# 大模型部署、运维、优化 — 端到端学习项目

> **目标**：从零到生产级，掌握 LLM 部署、推理优化、微调、运维、RAG/Agent 应用全链路
>
> **环境**：8×A800 80GB | Python 3.10 (conda: `cdp310_gpu`) | PyTorch 2.5.1+cu124 | CUDA 12.4
>
> **已调通**：端口 8001/8002 有 vLLM 服务在跑（Qwen3.5-35B-GPTQ-Int4），Docker 里还有 vLLM-Omni(8091/8092)

---

## 快速开始

```bash
# 1. 激活环境
conda activate cdp310_gpu

# 2. 绕过公司代理（重要！）
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY

# 3. 测试已有 vLLM 服务
curl --noproxy '*' http://localhost:8001/v1/models

# 4. 跑 benchmark
python3 src/benchmark/run_benchmark.py http://localhost:8001/v1 Qwen3.5-122B 10 4
```

---

## 目录结构总览

```
vllm_projects/
│
├── README.md                    ← 你在这里（本文件）
├── Dockerfile                   ← vLLM 推理服务容器镜像
│
├── docs/                        ← 📚 原理文档（30篇，按4轮组织）
│   ├── README.md                ←   文档总目录 + 学习路线图
│   ├── 00-environment/          ←   R1: CUDA工具链、GPU显存、推理框架生态
│   ├── 01-model-basics/         ←   R1: 架构对比、分词器、量化、位置编码
│   ├── 02-single-gpu-inference/ ←   R1: 推理流程、KV Cache、PagedAttn、FlashAttn
│   ├── 03-multi-gpu-inference/  ←   R1: 张量并行、流水线并行、NCCL通信
│   ├── 04-fine-tuning/          ←   R2: LoRA/QLoRA、SFT数据、RLHF/DPO、分布式训练
│   ├── 05-serving-optimization/ ←   R2: 调度策略、延迟/吞吐、量化部署、SpecDecode
│   ├── 06-production/           ←   R3: 监控、容错、容器化、安全
│   └── 07-application-layer/    ←   R4: API协议、RAG、Agent、多模态
│
├── src/                         ← 🐍 Python 源码
│   ├── gateway/                 ←   API 网关：路由 + 限流 + 安全 + 重试
│   ├── rag/                     ←   RAG 管线：切分 + Embedding + 检索 + 重排
│   ├── agent/                   ←   Agent：工具定义 + ReAct 循环
│   └── benchmark/               ←   压测：异步并发 benchmark
│
├── scripts/                     ← 🔧 Shell 运维脚本（全部可执行）
│   ├── check_env.sh             ←   环境检查
│   ├── deploy_vllm.sh           ←   单卡 vLLM 部署
│   ├── deploy_vllm_multigpu.sh  ←   多卡 TP 部署
│   ├── benchmark.sh             ←   API 压测
│   ├── health_monitor.sh        ←   健康检查 + 自动重启
│   ├── manage.sh                ←   Docker Compose 管理
│   └── entrypoint.sh            ←   Docker 容器入口
│
├── configs/                     ← ⚙️ 配置文件
│   ├── nginx.conf               ←   Nginx 负载均衡
│   ├── prometheus.yml           ←   Prometheus 抓取配置
│   ├── grafana_dashboard.json   ←   Grafana 监控面板
│   ├── docker-compose.yml       ←   Docker 服务编排
│   └── qwen2.5_7b_lora.yaml     ←   LLaMA-Factory LoRA 微调配置
│
├── experiments/                 ← 📊 实验记录
│   └── README.md                ←   实验日志 + 每轮检查清单 + 面试题
│
└── docs/superpowers/            ← 📋 项目管理（spec + plan）
    ├── specs/                   ←   设计文档
    └── plans/                   ←   实施计划
```

---

## 逐文件说明

### docs/ — 原理文档（30篇）

#### Round 1: 快速跑通全链路

| 文件 | 内容 |
|------|------|
| `docs/00-environment/cuda-toolchain.md` | CUDA 工具链五层架构、nvidia-smi 三行解读、版本兼容规则、PyTorch 下载源 |
| `docs/00-environment/gpu-memory-model.md` | A800 存储层次、推理显存分配公式、GQA 节省计算、本机 GPU 分布 |
| `docs/00-environment/inference-ecosystem.md` | vLLM/SGLang/Ollama/TGI/llama.cpp 对比、选型决策树、本机服务地图 |
| `docs/01-model-basics/model-architecture.md` | Decoder-only 架构、Qwen/LLaMA/DeepSeek 对比、GQA/MoE 详解、参数量估算 |
| `docs/01-model-basics/tokenizer-principles.md` | BPE 算法、中文分词特殊性、chat_template、特殊 token、tiktoken 使用 |
| `docs/01-model-basics/quantization-basics.md` | FP16/BF16/INT8/INT4 数值表示、GPTQ vs AWQ vs GGUF、量化模型下载源 |
| `docs/01-model-basics/position-encoding.md` | RoPE 数学原理、NTK-Aware/YaRN 外推、各模型位置编码对比 |
| `docs/02-single-gpu-inference/transformer-inference.md` | Prefill/Decode 两阶段、TTFT/TPOT 公式、compute-bound vs memory-bound |
| `docs/02-single-gpu-inference/kv-cache-deep-dive.md` | KV Cache 显存公式推导、GQA 压缩计算、FP8 KV Cache、面试计算题 |
| `docs/02-single-gpu-inference/paged-attention.md` | OS 虚拟内存类比、Block Table 映射、显存利用率 40%→96%、源码级理解 |
| `docs/02-single-gpu-inference/continuous-batching.md` | 静态 vs 动态 batching、Chunked Prefill、Preemption 策略、调度参数 |
| `docs/02-single-gpu-inference/flash-attention.md` | Tiling + Online Softmax、IO 复杂度分析、SRAM vs HBM、加速数据 |
| `docs/03-multi-gpu-inference/tensor-parallelism.md` | 列并行/行并行、Megatron 方案、通信量公式、本机 TP 分析 |
| `docs/03-multi-gpu-inference/pipeline-parallelism.md` | Bubble 问题、micro-batch 优化、TP vs PP 对比、混合并行 |
| `docs/03-multi-gpu-inference/nccl-communication.md` | AllReduce/AllGather/ReduceScatter、Ring Topology、NVLink vs PCIe |

#### Round 2: 深层优化

| 文件 | 内容 |
|------|------|
| `docs/04-fine-tuning/lora-qlora-principles.md` | 低秩分解数学、QLoRA NF4+双重量化、训练显存对比、LLaMA-Factory 配置 |
| `docs/04-fine-tuning/sft-data-engineering.md` | Alpaca/ShareGPT 格式、数据质量原则、去重方法、数据量经验 |
| `docs/04-fine-tuning/rlhf-dpo-theory.md` | RLHF 三阶段、Bradley-Terry 模型、DPO 消去 Reward Model 推导 |
| `docs/04-fine-tuning/distributed-training.md` | DeepSpeed ZeRO-1/2/3、FSDP、混合精度训练、梯度累积 |
| `docs/05-serving-optimization/scheduling-strategies.md` | 调度器工作流、Chunked Prefill、Prefix Caching 调度影响、Preemption |
| `docs/05-serving-optimization/latency-throughput.md` | TTFT/TPOT/Throughput 优化决策树、队列理论、调优记录模板 |
| `docs/05-serving-optimization/quantization-deploy.md` | GPTQ Marlin/AWQ/FP8 部署命令、本机实例、自己量化模型方法 |
| `docs/05-serving-optimization/speculative-decoding.md` | Draft-Target 架构、接受率与加速比公式、Tree Attention、vLLM 配置 |

#### Round 3: 生产加固

| 文件 | 内容 |
|------|------|
| `docs/06-production/monitoring-observability.md` | RED/USE 方法、vLLM metrics、Prometheus 配置、Grafana 面板、DCGM |
| `docs/06-production/fault-tolerance.md` | 故障模式分类、指数退避+Jitter、Circuit Breaker、健康检查、故障演练 |
| `docs/06-production/containerization.md` | Docker GPU 原理、Dockerfile、Docker Compose、本机 Docker 实例 |
| `docs/06-production/security.md` | Prompt Injection 防护、输入验证、API Key 管理、审计日志、安全检查清单 |

#### Round 4: 应用层扩展

| 文件 | 内容 |
|------|------|
| `docs/07-application-layer/openai-api-protocol.md` | Chat Completions 协议、SSE streaming、curl 绕过代理、Python SDK |
| `docs/07-application-layer/rag-pipeline.md` | RAG 全链路、Chunking 策略、Embedding 模型、向量数据库、Reranker |
| `docs/07-application-layer/agent-function-calling.md` | Function Calling 流程、ReAct 模式、vLLM 工具配置、安全限制 |
| `docs/07-application-layer/multimodal-deploy.md` | VLM 架构、图像 token 计算、Qwen2.5-VL 部署、API 调用 |

### src/ — Python 源码（10 个模块）

#### API 网关 `src/gateway/`

| 文件 | 功能 | 启动方式 |
|------|------|---------|
| `main.py` | 多模型路由 + 限流 + 安全检测 + 流式透传 | `uvicorn src.gateway.main:app --port 8080` |
| `ratelimit.py` | Token Bucket 算法，per API Key 独立限流 | 被 main.py 调用 |
| `security.py` | Prompt Injection 检测、输入长度限制、API Key 生成、审计日志 | 被 main.py 调用 |
| `client.py` | 带指数退避+Jitter 重试的 OpenAI 客户端封装 | `RobustLLMClient(base_url).chat(...)` |

#### RAG 管线 `src/rag/`

| 文件 | 功能 | 启动方式 |
|------|------|---------|
| `embedding_service.py` | BGE-large-zh-v1.5 Embedding 服务 (1024维) | `uvicorn src.rag.embedding_service:app --port 8002` |
| `rag_pipeline.py` | 完整 RAG：向量检索 → Cross-Encoder 重排 → LLM 生成 | `RAGPipeline().query("问题")` |
| `chunker.py` | 递归字符切分器，保留语义边界 | `DocumentChunker().chunk_documents(docs)` |

#### Agent `src/agent/`

| 文件 | 功能 | 启动方式 |
|------|------|---------|
| `tool_server.py` | 工具定义(OpenAI 格式) + 工具执行注册表 | 被 agent_loop.py 调用 |
| `agent_loop.py` | ReAct 主循环(Thought→Action→Observation) | `python3 src/agent/agent_loop.py` |

#### 压测 `src/benchmark/`

| 文件 | 功能 | 启动方式 |
|------|------|---------|
| `run_benchmark.py` | 异步并发压测，输出 TTFT/TPOT/Throughput | `python3 src/benchmark/run_benchmark.py [url] [model] [conc] [n]` |

### scripts/ — Shell 脚本（7 个）

| 脚本 | 功能 | 用法 |
|------|------|------|
| `check_env.sh` | GPU/驱动/CUDA/PyTorch/vLLM 环境全量检查 | `bash check_env.sh` |
| `deploy_vllm.sh` | 单卡 vLLM 部署，含完整参数说明 | `bash deploy_vllm.sh [model] [port] [gpu]` |
| `deploy_vllm_multigpu.sh` | 多卡 TP 部署，自动等待就绪 | `bash deploy_vllm_multigpu.sh [model] [tp] [port] [gpus]` |
| `benchmark.sh` | vLLM API 并发压测（一键脚本） | `bash benchmark.sh [host] [port] [model] [n] [conc]` |
| `health_monitor.sh` | 后台健康检查 + 指数退避自动重启 + 重启次数限制 | `bash health_monitor.sh [port] [model] [gpu]` |
| `manage.sh` | Docker Compose 一键管理 (up/down/ps/logs/status) | `bash manage.sh up\|down\|ps\|logs\|status` |
| `entrypoint.sh` | Docker 容器入口脚本，从环境变量读取配置 | Dockerfile 中调用 |

### configs/ — 配置文件（5 个）

| 文件 | 功能 | 用法 |
|------|------|------|
| `nginx.conf` | Nginx 反向代理 + least_conn 负载均衡 + SSE 支持 + 限流 | `nginx -c configs/nginx.conf` |
| `prometheus.yml` | vLLM + Gateway 指标抓取配置 | `prometheus --config.file=configs/prometheus.yml` |
| `grafana_dashboard.json` | 8 面板仪表盘（QPS/TTFT/TPOT/GPU/Requests/Error） | Grafana 导入 |
| `docker-compose.yml` | vLLM + Nginx 容器编排 | `docker-compose -f configs/docker-compose.yml up -d` |
| `qwen2.5_7b_lora.yaml` | LLaMA-Factory LoRA 微调配置 | `llamafactory-cli train configs/qwen2.5_7b_lora.yaml` |

---

## 学习路线

```
Round 1 (~1周)         Round 2 (~2周)          Round 3 (~1周)          Round 4 (~2周)
快速跑通全链路          深层优化                 生产加固                 应用层扩展
                                                                   
环境(CUDA/GMem)  →  FlashAttention      →  API网关+限流       →  RAG全管线
模型(架构/分词)  →  SpecDecode          →  Nginx负载均衡      →  Agent/FC
单卡推理(KVCache)→  LoRA/QLoRA微调      →  Prometheus+Grafana →  多模态部署
多卡推理(TP)     →  调度/性能调优        →  容错/健康检查       →  安全加固
Benchmark        →  量化部署/模型评估    →  Docker/K8s编排     →  全面回顾
```

---

## 已调通的基础设施

| 服务 | 端口 | 状态 |
|------|------|------|
| vLLM (Qwen3.5-35B-GPTQ) | 8001, 8002 | ✅ 运行中 |
| vLLM-Omni TTS | 8091 (Docker) | ✅ 运行中 |
| vLLM-Omni OCR | 8092 (Docker) | ✅ 运行中 |
| DeepSeek-32B (TP=2) | 9003 | ✅ 运行中 |
| DCGM Exporter | 9400 (Docker) | ✅ 运行中 |
| Dify | Docker | ✅ 运行中 |
| Weaviate (向量库) | Docker | ✅ 运行中 |

⚠️ **重要**：公司代理 `TPEproxyNwing` 会拦截 localhost 请求，访问本地服务时必须：
```bash
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY
curl --noproxy '*' http://localhost:8001/health
```

---

## 15 道面试自测题

完成全部学习后应该能回答：

1. Transformer 推理 Prefill 和 Decode 的计算特性有什么不同？瓶颈分别是什么？
2. KV Cache 占用多少显存？公式怎么写？GQA 如何减少 KV Cache？
3. PagedAttention 解决了什么问题？和 OS 虚拟内存的类比？
4. Continuous Batching 为什么比静态 batching 好？
5. FlashAttention 为什么省显存、为什么快？
6. TP 和 PP 的区别？各适合什么场景？通信量怎么算？
7. LoRA 为什么有效？秩 r 怎么选？QLoRA 做了哪些量化？
8. GPTQ vs AWQ 的区别？per-token vs per-channel？
9. Speculative Decoding 加速原理？什么情况下加速比为 1？
10. RAG 中为什么用 Reranker？Bi-Encoder 和 Cross-Encoder 的区别？
11. vLLM 比 HuggingFace Transformers 快在哪几个方面？
12. 推理服务从收到请求到返回结果，中间经历了哪些步骤？
13. P99 延迟突然飙高，从哪些维度排查？
14. 怎么估算部署一个 N-B 模型需要多少 GPU 显存？
15. 大模型部署有哪些安全风险？如何防范？
