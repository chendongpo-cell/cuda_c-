"""run_benchmark.py — vLLM 并发压测脚本

用法:
    python3 src/benchmark/run_benchmark.py [url] [model] [concurrency] [num_prompts]
"""

import asyncio, time, json, statistics, sys, os
from openai import AsyncOpenAI

os.environ.pop("http_proxy", None)
os.environ.pop("https_proxy", None)


async def run_benchmark(
    base_url: str = "http://localhost:8001/v1",
    model: str = "Qwen3.5-122B",
    num_prompts: int = 50,
    concurrency: int = 4,
    max_tokens: int = 128,
):
    client = AsyncOpenAI(base_url=base_url, api_key="dummy", timeout=120)
    sem = asyncio.Semaphore(concurrency)

    async def one_request(prompt: str, idx: int) -> dict:
        async with sem:
            t0 = time.monotonic()
            ttft = None
            try:
                stream = await client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=max_tokens, stream=True, temperature=0,
                )
                out_tokens = 0
                async for chunk in stream:
                    if ttft is None:
                        ttft = time.monotonic() - t0
                    if chunk.choices[0].delta.content:
                        out_tokens += 1
                total = time.monotonic() - t0
                return {"ttft": ttft, "total": total, "tokens": out_tokens, "status": "ok"}
            except Exception as e:
                return {"status": "error", "error": str(e), "ttft": None,
                        "total": time.monotonic() - t0, "tokens": 0}

    prompts = [
        f"请详细解释第{i}个AI和机器学习概念，包括其定义、主要应用场景、优点和局限性。"
        for i in range(num_prompts)
    ]

    print(f"Benchmark: {model} | prompts={num_prompts} | concurrency={concurrency}")
    t0 = time.monotonic()
    results = await asyncio.gather(*[one_request(p, i) for i, p in enumerate(prompts)])
    wall = time.monotonic() - t0

    ok = [r for r in results if r["status"] == "ok"]
    err = [r for r in results if r["status"] == "error"]

    if not ok:
        print("All requests failed!")
        return

    ttfts = [r["ttft"] for r in ok if r["ttft"]]
    tpots = [(r["total"]-r["ttft"])/max(r["tokens"],1)
             for r in ok if r["ttft"] and r["tokens"]>0]
    total_tokens = sum(r["tokens"] for r in ok)

    report = {
        "model": model, "num_prompts": num_prompts, "concurrency": concurrency,
        "successful": len(ok), "failed": len(err),
        "wall_time_s": round(wall, 1),
        "throughput_tps": round(total_tokens / wall, 1),
        "qps": round(len(ok) / wall, 2),
        "ttft_ms_p50": round(sorted(ttfts)[len(ttfts)//2] * 1000),
        "ttft_ms_p95": round(sorted(ttfts)[int(len(ttfts)*0.95)] * 1000),
        "ttft_ms_p99": round(sorted(ttfts)[int(len(ttfts)*0.99)] * 1000),
        "tpot_ms_p50": round(sorted(tpots)[len(tpots)//2] * 1000),
        "tpot_ms_p95": round(sorted(tpots)[int(len(tpots)*0.95)] * 1000),
    }

    print(f"""
{'='*60}
Benchmark Results
{'='*60}
Requests:  {len(results)} total, {len(ok)} ok, {len(err)} failed
Wall time: {wall:.1f}s  |  Throughput: {total_tokens/wall:.1f} t/s  |  QPS: {len(ok)/wall:.2f}
--- Latency ---
TTFT P50:  {report['ttft_ms_p50']}ms  |  P95: {report['ttft_ms_p95']}ms  |  P99: {report['ttft_ms_p99']}ms
TPOT P50:  {report['tpot_ms_p50']}ms  |  P95: {report['tpot_ms_p95']}ms
{'='*60}
""")
    return report


if __name__ == "__main__":
    url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8001/v1"
    model = sys.argv[2] if len(sys.argv) > 2 else "Qwen3.5-122B"
    conc = int(sys.argv[3]) if len(sys.argv) > 3 else 4
    n = int(sys.argv[4]) if len(sys.argv) > 4 else 50
    asyncio.run(run_benchmark(url, model, n, conc))
