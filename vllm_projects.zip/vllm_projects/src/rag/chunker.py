"""chunker.py — 文档智能切分器

支持: 递归字符切分（优先保留语义边界）

用法:
    chunker = DocumentChunker(chunk_size=500, chunk_overlap=50)
    chunks = chunker.chunk_documents([
        {"text": "长文档...", "metadata": {"source": "file.pdf"}}
    ])
"""

import uuid
import re
from typing import List, Dict


class DocumentChunker:
    """递归字符切分器"""

    def __init__(self, chunk_size: int = 500, chunk_overlap: int = 50):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        # 切分优先级: 段落 → 行 → 句子 → 逗号 → 空格 → 字符
        self.separators = ["\n\n", "\n", "。", "！", "？", "；", "，", " ", ""]

    def split_text(self, text: str) -> List[str]:
        return self._split_recursive(text, self.separators)

    def _split_recursive(self, text: str, separators: List[str]) -> List[str]:
        if not separators:
            # 最后手段: 按字符硬切
            step = self.chunk_size - self.chunk_overlap
            return [text[i:i+self.chunk_size] for i in range(0, len(text), step)]

        sep = separators[0]
        remaining = separators[1:]

        if sep == "":
            return self._split_recursive(text, remaining)

        splits = text.split(sep)
        chunks, current = [], ""

        for split in splits:
            candidate = current + (sep if current else "") + split
            if len(candidate) <= self.chunk_size:
                current = candidate
            else:
                if current.strip():
                    chunks.append(current.strip())
                if len(split) > self.chunk_size:
                    chunks.extend(self._split_recursive(split, remaining))
                    current = ""
                else:
                    current = split

        if current.strip():
            chunks.append(current.strip())

        return chunks

    def chunk_documents(self, documents: List[Dict]) -> List[Dict]:
        """批量切分，保留元数据"""
        all_chunks = []
        for doc in documents:
            parts = self.split_text(doc["text"])
            for i, part in enumerate(parts):
                all_chunks.append({
                    "id": str(uuid.uuid4()),
                    "text": part,
                    "metadata": {
                        **(doc.get("metadata", {})),
                        "chunk_index": i,
                        "chunk_total": len(parts),
                    }
                })
        return all_chunks
