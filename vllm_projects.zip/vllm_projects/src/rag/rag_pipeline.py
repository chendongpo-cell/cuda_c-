"""rag_pipeline.py — RAG 完整管线

流程: 检索(Top-K) → 重排序(Cross-Encoder) → 生成(LLM)

用法:
    rag = RAGPipeline()
    rag.index(documents)            # 离线索引
    result = rag.query("问题")       # 在线查询
"""

import json
import requests
from typing import List, Dict, Optional
from sentence_transformers import CrossEncoder
import chromadb
from openai import OpenAI


class RAGPipeline:
    """端到端 RAG 管线"""

    def __init__(
        self,
        embedding_url: str = "http://localhost:8002/v1/embeddings",
        llm_url: str = "http://localhost:8001/v1",
        llm_model: str = "Qwen3.5-122B",
        chroma_path: str = "/data/chendongpo/agent_projects/vllm_projects/data/chroma_db",
    ):
        self.embedding_url = embedding_url
        self.llm = OpenAI(base_url=llm_url, api_key="dummy")
        self.llm_model = llm_model

        self.chroma_client = chromadb.PersistentClient(path=chroma_path)
        self.collection = self.chroma_client.get_or_create_collection(
            name="knowledge_base", metadata={"hnsw:space": "cosine"}
        )
        self._reranker = None

    @property
    def reranker(self):
        if self._reranker is None:
            self._reranker = CrossEncoder(
                "BAAI/bge-reranker-v2-m3", device="cuda"
            )
        return self._reranker

    def embed(self, texts: List[str], is_query: bool = False) -> List[List[float]]:
        instruction = "为这个句子生成表示以用于检索相关文章：" if is_query else ""
        resp = requests.post(self.embedding_url,
            json={"texts": texts, "instruction": instruction})
        resp.raise_for_status()
        return resp.json()["embeddings"]

    def index(self, documents: List[Dict]):
        """索引文档"""
        texts = [d["text"] for d in documents]
        embeddings = self.embed(texts, is_query=False)
        self.collection.add(
            ids=[d["id"] for d in documents],
            embeddings=embeddings,
            documents=texts,
            metadatas=[d.get("metadata", {}) for d in documents],
        )
        print(f"Indexed {len(documents)} documents")

    def retrieve(self, query: str, top_k: int = 10) -> List[Dict]:
        """向量检索"""
        query_vec = self.embed([query], is_query=True)[0]
        results = self.collection.query(query_embeddings=[query_vec], n_results=top_k)
        return [
            {
                "id": results["ids"][0][i],
                "text": results["documents"][0][i],
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                "distance": results["distances"][0][i] if results["distances"] else None,
            }
            for i in range(len(results["ids"][0]))
        ]

    def rerank(self, query: str, documents: List[Dict], top_k: int = 3) -> List[Dict]:
        """Cross-Encoder 重排序"""
        pairs = [[query, d["text"]] for d in documents]
        scores = self.reranker.predict(pairs)
        for doc, score in zip(documents, scores):
            doc["rerank_score"] = float(score)
        documents.sort(key=lambda x: x["rerank_score"], reverse=True)
        return documents[:top_k]

    def generate(self, query: str, context_docs: List[Dict], max_tokens: int = 500) -> str:
        """基于检索结果生成回答"""
        context_text = "\n\n---\n\n".join(
            f"[来源{i+1}]: {d['text']}" for i, d in enumerate(context_docs)
        )
        prompt = f"""基于以下参考资料回答问题。如无相关信息，请如实说明。

## 参考资料
{context_text}

## 问题
{query}

## 回答"""
        resp = self.llm.chat.completions.create(
            model=self.llm_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3, max_tokens=max_tokens,
        )
        return resp.choices[0].message.content

    def query(self, question: str, top_k_retrieve: int = 10,
              top_k_rerank: int = 3, use_rerank: bool = True) -> Dict:
        """完整 RAG 查询"""
        docs = self.retrieve(question, top_k=top_k_retrieve)
        if use_rerank and len(docs) > top_k_rerank:
            docs = self.rerank(question, docs, top_k=top_k_rerank)
        else:
            docs = docs[:top_k_rerank]
        answer = self.generate(question, docs)
        return {
            "question": question,
            "answer": answer,
            "sources": [
                {"id": d["id"], "text_preview": d["text"][:200],
                 "score": d.get("rerank_score", d.get("distance")),
                 "metadata": d.get("metadata", {})}
                for d in docs
            ],
        }
