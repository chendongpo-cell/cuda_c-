"""embedding_service.py — BGE Embedding 模型部署服务

启动:
    python3 -m uvicorn src.rag.embedding_service:app --port 8002

模型: BAAI/bge-large-zh-v1.5 (1024维, 中文最优之一)

API:
    POST /v1/embeddings  {"texts": [...], "instruction": "..."}
    GET  /health
"""

from fastapi import FastAPI
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
import torch

app = FastAPI(title="Embedding Service")

model = SentenceTransformer(
    "BAAI/bge-large-zh-v1.5",
    device="cuda" if torch.cuda.is_available() else "cpu"
)
# normalize → 内积 = cosine similarity
model.encode = lambda texts, **kw: model.encode(
    texts, normalize_embeddings=True, **kw
)


class EmbedRequest(BaseModel):
    texts: list[str]
    instruction: str = ""


class EmbedResponse(BaseModel):
    embeddings: list[list[float]]
    dimensions: int


@app.post("/v1/embeddings", response_model=EmbedResponse)
async def embed(request: EmbedRequest):
    texts = request.texts
    # BGE: query 加 instruction 前缀可提升检索效果
    if request.instruction:
        texts = [f"{request.instruction}{t}" for t in texts]

    embeddings = model.encode(texts, batch_size=32, show_progress_bar=False)
    return EmbedResponse(
        embeddings=embeddings.tolist(),
        dimensions=int(embeddings.shape[1]),
    )


@app.get("/health")
async def health():
    return {"status": "ok", "model": "BAAI/bge-large-zh-v1.5"}
