"""rag_pipeline_prod.py — 基于内网基础设施的生产级 RAG 管线

使用 office_config 中配置的服务:
  LLM:       DeepSeek-Flash  @ 10.210.48.94:31610
  Embedding: BGE-M3          @ 10.210.52.229:6053
  Reranker:  BGE Reranker    @ 10.210.52.229:6054
  Milvus:                     @ 10.210.52.229:19530
  MySQL:                      @ 10.210.52.229:6052
"""

import json
import time
import requests
from typing import List, Dict, Optional
from pymilvus import connections, Collection, FieldSchema, CollectionSchema, DataType, utility


# ============ 内网配置 ============
LLM_URL = "http://10.210.48.94:31610/v1/chat/completions"
LLM_KEY = "sk-3PicmJ3fzLeXB8hpKcDJgvGHpqdtOxr6x5UF2Xwg8IYzrH2D"
LLM_MODEL = "deepseek-flash"

EMBED_URL = "http://10.210.52.229:6053/encode"
RERANK_URL = "http://10.210.52.229:6054/rerank"

MILVUS_HOST = "10.210.52.229"
MILVUS_PORT = 19530
MILVUS_DIM = 1024
MILVUS_COLLECTION = "vllm_projects_collection"  # {项目名}_collection


class ProdRAGPipeline:
    """基于内网基础设施的生产级 RAG 管线"""

    def __init__(self):
        # 连接 Milvus
        connections.connect(host=MILVUS_HOST, port=MILVUS_PORT)
        self._ensure_collection()
        self.collection = Collection(MILVUS_COLLECTION)
        self.collection.load()

    def _ensure_collection(self):
        """创建 Milvus 集合 (如果不存在)"""
        if utility.has_collection(MILVUS_COLLECTION):
            return

        fields = [
            FieldSchema(name="id", dtype=DataType.VARCHAR, is_primary=True, max_length=64),
            FieldSchema(name="text", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=MILVUS_DIM),
            FieldSchema(name="source", dtype=DataType.VARCHAR, max_length=512),
        ]
        schema = CollectionSchema(fields, description="vllm_projects knowledge base")
        collection = Collection(MILVUS_COLLECTION, schema)

        # 创建索引
        index_params = {
            "metric_type": "COSINE",
            "index_type": "IVF_FLAT",
            "params": {"nlist": 128}
        }
        collection.create_index("embedding", index_params)
        print(f"Created Milvus collection: {MILVUS_COLLECTION}")

    def embed(self, texts: List[str]) -> List[List[float]]:
        """调用内网 BGE-M3 Embedding"""
        resp = requests.post(EMBED_URL, json={"texts": texts}, timeout=30)
        resp.raise_for_status()
        return resp.json()["embeddings"]

    def index(self, documents: List[Dict]):
        """索引文档到 Milvus"""
        texts = [d["text"] for d in documents]
        embeddings = self.embed(texts)

        entities = [
            [d["id"] for d in documents],
            texts,
            embeddings,
            [d.get("metadata", {}).get("source", "") for d in documents],
        ]
        self.collection.insert(entities)
        self.collection.flush()
        print(f"Indexed {len(documents)} documents to Milvus")

    def retrieve(self, query: str, top_k: int = 10) -> List[Dict]:
        """向量检索 (Milvus)"""
        query_vec = self.embed([query])[0]

        results = self.collection.search(
            data=[query_vec],
            anns_field="embedding",
            param={"metric_type": "COSINE", "params": {"nprobe": 16}},
            limit=top_k,
            output_fields=["text", "source"]
        )

        docs = []
        for hits in results:
            for hit in hits:
                docs.append({
                    "id": hit.id,
                    "text": hit.entity.get("text", ""),
                    "source": hit.entity.get("source", ""),
                    "score": hit.score,
                })
        return docs

    def rerank(self, query: str, documents: List[Dict], top_k: int = 3) -> List[Dict]:
        """调用内网 BGE Reranker"""
        docs_text = [d["text"] for d in documents]
        resp = requests.post(RERANK_URL, json={
            "query": query, "docs": docs_text, "top_k": top_k
        }, timeout=30)
        resp.raise_for_status()
        ranked = resp.json()

        results = []
        for item in ranked:
            idx = item["index"]
            doc = documents[idx].copy()
            doc["rerank_score"] = item["score"]
            results.append(doc)
        return results

    def generate(self, query: str, context_docs: List[Dict], max_tokens: int = 500) -> str:
        """调用内网 DeepSeek-Flash 生成回答"""
        context_text = "\n\n---\n\n".join(
            f"[来源{i+1}]: {d['text']}" for i, d in enumerate(context_docs)
        )
        prompt = f"""基于以下参考资料回答问题。如无相关信息请如实说明。

## 参考资料
{context_text}

## 问题
{query}

## 回答"""

        resp = requests.post(
            LLM_URL,
            headers={"Authorization": f"Bearer {LLM_KEY}", "Content-Type": "application/json"},
            json={
                "model": LLM_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.3,
                "max_tokens": max_tokens,
            },
            timeout=120
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]

    def query(self, question: str, top_k_retrieve: int = 10,
              top_k_rerank: int = 3, use_rerank: bool = True) -> Dict:
        t0 = time.time()

        # 1. 检索
        docs = self.retrieve(question, top_k=top_k_retrieve)
        t1 = time.time()

        # 2. 重排序
        if use_rerank and len(docs) > top_k_rerank:
            docs = self.rerank(question, docs, top_k=top_k_rerank)
        else:
            docs = docs[:top_k_rerank]
        t2 = time.time()

        # 3. 生成
        answer = self.generate(question, docs)
        t3 = time.time()

        return {
            "question": question,
            "answer": answer,
            "sources": [
                {"id": d["id"], "text_preview": d["text"][:200],
                 "score": d.get("rerank_score", d.get("score")),
                 "source": d.get("source", "")}
                for d in docs
            ],
            "timing": {
                "retrieve_ms": (t1 - t0) * 1000,
                "rerank_ms": (t2 - t1) * 1000,
                "generate_ms": (t3 - t2) * 1000,
            }
        }
