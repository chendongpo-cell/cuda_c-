"""main.py — LLM API 网关

功能:
- 多模型路由（根据 model 名转发到不同后端）
- Token Bucket 限流（per API Key）
- 安全检测（注入过滤 + 输入验证）
- 流式透传

启动:
    python3 -m uvicorn src.gateway.main:app --host 0.0.0.0 --port 8080
"""

import os
import time
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse

from src.gateway.ratelimit import RateLimiter
from src.gateway.security import validate_request, log_request

# 绕过代理
os.environ.pop("http_proxy", None)
os.environ.pop("https_proxy", None)

app = FastAPI(title="LLM Gateway", version="1.0.0")
rate_limiter = RateLimiter(default_rate=20, default_burst=40)

# ============ 模型路由表 ============
MODELS = {
    "qwen3.5-35b": {
        "endpoints": ["http://localhost:8001/v1"],
        "max_tokens": 8192,
    },
}

_round_robin: dict[str, int] = {}


def get_endpoint(model_name: str) -> str:
    """轮询负载均衡"""
    if model_name not in MODELS:
        raise HTTPException(400, f"Unknown model: {model_name}")
    endpoints = MODELS[model_name]["endpoints"]
    idx = _round_robin.get(model_name, 0) % len(endpoints)
    _round_robin[model_name] = idx + 1
    return endpoints[idx]


@app.get("/health")
async def health():
    return {"status": "ok", "models": list(MODELS.keys())}


@app.get("/v1/models")
async def list_models():
    return {"object": "list", "data": [
        {"id": name, "object": "model"} for name in MODELS
    ]}


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    t_start = time.time()

    # 1. 提取 API Key + 限流
    auth = request.headers.get("Authorization", "")
    api_key = auth.replace("Bearer ", "") if auth.startswith("Bearer ") else "anonymous"
    if not await rate_limiter.is_allowed(api_key):
        raise HTTPException(429, "Rate limit exceeded", headers={"Retry-After": "5"})

    # 2. 解析 + 安全验证
    body = await request.json()
    violations = validate_request(body)
    if violations:
        raise HTTPException(400, "; ".join(violations))

    # 3. 模型路由
    model_name = body.get("model", list(MODELS.keys())[0])
    endpoint = get_endpoint(model_name)
    backend_url = f"{endpoint}/chat/completions"

    # 4. 限制 max_tokens
    max_model_tokens = MODELS.get(model_name, {}).get("max_tokens", 4096)
    if body.get("max_tokens", 256) > max_model_tokens:
        body["max_tokens"] = max_model_tokens

    # 5. 转发
    async with httpx.AsyncClient(timeout=120.0) as client:
        try:
            if body.get("stream"):
                req = client.build_request("POST", backend_url, json=body,
                    headers={"Authorization": "Bearer dummy", "Content-Type": "application/json"})
                backend_resp = await client.send(req, stream=True)
                if backend_resp.status_code >= 400:
                    content = await backend_resp.aread()
                    log_request(api_key[:8], model_name, 0, 0,
                                (time.time()-t_start)*1000, f"error_{backend_resp.status_code}")
                    raise HTTPException(backend_resp.status_code, detail=content.decode()[:500])
                log_request(api_key[:8], model_name, 0, 0,
                            (time.time()-t_start)*1000, "streaming")
                return StreamingResponse(backend_resp.aiter_bytes(),
                    media_type="text/event-stream",
                    headers={"Cache-Control": "no-cache", "Connection": "keep-alive"})
            else:
                resp = await client.post(backend_url, json=body,
                    headers={"Authorization": "Bearer dummy"})
                if resp.status_code >= 400:
                    raise HTTPException(resp.status_code, detail=resp.text[:500])
                data = resp.json()
                usage = data.get("usage", {})
                log_request(api_key[:8], model_name,
                            usage.get("prompt_tokens", 0),
                            usage.get("completion_tokens", 0),
                            (time.time()-t_start)*1000, "ok")
                return data
        except httpx.TimeoutException:
            log_request(api_key[:8], model_name, 0, 0,
                        (time.time()-t_start)*1000, "timeout")
            raise HTTPException(504, "Backend timeout")
