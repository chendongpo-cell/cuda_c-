"""client.py — 带指数退避重试的 LLM 客户端封装

用法:
    client = RobustLLMClient("http://localhost:8080/v1", max_retries=3)
    answer = client.chat(
        model="qwen2.5-7b",
        messages=[{"role": "user", "content": "Hello"}],
        max_tokens=100
    )
"""

import time
import random
import logging
from openai import OpenAI, APIError, APITimeoutError, APIConnectionError

logger = logging.getLogger(__name__)


class RobustLLMClient:
    """带重试 + 指数退避的 OpenAI 兼容客户端"""

    RETRYABLE_STATUSES = {429, 500, 502, 503, 504}

    def __init__(self, base_url: str, api_key: str = "dummy", max_retries: int = 3):
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.max_retries = max_retries

    def chat(self, **kwargs) -> str:
        """发送 Chat 请求，自动重试"""
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                stream = kwargs.pop("stream", False)
                response = self.client.chat.completions.create(**kwargs)
                if stream:
                    return response
                return response.choices[0].message.content
            except APITimeoutError as e:
                last_error = e
                logger.warning(f"Timeout (attempt {attempt+1})")
                if attempt < self.max_retries:
                    time.sleep(self._backoff(attempt))
            except APIConnectionError as e:
                last_error = e
                logger.warning(f"Connection error (attempt {attempt+1})")
                if attempt < self.max_retries:
                    time.sleep(self._backoff(attempt))
            except APIError as e:
                if e.status_code in self.RETRYABLE_STATUSES:
                    last_error = e
                    logger.warning(f"Retryable {e.status_code} (attempt {attempt+1})")
                    if attempt < self.max_retries:
                        retry_after = e.response.headers.get("Retry-After", self._backoff(attempt))
                        time.sleep(float(retry_after))
                        continue
                raise
        raise last_error

    @staticmethod
    def _backoff(attempt: int) -> float:
        """指数退避 + 随机抖动，最多30秒"""
        return min(2 ** attempt + random.uniform(0, 1), 30)
