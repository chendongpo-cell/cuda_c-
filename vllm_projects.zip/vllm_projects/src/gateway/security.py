"""security.py — LLM API 安全中间件

防护:
- Prompt Injection 检测
- 输入长度限制
- API Key 生成
- 请求审计日志
"""

import re
import hashlib
import secrets
import logging
from typing import Optional

logger = logging.getLogger("llm_api")

# ============ 注入检测规则 ============
INJECTION_PATTERNS = [
    (r"忽略\s*(所有|一切|之前)\s*(指令|规则|限制)", "指令覆盖攻击"),
    (r"ignore\s*(all|previous)\s*(instruction|prompt|rule)", "Prompt injection (EN)"),
    (r"(reveal|show|print|output)\s*(your|the)\s*(system\s*)?prompt", "System prompt 泄露"),
    (r"(DAN|Developer\s*Mode|jailbreak|越狱)", "Jailbreak 尝试"),
    (r"你\s*现在\s*(是|扮演|作为)", "角色扮演注入"),
]

# ============ 输入限制 ============
MAX_PROMPT_CHARS = 100000      # 总输入字符上限
MAX_OUTPUT_TOKENS = 4096       # 单次输出 token 上限
MAX_TOOL_CALLS = 10            # Agent 工具调用上限


def detect_injection(text: str) -> Optional[str]:
    """检测 prompt injection，返回攻击类型或 None"""
    for pattern, attack_type in INJECTION_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            return attack_type
    return None


def validate_request(body: dict) -> list[str]:
    """验证请求，返回违规列表（空=通过）"""
    violations = []

    # 1. 输入长度
    total_chars = 0
    for msg in body.get("messages", []):
        content = msg.get("content", "")
        if isinstance(content, str):
            total_chars += len(content)
        elif isinstance(content, list):
            total_chars += sum(
                len(p.get("text", "")) for p in content if p.get("type") == "text"
            )
    if total_chars > MAX_PROMPT_CHARS:
        violations.append(f"Input too long: {total_chars} chars (max {MAX_PROMPT_CHARS})")

    # 2. 输出上限
    if body.get("max_tokens", 256) > MAX_OUTPUT_TOKENS:
        violations.append(f"max_tokens too large (max {MAX_OUTPUT_TOKENS})")

    # 3. 注入检测
    for msg in body.get("messages", []):
        content = msg.get("content", "")
        texts = []
        if isinstance(content, str):
            texts = [content]
        elif isinstance(content, list):
            texts = [p.get("text", "") for p in content if p.get("type") == "text"]

        for text in texts:
            attack = detect_injection(text)
            if attack:
                violations.append(f"Content policy violation: {attack}")
                break

    return violations


def generate_api_key() -> tuple[str, str]:
    """生成 API Key 和 SHA256 哈希

    Returns:
        (raw_key, hashed_key) — raw 给用户，hashed 存服务端
    """
    raw = "sk-" + secrets.token_urlsafe(48)
    hashed = hashlib.sha256(raw.encode()).hexdigest()
    return raw, hashed


def log_request(api_key_hash: str, model: str,
                prompt_tokens: int, completion_tokens: int,
                duration_ms: float, status: str):
    """审计日志"""
    logger.info(
        f"key={api_key_hash[:8]}... model={model} "
        f"tokens={prompt_tokens}/{completion_tokens} "
        f"dur={duration_ms:.0f}ms status={status}"
    )
