"""ratelimit.py — Token Bucket 限流器

Token Bucket 算法:
- 以固定速率(rate)补充 token
- 最多攒 burst 个 token
- 每个请求消耗 1 个 token
- 桶空返回 False (触发 429)

用法:
    limiter = RateLimiter(default_rate=20, default_burst=40)
    if await limiter.is_allowed("user-api-key"):
        process_request()
    else:
        return 429
"""

import asyncio
import time
from collections import defaultdict


class TokenBucket:
    """单个 Token Bucket"""

    def __init__(self, rate: float, burst: int):
        self.rate = rate          # tokens/second
        self.burst = burst        # 最大容量
        self.tokens = float(burst)
        self.last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    async def consume(self, tokens: int = 1) -> bool:
        """尝试消费 token，成功返回 True"""
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_refill
            self.tokens = min(self.burst, self.tokens + elapsed * self.rate)
            self.last_refill = now
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False


class RateLimiter:
    """按 API Key 管理的多桶限流器"""

    def __init__(self, default_rate: float = 20, default_burst: int = 40):
        self.default_rate = default_rate
        self.default_burst = default_burst
        self.buckets: dict[str, TokenBucket] = {}
        self._lock = asyncio.Lock()

    async def get_bucket(self, key: str) -> TokenBucket:
        if key not in self.buckets:
            async with self._lock:
                if key not in self.buckets:
                    self.buckets[key] = TokenBucket(
                        self.default_rate, self.default_burst
                    )
        return self.buckets[key]

    async def is_allowed(self, key: str) -> bool:
        bucket = await self.get_bucket(key)
        return await bucket.consume()

    def stats(self) -> dict:
        return {
            "active_buckets": len(self.buckets),
            "default_rate": self.default_rate,
            "default_burst": self.default_burst,
        }
