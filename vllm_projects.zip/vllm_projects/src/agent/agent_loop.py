"""agent_loop.py — ReAct 模式 Agent 主循环

Thought → Action → Observation → Thought → ... → Final Answer

用法:
    agent = ReActAgent(llm_url="http://localhost:8001/v1", model="Qwen3.5-122B")
    answer = agent.run("今天上海天气怎么样？")
"""

import json
import logging
from typing import List, Dict
from openai import OpenAI
from src.agent.tool_server import TOOLS, execute_tool

logger = logging.getLogger(__name__)


class ReActAgent:
    """ReAct (Reasoning + Acting) Agent"""

    def __init__(
        self,
        llm_url: str = "http://localhost:8001/v1",
        model: str = "Qwen3.5-122B",
        max_iterations: int = 10,
        verbose: bool = True,
    ):
        self.client = OpenAI(base_url=llm_url, api_key="dummy")
        self.model = model
        self.max_iterations = max_iterations
        self.verbose = verbose

    def run(self, user_input: str, system_prompt: str = "") -> str:
        messages: List[Dict] = [
            {
                "role": "system",
                "content": system_prompt or (
                    "你是一个智能助手，可以使用工具完成任务。"
                    "需要外部信息或计算时调用function。"
                    "获得足够信息后直接回复用户。"
                )
            },
            {"role": "user", "content": user_input}
        ]

        for iteration in range(self.max_iterations):
            if self.verbose:
                print(f"\n[Iteration {iteration+1}/{self.max_iterations}]")

            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
                temperature=0.3,
            )
            msg = response.choices[0].message

            if msg.tool_calls:
                # 记录 assistant 消息 (含 tool_calls)
                messages.append({
                    "role": "assistant",
                    "content": msg.content,
                    "tool_calls": [
                        {"id": tc.id, "type": "function",
                         "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                        for tc in msg.tool_calls
                    ]
                })
                # 执行工具
                for tc in msg.tool_calls:
                    func_name = tc.function.name
                    func_args = json.loads(tc.function.arguments)
                    if self.verbose:
                        print(f"  🔧 {func_name}({json.dumps(func_args, ensure_ascii=False)})")
                    result = execute_tool(func_name, func_args)
                    if self.verbose:
                        result_str = json.dumps(result, ensure_ascii=False)
                        print(f"  📋 {result_str[:100]}...")
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": json.dumps(result, ensure_ascii=False)
                    })
            else:
                answer = msg.content
                messages.append({"role": "assistant", "content": answer})
                return answer

        return "达到最大迭代次数，任务未完成。"


if __name__ == "__main__":
    agent = ReActAgent(model="Qwen3.5-122B")
    tasks = ["今天上海天气怎么样？", "计算 (15+23)*2 的结果", "现在几点？今天星期几？"]
    for t in tasks:
        print(f"\n{'='*50}\n用户: {t}")
        print(f"回答: {agent.run(t)}")
