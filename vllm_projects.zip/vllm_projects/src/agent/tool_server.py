"""tool_server.py — Function Calling 工具定义和执行

包含: 工具定义(OpenAI格式) + 工具实现 + 执行注册表
"""

import json, math
from typing import Any, Dict, List
from datetime import datetime


# ============ 工具定义 ============
TOOLS: List[Dict] = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "查询指定城市的当前天气信息",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "城市名称，如'上海'、'北京'"}
                },
                "required": ["city"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "calculate",
            "description": "执行数学计算",
            "parameters": {
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "数学表达式，如'2+3*4'"}
                },
                "required": ["expression"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_current_time",
            "description": "获取当前日期和时间",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
]


# ============ 工具实现 ============
def get_weather(city: str) -> Dict:
    """获取天气 (Demo mock, 生产替换为真实API)"""
    mock_db = {
        "上海": {"weather": "中雨", "temperature": "28°C", "humidity": "85%"},
        "北京": {"weather": "晴", "temperature": "35°C", "humidity": "30%"},
        "深圳": {"weather": "多云", "temperature": "32°C", "humidity": "70%"},
        "杭州": {"weather": "阴", "temperature": "26°C", "humidity": "65%"},
        "成都": {"weather": "小雨", "temperature": "24°C", "humidity": "90%"},
    }
    return mock_db.get(city, {"weather": "未知", "temperature": "N/A"})


def calculate(expression: str) -> Dict:
    """安全计算数学表达式"""
    allowed = {
        "abs": abs, "round": round, "max": max, "min": min,
        "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos,
        "log": math.log, "pow": pow, "pi": math.pi, "e": math.e,
    }
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)
        return {"expression": expression, "result": result}
    except Exception as e:
        return {"expression": expression, "error": str(e)}


def get_current_time() -> Dict:
    now = datetime.now()
    return {
        "datetime": now.strftime("%Y-%m-%d %H:%M:%S"),
        "weekday": ["周一","周二","周三","周四","周五","周六","周日"][now.weekday()],
        "timestamp": int(now.timestamp()),
    }


# ============ 执行注册表 ============
TOOL_EXECUTORS = {
    "get_weather": get_weather,
    "calculate": calculate,
    "get_current_time": get_current_time,
}


def execute_tool(name: str, arguments: Dict[str, Any]) -> Any:
    executor = TOOL_EXECUTORS.get(name)
    if not executor:
        return {"error": f"Unknown tool: {name}"}
    try:
        return executor(**arguments)
    except Exception as e:
        return {"error": f"Tool execution failed: {str(e)}"}
