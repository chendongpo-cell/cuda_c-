# 实验记录

## 实验日志

### 2026-07-17 — Round 1.1 环境准备
- 使用 conda 环境 `cdp310_gpu` (Python 3.10.10)
- PyTorch 2.5.1+cu124 (从 2.12.0+cu130 降级，因为 CUDA 13.0 不兼容 Driver 535)
- CUDA 可用: ✅ | GPU 数: 8 | 每卡: 79GB
- 已安装: transformers, fastapi, openai, flash_attn, modelscope 等

### 2026-07-17 — Round 1.2 模型探索
- 发现本机已有模型：Qwen3-8B(16G), Qwen3-32B(62G), Qwen3.5-35B-GPTQ(23G), Qwen3.5-122B-GPTQ(74G)
- GQA ratio: Qwen3-8B = 32/8=4:1，KV Cache 节省 75%
- 无需额外下载模型，使用已有模型学习

### 2026-07-17 — Round 1.3 单卡推理部署
- 发现已有 vLLM 服务：端口 8001/8002 (Qwen3.5-35B-GPTQ-Int4)
- 绕过公司代理：必须 `unset http_proxy` + `--noproxy '*'`
- Chat API 测试成功：TTFT ~156ms, TPOT ~8ms
- Streaming 正常输出 (SSE 协议)

### 2026-07-17 — Round 1.4 多卡推理
- 本机已有 TP 部署：DeepSeek32B (TP=2, GPU 2-3)
- 端口 8001/8002 使用多 GPU EngineCore
- 张量并行通信量：~1.7GB/iteration，NVLink ~4ms

### 2026-07-17 — Round 1.5 Benchmark
- 30 请求, 并发 4, 0 失败
- Throughput: 419.3 tokens/s
- TTFT P50: 156ms, P95: 212ms
- TPOT P50: 8ms
- 模型: Qwen3.5-122B (实际 35B GPTQ-Int4)

---

## Round 1 总结

### 已掌握 ✅
- [x] CUDA 工具链层次关系（nvidia-smi / nvcc / torch.version.cuda 的区别）
- [x] GPU 显存模型和推理显存计算公式
- [x] GQA 如何节省 KV Cache（Qwen3-8B: 节省 75%）
- [x] 模型文件结构（safetensors / config.json / tokenizer / chat_template）
- [x] vLLM 单卡部署（API 调通 + streaming）
- [x] Prefill vs Decode 计算特性（compute-bound vs memory-bound）
- [x] KV Cache 原理和显存计算公式
- [x] PagedAttention 分页机制
- [x] Continuous Batching
- [x] Tensor Parallelism 多卡部署
- [x] NCCL 通信原语（AllReduce / AllGather / ReduceScatter）
- [x] Benchmark 指标解读（TTFT/TPOT/Throughput）
- [x] OpenAI API 协议和 SSE streaming
- [x] RoPE 位置编码
- [x] 本机代理问题排查（TPEproxyNwing → unset http_proxy）

### 产出文件 (24个)
```
docs/
├── 00-environment/
│   ├── cuda-toolchain.md        ✅ 含下载源 + nvidia-smi解释
│   ├── gpu-memory-model.md      ✅ 含本机GPU分布
│   └── inference-ecosystem.md   ✅ 含本机服务地图
├── 01-model-basics/
│   ├── model-architecture.md    ✅ GQA参数量计算
│   ├── tokenizer-principles.md  ✅ chat_template解读
│   ├── quantization-basics.md   ✅ AWQ/GPTQ/GGUF对比
│   └── position-encoding.md     ✅ RoPE/YaRN外推
├── 02-single-gpu-inference/
│   ├── transformer-inference.md ✅ Prefill/Decode分析
│   ├── kv-cache-deep-dive.md   ✅ 显存计算 + 面试题
│   ├── paged-attention.md      ✅ OS虚拟内存类比
│   └── continuous-batching.md  ✅ 调度策略详解
├── 03-multi-gpu-inference/
│   ├── tensor-parallelism.md   ✅ 列/行并行 + 通信量
│   ├── pipeline-parallelism.md ✅ Bubble分析 + micro-batch
│   └── nccl-communication.md   ✅ Ring topology + NVLink
└── 07-application-layer/
    └── openai-api-protocol.md  ✅ curl绕过代理

scripts/
├── check_env.sh               ✅
├── deploy_vllm.sh             ✅ 完整参数说明
├── deploy_vllm_multigpu.sh    ✅ TP部署 + 等待就绪
└── benchmark.sh               ✅ 异步并发压测

experiments/
└── README.md                  ✅ 实验日志 + 数据
```

### 关键发现
1. **代理拦截**: TPEproxyNwing 拦截 localhost → 必须 `--noproxy '*'`
2. **CUDA 兼容性**: PyTorch CUDA 版本不能大版本跳跃（13.0 > Driver 12.2）
3. **已有丰富基础设施**: Docker vLLM + Dify + DCGM Exporter + Elasticsearch + PostgreSQL
4. **GPU 0 最空闲**: ~58GB 可用，可跑 7B 模型

---

## Round 2 待执行
- [ ] FlashAttention 原理 + 实验
- [ ] Speculative Decoding 原理 + 实验
- [ ] LoRA 微调实操
- [ ] RLHF/DPO 原理
- [ ] Prefix Caching 测试
- [ ] 调度参数调优
- [ ] 量化部署对比
- [ ] 模型评估 (lm-evaluation-harness)

## Round 3 待执行
- [ ] API 网关 (FastAPI 多模型路由 + Token Bucket 限流)
- [ ] Nginx 负载均衡 + 客户端重试
- [ ] Prometheus + Grafana 监控
- [ ] 健康检查 + 自动重启
- [ ] Dockerfile + Docker Compose
- [ ] 故障演练

## Round 4 待执行
- [ ] Embedding 服务 (BGE)
- [ ] RAG 全管线
- [ ] Agent / Function Calling / ReAct
- [ ] 多模态部署 (Qwen2.5-VL)
- [ ] 安全加固
