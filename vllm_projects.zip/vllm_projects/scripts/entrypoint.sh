#!/bin/bash
# entrypoint.sh — Docker 容器启动入口
set -e
MODEL="${MODEL_PATH:-/models/Qwen2.5-7B-Instruct}"
TP="${TENSOR_PARALLEL_SIZE:-1}"
PORT="${PORT:-8000}"
MAX_LEN="${MAX_MODEL_LEN:-8192}"

echo "Starting vLLM: model=$MODEL tp=$TP port=$PORT max_len=$MAX_LEN"

exec python3 -m vllm.entrypoints.openai.api_server \
    --model "$MODEL" \
    --tensor-parallel-size "$TP" \
    --host 0.0.0.0 \
    --port "$PORT" \
    --max-model-len "$MAX_LEN" \
    --gpu-memory-utilization 0.90
