#!/bin/bash
# manage.sh — Docker Compose 一键管理
# 用法: bash manage.sh {up|down|ps|logs|status}
COMPOSE_FILE="/data/chendongpo/agent_projects/vllm_projects/configs/docker-compose.yml"

case "$1" in
    up)
        docker-compose -f "$COMPOSE_FILE" up -d
        sleep 30
        curl -s --noproxy '*' http://localhost:8080/health ;;
    down) docker-compose -f "$COMPOSE_FILE" down ;;
    logs) docker-compose -f "$COMPOSE_FILE" logs -f --tail=100 "${2:-}" ;;
    ps)   docker-compose -f "$COMPOSE_FILE" ps ;;
    status)
        docker-compose -f "$COMPOSE_FILE" ps
        echo ""
        nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu --format=csv,noheader ;;
    *) echo "Usage: $0 {up|down|logs|ps|status}" ;;
esac
