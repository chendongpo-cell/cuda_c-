#!/bin/bash
# deploy_vllm_multigpu.sh — 多卡 TP 部署 vLLM
# 用法: bash deploy_vllm_multigpu.sh [model] [tp_size] [port] [gpu_ids]
set -e

MODEL="${1:-/data/dongshaoqi/hfms/Qwen3-32B}"
TP_SIZE="${2:-2}"
PORT="${3:-8003}"
GPU_IDS="${4:-0,1}"
MODEL_NAME="${5:-my-model-tp}"
MAX_LEN="${6:-32768}"

echo "============================================"
echo "  vLLM Multi-GPU (TP=$TP_SIZE) Deployment"
echo "============================================"
echo "Model:      $MODEL"
echo "TP Size:    $TP_SIZE"
echo "Port:       $PORT"
echo "GPUs:       $GPU_IDS"
echo "Model Name: $MODEL_NAME"
echo "Max Len:    $MAX_LEN"
echo "============================================"

export NO_PROXY=localhost,127.0.0.1
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY
export CUDA_VISIBLE_DEVICES="$GPU_IDS"

python3 -m vllm.entrypoints.openai.api_server \
    --model "$MODEL" \
    --tensor-parallel-size "$TP_SIZE" \
    --served-model-name "$MODEL_NAME" \
    --host 0.0.0.0 \
    --port "$PORT" \
    --max-model-len "$MAX_LEN" \
    --gpu-memory-utilization 0.90 \
    --dtype auto \
    2>&1 | tee /tmp/vllm_tp${TP_SIZE}_${PORT}.log &

PID=$!
echo "vLLM PID: $PID"
echo ""

# 等待服务就绪
echo "Waiting for service to be ready..."
for i in $(seq 1 60); do
    sleep 2
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --noproxy '*' "http://localhost:$PORT/health" 2>/dev/null || echo "000")
    if [ "$HTTP_CODE" = "200" ]; then
        echo "✅ vLLM ready on port $PORT"
        break
    fi
    echo -n "."
done

echo ""
echo "=== GPU Memory Usage ==="
nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv,noheader

echo ""
echo "Verify:"
echo "  curl --noproxy '*' http://localhost:$PORT/v1/models"
