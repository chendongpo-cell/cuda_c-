#!/bin/bash
# health_monitor.sh — vLLM 健康检查 + 自动重启
# 用法: bash health_monitor.sh [port] [model_path] [gpu_id]

PORT="${1:-8000}"
MODEL="${2:-/data/dongshaoqi/hfms/Qwen3-8B}"
GPU="${3:-0}"
MAX_RESTARTS=3
RESTART_WINDOW=300
RESTART_COUNT=0
LAST_RESTART=0

check() {
    curl -s -o /dev/null -w "%{http_code}" --max-time 10 --noproxy '*' \
        "http://localhost:$PORT/health" 2>/dev/null
}

restart_vllm() {
    echo "[$(date '+%H:%M:%S')] Restarting vLLM on port $PORT (GPU $GPU)..."
    kill $(lsof -ti:$PORT) 2>/dev/null
    sleep 5
    CUDA_VISIBLE_DEVICES=$GPU nohup python3 -m vllm.entrypoints.openai.api_server \
        --model "$MODEL" --port "$PORT" --max-model-len 32768 \
        > /tmp/vllm_${PORT}.log 2>&1 &
    PID=$!
    for i in $(seq 1 30); do
        sleep 2
        [ "$(check)" = "200" ] && echo "[$(date '+%H:%M:%S')] Ready (PID=$PID)" && return 0
    done
    echo "[$(date '+%H:%M:%S')] Startup timeout!"
    return 1
}

echo "[$(date)] Health monitor started: port=$PORT"
while true; do
    sleep 10
    CODE=$(check)
    if [ "$CODE" != "200" ]; then
        echo "[$(date '+%H:%M:%S')] FAILED (HTTP $CODE)"
        NOW=$(date +%s)
        if [ $((NOW - LAST_RESTART)) -gt $RESTART_WINDOW ]; then
            RESTART_COUNT=0
        fi
        RESTART_COUNT=$((RESTART_COUNT + 1))
        LAST_RESTART=$NOW
        if [ $RESTART_COUNT -gt $MAX_RESTARTS ]; then
            echo "[$(date)] CRITICAL: Too many restarts!"
            exit 1
        fi
        restart_vllm
    fi
done
