#!/bin/bash
# check_env.sh — 检查 GPU 环境和依赖

echo "============================================"
echo "  LLM Deployment Environment Check"
echo "============================================"

echo ""
echo "=== NVIDIA Driver ==="
nvidia-smi --query-gpu=index,name,memory.total,driver_version --format=csv,noheader 2>/dev/null || echo "nvidia-smi not found!"

echo ""
echo "=== CUDA Toolkit ==="
nvcc --version 2>/dev/null || echo "nvcc not found"

echo ""
echo "=== Python ==="
python3 --version 2>/dev/null || echo "python3 not found"
# Activate venv if it exists
VENV_PYTHON="/data/chendongpo/agent_projects/vllm_projects/.venv/bin/python3"
if [ -f "$VENV_PYTHON" ]; then
    PYTHON="$VENV_PYTHON"
else
    PYTHON="python3"
fi
echo "  Python: $PYTHON"

echo ""
echo "=== PyTorch ==="
$PYTHON -c "
import torch
print(f'  Version: {torch.__version__}')
print(f'  CUDA Available: {torch.cuda.is_available()}')
print(f'  CUDA Version: {torch.version.cuda}')
print(f'  GPU Count: {torch.cuda.device_count()}')
for i in range(torch.cuda.device_count()):
    props = torch.cuda.get_device_properties(i)
    print(f'  GPU {i}: {props.name} ({props.total_mem/1024**3:.0f}GB)')
" 2>&1 || echo "PyTorch not installed"

echo ""
echo "=== vLLM ==="
$PYTHON -c "import vllm; print(f'  vLLM: {vllm.__version__}')" 2>&1 || echo "vLLM not installed"

echo ""
echo "=== Transformers ==="
$PYTHON -c "import transformers; print(f'  Transformers: {transformers.__version__}')" 2>&1 || echo "Transformers not installed"

echo ""
echo "=== Disk Usage ==="
df -h / /data 2>/dev/null

echo ""
echo "=== System Memory ==="
free -h

echo ""
echo "============================================"
echo "  Check Complete"
echo "============================================"
