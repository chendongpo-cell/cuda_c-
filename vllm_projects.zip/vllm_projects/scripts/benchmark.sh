#!/bin/bash
# benchmark.sh — vLLM API 压测
# 用法: bash benchmark.sh [host] [port] [model] [num_prompts] [concurrency]
set -e

HOST="${1:-localhost}"
PORT="${2:-8001}"
MODEL="${3:-Qwen3.5-122B}"
NUM_PROMPTS="${4:-50}"
CONCURRENCY="${5:-4}"

export NO_PROXY=localhost,127.0.0.1
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY

echo "============================================"
echo "  vLLM Benchmark"
echo "============================================"
echo "Host:        $HOST:$PORT"
echo "Model:       $MODEL"
echo "Prompts:     $NUM_PROMPTS"
echo "Concurrency: $CONCURRENCY"
echo "============================================"

python3 -c "
import asyncio
import time, json, statistics
from openai import AsyncOpenAI

async def run():
    client = AsyncOpenAI(
        base_url='http://$HOST:$PORT/v1',
        api_key='dummy',
        timeout=120
    )
    sem = asyncio.Semaphore($CONCURRENCY)

    async def one_request(prompt, idx):
        async with sem:
            t0 = time.monotonic()
            ttft = None
            try:
                stream = await client.chat.completions.create(
                    model='$MODEL',
                    messages=[{'role': 'user', 'content': prompt}],
                    max_tokens=128, stream=True, temperature=0
                )
                out_tokens = 0
                async for chunk in stream:
                    if ttft is None: ttft = time.monotonic() - t0
                    if chunk.choices[0].delta.content: out_tokens += 1
                total = time.monotonic() - t0
                return {'ttft': ttft, 'total': total, 'tokens': out_tokens}
            except Exception as e:
                return {'error': str(e), 'ttft': None, 'total': time.monotonic() - t0, 'tokens': 0}

    prompts = [f'请详细解释第{i}个机器学习概念，包括其定义、应用场景和优缺点。' for i in range($NUM_PROMPTS)]

    print('Starting...')
    t0 = time.monotonic()
    results = await asyncio.gather(*[one_request(p, i) for i, p in enumerate(prompts)])
    wall = time.monotonic() - t0

    ok = [r for r in results if 'error' not in r]
    err = [r for r in results if 'error' in r]

    if not ok:
        print('All requests failed!')
        return

    ttfts = [r['ttft'] for r in ok if r['ttft']]
    tpots = [(r['total']-r['ttft'])/max(r['tokens'],1) for r in ok if r['ttft'] and r['tokens']>0]
    total_tokens = sum(r['tokens'] for r in ok)

    print(f\"\"\"
{'='*60}
Benchmark Results
{'='*60}
Requests:  {len(results)} total, {len(ok)} ok, {len(err)} failed
Wall time: {wall:.1f}s
Throughput:{total_tokens/wall:.1f} tokens/s
QPS:       {len(ok)/wall:.2f} req/s
Concurrency: {$CONCURRENCY}
--- Latency ---
TTFT P50:  {statistics.median(ttfts)*1000:.0f}ms
TTFT P95:  {sorted(ttfts)[int(len(ttfts)*0.95)]*1000:.0f}ms
TTFT P99:  {sorted(ttfts)[int(len(ttfts)*0.99)]*1000:.0f}ms
TPOT P50:  {statistics.median(tpots)*1000:.0f}ms
TPOT P95:  {sorted(tpots)[int(len(tpots)*0.95)]*1000:.0f}ms
{'='*60}
\"\"\")

asyncio.run(run())
" 2>&1
