#!/bin/bash
# deploy_vllm.sh — 单卡部署 vLLM OpenAI 兼容服务
# 用法: bash deploy_vllm.sh [model_path] [port] [gpu_id]
set -e

MODEL_PATH="${1:-/data/dongshaoqi/hfms/Qwen3-8B}"
PORT="${2:-8000}"
GPU_ID="${3:-0}"
MODEL_NAME="${4:-my-model}"
MAX_LEN="${5:-32768}"
GPU_MEM="${6:-0.90}"

echo "============================================"
echo "  vLLM Deployment"
echo "============================================"
echo "Model:      $MODEL_PATH"
echo "Port:       $PORT"
echo "GPU:        $GPU_ID"
echo "Model Name: $MODEL_NAME"
echo "Max Len:    $MAX_LEN"
echo "GPU Mem %:  $GPU_MEM"
echo "============================================"

# 绕过代理
export NO_PROXY=localhost,127.0.0.1
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY

CUDA_VISIBLE_DEVICES=$GPU_ID python3 -m vllm.entrypoints.openai.api_server \
    --model "$MODEL_PATH" \
    --served-model-name "$MODEL_NAME" \
    --host 0.0.0.0 \
    --port "$PORT" \
    --max-model-len "$MAX_LEN" \
    --gpu-memory-utilization "$GPU_MEM" \
    --dtype auto \
    --max-num-seqs 16 \
    2>&1 | tee /tmp/vllm_${PORT}.log

# ================================================
# 参数说明:
# ================================================
# --model                 模型路径或 HuggingFace 模型名
# --served-model-name     API 中展示的模型名（可自定义）
# --host 0.0.0.0          监听所有网络接口
# --port                  服务端口
# --max-model-len         最大上下文长度（超过的不处理）
# --gpu-memory-utilization GPU 显存使用率上限 (0.90 = 90%)
# --dtype auto            自动选择精度 (BF16 > FP16)
# --max-num-seqs          最大并发序列数（= 最大并发请求数）

# ================================================
# 常用扩展参数:
# ================================================
# --tensor-parallel-size N        多卡张量并行
# --enable-prefix-caching         开启前缀缓存
# --enable-chunked-prefill        分块 Prefill（长 prompt 友好）
# --quantization awq              加载量化模型
# --enable-lora                   开启 LoRA 支持
# --lora-modules name=path        加载 LoRA adapter
# --tool-call-parser hermes       开启 Function Calling
# --enable-auto-tool-choice       自动选择工具调用
# --speculative-model path/7B     Speculative Decoding 小模型

# ================================================
# 验证服务:
# ================================================
# curl --noproxy '*' http://localhost:8000/health
# curl --noproxy '*' http://localhost:8000/v1/models
# curl --noproxy '*' http://localhost:8000/v1/chat/completions \
#   -H "Content-Type: application/json" \
#   -d '{"model":"my-model","messages":[{"role":"user","content":"你好"}],"max_tokens":100}'
