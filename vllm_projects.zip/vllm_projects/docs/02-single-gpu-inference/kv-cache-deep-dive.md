# KV Cache 深度解析

## 一句话总结
KV Cache 缓存每层 Transformer 的历史 Key 和 Value，让 Decode 阶段每步只需算新 token 的 QKV 并和缓存 KV 做 Attention，复杂度从 O(n²) 降到 O(n)。但代价是显存使用随 seq_len × batch 线性增长。GQA 通过减少 KV head 数大幅压缩 Cache。

## 没有 KV Cache 的世界

### 第 n 步要算什么

```
Attention(Q_n, [K_1, K_2, K_3, ..., K_n], [V_1, V_2, V_3, ..., V_n])

生成 token_1: attention([Q_1], [K_1], [V_1])                          = 1 次 Q×K
生成 token_2: attention([Q_2], [K_1,K_2], [V_1,V_2])                  = 2 次 Q×K
生成 token_3: attention([Q_3], [K_1,K_2,K_3], [V_1,V_2,V_3])          = 3 次 Q×K
...
生成 token_n: attention([Q_n], [K_1,...,K_n], [V_1,...,V_n])          = n 次 Q×K

总计算量 = 1+2+3+...+n = n(n+1)/2 ≈ n²/2 → O(n²)

而且每个历史 token 的 K 和 V 都被重复计算了:
  K_1 被算了 n 次, K_2 被算了 n-1 次, ...
  → 大量冗余计算
```

### 数值例子

```
生成 1000 个 token:
  无 KV Cache: total FLOPs ≈ 2×params × 1000²/2
              ≈ 2×7B × 500000 ≈ 7 EB FLOPs (天文数字)

生成 4096 个 token:
  无 KV Cache: total FLOPs ≈ 2×7B × 4096²/2 ≈ 117 PB FLOPs
  → 不缓存会慢到没法用
```

## KV Cache 如何工作

### 核心思想

```
Prefill 阶段 (处理 prompt):
  对于每个 token, 计算出该层的 K 和 V
  K_prompt = X_prompt × W_K   → 存入 KV Cache
  V_prompt = X_prompt × W_V   → 存入 KV Cache

Decode 阶段 (逐个生成):
  只计算新 token 的 Q, K, V:
    Q_new = x_new × W_Q    (算新的 Q)
    K_new = x_new × W_K    (算新的 K, 追加到 KV Cache)
    V_new = x_new × W_V    (算新的 V, 追加到 KV Cache)
    
  然后 Q_new 和 KV Cache 中的所有历史 K, V 做 Attention:
    Attention(Q_new, [K_cache | K_new], [V_cache | V_new])
    
  每步只需:
    - 算 1 个新 token 的 QKV
    - 读 KV Cache 中的所有历史 K, V
    - 做 Attention
  → O(n) 而非 O(n²)
```

### 存储结构

```
每层 Transformer 有自己的 KV Cache:

Layer 0:  Key Cache[0..seq_len-1, 0..num_kv_heads-1, 0..head_dim-1]
          Value Cache[0..seq_len-1, 0..num_kv_heads-1, 0..head_dim-1]
Layer 1:  Key Cache[...], Value Cache[...]
...
Layer 31: Key Cache[...], Value Cache[...]

每个元素是 FP16 (2 bytes)

一个 token 在一层的 KV 大小:
= num_kv_heads × head_dim × 2 (K) + num_kv_heads × head_dim × 2 (V)
= 2 × num_kv_heads × head_dim × 2 bytes
= 4 × num_kv_heads × head_dim bytes
```

## KV Cache 显存计算

### 完整公式

```
KV_Cache_Memory =
  2                # K + V
× num_layers       # 每层独立存储
× num_kv_heads     # GQA 的 KV head 数
× head_dim         # 每个 head 的维度
× total_tokens     # 所有请求的总 token 数
× bytes_per_elem   # FP16=2, FP8=1

其中 total_tokens = Σ(prompt_len + generated_len) for each request
```

### 逐步计算（Qwen3-8B 实例）

```
Qwen3-8B 参数:
  num_layers = 36
  num_kv_heads = 8    (GQA, Q heads=32, KV heads=8, ratio=4:1)
  head_dim = 128
  dtype = FP16 (2 bytes)

一个 token 的 KV Cache:
  per_layer = 2 × 8 × 128 × 2 = 4096 bytes = 4 KB
  all_layers = 36 × 4 KB = 144 KB

场景 1: 单请求, seq_len=4096
  KV_Cache = 144 KB × 4096 = 576 MB

场景 2: 单请求, seq_len=40960 (长上下文)
  KV_Cache = 144 KB × 40960 = 5.6 GB
  → 占总显存 5.6/80 = 7%, 还可以

场景 3: 16 个并发请求, 平均 seq_len=8192
  KV_Cache = 144 KB × 8192 × 16 = 18 GB
  → 占 22.5%!

场景 4: 128 个并发, 平均 seq_len=4096
  KV_Cache = 144 KB × 4096 × 128 = 72 GB
  → 占 90%! 加上模型参数 16GB → OOM!

结论: 大并发 + 长上下文 = KV Cache 杀死显存
```

### 如果没有 GQA

```
如果 Qwen3-8B 用标准 MHA (32 heads 而不是 8):
  一个 token 的 KV Cache = 36 × 2 × 32 × 128 × 2 = 576 KB
  (而不是 144 KB)

  场景 3: 16 并发 avg_seq=8192
  KV_Cache = 576 KB × 8192 × 16 = 72 GB ← 比 GQA 多 4 倍！

  场景 4: 128 并发 avg_seq=4096
  KV_Cache = 576 KB × 4096 × 128 = 288 GB ← 早 OOM 了

GQA 让 KV Cache 减少 (Q_heads/KV_heads) = 32/8 = 4 倍
这 4 倍的节省直接转化为 4 倍的并发能力
```

## 各主流模型 KV Cache 对比

| 模型 | num_kv_heads | head_dim | layers | 每 token KV(KB) | GQA Ratio |
|------|-------------|----------|--------|-----------------|-----------|
| Qwen2.5-7B | 4 | 128 | 28 | ~112 | 7:1 |
| Qwen3-8B | 8 | 128 | 36 | ~144 | 4:1 |
| LLaMA3.1-8B | 8 | 128 | 32 | ~128 | 4:1 |
| Qwen2.5-72B | 8 | 128 | 80 | ~320 | 8:1 |
| LLaMA3.1-70B | 8 | 128 | 80 | ~320 | 8:1 |
| DeepSeek-V2 | MLA (576) | — | 60 | ~35 (MLA!) | MLA |

> MLA (Multi-head Latent Attention) 是 DeepSeek 的秘密武器：
> 不直接存 K 和 V，而是存一个压缩后的 latent vector
> 使用时再解压 → KV Cache 减少 90%+
> 这就是为什么 DeepSeek-V2 可以有 128K+ 上下文

## KV Cache 优化技术谱

### 1. GQA / MLA — 减少 KV head 数
```
GQA: 多个 Q head 共享一对 K,V head
MLA: 低秩压缩 K 和 V (更进一步)
→ 减少 KV Cache 的大小
```

### 2. PagedAttention — 分页管理
```
不是预分配连续大块，而是按需分页
→ 消除内存碎片，提高显存利用率
→ 见 paged-attention.md
```

### 3. Prefix Caching — 共享前缀
```
多个请求的公共前缀只存一份 KV Cache
→ 适合长 system prompt / few-shot examples
→ 命中率决定收益
```

### 4. KV Cache 量化 (FP8/INT8)
```
K 和 V 用低精度存储:
  FP8: 每元素 1 byte (vs FP16 2 bytes) → 减半
  精度损失通常 < 0.5%
  vLLM: --kv-cache-dtype fp8
  本机 vLLM-Omni 就在用 : --kv-cache-dtype fp8
```

### 5. Multi-Query Attention (MQA) — 极端 GQA
```
所有 Q head 共享同一个 K,V pair
→ KV head = 1
→ KV Cache 最小, 但模型能力可能受损
→ PaLM 系列用过, 现在主流又回到了 GQA
```

### 6. Sliding Window / Layer-wise 不同长度
```
不同层用不同的 KV Cache 长度
浅层用全长度, 深层用滑动窗口
→ 在质量和显存之间折中
```

## 面试精算

**Q: 部署 Qwen2.5-72B (80层, 8 KV heads, head_dim=128, FP16)，32 并发，平均 seq_len=8192。模型参数和 KV Cache 各占多少？总共需要多少 GPU？**

```
模型参数: 72B × 2 (FP16) = 144 GB

KV Cache:
  per_token_per_layer = 2 × 8 × 128 × 2 = 4096 bytes = 4 KB
  per_token = 80 layers × 4 KB = 320 KB
  total_tokens = 32 requests × 8192 seq = 262144 tokens
  KV_Cache = 320 KB × 262144 ≈ 80 GB

总计: 144 + 80 = 224 GB

A800 一张 80 GB → 需要 224/80 ≈ 3 张但不够
加上 overhead (~4GB/卡) → 至少 4 张 A800 (TP=4)

每卡:
  参数: 144/4 = 36 GB
  KV Cache: 80/4 = 20 GB (因为 TP 切分了每层的矩阵)
  Overhead: ~4 GB
  每卡总计: ~60 GB → 4 张刚好
```

## 查看本机 KV Cache 使用

```bash
unset http_proxy https_proxy
curl -s --noproxy '*' http://localhost:8001/metrics | grep cache
# vllm:gpu_cache_usage_perc     # 当前 KV Cache 使用率
# vllm:cpu_cache_usage_perc     # CPU swap 使用率

# 从启动日志推算:
# "GPU KV cache blocks: N, block_size: 16"
# → 最大 KV Cache = N × 16 × per_token_size
```

---

## 常见问题排查

### 1. vLLM 启动报 "No enough GPU memory for KV cache"

```
原因: 模型参数占用后，剩余显存放不下最小 KV Cache

计算:
  模型参数: 144 GB (72B FP16), TP=4 → 每卡 36 GB
  剩余显存: 80 - 36 - 4(overhead) = 40 GB
  KV Cache block 大小: block_size × per_token_size
  
  如果 max-model-len=65536, gpu-memory-utilization=0.90:
  → KV Cache 预分配空间 = (80×0.9 - 36) × 90% ≈ 32 GB
  → 能存的 token 数 = 32GB / per_token_size

解决:
  1. 减小 max-model-len (如 65536→32768, KV Cache 减半)
  2. 减小 gpu-memory-utilization (留更多给 KV Cache)
  3. 开启 --kv-cache-dtype fp8 (KV Cache 再减半)
  4. 增大 chunked-prefill (减少 Prefill 瞬时显存)
  5. TP 从 4 增到 8 (每卡参数从 36GB→18GB, 但通信增加)
```

### 2. KV Cache 用满导致请求 swap

```
现象:
  vllm:num_requests_swapped > 0
  curl /metrics 看到有请求被换出到 CPU

原因:
  并发太大 / seq_len 太长 → KV Cache block 不够用

排查:
  # 查看 KV Cache 使用率
  curl --noproxy '*' http://localhost:8001/metrics | grep cache
  # vllm:gpu_cache_usage_perc 1.0 = 100% ← 满了

  # 查看有多少请求被 swap
  # vllm:num_requests_swapped > 0

解决:
  1. 增大 gpu-memory-utilization (如 0.9→0.95)
  2. 减小 max-num-seqs (减少并发)
  3. 开启 --enable-prefix-caching (共享前缀, 省 KV Cache)
  4. 增大 CPU swap space: --swap-space 8 (默认 4GB)
```

### 3. 显存泄漏 (memory grows over time)

```
现象:
  运行几小时后, vllm:gpu_cache_usage_perc 持续增长
  最终 OOM

原因:
  KV Cache block 没被正确释放 (bug)
  Prompt 越来越长 (用户行为)

排查:
  watch -n 60 'curl -s --noproxy "*" http://localhost:8001/metrics | grep cache'
  # 观察是否持续增长(不回落)

  # 检查是否有请求卡住
  # vllm:num_requests_running 长时间不变 → 可能有请求 hang 了

临时修复:
  设置 max-model-len 上限, 拒绝超长请求
  设置 max-num-seqs 上限
  定期重启 (cron: 每天凌晨重启)
```

### 4. GQA 对比实验

```python
# 验证 GQA 省了多少 KV Cache
import torch

def calc_kv_cache(num_layers, num_kv_heads, head_dim, seq_len, batch, dtype_bytes=2):
    return 2 * num_layers * num_kv_heads * head_dim * seq_len * batch * dtype_bytes

# Qwen3-8B: 实际 GQA (8 KV heads)
gqa_kv = calc_kv_cache(36, 8, 128, 4096, 16)
# 假如同等配置但没有 GQA (32 KV heads)
no_gqa_kv = calc_kv_cache(36, 32, 128, 4096, 16)

print(f"GQA (8 heads):     {gqa_kv/1024**3:.1f} GB")
print(f"No GQA (32 heads): {no_gqa_kv/1024**3:.1f} GB")
print(f"节省: {(1-gqa_kv/no_gqa_kv)*100:.0f}%")
# 输出: GQA 节省 75%
```

## 面试深度题

**Q: MLA (Multi-head Latent Attention) 比 GQA 更进一步，原理是什么？**

```
GQA: 多个 Q head 共享 K,V pair → 减少了 K,V head 数量
     但每个 K,V 向量还是 head_dim 维 (如 128)

MLA: 不是减少 head 数, 而是压缩 K,V 的维度本身

  原始: K,V ∈ R^{num_heads × head_dim}
  压缩: C ∈ R^{latent_dim}  其中 latent_dim << num_heads × head_dim
  
  存储: latent vector C (小)
  使用时: K = W_DK × C + W_UK × C  (解压)
          V = W_DV × C + W_UV × C
  
  效果: DeepSeek-V2: 每 token KV Cache 从 ~320KB 降到 ~35KB
       → 压缩 9×, 比最好的 GQA 还小 3×
```

**Q: 为什么 kv-cache-dtype fp8 几乎不掉精度？**

```
KV Cache 存的是 Key 和 Value 向量（不是权重）:
  - K,V 是激活值，不是训练好的参数
  - 激活值分布通常很窄 (集中在 -1 到 1)
  - FP8 的 4 位指数够覆盖这个范围
  - 3 位尾数精度损失 < 0.5%
  
  和权重量化不同:
  - 权重可能范围大 (有些 outlier)
  - 权重量化需要更小心
  
  所以 KV Cache FP8 是低垂果实: 简单、有效、几乎无损
```

**Q: 如果用户要求长上下文 (128K), 并发 64, 8×A800 够吗？**

```
假设 72B 模型, TP=8, FP16:
  参数: 144GB / 8 = 18 GB/卡
  剩余: 80 - 18 - 4 = 58 GB/卡给 KV Cache

KV Cache per token (Qwen2.5-72B):
  per_token = 2 × 80 layers × 8 kv_heads × 128 dim × 2 bytes
            = 327,680 bytes ≈ 320 KB

一个请求 128K token: 128K × 320KB = 40 GB
64 并发: 40 × 64 = 2560 GB ← 完全不可能!

用 FP8 KV Cache: 2560 / 2 = 1280 GB ← 还是不够
用 GQA + FP8 + 减少并发:

实际方案:
  max-model-len = 131072 (128K)
  per_token = 320KB / 2 (FP8) = 160KB
  每请求平均 seq_len = 16K (不是所有请求都 128K)
  并发 64:
    KV_Cache = 64 × 16K × 160KB ≈ 160 GB
    8×A800: 160/8 = 20 GB/卡 ← 刚好!

所以关键: 平均 seq_len << max-model-len
  如果平均 seq_len 接近 max → 必须减并发或加 GPU
```
