# PagedAttention 详解

## 一句话总结
PagedAttention 把 KV Cache 切成固定大小的 Block（页），通过 Block Table 映射逻辑位置到物理位置。类比操作系统虚拟内存：物理块可以不连续，按需分配，零内部碎片。显存利用率从 ~40% 提升到 ~96%。

## 传统 KV Cache 管理的灾难

### 预分配问题

```
传统方法: 每个序列启动时预分配最大 seq_len 的连续 KV Cache

序列A: 实际只用 100 token → 预分配了 2048 token 的空间
┌────────────────────┬──────────────────────────────────────┐
│  100 token 已使用   │      1948 token 浪费 (内部碎片)         │
└────────────────────┴──────────────────────────────────────┘
浪费率: 1948/2048 = 95%

序列B: 实际需要 2049 token → 预分配 2048, 差 1 个!
┌─────────────────────────────┬───┐
│    2048 token 已使用         │ X │ ← 第2049个没地方放 → OOM!
└─────────────────────────────┴───┘

序列C: 已完成, 释放了 2048 token 的连续空间
        但序列D只需要 200 token → 用不上这么大的连续块
        这个 2048 的坑位只能给另一个需要 ≥2048 的序列
        → 外部碎片!
```

### 三种浪费

```
1. 内部碎片: 预分配太多, 实际用不了那么多
2. 外部碎片: 释放后产生的连续大块, 小请求用不了, 大请求又不够
3. 预留浪费: 为了"可能"的长序列, 预留了大量空间

总显存利用率: 通常只有 20-40%
→ 一个 80GB 的 GPU 实际只用了 16-32GB 的 KV Cache
→ 明明还有 40+GB 空闲, 但放不下第 17 个请求 (因为碎片)
```

## PagedAttention 的设计

### 核心概念

```
Block (页):
  大小固定, 如 block_size=16 token
  每个 Block 存 16 个 token 在该层的所有 KV head 的完整 K 和 V

Block Table (页表):
  每个序列有一个 Block Table
  Block Table[i] = 物理块 ID
  逻辑块 i → 物理块 BlockTable[i]

物理内存池:
  全部物理 block 统一管理
  分配: pop from free list
  释放: push to free list
```

### 图解

```
物理 GPU 显存 (HBM):
┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
│ #0 │ #1 │ #2 │ #3 │ #4 │ #5 │ #6 │ #7 │ #8 │ #9 │  ← 每个是一块 (16 token)
│空闲│Seq1│Seq2│Seq1│Seq2│Seq1│空闲│空闲│Seq3│Seq3│
└────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
      Block0  Block1  Block0  Block1  Block2  Block0  Block1

序列1 (3个逻辑块 → 3个物理块):
  Block Table: [1, 3, 5]      ← 物理块不连续!
  token_0..15   → 物理块 #1
  token_16..31  → 物理块 #3
  token_32..47  → 物理块 #5

序列2 (2个逻辑块 → 2个物理块):
  Block Table: [2, 4]
  token_0..15   → 物理块 #2
  token_16..31  → 物理块 #4

序列3 (2个逻辑块 → 2个物理块):
  Block Table: [8, 9]
  token_0..15   → 物理块 #8

零内部碎片: 每个序列用多少块就分配多少块, 不用预分配
零外部碎片: 任意空闲块都可以分配给任意序列, 因为不需要连续
```

### Block Table 数据结构

```python
class BlockTable:
    """逻辑块 → 物理块的映射"""
    block_ids: List[int]  # [1, 3, 5] 表示物理块 1,3,5
    
    def __getitem__(self, logical_idx: int) -> int:
        return self.block_ids[logical_idx]
    
    def append_block(self, physical_id: int):
        self.block_ids.append(physical_id)
    
    @property
    def num_blocks(self) -> int:
        return len(self.block_ids)
    
    @property
    def num_tokens(self) -> int:
        return len(self.block_ids) * BLOCK_SIZE


class BlockAllocator:
    """GPU 显存块管理器"""
    free_blocks: Deque[int]              # 空闲块队列
    block_size: int = 16                 # 每块存 16 token
    num_total_blocks: int = 0
    
    def __init__(self, gpu_memory_gb, per_block_bytes):
        available_memory = gpu_memory_gb * 1024**3 * gpu_memory_utilization
        self.num_total_blocks = available_memory // per_block_bytes
        self.free_blocks = deque(range(self.num_total_blocks))
    
    def allocate(self) -> int:
        if not self.free_blocks:
            raise OutOfMemoryError("No free blocks!")
        return self.free_blocks.popleft()
    
    def free(self, block_id: int):
        self.free_blocks.append(block_id)
    
    def get_num_free_blocks(self) -> int:
        return len(self.free_blocks)
```

### 动态增长和释放

```python
# 序列生成过程中动态增长
seq = Sequence(prompt="Hello, how are you?")

# Prefill 阶段: 分配 3 个 block 给 prompt
blocks = [allocator.allocate() for _ in range(3)]
seq.block_table = BlockTable(blocks)

# Decode 阶段: 每 16 个 token 分配一个新 block
for i in range(100):
    token = forward(seq)
    seq.output.append(token)
    if len(seq.output) % BLOCK_SIZE == 0:
        # 当前 block 满了, 分配新 block
        new_block = allocator.allocate()
        seq.block_table.append_block(new_block)

# 完成: 释放所有 block
for block_id in seq.block_table.block_ids:
    allocator.free(block_id)
```

## Copy-on-Write (CoW) 共享

### 并行采样场景

```
同一 prompt 生成 3 个不同的 completion (n=3):

3 个序列共享同一个 prompt 的 KV Cache:
  ┌──────────────────┐
  │ Prompt KV Cache   │  ← 3个序列指向同一批物理块
  │ (物理块 #1, #3, #5)│
  └──────┬───────────┘
         ├── Seq_A (block_table: [1,3,5, 7, 10, ...])
         ├── Seq_B (block_table: [1,3,5, 8, 12, ...])
         └── Seq_C (block_table: [1,3,5, 9, 14, ...])
                ↑ 共享的 prompt 块
                       ↑ 分叉后各自的新块

一个 2000 token 的 prompt:
  无 CoW: 3 × 2000 = 6000 token 的 KV Cache
  有 CoW: 2000 shared + 3 × 各自新 token
  → 节省 ~60%
```

### 实现

```python
# Block 的引用计数
class PhysicalBlock:
    block_id: int
    ref_count: int = 0    # 有多少序列在用这个 block
    data: Tensor           # 实际的 KV Cache 数据

def fork_sequence(parent: Sequence) -> Sequence:
    """并行采样: 从父序列分叉出一个子序列"""
    child = Sequence()
    child.block_table = BlockTable([])
    
    # 共享所有 prompt 块
    for block_id in parent.block_table.block_ids:
        physical_block = get_physical_block(block_id)
        physical_block.ref_count += 1
        child.block_table.append_block(block_id)
    
    return child

# 只有分叉后新生成的 token 才分配新 block (不共享)
```

## 与操作系统的精确类比

```
PagedAttention          ←→  操作系统虚拟内存
────────────────────         ───────────────────
Block (16 token)       ←→   Page (4KB)
Block Table            ←→   Page Table
Block Table Entry      ←→   PTE (Page Table Entry)
逻辑 token 位置         ←→   Virtual Address
物理 Block ID          ←→   Physical Frame Number
BlockAllocator         ←→   Physical Memory Manager
free_blocks queue      ←→   Free Frame List
CoW 共享               ←→   fork() 的 CoW 页面
Swap out               ←→   Page out to swap file
Recompute              ←→   Page fault + re-compute (而不是从磁盘读)
```

## 性能数据

### vLLM 论文实测

```
测试条件: LLaMA-13B, A100-40GB, ShareGPT dataset

                    传统方式      PagedAttention
显存利用率           ~40%          ~96%
最大 batch size      ~50           ~200+
最大吞吐 (tok/s)    ~1000          ~24000 (24×)
平均 TTFT (ms)      1800           200 (9×)
```

### 为什么提升这么显著

```
batch size 从 50 → 200:
  → 4× 更多的请求同时处理
  → GPU 利用率从 30% → 80%+
  → 吞吐 4× 提升

KV Cache 零碎片:
  → 不再浪费 60% 的显存
  → 浪费的显存变成可用的 KV Cache
  → 可以容纳更多请求

两者叠加 → 24× 总提升
```

## 本机验证

```bash
# 从 vLLM 启动日志推断 PagedAttention 配置
# "GPU KV cache blocks: N"
# "block_size: 16"

# 本机端口 8001:
# 35B GPTQ-Int4 模型 ~23GB
# 剩余 ~57GB 给 KV Cache
# 每块 ≈ 16 token × per_token_size
# 可用 block 数 = 57GB / per_block_size
```

## PagedAttention 的局限

```
1. Block Size 固定:
   block_size=16 → 最多 15 token 的内部碎片
   但 block_size 太大 → 小请求浪费多
   block_size 太小 → Block Table 开销大 + kernel 效率低

2. CoW 复制时机:
   分叉后第一个不同的 token 就要分配新 block
   但其实大部分 block 内容不变 → 有优化空间

3. 大 batch 下的 Block Table 开销:
   每个序列都要维护 Block Table
   超多序列 (1000+) → Block Table 内存开销不可忽略

---

## 常见问题排查

### 1. "block_size 怎么选？16 还是 32？"

```
block_size 越大:
  + GPU kernel 效率越高 (一次处理更多 token)
  + Block Table 更小 (同样 seq 需要更少 block)
  - 内部碎片更多 (最后一个 block 平均浪费 block_size/2 token)
  - CoW 粒度更粗 (fork 后浪费更多)

block_size 越小:
  + 碎片更少, 内存利用率更高
  - Block Table 更大, kernel launch 更多

经验:
  - 短 prompt 为主 (<1024): block_size=16
  - 长 prompt 为主 (>4096): block_size=32
  - 混合: block_size=16 (默认, 最通用)
  
  vLLM 默认 16 是基于大量实验的最优值
  除非有特殊需求, 不要改
```

### 2. "为什么 nvidia-smi 显示显存还有空余，但 vLLM 说 No free blocks？"

```
GPU 显存的分配:
  模型参数: 14 GB
  KV Cache blocks: 预分配一定数量
  
  nvidia-smi 显示的 "free" = 总显存 - 已分配
  但 KV Cache blocks 虽然已分配, 不是全部在用
  
  vLLM 启动时根据 gpu-memory-utilization 预分配 KV Cache 池:
  KV_Cache_pool = (80GB × 0.9 - 14GB) × 90% ≈ 52 GB
  → 预分配 52 GB 的 block 池
  
  nvidia-smi 看到 "57 GB used" = 14(模型) + 43(KV Cache pool 预留但未使用)
  → "23 GB free" 是预留的缓冲 (防止 OOM)
  
  真正限制不是 nvidia-smi 的 free, 而是 gpu-memory-utilization!
  
  如果 block 池用完了 → No free blocks
  解决: 增大 gpu-memory-utilization 或减小 max-num-seqs
```

### 3. "显存明明还有很多 free, 为什么新请求被 swap 了？"

```
可能原因:
  1. gpu-memory-utilization 设得太低 (如 0.70)
     → 明明有 30% 剩余但 vLLM 不用
     → 设为 0.90

  2. Block Table 满了 (不是显存, 是 block 数量上限)
     → 增大 max-num-seqs

  3. CPU swap space 满了
     → --swap-space 8 (默认 4GB)
```

### 4. "CoW 共享不生效"

```
检查:
  1. 请求是否真的共享 prompt？
     - 只有完全相同的 token ID 序列才能共享
     - "你好" 和 "你好！" → 不共享（不同 system prompt）

  2. 是否开了 prefix caching？
     - vLLM 需要 --enable-prefix-caching

  3. n>1 的并行采样？
     - 同一请求的 n=3 才会触发 CoW
     - 不同请求之间的共享 → prefix caching
```

## 源码关键路径

```python
# vllm/core/block_manager.py — BlockAllocator 实现 (简化)

class BlockSpaceManager:
    """管理所有序列的 block 分配"""
    
    def __init__(self, block_size, num_gpu_blocks, num_cpu_blocks):
        self.gpu_allocator = BlockAllocator(num_gpu_blocks, block_size)
        self.cpu_allocator = BlockAllocator(num_cpu_blocks, block_size)
        self.block_tables: Dict[int, BlockTable] = {}  # seq_id → BlockTable
    
    def allocate(self, seq: Sequence) -> None:
        """为一个序列分配 block"""
        num_blocks = ceil(seq.num_tokens / block_size)
        
        # 尝试从 GPU 分配
        try:
            blocks = [self.gpu_allocator.allocate() for _ in range(num_blocks)]
        except OutOfMemoryError:
            # GPU 不够 → Preemption
            self._preempt()
            blocks = [self.gpu_allocator.allocate() for _ in range(num_blocks)]
        
        seq.block_table = BlockTable(blocks)
    
    def append_slot(self, seq: Sequence) -> None:
        """Decode 时追加一个 block (如果当前 block 满了)"""
        if len(seq.output_tokens) % block_size == 0:
            new_block = self.gpu_allocator.allocate()
            seq.block_table.append_block(new_block)
    
    def free(self, seq: Sequence) -> None:
        """释放一个序列的所有 block"""
        for block_id in seq.block_table.block_ids:
            # 检查引用计数 (CoW)
            physical_block = self.get_physical_block(block_id)
            physical_block.ref_count -= 1
            if physical_block.ref_count == 0:
                self.gpu_allocator.free(block_id)
    
    def fork(self, parent_seq: Sequence) -> Sequence:
        """CoW: 从父序列分叉"""
        child_seq = Sequence()
        for block_id in parent_seq.block_table.block_ids:
            physical_block = self.get_physical_block(block_id)
            physical_block.ref_count += 1    # ref count +1
            child_seq.block_table.append_block(block_id)
        return child_seq
    
    def _preempt(self) -> None:
        """抢占一个低优先级序列"""
        victim = self._pick_victim()
        for block_id in victim.block_table.block_ids:
            # Swap to CPU
            copy_gpu_to_cpu(block_id)
            self.gpu_allocator.free(block_id)
            victim.status = SequenceStatus.SWAPPED
```

## 面试追问

**Q: PagedAttention 的 block 大小为什么是 16/32 token 而不是像 OS 的 4KB 页？**

A: OS 页大小是硬件决定的（MMU 固定 4KB）。PagedAttention 的 block_size 是软件可调的。16 token 的 block 约 = 16×4KB = 64KB（7B模型），比 OS 页大，因为 GPU kernel 一次处理 16 token 更高效。太小 → kernel launch 太多。太大 → 碎片多。

**Q: 为什么 vLLM 不是纯 Python 实现的 PagedAttention？**

A: PagedAttention 核心是 CUDA kernel。Python 层只是管理 BlockTable 和调度。真正的 KV Cache 加载和 Attention 计算是 C++/CUDA 写的（vllm/csrc/attention/）。因为需要精细控制 HBM→SMEM 的数据搬运和 Tensor Core 调用，Python 做不了。

**Q: 多卡 TP 时 KV Cache 怎么分布？**

A: 每张卡有自己独立的 KV Cache block 池。TP 切分的是 Attention 矩阵的列维度（head_dim 切分），所以每张卡只存 KV head 对应的一部分。block 分配逻辑和单卡一样，但释放和 CoW 也是各管各。
```
