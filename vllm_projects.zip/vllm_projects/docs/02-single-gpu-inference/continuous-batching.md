# Continuous Batching 深度解析

## 一句话总结
Continuous Batching 让请求随时加入和退出 GPU 计算批次，不等整批完成。相比静态 batching（等最慢的请求），GPU 空闲时间降到最低，吞吐提升 5-10 倍。

## 先理解：为什么需要 Batching

### 没有 Batching 的世界

```
GPU 一次只能处理一个请求:

请求A (100 token): ████████████████████████  (20ms)
        等A做完→
请求B (20 token):  ████                       (4ms)
                 等B做完→
请求C (50 token):  ██████████                 (10ms)

总时间: 20+4+10 = 34ms
GPU 算力利用率: ≈ 20% (大部分时间在处理单个请求的小矩阵)
```

### 静态 Batching

```
把 3 个请求打包一起送去 GPU:

请求A (100 token)+请求B (20 token)+请求C (50 token):
  batch = [A,B,C]
  GPU 一次 forward 处理这 3 个请求

但是! 请求的长度不一样:
  A 需要 20 步 Decode, B 只需要 4 步, C 需要 10 步

  时间线:
  Step 1-4:   batch=[A,B,C]  3 个都在算 ✓
  Step 5-10:  batch=[A,C]    B 做完了, 但位置空着 ✗
  Step 11-20: batch=[A]      C 也做完了, GPU 只处理 1 个请求 ✗

问题: B 和 C 的 batch 位置被浪费了
  GPU 明明可以同时处理 3 个请求
  但为了等 A 做完, 浪费了 (10-4)+(20-10) = 16 个 step 的 batch 容量

浪费率 = 16/(20×3) = 27% 的 GPU 时间
```

## Continuous Batching 怎么做的

```
同样 3 个请求, Continuous Batching:

Step 1-4:   batch=[A,B,C]      ← B 在第4步完成
Step 5:     batch=[A,C, D]     ← B 退出, D 立即接上! 
Step 6-10:  batch=[A,C,D]
Step 10:    C 完成
Step 11:    batch=[A,D,E]      ← C 退出, E 接上
Step 12-19: batch=[A,D,E]
Step 20:    A 完成
Step 21:    batch=[D,E,F]      ← 无缝衔接

关键变化:
  - 不再等"整批完成"
  - 每个 iteration 重新组 batch
  - 完成的请求立刻退出, 新请求立刻加入
  - batch 位置始终饱满
  
浪费率: ≈ 0%
```

### 用流水线类比

```
静态 Batching = 固定班车:
  8 点发车, 不管人到没到齐
  早到的人等, 迟到的人等下一班

Continuous Batching = 流水线:
  来一个处理一个, 做完立刻下线
  新来的立刻插到流水线空位
  永远在跑
```

## 实现细节

### 每次 Iteration 的调度

```
调度器在每次 iteration 开始时的决策:

while True:
    # 1. 检查 waiting 队列 (有没有新请求?)
    for new_request in waiting_queue:
        if 显存够分 KV Cache block:
            分配 block, request 进入 scheduled 列表
    
    # 2. 加入 running 中的请求
    for running_request in running_list:
        if not running_request.finished:
            scheduled.append(running_request)
    
    # 3. Token budget 检查
    # 不能一次处理太多 token (受 max-num-batched-tokens 限制)
    total_tokens = sum(len(req) for req in scheduled)
    if total_tokens > max_num_batched_tokens:
        scheduled = scheduled[:max_num_seqs]  # 裁掉一些
    
    # 4. GPU forward: 一次处理 scheduled 中的所有请求
    results = model.forward(scheduled)
    
    # 5. 处理结果
    for req, next_token in zip(scheduled, results):
        req.output.append(next_token)
        if next_token == EOS or len(req.output) >= max_tokens:
            req.finished = True
            release_blocks(req.block_table)  # 释放 KV Cache
    
    # 6. 回到 1 (不等待, 立即开始下一次 iteration)
```

### 组 batch 的关键操作

```
把多个请求拼成一次 forward:

请求A: prompt="你好" → tokens=[123, 456], positions=[0,1], block_table=[7,3]
请求B: decode  → tokens=[789], positions=[15], block_table=[2,4,12,11,8]
请求C: decode  → tokens=[321], positions=[8],  block_table=[1,5,9]

拼接:
  input_ids = [123, 456, 789, 321]         # 4 个 token
  positions = [0, 1, 15, 8]                 # 各自的位置
  block_tables = [[7,3], [2,4,12,11,8], [1,5,9]]

一次 GPU forward:
  model(input_ids, positions, block_tables)
  → 4 个 token 的计算并行执行
  → 从 block_tables 加载各自的 KV Cache
```

## 三个关键参数

```
max-num-seqs (最大并发序列数):
  决定了最多同时处理多少请求
  太小 → batch 不够, GPU 空转
  太大 → KV Cache 不够, 触发 swap
  
  经验值: 64-128 (7B 模型)
          32-64  (72B 模型)

max-num-batched-tokens (每次 iteration 最多处理多少 token):
  同时处理的所有请求的总 token 数上限
  包含 Prefill 的 prompt token + Decode 的新 token
  
  经验值: 2048-16384
  
  设置原则:
    max-num-batched-tokens ≥ max-num-seqs (保证每个 decode 至少有 1 个 token)
    如果经常有长 prompt, 设大一点

gpu-memory-utilization (显存使用率):
  决定了可以分配多少 KV Cache block
  越大 → KV Cache 越多 → 能支持的并发越大
  但留太少缓冲 → OOM 风险
  
  经验值: 0.90-0.95
```

## Chunked Prefill

### 问题: 一个超大 prompt 阻塞所有人

```
一个用户发了 100,000 token 的 prompt:

无 Chunked Prefill:
  Prefill 需要 100K tokens 一次算完
  → 这次 Prefill 占满 max-num-batched-tokens
  → 其他 63 个 decode 请求被挤出去
  → 这次 iteration 只处理了 1 个请求!
  → 下次 iteration 才能继续 decode

有 Chunked Prefill:
  Prefill 分成多块:
    Iter 1: Prefill chunk 0 (tokens 0-4095)  +  decode 请求们
    Iter 2: Prefill chunk 1 (tokens 4096-8191) + decode 请求们
    Iter 3: Prefill chunk 2 (tokens 8192-12287) + decode 请求们
    ...
  
  每次 iteration 只处理一个 chunk
  → decode 请求不受影响
  → 虽然这个大 prompt 的 TTFT 变长了
  → 但其他所有用户的延迟不受影响
```

## 调度优先级

```
优先级从高到低:

1. Swap-in 请求:
   之前因为显存不够被换出到 CPU 的请求
   优先恢复 (用户等了很久了)

2. Prefill 请求:
   新来的, 需要先做 Prefill
   Prefill 是 compute-bound → GPU 利用率高 → 优先做

3. Decode 请求:
   正在生成的请求
   Decode 是 memory-bound → GPU 利用率低 → 不着急

为什么 Prefill 优先?
  让 GPU 趁 batch 大时把 compute-heavy 的活干完
  Decode 的活反正 GPU 利用率低, 随时能做
```

## Preemption (抢占)

```
显存不够时, 挑一个低优先级的请求 "赶出去":

Swap out (换出):
  把该请求的 KV Cache block 从 GPU 显存搬到 CPU 内存
  block 还是分配状态, 只是数据搬到 CPU 了
  恢复时: 从 CPU 搬回 GPU (快)
  代价: 占 CPU 内存

Recompute (重算):
  直接释放 KV Cache block
  恢复时: 重新做一遍 Prefill (慢)
  代价: 延迟增加
  好处: 不占 CPU 内存

vLLM 默认策略:
  先尝试 swap (CPU 内存还够)
  swap 满了 → recompute
```

## 常见问题

### 1. "为什么 GPU 利用率一直在 30-40%, 而不是 100%?"

```
Decode 阶段是 memory-bound → 这很正常

一个办法区分:
  nvidia-smi dmon -s pucv -d 1
  # 观察:
  #  如果 GPU-Util 低但 SM-Active 也低 → batch 太小
  #  如果 GPU-Util 低但 SM-Active 高 → memory-bound (正常)

增大 batch:
  增加 max-num-seqs → 更多 decode 请求同时跑
  → 更多 token 一起算 → GPU 利用率提升
  → 代价: 单请求延迟可能略增 (竞争 HBM 带宽)
```

### 2. "batch 设很大, 吞吐提高了, 但 P99 延迟变差了?"

```
原因: 大 batch → 每个 decode step 要读更多 KV Cache → 竞争 HBM 带宽

权衡:
  max-num-seqs=32:  吞吐 800 tok/s, P95 TTFT=200ms
  max-num-seqs=128: 吞吐 2000 tok/s, P95 TTFT=500ms
  max-num-seqs=256: 吞吐 2800 tok/s, P95 TTFT=1200ms

根据业务需求选:
  离线批量处理 → 大 batch, 高吞吐
  在线实时 API → 中等 batch, 保证 P95 延迟
```

### 3. "为什么 waiting 队列一直有请求在排队?"

```
有 waiting 说明系统在满负荷运行:
  显存的 KV Cache block 全满了
  → 新请求无法分配 block → 在 waiting 队列等

这其实说明系统效率不错 (block 物尽其用)

但如果 waiting 持续增长, 说明吞吐不够:
  解决: 加 GPU 或起第二个实例
```

### 4. "为什么有请求被 swap, 但 CPU 内存还有很多?"

```
可能原因: CPU swap space 设得太小

vLLM 默认 --swap-space 4 (4GB)
增大: --swap-space 16 (16GB)

检查:
  free -h  # 看 CPU 内存
  curl --noproxy '*' http://localhost:8001/metrics | grep swap
```