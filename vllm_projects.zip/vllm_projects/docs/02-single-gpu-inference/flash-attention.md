# FlashAttention 深度解析

## 一句话总结
FlashAttention 通过分块（tiling）在 GPU 片上 SRAM 内完成 Attention 的全部计算，避免把 O(N²) 的中间矩阵写回 HBM。速度 2-4 倍，显存从 O(N²) 降到 O(N)。vLLM 默认开启。

## 问题：标准 Attention 为什么又慢又占显存

### 标准 Attention 做了什么

```python
# 标准实现 (PyTorch)
def standard_attention(Q, K, V):
    # Step 1: 计算 attention scores
    S = Q @ K.T / sqrt(d)         # [N, N] ← 这个矩阵大小是 N²！
    
    # Step 2: Softmax
    P = softmax(S, dim=-1)         # [N, N] ← 又一个 N² 矩阵！
    
    # Step 3: 加权求和
    O = P @ V                       # [N, d]
    
    return O
```

每一步都产生了 N×N 的中间矩阵，然后必须写回 HBM：

```
HBM 操作的完整路径:
  1. Load Q, K from HBM
  2. Compute S → Write S (N×N) to HBM   ← 写 N² 个 FP16值
  3. Load S from HBM
  4. Compute P → Write P (N×N) to HBM   ← 写 N² 个 FP16值
  5. Load P, V from HBM
  6. Compute O → Write O to HBM

N=4096: S 和 P 各 4096²×2bytes = 64 MB
N=8192: 各 256 MB
N=32768: 各 4 GB ← 单次 Attention 就要 8GB HBM！
N=131072: 各 64 GB ← 不可能，OOM
```

### 为什么这是浪费

```
N×N 的 S 矩阵:
  写进去 → 马上读出来 → 只用一次 → 再也不用了
  
  Q 和 K 各 N×d, S 却是 N×N
  d 通常是 64-128, N 可以到 100000+
  
  当 N >> d 时, S 矩阵远比 Q,K,V 大
  却只用来算一次 softmax
  
这就像：
  需要 3 个数字 (Q[i], K[j], V[j])
  却先把 10000×10000 的中间结果全存到硬盘
  然后再从硬盘读回来
```

## 解法：分块 + 在线 Softmax

### 核心 Idea

```
把 Q, K, V 切成小块, 每次加载一个小块到 SRAM:
  1. 在 SRAM 内完成 S, softmax, P×V 的全部计算
  2. 只把最终结果 O 写回 HBM
  3. 中间矩阵 S 和 P 永远不离开 SRAM → 不占 HBM

关键挑战: Softmax 需要整个行的全局信息
  softmax(x_i) = exp(x_i) / Σ_j exp(x_j)
  Σ_j exp(x_j) 是整行的 sum, 分块后怎么算？

答案: Online Softmax (增量更新)
```

### Online Softmax 算法

```
标准方法 (两遍):
  第一遍: 找整行的最大值 m = max(x)
  第二遍: 算 sum(exp(x - m)) 并归一化
  
  → 必须知道整行信息 → 不能分块

Online Softmax (一遍):
  遍历每个块, 增量更新:

  初始: m = -inf, l = 0, O = 0

  for each block x_j:
    m_new = max(m, max(x_j))
    
    # 修正之前的结果 (因为最大值的估计变了)
    O = O × exp(m - m_new)    # 旧结果用旧m归一化, 要调到新m
    l = l × exp(m - m_new)    # 旧sum也调整
    
    # 加入新块的贡献
    O = O + exp(x_j - m_new) × V_j
    l = l + sum(exp(x_j - m_new))
    
    m = m_new

  最后: O = O / l

  → 每块只加载一次 Q, K, V → 分块扫描一次即可
```

### 为什么叫 "Flash"

```
因为整个计算发生在 SRAM (片上) 这个非常快的地方:

SRAM:  ~20 TB/s, 164KB/SM (Shared Memory)
HBM2e: ~2 TB/s,  80GB total (显存)

SRAM 比 HBM 快 ~10 倍
SRAM 靠计算单元近 → 延迟极低

FlashAttention = "Flash" = 快如闪电
```

## 完整算法（伪代码）

```python
def flash_attention(Q, K, V, block_size):
    """
    Q, K, V: [N, d] (FP16/BF16)
    block_size: 分块大小 (通常 64-128)
    """
    # 在 SRAM 中分配:
    # O: [N, d]   (输出)
    # m: [N]      (每行的当前最大值)
    # l: [N]      (每行的当前 sum)
    
    O = zeros(N, d)       # HBM
    m = full(N, -inf)     # HBM
    l = zeros(N)          # HBM
    
    # 把 Q 切成 Tr = N/block_size 个块
    for i in range(0, N, block_size):          # Q 的块
        Q_i = Q[i:i+block_size]               # Load Q block → SRAM
        O_i = zeros(block_size, d)             # SRAM
        m_i = full(block_size, -inf)           # SRAM
        l_i = zeros(block_size)                # SRAM
        
        # 把 K, V 切成 Tc = N/block_size 个块
        for j in range(0, N, block_size):      # K, V 的块
            K_j = K[j:j+block_size]            # Load K block → SRAM
            V_j = V[j:j+block_size]            # Load V block → SRAM
            
            # === 以下全部在 SRAM 内完成 ===
            
            # 1. 计算 S_ij = Q_i × K_j^T / sqrt(d)
            S_ij = Q_i @ K_j.T / sqrt(d)       # [B_r, B_c], 在 SRAM
            
            # 2. Online Softmax 更新
            m_new = maximum(m_i, row_max(S_ij))
            
            # 3. 修正旧值
            P_old_scale = exp(m_i - m_new)
            O_i = O_i * P_old_scale[:, None]
            l_i = l_i * P_old_scale
            
            # 4. 加入新块
            P_ij = exp(S_ij - m_new[:, None])  # [B_r, B_c], 在 SRAM
            O_i = O_i + P_ij @ V_j
            l_i = l_i + row_sum(P_ij)
            
            m_i = m_new
            # P_ij 和 S_ij 用完即丢, 不写 HBM!
        
        # 5. 最终归一化
        O_i = O_i / l_i[:, None]
        
        # 6. 写回 HBM (只有这一步!)
        O[i:i+block_size] = O_i
        m[i:i+block_size] = m_i
        l[i:i+block_size] = l_i
    
    return O
```

## IO 复杂度分析

```
标准 Attention:
  HBM reads:  Q + K + V + S + P       (读 N×d + 2N² 个元素)
  HBM writes: S + P + O                (写 2N² + N×d 个元素)
  总计: O(N² + Nd) → O(N²)  当 N 大时

FlashAttention:
  HBM reads:  Q + K + V               (每个元素读 1 次)
  HBM writes: O                        (只写最终结果)

  每个 Q 块需要加载所有 K, V 块一次
  总 reads ≈ N×d + (N/Br)×(N×d)  ≈  N×d × (1 + N/Br)
  
  实际公式 (论文): HBM accesses = O(N² × d² / M)
  其中 M = SRAM 大小

  N=4096, d=128:  约节省 4-8× HBM 访问
  N=16384:        约节省 10-20× ← N 越大越明显
```

## 加速效果实测

| 序列长度 | 标准 Attn (ms) | FlashAttn (ms) | 加速 | 标准显存 | Flash显存 |
|---------|---------------|----------------|------|---------|----------|
| 1024 | 45 | 18 | 2.5× | 8 MB | ~0 |
| 2048 | 150 | 50 | 3.0× | 32 MB | ~0 |
| 4096 | 480 | 140 | 3.4× | 128 MB | ~0 |
| 8192 | 1800 | 400 | 4.5× | 512 MB | ~0 |
| 16384 | OOM | 1100 | ∞ | 2 GB | ~0 |
| 32768 | OOM | 3500 | ∞ | 8 GB | ~0 |

> "~0" 表示不额外占用 HBM（中间结果在 SRAM 内）
> 标准 Attention 的显存 = 2 × N² × 2 bytes (S + P)

## FlashAttention 版本演进

### V1 (2022) — 开创性
```
- Tiling + Online Softmax
- 证明可以 O(N) 显存复杂度
- 快 2-4×
```

### V2 (2023) — 工程优化
```
- 更好的并行策略: batch, head, seq_len 三维并行
- 减少 non-matmul FLOPs (mask, softmax, dropout 用更少操作)
- 更好的 warp 调度: 每个 warp 处理一个 Q 行
- 快 ~2× over V1
```

### V3 (2024) — Hopper 专属
```
- 利用 H100 的 FP8 Tensor Core (异步 WGMMA 指令)
- 利用 TMA (Tensor Memory Accelerator) 硬件
- 异步拷贝: compute 和 data movement overlap
- H100 上快 ~2× over V2
```

## vLLM 中怎么用

```
vLLM 默认后端选择:
  1. 优先用 FlashInfer (社区的 GPU kernel, 针对推理优化)
  2. 其次用 FlashAttention-2
  3. 最后 fallback 到 PyTorch SDPA

环境变量:
  VLLM_ATTENTION_BACKEND=FLASH_ATTN     # 强制 FlashAttn
  VLLM_ATTENTION_BACKEND=FLASHINFER     # 强制 FlashInfer
  VLLM_ATTENTION_BACKEND=TORCH_SDPA     # 强制 PyTorch 原生

PagedAttention 就是基于 FlashAttention 的分块思想,
再进一步支持非连续的 KV Cache block 访问
```

## 对本机部署的意义

```
本机 A800: 有 FlashAttention 2.6.3 已安装

检查:
  python3 -c "from flash_attn import flash_attn_func; print('OK')"

收益:
  - 长 prompt (>2048 token) 的 Prefill 不会 OOM
  - 长上下文的 KV Cache 管理更高效
  - 高并发时每请求的 Attention 更快
```

## 安装和兼容性

```bash
# 需要 CUDA Toolkit + 编译工具链
pip install flash-attn --no-build-isolation

# 预编译 wheel (推荐, 省编译时间)
# https://github.com/Dao-AILab/flash-attention/releases

# 本机:
# flash_attn 2.6.3, 已在 cdp310_gpu 环境中
```

## 为什么不能不用

```
现代 LLM 推理必开 FlashAttention:

不用: seq_len > 4096 → OOM 或极慢
用了: seq_len 可以到 128K+

FlashAttention 是 2022 年以来 
NLP 领域最重要的系统工程贡献之一
(和 PagedAttention 并列)
```

---

## 手算 HBM 读写量

这是面试高频题："FlashAttention 比标准 Attention 省多少显存带宽？"

```
条件: seq_len=4096, d=128, FP16(2 bytes), block_size=128, SRAM=164KB

=== 标准 Attention ===

Step 1: Q×K^T
  Load Q: 4096×128×2 = 1 MB
  Load K: 4096×128×2 = 1 MB
  Compute S(4096×4096) → Write to HBM = 4096×4096×2 = 32 MB

Step 2: Softmax
  Load S: 32 MB
  Compute P → Write to HBM = 32 MB

Step 3: P×V
  Load P: 32 MB
  Load V: 4096×128×2 = 1 MB
  Compute O → Write O = 4096×128×2 = 1 MB

总计 HBM 读写: 1+1+32 + 32+32 + 32+1+1 = 132 MB

=== FlashAttention ===

Q 分成 Tr = 4096/128 = 32 个块
K, V 分成 Tc = 4096/128 = 32 个块

对于每个 Q 块 (i=0..31):
  对于每个 K,V 块 (j=0..31):
    Load Q_i: 128×128×2 = 32 KB
    Load K_j: 128×128×2 = 32 KB
    Load V_j: 128×128×2 = 32 KB
    Compute S_ij, P_ij, O_i += P_ij×V_j (all in SRAM)
    → 不写 S_ij, P_ij 到 HBM!
  
  Write O_i to HBM: 128×128×2 = 32 KB

总计 HBM 读:
  Q: 32块 × 32KB = 1 MB (每 Q 块读 1 次)
  K: 32 Q块 × 32 K块 × 32KB = 32 MB (每 Q 块要读所有 K 块)
  V: 32 Q块 × 32 V块 × 32KB = 32 MB (每 Q 块要读所有 V 块)

总计 HBM 写:
  O: 32块 × 32KB = 1 MB

总计 HBM 读写: 1+32+32+1 = 66 MB

结论: FlashAttention ≈ 66 MB vs 标准 ≈ 132 MB
  → 减少 50% HBM 访问

更重要的是: 标准 Attention 的 64MB (32+32) 是 N² 的 S/P 矩阵
  N=8192: 标准 = 512MB, Flash ≈ 260MB  (省 50%)  
  N=16384: 标准 = 2048MB, Flash ≈ 520MB (省 75%)
  N=32768: 标准 = 8192MB, Flash ≈ 1040MB (省 87%)

N 越大, FlashAttention 节省的 HBM 越小... 
不对, 重新算:

FlashAttention 的 HBM 读写 ≈ O(N² × d² / M)
更精确的:
  读 Q: N×d 次
  读 K: Tr × N×d / Tc   ← Tr=Tc 时 = N×d (读 N/B 遍)
  所以总读 ≈ N×d × (1 + 2N/Br)  ← 这里 N/Br = Tr = 块数

  N=4096, d=128, Br=128: Tr=32
  读 ≈ 4096×128 × (1+2×32) = 524288 × 65 ≈ 34 MB
  写 ≈ N×d = 1 MB
  总计 ≈ 35 MB ← 之前估算略高, 这是精确值

vs 标准 ≈ 132 MB
→ 实际节省约 73%
```

---

## 常见问题排查

### 1. 装了 FlashAttention 但 vLLM 没用上

```bash
# 检查
python3 -c "from flash_attn import flash_attn_func; print('OK')"
# 如果报错: ModuleNotFoundError → 没装或装错了

# vLLM 启动日志中查看:
# "Using FlashAttn backend" → 在用
# "Using FlashInfer backend" → 在用 FlashInfer (可能是更好的选择)
# "Using Torch SDPA backend" → fallback 了, 没用上

# 强制指定:
export VLLM_ATTENTION_BACKEND=FLASH_ATTN
```

### 2. FlashAttention 在某些 seq_len 下变慢

```
原因: block_size 不是 seq_len 的约数 → 最后一个块利用率低

解决: 不用管, vLLM 会自动处理。性能下降 < 5%
如果极端敏感: 确保 max-model-len 是 block_size 的倍数
```

### 3. 编译 FlashAttention 失败

```bash
# 常见错误:
# "CUDA_HOME environment variable is not set"
# "nvcc not found"

# 解决:
export CUDA_HOME=/usr/local/cuda
export PATH=$CUDA_HOME/bin:$PATH

# 如果没有 CUDA Toolkit:
# pip install flash-attn --no-build-isolation 需要 nvcc
# 改为下载预编译 wheel:
# https://github.com/Dao-AILab/flash-attention/releases

# 本机 CUDA 12.6, 下载 cu122 的 wheel 即可
```

### 4. 显存不够 → FlashAttention 能救吗

```
FlashAttention 省的是 Attention 中间矩阵的显存 (O(N²) → O(1))
不省模型参数、KV Cache、激活值的显存

能省多少:
  N=4096: 省 64 MB (不多)
  N=8192: 省 256 MB
  N=32768: 省 2 GB (开始明显)
  N=131072: 省 32 GB (质的飞跃)

所以:
  短 prompt (<4096): FlashAttn 省显存不明显, 主要是加速
  长 prompt (>8192): FlashAttn 是能不能跑的区别
```

## 面试追问

**Q: FlashAttention 的 block_size 怎么选？**
A: 受 SRAM 大小限制。SRAM 需要同时放下 Q_block(Br×d) + K_block(Bc×d) + V_block(Bc×d) + S_block(Br×Bc) + P_block(Br×Bc)。A800 有 164KB SRAM/SM。2×Br×Bc×2 + Br×d×2 + 2×Bc×d×2 < 164KB。若 Br=Bc, d=128: 4B² + 256B + 512B < 164K → B² + 64B + 128 < 41K → B ≈ 128-256。实际取 128 是经过 autotune 的。

**Q: FlashAttention 支持 mask 吗？**
A: 支持。Causal mask 在 SRAM 内直接应用, 不额外占 HBM。只需在计算 S_ij 后立即 mask, 被 mask 的值直接设 -inf 进入后续 softmax。

**Q: FlashAttention vs PagedAttention 的关系？**
A: 互补。FlashAttention 解决单次 Attention 的计算/显存效率, PagedAttention 解决多个请求的 KV Cache 管理效率。vLLM 同时用两者: PagedAttention 管理 KV block, FlashAttention 计算每个 block 内的 Attention。
