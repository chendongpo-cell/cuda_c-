# vLLM 内部架构全景

## 一句话总结
vLLM 的核心架构：API Server → Scheduler(调度器) → BlockAllocator(显存管理) → Worker/ModelRunner(执行推理) → GPU。每个请求经历：入队 → 分配 KV Cache block → Prefill → Decode → 释放 block 六个阶段。

## 整体架构图

```
┌─────────────────────────────────────────────────────────┐
│                    vLLM 整体架构                         │
│                                                         │
│  HTTP Request (OpenAI API)                               │
│       ↓                                                  │
│  ┌──────────────────────┐                               │
│  │   API Server          │  FastAPI/uvicorn              │
│  │   (entrypoints/)      │  解析请求, tokenize           │
│  └──────────┬───────────┘                               │
│             ↓                                            │
│  ┌──────────────────────┐                               │
│  │   Scheduler            │  核心调度器                  │
│  │   (core/scheduler.py) │                               │
│  │                        │  决定: 谁做Prefill/谁做Decode │
│  │   - waiting: 排队请求   │       谁被swap/recompute     │
│  │   - running: 正在执行   │       给每个请求分配 block   │
│  │   - swapped: 被换出    │                               │
│  └──────────┬───────────┘                               │
│             ↓                                            │
│  ┌──────────────────────┐                               │
│  │   BlockAllocator       │  GPU 显存块管理器            │
│  │   (core/block_manager) │                               │
│  │                        │  分配/释放 KV Cache block    │
│  │   - free_blocks: 空闲  │  CoW 共享 block              │
│  │   - block_size: 16     │  Swap in/out                 │
│  └──────────┬───────────┘                               │
│             ↓                                            │
│  ┌──────────────────────┐                               │
│  │   Worker / ModelRunner│  实际执行推理                 │
│  │   (worker/)           │                               │
│  │                        │  组 batch → GPU forward      │
│  │   每张 GPU 一个 Worker  │  TP: 多 Worker 协作          │
│  └──────────┬───────────┘                               │
│             ↓                                            │
│  ┌──────────────────────┐                               │
│  │   GPU                  │  执行 CUDA kernel            │
│  │   PagedAttention       │  返回 logits → sample token  │
│  └──────────────────────┘                               │
└─────────────────────────────────────────────────────────┘
```

## 请求全生命周期

```
一个 Chat Completions 请求的完整旅程:

1. 接收请求
   POST /v1/chat/completions → FastAPI → tokenize
   → 封装成 SequenceGroup

2. 进入调度
   Scheduler.add_request(seq_group)
   → 放入 waiting 队列

3. 分配显存
   下次 iteration:
   Scheduler._schedule()
   → 检查 waiting 队列
   → BlockAllocator.allocate() 分 block
   → 如果显存不够 → Preemption (swap/recompute)

4. Prefill (首次)
   ModelRunner.execute_model()
   → batch = [prefill_req, ...decode_reqs...]
   → GPU forward: 计算所有 prompt token 的 KV Cache
   → 把 KV Cache 存入分配的 block
   → 产出第一个 output token

5. Decode (循环)
   ModelRunner.execute_model()
   → batch = [decode_req_1, decode_req_2, ...]
   → 每次 iteration:
       从 block 读取 KV Cache
       GPU forward: 算一个新 token
       新 token 的 KV 追加到 block
       → 产出下一个 token

6. 结束 & 释放
   生成完成 (EOS / max_tokens / stop string)
   → Scheduler.free_request()
   → BlockAllocator.free() 释放所有 block
   → 返回完整 response
```

## 核心数据结构

### SequenceGroup

```python
# 一个请求的所有信息
class SequenceGroup:
    request_id: str           # 请求唯一 ID
    seqs: List[Sequence]      # 一个或多个序列 (n>1 时多个)
    sampling_params: dict     # temperature, top_p, max_tokens 等
    arrival_time: float       # 到达时间
    prompt: str               # 原始 prompt
    prompt_token_ids: list    # tokenize 后的 prompt
```

### Sequence

```python
# 单个序列 (n=1 时等于一个 SequenceGroup)
class Sequence:
    seq_id: int
    status: Waiting | Running | Swapped | Finished
    output_token_ids: list        # 已生成的 token
    logical_token_blocks: list    # 逻辑 block 列表 (Block Table)
    block_table: list[int]        # 物理 block ID 列表
```

### BlockTable

```python
# 逻辑位置 → 物理位置的映射
# 每个 Sequence 有一个 BlockTable

Sequence:
  logical_blocks: [0, 1, 2, 3]     # 逻辑块序号
  block_table:    [7, 3, 12, 5]   # 对应的物理块 ID
  #           block_0 → 物理块 #7
  #           block_1 → 物理块 #3
  #           block_2 → 物理块 #12
  #           block_3 → 物理块 #5
```

### BlockAllocator

```python
# GPU 显存块管理器
class BlockAllocator:
    free_blocks: list[int]       # 空闲物理块队列
    block_size: int = 16         # 每块存 16 个 token 的 KV Cache
    num_gpu_blocks: int          # GPU 上共有多少 block
    
    def allocate(self) -> int:
        """分配一个物理块, 返回 block_id"""
        return self.free_blocks.pop()
    
    def free(self, block_id: int):
        """释放物理块"""
        self.free_blocks.append(block_id)
    
    def get_num_free_blocks(self) -> int:
        return len(self.free_blocks)
```

## 调度器内部流程 (每次 iteration)

```python
def _schedule(self) -> SchedulerOutput:
    """
    每次 iteration 的核心调度逻辑
    """
    scheduled = []  # 本次要执行的 seq_group 列表
    
    # === Step 1: 处理排队请求 ===
    for seq_group in self.waiting:
        # 计算这个请求需要多少 block
        num_blocks_needed = self._get_num_blocks(seq_group.prompt_len)
        
        # 检查空闲 block 够不够
        if self.block_allocator.get_num_free_blocks() >= num_blocks_needed:
            # 分配 block
            blocks = [self.block_allocator.allocate() for _ in range(num_blocks_needed)]
            seq_group.block_table = blocks
            
            # 从 waiting 移到 scheduled
            self.waiting.remove(seq_group)
            scheduled.append(seq_group)
        else:
            # 显存不够 → Preemption
            # 1. 选一个 running 的最低优先级 seq
            # 2. Swap out 或 Recompute
            victim = self._pick_victim()
            if victim:
                self._preempt(victim)
                # retry allocation
    
    # === Step 2: 加入 running 请求 ===
    for seq_group in self.running:
        if not seq_group.is_finished():
            scheduled.append(seq_group)
    
    # === Step 3: token budget 检查 ===
    # max-num-batched-tokens 限制
    total_tokens = sum(len(sg) for sg in scheduled)
    if total_tokens > self.max_num_batched_tokens:
        # 减掉一些 running 请求 (这轮不执行)
        scheduled = scheduled[:self.max_num_seqs]
    
    return scheduled
```

## 和 HuggingFace Transformers 的对比

### 为什么 vLLM 快 24 倍

```python
# HuggingFace Transformers 推理:
for request in requests:
    # 1. 一次只处理一个请求 (无 batching)
    inputs = tokenizer(request.prompt, return_tensors="pt").to("cuda")
    
    # 2. 每次都预分配最大长度的 KV Cache (连续内存)
    past_key_values = None  # 大量碎片和浪费
    
    # 3. 用 transformers 的 model.generate()
    outputs = model.generate(**inputs, max_new_tokens=100)
    #         ↑ 每个 request 单独做 GPU launch

# vLLM 推理:
while waiting or running:
    # 1. 一次处理多个请求 (Continuous Batching)
    batch = scheduled_requests
    
    # 2. PagedAttention: 按需分配 block,零碎片
    for req in batch:
        req.block_table = allocate_blocks(needed)
    
    # 3. 一次 GPU forward 处理整个 batch
    logits = model.forward(batch)
    #         ↑ 所有请求共享一次 GPU launch
```

### 性能差异来源

| 优化点 | HF Transformers | vLLM | 加速 |
|--------|---------------|------|------|
| Batching | 静态/无 | Continuous Batching | ~5-10× |
| KV Cache 管理 | 预分配连续内存 | PagedAttention 分页 | ~2-3× |
| GPU Launch | 每请求单独 | 合并 batch 一次 | ~2× |
| CUDA Graph | 无 | Decode 用 CUDA Graph | ~1.3× |
| Kernel 优化 | 基础 | FlashInfer/自定义 kernel | ~1.5-2× |
| Prefix Caching | 无 | Radix Tree | ~3-5× (长system prompt) |

综合加速 ≈ 5×2×2×1.3×1.5 = **20-40×** (和论文的 24× 一致)

## vLLM 的 OpenAI API 实现

```python
# vllm/entrypoints/openai/api_server.py
# 用 FastAPI 实现的 OpenAI 兼容 API

# 核心路由:
@app.post("/v1/chat/completions")     # ← 最常用
@app.post("/v1/completions")          # 旧格式
@app.get("/v1/models")                # 模型列表
@app.get("/health")                   # 健康检查
@app.get("/metrics")                  # Prometheus 指标

# 实际处理:
# 1. 解析 OpenAI 格式的 request body
# 2. 调用 tokenizer 把 messages 转成 prompt
# 3. 创建 SequenceGroup 交给 Scheduler
# 4. 如果是 streaming → 用 SSE 逐 token 返回
# 5. 如果是 non-streaming → 等到完成再返回
```

## 查看 vLLM 内部状态

```bash
# 运行时指标
curl --noproxy '*' http://localhost:8001/metrics | grep vllm:

# 启动日志中的关键信息
# "INFO: Using block size 16 for KV cache"
# "INFO: GPU KV cache blocks: 2560, CPU KV cache blocks: 640"
# → GPU: 2560×16=40960 个 token 的 KV Cache 空间
# → CPU swap: 640×16=10240 个 token 的 swap 空间

# 用这些数字验证显存公式:
# block_size × num_gpu_blocks × per_block_kv_cache_size ≈ gpu_memory * gpu_memory_utilization
```

## 源码关键文件

如果你想深入读 vLLM 源码，从这些文件入手：

```
vllm/
├── entrypoints/openai/api_server.py   # API 层, 入口
├── core/
│   ├── scheduler.py                   # 调度器 (最核心)
│   └── block_manager.py               # BlockAllocator
├── engine/
│   └── llm_engine.py                  # LLMEngine (协调 Scheduler + Worker)
├── worker/
│   ├── worker.py                      # Worker (单 GPU)
│   └── model_runner.py                # ModelRunner (组 batch + forward)
├── attention/
│   └── backends/flash_attn.py         # PagedAttention FlashAttn 实现
└── model_executor/
    └── models/                         # 各模型适配 (Qwen/LLaMA/DeepSeek...)
```

---

## 源码走读：一次 forward 的完整路径

```
API 请求进来 → 生成 token 出去, 代码调用链:

1. api_server.py:
   @app.post("/v1/chat/completions")
   → tokenize(messages)  →  LLMEngine.add_request()

2. llm_engine.py:
   def add_request(request_id, prompt, sampling_params):
       seq_group = SequenceGroup(request_id, prompt, sampling_params)
       self.scheduler.add_request(seq_group)

   def step():  # 每次 iteration
       scheduler_output = self.scheduler.schedule()  # ← 决定 batch 内容
       output = self.workers[0].execute_model(scheduler_output)  # ← GPU forward
       self.scheduler.update(output)  # ← 更新状态
       return output

3. scheduler.py (核心):
   def schedule():
       # Step 1: 处理 waiting 队列
       for seq_group in self.waiting:
           if block_allocator.can_allocate(seq_group):
               blocks = block_allocator.allocate(seq_group)
               seq_group.block_table = blocks
               scheduled.append(seq_group)
       
       # Step 2: 加入 running
       for seq_group in self.running:
           if not seq_group.finished:
               scheduled.append(seq_group)
       
       # Step 3: token budget
       if total_tokens > max_num_batched_tokens:
           scheduled = trim(scheduled)
       
       return SchedulerOutput(scheduled)

4. model_runner.py (执行):
   def execute_model(scheduler_output):
       # 1. Prepare inputs
       for seq_group in scheduler_output:
           tokens = seq_group.get_tokens()          # prompt + generated
           positions = seq_group.get_positions()    # token 位置
           block_tables = seq_group.block_table     # KV Cache block table
       
       # 2. 一次 GPU forward
       hidden_states = model(
           input_ids=concat_tokens,
           positions=concat_positions,
           kv_caches=load_from_block_tables(block_tables)
       )
       
       # 3. Sample
       next_tokens = sample(hidden_states, sampling_params)
       
       return next_tokens

5. attention/backends/flash_attn.py (PagedAttention kernel):
   def forward(query, key, value, block_tables, ...):
       # 从 block table 加载非连续的 KV Cache
       for block_id in batch["block_tables"]:
           k_block = kv_cache_pool[block_id * block_size : (block_id+1) * block_size]
       
       # FlashAttention: SRAM tiling + Online Softmax
       output = flash_attn_func(query, key, value, causal=True)
       return output
```

---

## 常见问题排查

### 1. "第一次请求很慢 (TTFT 3-5s)"

```
原因: CUDA kernel JIT 编译

vLLM 首次加载模型时:
  PyTorch 的 CUDA kernel 可能未被编译
  第一次 forward 时 PyTorch 会 JIT 编译 → 耗时几秒

解决:
  # 预热 (warmup)
  curl ... -d '{"max_tokens":1}'  # 发一个最小请求触发编译
  # 或在启动参数加: --enforce-eager (禁用 CUDA Graph, 但启动时编译)
```

### 2. "vLLM 进程在后台, 但过一会就死了"

```
排查:
  1. journalctl -u vllm-7b --no-pager | tail -50
     或 docker logs vllm-7b --tail 50

  2. 常见死因:
     a. OOM killer (显存或内存):
        dmesg | grep -i "out of memory"
        解决: 减 max-num-seqs 或 gpu-memory-utilization

     b. CUDA kernel error:
        "CUDA error: an illegal memory access was encountered"
        解决: 重启，通常是 bug 或显存踩踏

     c. tokenizer 问题:
        "KeyError: '<|im_start|>'"
        解决: 确认 chat_template 和模型匹配

     d. 端口被占用:
        "Address already in use"
        解决: 换端口或 kill 旧进程
```

### 3. "vLLM 日志里看到大量 swap/recompute"

```
日志:
  "WARNING: Swapped 1 requests to CPU"
  "WARNING: Recomputing 2 requests"

原因: KV Cache block 不够

解决:
  1. gpu-memory-utilization 从 0.90 → 0.95
  2. max-num-seqs 减半
  3. 开 prefix-caching (如果 system prompt 长)
  4. 开 kv-cache-dtype fp8 (KV Cache 减半)
```

### 4. "API 返回 200 但 response 是空的"

```
原因:
  生成了 EOS 或 stop token 作为第一个 token
  
解决:
  检查 stop token 设置: --stop "<|im_end|>"
  有时 tokenizer 把 EOS 当成第一个 token → 立即停止
  加 min_tokens=1 参数
```

## 面试追问

**Q: vLLM 为什么用 FastAPI？换 gRPC 会更快吗？**

A: FastAPI 容易对接 OpenAI 生态（JSON/SSE）。gRPC 更快（二进制）但生态不兼容。生产上可以内部用 gRPC 做 backend 间通信，对外保持 OpenAI 兼容 REST。vLLM 选择 FastAPI 是因为：1) Python 生态完善 2) 流式 SSE 天然支持 3) 调试方便。性能瓶颈不在 API 层（JSON 解析 vs GPU forward 可以忽略）。

**Q: vLLM 单进程多 GPU 还是多进程？**

A: TP 时是多进程（Ray actor per GPU）。vLLM 用 Ray 做分布式：每个 GPU Worker 是独立的 Ray actor 进程，有自己的 CUDA context。好处：隔离好，一个 GPU OOM 不影响其他。坏处：进程间通信有 overhead（但 NVLink 快）。

**Q: vLLM 的 Continuous Batching 和 Triton 的 Dynamic Batching 有什么区别？**

A: Triton Dynamic Batching: 等足够多请求再批量处理（类似 batch queue）。vLLM Continuous Batching: 不需要等，每次 iteration 动态组 batch，完成的立刻退出。vLLM 更激进，延迟更低。Triton 更适合 batch size 固定的场景（如图像推理），vLLM 更适合 token 长度不固定的 LLM。
