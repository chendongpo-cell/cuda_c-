# Transformer 推理全流程

## 一句话总结
推理分两阶段：Prefill（并行编码所有 prompt token，计算密集，GPU 利用率高）和 Decode（逐 token 自回归生成，内存带宽密集，GPU 利用率低）。首 token 延迟看 Prefill，生成速度看 Decode。

## 先理解：一个 Token 在 Transformer 里经历什么

想象每个 token 是一张纸，Transformer 是 32 个工人组成的流水线。

```
输入: token_id = 12345 (代表"猫"这个字)

第0步: 查字典 (Embedding)
  12345 → 查表 → 4096维的向量 [0.02, -0.15, 0.33, ..., 0.08]
  这个向量就是"猫"这个字在数学空间的坐标

然后进入 32 层流水线。每层做两件事:

第一件事: Attention (和所有其他 token 交流)
  ┌─────────────────────────────────────────┐
  │ "猫" 的向量 去问所有其他位置的向量:       │
  │ "我应该关注谁?"                           │
  │                                          │
  │ 比如翻译 "I love cats":                   │
  │ "cats" 问: 我和 "I" 的关系? → 0.1 (一般)  │
  │ "cats" 问: 我和 "love" 的关系? → 0.8 (强!) │
  │ → "cats" 的向量更新为包含 "love" 的信息   │
  │ → 模型知道 cats 是 love 的宾语            │
  └─────────────────────────────────────────┘

第二件事: FFN (自己消化)
  ┌─────────────────────────────────────────┐
  │ 更新后的向量 → 两个矩阵乘法 → 新向量      │
  │ 这一步不和其他 token 交流，只是自己消化   │
  │ → 提取更高级的语义特征                    │
  └─────────────────────────────────────────┘

32 层流水线走完 → 最后一步: 输出 (LM Head)
  4096维向量 → × W_lm_head → 151936维向量
  151936 = 词表大小 (Qwen3-8B)
  每个位置的值 = "下一个 token 是这个字的概率"
  
  151936 个值中最大的那个 → 就是模型预测的下一个 token
```

## 为什么推理和训练不一样

```
训练 (已知答案, 一次算完):
  输入: "今天天气怎么样<ans>很好</ans>"
  一次 forward: 对所有位置同时计算 loss
  → 每个位置都知道正确答案是什么
  → 可以并行 (batch 内所有样本全并行)

推理 (不知道答案, 每次只能猜一个):
  输入: "今天天气怎么"  (只知道 prompt)
  → 第1步: 算 next_token → "样"
  → 第2步: 把"样"拼回去, 得到 "今天天气怎么样", 再算 next_token → "很"
  → 第3步: "今天天气怎么样很", 算 next_token → "好"
  → ...循环直到输出 EOS 或达到 max_tokens

为什么不能一次全算出来?
  因为第 N+1 个 token 依赖第 N 个 token
  你不知道"样"之前, 没法预测"很"
  
  这就是自回归 (auto-regressive)
```

## Prefill 阶段：一口气理解整个 prompt

### 用数字理解

```
输入: "请解释一下 Transformer" (10 个 token)

计算量分析:

每层要做的事:
  1. 10个token × 4096维 → 和 W_Q(4096×4096) 乘 → 10×4096 结果
  2. 10个token × 4096维 → 和 W_K(4096×4096) 乘 → 10×4096 结果  
  3. 10个token × 4096维 → 和 W_V(4096×4096) 乘 → 10×4096 结果
  4. Q×K^T: [10,4096] × [4096,10] = [10,10] → 100 次点积
  5. softmax + V: [10,10] × [10,4096] = [10,4096]
  6. 和 W_O 乘: [10,4096] × [4096,4096] = [10,4096]
  7. FFN: 两个 [10,4096] × [4096,12288] 和 [10,12288] × [12288,4096]

总的浮点运算:
  ≈ 2×参数总量 × token数  (经验公式)
  ≈ 2 × 8B × 10 ≈ 160 GFLOPs

A800 算力: 312 TFLOPS (BF16 理论峰值)
实际利用率 ~80% → 250 TFLOPS

Prefill 时间 ≈ 160G / 250T ≈ 0.64 毫秒

为什么这么快?
  10 个 token 同时算 → 矩阵乘法效率高
  Tensor Core 擅长做大矩阵乘法
  Q×K, Q×W 这些都是大矩阵 → GPU 算起来就很爽
```

### 长 prompt 就慢了

```
4096 token 的 prompt (比如一篇长文章):

总 FLOPs ≈ 2 × 8B × 4096 ≈ 65.5 TFLOPs
时间 ≈ 65.5T / 250T ≈ 0.26 秒

32768 token 的 prompt (一本书):
总 FLOPs ≈ 2 × 8B × 32768 ≈ 524 TFLOPs  
时间 ≈ 524T / 250T ≈ 2.1 秒

长 prompt 的 TTFT 就是这么来的
所以如果你的 API 感觉 "卡了一下才开始输出" → 就是 Prefill 在做工
```

## Decode 阶段：一个一个往外蹦

### 为什么慢

```
生成第 1 个 token("很")时:
  输入: 只有 1 个 token("样"的 embedding)
  输出: 要在 151936 个候选中选 1 个

这次只算 1 个 token:
  FLOPs ≈ 2 × 8B × 1 ≈ 16 GFLOPs ← 很少!

但需要读的数据:
  前面 10 个 token 的 KV Cache (每个 token 在每层的 K 和 V)
  10 tokens × 36 layers × 2 (K+V) × 8 heads × 128 dim × 2 bytes
  ≈ 1.4 MB

为什么 16 GFLOPs 的计算需要读 1.4 MB 数据:
  算力/带宽比 = 16G / 1.4M ≈ 11400 FLOPs/byte
  
  A800: 每 byte 能提供 ~156 FLOPs 的算力
  但实际需要 11400 FLOPs/byte → 远大于 156
  
  这意味着: 计算单元大部分时间在等数据
  → GPU 利用率低 (10-30%)
  → 每 token 的时间被 HBM 带宽限制

这就像:
  你是一个超级聪明的数学家 (GPU 算力)
  但图书馆规定每次只能借一本书 (HBM 带宽)
  你大部分时间花在去图书馆的路上
```

### 用数字理解

```
生成 100 个 token:

每步的时间 = KV Cache 读取时间 + 计算时间

对于 7B 模型, seq_len=4096:
  读 KV Cache: ~256 MB / 2TB/s ≈ 0.13 ms
  计算: 16GFLOPs / 250TFLOPS ≈ 0.06 ms
  → 理论 TPOT ≈ 0.2 ms

实际 TPOT ≈ 8-20 ms (比理论慢 40-100 倍！)

为什么差这么多?
  1. GPU 利用率: 单 token 时 Tensor Core 利用率只有 ~20%
  2. Launch overhead: 每次 forward 需要 20+ 个 CUDA kernel launch
  3. 非 GEMM 操作: softmax, causal mask, sample 不加速
  4. Batch 不够大: 1 个 token 填不满 108 个 SM

增大 batch 可以改善:
  并发 64 个请求一起 Decode → 64 个 token 一起算
  → GPU 利用率从 20% → 60%+
  → TPOT 不变 (每 token 时间), 但吞吐翻了近 3 倍
```

## 一句话说清 Prefill vs Decode

```
           Prefill                Decode
做什么      一次性算所有prompt      一次只算一个新token
计算量      O(seq²)                O(seq)
瓶颈        GPU算力(compute-bound) 显存带宽(memory-bound)
GPU利用率   80-100%                10-30%
像什么      一口气读完整本书        一个字一个字往外蹦
优化方法    FlashAttention、大batch  KV Cache量化、CUDA Graph
```

## 关键指标

```
TTFT (Time To First Token):
  从请求发出到收到第1个token的时间
  = 网络延迟 + 排队时间 + Prefill时间
  
  短 prompt (<100 token): Prefill < 10ms → TTFT 主要看排队
  长 prompt (>1000 token): Prefill 几百ms → TTFT 主要看 Prefill

TPOT (Time Per Output Token):
  除第1个token外, 每token平均时间
  = Decode每步时间

  短 seq (<4096): TPOT ~10-20ms
  长 seq (>32K): TPOT ~50-100ms

Throughput (tokens/s):
  所有并发请求的总产出
  受 batch size 和 GPU 利用率影响
```

## 实战：观察本机的 Prefill 和 Decode

```bash
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY

# 测试1: 短 prompt, 看 TTFT
time curl -s --noproxy '*' http://localhost:8001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"Qwen3.5-122B","messages":[{"role":"user","content":"你好"}], "max_tokens":1}'
# 几乎立即返回 → TTFT 很小 (<100ms)

# 测试2: 长 prompt, 看 TTFT
LONG_PROMPT=$(python3 -c "print('请总结以下内容：' + '人工智能是计算机科学的一个分支，致力于创建能够执行通常需要人类智能的任务的系统。' * 200)")
time curl -s --noproxy '*' ... -d "{\"messages\":[{\"role\":\"user\",\"content\":\"$LONG_PROMPT\"}],\"max_tokens\":1}"
# TTFT 明显更长 → Prefill 在做工

# 测试3: 对比不同 max_tokens, 看 Decode 速度
for mt in 10 50 100 200; do
  echo "max_tokens=$mt:"
  time curl -s --noproxy '*' ... -d "{...,\"max_tokens\":$mt}" > /dev/null
done
# 时间应该线性增长, 斜率 ≈ TPOT
```

## 常见问题

### 1. "为什么看起来 GPU 利用率只有 20%, 但 API 还挺快的?"

```
因为 Decode 的 GPU 利用率本来就是 10-30% (memory-bound)
这不是问题, 是特性

如果你看的是 nvidia-smi 的 GPU-Util:
  它是 kernel 执行时间占比
  Decode 时每个 kernel 很短 (< 50μs)
  kernel 之间的 launch gap 不算 utilization

所以 20% 是正常的
想看真实利用率用 Nsight (见 docs/08-advanced/nsight-profiling.md)
```

### 2. "为什么 TTFT 有时候 200ms, 有时候 2s?"

```
200ms: Prefill 短 prompt + 无需排队 → 正常
2s:   Prefill 长 prompt (>2000 token) + 前面有请求在排队

排查:
  # 看排队请求数
  curl --noproxy '*' http://localhost:8001/metrics | grep num_requests_waiting
  
  # 如果 waiting > 0, 说明有排队
  # 增大 max-num-seqs 或增加实例
```

### 3. "为什么 max_tokens=1 的请求延迟还是很高?"

```
因为延迟来自:
  TTFT = 排队 + Prefill (受 prompt 长度影响, 不受 max_tokens 影响)

max_tokens=1 只是控制了 Decode 的步数 = 1 步
但 Prefill 还是要算整个 prompt

只有 prompt 很短时 (<10 token), TTFT 才能真正降到最小
```

### 4. Decode 能不能用 GPU 的算力更多一点?

```
增加 Concurrent Batching:
  把多个请求拼成 batch → GPU 一次处理多个 token
  → 每个 token 的平均成本下降

使用 CUDA Graph:
  消除 kernel launch overhead (那 20+个 kernel 的 launch gap)
  → 每步节省 5-10μs

使用 FP8 KV Cache:
  减少 KV Cache 读取量 → 缓解 memory-bound

但这些都不能改变 Decode 本质上是 memory-bound
除非有颠覆性的硬件架构 (更大的 SRAM / 更高的 HBM 带宽)
```