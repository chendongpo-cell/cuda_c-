# NCCL 通信原语

## 一句话总结
NCCL 是 NVIDIA 的多 GPU 通信库。核心原语：AllReduce（求和）、AllGather（拼接）、ReduceScatter（分散求和）。TP 主要用 AllReduce，Ring 拓扑下通信高效。

## 四大通信原语

### AllReduce
```
所有卡对各自的值求和，每张卡得到相同结果

输入:
  卡0: a, 卡1: b, 卡2: c, 卡3: d
输出:
  所有卡: a+b+c+d

Ring AllReduce (2步):
  Step 1 - ReduceScatter: 每卡得到 sum 的一部分
    卡0: sum_chunk0, 卡1: sum_chunk1, ...
  Step 2 - AllGather: 拼接所有 chunk
    所有卡: [sum_chunk0, sum_chunk1, sum_chunk2, sum_chunk3]

通信量: 2 × (N-1)/N × data_size  ← 几乎不随卡数增长
```

### AllGather
```
把所有卡的数据拼接起来

输入:
  卡0: [A], 卡1: [B], 卡2: [C], 卡3: [D]
输出:
  所有卡: [A, B, C, D]

通信量: (N-1)/N × data_size
```

### ReduceScatter
```
求和后分散到各卡

输入:
  卡0: [a0,a1,a2,a3], 卡1: [b0,b1,b2,b3], ...
输出:
  卡0: sum([a0,b0,c0,d0]), 卡1: sum([a1,b1,c1,d1]), ...
  (每卡只得到一个 chunk 的和)

通信量: (N-1)/N × data_size
```

### Broadcast
```
一张卡广播到所有卡

卡0: [data] → 所有卡: [data]
通信量: data_size
```

## Ring Topology

```
Ring AllReduce 的数据流 (4卡):

Step 1: ReduceScatter (顺时针传)
  卡0 → data0 → 卡1 → data0+data1 → 卡2 → ... → 卡3
  卡1 → data1 → 卡2 → ...
  同一时刻有 N 个数据在环上流动 (流水线)

Step 2: AllGather (逆时针传)
  类似，但传递的是求和后的 chunk

优点:
  1. 带宽利用率接近 100%
  2. 通信量 O(N-1)/N → 接近常数
  3. 每卡只收发 2 次
```

## NVLink vs PCIe

```
NVLink 3.0 (A800):
  带宽: 400 GB/s (双向), 每个方向 200 GB/s
  延迟: ~1-2 μs (GPU direct)
  拓扑: 全互联 (每卡之间直连)

PCIe 4.0 x16:
  带宽: ~32 GB/s (双向)
  延迟: ~5-10 μs (通过 CPU/PCIe switch)
  拓扑: 树形 (通过 PCIe switch)

GPU间通信: NVLink 比 PCIe 快 ~12 倍
```

## TP 用到的通信

```
TP 中每层 Transformer 的前向传播:

Attention 后: 1× AllReduce (把行并行的 O_i 求和)
MLP 后:      1× AllReduce (把行并行的 Y_i 求和)

每个 iteration:
  总 AllReduce = 2 × num_layers

做 ring AllReduce 时:
  通信量 = 2 × (N-1)/N × data
  延迟 = 2 × (N-1)/N × data / bandwidth + 2×latency×N

实际例子 (TP=4, batch=8, seq_len=4096, hidden=4096, 32层, FP16):
  data = batch × seq_len × hidden × 2 bytes = 8 × 4096 × 4096 × 2 = 256 MB
  通信量 = 2 × (4-1)/4 × 256MB = 2 × 0.75 × 256MB = 384 MB/层
  总通信 = 384MB × 32 × 2 = 24.6 GB
  
  NVLink: 24.6 GB / 400 GB/s ≈ 62 ms
  PCIe:   24.6 GB / 32 GB/s ≈ 769 ms ← 不可接受

所以: TP 必须 NVLink，不能 PCIe
```

## 查看 NCCL 信息

```bash
# NCCL 环境变量
echo $NCCL_SOCKET_IFNAME   # 网卡
echo $NCCL_IB_DISABLE      # InfiniBand 开关
echo $NCCL_DEBUG           # 调试级别

# NCCL 调试模式
export NCCL_DEBUG=INFO     # 打印通信详情
export NCCL_DEBUG=WARN     # 只打印警告/错误

# GPU 拓扑
nvidia-smi topo -m         # 查看 GPU 间互联拓扑
# NVLink 标记为 NV12 (最多12个NVLink通道)
# PCIe 标记为 PIX/PHB
# NUMA 节点: 同一 NUMA node 的 GPU 通信更快
```

## 本机 GPU 拓扑

```bash
nvidia-smi topo -m
# 输出会显示每对 GPU 之间的连接类型
# A800 之间应该是 NV12 (全互联 NVLink)
```
