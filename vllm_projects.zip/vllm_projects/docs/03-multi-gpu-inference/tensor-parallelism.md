# 张量并行深度解析

## 一句话总结
张量并行把一层内的超大矩阵乘法切分到多张 GPU，每张算一部分，然后 AllReduce 汇聚。适合单机多卡（NVLink 快），通信量随 batch×seq 线性增长但不随层数增长。

## 先理解：为什么一张 GPU 放不下大模型

```
Qwen2.5-72B 的参数量:
  72,000,000,000 个参数 × 2 bytes (FP16) = 144 GB

一张 A800 显存: 80 GB
  → 放不下! (144 > 80)

方案 1: 量化 (INT4) → 144/4 = 36 GB ✅
方案 2: 多张 GPU 一起 → TP ✅
方案 3: 量化 + 多 GPU → 都可以
```

## 核心思路：把矩阵切碎，分给多张 GPU

### 以 Self-Attention 为例

```
原始的 Attention 计算:
  Q = Input × W_Q    (W_Q 是 [4096, 4096] 的矩阵)
  K = Input × W_K
  V = Input × W_V
  Output = Attention(Q,K,V) × W_O

TP=4 时, 把每个 W 的列切成 4 份:

  卡0: W_Q 的列 0-1023    卡1: W_Q 的列 1024-2047
  卡2: W_Q 的列 2048-3071  卡3: W_Q 的列 3072-4095

每张卡做自己的部分:
  卡0: Q_0 = Input × W_Q_0    (4096维 → 1024维的结果)
  卡1: Q_1 = Input × W_Q_1
  卡2: Q_2 = Input × W_Q_2
  卡3: Q_3 = Input × W_Q_3

然后拼起来用 (不需要物理拼接, 逻辑上管):
  Q = [Q_0 | Q_1 | Q_2 | Q_3]  → 完整 4096维
```

### 列并行 + 行并行

```
Attention 层有两个矩阵:
  W_Q, W_K, W_V: 列并行 (每张卡持有 1/4 列)
    卡i: Q_i = Input × W_Q_列i
    
  W_O: 行并行 (每张卡持有 1/4 行)
    卡i: Output_i = Attention(Q_i,K_i,V_i) × W_O_行i
    
    然后 AllReduce: 每张卡把其他卡的 Output_i 加过来
    最终每张卡得到完整的 Output

为什么 W_O 要行并行?
  因为 Attention(Q,K,V)的输出是 [seq, full_dim]
  如果 W_O 做成列并行, 输出要 AllGather 拼接
  行并行只需要 AllReduce 求和 (Ring AllReduce 效率更高)
```

## 一步一步推演

### 第1步: Input 广播

```
所有卡都有完整的 Input (不需要通信)
因为每张卡都需要相同的 Input 去和自己的 W 块算

Input [batch, seq, hidden] → 每张卡各有一份
```

### 第2步: 计算 Q, K, V (各算各的, 不需要通信)

```
卡0: Q0 = Input × W_Q_0  (1/4 的列)
卡1: Q1 = Input × W_Q_1
卡2: Q2 = Input × W_Q_2  
卡3: Q3 = Input × W_Q_3

同时算 K 和 V, 也是各算各的

这一阶段完全无通信!
```

### 第3步: Attention (各算各的, 不需要通信)

```
卡0: 用自己的 Q0,K0,V0 算 Attention → 得到 attn_0 [seq, 1024]
卡1: attn_1 [seq, 1024]
卡2: attn_2 [seq, 1024]
卡3: attn_3 [seq, 1024]

这一阶段也完全无通信!
```

### 第4步: 行并行 Output

```
卡0: Output_0 = attn_0 × W_O_行0  (1/4 的行)
     → Output_0 [seq, 4096] ← 只有 1/4 的行贡献

卡1: Output_1 [seq, 4096]
卡2: Output_2 [seq, 4096]
卡3: Output_3 [seq, 4096]
```

### 第5步: AllReduce (唯一需要通信的地方！)

```
Output_final = Output_0 + Output_1 + Output_2 + Output_3

Ring AllReduce:
  卡0 → 卡1 → 卡2 → 卡3 → 卡0
  数据在环上转一圈
  每张卡收一次发一次
  最后每张卡都得到完整的 Output_final

通信量 = 2 × (TP-1)/TP × data_size
       = 2 × 3/4 × (batch×seq×hidden×2bytes)
       ≈ 1.5 × data_size

对于 batch=8, seq=4096, hidden=4096, FP16:
  data_size = 8×4096×4096×2 = 256 MB
  每次 AllReduce ≈ 1.5 × 256 = 384 MB
  
NVLink 400GB/s: 384MB / 400GB/s ≈ 1ms
→ 对于 Attention 层, 通信只占 ~1ms, 几乎可忽略
```

## MLP 层同理

```
MLP 也有两个矩阵:

W_gate, W_up: 列并行
  gate_0 = Input × W_gate_列0  (各算各的, 无通信)

W_down: 行并行 + AllReduce
  卡0: Output_0 = hidden_0 × W_down_行0
  AllReduce → 完整 Output

每层 MLP 也需要 1 次 AllReduce
```

## 每层通信开销汇总

```
每层 Transformer 需要 2 次 AllReduce:
  1. Attention 后: 1 次
  2. MLP 后: 1 次

整个模型:
  总 AllReduce = 2 × num_layers 次

Qwen2.5-72B: 80 层
  总 AllReduce = 2 × 80 = 160 次

每层每次 AllReduce ≈ 384MB
总通信量 = 160 × 384MB ≈ 60 GB

NVLink: 60GB / 400GB/s ≈ 150ms 总通信时间

如果计算时间 ≈ 3-5 秒 (取决于 batch)
→ 通信占比 ≈ 3-5%
→ NVLink 下通信不是瓶颈!
```

## 但如果用 PCIe 呢？

```
PCIe 4.0 x16: ~32 GB/s (NVLink 的 1/12)

同样的通信量:
  60GB / 32GB/s ≈ 1.9 秒

如果计算时间 ~3-5 秒:
  通信占比 ≈ 40-60%
  → PCIe 下通信是严重瓶颈!

结论: TP 只能在 NVLink 互联的 GPU 之间做
```

## TP Size 怎么选

```
原则: TP 是为了把模型放进显存

Qwen3-8B (16 GB): TP=1 够了
Qwen3-32B (62 GB): TP=1 也够 (显存利用率 ~78%)
Qwen2.5-72B (144 GB): TP=2 刚好, TP=4 更宽松
LLaMA3-405B (810 GB): TP=8 在 8×A800 上刚好

更大的 TP Size:
  + 每卡显存占用更少 (可以跑更大 batch)
  + 每卡计算量更少
  - 通信量增大 (AllReduce 的 data_size 不变但参与卡更多)
  - Ring AllReduce 延迟增大 (环更长)

经验法则:
  TP=2: 通信可忽略
  TP=4: 通信 ~5%
  TP=8: 通信 ~15% (开始明显)
  TP>8: 通信成为瓶颈, 考虑 TP+PP 混合
```

## 常见问题排查

### 1. "多卡显存分配不均"

```
正常情况: 每卡显存差异 < 5%

如果差异 > 10%:
  检查: CUDA_VISIBLE_DEVICES 是否正确
  检查: --tensor-parallel-size 是否等于可见 GPU 数
  检查: 模型配置中的 num_attention_heads 是否能被 TP 整除

  Qwen3-8B: 32 heads, TP=4 → 32/4=8 → ✅
  Qwen3-8B: 32 heads, TP=3 → 32/3 → ❌ 不能被整除!
```

### 2. "TP=8 反而比 TP=4 慢"

```
TP Size 不是越大越好!

原因:
  TP=8: 每卡计算量更少 (1/8)
        但通信量不变 (AllReduce data_size 相同)
        通信延迟增大 (8 卡 Ring 比 4 卡 Ring 长一倍)
        
  如果 batch 不大:
    计算时间本来就短 → 通信占比变高 → 总体反而慢了

TP=8 只在以下情况有价值:
  - 模型必须用 TP=8 才放得下 (如 405B)
  - batch 很大, 计算时间主导
```

### 3. "NVLink 通信失败"

```
检查:
  nvidia-smi topo -m               # 看 GPU 拓扑
  nvidia-smi nvlink -s             # 看 NVLink 状态
  nvidia-smi nvlink -e             # 看 NVLink 错误计数

如果 NVLink 故障:
  GPU 间通信会自动 fallback 到 PCIe
  → 性能断崖式下降

  dmesg | grep NVLINK              # 看系统日志
```

### 4. "TP 多卡时网络可能成为瓶颈?"

```
一个常见误解: TP 需要跨节点网络

TP 在单机内通过 NVLink (400GB/s) 不需要走网络
PP 跨节点时才需要网络 (InfiniBand/RoCE)

TP 和网络的唯一关系:
  单机 8 卡内 → NVLink 搞定
  跨机器 → 不要用 TP, 用 PP 或者 DP
```

### 5. "为什么我的 NVLink 带宽只有 200GB/s?"

```
NVLink 3.0 的 400GB/s 是双向合计:
  读: 200 GB/s
  写: 200 GB/s
  总计: 400 GB/s

AllReduce 是读+写 → 单向有效带宽 ≈ 200 GB/s
所以实际通信时间 ≈ data_size / 200GB/s

之前算的 384MB / 200GB/s ≈ 2ms 每层
总通信 = 160层 × 2ms ≈ 320ms (而非之前的 150ms)

这是正常的!
```

## 面试追问

**Q: 既然 TP 通信量这么大, 为什么不用 PP 替代 TP?**

A: PP 有 bubble, GPU 利用率低。TP 虽然通信量大, 但 NVLink 下可接受 (5-15%)。PP 适合跨节点 (通信量小但 bubble 大)。实践: 节点内用 TP, 跨节点用 PP/DP。

**Q: 72B 模型, 用 2×TP=4 还是 1×TP=8 更好?**

A: 2 台机器各 TP=4 (2×4=8 卡) 更好。因为: 1) 单机 TP=4 通信 ~5%, 不影响性能; 2) 两台机器间可以用 PP, 通信量小; 3) TP=8 的通信开销比 TP=4+PP 的 bubble 开销更大。
