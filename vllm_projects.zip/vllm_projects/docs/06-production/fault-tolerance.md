# 容错与弹性

## 一句话总结
推理服务三大故障：OOM、CUDA Error、超时。应对策略：重试（指数退避+Jitter）、熔断（Circuit Breaker）、优雅降级（切换备模型）、健康检查+自动重启。

## 故障模式

| 故障 | 现象 | 恢复 |
|------|------|------|
| **OOM** | CUDA OutOfMemory | 减max-num-seqs、开swap/preemption、降级量化模型 |
| **CUDA Error** | CUDA kernel error | 重启服务（通常无法恢复）|
| **超时** | 生成卡住 | 客户端重试、服务端限max_tokens |
| **进程crash** | 连接拒绝 | 健康检查+自动重启 |
| **显存泄漏** | 显存缓慢增长 | 重启（定期或触发式）|

## 重试策略

### Exponential Backoff + Jitter

```python
import time, random

def retry_with_backoff(max_retries=3, base_delay=1):
    for attempt in range(max_retries + 1):
        try:
            return do_request()
        except RetryableError:
            if attempt < max_retries:
                delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), 30)
                time.sleep(delay)
            else:
                raise
```

### 什么该重试
- HTTP 429 (Rate Limit) → 读 Retry-After header
- HTTP 5xx (Server Error)
- 连接超时/拒绝
- CUDA OOM（减少输入重试）

### 什么不该重试
- HTTP 4xx (除了429) → 客户端错误，重试也没用
- Prompt Injection → 拒绝

## Circuit Breaker（熔断器）

```
状态机:
  Closed ──(失败>阈值)──→ Open ──(冷却时间到)──→ Half-Open
    ↑                                               ↓
    └────────(成功)──────────←────(成功)─────────────┘
                                    ↓
                                (失败)→ Open

配置:
  failure_threshold: 5      # 5次失败触发熔断
  timeout: 30s              # 30秒冷却后尝试half-open
  half_open_requests: 2     # half-open时放行2个请求探测
```

## 健康检查

```bash
# Liveness Probe: 进程是否活着
curl --noproxy '*' http://localhost:8001/health
# 返回 200 → 活着

# Readiness Probe: 是否可以接流量
curl --noproxy '*' http://localhost:8001/v1/models
# 返回模型列表 → 模型加载好了

# 启动时: Readiness 未就绪 → 不分配流量
# 运行时: Liveness 失败 → 重启
```

## 健康监控脚本要点

```bash
# 核心逻辑
check_and_restart() {
    if ! curl -sf --noproxy '*' "http://localhost:$PORT/health" > /dev/null; then
        echo "Health check failed, restarting..."
        kill $PID 2>/dev/null
        start_vllm
    fi
}

# 重启窗口限制 (防止无限重启)
MAX_RESTARTS=3
RESTART_WINDOW=300  # 5分钟

if [ $restart_count -gt $MAX_RESTARTS ]; then
    echo "CRITICAL: Too many restarts!"
    # 触发告警
fi
```

## 优雅降级

```
降级策略:
  72B模型 OOM → 自动切到量化版 (INT4, ~36GB)
  量化版也 OOM → 切到 7B 模型
  都不行 → 返回友好错误"服务繁忙，请稍后重试"

实现:
  - 多模型注册表
  - 请求失败时自动 fallback
  - 降级事件记录到日志 + 告警
```

## 故障演练清单

```bash
# 1. 模拟 OOM
# 发送超大 batch + max_tokens 请求

# 2. 模拟进程 crash
kill -9 $(pgrep -f vllm.entrypoints)
# 观察健康检查是否重启

# 3. 模拟网络超时
# iptables 临时阻断，验证客户端重试

# 4. 模拟磁盘满
# 填满磁盘，观察日志和模型加载行为
```
