# 容器化部署

## 一句话总结
Docker + nvidia-container-runtime 实现 GPU 容器化。容器内不需要装驱动，只需 CUDA 库。本机已有 Docker vLLM 实例（vllm/vllm-omni:v0.22.0）。

## Docker GPU 原理

```
容器内:
  ls /dev/nvidia*          → 来自宿主机透传
  nvidia-smi               → 容器可见宿主机GPU (需要--gpus all)
  /usr/local/cuda/lib64/   → 容器自己装的 CUDA 库

宿主机:
  nvidia-container-runtime → Docker 的 GPU 运行时
  驱动 + 内核模块           → 不在容器内，透传即可
```

## vLLM Dockerfile

```dockerfile
FROM nvidia/cuda:12.4.0-runtime-ubuntu22.04

ENV PYTHONUNBUFFERED=1
RUN apt-get update && apt-get install -y python3.10 python3-pip \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

RUN pip3 install --no-cache-dir torch==2.5.1 vllm

COPY entrypoint.sh /app/entrypoint.sh
RUN chmod +x /app/entrypoint.sh

HEALTHCHECK --interval=30s --timeout=10s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

EXPOSE 8000
ENTRYPOINT ["/app/entrypoint.sh"]
```

## Docker Compose

```yaml
services:
  vllm-7b:
    build: .
    ports: ["8000:8000"]
    volumes:
      - /data/models:/models:ro
    environment:
      - MODEL_PATH=/models/Qwen2.5-7B-Instruct
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              device_ids: ['0']
              capabilities: [gpu]
    restart: unless-stopped
```

## 关键命令

```bash
# 构建
docker build -t my-vllm -f Dockerfile .

# 运行
docker run --gpus '"device=0"' \
    -v /data/models:/models:ro \
    -p 8000:8000 \
    my-vllm

# 查看日志
docker logs -f vllm-7b

# 进入容器
docker exec -it vllm-7b bash

# docker-compose
docker-compose -f configs/docker-compose.yml up -d
docker-compose ps
docker-compose logs -f vllm-7b
docker-compose down
```

## 本机 Docker vLLM 实例

| 容器名 | 镜像 | 端口 | 功能 |
|--------|------|------|------|
| unlimited-ocr | vllm/vllm-omni:v0.22.0 | 8092 | OCR |
| qwen3-tts | vllm/vllm-omni:v0.22.0 | 8091 | TTS |

```bash
# 查看容器的 vLLM 命令
docker inspect unlimited-ocr | jq '.[0].Args'
# 或
docker logs unlimited-ocr 2>&1 | head -10
```

## Docker Hub 镜像

```bash
docker pull vllm/vllm-openai:latest
# https://hub.docker.com/r/vllm/vllm-openai

docker pull vllm/vllm-omni:v0.22.0
# https://hub.docker.com/r/vllm/vllm-omni
# 本机已拉取: d63693f510d6, 26.1GB

docker pull nvidia/cuda:12.4.0-runtime-ubuntu22.04
# https://hub.docker.com/r/nvidia/cuda
```
