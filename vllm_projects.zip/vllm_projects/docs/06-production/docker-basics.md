# Docker 基础

## 一句话总结
Docker 把应用和它的所有依赖打包成一个镜像（Image），运行时变成容器（Container）。镜像像"安装包"，容器像"运行中的程序"。GPU 容器通过 nvidia-container-runtime 把宿主机 GPU 透传进去。

## 核心概念

### 三个核心对象

```
┌──────────────┐    docker build    ┌──────────────┐    docker run     ┌──────────────┐
│  Dockerfile   │  ───────────────→ │    Image      │  ───────────────→ │  Container    │
│  (配方/图纸)   │                   │   (安装包)    │                    │  (运行实例)    │
└──────────────┘                    └──────────────┘                    └──────────────┘
      ↑                                                                    │
      │                        docker commit                              │
      └────────────────────────────────────────────────────────────────────┘

Image (镜像):
  - 只读模板, 分层存储
  - 类似虚拟机的快照/ISO
  - 存在本地: docker images 查看

Container (容器):
  - 镜像的运行实例
  - 在镜像层之上加一个可写层
  - 容器删除 → 可写层丢失 (所以数据要挂 Volume)
  
Dockerfile (构建文件):
  - 描述如何构建镜像
  - 每条指令生成一层 (layer)
```

### 分层存储

```
Dockerfile 的每一行 → 一个新的 layer:

FROM ubuntu:22.04              ← Layer 1: 基础系统 (只读)
RUN apt-get install python3     ← Layer 2: 安装 Python (只读)
COPY app.py /app/               ← Layer 3: 复制代码 (只读)
CMD ["python3", "/app/app.py"]  ← 元数据, 不产生 layer

容器运行时:
  Layer 1 + Layer 2 + Layer 3 + 可写层 (容器独有)

好处:
  - 多个镜像共享相同 layer (节省磁盘)
  - 改一行只需重建该层及之后的层 (缓存加速)
  - 可写层只是 overlay → 容器秒启动
```

## 常用命令

### 镜像操作

```bash
# 搜索/下载镜像
docker search ubuntu                         # 搜索
docker pull ubuntu:22.04                     # 下载 (不写 tag 默认 latest)
docker pull nvidia/cuda:12.4.0-runtime-ubuntu22.04

# 查看本地镜像
docker images                                # 所有镜像
docker images | grep vllm                    # 过滤
docker image inspect ubuntu:22.04            # 详细信息

# 删除
docker rmi ubuntu:22.04                      # 删除镜像
docker image prune                           # 删除未使用的镜像

# 构建
docker build -t my-app:v1 .                  # 用当前目录的 Dockerfile 构建
docker build -t my-app:v1 -f Dockerfile.gpu . # 指定 Dockerfile
docker build --no-cache -t my-app:v1 .       # 不使用缓存
```

### 容器操作

```bash
# 运行
docker run ubuntu:22.04 echo "hello"        # 运行后立即退出
docker run -it ubuntu:22.04 bash            # 交互式进入
docker run -d --name my-nginx nginx          # 后台运行 (-d = detach)
docker run -d --restart=unless-stopped nginx # 自动重启

# 常用 run 参数
docker run \
    --name my-container \                   # 命名
    -d \                                    # 后台
    -p 8080:80 \                            # 端口映射 (宿主机:容器)
    -v /host/path:/container/path \         # 挂载目录 (宿主机:容器)
    -v /host/path:/container/path:ro \      # 只读挂载
    -e ENV_VAR=value \                      # 环境变量
    --gpus all \                            # 使用所有 GPU
    --gpus '"device=0,1"' \                # 使用指定 GPU
    --restart=unless-stopped \              # 重启策略
    --network my-net \                      # 指定网络
    my-image:tag

# 查看
docker ps                                   # 运行中的容器
docker ps -a                                # 所有容器 (包括已停止)
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
docker logs my-container                    # 查看日志
docker logs -f my-container                 # 实时跟踪日志
docker logs --tail=100 my-container         # 最后 100 行

# 进入容器
docker exec -it my-container bash           # 进入运行中的容器
docker exec my-container cat /app/config.py # 执行单条命令

# 停止/删除
docker stop my-container                    # 停止
docker start my-container                   # 重新启动
docker restart my-container                 # 重启
docker rm my-container                      # 删除 (必须先 stop)
docker rm -f my-container                   # 强制删除
docker container prune                      # 删除所有已停止的容器
```

### GPU 容器

```bash
# GPU 容器的特殊之处: --gpus 参数

# 使用所有 GPU
docker run --gpus all nvidia/cuda:12.4.0-runtime-ubuntu22.04 nvidia-smi

# 使用指定 GPU
docker run --gpus '"device=0,1"' vllm/vllm-openai ...

# 容器内:
#   ls /dev/nvidia*           # 宿主机透传的 GPU 设备
#   nvidia-smi                 # 可以看到 GPU (信息来自宿主机 Driver)
#   /usr/local/cuda/           # 容器自己装的 CUDA 库
#   不需要装 GPU 驱动!          # Driver 在宿主机, 透传进来
```

## Dockerfile 指令

### 完整示例

```dockerfile
# === 基础镜像 ===
FROM nvidia/cuda:12.4.0-runtime-ubuntu22.04
# FROM 必须是第一条指令
# 选择: nvidia/cuda (有 CUDA), ubuntu (纯系统), python:3.10-slim (有 Python)
# tag 含义: 12.4.0 = CUDA 版本, runtime = 只有运行时库(不含编译工具)
#           ubuntu22.04 = 操作系统版本
# 其他选择: devel (含编译工具, 更大), base (中等)

# === 元信息 ===
LABEL maintainer="your@email.com"
LABEL version="1.0"
LABEL description="vLLM inference server"

# === 环境变量 ===
ENV PYTHONUNBUFFERED=1 \
    DEBIAN_FRONTEND=noninteractive \
    CUDA_HOME=/usr/local/cuda
# PYTHONUNBUFFERED=1: Python 输出不缓冲 (对日志友好)
# DEBIAN_FRONTEND=noninteractive: apt 安装时不弹交互提示

# === 工作目录 ===
WORKDIR /app
# 如果 /app 不存在 → 自动创建
# 后续的 RUN/CMD/COPY 都相对于这个目录

# === 安装系统依赖 ===
RUN apt-get update && \
    apt-get install -y --no-install-recommends \
        python3.10 \
        python3-pip \
        git \
        curl \
        wget && \
    rm -rf /var/lib/apt/lists/*
# 最佳实践:
#   1. update 和 install 放同一个 RUN → 减少层
#   2. --no-install-recommends → 不装推荐包 (减小镜像)
#   3. rm -rf /var/lib/apt/lists/* → 清理 apt 缓存
#   4. 用 && 连接 → 任一命令失败则整个 RUN 失败

# === 安装 Python 依赖 ===
# 先 COPY requirements.txt → 利用 Docker 缓存
COPY requirements.txt /app/
RUN pip3 install --no-cache-dir -r requirements.txt
# --no-cache-dir: 不缓存 pip 包 → 减小镜像

# === 复制代码 ===
COPY . /app/
# COPY vs ADD:
#   COPY: 简单复制文件/目录 (推荐)
#   ADD: 额外支持 URL 下载和 tar 自动解压 (少用)

# === 暴露端口 ===
EXPOSE 8000
# 这是文档性质的, 不会真正 publish 端口
# 需要 docker run -p 8000:8000 才真正映射

# === 健康检查 ===
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1
# --interval: 检查间隔
# --timeout: 单次检查超时
# --retries: 连续失败 N 次 → unhealthy

# === 启动命令 ===
ENTRYPOINT ["python3", "-m", "vllm.entrypoints.openai.api_server"]
CMD ["--host", "0.0.0.0", "--port", "8000"]
# ENTRYPOINT: 容器的 "主程序"
# CMD: 默认参数
# 完整命令 = ENTRYPOINT + CMD
# 最终执行: python3 -m vllm.entrypoints.openai.api_server --host 0.0.0.0 --port 8000

# ENTRYPOINT vs CMD vs RUN:
#   RUN:       构建时执行 (装软件)
#   CMD:       运行时默认命令 (可被 docker run 后面的参数覆盖)
#   ENTRYPOINT: 运行时主程序 (不会被覆盖, 除非 --entrypoint)
```

### Shell 形式 vs Exec 形式

```dockerfile
# Exec 形式 (推荐)
CMD ["python3", "app.py"]
ENTRYPOINT ["python3", "app.py"]
RUN ["pip3", "install", "torch"]
# → 直接执行二进制, 不启动 shell
# → 信号处理正确 (Ctrl+C 能传到程序)

# Shell 形式
CMD python3 app.py
RUN pip3 install torch
# → 实际是 /bin/sh -c "pip3 install torch"
# → 多一层 shell 进程
# → 信号处理可能有问题
```

## Docker Compose

### 为什么需要

```
单容器: docker run --gpus all -p 8000:8000 -v /data/models:/models ...
  → 参数太多, 容易忘

多容器: vLLM + Nginx + Prometheus + Grafana
  → 每个都要手动 docker run
  → 还要管理网络 (它们之间怎么通信?)
  → 启动顺序 (等 vLLM 启动了再启 Nginx?)

Docker Compose 解决:
  → 一个 YAML 描述所有服务
  → docker-compose up 一键全部启动
  → 自动创建网络, 服务间用服务名通信
```

### 完整 YAML 解析

```yaml
version: '3.8'                    # Compose 文件格式版本

services:                          # 定义所有服务
  vllm-7b:                        # 服务名 (也是容器名和 DNS 名)
    build:                         # 从哪里构建
      context: ..                  #   Dockerfile 所在目录
      dockerfile: Dockerfile       #   Dockerfile 文件名
    # 或者直接用镜像:
    # image: vllm/vllm-openai:latest
    
    container_name: vllm-7b-prod  # 固定容器名
    ports:                         # 端口映射
      - "8000:8000"               #   宿主机:容器
    volumes:                       # 卷挂载
      - /data/models:/models:ro   #   宿主机路径:容器路径:只读
    
    environment:                   # 环境变量
      - MODEL_PATH=/models/Qwen2.5-7B-Instruct
      - TENSOR_PARALLEL_SIZE=1
    
    # GPU 分配
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              device_ids: ['0']    # 只给 GPU 0
              capabilities: [gpu]
    
    restart: unless-stopped       # 重启策略
    
    networks:
      - llm_net                   # 加入哪个网络
  
  nginx:
    image: nginx:alpine
    ports:
      - "8080:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
    depends_on:                   # 依赖关系
      - vllm-7b                  #   nginx 等 vllm-7b 启动后再启
    networks:
      - llm_net

networks:                          # 网络定义
  llm_net:
    driver: bridge                # bridge = 单机网络

# volumes:                         # 命名卷 (持久化)
#   model_data:
#     driver: local
```

### Compose 命令

```bash
docker-compose up -d              # 启动所有服务 (后台)
docker-compose up -d vllm-7b     # 只启动指定服务
docker-compose down               # 停止并删除所有
docker-compose down -v            # 同时删除 volumes
docker-compose ps                 # 查看状态
docker-compose logs -f vllm-7b   # 看日志
docker-compose restart vllm-7b   # 重启
docker-compose exec vllm-7b bash # 进入容器
docker-compose build              # 重新构建镜像
docker-compose pull               # 拉取最新镜像
```

## 网络

### 网络模式

```bash
# bridge (默认): 容器在隔离网络中, 通过宿主机端口映射访问
docker run -p 8000:8000 my-app

# host: 容器直接使用宿主机网络 (端口不隔离)
docker run --network host my-app
# 容器内 localhost:8000 = 宿主机 localhost:8000
# 本机很多容器用这个模式!

# none: 无网络

# 自定义网络: 容器间用服务名互相访问
docker network create my-net
docker run --network my-net --name app1 ...
docker run --network my-net --name app2 ...
# app2 可以 ping app1
```

### 本机网络实例

```bash
# 本机很多容器用 host 网络:
docker ps --format "{{.Names}}\t{{.Ports}}" | head -10
# 看到端口如 0.0.0.0:8092->8092/tcp 就是 bridge 模式
# 看到空 Ports 但有服务在跑 → 可能是 host 网络
```

## 存储

### 三种挂载方式

```bash
# 1. Bind Mount: 宿主机路径 → 容器路径
docker run -v /data/models:/models:ro ...
# /data/models 是宿主机实际路径
# 适合: 模型文件、配置文件

# 2. Volume: Docker 管理的卷
docker volume create model_data
docker run -v model_data:/models ...
# 数据存在 /var/lib/docker/volumes/
# 适合: 数据库、持久化数据

# 3. tmpfs: 内存临时文件系统
docker run --tmpfs /tmp ...
# 纯内存, 容器停止就没了
```

## 常用调试命令

```bash
# 信息
docker info                       # Docker 系统信息
docker version                    # 版本
docker system df                  # 磁盘占用

# 检查容器
docker inspect my-container       # 完整 JSON (所有配置)
docker inspect -f '{{.State.Status}}' my-container  # 提取字段
docker top my-container           # 容器内进程
docker stats                      # 实时资源使用

# 日志
docker logs --tail=50 -f my-container

# 清理
docker system prune               # 清理所有未使用资源
docker system prune -a            # 包括未使用的镜像
docker builder prune              # 清理构建缓存

# 导出/导入
docker save -o image.tar my-image:tag           # 导出镜像
docker load -i image.tar                        # 导入镜像
docker export -o container.tar my-container      # 导出容器文件系统
```

## 本机 Docker 环境

```bash
# 查看本机 Docker 生态
docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}"
docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}"
docker network ls

# 本机值得学习的容器:
# vllm/vllm-omni:v0.22.0         ← vLLM 多模态 (OCR+TTS)
# nvidia/dcgm-exporter            ← GPU 监控
# langgenius/dify-*               ← Dify LLM 应用平台
# semitechnologies/weaviate       ← 向量数据库
```

## 常见问题

### 权限问题

```bash
# 容器内默认是 root → 生成的文件宿主机看不了
# 原因: UID 不匹配

# 解决:
docker run -u $(id -u):$(id -g) ...     # 用当前用户 ID
# 或 Dockerfile 中:
RUN useradd -m -u 1000 appuser
USER appuser
```

### 磁盘空间不足

```bash
# Docker 容易吃满磁盘
docker system df                     # 看占用
docker system prune -a               # 清理
docker builder prune --all           # 清理构建缓存

# 常见罪魁:
# - 大量旧镜像 (docker images 看看)
# - 构建缓存 (每次 docker build 产生中间层)
# - 停止的容器 (docker ps -a)
```

### 容器退出

```bash
# 查看退出原因
docker inspect my-container | grep -A5 State

# 常见退出码:
# 0: 正常退出
# 1: 应用错误
# 137: 被 OOM Killer 杀了 (内存不足)
# 143: 收到 SIGTERM (正常停止)
```
