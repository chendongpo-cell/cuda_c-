# 监控与可观测性

## 一句话总结
推理服务监控三件套：Prometheus（采集）+ Grafana（可视化）+ DCGM Exporter（GPU 指标）。核心指标：TTFT/TPOT/Throughput + GPU 显存/利用率/温度。

## 指标金字塔

```
L1: 业务指标 (最关键)
  QPS, 错误率, 平均/分位数延迟, 用户数

L2: 服务指标
  vLLM: num_requests_running/waiting/swapped
  TTFT/TPOT histogram, cache usage %

L3: 硬件指标
  GPU 利用率, 显存使用, 温度, 功耗
  CPU 内存, 磁盘 IO, 网络吞吐
```

## vLLM 暴露的 Metrics

```
访问: GET /metrics (Prometheus 格式)

关键指标:
vllm:num_requests_running          # 正在处理的请求
vllm:num_requests_waiting          # 排队等待
vllm:num_requests_swapped          # 被swap出去的
vllm:gpu_cache_usage_perc          # GPU KV Cache 使用率%
vllm:cpu_cache_usage_perc          # CPU KV Cache 使用率%
vllm:time_to_first_token_seconds   # TTFT 直方图 (_sum/_count/_bucket)
vllm:time_per_output_token_seconds # TPOT 直方图
vllm:request_success_total         # 成功请求计数
vllm:prompt_tokens_total           # prompt token 计数
vllm:generation_tokens_total       # 生成 token 计数
```

## Prometheus 配置

```yaml
# configs/prometheus.yml
global:
  scrape_interval: 10s

scrape_configs:
  - job_name: 'vllm'
    static_configs:
      - targets: ['localhost:8001', 'localhost:8002']
    metrics_path: '/metrics'
    scrape_interval: 5s
```

## Grafana 面板设计

```json
Panels:
1. QPS (rate of requests)         → Stat
2. TTFT P50/P95/P99 (ms)          → Time Series
3. TPOT P50/P95                   → Time Series
4. GPU Memory Used (%)            → Gauge (per GPU)
5. vLLM Running/Waiting/Swapped   → Time Series
6. GPU Utilization (%)            → Gauge
7. Error Rate (%)                 → Stat
```

## DCGM Exporter (NVIDIA GPU 监控)

本机已运行：
```bash
docker ps | grep dcgm
# nvidia/dcgm-exporter:4.1.1-4.0.4-ubuntu22.04 on port 9400

curl localhost:9400/metrics | head -20
# DCGM_FI_DEV_GPU_UTIL, DCGM_FI_DEV_MEM_COPY_UTIL, ...
```

## 告警规则

```yaml
# Prometheus AlertManager 规则
- alert: HighGPUUsage
  expr: vllm:gpu_cache_usage_perc > 90
  for: 5m
  annotations:
    summary: "GPU KV Cache > 90%"

- alert: HighLatency
  expr: histogram_quantile(0.95, vllm:time_to_first_token_seconds_bucket) > 1
  for: 5m
  annotations:
    summary: "P95 TTFT > 1s"

- alert: ServiceDown
  expr: up{job="vllm"} == 0
  for: 1m
  annotations:
    summary: "vLLM service is down"
```

## 本机监控基础设施

| 组件 | 端口 | 状态 |
|------|------|------|
| DCGM Exporter | 9400 | ✅ 运行中 |
| Prometheus | 需部署或已有内部实例 | ⚠️ |
| Grafana | 需部署或已有内部实例 | ⚠️ |
| vLLM /metrics | 8001/metrics | ✅ |

## 查看当前指标

```bash
unset http_proxy https_proxy
curl -s --noproxy '*' http://localhost:8001/metrics | grep -E "^vllm:" | head -20
```
