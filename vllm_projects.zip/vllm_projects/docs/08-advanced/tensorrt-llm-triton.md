# TensorRT-LLM + Triton Inference Server

## 一句话总结
TensorRT-LLM 是 NVIDIA 官方推理框架，通过编译优化（graph capture、kernel fusion、precision calibration）把 HuggingFace 模型转成极致优化的 TensorRT Engine。Triton Server 是统一推理服务平台，支持多框架多模型。搭配使用是 NVIDIA GPU 上推理性能的天花板。

## vLLM vs TensorRT-LLM 对比

| 维度 | vLLM | TensorRT-LLM |
|------|------|-------------|
| **开发者** | UC Berkeley 社区 | NVIDIA 官方 |
| **优化方式** | PagedAttention + 运行时调度 | 编译时优化 + 运行时调度 |
| **模型加载** | 直接加载 HF 模型 | 需要先编译成 TRT Engine |
| **首次启动** | 秒级 | 分钟级 (需要编译) |
| **推理速度** | 快 (比 HF 快 24×) | **极快** (比 vLLM 再快 30-50%) |
| **显存效率** | 好 (PagedAttention) | 更好 (编译时确定内存布局) |
| **灵活性** | 高，支持大量模型 | 中，需要模型支持 |
| **调试难度** | 低 | 高 |
| **生产成熟度** | 高 | 最高 (NVIDIA 企业支持) |
| **适用** | 通用推理 | 追求极致性能 + NVIDIA 生态 |

## TensorRT 编译原理

### 三阶段编译

```
HuggingFace 模型
      ↓
Phase 1: Graph Capture (图捕获)
  用 torch.fx / dynamo 追踪模型的计算图
  得到完整的计算图 (IR graph)
      ↓
Phase 2: Graph Optimization (图优化)
  - Layer Fusion: 把多个连续操作合并
    例: LayerNorm + MatMul + Bias + GELU → 一个 kernel
  - Constant Folding: 预计算常量
  - Dead Code Elimination: 去掉无用计算
  - Precision Calibration: 找到最佳量化精度
      ↓
Phase 3: Code Generation (代码生成)
  为每个 fused operation 生成最优 CUDA kernel
  使用 CUDAGraph 把整个 forward 捕获成图
  → TensorRT Engine (序列化文件, 约等于模型大小)
      ↓
推理时: 加载 Engine → 输入 → 执行 → 输出
```

### 关键优化技术

```
1. Kernel Fusion (算子融合):
   原始:   [LayerNorm] → [MatMul Q] → [MatMul K] → [MatMul V]
   融合后: [LayerNorm + 3×MatMul]              ← 一个 kernel 搞定
   收益: 减少 3 次 HBM 读写

2. Kernel Auto-Tuning:
   TensorRT 会尝试多种 kernel 实现, 选最快的
   例: GEMM 有 10+ 种实现 (不同 tile size, 不同 precision)
   → 自动 benchmark → 选最优

3. Multi-Stream Execution:
   把无依赖的操作放到不同 Stream 上并行执行
   Decode 的 QKV 三个投影可以并行

4. Precision Calibration:
   自动测试 INT8/FP8 量化的精度损失
   选精度损失 < 0.5% 的最高性能配置

5. Weight Pre-Packing:
   权重在编译时重排内存布局
   推理时直接加载, 不用运行时转换
```

## 实战：编译 Qwen 模型

### 安装

```bash
# 1. 安装 TensorRT-LLM
pip install tensorrt_llm

# 2. 确认 CUDA 版本兼容
# TRT-LLM 需要 CUDA 12.x + Driver 525+
nvidia-smi | grep "CUDA Version"
# 本机: CUDA 12.2 → 兼容

# 3. 安装 Triton Server (可选，用于服务化部署)
# 用 Docker 最简单:
docker pull nvcr.io/nvidia/tritonserver:24.01-trtllm-python-py3
```

### 编译 Qwen2.5-7B

```bash
# Step 1: 下载 HF 模型 (如果还没有)
MODEL_PATH=/data/models/Qwen2.5-7B-Instruct
ENGINE_PATH=/data/models/Qwen2.5-7B-TRT

# Step 2: 编译成 TensorRT Engine
# FP16 精度 (推荐，最快)
python3 tensorrt_llm/commands/build.py \
    --model_dir $MODEL_PATH \
    --output_dir $ENGINE_PATH \
    --dtype float16 \
    --max_input_len 32768 \
    --max_output_len 4096 \
    --max_batch_size 64 \
    --use_gpt_attention_plugin float16 \
    --use_gemm_plugin float16 \
    --use_rmsnorm_plugin float16 \
    --paged_kv_cache enable \
    --remove_input_padding enable \
    --gather_generation_logits enable

# 参数说明:
# --use_gpt_attention_plugin: 用 TRT 的优化 Attention kernel
# --use_gemm_plugin: 用 TRT 的优化 GEMM kernel
# --paged_kv_cache: 开 KV Cache 分页 (类似 vLLM PagedAttention)
# --remove_input_padding: 去掉 batch padding → 省显存
# --gather_generation_logits: 只在最后一步取 logits

# Step 3: 编译 INT8 量化版 (显存减半, 速度更快)
python3 tensorrt_llm/commands/build.py \
    --model_dir $MODEL_PATH \
    --output_dir ${ENGINE_PATH}_int8 \
    --dtype float16 \
    --use_weight_only \
    --weight_only_precision int8 \
    --max_input_len 32768 \
    --max_output_len 4096 \
    --max_batch_size 64 \
    --use_gpt_attention_plugin float16 \
    --use_gemm_plugin float16 \
    --paged_kv_cache enable \
    --remove_input_padding enable

# 编译时间: 7B 约 5-10 分钟, 72B 约 30-60 分钟
```

### 用 TRT-LLM Python API 推理

```python
from tensorrt_llm import LLM, SamplingParams

# 加载编译好的 Engine
llm = LLM(
    model="/data/models/Qwen2.5-7B-TRT",
    tensor_parallel_size=1,
    dtype="float16",
)

# 推理
prompts = [
    "解释一下 Transformer 的注意力机制",
    "用 Python 写快速排序",
]

sampling_params = SamplingParams(
    temperature=0.7,
    top_p=0.9,
    max_tokens=200,
)

outputs = llm.generate(prompts, sampling_params)
for output in outputs:
    print(output.outputs[0].text)
```

## Triton Inference Server

### 架构

```
               ┌──────────────────────┐
               │   Triton Server       │
               │                      │
HTTP/gRPC ←── │  ┌────────────────┐  │
请求           │  │  Model Manager  │  │ ← 管理所有模型实例
               │  └───────┬────────┘  │
               │          ↓           │
               │  ┌────────────────┐  │
               │  │  Backend 层     │  │
               │  │  TRT | ONNX |  │  │
               │  │  PyTorch | TF  │  │ ← 支持多种模型格式
               │  │  Python | ...  │  │
               │  └───────┬────────┘  │
               │          ↓           │
               │  ┌────────────────┐  │
               │  │  GPU 0,1,2,... │  │
               │  └────────────────┘  │
               └──────────────────────┘

特性:
  - 同时加载多个模型 (Qwen + Embedding + Reranker)
  - 动态 batching: 自动合并请求
  - 模型版本管理: 热切换, A/B 测试
  - 支持 Python Backend (可以跑 vLLM!)
  - gRPC + HTTP 双协议
```

### Triton 部署配置

```bash
# 模型仓库目录结构
model_repository/
├── qwen7b/
│   ├── config.pbtxt          # 模型配置
│   └── 1/                    # 版本 1
│       └── model.plan        # TensorRT Engine 文件
├── embedding/
│   ├── config.pbtxt
│   └── 1/
│       └── model.onnx
└── reranker/
    ├── config.pbtxt
    └── 1/
        └── model.py           # Python Backend
```

```protobuf
# qwen7b/config.pbtxt
name: "qwen7b"
backend: "tensorrt_llm"
max_batch_size: 64

input [
  {
    name: "input_ids"
    data_type: TYPE_INT32
    dims: [-1]
  },
  {
    name: "input_lengths"
    data_type: TYPE_INT32
    dims: [1]
  },
  {
    name: "request_output_len"
    data_type: TYPE_INT32
    dims: [1]
  }
]

output [
  {
    name: "output_ids"
    data_type: TYPE_INT32
    dims: [-1, -1]
  }
]

instance_group [
  {
    count: 2                    # 2 个实例 (提高并发)
    kind: KIND_GPU
    gpus: [0, 1]               # 在 GPU 0 和 1 上各一个
  }
]

dynamic_batching {
  max_queue_delay_microseconds: 100  # 最多等 100μs 再组 batch
}

parameters {
  key: "gpt_model_path"
  value: { string_value: "/data/models/Qwen2.5-7B-TRT" }
}

parameters {
  key: "gpt_model_type"
  value: { string_value: "inflight_batching" }   # 类似 Continuous Batching
}
```

### 启动 Triton

```bash
# Docker 方式 (推荐)
docker run --gpus all --rm \
    -v /data/model_repository:/models \
    -v /data/models/Qwen2.5-7B-TRT:/engines/qwen7b \
    -p 8000:8000 -p 8001:8001 -p 8002:8002 \
    nvcr.io/nvidia/tritonserver:24.01-trtllm-python-py3 \
    tritonserver --model-repository=/models

# 端口:
# 8000: HTTP
# 8001: gRPC
# 8002: Metrics (Prometheus)

# 验证
curl http://localhost:8000/v2/health/ready
curl http://localhost:8000/v2/models
```

### Triton 客户端调用

```python
# gRPC 客户端 (比 HTTP 快)
import tritonclient.grpc as grpcclient

client = grpcclient.InferenceServerClient("localhost:8001")

# 准备输入
import numpy as np
input_ids = np.array([[1, 2, 3, 4, 5]], dtype=np.int32)  # tokenized prompt
input_len = np.array([[5]], dtype=np.int32)
output_len = np.array([[100]], dtype=np.int32)

# 调用
response = client.infer(
    model_name="qwen7b",
    inputs=[
        grpcclient.InferInput("input_ids", input_ids.shape, "INT32"),
        grpcclient.InferInput("input_lengths", input_len.shape, "INT32"),
        grpcclient.InferInput("request_output_len", output_len.shape, "INT32"),
    ]
)

# 获取输出
output_ids = response.as_numpy("output_ids")
```

## 性能对比（实测参考）

```
测试条件: A800, Qwen2.5-7B, 128 token output, 并发 8

                    吞吐 (tok/s)   TTFT P50   TPOT P50   显存
─────────────────────────────────────────────────────────────
HF Transformers       50             800ms      200ms      14GB
vLLM (FP16)          2400            150ms       20ms      16GB
vLLM (AWQ INT4)      3200            140ms       15ms       5GB
TRT-LLM (FP16)       3500            100ms       12ms      15GB
TRT-LLM (INT8)       5000             90ms        8ms       8GB
TRT-LLM (FP8, H100)  7000             60ms        5ms       8GB

结论:
  vLLM 是开箱即用的最优选择 (不需要编译)
  TRT-LLM 追求极致性能需要额外编译步骤
  量化 + TRT-LLM = 最佳性价比
```

## 决策：什么时候用 TRT-LLM

```
用 vLLM 就够:
  - 模型已经跑得不错 (TTFT/TPOT 满足需求)
  - 频繁更换模型 (编译成本太高)
  - 需要快速迭代

值得用 TRT-LLM:
  - 模型固定不变 (生产环境长期部署)
  - 延迟极度敏感 (如实时对话, TTFT < 100ms)
  - 高并发 (节省的 GPU 数量 > 编译成本)
  - NVIDIA 企业支持 (买 DGX 的一般都用这个)
```

## 安装命令

```bash
# TensorRT-LLM
pip install tensorrt_llm
# 需要 CUDA 12.x + cuDNN 9.x
# https://github.com/NVIDIA/TensorRT-LLM

# Triton Server Docker
docker pull nvcr.io/nvidia/tritonserver:24.01-trtllm-python-py3
# 文档: https://github.com/triton-inference-server/server
# NGC: https://catalog.ngc.nvidia.com/containers
```
