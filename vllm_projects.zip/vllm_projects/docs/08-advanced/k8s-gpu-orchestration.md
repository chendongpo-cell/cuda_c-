# K8s GPU 编排与自动扩缩容

## 一句话总结
在大规模生产环境中，vLLM 实例跑在 K8s Pod 里，由 GPU Operator 管理 GPU 资源，HPA/KEDA 根据 QPS 或 GPU 利用率自动扩缩实例数。Ray 负责跨节点调度（多节点推理时用）。

## 为什么需要 K8s

```
单机时代 (你现在的位置):
  SSH 到 GPU 机器 → 手动启动 vLLM → screen/tmux 后台运行
  问题:
    - 进程挂了没人知道
    - GPU 0 满了, GPU 1 空闲, 但手动调度麻烦
    - 升级模型 = 手动停 → 手动启 → 用户断连

K8s 时代 (生产环境):
  提交 YAML → K8s 自动找有 GPU 的机器 → 启动 Pod → 健康检查
  Pod 挂了 → 自动重启
  QPS 高了 → 自动多起几个 Pod
  GPU 1 空闲 → 新 Pod 自动调度到 GPU 1
  升级模型 → 滚动更新, 用户无感知
```

## 核心概念速查

```
Node:    一台物理机/虚拟机 (你的 GPU 服务器)
Pod:     最小调度单位 (一个或多个容器)
         一个 vLLM Pod = 1 个 vLLM 容器
Deployment: 管理 Pod 的副本数 (我要 3 个 vLLM Pod)
Service: 为 Pod 提供稳定 IP 和负载均衡
Ingress: 外部流量入口 (类比 Nginx)
ConfigMap: 配置文件 (模型路径、端口等)
Secret: 敏感信息 (API Key)

GPU 相关:
  nvidia.com/gpu: K8s 中 GPU 的资源名
  GPU Operator: 自动安装 GPU 驱动 + device plugin
  MIG: 把一张 GPU 切成多个小块, 给不同 Pod 用
```

## Step-by-Step: K8s 上部署 vLLM

### 1. 创建 Namespace

```yaml
# 00-namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: llm-inference
```

### 2. 模型存储 (PVC)

```yaml
# 01-storage.yaml
# 用 PV/PVC 挂载模型文件
apiVersion: v1
kind: PersistentVolume
metadata:
  name: models-pv
spec:
  capacity:
    storage: 500Gi
  accessModes:
    - ReadOnlyMany       # 多个 Pod 同时只读挂载
  nfs:                    # 假设用 NFS 共享存储
    server: 10.0.0.10
    path: /data/models
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: models-pvc
  namespace: llm-inference
spec:
  accessModes:
    - ReadOnlyMany
  resources:
    requests:
      storage: 500Gi
```

### 3. Deployment

```yaml
# 02-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vllm-qwen7b
  namespace: llm-inference
spec:
  replicas: 2                    # 2 个副本 (高可用)
  selector:
    matchLabels:
      app: vllm-qwen7b
  template:
    metadata:
      labels:
        app: vllm-qwen7b
    spec:
      containers:
      - name: vllm
        image: vllm/vllm-openai:latest
        args:
          - "--model"
          - "/models/Qwen2.5-7B-Instruct"
          - "--host"
          - "0.0.0.0"
          - "--port"
          - "8000"
          - "--max-model-len"
          - "32768"
        ports:
        - containerPort: 8000
          name: http
        env:
        - name: CUDA_VISIBLE_DEVICES
          value: "0"               # 每个 Pod 只用 1 张 GPU
        resources:
          limits:
            nvidia.com/gpu: 1       # 请求 1 张 GPU
            memory: "32Gi"
            cpu: "8"
          requests:
            nvidia.com/gpu: 1
            memory: "24Gi"
            cpu: "4"
        volumeMounts:
        - name: models
          mountPath: /models
        livenessProbe:             # 存活探针
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:            # 就绪探针
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
      volumes:
      - name: models
        persistentVolumeClaim:
          claimName: models-pvc
      nodeSelector:                 # 指定 GPU 节点
        accelerator: nvidia-a800    # 需要提前给节点打标签
```

### 4. Service

```yaml
# 03-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: vllm-qwen7b-svc
  namespace: llm-inference
spec:
  selector:
    app: vllm-qwen7b
  ports:
  - port: 8000
    targetPort: 8000
    protocol: TCP
  type: ClusterIP             # 集群内部访问
---
# 如果需要外部访问, 加 Ingress:
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: vllm-ingress
  namespace: llm-inference
spec:
  rules:
  - host: llm-api.example.com
    http:
      paths:
      - path: /v1
        pathType: Prefix
        backend:
          service:
            name: vllm-qwen7b-svc
            port:
              number: 8000
```

### 5. 部署

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-storage.yaml
kubectl apply -f 02-deployment.yaml
kubectl apply -f 03-service.yaml

# 查看状态
kubectl -n llm-inference get pods
kubectl -n llm-inference get svc
kubectl -n llm-inference logs -f deployment/vllm-qwen7b

# 测试 (从集群内)
kubectl -n llm-inference run -it --rm test --image=curlimages/curl -- \
    curl http://vllm-qwen7b-svc:8000/health
```

## GPU 调度详解

### GPU 资源类型

```yaml
# 整卡 GPU
resources:
  limits:
    nvidia.com/gpu: 1       # 一张完整 GPU

# GPU 分片 (MIG, A100/A800/H100 支持)
resources:
  limits:
    nvidia.com/mig-1g.10gb: 1  # 1/8 张 A800 (10GB)

# GPU 时间切片 (多个 Pod 共享一张 GPU, 性能差)
# 不推荐推理用, 适合交互式开发
```

### 节点标签和调度

```bash
# 给 GPU 节点打标签
kubectl label node gpu-node-01 accelerator=nvidia-a800
kubectl label node gpu-node-01 gpu-count=8
kubectl label node gpu-node-01 gpu-memory=80gb

# 然后在 Deployment 里用 nodeSelector 或 affinity:
spec:
  nodeSelector:
    accelerator: nvidia-a800
```

### GPU Operator

```bash
# NVIDIA GPU Operator: 自动管理 GPU 驱动 + device plugin + DCGM
helm repo add nvidia https://helm.ngc.nvidia.com/nvidia
helm install gpu-operator nvidia/gpu-operator \
    --set driver.enabled=false \        # 如果宿主机已装驱动
    --set toolkit.enabled=true
```

## 自动扩缩容

### HPA (水平 Pod 自动扩缩)

```yaml
# 04-hpa.yaml
# 基于 QPS 或 GPU 利用率自动增减 Pod 数
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: vllm-hpa
  namespace: llm-inference
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: vllm-qwen7b
  minReplicas: 1
  maxReplicas: 8
  metrics:
  - type: Pods
    pods:
      metric:
        name: vllm:num_requests_running     # vLLM 暴露的指标
      target:
        type: AverageValue
        averageValue: "50"                   # 每个 Pod 平均 50 并发 → 扩容
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300       # 5 分钟后再缩容 (防止抖动)
    scaleUp:
      stabilizationWindowSeconds: 60        # 1 分钟后扩容
```

### KEDA (基于事件扩缩)

```bash
# KEDA 支持更灵活的扩缩触发条件:
# - Prometheus 指标
# - 消息队列长度 (Kafka, RabbitMQ)
# - Cron 定时扩缩

helm install keda kedacore/keda --namespace keda --create-namespace
```

```yaml
# KEDA ScaledObject: 基于 Prometheus QPS 扩缩
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: vllm-keda
  namespace: llm-inference
spec:
  scaleTargetRef:
    name: vllm-qwen7b
  minReplicaCount: 1
  maxReplicaCount: 8
  triggers:
  - type: prometheus
    metadata:
      serverAddress: http://prometheus.monitoring:9090
      metricName: vllm_request_rate
      threshold: "100"             # QPS > 100 → 扩容
      query: rate(vllm:request_success_total[1m])
```

## 多节点推理 (Ray on K8s)

场景：模型太大，单机 8 卡装不下

```yaml
# Kuberay: 在 K8s 上跑 Ray 集群
apiVersion: ray.io/v1
kind: RayCluster
metadata:
  name: ray-llm
spec:
  headGroupSpec:
    rayStartParams:
      dashboard-host: '0.0.0.0'
    template:
      spec:
        containers:
        - name: ray-head
          image: rayproject/ray:latest
  workerGroupSpecs:
  - groupName: gpu-workers
    replicas: 4
    minReplicas: 4
    maxReplicas: 8
    rayStartParams: {}
    template:
      spec:
        containers:
        - name: ray-worker
          image: vllm/vllm-openai:latest
          resources:
            limits:
              nvidia.com/gpu: 8       # 每个 worker 8 张 GPU
```

## CI/CD Pipeline

### 模型更新的灰度发布

```yaml
# 金丝雀发布 (Canary Deployment)
# 90% 流量走旧版本, 10% 走新版本

# 旧版本 (stable)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vllm-stable
spec:
  replicas: 9
  template:
    metadata:
      labels:
        version: v1.0
    spec:
      containers:
      - name: vllm
        image: vllm/vllm-openai:v0.17.0

---
# 新版本 (canary)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vllm-canary
spec:
  replicas: 1
  template:
    metadata:
      labels:
        version: v2.0-canary
    spec:
      containers:
      - name: vllm
        image: vllm/vllm-openai:v0.18.0

---
# Service 同时路由到两个版本
apiVersion: v1
kind: Service
spec:
  selector:
    app: vllm    # stable 和 canary 都有这个 label
```

## 生产 K8s 配置模板

### 一个 Pod 多 GPU (TP=4)

```yaml
spec:
  containers:
  - name: vllm-72b
    resources:
      limits:
        nvidia.com/gpu: 4       # 4 张 GPU
    env:
    - name: TENSOR_PARALLEL_SIZE
      value: "4"
    args:
    - "--tensor-parallel-size"
    - "4"
    - "--model"
    - "/models/Qwen2.5-72B-Instruct"
```

### 完全生产配置

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vllm-production
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1            # 滚动更新时最多多出 1 个 Pod
      maxUnavailable: 0      # 滚动更新时不允许不可用
  template:
    spec:
      # 反亲和性: 不同 Pod 分散到不同节点 (提高可用性)
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 100
            podAffinityTerm:
              labelSelector:
                matchLabels:
                  app: vllm
              topologyKey: kubernetes.io/hostname
      
      # Pod 优雅停止 (给时间排空请求)
      terminationGracePeriodSeconds: 60
      
      containers:
      - name: vllm
        image: vllm/vllm-openai:v0.18.0
        resources:
          limits:
            nvidia.com/gpu: 1
            memory: "40Gi"
          requests:
            nvidia.com/gpu: 1
            memory: "30Gi"
        
        # 生命周期钩子
        lifecycle:
          preStop:
            exec:
              command: ["/bin/sh", "-c", "sleep 15"]  # 等流量切走
        
        # 三个探针
        startupProbe:          # 启动探针: 等模型加载完
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
          failureThreshold: 30    # 最多等 5 分钟
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          periodSeconds: 10
```

## 常用运维命令

```bash
# 查看 GPU 分配
kubectl describe nodes | grep nvidia.com/gpu

# 查看 Pod GPU 使用
kubectl -n llm-inference exec vllm-qwen7b-xxx -- nvidia-smi

# 手动扩缩
kubectl -n llm-inference scale deployment vllm-qwen7b --replicas=4

# 查看扩缩历史
kubectl -n llm-inference describe hpa vllm-hpa

# 滚动重启
kubectl -n llm-inference rollout restart deployment vllm-qwen7b

# 回滚
kubectl -n llm-inference rollout undo deployment vllm-qwen7b

# 查看日志
kubectl -n llm-inference logs -f -l app=vllm-qwen7b --tail=100

# 进入容器
kubectl -n llm-inference exec -it vllm-qwen7b-xxx -- bash
```

## K8s vs Docker Compose 选型

```
Docker Compose (当前项目):
  ✅ 简单，一个 YAML + 一条命令
  ✅ 适合单机
  ❌ 不能跨机器
  ❌ 没有自动扩缩
  ❌ 没有滚动更新
  ❌ 没有健康探针

K8s:
  ✅ 跨机器集群
  ✅ 自动扩缩 (HPA/KEDA)
  ✅ 滚动更新 + 回滚
  ✅ 健康探针 + 自动重启
  ✅ 服务发现 + 负载均衡
  ❌ 复杂度高
  ❌ YAML 地狱
  ❌ 学习曲线陡

建议:
  单机 < 4 GPU → Docker Compose
  多机 / 多服务 / 需要高可用 → K8s
```
