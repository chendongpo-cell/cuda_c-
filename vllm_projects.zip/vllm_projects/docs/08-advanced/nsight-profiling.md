# NVIDIA Nsight 性能分析

## 一句话总结
Nsight Systems 是 GPU 时间线分析工具，回答"GPU 在等什么"；Nsight Compute 是 kernel 级分析工具，回答"这个 kernel 为什么慢"。搭配使用能从硬件层面定位推理瓶颈。

## 先说结论：什么情况下 GPU 利用率低

```
日常看到 nvidia-smi 显示 GPU-Util: 20%，不代表 GPU 在偷懒。

可能的原因:
  1. GPU 在等数据: HBM 带宽不够 → memory-bound (Decode 阶段正常)
  2. GPU 在等 CPU: CPU 没来得及提交下一个 kernel
  3. GPU 在等同步: 多 Stream 间的 cudaStreamSynchronize
  4. GPU 确实空闲: batch 太小, kernel launch 间隔大
  5. GPU 利用率统计不准: Tensor Core 活动没被正确统计

Nsight 能精确告诉你到底是哪种情况
```

## Nsight Systems — 时间线分析

### 做什么

```
Nsight Systems (nsys) 回答:
  - GPU 什么时间在计算、什么时间在等？
  - CPU 和 GPU 之间的同步开销多大？
  - 每个 kernel launch 的间隔是多少？
  - 多 Stream 有没有真的并行？

输出: 一个 .nsys-rep 文件, 用 Nsight Systems GUI 打开
      能看到完整的 CPU-GPU 交互时间线
```

### 采集数据

```bash
# 安装: CUDA Toolkit 自带
which nsys
# 通常在 /usr/local/cuda/bin/nsys

# 最简单的采集:
nsys profile -o vllm_profile python3 my_vllm_bench.py

# 详细采集 (推荐):
nsys profile \
    --trace=cuda,osrt,nvtx,cudnn,cublas \
    --cuda-memory-usage=true \
    --gpu-metrics-device=0 \
    --output=vllm_detailed \
    python3 my_vllm_bench.py

# 参数说明:
# --trace=cuda:       追踪所有 CUDA API 调用和 kernel launch
# --trace=osrt:       追踪 OS runtime (线程创建、同步)
# --trace=nvtx:       追踪 NVTX 标记 (需要在代码里手动加)
# --trace=cudnn:      追踪 cuDNN 调用
# --trace=cublas:     追踪 cuBLAS 调用
# --cuda-memory-usage:追踪显存分配/释放
# --gpu-metrics-device:采集 GPU 硬件指标 (SM 频率、显存频率等)

# 轻量采集 (生产环境):
nsys profile \
    --trace=cuda \
    --sample=cpu \
    --backtrace=fp \
    --output=prod_profile \
    python3 my_vllm_serve.py  # 跑 1 分钟后 Ctrl+C
```

### 解读时间线

```
Nsight Systems 时间线 (简化):

CPU Stream 14:  [───tokenize──] [─launch_kernel─────────────────────] [─sample─] [─launch─]
GPU Stream 0 :                   [═══Prefill═══════] [=Decode=] [=Decode=] [=Decode=]
GPU Stream 1 :                                     [=========Copy KV Cache===========]
GPU Stream 2 :                   [══════GEMM═══════] [══GEMM══]

关键发现:
  1. GPU Stream 0 的 kernel 之间有空隙 → CPU launch overhead 太大
     → 解决: 用 CUDA Graph 消除 launch gap
  
  2. GPU Stream 1 和 Stream 0 重叠 → 好的, Copy 和 Compute 并行
     → 这是 PagedAttention 的 block copy 和 attention compute 重叠
  
  3. CPU 在 launch_kernel 阶段花了很长时间
     → Python overhead, 考虑 torch.compile 减少 Python 调用
  
  4. Decode kernel 很短 (10-20μs), 但 launch gap 有 5μs
     → 50% 时间在等 CPU launch → 用 CUDA Graph 可以消除
```

### 找瓶颈的流程

```
Step 1: 看 GPU 利用率曲线
  ├── 持续 90%+ → GPU 饱和, 没有明显瓶颈
  ├── 周期性地掉到 0% → 有 gap, 继续 Step 2
  └── 一直在 20-40% → Decode memory-bound (正常) 或 Step 2

Step 2: 放大 gap 区域
  ├── gap 在 kernel 之间 → CPU launch overhead
  │   → 解决: CUDA Graph, torch.compile, 减少 Python 代码
  ├── gap 在 kernel 和 memcpy 之间 → 同步点
  │   → 解决: 找代码中的 torch.cuda.synchronize() 或 .item() 调用
  └── gap 后面是 long kernel → 上一个 kernel 太慢
      → 继续 Step 3

Step 3: 把慢 kernel 拿去 Nsight Compute 分析
  → 见下一节
```

## Nsight Compute — Kernel 级分析

### 做什么

```
Nsight Compute (ncu) 回答:
  - 这个 kernel 用了多少 SM？
  - 多少时间在算 (compute)、多少时间在等内存 (memory)？
  - SM 占用率 (occupancy) 是多少？
  - L1/L2 cache 命中率？
  - Tensor Core 利用率？
  - 为什么这个 kernel 跑不满 GPU？

输出: 详细的 kernel 性能报告
```

### 采集和分析

```bash
# 分析单个 kernel
ncu --kernel-name gemm_kernel --set full python3 my_bench.py

# 分析最慢的 N 个 kernel
ncu --kernel-name regex:.* --top-n 10 python3 my_bench.py

# 只采关键指标 (快):
ncu --metrics \
    sm__throughput.avg.pct_of_peak_sustained_elapsed, \
    dram__throughput.avg.pct_of_peak_sustained_elapsed, \
    sm__warps_active.avg.pct_of_peak_sustained_elapsed \
    python3 my_bench.py

# 保存到文件
ncu --set full -o kernel_report python3 my_bench.py
# 生成 kernel_report.ncu-rep, 用 Nsight Compute GUI 打开
```

### 关键指标解读

```
=== Memory Workload Analysis (显存瓶颈分析) ===

DRAM Throughput: 85% of peak
  → GPU 85% 的时间在等显存
  → 这是 memory-bound kernel (正常)

L1 Cache Hit Rate: 45%
  → L1 没命中, 要读 L2/DRAM
  → 考虑调 tile size 提高缓存命中率

L2 Cache Hit Rate: 80%
  → L2 还可以, 但 20% 要去 DRAM


=== SM Workload Analysis (计算瓶颈分析) ===

SM Utilization: 30% of peak
  → 只有 30% 的 SM 在活跃
  → 原因可能是:
     1. Occupancy 太低 (见下面)
     2. 有 long latency 操作 (等内存)

Warp Occupancy: 25% (32 warps / 128 max per SM)
  → 每个 SM 只能同时跑 32 个 warp
  → 理论最大值是 128
  → 原因: Register 用太多 → 限制了每个 SM 的 warp 数
     → 解决: 减少每个线程的 register 使用


=== Tensor Core Analysis ===

Tensor Active: 55%
  → 55% 的周期 Tensor Core 在工作
  → 其余 45% 在等数据或做非矩阵运算 (softmax, mask)

FP16 Tensor Core: Used
  → 确认用了 FP16 Tensor Core


=== 结论 ===
这个 kernel 是 memory-bound (DRAM 85%)
Tensor Core 利用率 55% → 还行
SM 利用率 30% → 偏低, 但因为 memory-bound 所以正常
优化方向: 不是让 GPU 更忙, 而是减少显存读写
  → FlashAttention 已经做了 (tiling 减少 DRAM 读写)
  → FP8 KV Cache (减半显存读写量)
  → Kernel Fusion (减少中间结果写回)
```

### 实战分析流程

```bash
# 1. 先用 nsys 找到慢的阶段
nsys profile -o step1 python3 bench.py

# 2. 用 ncu 分析该阶段最慢的 kernel
ncu --kernel-name "Attention" --set full -o step2 python3 bench.py

# 3. 打开 step2.ncu-rep, 看:
#    - Memory Workload: DRAM % 是多少? → 判断 memory/compute bound
#    - Warp Occupancy: 有没有占满 SM?
#    - Tensor Core: 有没有用到?
#    - Roofline Chart: 当前 kernel 在 roofline 的哪个位置?

# 4. Roofline 分析:
#    Y轴: FLOPs/sec (算力)
#    X轴: FLOPs/byte (算数强度)
#    斜线: HBM 带宽上限
#    水平线: GPU 峰值算力
#
#    如果你的 kernel 在斜线上 → memory-bound → 减少内存读写
#    如果你的 kernel 在水平线附近 → compute-bound → 提高算力利用率
```

## 推理性能分析流程

### 标准分析脚本

```python
# profile_bench.py — 集成 NVTX 标记的推理压测脚本
import torch
import nvtx

# 手动标记关键阶段 (配合 nsys 使用)
with nvtx.annotate("Prefill", color="blue"):
    output = llm.prefill(prompt_tokens)

for i in range(max_new_tokens):
    with nvtx.annotate("Decode", color="green"):
        output = llm.decode()
    
    with nvtx.annotate("Sample", color="red"):
        next_token = sample(output)

# 运行:
# nsys profile --trace=nvtx,cuda python3 profile_bench.py
```

### 常见优化场景

```
场景 1: Decode kernel 之间有 gap
  CPU Timeline: [launch][─gap─][launch][─gap─][launch]
  GPU Timeline: [═══kernel═══]     [═══kernel═══]
  原因: Python overhead, 每次 decode 都要走一遍 Python 调度器
  解决: CUDA Graph (vLLM 默认开启)
  验证: 开了 CUDA Graph 后 gap 应该消失

场景 2: Prefill 长 prompt 时 GPU 利用率低
  原因: Attention 的 softmax/mask 部分是非 GEMM 操作
  解决: FlashAttention 已经优化了这个
  验证: 对比 FlashAttn vs 标准 Attn 的 kernel 时间

场景 3: 多卡通信是瓶颈
  ncu 或 nsys 可以看到 NCCL AllReduce kernel
  如果 AllReduce 时间占比 > 10% → TP 通信太多
  解决: 减少 TP size, 或检查 NVLink 是否正常 (nvidia-smi topo -m)

场景 4: Tokenizer 是瓶颈
  CPU 上 tokenizer 占了 50%+ 的时间 (nsys 能看到)
  解决: 用 Rust tokenizer (HuggingFace tokenizers 库)
  或 batch tokenize 而不是逐条
```

## 安装和本机使用

```bash
# Nsight Systems (CUDA Toolkit 自带)
which nsys
# 通常在 /usr/local/cuda/bin/nsys
# 或安装独立版本: https://developer.nvidia.com/nsight-systems

# Nsight Compute (CUDA Toolkit 自带)
which ncu
# 通常在 /usr/local/cuda/bin/ncu
# 或安装独立版本: https://developer.nvidia.com/nsight-compute

# 本机:
nvcc --version  # 12.6 → nsys 和 ncu 应该在 /usr/local/cuda/bin/

# 简单验证:
nsys --version
ncu --version
```

## 快速参考

| 问题 | 工具 | 怎么看 |
|------|------|--------|
| GPU 在等什么？ | nsys | 时间线上找 gap |
| 这个 kernel 为什么慢？ | ncu | 看 DRAM% 和 SM% |
| CPU launch overhead 多大？ | nsys | CPU Stream 上 kernel launch 的间隔 |
| 多卡通信正常吗？ | nsys | 看 NCCL kernel 时间和 NVLink 带宽 |
| Tensor Core 用了吗？ | ncu | Tensor Active % |
| 寄存器用太多？ | ncu | Warp Occupancy |
| 量化后性能变化？ | ncu | 对比 FP16 vs INT8 kernel 的 DRAM% |
