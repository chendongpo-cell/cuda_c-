# 大模型部署推理优化工程师 — 技能全景图

## 当前已覆盖 ✅ vs 待补充 ❌

---

## 一、推理引擎（核心技能）

| 技能 | 状态 | 说明 |
|------|------|------|
| vLLM 原理与部署 | ✅ 已覆盖 | PagedAttention, Continuous Batching, TP, Prefix Caching |
| vLLM 源码级理解 | ✅ 已覆盖 | Scheduler, BlockAllocator, 请求全生命周期 |
| **TensorRT-LLM** | ❌ 待补充 | NVIDIA 官方推理框架，极致性能（比 vLLM 还快 30-50%） |
| **Triton Inference Server** | ❌ 待补充 | NVIDIA 统一推理服务，支持多框架多模型 |
| SGLang | ⚠️ 简介 | RadixAttention 前缀缓存，结构化生成 |
| Ollama / llama.cpp | ⚠️ 简介 | 本地/CPU 推理 |

### 为什么必须学 TensorRT-LLM

```
vLLM: 通用推理框架，易用性好，性能好
TensorRT-LLM: NVIDIA 官方，性能极致，但需要编译模型

很多大厂/GPU云的底层用的是 TensorRT-LLM:
  - BentoML, Anyscale, NVIDIA NIM 背后都是它
  - 对 GPU 利用最充分 (CUDAGraph + 手写 kernel)
  - Latency 比 vLLM 低 30-50%

学习路径:
  1. 理解 TensorRT 编译原理 (graph capture, kernel fusion, precision calibration)
  2. 会编译模型: HuggingFace → TensorRT Engine
  3. 会用 Triton Server 部署编译好的 Engine
  4. 会对比 vLLM vs TRT-LLM 的性能
```

---

## 二、GPU 底层（硬核技能）

| 技能 | 状态 | 说明 |
|------|------|------|
| CUDA 编程模型 | ✅ 已覆盖 | Kernel, Thread, Warp, SM, Tensor Core |
| CUDA Stream/Graph | ✅ 已覆盖 | 并发执行, 图优化 |
| FlashAttention 原理 | ✅ 已覆盖 | Tiling, Online Softmax, IO 复杂度 |
| **手写 CUDA Kernel** | ❌ 待补充 | 当现成 kernel 不够时，自己写融合 kernel |
| **Triton 语言** | ❌ 待补充 | OpenAI 的 GPU 编程语言，比 CUDA 好写 |
| **NVIDIA Nsight 性能分析** | ❌ 待补充 | GPU profiler，找 kernel 级瓶颈 |
| **CUTLASS** | ❌ 待补充 | NVIDIA 模板库，vLLM 的 PagedAttention 就基于它 |

### 需要到什么程度

```
初级 (够用):
  会看 nvidia-smi, 知道 GPU 利用率低时怎么调

中级 (加分):
  会用 Nsight Systems 做 timeline 分析
  能找到是哪个 kernel 慢了

高级 (专家):
  能写 CUDA/Triton kernel 做算子融合
  比如把 LayerNorm + Attention + Residual 三个 kernel 合成一个
```

---

## 三、分布式系统

| 技能 | 状态 | 说明 |
|------|------|------|
| 单机多卡 (TP/PP) | ✅ 已覆盖 | vLLM TP 部署, NCCL 通信 |
| **多节点部署** | ❌ 待补充 | 模型大到一台机器放不下 → 跨机器推理 |
| **Ray** | ❌ 待补充 | 分布式计算框架, vLLM 内部用 Ray 做多节点调度 |
| **Kubernetes** | ❌ 待补充 | 容器编排, GPU 调度, 自动扩缩容 |
| **RDMA / InfiniBand** | ❌ 待补充 | 跨节点高速网络, NCCL 跨节点通信 |
| **GPU 虚拟化 (MIG)** | ❌ 待补充 | 一张 A100/H100 切成 7 小块, 多租户共享 |

### 多节点部署场景

```
单机 8×A800 放不下 405B 模型
→ 需要 2-4 个节点, 每个节点 8 张卡
→ 跨节点用 PP, 节点内用 TP
→ 需要 Ray 做跨节点调度
→ 网络必须是 InfiniBand (200Gbps+)
→ PCIe 不够用, NCCL 跨节点通信必须是 RDMA

这是真正的大厂场景
```

---

## 四、服务化与运维

| 技能 | 状态 | 说明 |
|------|------|------|
| API 网关 + 限流 | ✅ 有代码 | FastAPI + Token Bucket |
| Nginx 负载均衡 | ✅ 有配置 | least_conn + SSE 支持 |
| Prometheus + Grafana | ✅ 已覆盖 | 指标采集 + 可视化 |
| Docker + Compose | ✅ 已覆盖 | Dockerfile + 编排 |
| **K8s + GPU Operator** | ❌ 待补充 | GPU 集群调度 |
| **自动扩缩容 (HPA/KEDA)** | ❌ 待补充 | 根据 QPS/GPU 利用率自动扩实例 |
| **CI/CD Pipeline** | ❌ 待补充 | 模型版本管理, 灰度发布, A/B 测试 |
| **SLO/SLA 管理** | ❌ 待补充 | 定义延迟/可用性目标, 错误预算 |
| **多租户隔离** | ❌ 待补充 | 按用户的速率限制, 显存隔离, 成本核算 |

---

## 五、模型优化

| 技能 | 状态 | 说明 |
|------|------|------|
| AWQ/GPTQ 量化 | ✅ 已覆盖 | 原理 + 部署命令 |
| FP8 量化 | ⚠️ 简介 | 需要补充 H100 实践 |
| LoRA/QLoRA 微调 | ✅ 已覆盖 | 原理 + LLaMA-Factory 配置 |
| **模型蒸馏** | ❌ 待补充 | 大模型教小模型, 减小部署成本 |
| **模型剪枝** | ❌ 待补充 | 去掉不重要的权重/层 |
| **torch.compile / dynamo** | ❌ 待补充 | PyTorch 2.0 的图编译, 自动 kernel fusion |
| **ONNX 导出** | ❌ 待补充 | 跨框架模型格式转换 |

---

## 六、应用层

| 技能 | 状态 | 说明 |
|------|------|------|
| OpenAI API 协议 | ✅ 已覆盖 | Chat Completions, Streaming, Function Calling |
| RAG 管线 | ✅ 已覆盖 | Embedding + 检索 + 重排 + 生成 + 源码 |
| Agent/FC | ✅ 已覆盖 | ReAct + 工具定义 + 源码 |
| 多模态部署 | ⚠️ 简介 | VLM 原理 + 命令 |
| **Prompt 工程化** | ❌ 待补充 | 版本管理, A/B 测试, 模板引擎 |
| **RAG 高级优化** | ❌ 待补充 | HyDE, 多路召回, 自查询, 纠错式 RAG |
| **在线评估** | ❌ 待补充 | 用户反馈收集, 模型效果回归检测 |

---

## 七、软技能

| 技能 | 状态 | 说明 |
|------|------|------|
| 性能分析报告 | ❌ 待补充 | 压测 → 找瓶颈 → 写报告 → 推优化 → 验证 |
| 容量规划 | ❌ 待补充 | 预估 "N 个用户, M QPS" 需要多少 GPU |
| 成本核算 | ❌ 待补充 | GPU 租赁/TCO 计算, 不同方案的性价比 |
| 故障复盘 | ❌ 待补充 | Post-mortem 文档, 根因分析 |

---

## 优先级建议

### 🔴 第一优先（直接影响面试和日常工作）

```
1. TensorRT-LLM + Triton Server
   理由: 很多公司实际用这个, 面试必问 "vLLM vs TRT-LLM"

2. Nsight Systems 性能分析
   理由: 能从 kernel 级找到瓶颈, 是区分 "会用" 和 "会优化" 的分水岭

3. K8s + GPU 调度基础
   理由: 生产环境基本都在 K8s 上
```

### 🟡 第二优先（进阶，区分优秀工程师）

```
4. Ray 分布式框架
5. Triton 语言写 kernel
6. 自动扩缩容 (HPA/KEDA)
7. torch.compile 图优化
8. 容量规划 + 成本核算
```

### 🟢 第三优先（专家级）

```
9. 手写 CUDA kernel + CUTLASS
10. RDMA / InfiniBand 调优
11. 多节点跨机推理
12. 模型蒸馏/剪枝
```

---

## 学习路径建议

```
现在的位置 ──────→ 推理工程师 ──────→ 高级工程师 ──────→ 专家
(已有基础)      (3-6个月)          (6-12个月)         (1-2年)

第1步: TensorRT-LLM + Nsight
  - 学会编译 TRT Engine
  - 学会用 Nsight 找 kernel 瓶颈
  - 能对比 vLLM vs TRT-LLM 的性能差异

第2步: K8s + Ray
  - 在 K8s 上部署一套推理服务
  - 学会 GPU node labeling, resource request/limit
  - 学会 Ray Serve 做模型部署

第3步: Triton + torch.compile
  - 手写一个简单的 CUDA kernel (向量加法)
  - 用 Triton 写一个融合 kernel (RMSNorm + MatMul)
  - 理解 torch.compile 的 graph capture

第4步: 多节点 + 高级优化
  - 跨节点 TP/PP 部署
  - 蒸馏 + 剪枝 + 量化全链路
  - 自建完整的 CI/CD pipeline
```

---

## 推荐资源

| 主题 | 资源 |
|------|------|
| TensorRT-LLM | https://github.com/NVIDIA/TensorRT-LLM |
| Triton Server | https://github.com/triton-inference-server/server |
| Nsight Systems | `nsys profile python3 script.py` (CUDA Toolkit 自带) |
| Triton 语言 | https://triton-lang.org/ |
| CUDA 编程 | 《CUDA C++ Programming Guide》+ CUDA By Example |
| K8s GPU | NVIDIA GPU Operator + K8s device plugin |
| Ray | https://docs.ray.io/ |
