# 多模态模型部署

## 一句话总结
VLM = Vision Encoder(ViT/CLIP) + Projector(把图像映射到LLM空间) + LLM Decoder。图像先被切为N个patch token，和文本token一起进LLM。部署时注意图像token的KV Cache也占显存。

## VLM 架构

```
图片 ──→ Vision Encoder (ViT/SigLIP)
              ↓
        图像 tokens (N个, 如336×336 → 576 tokens)
              ↓
         Projector (MLP)  ← 把视觉特征映射到LLM文本空间
              ↓
    [image_tokens | text_tokens]  ← 拼接后进LLM
              ↓
         LLM Decoder ──→ 文本输出
```

## 图像 Token 数量

| patch_size | 336×336图片的token数 |
|-----------|-------------------|
| 14 (Qwen2.5-VL) | (336/14)² = 576 |
| 16 (LLaVA) | (336/16)² = 441 |

每个图像token也有KV Cache！多图场景要考虑：
```
5张图 × 576 tokens × FP16 KV Cache ≈ 额外 ~200MB+ KV Cache
```

## 部署 Qwen2.5-VL

```bash
# 下载
python3 -c "
from modelscope import snapshot_download
snapshot_download('qwen/Qwen2.5-VL-7B-Instruct', cache_dir='./models/')
"
# ModelScope: https://www.modelscope.cn/models/qwen/Qwen2.5-VL-7B-Instruct

# 启动
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/Qwen2.5-VL-7B-Instruct \
    --max-model-len 8192 \
    --limit-mm-per-prompt image=5 \   # 每请求最多5张图
    --port 8003
```

## API 调用

```python
import base64
from openai import OpenAI

client = OpenAI(base_url="http://localhost:8003/v1", api_key="dummy")

with open("photo.jpg", "rb") as f:
    img_b64 = base64.b64encode(f.read()).decode()

resp = client.chat.completions.create(
    model="qwen2.5-vl-7b",
    messages=[{
        "role": "user",
        "content": [
            {"type": "text", "text": "描述这张图片"},
            {"type": "image_url", "image_url": {
                "url": f"data:image/jpeg;base64,{img_b64}"
            }}
        ]
    }],
    max_tokens=500
)
```

## 主流VLM

| 模型 | 视觉编码器 | LLM | 特点 |
|------|----------|-----|------|
| Qwen2.5-VL | ViT (SigLIP) | Qwen2.5 | 中文最优 |
| LLaVA-1.6 | CLIP-ViT | Vicuna/Mistral | 经典架构 |
| InternVL2 | InternViT | InternLM | 大分辨率 |
| LLaMA3.2-V | ViT | LLaMA3.2 | Meta生态 |

## 本机 vLLM-Omni

本机Docker中运行的 vllm/vllm-omni 支持多模态（OCR/TTS）：
```bash
# 端口8092: OCR服务  
# 端口8091: TTS服务

# 查看日志了解模型配置
docker logs unlimited-ocr 2>&1 | head -5
```
