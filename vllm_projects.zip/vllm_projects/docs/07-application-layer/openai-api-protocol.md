# OpenAI API 协议详解

## 一句话总结
OpenAI API 已成为 LLM 服务的事实标准。Chat Completions 端点支持多轮对话、流式输出(SSE)、Function Calling。vLLM 完全兼容此协议。

## Chat Completions 请求

### 完整请求体

```json
{
  "model": "qwen2.5-7b",
  "messages": [
    {"role": "system", "content": "你是一个有用的助手"},
    {"role": "user", "content": "解释Transformer"},
    {"role": "assistant", "content": "Transformer是一种..."},
    {"role": "user", "content": "详细一点"}
  ],
  "temperature": 0.7,
  "top_p": 0.9,
  "max_tokens": 500,
  "stop": ["\n\n"],
  "stream": true,
  "frequency_penalty": 0.0,
  "presence_penalty": 0.0,
  "tools": [{"type": "function", "function": {...}}],
  "tool_choice": "auto"
}
```

### 关键参数

| 参数 | 默认值 | 说明 |
|------|-------|------|
| `temperature` | 1.0 | 0=确定，越高越随机。RAG 用 0.1-0.3 |
| `top_p` | 1.0 | 只从累积概率达到 p 的 token 中采样 |
| `max_tokens` | 无限 | 生成的最大 token 数 |
| `stop` | — | 遇到这些字符串立即停止 |
| `stream` | false | true=SSE 流式输出 |
| `frequency_penalty` | 0 | 惩罚已出现的 token (-2.0到2.0) |
| `presence_penalty` | 0 | 惩罚出现过的 token 类型 |

## Streaming (SSE 协议)

```
请求: {"stream": true, ...}
响应: Content-Type: text/event-stream

data: {"choices":[{"delta":{"role":"assistant"},"index":0}]}

data: {"choices":[{"delta":{"content":"很"},"index":0}]}

data: {"choices":[{"delta":{"content":"高"},"index":0}]}

data: {"choices":[{"delta":{"content":"兴"},"index":0}]}

data: {"choices":[{"delta":{"content":""},"finish_reason":"stop","index":0}]}

data: [DONE]
```

每行以 `data: ` 开头，是 JSON 格式。`[DONE]` 表示流结束。

## Python SDK 使用

```python
from openai import OpenAI
import os

# 绕过代理
os.environ.pop('http_proxy', None)
os.environ.pop('https_proxy', None)

client = OpenAI(
    base_url="http://localhost:8001/v1",
    api_key="dummy"
)

# 非流式
resp = client.chat.completions.create(
    model="Qwen3.5-122B",
    messages=[{"role": "user", "content": "Hello"}],
    temperature=0.3,
    max_tokens=200
)
print(resp.choices[0].message.content)

# 流式
stream = client.chat.completions.create(
    model="Qwen3.5-122B",
    messages=[{"role": "user", "content": "写一首诗"}],
    temperature=0.7,
    max_tokens=100,
    stream=True
)
for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="", flush=True)
```

## curl 脚本（绕过代理）

```bash
# 必须清代理
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY

# 非流式
curl -s --noproxy '*' http://localhost:8001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"Qwen3.5-122B","messages":[{"role":"user","content":"你好"}],"max_tokens":100}'

# 流式
curl -s --noproxy '*' http://localhost:8001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"Qwen3.5-122B","messages":[{"role":"user","content":"你好"}],"stream":true,"max_tokens":100}'
```

## Token 计量

```python
import tiktoken
enc = tiktoken.get_encoding("cl100k_base")
text = "大模型部署学习"
tokens = enc.encode(text)
print(f"文本: {text}\nToken数: {len(tokens)}")
# 中文约 1-2 字/token，英文约 0.75 词/token
```

## 本机已调通

| 端点 | URL |
|------|-----|
| Health | `curl --noproxy '*' http://localhost:8001/health` |
| Models | `curl --noproxy '*' http://localhost:8001/v1/models` |
| Chat | `curl --noproxy '*' http://localhost:8001/v1/chat/completions` |
| Metrics | `curl --noproxy '*' http://localhost:8001/metrics` |

⚠️ **关键提醒**: 公司有代理(TPEproxyNwing)，访问 localhost 必须用 `--noproxy '*'` 或 `NO_PROXY=localhost`！
