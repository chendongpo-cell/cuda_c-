# RAG 全链路深度解析

## 一句话总结
RAG = 检索增强生成。离线阶段：文档切分(chunking) → Embedding → 向量库。在线阶段：query embedding → 向量检索(Top-K) → Reranker 精排 → prompt 拼接 → LLM 生成。本质是把 LLM 的"记忆"外包给外部知识库。

## 为什么需要 RAG

```
LLM 的两大局限:
  1. 知识截止日期: 训练数据到某天就停了
     "今天天气怎么样?" → 不知道
     "公司最新的政策是什么?" → 不知道
  
  2. 幻觉 (Hallucination):
     对不知道的内容, LLM 不会说 "不知道"
     而是编一个听起来合理的答案
     → 在企业应用中不可接受

RAG 解决:
  LLM 不需要 "知道" 所有答案
  只需要 "读取" 检索到的文档
  然后 "总结/推理/回答"
```

## 全链路架构

### 离线阶段：构建知识库

```
Step 1: 文档解析
  PDF → pypdf/pdfplumber
  DOCX → python-docx
  HTML → BeautifulSoup
  Markdown → 直接读
  → 提取纯文本

Step 2: 文本切分 (Chunking)
  长文档 → 切成小块 (chunk)
  每个 chunk 300-800 字
  重叠 50-100 字 (防止切到句子中间)
  → 带元数据的 chunk 列表

Step 3: Embedding
  每个 chunk → embedding 模型 → 向量 (如 1024 维)
  → 文本变成可计算的向量

Step 4: 存入向量库
  向量 + 元数据 → ChromaDB/Milvus/Qdrant
  → 支持相似度检索
```

### 在线阶段：查询

```
Step 1: 用户问题
  "vLLM 如何优化显存使用?"

Step 2: Query Embedding
  问题 → embedding 模型 → query 向量

Step 3: 向量检索
  query 向量 vs 库中所有 chunk 向量 → Top-K 最相似
  → 取前 10-20 个

Step 4: Reranker 精排 (可选但推荐)
  用 Cross-Encoder 对 Top-K 做精细打分
  → 取前 3-5 个最相关的

Step 5: Prompt 拼接
  """
  参考资料:
  [1] vLLM 的 PagedAttention 通过分页管理 KV Cache...
  [2] PagedAttention 将显存利用率从 40% 提升到 96%...
  
  问题: vLLM 如何优化显存使用?
  """

Step 6: LLM 生成
  prompt → LLM → 带引用的回答
  "vLLM 主要有两种显存优化: (1) PagedAttention[1]..."
```

## Chunking 策略对比

### 固定大小切分

```python
# 简单粗暴
def fixed_chunk(text, size=500, overlap=50):
    chunks = []
    for i in range(0, len(text), size - overlap):
        chunks.append(text[i:i+size])
    return chunks

优点: 简单, 速度快
缺点: 可能在句子中间切断
```

### 递归字符切分 (推荐)

```python
# 优先按自然分隔符切分
separators = ["\n\n", "\n", "。", "！", "？", "；", "，", " ", ""]

def recursive_split(text, separators):
    if not separators:
        return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]
    
    sep = separators[0]
    remaining = separators[1:]
    splits = text.split(sep)
    
    chunks, current = [], ""
    for split in splits:
        candidate = current + sep + split if current else split
        if len(candidate) <= chunk_size:
            current = candidate
        else:
            if current: chunks.append(current)
            if len(split) > chunk_size:
                chunks.extend(recursive_split(split, remaining))
                current = ""
            else:
                current = split
    if current: chunks.append(current)
    return chunks

优点: 尽量保持语义完整
缺点: 略慢
```

### 语义切分

```python
# 用 embedding 相似度找话题转换点
def semantic_chunk(sentences):
    embeddings = model.encode(sentences)
    chunks = []
    current = [sentences[0]]
    
    for i in range(1, len(sentences)):
        similarity = cosine(embeddings[i-1], embeddings[i])
        if similarity < threshold:  # 话题变了
            chunks.append(" ".join(current))
            current = [sentences[i]]
        else:
            current.append(sentences[i])
    chunks.append(" ".join(current))
    return chunks

优点: 最尊重原文结构
缺点: 需要 embedding, 慢
```

### 父子文档 (生产级)

```
小 chunk (200字) 用于检索:
  - 语义精确匹配
  - 检索到更相关的片段

大 chunk (800字) 用于生成:
  - 包含足够上下文
  - LLM 能理解完整意思

实现:
  index 时: 小 chunk 入库, 每个 chunk 指向父文档
  检索时: 用小 chunk 匹配, 返回对应的父文档
```

## Embedding 模型选型

| 模型 | 维度 | 中文效果 | 速度 | 显存 |
|------|------|---------|------|------|
| BGE-large-zh-v1.5 | 1024 | ⭐⭐⭐⭐⭐ | 快 | ~1.3 GB |
| GTE-Qwen2-7B-instruct | 3584 | ⭐⭐⭐⭐⭐ | 中等 | ~14 GB |
| multilingual-e5-large | 1024 | ⭐⭐⭐⭐ | 快 | ~1.2 GB |
| text2vec-large-chinese | 1024 | ⭐⭐⭐⭐ | 快 | ~1.3 GB |

```bash
# 推荐: BGE (中文最好的轻量模型)
pip install sentence-transformers
python3 -c "
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('BAAI/bge-large-zh-v1.5')
# 正常化 → 直接用内积 = cosine similarity
model.encode = lambda texts, **kw: model.encode(texts, normalize_embeddings=True, **kw)
"
```

## Reranker 原理

### Bi-Encoder vs Cross-Encoder

```
Bi-Encoder (Embedding 模型):
  query → Encoder → q_vector  ┐
  doc   → Encoder → d_vector  ┘ → cosine(q, d)
  
  优点: 文档向量可预计算存储, 检索极快
  缺点: query 和 doc 独立编码, 丢失交互信息

Cross-Encoder (Reranker):
  [query, doc] → BERT → score
  
  优点: query 和 doc 一起编码 → 精确理解
  缺点: 慢! 每对 (query, doc) 都要跑一遍 BERT
  → 只能对 Top-K 重排, 不能全量检索
```

### 流程

```
检索阶段 (Bi-Encoder):  10000 篇文档 → Top-20  (快速, ~10ms)
重排阶段 (Cross-Encoder): 20 篇 → Top-3    (精确, ~100ms)
生成阶段 (LLM):          3 篇 + 问题 → 回答 (推理, ~500ms)
```

## 向量数据库选型

| 库 | 类型 | 特点 | 适合 |
|----|------|------|------|
| **ChromaDB** | 嵌入式 | pip install 即可, 零配置 | 原型/小规模 |
| **Milvus** | 分布式 | 十亿级, GPU 索引 | 生产/大规模 |
| **Qdrant** | Rust | 过滤强大, 性能好 | 中等规模 |
| **Weaviate** | Java | 全功能, GraphQL API | 企业级 (本机有) |

```bash
# ChromaDB 最简上手
pip install chromadb
python3 -c "
import chromadb
client = chromadb.PersistentClient(path='./chroma_db')
collection = client.create_collection('kb', metadata={'hnsw:space': 'cosine'})
collection.add(documents=['文本1', '文本2'], ids=['1', '2'])
results = collection.query(query_texts=['查询'], n_results=3)
"
```

## 检索优化技巧

### 1. Query Rewriting

```
原始问题: "vllm怎么加速"
改写后:   "vLLM推理框架 性能优化 加速技术"
→ LLM 改写, 补充关键词 → 提高召回率
```

### 2. HyDE (Hypothetical Document Embeddings)

```
问题 → LLM 生成假设答案 → 用假设答案的 embedding 去检索
→ 有时比用问题的 embedding 效果更好
→ 因为答案和文档在语义空间更接近
```

### 3. 多路召回 + RRF 融合

```
路1: 向量检索 (语义相似)         → results_1
路2: BM25 关键词检索 (精确匹配)   → results_2

RRF (Reciprocal Rank Fusion):
  score(doc) = Σ 1/(k + rank_i(doc))
  
→ 两边都排名高的文档综合得分最高
→ 取综合排名 Top-K
```

## 本机已有 RAG 基础设施

```
Dify: langgenius/dify-* 全家桶 (API + Web + Worker + Plugin)
Weaviate: semitechnologies/weaviate (向量数据库, 端口未暴露)
PostgreSQL: docker-db, gsk_pg, industry_postgres
Elasticsearch: gsk-es-02

可以利用这些现成服务搭建 RAG, 不需要从零开始
```

---

## 检索效果排查

这是 RAG 上线后最常遇到的问题。

### "检索结果不相关"

```
现象: LLM 回答 "参考资料中未找到相关信息" 或瞎编

排查步骤:

Step 1: 确认 Embedding 模型适合你的数据
  - 中文文档 → BGE-large-zh (不是 multilingual!)
  - 英文文档 → E5 或 multilingual
  - 代码文档 → 通用模型效果差, 考虑 code-specific embedding

Step 2: 检查 Chunking 策略
  - chunk 太短 (<100字) → 信息不完整
  - chunk 太长 (>1000字) → 检索不精确
  - 推荐: 300-500 字 + 50-100 字重叠
  
Step 3: 检查查询本身
  用户问: "怎么弄?"
  → 查询太模糊 → rewriting: "怎么安装vLLM?"
  
  解决: 加 Query Rewriting (让 LLM 把用户问题改写成明确的查询)

Step 4: 检查向量库
  - 确认 collection 的 metric_type = COSINE (不是 L2!)
  - 确认 embedding 维度匹配 (BGE-M3=1024, BGE-large=1024)
  - 确认索引类型: IVF_FLAT 召回率 > HNSW
```

### "检索到相关文档但 LLM 回答还是不对"

```
可能原因:
  1. Reranker 没生效: Top-K 检索的文档包含噪声
     → 开 Reranker, 把 10→3 精度提升
  
  2. Prompt 模板问题: 文档和问题混在一起
     → 优化 prompt 结构, 明确告诉 LLM "只能基于文档回答"
  
  3. LLM 不够强: 7B 模型阅读理解能力有限
     → 换更大模型 (72B) 或更强的 DeepSeek
  
  4. 文档本身有问题: 文档和问题语义相关但信息不对
     例: 问题是 "vLLM如何部署", 检索到的文档是 "vLLM介绍"
     → 增强数据质量, 确保文档有足够细节
```

### "检索太慢 (>500ms)"

```
排查:
  
  Retrieve 阶段:
    - Embedding 模型是否在 GPU 上？ (CPU 慢 10×)
    - 向量库索引类型？ HNSW 检索快但召回略低
    - 库中向量数量？ >10万考虑 IVF_PQ 压缩
    - 内网 BGE-M3 API 延迟？ 测一下: time curl /encode

  Rerank 阶段:
    - Reranker 模型太大？ bge-reranker-v2-m3 ~2GB
    - Top-K 太多？ 10→3 减少计算量
  
  Generate 阶段:
    - Prompt 太长？ context 控制在 2000 字以内
    - LLM 太慢？ 考虑量化或换更快的模型
```

### "Embedding 结果不对 (两个相似句子给的向量差异很大)"

```
测试:
texts = ["今天天气很好", "今日天气不错"]
embeddings = model.encode(texts)
similarity = cosine(embeddings[0], embeddings[1])
# 预期: > 0.85 (非常相似)

如果 similarity < 0.7:
  检查: 是否 normalize_embeddings=True
  检查: 模型是否正确加载 (BGE-large-zh vs BGE-base)
  检查: instruction 前缀是否正确
    BGE query: "为这个句子生成表示以用于检索相关文章：" + query
    BGE doc:   不加前缀
```

---

## 内网 RAG 基础设施

本项目有完整的内网 RAG 服务可用:

| 服务 | 地址 | 用途 |
|------|------|------|
| DeepSeek-Flash | 10.210.48.94:31610 | LLM 生成 |
| BGE-M3 Embedding | 10.210.52.229:6053 | 向量化 (1024维) |
| BGE Reranker | 10.210.52.229:6054 | 精排 |
| Milvus | 10.210.52.229:19530 | 向量库 |

对接代码见: `src/rag/rag_pipeline_prod.py`

详见: `docs/00-environment/internal-infra.md`
