# Agent 与 Function Calling 深度解析

## 一句话总结
LLM 通过 Function Calling 调用外部工具（天气查询、计算器、数据库搜索等）。Agent = LLM + 工具定义 + ReAct 循环(Thought → Action → Observation)，让 LLM 从 "只会说" 变成 "会做"。

## Function Calling 机制

### OpenAI 协议格式

```json
// 请求: 告诉 LLM 有哪些工具可用
{
  "model": "qwen3.5-35b",
  "messages": [{"role": "user", "content": "今天上海天气怎么样?"}],
  "tools": [
    {
      "type": "function",
      "function": {
        "name": "get_weather",
        "description": "查询指定城市的天气",
        "parameters": {
          "type": "object",
          "properties": {
            "city": {"type": "string", "description": "城市名称"}
          },
          "required": ["city"]
        }
      }
    }
  ],
  "tool_choice": "auto"
}

// LLM 返回: 决定调用工具
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": null,
      "tool_calls": [{
        "id": "call_abc123",
        "function": {
          "name": "get_weather",
          "arguments": "{\"city\": \"上海\"}"
        }
      }]
    }
  }]
}

// 系统: 执行 get_weather("上海") → 获取结果
// 然后把结果发回 LLM

// 继续对话: 把工具结果加入 messages
{
  "messages": [
    {"role": "user", "content": "今天上海天气怎么样?"},
    {"role": "assistant", "tool_calls": [...]},
    {"role": "tool", "tool_call_id": "call_abc123", "content": "{\"weather\": \"中雨\", \"temp\": \"28°C\"}"}
  ]
}

// LLM 最终返回: 基于工具结果生成回答
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "今天上海有中雨，温度28°C，建议带伞。"
    }
  }]
}
```

### 完整的执行流程

```
用户输入
    ↓
LLM 分析: 这个问题需要调用工具吗?
    ↓
  Yes → 返回 tool_call (函数名 + 参数)
         ↓
       系统执行工具
         ↓
       结果返回给 LLM
         ↓
       LLM 判断: 信息够了吗?
         ↓                    ↓
       Yes → 生成最终回答    No → 再调一个工具
    ↓
  No → 直接生成回答
```

## ReAct (Reasoning + Acting) 模式

### 核心循环

```
Thought (思考): 我现在需要什么信息? 该做什么?
Action (行动): 调用工具
Observation (观察): 工具返回了什么?
→ 循环直到得到足够信息
→ Final Answer (最终回答)
```

### 完整示例

```
用户: "上海和北京今天哪个更热? 温差多少?"

Iter 1:
  Thought: 需要同时查上海和北京的天气
  Action: get_weather("上海")
  Observation: {"weather": "中雨", "temp": "28°C"}

  Action: get_weather("北京")  
  Observation: {"weather": "晴", "temp": "35°C"}

Iter 2:
  Thought: 北京35°C > 上海28°C, 温差=7°C
  → 信息够了, 可以回答
  
  Final Answer: "北京更热, 35°C vs 上海28°C, 温差7°C"
```

### 代码骨架

```python
class ReActAgent:
    def run(self, user_input):
        messages = [{"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_input}]
        
        for iteration in range(max_iterations):
            response = llm.chat(messages, tools=TOOLS)
            
            if response.has_tool_calls():
                # 记录 assistant 消息
                messages.append(response.message)
                
                # 执行每个工具调用
                for tool_call in response.tool_calls:
                    result = execute_tool(tool_call.name, tool_call.args)
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id, 
                        "content": str(result)
                    })
            else:
                # 没有 tool_call → 最终回答
                return response.content
        
        return "达到最大迭代次数"
```

## 工具设计原则

### 1. 描述要精确

```
❌ 不好:
  "get_data": "获取数据"

✅ 好:
  "get_weather": "查询指定城市的当前天气信息，包括温度、湿度、天气状况"

LLM 靠 description 来决定是否调用, 描述不清楚 → 调错工具
```

### 2. 参数要具体

```json
❌ 不好:
"parameters": {
  "properties": {
    "query": {"type": "string"}
  }
}

✅ 好:
"parameters": {
  "type": "object",
  "properties": {
    "city": {
      "type": "string",
      "description": "城市名称，如'上海'、'北京'。不支持省份和国家。"
    }
  },
  "required": ["city"]
}
```

### 3. 返回值要结构化

```python
# LLM 需要理解返回值 → JSON 最通用
return {
    "temperature": 28,
    "weather": "中雨",
    "humidity": 85,
    "city": "上海"
}

# 而不是:
return "上海今天28度, 中雨"  # LLM 需要额外解析
```

## vLLM 的 Function Calling 支持

```bash
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --tool-call-parser hermes \        # 或 llama3_json
    --enable-auto-tool-choice

# tool-call-parser:
#   hermes: Qwen/Hermes 系列模型
#   llama3_json: LLaMA 3.1+ 系列
#   mistral: Mistral 系列
```

```python
# OpenAI SDK 调用 (和调用 OpenAI 完全一样)
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8001/v1", api_key="dummy")

response = client.chat.completions.create(
    model="Qwen3.5-122B",
    messages=[{"role": "user", "content": "上海天气?"}],
    tools=TOOLS,
    tool_choice="auto"
)
```

## Agent 的安全防护

### 必须限制

```python
MAX_ITERATIONS = 10        # 最多循环 10 轮
MAX_TOOL_CALLS = 10        # 单轮最多调 10 次工具
TOOL_TIMEOUT = 30          # 单工具执行超时 30 秒
MAX_OUTPUT_TOKENS = 4096   # 回答不能太长

# 防止:
# 1. 无限循环: LLM 不断调工具但始终不回答
# 2. 工具卡死: 外部 API 不响应
# 3. 工具返回太大: 撑爆 context window
```

### 工具沙箱

```python
# 工具执行应该有权限限制
def execute_tool(name, args):
    if name not in ALLOWED_TOOLS:
        return {"error": "Unknown tool"}
    
    # 检查参数合法性
    if name == "run_shell_command":
        # ⚠️ 绝对不能直接执行任意 shell 命令!
        return {"error": "Shell access not allowed"}
    
    if name == "search_database":
        # 限制搜索范围
        if "DROP" in args["query"].upper():
            return {"error": "Invalid query"}
    
    # 限制执行时间
    with timeout(TOOL_TIMEOUT):
        return TOOL_EXECUTORS[name](**args)
```

## Agent 架构模式对比

| 模式 | 流程 | 适合 |
|------|------|------|
| **ReAct** | Thought→Action→Observation 循环 | 通用, 需要多步推理 |
| **Plan-Execute** | 先制定完整计划, 再逐步执行 | 任务明确, 步骤固定 |
| **Router** | 根据问题类型路由到不同 Agent | 多领域问题 |
| **Multi-Agent** | 多个 Agent 协作/辩论 | 复杂任务分解 |

## Agent 框架

| 框架 | 特点 | 适合 |
|------|------|------|
| **OpenAI Function Calling** | 原生稳定, vLLM 完全兼容 | 简单场景 |
| **LangChain Agent** | 生态全, 工具多, 抽象层多 | 快速原型 |
| **LangGraph** | 有状态图, 复杂流程 | 多步工作流 |
| **AutoGen** | 多 Agent 对话 | 协作式任务 |
| **Dify** | 可视化编排, 拖拽式 | 非程序员 (本机有部署)|

## 本机可用的 Agent 服务

```bash
# 端口 8001 的 vLLM 已开启 Function Calling:
# --enable-auto-tool-choice --tool-call-parser hermes

# 测试:
curl -s --noproxy '*' http://localhost:8001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen3.5-122B",
    "messages": [{"role": "user", "content": "上海天气?"}],
    "tools": [{
      "type": "function",
      "function": {
        "name": "get_weather",
        "description": "查询指定城市的天气",
        "parameters": {
          "type": "object",
          "properties": {"city": {"type": "string"}},
          "required": ["city"]
        }
      }
    }]
  }'
```
