# 大模型部署运维优化 — 学习笔记

> **目标**: 从零到生产级，掌握大模型部署、推理优化、微调、运维、RAG/Agent 应用全链路
>
> **硬件**: 8× NVIDIA A800 80GB | **Python**: 3.10 | **PyTorch**: 2.5 | **CUDA**: 12.6

---

## 学习路线图

```
Round 1: 快速跑通全链路 (~1周)
├── 环境准备 (CUDA 工具链、GPU 显存模型、推理框架生态、CUDA 深度、部署方式对比)
├── 模型基础 (架构对比、分词器、量化基础、位置编码)
├── 单卡推理 (Transformer 推理流程、KV Cache、PagedAttention、Continuous Batching)
├── 多卡推理 (张量并行、流水线并行、NCCL 通信)
└── 应用对接 (OpenAI API 协议、RoPE 原理)

Round 2: 深层优化 (~2周)
├── 推理引擎深挖 (FlashAttention、Speculative Decoding)
├── 模型微调 (LoRA/QLoRA、SFT 数据工程、RLHF/DPO、分布式训练)
├── 服务性能优化 (调度策略、Prefix Caching、延迟/吞吐分析、量化部署)
└── 模型评估 (benchmark 体系、A/B 测试)

Round 3: 生产加固 (~1周)
├── 服务化架构 (API 网关、限流、负载均衡)
├── 监控与可观测性 (Prometheus+Grafana、GPU 指标、链路追踪)
├── 容错与弹性 (故障模式、重试策略、健康检查)
└── 容器化 (Docker、Docker Compose、一键管理脚本)

Round 4: 应用层扩展 (~2周)
├── RAG 管线 (Embedding 服务、向量数据库、检索+重排、查询优化)
├── Agent/Function Calling (工具定义、ReAct 循环、安全限制)
├── 多模态部署 (VLM 架构、图像 token 处理)
└── 安全加固 (注入检测、API Key 管理、审计日志)
```

---

## 文档索引

### Round 1: 快速跑通全链路
- [00-environment/cuda-toolchain.md](00-environment/cuda-toolchain.md)
- [00-environment/gpu-memory-model.md](00-environment/gpu-memory-model.md)
- [00-environment/inference-ecosystem.md](00-environment/inference-ecosystem.md)
- [00-environment/cuda-ecosystem-deep-dive.md](00-environment/cuda-ecosystem-deep-dive.md)
- [00-environment/deployment-comparison.md](00-environment/deployment-comparison.md)
- [01-model-basics/model-architecture.md](01-model-basics/model-architecture.md)
- [01-model-basics/tokenizer-principles.md](01-model-basics/tokenizer-principles.md)
- [01-model-basics/quantization-basics.md](01-model-basics/quantization-basics.md)
- [01-model-basics/position-encoding.md](01-model-basics/position-encoding.md)
- [02-single-gpu-inference/transformer-inference.md](02-single-gpu-inference/transformer-inference.md)
- [02-single-gpu-inference/kv-cache-deep-dive.md](02-single-gpu-inference/kv-cache-deep-dive.md)
- [02-single-gpu-inference/paged-attention.md](02-single-gpu-inference/paged-attention.md)
- [02-single-gpu-inference/continuous-batching.md](02-single-gpu-inference/continuous-batching.md)
- [02-single-gpu-inference/vllm-architecture.md](02-single-gpu-inference/vllm-architecture.md)
- [03-multi-gpu-inference/tensor-parallelism.md](03-multi-gpu-inference/tensor-parallelism.md)
- [03-multi-gpu-inference/pipeline-parallelism.md](03-multi-gpu-inference/pipeline-parallelism.md)
- [03-multi-gpu-inference/nccl-communication.md](03-multi-gpu-inference/nccl-communication.md)

### Round 2: 深层优化
- [02-single-gpu-inference/flash-attention.md](02-single-gpu-inference/flash-attention.md)
- [04-fine-tuning/lora-qlora-principles.md](04-fine-tuning/lora-qlora-principles.md)
- [04-fine-tuning/sft-data-engineering.md](04-fine-tuning/sft-data-engineering.md)
- [04-fine-tuning/rlhf-dpo-theory.md](04-fine-tuning/rlhf-dpo-theory.md)
- [04-fine-tuning/distributed-training.md](04-fine-tuning/distributed-training.md)
- [05-serving-optimization/scheduling-strategies.md](05-serving-optimization/scheduling-strategies.md)
- [05-serving-optimization/latency-throughput.md](05-serving-optimization/latency-throughput.md)
- [05-serving-optimization/quantization-deploy.md](05-serving-optimization/quantization-deploy.md)
- [05-serving-optimization/speculative-decoding.md](05-serving-optimization/speculative-decoding.md)

### Round 3: 生产加固
- [06-production/docker-basics.md](06-production/docker-basics.md)
- [06-production/containerization.md](06-production/containerization.md)
- [06-production/monitoring-observability.md](06-production/monitoring-observability.md)
- [06-production/fault-tolerance.md](06-production/fault-tolerance.md)

### Round 4: 应用层扩展
- [07-application-layer/openai-api-protocol.md](07-application-layer/openai-api-protocol.md)
- [07-application-layer/rag-pipeline.md](07-application-layer/rag-pipeline.md)
- [07-application-layer/agent-function-calling.md](07-application-layer/agent-function-calling.md)
- [07-application-layer/multimodal-deploy.md](07-application-layer/multimodal-deploy.md)
- [06-production/security.md](06-production/security.md)

### 进阶篇
- [08-advanced/tensorrt-llm-triton.md](08-advanced/tensorrt-llm-triton.md)
- [08-advanced/nsight-profiling.md](08-advanced/nsight-profiling.md)
- [08-advanced/k8s-gpu-orchestration.md](08-advanced/k8s-gpu-orchestration.md)

### 综合指南
- [production-deployment-guide.md](production-deployment-guide.md)
- [skill-gap-analysis.md](skill-gap-analysis.md)

---

## 代码产出

| 模块 | 文件 | 功能 |
|------|------|------|
| 网关 | `src/gateway/main.py` | API 网关：多模型路由 + 限流 |
| 网关 | `src/gateway/ratelimit.py` | Token Bucket 限流器 |
| 网关 | `src/gateway/security.py` | 安全中间件（注入检测） |
| 网关 | `src/gateway/client.py` | 带重试的 LLM Client |
| RAG | `src/rag/embedding_service.py` | BGE Embedding 服务 |
| RAG | `src/rag/rag_pipeline.py` | RAG 完整管线 |
| RAG | `src/rag/chunker.py` | 文档智能切分器 |
| Agent | `src/agent/tool_server.py` | 工具定义 + 执行 |
| Agent | `src/agent/agent_loop.py` | ReAct Agent 主循环 |
| 压测 | `src/benchmark/run_benchmark.py` | 并发压测脚本 |

## 运维脚本

| 脚本 | 功能 |
|------|------|
| `scripts/check_env.sh` | 环境检查 |
| `scripts/deploy_vllm.sh` | 单卡 vLLM 部署 |
| `scripts/deploy_vllm_multigpu.sh` | 多卡 TP 部署 |
| `scripts/benchmark.sh` | 压测脚本 |
| `scripts/health_monitor.sh` | 健康检查 + 自动重启 |
| `scripts/manage.sh` | Docker Compose 管理 |

## 配置文件

| 文件 | 功能 |
|------|------|
| `configs/nginx.conf` | Nginx 负载均衡 |
| `configs/prometheus.yml` | Prometheus 抓取配置 |
| `configs/docker-compose.yml` | 服务编排 |
| `configs/qwen2.5_7b_lora.yaml` | LoRA 微调配置 |
```
