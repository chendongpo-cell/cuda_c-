# GPU 显存模型

## 一句话总结
GPU 有 HBM(大容量慢)、L2 Cache(中)、Shared Memory(小快)、Register(最小最快) 四层存储。推理时：模型参数 + KV Cache + 中间激活 + 框架开销 共用 HBM 80GB。

## A800 硬件规格

```
A800 GPU 芯片 (80GB HBM2e)
├── 计算核心
│   ├── 6912 CUDA Cores (FP32)
│   ├── 3456 CUDA Cores (FP64)
│   └── 432 Tensor Cores (第3代，支持 FP16/BF16/INT8/INT4/TF32)
│
├── 存储层次 (越往上越快、越小)
│   ┌──────────────────────────────────────┐
│   │  Register File (每 SM)                │  ← 256KB/SM, 最快
│   ├──────────────────────────────────────┤
│   │  SMEM / Shared Memory (每 SM)         │  ← 164KB/SM, ~20TB/s
│   │  FlashAttention 核心利用此层做 tile     │
│   ├──────────────────────────────────────┤
│   │  L2 Cache (所有 SM 共享)               │  ← 40MB, ~4TB/s
│   ├──────────────────────────────────────┤
│   │  HBM2e / Global Memory               │  ← 80GB, ~2TB/s 带宽
│   │  模型参数 + 激活 + KV Cache 都在这里     │
│   └──────────────────────────────────────┘
│
└── NVLink Bridge (400GB/s 双向 × 每卡)
    → 连接其他 A800，实现跨卡显存访问
```

## 推理显存分配公式

### 1. 模型参数
```
Model_Params = num_params × bytes_per_param

例: Qwen2.5-7B (70亿参数), FP16
  = 7 × 10^9 × 2 bytes
  = 14 GB

例: Qwen2.5-72B, FP16
  = 72 × 10^9 × 2 bytes
  = 144 GB
```

### 2. KV Cache
```
KV_Cache = 2 × num_layers × num_kv_heads × head_dim × seq_len × batch × bytes_per_elem

# GQA 减少了 KV heads 数量！
# Qwen2.5-7B: 28 个 Q heads，但只有 4 个 KV heads (GQA ratio = 7:1)

例: Qwen2.5-7B, seq_len=4096, batch=8, FP16
  = 2 × 32 layers × 4 kv_heads × 128 head_dim × 4096 seq × 8 batch × 2 bytes
  = 2 × 32 × 4 × 128 × 4096 × 8 × 2
  ≈ 2.1 GB

例: 同样条件但 seq_len=32768 (长上下文)
  = 2.1 GB × (32768/4096) ≈ 16.8 GB
```

### 3. 中间激活 + 框架开销
```
Activations ≈ 1-4 GB (取决于 batch_size 和 seq_len)
Overhead ≈ 1-2 GB (CUDA context + workspace)
```

### 4. 总显存预算表

| 模型 | 精度 | 参数 | KV Cache (4K,bs=8) | 总计 | 最低 GPU 配置 |
|------|------|------|---------------------|------|-------------|
| Qwen2.5-7B | FP16 | 14 GB | ~2 GB | **~18 GB** | 1×A800 或 1×24GB |
| Qwen2.5-7B | INT4 | 3.5 GB | ~2 GB | **~7 GB** | 1×RTX 3060 12GB |
| Qwen2.5-14B | FP16 | 28 GB | ~3 GB | **~33 GB** | 1×A800 |
| Qwen2.5-72B | FP16 | 144 GB | ~16 GB | **~170 GB** | 4×A800 (TP=4) |
| Qwen2.5-72B | INT4 | 36 GB | ~16 GB | **~60 GB** | 1×A800 |
| DeepSeek-V2-Lite | FP16 | ~32 GB | ~8 GB | **~45 GB** | 1×A800 |

## 存储层次的数据流

一次 Attention 计算的数据流动：

```
1. Load Q, K, V: HBM → L2 Cache → SMEM        (读：慢→快)
2. Compute Q×K^T: Tensor Cores, 数据在 SMEM     (计算：最快)
3. Softmax: SMEM 内完成                         (不写中间结果)
4. Compute Attn×V: SMEM 内完成                  (不写中间结果)
5. Write Output: SMEM → L2 → HBM               (写：快→慢)

标准Attention: 步骤2的中间矩阵(N×N)要写回HBM → 慢 + 占显存
FlashAttention: 分块在SMEM内完成步骤2-4 → 快 + 不占额外显存
```

## 为什么 GQA 省显存

```
普通 Multi-Head Attention (MHA):
  Q: 28 heads × 128 dim = 3584
  K: 28 heads × 128 dim = 3584    → KV Cache = 28 × 2 = 56 个向量/层
  V: 28 heads × 128 dim = 3584

Grouped Query Attention (GQA, Qwen2.5-7B):
  Q: 28 heads × 128 dim = 3584
  K: 4 heads × 128 dim = 512      → KV Cache = 4 × 2 = 8 个向量/层
  V: 4 heads × 128 dim = 512
  节省: (28-4)/28 = 85.7%  KV Cache 减少

Qwen2.5-72B (GQA ratio = 64/8 = 8):
  KV Cache 减少 87.5%
```

## 查看显存使用

```bash
# 实时监控所有 GPU
watch -n 1 nvidia-smi

# 只看显存数值
nvidia-smi --query-gpu=index,memory.used,memory.total,memory.free --format=csv

# 查看进程级显存占用
nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,noheader
```

```python
# PyTorch 内查看
import torch
print(f"Allocated: {torch.cuda.memory_allocated()/1024**3:.2f} GB")    # 实际分配
print(f"Cached:    {torch.cuda.memory_reserved()/1024**3:.2f} GB")    # 缓存池
print(f"Max Alloc: {torch.cuda.max_memory_allocated()/1024**3:.2f} GB") # 峰值

# 清空缓存
torch.cuda.empty_cache()
```

## 实战验证

```bash
# 本机当前 GPU 显存分布 (2026-07-17)
nvidia-smi --query-gpu=index,memory.used,memory.total --format=csv,noheader
# 0: ~22GB / 80GB  ← 最空闲，可跑 7B
# 1: ~22GB / 80GB
# 2: ~81GB / 80GB  ← DeepSeek 32B TP
# 3: ~64GB / 80GB
# 4: ~39GB / 80GB  ← vLLM-Omni TTS
# 5: ~78GB / 80GB  ← vLLM Qwen 35B GPTQ
# 6: ~78GB / 80GB  ← vLLM Qwen 35B GPTQ
# 7: ~78GB / 80GB  ← vLLM Qwen 35B GPTQ
```
