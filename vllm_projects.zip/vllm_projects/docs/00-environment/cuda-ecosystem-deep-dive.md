# CUDA 生态深度解析

## 一句话总结
CUDA 不只是"用 GPU 跑 PyTorch"。从底层到上层：PTX 指令 → SASS 机器码 → CUDA Kernel → CUDA Stream 并发 → CUDA Graph 图优化 → Tensor Core 矩阵加速 → cuBLAS/cuDNN 算子库 → PyTorch → vLLM。理解这一整条链才能真正做好推理优化。

## CUDA 编程模型

### Kernel Launch

```cpp
// CUDA C++ 代码
__global__ void vec_add(float* a, float* b, float* c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) c[i] = a[i] + b[i];
}

// 启动: 256 个线程/block, 需要 (n+255)/256 个 block
vec_add<<<(n+255)/256, 256>>>(a, b, c, n);
```

### 线程层次

```
Grid (一次 kernel launch)
├── Block 0
│   ├── Thread 0 ── Thread 31  (Warp 0)
│   ├── Thread 32 ── Thread 63 (Warp 1)
│   └── ...
├── Block 1
│   └── ...
└── Block N
    └── ...

关键概念:
- Warp: 32 个线程一组，GPU 的调度和执行单位
- SM (Streaming Multiprocessor): 管理多个 warp，A800 有 108 个 SM
- 每个 SM 同时运行多个 warp → 隐藏内存延迟
```

### SM 内部工作原理

```
一个 SM (Streaming Multiprocessor) 内部:

┌─ Warp Scheduler ─────────────────────────┐
│  管理 64 个 warp (2048 个线程)             │
│  每周期挑一个 ready 的 warp 发给执行单元   │
└──────────────┬───────────────────────────┘
               ↓
┌─ 执行单元 ────────────────────────────────┐
│  FP32 Core × 64    (单精度浮点)           │
│  FP64 Core × 32    (双精度浮点)           │
│  Tensor Core × 4   (矩阵乘加, 第3代)      │
│  LD/ST Unit × 16   (数据加载/存储)        │
│  SFU × 16          (特殊函数 sin/cos/exp) │
└───────────────────────────────────────────┘
               ↓
┌─ 存储 ───────────────────────────────────┐
│  Register: 256KB/SM    (最快)            │
│  SMEM:    164KB/SM     (Shared Memory)   │
│  L1 Cache: 192KB/SM    (数据缓存)        │
└───────────────────────────────────────────┘

延迟隐藏:
  一个 warp 等内存 → 调度器切换到另一个 warp
  这叫 "zero-overhead thread scheduling"
  所以 GPU 不怕高延迟，只怕没足够多的 warp 可切
```

## Tensor Core 原理

### 为什么有 Tensor Core

```
FP32 Core: 每个周期做 1 次 FMA (Fused Multiply-Add)
  → 一个 SM 有 64 个 FP32 core
  → 每周期 64 次 FMA

Tensor Core: 每个周期做 1 次 4×4×4 矩阵乘法
  → 相当于 4×4×4×2 = 128 次 FMA
  → 一个 SM 有 4 个 Tensor Core
  → 每周期 4×128 = 512 次 FMA
  → 比 FP32 core 快 8 倍！
```

### Tensor Core 支持的数据类型

```
A800 第3代 Tensor Core 支持:
  FP64  → 2×  加速
  FP32  → 8×  加速
  TF32  → 8×  加速 (FP32 范围 + FP16 精度, PyTorch 默认)
  BF16  → 16× 加速 (训练推荐)
  FP16  → 16× 加速 (推理常用)
  INT8  → 32× 加速 (量化推理)
  INT4  → 64× 加速 (量化推理)
  FP8   → 32× 加速 (H100 起)

加速倍数 = 相对于 FP32 Core 的吞吐
```

### 推理如何用到 Tensor Core

```python
# PyTorch 中自动使用 Tensor Core:
# torch.matmul(Q, K) 在 BF16/FP16 下自动走 Tensor Core

# vLLM 中:
# PagedAttention 实现的 attention kernel
# 也是用 Tensor Core 算矩阵乘法
# 所以即使 Decode 阶段是 memory-bound,
# 矩阵乘法本身还是很快的 (瓶颈在 HBM 带宽, 不在算力)
```

## CUDA Stream 和并发

### 问题

```python
# 默认 Stream (Stream 0): 所有操作排队
a = model(x)      # ← 等这个算完
b = model(y)      # ← 才能算这个
# 即使有两个 batch 完全独立, 也要排队
```

### 解决: 多 Stream

```python
stream1 = torch.cuda.Stream()
stream2 = torch.cuda.Stream()

with torch.cuda.stream(stream1):
    a = model(x)      # ← Stream 1 上算
with torch.cuda.stream(stream2):
    b = model(y)      # ← Stream 2 上同时算 (如果显存够)

torch.cuda.synchronize()  # 等两个都完成
```

### 推理中的应用

```
vLLM 可以利用多 Stream:
  Stream 1: Decode batch A
  Stream 2: Prefill batch B
  同时执行 → GPU 利用率更高

Copy/Compute Overlap:
  Stream 1: HBM → SMEM (加载数据)
  Stream 2: 计算上一个 chunk
  → 加载和计算重叠 → 隐藏内存延迟
```

## CUDA Graph

### 问题

```
推理时每次调用 kernel 都有 launch overhead:
  1. CPU 提交 kernel 到 GPU
  2. GPU 调度执行
  3. 返回结果

每次 launch overhead ≈ 5-10μs
如果每秒 launch 10000 次 → 浪费 50-100ms
对于 decode (每 token 都要 launch 多次 kernel)
→ overhead 占比不小
```

### 解决: CUDA Graph

```
第1次: 录制整个计算图
  graph = torch.cuda.CUDAGraph()
  with torch.cuda.graph(graph):
      output = model(input)     # 录制, 不是执行

第2次及以后: 直接 replay
  input.copy_(new_data)
  graph.replay()                # 一次性提交整个图 → 没有 per-kernel overhead
```

### 推理收益

```
首 token (Prefill): 正常执行 (需要构建 KV Cache)
后续 token (Decode): CUDA Graph replay
  → launch overhead 从 ~50μs 降到 ~5μs
  → 每 token 节省 ~45μs
  → 生成 1000 token 节省 ~45ms

vLLM 默认开启了 CUDA Graph:
  --enforce-eager  # 关闭 CUDA Graph (本机 vLLM-Omni 就用了这个)
```

## PTX vs SASS

```
CUDA 编译流水线:
  .cu 文件 → nvcc → PTX (中间表示) → ptxas → SASS (机器码)
                         ↓                      ↓
                    跨GPU通用              特定GPU架构优化
                    (虚拟指令集)            (真实机器指令)

PTX (Parallel Thread Execution):
  - 类汇编的中间表示
  - 跨架构兼容 (A100 的 PTX 可以跑在 H100 上, JIT 编译)

SASS (Shader Assembly):
  - 真正的 GPU 机器码
  - 架构特定 (A100 的 SASS 不能在 H100 上运行)
  - 用 cuobjdump 可以反编译查看

为什么关心?
  - FlashAttention 手写了 PTX 来精细控制 SMEM 和寄存器
  - vLLM 的某些 CUDA kernel 也手写了 PTX 优化
```

## 推理用到的关键 CUDA 库

| 库 | 功能 | 推理中的角色 |
|----|------|------------|
| **cuBLAS** | 矩阵乘法 GEMM | Attention 的 Q×K、Attn×V；FFN 层的所有矩阵乘法 |
| **cuDNN** | 深度学习原语 | 卷积、归一化、激活函数（CNN 模型用到）|
| **cuBLASLt** | 高级矩阵乘法 | 混合精度 GEMM（FP16 输入，FP32 累加）|
| **NCCL** | 多 GPU 通信 | TP 的 AllReduce |
| **cuFFT** | 快速傅里叶变换 | 某些特殊模型用到 |
| **CUTLASS** | 模板库 | 自定义 GEMM kernel（vLLM 用于 PagedAttention）|

## 推理优化手段与 CUDA 的对应关系

```
推理优化                用到的 CUDA 技术
────────                ────────────────
FlashAttention          SMEM tiling + 手写 PTX
PagedAttention          CUTLASS 自定义 GEMM
Continuous Batching     多 Stream 并发
KV Cache FP8            低精度 Tensor Core
Tensor Parallelism      NCCL AllReduce (NVLink)
CUDA Graph              CUDAGraph capture + replay
量化推理 (INT4/INT8)     Tensor Core INT8/INT4 指令
torch.compile           CUDA Graph + Triton
```

## 查看本机 CUDA 生态

```bash
# CUDA 版本
nvcc --version                   # 12.6
nvidia-smi --query-gpu=compute_cap --format=csv,noheader  # A800: 8.0

# CUDA 库版本
ls /usr/local/cuda/lib64/libcublas.so*      # cuBLAS
ls /usr/local/cuda/lib64/libcudnn.so*       # cuDNN
ls /usr/local/cuda/lib64/libnccl.so*        # NCCL

# Tensor Core 是否启用
python3 -c "import torch; print(torch.backends.cuda.matmul.allow_tf32)"  # True = 在用
python3 -c "import torch; print(torch.backends.cudnn.allow_tf32)"        # True = 在用

# CUDA Graph 是否启用 (vLLM)
# 如果启动日志里没有 "CUDA graph" 相关错误 → 默认启用
# 如果指定了 --enforce-eager → 关闭
```

## 下载源

```bash
# CUDA Toolkit
wget https://developer.download.nvidia.com/compute/cuda/12.4.0/local_installers/cuda_12.4.0_550.54.14_linux.run
# 选择页面: https://developer.nvidia.com/cuda-downloads

# cuDNN (需要注册)
# https://developer.nvidia.com/cudnn

# NCCL
# https://developer.nvidia.com/nccl
```
