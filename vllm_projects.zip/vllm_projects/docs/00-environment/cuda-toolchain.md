# CUDA 工具链层次关系

## 一句话总结
CUDA 工具链从上到下：PyTorch → cuDNN/cuBLAS → CUDA Toolkit → NVIDIA Driver → GPU。每层独立版本号，必须兼容。

## nvidia-smi 三行解读

```
$ nvidia-smi
NVIDIA-SMI 535.171.04       ← SMI 工具版本（nvidia-smi 这个命令的版本号）
Driver Version: 535.171.04  ← 内核驱动版本（真正操作硬件的内核模块）
CUDA Version: 12.2          ← 该 Driver 最高支持的 CUDA API 版本（天花板）
```

**通俗类比：**
- Driver = 操作系统（Windows 11）
- CUDA Version (12.2) = 系统支持的最高 API（DirectX 12.2）
- nvidia-smi = 任务管理器（告诉你系统版本+资源使用）
- PyTorch + CUDA runtime = 游戏（需要兼容的操作系统版本）

## 五层架构

```
┌────────────────────────────────┐
│  你的 Python 代码               │  import torch; model()
├────────────────────────────────┤
│  PyTorch (libtorch)            │  torch.cuda 模块
│  自带 CUDA runtime             │  torch.version.cuda → 12.4
├────────────────────────────────┤
│  cuDNN / cuBLAS / cuFFT        │  NVIDIA 优化算子库
├────────────────────────────────┤
│  CUDA Toolkit (nvcc)           │  编译器 + 开发工具
│  本机: nvcc 12.6.77            │  /usr/local/cuda/
├────────────────────────────────┤
│  NVIDIA Driver (kernel module) │  内核模块，直接操作硬件
│  本机: 535.171.04              │  支持 CUDA API: 最高 12.2
├────────────────────────────────┤
│  GPU 硬件                       │  8× A800 80GB HBM2e
└────────────────────────────────┘
```

## 三个关键版本号

| 命令 | 输出版本 | 含义 |
|------|---------|------|
| `nvidia-smi` | CUDA Version: **12.2** | Driver 支持的 **最高** CUDA API 版本（天花板） |
| `nvcc --version` | CUDA **12.6.77** | 系统安装的 CUDA Toolkit 编译器版本 |
| `torch.version.cuda` | **12.4** | PyTorch 编译时链接的 CUDA 运行时版本 |

## 版本兼容规则

核心规则：
```
PyTorch CUDA 版本 必须 ≤ Driver 支持的 CUDA 版本（同大版本号可向前兼容）
```

### 本机实测

| PyTorch 版本 | 结果 | 原因 |
|-------------|------|------|
| 2.12.0+cu130 (CUDA **13.0**) | ❌ GPU 不可用 | 13.0 > 12.2，大版本号跳跃，Driver 不认识 |
| 2.5.1+cu124 (CUDA **12.4**) | ✅ 正常 | 同大版本(12.x)，NVIDIA minor version 向前兼容 |
| 2.3.0+cu121 (CUDA **12.1**) | ✅ 正常 | 12.1 ≤ 12.2，完美匹配 |

### Forward Compatibility（向前兼容）
NVIDIA 的 minor version compatibility 机制：CUDA 12.x 的应用可以在任意 CUDA 12.x 驱动上跑。但大版本号跳跃（12→13）不行。所以 PyTorch 2.12+cu130 在 Driver 535 (CUDA 12.2) 上挂掉了。

## 常见问题排查

### 1. CUDA 不可用
```python
import torch
torch.cuda.is_available()  # → False
```
**排查步骤：**
```
nvidia-smi                           # 检查驱动是否正常
torch.version.cuda                   # 看 PyTorch CUDA 版本
# 如果 PyTorch CUDA > Driver CUDA → 降级 PyTorch
```

### 2. 多 CUDA 版本共存
本机可同时装多个 CUDA Toolkit：
```bash
ls /usr/local/cuda*           # cuda-12.4/  cuda-12.6/
ls -l /usr/local/cuda         # → 软链接指向默认版本
```
PyTorch 自带 CUDA runtime，不依赖系统 `/usr/local/cuda`。但 Driver 版本是所有版本的硬上限。

### 3. Docker 里的 CUDA
```bash
docker run --gpus all nvidia/cuda:12.4.0-runtime-ubuntu22.04 nvidia-smi
# 容器内 nvidia-smi 的 Driver/CUDA Version 来自宿主机
# 容器不需要装驱动，只需要 CUDA 库
```

---

## 下载源记录（已验证可用）

### PyTorch
```bash
# ✅ CUDA 12.4 (推荐，兼容 Driver 535)
pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cu124
# whl 地址: https://download.pytorch.org/whl/cu124/torch-2.5.1%2Bcu124-cp310-cp310-linux_x86_64.whl
# 大小: ~908 MB

# CUDA 12.1 (最保守，完全匹配 Driver)
pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cu121

# CUDA 11.8 (老旧GPU兼容)
pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cu118
```

### PyTorch 官网版本选择器
```
https://pytorch.org/get-started/locally/
```

---

## 本机环境卡片

| 项目 | 值 |
|------|-----|
| GPU | 8× NVIDIA A800 80GB PCIe |
| Driver | 535.171.04 |
| Driver CUDA 上限 | 12.2 |
| 系统 CUDA Toolkit (nvcc) | 12.6.77 |
| Conda 环境 | `cdp310_gpu` (Python 3.10.10) |
| 当前 PyTorch | 2.5.1+cu124 |
| CUDA 可用 | ✅ True |
