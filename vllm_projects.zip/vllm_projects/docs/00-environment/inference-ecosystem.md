# 推理框架生态

## 一句话总结
主流推理框架分两大类：高性能服务框架（vLLM/SGLang/TGI）和轻量本地框架（Ollama/llama.cpp）。生产环境首选 vLLM，本地测试首选 Ollama。

## 框架对比总览

| 框架 | 作者 | 核心语言 | 核心技术 | 适合场景 |
|------|------|---------|---------|---------|
| **vLLM** | UC Berkeley | Python/C++ | PagedAttention, Continuous Batching | 生产级高吞吐 API |
| **SGLang** | Stanford/UCB/CMU | Python | RadixAttention, SGLang DSL | 复杂 prompt 编程 |
| **TGI** | HuggingFace | Rust/Python | HF 生态深度集成 | HuggingFace 用户 |
| **Ollama** | 社区 | Go | llama.cpp 封装，一键部署 | 本地开发测试 |
| **llama.cpp** | ggerganov | C++ | GGUF 量化，纯 CPU 推理 | 消费硬件/边缘 |
| **TensorRT-LLM** | NVIDIA | C++/Python | TensorRT 编译优化 | 极致性能需求 |

## vLLM — 生产服务首选

### 核心创新

**1. PagedAttention — KV Cache 分页管理**
- 类比操作系统虚拟内存：KV Cache 切成固定大小的 block
- Block Table 映射逻辑块→物理块（物理块可以不连续）
- 显存利用率从 ~40% → ~96%
- 零内部碎片，按需分配

**2. Continuous Batching — 动态请求拼接**
- 传统静态 batching：等一批请求全部完成才能换新请求
- Continuous Batching：随时有新请求加入、完成的请求退出
- GPU 利用率最大化

**3. 性能数据 (vLLM 论文)**
- 比 HuggingFace Transformers 快 **24 倍**
- 比 TGI 快 **2-3 倍**（同等硬件条件）

### 启动命令

```bash
# 基础单卡部署
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --host 0.0.0.0 \
    --port 8000

# 多卡张量并行
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --tensor-parallel-size 4 \
    --port 8001

# 开启所有优化
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --enable-prefix-caching \        # 前缀缓存
    --enable-chunked-prefill \       # 分块 prefill
    --max-num-seqs 128               # 最大并发
```

### Docker 部署

```bash
# vLLM 官方 Docker 镜像
docker run --gpus all \
    -v /path/to/models:/models \
    -p 8000:8000 \
    vllm/vllm-openai:latest \
    --model /models/Qwen2.5-7B-Instruct

# vLLM-Omni (多模态版)
docker run --gpus all \
    -v /path/to/models:/model \
    -p 8092:8092 \
    vllm/vllm-omni:v0.22.0 \
    vllm serve /model --port 8092
```

## SGLang — 结构化生成专家

### 核心创新

**1. RadixAttention — 基数树前缀缓存**
- 比 vLLM 的 Prefix Caching 更精细（Radix Tree 数据结构）
- 自动识别共享前缀的子树，最大化 KV Cache 复用

**2. SGLang DSL**
```python
# SGLang 的领域特定语言，简化复杂 prompt 编程
@function
def multi_turn(s):
    s += system("你是一个编程助手")
    s += user("写一个快速排序")
    s += assistant(gen("code", max_tokens=500))
    s += user("加上注释")
    s += assistant(gen("code_with_comments", max_tokens=600))
```

**3. 结构化输出**
- JSON 模式、Regex 约束、Grammar 约束
- 适合需要严格格式输出的场景

### 启动命令

```bash
python3 -m sglang.launch_server \
    --model /path/to/model \
    --host 0.0.0.0 \
    --port 30000
```

## Ollama — 本地开发利器

### 特点
- 一条命令启动：`ollama run qwen2.5:7b`
- Modelfile（类 Dockerfile 的模型配置）
- 自动下载 + 量化 + 服务化
- 内置 REST API（兼容 OpenAI 格式）

### 常用命令

```bash
# 下载并运行
ollama run qwen2.5:7b

# 列出本地模型
ollama list

# 自定义 Modelfile
cat > Modelfile << 'EOF'
FROM qwen2.5:7b
SYSTEM "你是一个专业的Python编程助手"
PARAMETER temperature 0.3
PARAMETER num_ctx 8192
EOF
ollama create my-qwen -f Modelfile

# API 调用
curl http://localhost:11434/v1/chat/completions \
  -d '{"model":"qwen2.5:7b","messages":[{"role":"user","content":"Hello"}]}'
```

## llama.cpp — 纯 CPU/边缘推理

### 特点
- 纯 C++ 实现，无 Python 依赖
- GGUF 量化格式（支持 2-8 bit）
- 支持 CPU + GPU 混合推理（部分层在 GPU）
- Metal/CUDA/Vulkan 多种后端

### 常用命令

```bash
# 下载 GGUF 模型
wget https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF/resolve/main/qwen2.5-7b-instruct-q4_k_m.gguf

# CPU 推理
./llama-cli -m qwen2.5-7b-instruct-q4_k_m.gguf -p "你好" -n 100

# GPU offload (部分层在 GPU)
./llama-cli -m model.gguf -p "Hello" -ngl 32  # 32层在 GPU
```

## 选型决策树

```
需要生产级高吞吐 API？
├── Yes → GPU 是 NVIDIA？
│         ├── Yes → 需要极致性能？
│         │         ├── Yes → TensorRT-LLM (需编译优化)
│         │         └── No  → vLLM (推荐)
│         └── No  → llama.cpp (通用后端)
├── No  → 本地开发测试？
│         └── Ollama (最方便)
└── 需要复杂 prompt / 结构化输出？
    └── SGLang
```

## 下载源记录

### vLLM
```bash
pip install vllm
# PyPI: https://pypi.org/project/vllm/
# 文档: https://docs.vllm.ai/
```

### vLLM Docker 镜像
```bash
docker pull vllm/vllm-openai:latest
# Docker Hub: https://hub.docker.com/r/vllm/vllm-openai

# 多模态版 (本机正在使用)
docker pull vllm/vllm-omni:v0.22.0
# Docker Hub: https://hub.docker.com/r/vllm/vllm-omni
# 本机已拉取: d63693f510d6, 26.1GB
```

### Ollama
```bash
curl -fsSL https://ollama.com/install.sh | sh
# 官网: https://ollama.com/
```

### llama.cpp
```bash
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp && make
# GitHub: https://github.com/ggerganov/llama.cpp
```

---

## 本机现有推理服务

| 端口 | 模型 | 部署方式 | 框架 | GPU |
|------|------|---------|------|-----|
| 8001 | Qwen3.5-35B-GPTQ-Int4 | venv 直跑 | vLLM | GPU 6-7 |
| 8002 | 同上 | venv 直跑 | vLLM | GPU 5-6 |
| 8091 | vLLM-Omni (TTS) | Docker | vLLM-Omni | GPU 4 |
| 8092 | vLLM-Omni (OCR) | Docker | vLLM-Omni | GPU 0/4 |
| 9003 | DeepSeek-32B (TP=2) | venv 直跑 | vLLM | GPU 2-3 |

**关键发现：**
- 8001 和 8002 的 vLLM 命令使用了 `--enable-auto-tool-choice --tool-call-parser hermes`
- Docker 版 vLLM-Omni 使用镜像 `vllm/vllm-omni:v0.22.0`（26.1GB）
- 有现成的 DCGM Exporter（GPU 监控）在运行：`nvidia/dcgm-exporter:4.1.1-4.0.4-ubuntu22.04:9400`
