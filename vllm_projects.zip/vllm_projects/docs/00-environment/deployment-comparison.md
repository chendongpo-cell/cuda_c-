# 部署方式对比：Docker vs pip vs 源码

## 一句话总结
Docker（完整环境，开箱即用）、pip（轻量灵活，需自己配环境）、源码（可以改代码调试）。原理和执行代码完全一样，只是"怎么把 vLLM 装到机器上"不同。

## 三种方式对比

```
源码编译                     pip wheel                    Docker 镜像
─────────                    ────────                    ──────────
git clone                    pip install vllm            docker pull vllm/...
pip install -e .             ↓                           ↓
    ↓                       下载 .whl (~200MB)          下载镜像 (~26GB)
编译 C++/CUDA 扩展           ↓                           ↓
    ↓                       安装到 site-packages         docker run --gpus all
python3 -m vllm...           ↓                           ↓
                           python3 -m vllm...          容器内 python3 -m vllm...
                          
环境: 自己全搞定             环境: 配 CUDA+PyTorch        环境: 镜像自带一切
适合: 开发/改代码            适合: 学习/轻量部署          适合: 生产部署
```

## 详细对比

| 维度 | Docker | pip wheel | 源码编译 |
|------|--------|-----------|---------|
| **安装速度** | `docker pull` 几分钟（取决于网速） | `pip install` 10-30秒 | `git clone + 编译` 10-30分钟 |
| **磁盘占用** | 26GB（完整镜像） | ~3-5GB（包+依赖） | ~5-10GB（源码+编译产物） |
| **CUDA 依赖** | 镜像自带 CUDA runtime | 系统和 PyTorch 的 CUDA 必须兼容 | 需要 CUDA Toolkit + 编译工具链 |
| **Python 依赖** | 镜像自带 Python | 需要自己管理 venv/conda | 需要自己管理 |
| **版本更新** | `docker pull` 最新 tag | `pip install --upgrade` | `git pull + 重新编译` |
| **环境隔离** | ✅ 完全隔离 | ❌ 和系统环境混在一起 | ❌ 和系统环境混在一起 |
| **多版本共存** | ✅ 不同容器不同版本 | ⚠️ 需要多个 venv | ⚠️ 需要多个 venv |
| **调试方便** | ❌ 需 `docker exec` 进去 | ✅ 直接改代码 | ✅ 直接改代码 |
| **性能** | ≈ 原生（GPU 透传） | 原生 | 原生 |
| **自定义** | 修改 Dockerfile | 改 site-packages 或 fork | ✅ 直接改源码 |
| **适合场景** | 生产、多服务、快速复现 | 学习、开发、单机 | 开发 vLLM 本身 |

## 本机三种方式的实际案例

```bash
# Docker 版 (本机正在跑)
docker run --gpus all \
    -v /path/to/model:/model \
    vllm/vllm-omni:v0.22.0 \
    vllm serve /model --port 8092
# 版本: 0.22.0, 大小: 26.1GB

# pip 版 (本机正在跑)
/data/dongshaoqi/venv2/bin/python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model --port 8001
# 版本: 0.18.1, 安装: pip install vllm

# 源码版 (如果要改 vLLM 代码)
git clone https://github.com/vllm-project/vllm.git
cd vllm
pip install -e .  # editable install, 改了代码立即生效
```

## 为什么 Docker 镜像那么大（26GB vs 200MB）

```
pip wheel (vllm-0.18.1-cp310-cp310-linux_x86_64.whl):  ~200MB
  └── 只有 vLLM 自己的 Python 代码 + 少量 .so

pip 安装后 (vllm + 所有依赖):  ~3-5GB
  ├── vLLM: ~200MB
  ├── torch: ~2.5GB
  ├── transformers: ~50MB
  ├── flash-attn: ~100MB
  ├── 其他 50+ 依赖: ~1GB
  └── 你的: Python + CUDA 系统级（不计入）

Docker 镜像 (vllm/vllm-omni:v0.22.0):  26.1GB
  ├── Ubuntu 22.04 base: ~2GB
  ├── CUDA 12.x runtime + libs: ~5GB
  ├── Python 3.10 + pip: ~500MB
  ├── vLLM + 60+ 依赖: ~5GB
  ├── flashinfer-cubin (预编译 CUDA kernel): ~3GB
  ├── PyTorch: ~3GB
  ├── 其他 CUDA kernel 库 (tokenspeed, tilelang, ...): ~5GB
  └── Docker layer 开销: ~2GB
```

## 选型指南

```
我需要改 vLLM 源码？      → 是 → 源码编译 (pip install -e .)
我需要快速复现/上线？     → 是 → Docker
我需要多个版本同时跑？     → 是 → Docker
我只有 CPU/无 root 权限？ → 是 → pip (venv)
我要学习/研究原理？       → 是 → pip (方便看代码/调试)
我要极致性能？            → 是 → Docker (有预编译高级 kernel)
```

## 原理完全相同

不管你用哪种方式部署，vLLM 执行的代码是一样的：

```python
# 不管是 Docker 还是 pip，底层都是这些:

# PagedAttention: 同样的分页算法
# Continuous Batching: 同样的调度策略
# KV Cache 管理: 同样的内存池
# Tensor Parallelism: 同样的 NCCL all-reduce
# OpenAI API: 同样的 /v1/chat/completions 端点

# 区别只在:
# Docker: /usr/local/lib/python3.10/site-packages/vllm/
# pip:    ~/miniconda3/envs/xxx/lib/python3.10/site-packages/vllm/
# 源码:   ~/vllm/vllm/
# ↑ 同一份代码装在三个不同位置
```

## 下载源

```bash
# Docker
docker pull vllm/vllm-openai:latest
# https://hub.docker.com/r/vllm/vllm-openai

# pip
pip install vllm
# https://pypi.org/project/vllm/

# 源码
git clone https://github.com/vllm-project/vllm.git
pip install -e ".[dev]"
```
