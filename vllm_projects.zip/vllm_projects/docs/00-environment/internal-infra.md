# 内网基础设施

> 本机可用的内网 RAG 和大模型服务。所有地址来自 office_config。

## 服务总览

```
┌─────────────────────────────────────────────────────────┐
│                    内网 AI 基础设施                       │
│                                                         │
│  10.210.48.94:31610     DeepSeek-Flash (LLM API)        │
│  10.210.52.229:6053     BGE-M3 Embedding                │
│  10.210.52.229:6054     BGE Reranker                    │
│  10.210.52.229:19530    Milvus 向量库 (1024维, COSINE)   │
│  10.210.52.229:6052     MySQL                           │
│  10.210.52.229:6051     Redis                           │
│  10.210.57.104:8081     私有 pip 源                      │
│  10.210.52.229:6056     Gitea (Git)                     │
│  10.210.52.229:6057     Jenkins (CI/CD)                 │
└─────────────────────────────────────────────────────────┘
```

## 各服务详情

### 大模型 API

```python
BASE_URL = "http://10.210.48.94:31610/"
API_KEY = "sk-3PicmJ3fzLeXB8hpKcDJgvGHpqdtOxr6x5UF2Xwg8IYzrH2D"
MODEL_NAME = "deepseek-flash"
FULL_API_URL = "http://10.210.48.94:31610/v1/chat/completions"

# 调用示例:
import requests
resp = requests.post(
    "http://10.210.48.94:31610/v1/chat/completions",
    headers={"Authorization": f"Bearer {API_KEY}"},
    json={
        "model": "deepseek-flash",
        "messages": [{"role": "user", "content": "你好"}],
        "max_tokens": 100
    }
)
```

### BGE-M3 Embedding

```python
BGE_API_URL = "http://10.210.52.229:6053/encode"
# 请求: POST {"texts": ["文本1", "文本2"]}
# 返回: {"embeddings": [[...1024维向量...], ...]}

import requests
resp = requests.post(BGE_API_URL, json={"texts": ["你好世界"]})
embedding = resp.json()["embeddings"][0]  # 1024维
```

### BGE Reranker

```python
RERANK_API_URL = "http://10.210.52.229:6054/rerank"
# 请求: POST {"query": "问题", "docs": ["文1","文2","文3"], "top_k": 3}

resp = requests.post(RERANK_API_URL, json={
    "query": "什么是Transformer",
    "docs": ["Transformer是一种...", "CNN用于图像...", "RNN处理序列..."],
    "top_k": 2
})
# 返回: [{"index": 0, "score": 0.95}, {"index": 2, "score": 0.32}]
```

### Milvus 向量库

```python
MILVUS_CONF = {
    "host": "10.210.52.229",
    "port": 19530,
    "uri": "http://10.210.52.229:19530",
    "dimension": 1024,           # BGE-M3 输出 1024 维
    "metric_type": "COSINE"
}

from pymilvus import connections, Collection
connections.connect(host=MILVUS_CONF["host"], port=MILVUS_CONF["port"])
# 集合命名: {项目名}_collection
```

### MySQL

```python
MYSQL_CONF = {
    "host": "10.210.52.229",
    "port": 6052,
    "user": "root",
    "password": "123456"
}
# 库名 = 项目名 (自动隔离)
```

### Redis

```python
REDIS_CONF = {
    "host": "10.210.52.229",
    "port": 6051,
    "password": "",
    "db": 0,
    "decode_responses": True
}
# Key 前缀: {项目名}:xxx (自动隔离)
```

## 和本机 vLLM 的配合

```
内网 LLM (DeepSeek-Flash)     本机 vLLM (Qwen3.5-35B)
─────────────────────────     ────────────────────────
远程 API 调用                 本地 GPU 推理
不需要 GPU                    需要 A800
共享资源, 可能有排队           独享资源
适合: 轻量调用, 原型验证      适合: 高并发, 长文本, 微调

可以混合使用:
  Embedding → 内网 BGE-M3 (不用占 GPU)
  Reranker  → 内网 BGE Reranker (不用占 GPU)
  向量存储  → 内网 Milvus
  LLM 生成  → 本机 vLLM (低延迟) 或 内网 DeepSeek (省显存)
```
