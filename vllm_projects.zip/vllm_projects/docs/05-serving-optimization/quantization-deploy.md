# 量化部署实践

## 一句话总结
生产环境推荐 AWQ（精度好+速度快），vLLM 原生支持 AWQ/GPTQ/FP8/SqueezeLLM。INT4 显存减少 75%，精度损失 <1%。本机已有 GPTQ-Int4 实例在跑。

## 各量化方法对比

| 方法 | 压缩比 | 精度损失 | 推理速度 | vLLM支持 |
|------|-------|---------|---------|---------|
| FP8 (W8A8) | 2× | <0.1% | +60-100% | ✅ |
| AWQ INT4 | 4× | <1% | +30-50% | ✅ |
| GPTQ INT4 | 4× | <1% | +30-50% | ✅ |
| GPTQ Marlin | 4× | <1% | +50-80% | ✅ (本机在用) |
| SqueezeLLM | 4× | <2% | +20-30% | ✅ |
| GGUF Q4_K_M | 4.5× | <2% | CPU推理 | ❌ (llama.cpp) |

## GPTQ vs AWQ 区别

```
GPTQ: 逐列量化 + Hessian-based 误差补偿
  - 需要校准数据（128个样本通常够）
  - 逐列做，每列量化后立即补偿剩余权重的误差
  - 时间: ~1-4小时 (7B在A800上)

AWQ: 基于激活值大小保护重要权重
  - 核心发现: 1%的"显著权重"对精度影响巨大
  - 对显著权重做 scaling 保护
  - 时间: ~10-30分钟 (更快)
  - 精度: 通常和GPTQ持平或更好

Marlin kernel: 专门优化的 INT4 GPU kernel
  本机用的 --quantization gptq_marlin → 这就是 GPTQ 模型用 Marlin kernel 跑
```

## vLLM 量化部署命令

```bash
# AWQ
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model-AWQ \
    --quantization awq

# GPTQ (Marlin kernel, 最推荐)
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model-GPTQ \
    --quantization gptq_marlin

# FP8 (需要模型本身支持FP8)
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model-FP8 \
    --quantization fp8

# 本机实际命令 (端口8001):
# vllm serve QwenQwen3.5-35B-A3B-GPTQ-Int4 \
#     --quantization gptq_marlin --gpu-memory-utilization 0.9
```

## 量化模型显存对比 (实测值)

| 模型 | FP16 | GPTQ-Int4 | 节省 |
|------|------|-----------|------|
| Qwen3.5-35B-GPTQ | ~70GB | **23GB** | 67% |
| Qwen2.5-7B | 14GB | ~3.5GB | 75% |
| Qwen2.5-72B | 144GB | ~36GB | 75% |

## FP8 KV Cache

```bash
# KV Cache 用量化减少显存
--kv-cache-dtype fp8    # KV Cache FP16→FP8, 减半

# 本机 vLLM-Omni 实例 (端口8091) 就在用:
# --kv-cache-dtype fp8 --gpu-memory-utilization 0.45
```

## 下载量化模型

```bash
# HuggingFace (需要网络)
# Qwen2.5-7B-AWQ: https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-AWQ
# Qwen2.5-7B-GPTQ-Int4: https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GPTQ-Int4

# ModelScope (国内)
python3 -c "
from modelscope import snapshot_download
snapshot_download('qwen/Qwen2.5-7B-Instruct-GPTQ-Int4', cache_dir='./models/')
"
```

## 自己量化模型

```bash
# 用 AutoAWQ 量化
pip install autoawq

python3 -c "
from awq import AutoAWQForCausalLM
from transformers import AutoTokenizer

model_path = '/path/to/fp16-model'
quant_path = '/path/to/output-awq'

model = AutoAWQForCausalLM.from_pretrained(model_path)
tokenizer = AutoTokenizer.from_pretrained(model_path)

model.quantize(tokenizer, quant_config={'zero_point': True, 'q_group_size': 128})
model.save_quantized(quant_path)
tokenizer.save_pretrained(quant_path)
"
```
