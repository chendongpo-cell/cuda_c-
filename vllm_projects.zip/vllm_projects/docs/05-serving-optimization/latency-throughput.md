# 延迟与吞吐优化

## 一句话总结
延迟和吞吐是一对矛盾。调 TTFT 看 Prefill 优化（batch size、prefix caching），调 TPOT 看 Decode 优化（KV Cache、内存带宽），调吞吐看调度参数（max-num-seqs）。

## 核心指标

| 指标 | 含义 | 受什么影响 |
|------|------|----------|
| **TTFT** | 首 token 延迟 | Prefill 计算量、排队时间、prefix cache 命中率 |
| **TPOT** | 每 output token 时间 | Decode 计算量、KV Cache 读取速度、batch 大小 |
| **Throughput** | 每秒产出 token 数 | batch 大小、GPU 利用率、调度效率 |
| **QPS** | 每秒处理请求数 | Throughput / 平均输出长度 |

## 优化决策树

```
TTFT 太高？
├── 检查是否有长 prompt → chunked-prefill
├── 检查 waiting 队列 → 增大 max-num-seqs
├── 检查 prefix cache hit rate → 开启 --enable-prefix-caching
└── 检查 GPU 利用率 → 增大 max-num-batched-tokens

TPOT 太高？
├── 检查 GPU 利用率 → 如果低 → memory-bound，正常
├── 检查 batch 是否太大 → 减少 max-num-seqs
├── 考虑量化 KV Cache (--kv-cache-dtype fp8)
└── 考虑 speculative decoding

Throughput 太低？
├── 检查 GPU 利用率 → 增大 max-num-seqs
├── 检查是否有 swap → 增大显存或减少并发
├── 考虑 Continuous Batching 参数调优
└── 考虑量化模型 (AWQ/GPTQ)
```

## 关键权衡

### 延迟 vs 吞吐
```
增大 max-num-seqs:
  Throughput ↑ (更多并发利用 GPU)
  TTFT ↑ (更多排队等待)
  TPOT ↑ (KV Cache 更大，显存带宽竞争)

减小 max-num-seqs:
  延迟 ↓ (少排队)
  Throughput ↓ (GPU 可能空转)
```

### 显存 vs 吞吐
```
增大显存占用:
  --gpu-memory-utilization 0.95 → 更多 KV Cache blocks → 更大 batch → 更高吞吐
  但风险: OOM 概率增大

减小显存占用:
  --gpu-memory-utilization 0.80 → 更安全
  但: 更少 KV Cache → 更小 batch → 更低吞吐
```

## 压测方法

```bash
# 1. 找最大吞吐
bash benchmark.sh localhost 8001 MODEL 200 inf
# --request-rate inf → 不限速，测系统上限

# 2. 找延迟-吞吐曲线
for rate in 1 2 4 8 16 32; do
    bash benchmark.sh localhost 8001 MODEL 100 $rate
done
# 记录每个 rate 下的 TTFT P95 和 Throughput

# 3. 找到 P95 延迟目标下的最大吞吐
# 例如: P95 TTFT < 500ms 时，最大 QPS 是多少
```

## 调优记录模板

```yaml
实验:
  模型: Qwen3-35B-GPTQ-Int4
  TP: 2 (GPU 5,6)
  GPU显存: 80GB×2

参数:
  max-num-seqs: 64
  max-num-batched-tokens: 8192
  gpu-memory-utilization: 0.90
  enable-prefix-caching: true

结果:
  Throughput: 419 tokens/s
  QPS: 3.28 req/s
  TTFT P50: 156ms
  TTFT P95: 212ms
  TPOT P50: 8ms
```

## 队列理论速查

```
Little's Law:
  L = λ × W
  L = 系统内请求数 (running + waiting)
  λ = 到达率 (QPS)
  W = 平均延迟

如果 P95 TTFT = 500ms, 期望 λ = 10 QPS:
  L = 10 × 0.5 = 5 个请求同时在系统内
  → max-num-seqs 设为 10-20 即可

如果 max-num-seqs=64, 期望 P95 TTFT < 1s:
  L = 64, W = 1 → λ_max = 64 QPS (理论上限)
  实际约为理论值的 50-70% = 30-45 QPS
```
