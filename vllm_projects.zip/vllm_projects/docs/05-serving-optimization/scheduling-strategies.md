# 调度策略

## 一句话总结
vLLM 调度器在每次 iteration 决定：哪些请求做 Prefill（计算密集）、哪些做 Decode（内存密集）、哪些被抢占。目标是最大化吞吐同时控制延迟。

## 调度器工作流程

```
每次 iteration:
1. 检查新请求 → 如果有，分配 KV Cache blocks
2. 如果显存不够 → Preemption (swap/recompute 低优先级请求)
3. 混合组 batch: [prefill_reqs..., decode_reqs...]
4. GPU 一次 forward
5. 完成的请求释放资源
6. 回到 1
```

## 关键参数

```bash
--max-num-seqs 128              # 最大并发序列数
--max-num-batched-tokens 8192   # 每次 iteration 最多处理 token 数
--max-paddings 256              # padding token 上限
--enable-chunked-prefill        # 分块 Prefill (避免长prompt阻塞)
```

## max-num-batched-tokens 的作用

```
假设 max-num-batched-tokens = 8192

Prefill: 一个 7000 token 的 prompt → 一次处理完 ✅
         一个 10000 token 的 prompt → 分两次 (7000 + 3000) ✅ (需 chunked-prefill)

Decode: running_seqs × 1 token/seq ≤ 8192
        即最多 8192 个序列同时 decode

经验值:
  max-num-batched-tokens ≈ max-num-seqs × 2  (保证 Prefill 有足够空间)
```

## 调度优先级

```
1. Swap-in requests: 之前被换出的请求，优先恢复
2. Waiting requests: 排队中的新请求 (Prefill)
3. Running requests: 正在 decode 的请求

为什么 Prefill 优先？
  Prefill 是 compute-bound → GPU 利用率高 → 尽快做完来减少等待
  Decode 是 memory-bound → 慢慢处理
```

## Chunked Prefill 详解

```
问题: 一个 100000 token 的 prompt 的 Prefill 会长时间阻塞其他请求

Chunked Prefill:
  chunk_size = min(max-num-batched-tokens, remaining_tokens)
  
  Iter 1: Prefill tokens 0-4095 (chunk)
  Iter 2: Decode + Prefill tokens 4096-8191
  Iter 3: Decode + Prefill tokens 8192-12287
  ...
  
好处: 不让一个超大请求独占 GPU
代价: 单请求的 TTFT 会增加 (但 P99 大幅改善)
```

## Prefix Caching 的调度影响

```
开启 --enable-prefix-caching 后:
  调度器会检查新请求的 prompt 是否和已有请求共享前缀
  如果命中 → 直接复用 KV Cache → 跳过 Prefill → TTFT 极低

适合场景:
  System prompt 很长 (>500 token) 且不变
  Few-shot examples 固定
  RAG 的 instruction prefix 固定
```

## 抢占 (Preemption)

```
当显存不够时:
  1. 选择优先级最低的请求 (排队最久的? 生成最多的?)
  2. Swap out: KV Cache 搬到 CPU 内存
  3. 或者 Recompute: 直接丢弃 KV Cache

Swap vs Recompute:
  --swap-space 4 (默认 4GB CPU swap)
  Swap: 快恢复（直接搬回来），但占 CPU 内存
  Recompute: 不占 CPU 内存，但恢复时要重算 Prefill
```

## 调优经验

| 场景 | max-num-seqs | max-num-batched-tokens | 理由 |
|------|-------------|----------------------|------|
| 短prompt高并发 | 128-256 | 4096 | 请求多但每个量小 |
| 长prompt少并发 | 16-32 | 16384 | 每个请求 token 多 |
| 混合 | 64-128 | 8192 | 默认平衡 |
| 显存紧张 | 减少 | 减少 | 先保证不OOM |
