# Speculative Decoding 深度解析

## 一句话总结
用小模型（Draft）快速生成候选 token 序列，大模型（Target）一次性并行验证。数学上保证输出分布和大模型完全一致（无损），加速比 2-3 倍。Draft 和 Target 越"像"、每次 Draft 越多，加速越明显。

## 为什么自回归生成慢

```
传统 Decode (自回归):
  Iter 1: Target("今天")       → "天气"    (1 token, 跑了一遍大模型)
  Iter 2: Target("今天天气")   → "怎么"    (又跑了一遍)
  Iter 3: Target("今天天气怎么") → "样"    (又双跑了一遍)
  ...

每次只产 1 个 token, 但每次都要:
  1. 把一个 token 的 embedding 传过所有层
  2. 读所有历史 KV Cache (2GB+)
  3. 做 Attention
  4. 算 softmax + sample

大模型跑一轮的时间 ≈ 10-50ms
但要跑几百次 → 几秒到几十秒

问题不是一步太慢，而是步数太多
→ 能不能一步多产几个 token?
```

## Speculative Decoding 原理

### 两步走

```
Step 1: Draft (小模型, 快速)
  小模型 (如 7B) 快速 "猜测" 接下来可能的 token 序列
  Draft: t1 → t2 → t3 → t4 → t5    (快速, 自回归)
  
  为什么快? 小模型 7B vs 大模型 72B → 10 倍参数差
  7B 每一步 ~2ms, 5 步 ~10ms
  72B 每步 ~20ms, 但可以一次验证 5 个!

Step 2: Verify (大模型, 并行)
  大模型 (72B) 把这 5 个候选 token 和 prompt 拼在一起
  一次性做 Prefill:
    输入: [prompt, t1, t2, t3, t4, t5]   ← 6 个 token 一次算
    → 14ms (只比 decode 一步稍慢, 因为 token 多了)
  
  验证每个候选:
    t1: P_draft(t1) ≤ P_target(t1)? → 一定接受
    t2: P_target(t2) 有多大?        → 概率接受
    t3: 被拒绝了                    → t3,t4,t5 全丢弃
    
  接受: t1, t2 → 2 个 token 到手
  拒绝点: 大模型自己生成 t3' (替代 t3)
  
  总时间: 10ms (draft) + 14ms (verify) = 24ms
  → 产出了 3 个 token (t1, t2, t3')
  → 等效每 token 8ms → 加速 20/8 = 2.5×
```

### Rejection Sampling 保证无损

```python
def speculative_decode(prompt, target_model, draft_model, gamma=5):
    """
    gamma: 每次 draft 多少个候选 token
    """
    tokens = tokenize(prompt)
    
    while len(tokens) < max_tokens:
        # Step 1: Draft (小模型)
        draft_tokens = []
        draft_probs = []
        for _ in range(gamma):
            logits = draft_model.forward(tokens + draft_tokens)
            probs = softmax(logits[-1] / temperature)
            next_tok = sample(probs)
            draft_tokens.append(next_tok)
            draft_probs.append(probs[next_tok])
        
        # Step 2: Verify (大模型, 一次性)
        target_logits = target_model.forward(tokens + draft_tokens)
        target_probs = [softmax(l[-1] / temperature) for l in target_logits[-gamma:]]
        
        # Step 3: 逐个验证
        accepted = 0
        for i in range(gamma):
            p_draft = draft_probs[i]
            p_target = target_probs[i][draft_tokens[i]]
            
            # Rejection sampling
            if p_draft <= p_target:
                # 一定接受
                tokens.append(draft_tokens[i])
                accepted += 1
            else:
                # 以 p_target/p_draft 概率接受
                if random() < p_target / p_draft:
                    tokens.append(draft_tokens[i])
                    accepted += 1
                else:
                    # 拒绝! 从 target 分布中采样替代
                    residual = normalize(target_probs[i] - draft_probs)
                    alternative = sample(residual)
                    tokens.append(alternative)
                    break
        
        if accepted == gamma:
            # 全部接受! 额外奖励一个 token (大模型自己生成的)
            extra_logits = target_model.forward(tokens)
            tokens.append(sample(softmax(extra_logits[-1])))
    
    return tokens
```

### 数学证明（简化）

```
要证明: SpecDecode 的最终输出分布 = 直接用 Target 的分布

不证数学推导, 直观理解:
  对于每个候选 token x:
    如果 P_draft(x) ≤ P_target(x):
      直接接受 x → 正确的 (因为 x 在 target 分布中有足够的概率质量)
    如果 P_draft(x) > P_target(x):
      以 P_target/P_draft 概率接受 → 调整到 target 的概率水平
      拒绝后从 residual 采样 → residual = target - draft 的正部
      
  这确保最终接受或拒绝后, 每个 token 的分布都等于 P_target
  → 无损
```

## 加速比分析

### 理论公式

```
设:
  α = draft 的平均接受率 (每个 token 被接受的概率)
  γ = 每次 draft 的 token 数
  c = draft 一次 forward 相对于 target 的代价比 (≈ 0.1 对于 7B vs 72B)

理论加速比:
  speedup = (1 - α^(γ+1)) / ((1 - α) × (1 + γc) × (γ+1))

简化 (c→0, 即 draft 代价忽略):
  speedup ≈ (1 - α^(γ+1)) / ((1 - α)(γ+1))

数值:
  α=0.9, γ=3 → 加速 ≈ 3.1
  α=0.8, γ=5 → 加速 ≈ 2.7
  α=0.7, γ=5 → 加速 ≈ 2.2
  α=0.6, γ=5 → 加速 ≈ 1.8
  α=0.5, γ=5 → 加速 ≈ 1.5
  α=0.3, γ=5 → 加速 ≈ 1.2
  α=0.1, γ=5 → 加速 ≈ 1.0 ← draft 没用
```

### 决定加速比的因素

```
1. 接受率 α:
   draft 和 target 越像 → α 越高
   同一系列: Qwen2.5-7B draft, Qwen2.5-72B target → α≈0.8
   不同系列: LLaMA3 draft, Qwen target → α≈0.3-0.5
   简单续写任务 > 复杂推理任务

2. Draft 长度 γ:
   α 高时 → 增大 γ → 更好
   α 低时 → 增大 γ → 浪费 (大量被拒)
   最优 γ 通常 3-6

3. Draft 模型选择:
   太小 (0.5B): 接受率低
   太大 (14B): draft 本身也慢 → c 变大
   最优: 同系列 1/10~1/4 参数量的模型
```

## Tree Attention 扩展

```
普通 SpecDecode: draft 一条链
  t1 → t2 → t3 → t4 → t5
  t3 被拒 → t4, t5 全丢

Tree Attention: draft 多叉树
        t1
       /  \
     t2a  t2b
     /  \    \
   t3a t3b  t3c

大模型同时验证 6 个候选:
  → t1 被接受 (根节点)
  → t2a 被接受 (概率高的那条)
  → t2b 被拒
  
实际产出: t1, t2a (再加 target 自己的 t3)
→ 比单链多接受 1-2 个 token
→ 额外 ~20-30% 加速
```

## vLLM 中配置

```bash
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/Qwen2.5-72B-Instruct \
    --speculative-model /path/to/Qwen2.5-7B-Instruct \
    --num-speculative-tokens 5 \
    --speculative-draft-tensor-parallel-size 1 \
    --tensor-parallel-size 4

# --speculative-model: Draft 模型路径
# --num-speculative-tokens: 每次 draft 几个 token
# --speculative-draft-tensor-parallel-size: Draft 的 TP (通常 1, 因为小)
```

## 适用与不适用

```
✅ 适合:
  - 大模型 (>30B), 小模型做 draft (同系列最好)
  - 高吞吐场景 (draft 的额外计算可以摊销)
  - 简单续写/翻译/摘要 (接受率高)
  - 有足够显存装两个模型

❌ 不适合:
  - 模型 <7B (draft 省不了多少)
  - 不同系列 draft (接受率低)
  - 极低延迟需求 (draft 多了一步, TTFT 会变慢)
  - 复杂推理/代码生成 (接受率低)
  - 显存紧张 (两个模型同时 loaded)

⚠️ 关键: TTFT 会变慢!
  draft 先要自回归生成 γ 个 token → 增加 ~2-5ms
  如果 prompt 很短 → TTFT 可能翻倍
  如果 prompt 很长 → Prefill 时间主导 → 影响小
```
