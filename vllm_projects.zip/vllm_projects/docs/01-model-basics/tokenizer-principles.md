# 分词器原理

## 一句话总结
分词器把文本切成 token 序列。主流算法：BPE（GPT/LLaMA/Qwen）和 SentencePiece。中文通常 1-2 个字符 = 1 token，英文 ~0.75 词 = 1 token。

## 为什么需要分词器

```
模型不认字，只认数字：
"你好世界" → Tokenizer → [123, 456, 789] → Embedding → [向量, 向量, 向量]
```

模型接收的是 token ID 序列，不是原始文本。分词器决定了：
- 词表大小（vocab_size）：影响 Embedding 层参数量
- 分词效率：中文分词质量直接影响推理速度和效果
- 特殊 token 处理：对话格式依赖特殊 token 标记

## BPE (Byte Pair Encoding)

GPT/LLaMA/Qwen 家族使用的算法：

```
算法流程：
1. 初始化：每个字符是一个 token
2. 统计所有相邻 token pair 出现频率
3. 合并频率最高的 pair 为新 token
4. 重复 2-3 直到达到目标 vocab_size

例子 (简化):
文本: "low low low low"
第1轮: 合并 "l"+"o" → "lo" (出现4次)
第2轮: 合并 "lo"+"w" → "low" (出现4次)
最终词表: {"l":0, "o":1, "w":2, " ":3, "lo":4, "low":5}
```

## 中文分词的特殊性

```
中文不像英文有空格分隔，所以中文 token 效率更低：

英文: "Hello World" → 2 tokens (Hello, World)
中文: "你好世界" → 3-6 tokens (取决于分词器)

Qwen 对中文做了优化，词表包含更多中文 n-gram：
Qwen2.5 vocab: 151936 (比 LLaMA 的 128000 大，多了中文词条)
```

## 模型文件解读

以 Qwen3-8B 为例：

```
Qwen3-8B/
├── tokenizer.json          # 完整分词器（词表 + merge规则 + 特殊token）
├── tokenizer_config.json   # 分词器配置（chat_template 在这里！）
├── vocab.json              # BPE 词表 (token → id)
└── merges.txt              # BPE 合并规则 (pair → 合并后token)
```

### tokenizer_config.json 中的 chat_template

```json
{
  "chat_template": "{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n' }}{% endif %}{{ '<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n' }}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant\n' }}{% endif %}"
}
```

这个 template 把 messages 列表转成训练/推理用的原始文本：
```
<|im_start|>system
You are a helpful assistant.<|im_end|>
<|im_start|>user
你好<|im_end|>
<|im_start|>assistant
你好！有什么可以帮助你的？<|im_end|>
```

## 特殊 Token

| Token | 含义 | 例子 |
|-------|------|------|
| `<\|im_start\|>` | 消息开始 | 标记 role 的开始 |
| `<\|im_end\|>` | 消息结束 | 标记一条消息的结束 |
| `<\|endoftext\|>` | 文本结束/填充 | LLaMA 的填充 token |
| BOS | Beginning of Sequence | 序列开始（部分模型用） |
| EOS | End of Sequence | 序列结束 = 停止生成 |
| PAD | Padding | 批处理时补齐长度 |
| UNK | Unknown | 未登录词（BPE 一般没有，因为字节级回退） |

## Token 计数工具

### Tiktoken (OpenAI 官方)
```bash
pip install tiktoken
```

```python
import tiktoken

# OpenAI 的编码器
enc = tiktoken.get_encoding("cl100k_base")
text_en = "Hello, world!"
text_cn = "你好世界"

print(f"'{text_en}' → {len(enc.encode(text_en))} tokens")  # ~4 tokens
print(f"'{text_cn}' → {len(enc.encode(text_cn))} tokens")  # ~4-6 tokens
```

### Transformers (HuggingFace 通用)
```python
from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("/data/dongshaoqi/hfms/Qwen3-8B")
text = "大模型部署学习"

tokens = tokenizer.encode(text)
print(f"文本: {text}")
print(f"Token IDs: {tokens}")
print(f"Token数: {len(tokens)}")
print(f"解码: {tokenizer.decode(tokens)}")

# 逐个看
for tid in tokens:
    print(f"  {tid:>6} → '{tokenizer.decode([tid])}'")
```

输出示例：
```
文本: 大模型部署学习
Token IDs: [3837, 91465, 100230, 100638]
Token数: 4
解码: 大模型部署学习
  3837 → '大'
 91465 → '模型'
100230 → '部署'
100638 → '学习'
```

## 下载源

```bash
# Tiktoken
pip install tiktoken
# GitHub: https://github.com/openai/tiktoken

# HuggingFace Tokenizers (Rust实现，极快)
pip install tokenizers
# GitHub: https://github.com/huggingface/tokenizers
```
