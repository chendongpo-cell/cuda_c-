# 量化基础深度解析

## 一句话总结
量化 = 用低精度存模型权重来省显存。FP16(2B)→INT4(0.5B) 省 75%。核心差异在各方法如何补偿量化误差：GPTQ 用 Hessian 补偿、AWQ 保护显著权重、GGUF 混合精度。

## 为什么量化有效

### 神经网络对精度不敏感

```
权重分布通常是正态分布 N(0, 0.01):
    
         ╱ ╲
        ╱   ╲
       ╱     ╲           ← 大部分权重集中在均值附近
      ╱       ╲
  ───┴─────────┴───      ← 只有少数极端值

用 16 个值 (INT4) 或 256 个值 (INT8)
来近似这个连续分布 → 精度损失很小

模型训练时就学了应对噪声:
  - Dropout: 随机丢弃神经元 → 强制鲁棒
  - Weight Decay: 权重衰减 → 偏好小权重
  - SGD 噪声: 梯度本身就是近似 → 天然容忍误差
```

## 数值表示基础

### 浮点数格式

```
FP32 (4 bytes):   [符号1][指数8][尾数23]
  范围: ±3.4 × 10^38, 精度: ~7 位有效数字
  用途: 训练时 master weights

FP16 (2 bytes):   [符号1][指数5][尾数10]
  范围: ±65504, 精度: ~3-4 位有效数字
  问题: 动态范围小 → 梯度容易溢出或 underflow

BF16 (2 bytes):   [符号1][指数8][尾数7]
  范围: 同 FP32 (±3.4×10^38), 精度: ~2-3 位
  优势: 指数位 = FP32 → 不会溢出/underflow
  训练: BF16 不需要 loss scaling
  推理: BF16 和 FP16 几乎一样快

TF32 (19 bits):   [符号1][指数8][尾数10]
  FP32 范围 + FP16 精度 → Tensor Core 专用
  PyTorch 默认: torch.backends.cuda.matmul.allow_tf32 = True
```

### 为什么 BF16 训练更稳定

```python
# FP16 训练: 需要 loss scaling
loss = model(x)
loss = loss * 1024   # scale up (防止梯度 < 2^-14 underflow)
loss.backward()
for p in model.parameters():
    p.grad = p.grad / 1024  # unscale
    optimizer.step()

# BF16 训练: 不需要
loss = model(x)
loss.backward()      # 梯度直接是 BF16, 指数位够大
optimizer.step()
```

### 整数量化

```
INT8:  [-128, 127] 或 [0, 255]
  量化: x_int = round((x_float - zero_point) / scale)
  反量化: x_float ≈ (x_int + zero_point) × scale

INT4:  [-8, 7] 或 [0, 15]
  只有 16 个离散值
  需要更精细的 group-wise 量化 (每 128 个元素一组)

量化三要素:
  scale: 浮点数 → 整数的缩放因子
  zero_point: 浮点 0 对应的整数值
  group_size: 共享同一 scale/zero_point 的元素数
```

## 量化粒度分析

```
Per-tensor:
  [ ───────── 整个 tensor ───────── ]  × 1组(scale, zero_point)
  最粗糙, 开销最小

Per-channel:
  [──ch0──][──ch1──][──ch2──][──ch3──]  × 4组
  适合: 权重 (不同输出通道统计差异大)

Per-group (group_size=128):
  [g0][g1][g2][g3][g4][g5][g6][g7]...   × N/128 组
  最精细, 精度损失最小
  适合: AWQ/GPTQ 默认配置

Per-token:
  用于激活值 (每个 token 动态量化)
  量化开销较大, 但确保精度
```

## 三大量化方法深度对比

### GPTQ

```
算法流程:
1. 准备校准数据 (128 个样本, 跑一遍收集各层输入)
2. 逐列 (per-column) 量化权重:
   对 W 的每一列 j:
     a. 量化 W[:,j] → W_int[:,j]     (引入量化误差)
     b. 计算 Hessian: H = 2X^T X    (从校准数据估算)
     c. 用 H 补偿剩余列: W[:,j+1:] -= H^{-1}_jj × error × H[j,:]
        ↑ 后一列的权重被修正, 来弥补前一列的量化误差
3. 逐列重复 → 全部量化完毕

关键: Obd (Optimal Brain Damage) 的变体
  Hessian-based 补偿让误差在列之间传播和抵消
```

### AWQ (Activation-Aware Weight Quantization)

```
核心发现:
  1% 的 "显著权重" (激活值大的通道) 
  对模型精度影响占 90%+

AWQ 流程:
1. 用校准数据跑一遍, 记录每个通道的平均激活值
2. 找到激活值最大的 1% 通道 → "显著通道"
3. 对这些通道的权重做 scaling (放大权重, 激活值也相应调整):
   W_salient = W_salient × scale
   (推理时激活值会被对应缩小, 输出不变)
4. 所有权重统一量化

效果: 显著权重量化误差的绝对值虽然一样
       但因为被放大了 → 相对误差更小 → 精度保护

vs GPTQ:
  速度快 3-10× (不需要逐列+Hessian计算)
  精度相当或略好
  对硬件更友好 (不需要复杂逆矩阵)
```

### GGUF / llama.cpp 量化

```
不是为 GPU 推理设计的, 而是为 CPU 和混合推理:

K-quant (K=kalman):
  Q4_K_M: 中等质量 4-bit, 最常用
    attention 和 output 层: 较高精度 (Q6_K)
    其他层: 4-bit
    
  Q5_K_M: 高质量 5-bit
    推理质量接近 FP16
  
  Q8_0: 8-bit, 几乎无损
    用于不需要省钱时

IMatrix (Importance Matrix):
  类似 AWQ 的思路, 但用更简单的统计量
  某些 GGUF 模型标注了 "I-quant" → 激活感知量化
```

## FP8 量化 (热点)

```
H100 起支持原生 FP8 Tensor Core:

E4M3 (推理): [符号1][指数4][尾数3]
  范围: ±240, 精度: 2 位有效数字
  适合: 权重和激活 (都是 [-1, 1] 左右的分布)

E5M2 (训练): [符号1][指数5][尾数2]
  范围: ±57344, 精度: 1 位有效数字
  适合: 梯度 (范围大)

vLLM FP8 支持 (实验性):
  --quantization fp8
  --kv-cache-dtype fp8    ← 已稳定, 本机就在用

FP8 vs INT8:
  FP8: 浮点格式, 不需要 scale/zero_point → 实现更简单
  INT8: 整数格式, 需要 calibration → 更成熟
```

## 量化模型显存对照

| 模型 | FP16 | INT8 | AWQ/GPTQ INT4 | GGUF Q4_K_M | FP8(预估) |
|------|------|------|---------------|-------------|----------|
| Qwen3-8B | 16 GB | 8 GB | 4 GB | 4.5 GB | 8 GB |
| Qwen2.5-7B | 14 GB | 7 GB | 3.5 GB | 4 GB | 7 GB |
| Qwen2.5-14B | 28 GB | 14 GB | 7 GB | 8 GB | 14 GB |
| Qwen2.5-72B | 144 GB | 72 GB | **36 GB** | 40 GB | 72 GB |
| Qwen3.5-35B | 70 GB | 35 GB | **23 GB** ← 本机 | — | — |

## 本机量化部署实战

```bash
# 端口 8001 的启动命令 (从 ps aux 提取):
vllm serve QwenQwen3.5-35B-A3B-GPTQ-Int4 \
    --quantization gptq_marlin \        # Marlin: 专门优化 INT4 的 CUDA kernel
    --gpu-memory-utilization 0.9 \
    --dtype float16 \
    --port 8001

# 端口 8091 (vLLM-Omni TTS, Docker):
vllm serve /model --kv-cache-dtype fp8 \  # FP8 KV Cache
    --gpu-memory-utilization 0.45
```

### Marlin Kernel 为什么快

```
标准 INT4 matmul:
  1. 从内存读 INT4 权重 (4 bits)
  2. Dequant 到 FP16 (加 scale/zero_point)
  3. FP16 GEMM
  → step 2 是额外开销

Marlin Kernel:
  1. 从内存读 INT4 权重
  2. 直接用 INT4 做 Tensor Core GEMM
  3. 结果自动 scaled
  → 省去 dequant 开销 → 快 30-50%
```

## 自己量化模型

```bash
pip install autoawq

python3 << 'EOF'
from awq import AutoAWQForCausalLM
from transformers import AutoTokenizer

model_path = "/data/models/my-fp16-model"
quant_path = "/data/models/my-awq-model"

# 加载
model = AutoAWQForCausalLM.from_pretrained(model_path)
tokenizer = AutoTokenizer.from_pretrained(model_path)

# 量化 (约 10-30 分钟, 取决于模型大小)
model.quantize(
    tokenizer,
    quant_config={
        'zero_point': True,      # 非对称量化
        'q_group_size': 128,     # group-wise
        'w_bit': 4               # 4-bit
    }
)

# 保存
model.save_quantized(quant_path)
tokenizer.save_pretrained(quant_path)
print(f"Done: {quant_path}")
EOF
```

## 量化精度损失参考

| 方法 | MMLU | HumanEval | GSM8K | 平均损失 |
|------|------|-----------|-------|---------|
| FP16 baseline | 72.5 | 65.2 | 78.1 | — |
| GPTQ INT4 | 71.8 | 63.9 | 77.2 | -0.8% |
| AWQ INT4 | 72.1 | 64.5 | 77.8 | -0.5% |
| GGUF Q4_K_M | 70.5 | 62.1 | 75.0 | -2.1% |
| GGUF Q5_K_M | 71.8 | 64.0 | 77.0 | -0.9% |

> AWQ 几乎无损, GPTQ 略低, GGUF 要看 quality 等级
