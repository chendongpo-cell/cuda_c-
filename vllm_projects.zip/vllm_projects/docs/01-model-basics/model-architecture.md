# 模型架构深度解析

## 一句话总结
当前主流 LLM 都是 Decoder-only Transformer：Qwen、LLaMA、DeepSeek 核心架构相同，差异在注意力机制（GQA/MLA）和 FFN 设计。理解架构才能理解显存分布、推理瓶颈和优化方向。

## Transformer 是怎么工作的

### 输入：把文字变成数字

```
用户输入: "猫吃鱼"

Step 1: Tokenizer 切词
  → ["猫", "吃", "鱼"]  (假设切成了3个token)

Step 2: 查 Embedding 表
  猫 → [0.01, -0.23, 0.45, ...]  (4096维向量)
  吃 → [0.12, 0.34, -0.11, ...]
  鱼 → [-0.05, 0.67, 0.23, ...]

Step 3: 加位置编码
  位置0的猫向量 + RoPE(0)
  位置1的吃向量 + RoPE(1)
  位置2的鱼向量 + RoPE(2)
  
  不加位置信息 → "猫吃鱼" 和 "鱼吃猫" 对模型来说是一样的
```

### 一层 Transformer 的完整计算

```
输入: x (一个 token 的 4096 维向量)

=== Attention 块 (和其他 token 交流) ===

1. RMSNorm: 归一化 (和 LayerNorm 类似但去掉了中心化)
   y = x / sqrt(mean(x²) + ε) × γ
   作用: 让每层的输入分布稳定

2. 计算 Q, K, V:
   Q = y × W_Q   (4096 → 4096, 通过 W_Q[4096×4096])
   K = y × W_K
   V = y × W_V
   
   为什么要三个投影?
   Q(Query): "我在找什么信息?"
   K(Key):   "我有什么信息?"
   V(Value): "我的实际内容是什么?"
   
   类比图书馆:
     Q = 你的查询 "关于机器学习的书"
     K = 每本书的目录
     V = 每本书的实际内容
     
     Q·K 匹配 → 找到相关的书 → 取那些书的 V

3. 拆分多头:
   4096维 → 32个头 × 128维/头
   
   为什么要多头?
     不同头关注不同的关系:
       头1: 关注语法 (主语-谓语)
       头2: 关注距离 (近处 vs 远处)
       头3: 关注语义 (同义词)
       ...

4. 加 RoPE:
   Q_rot = RoPE(Q, position)
   K_rot = RoPE(K, position)
   旋转这个向量的各个维度对, 给每个位置打上标记

5. 计算 Attention:
   score = Q_rot × K_rot^T / √128   (128 = head_dim)
   
   除以 √128 是为了防止点积太大 → softmax 梯度消失
   如果 head_dim=128, Q·K 的期望值是 √128 ≈ 11
   除以 √128 → 期望值 ≈ 1 → softmax 不会太陡

6. Softmax + Causal Mask:
   masked_score[i,j] = score[i,j]   如果 j ≤ i (causal)
                      -inf           如果 j > i (未来, 看不到)
   
   softmax 后 第 i 个 token 只能看到 0..i 的 token
   
   例: "猫吃鱼"
     token_2("鱼") 可以 attention 到 token_0("猫"), token_1("吃"), token_2("鱼")
     token_0("猫") 只能 attention 到 token_0("猫") 自己

7. 加权求和:
   attn_output = softmax(masked_score) × V
   把每个 token 的 V 按 attention score 加权平均

8. Output 投影:
   output = attn_output × W_O

9. 残差连接:
   x = x + output   (跳过 Attention, 原始信息和 Attention 结果相加)
   
   为什么需要残差?
     如果 Attention 算得很烂 (比如权重全是0)
     至少原始信息还能传过去 (x = x + 0 = x)
     这样深层网络不会退化

=== FFN 块 (自己消化) ===

10. RMSNorm 归一化

11. SwiGLU 激活:
    gate = x × W_gate
    up = x × W_up
    hidden = SiLU(gate) × up
    
    SiLU(x) = x × σ(x) = x / (1 + e^(-x))
    
    和 ReLU 的区别:
      ReLU(x) = max(0, x)    → 负数直接变0 (信息丢失)
      SiLU(x) = x × σ(x)     → 负数变小但不为0 (信息保留)

    为什么 SiLU 更好?
      保留负值信息 → 更丰富的特征表达
      光滑可导 → 训练更稳定

12. Down 投影:
    output = hidden × W_down
    12288维 → 4096维 (回到原始维度)

13. 残差连接:
    x = x + output

这13步完成一层 Transformer
Qwen3-8B 有 36 层 → 重复 36 次 → 最后 LM Head 输出
```

## 三大模型家族对比

| 特性 | Qwen3 | LLaMA 3.1 | DeepSeek-V2 |
|------|-------|-----------|-------------|
| 开发者 | 阿里 | Meta | DeepSeek |
| 注意力 | GQA | GQA | **MLA** |
| FFN | SwiGLU | SwiGLU | SwiGLU + MoE |
| 上下文 | 32K | 128K | 128K |
| 中文 | 🟢 原生最优 | ⚠️ 一般 | 🟢 很强 |
| 参数量 | 0.5B-72B | 8B-405B | 236B(MoE) |

### GQA 为什么省显存

```
标准 MHA:
  32 个 Query 头 + 32 个 Key 头 + 32 个 Value 头
  → KV Cache = 2 × 32 = 64 个 head 的缓存

GQA (Qwen3-8B):
  32 个 Query 头 + 8 个 Key 头 + 8 个 Value 头
  4 个 Q 头共享 1 对 KV 头
  → KV Cache = 2 × 8 = 16 个 head 的缓存
  → 省了 (64-16)/64 = 75%

效果等价吗?
  实验证明: GQA 效果和 MHA 几乎一样
  原因: K 和 V 的信息可以被多个 Q 头复用
  只是换了种方式组织信息
```

### MLA (DeepSeek 的秘密武器)

```
GQA 减少了 KV head 的数量 (32→8)
MLA 更进一步, 压缩每个 KV head 的维度

传统: K ∈ R^{8 heads × 128 dim} = 1024 维
MLA:  压缩到 latent_dim=576 维 → 使用时解压 → 完整 K, V

每 token KV Cache 对比 (72B 级别):
  GQA (8 heads): ~320 KB
  MLA:          ~35 KB  ← 减少 90%!
  
这就是 DeepSeek 支持 128K+ 长上下文的秘诀
```

## 参数量快速估算

```
公式: Total ≈ vocab × hidden           (Embedding + LM Head)
             + layers × (               (Transformer 层)
                 4 × hidden²           (Q,K,V,O 四个投影)
               + 3 × hidden × inter    (SwiGLU 的三个投影)
               )

Qwen3-8B 验证:
  vocab=151936, hidden=4096, layers=36, inter=12288

  Embedding: 151936 × 4096 = 622M
  每层: 4×4096² + 3×4096×12288 = 67M + 151M = 218M
  所有层: 36 × 218M = 7.85B
  总计: 622M + 7.85B ≈ 8.5B

和官方声称的 8B 一致!
```

## 常见问题

### "为什么 Qwen3-8B 实际加载要 16GB, 但参数量只有 8B?"

```
8B 参数 × 2 bytes (FP16) = 16 GB
因为每个参数是 2 字节 (FP16)

如果 INT4 量化: 8B × 0.5 bytes = 4 GB
```

### "为什么不同模型的 vocab_size 差别很大?"

```
Qwen: 151,936  (为中文优化, 包含大量中文词条和 n-gram)
LLaMA3: 128,000 (主要英文, tokenizer 效率对英文高)
GPT-4: ~100,000

vocab_size 大的好处: 中文/多语言 token 效率更高
vocab_size 大的代价: Embedding 层更大 (151936×4096=622M)
  622M / 8B ≈ 7.8% 的参数只是 Embedding!
```

### "为什么叫 Decoder-only?"

```
原始 Transformer 有 Encoder + Decoder:
  Encoder: 理解输入
  Decoder: 生成输出

现在的 LLM 只有 Decoder:
  不需要 Encoder 理解输入
  Decoder 自带 causal attention (只能看到之前的 token)
  所以叫 Decoder-only

BERT 是 Encoder-only (只理解, 不生成)
T5 是 Encoder-Decoder (翻译等任务)
GPT/LLaMA/Qwen 是 Decoder-only (现在的主流)
```
