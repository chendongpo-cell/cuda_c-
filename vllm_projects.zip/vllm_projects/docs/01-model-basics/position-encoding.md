# 位置编码原理

## 一句话总结
Transformer 本身不知道 token 顺序。位置编码告诉模型"谁在谁前面"。进化路线：绝对位置 → RoPE（相对位置 + 可外推）→ YaRN（超长上下文外推）。

## 为什么需要位置编码

```
没有位置编码:
"我爱她" 和 "她爱我" → 相同的 attention 结果 → 模型分不清

有位置编码:
"我(pos=0) 爱(pos=1) 她(pos=2)" vs "她(pos=0) 爱(pos=1) 我(pos=2)"
→ attention 计算时融入了位置信息 → 模型能区分
```

## 绝对位置编码 (Sinusoidal)

原始 Transformer 使用的方案：

```
PE(pos, 2i)   = sin(pos / 10000^(2i/d))
PE(pos, 2i+1) = cos(pos / 10000^(2i/d))

pos: token 位置
i: 维度索引
d: embedding 维度
```

特点：
- 每个位置有唯一的编码向量
- 固定编码，不参与训练
- 缺点：无法外推到更长序列（没见过的位置 = 没见过的编码）

## RoPE (Rotary Position Embedding)

**核心思路：通过旋转 Q 和 K 向量来编码相对位置。**

### 数学原理

```
对位置 m 的 Query:  Q_m = R(θ, m) × Q
对位置 n 的 Key:    K_n = R(θ, n) × K

其中 R(θ, m) 是旋转矩阵:
R(θ, m) = [cos(mθ₁)  -sin(mθ₁)  0         0      ...]
          [sin(mθ₁)   cos(mθ₁)   0         0      ...]
          [0          0         cos(mθ₂)  -sin(mθ₂) ...]
          [0          0         sin(mθ₂)   cos(mθ₂) ...]

Attention score:
Q_m^T × K_n = (R(θ,m)Q)^T × (R(θ,n)K)
            = Q^T × R(θ,n-m) × K        ← 只依赖相对位置 (n-m)！
```

### 频率设计

```
θ_i = 10000^(-2i/d)    (标准设定，i = 0, 1, ..., d/2-1)

低频: θ₁ ≈ 1.0          → 旋转慢 → 擅长长距离依赖
高频: θ_d/2 ≈ 0.0001    → 旋转快 → 擅长相邻 token 关系
```

### 为什么 RoPE 能外推

```
RoPE 的 attention score 只依赖相对位置 (n-m)
→ 即使在训练时没见过 seq_len=32768
→ 推理时遇到 seq_len=65536，相对位置关系仍然有效
→ 只是频率分布可能需要调整（见 YaRN）
```

## 外推方法

### 线性插值 (Position Interpolation)
```
训练时 max_seq=4096,  推理时需要 8192
→ 把位置索引压缩: pos_new = pos × (4096/8192) = pos/2
→ 原来 pos=4096 的编码 → 现在 pos=8192 用编码(4096)

缺点: 所有频率都被压缩 → 相邻 token 区分能力下降
```

### NTK-Aware 插值 (RoPE Scaling)
```
只压缩低频，保留高频:
θ_i_new = θ_i × scale^{(d-2i)/(d-2)}

高频 (i 接近 d/2): θ_new ≈ θ → 几乎不变 → 保留局部关系
低频 (i 接近 0): θ_new ≈ θ × scale → 被压缩 → 扩展远距离

效果: 比纯线性插值好很多
```

### YaRN (Yet another RoPE extensioN)
```
结合 NTK-aware + 温度调节:
1. NTK-aware 缩放频率
2. 对 attention score 加温度系数 √(1/scale)

效果: 可以外推到训练长度的 64-128 倍
Qwen2.5 的 max_position_embeddings=32768 到 128K 的 support 就靠这个
```

## 各模型的位置编码

| 模型 | 编码方式 | 训练上下文 | 最大外推 |
|------|---------|-----------|---------|
| Qwen2.5-7B | RoPE | 32K | 128K (dynamic NTK) |
| Qwen3-8B | RoPE | 40K | 128K |
| LLaMA3.1-8B | RoPE | 128K | — |
| DeepSeek-V2 | RoPE (MLA内) | 128K | 1M |

## 实战

```python
# 查看模型的 RoPE 配置
python3 -c "
import json
with open('/data/dongshaoqi/hfms/Qwen3-8B/config.json') as f:
    c = json.load(f)
print(f'max_position_embeddings: {c[\"max_position_embeddings\"]}')
print(f'rope_scaling: {c.get(\"rope_scaling\", \"None (使用默认)\")}')
print(f'rope_theta: {c.get(\"rope_theta\", \"默认 10000\")}')
"
```

```bash
# vLLM 中设置最大上下文长度
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --max-model-len 65536   # 设置 64K 上下文（外推到训练长度2倍）
```

## 面试要点

**Q: RoPE 为什么比绝对位置编码好？**
A: 1) 相对位置编码 — attention 只依赖 token 间距离；2) 可外推 — 通过插值/缩放扩展上下文；3) 每层都注入位置信息 — 不是只在 embedding 层加。

**Q: 怎么把 4K 模型扩展到 32K 上下文？**
A: NTK-aware RoPE scaling + 少量长上下文微调。只改 config 中 rope_scaling 参数，不需要重新训练。
