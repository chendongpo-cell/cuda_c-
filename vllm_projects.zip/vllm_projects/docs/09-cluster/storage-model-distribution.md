# 分布式存储与模型分发

## 场景

单机: 模型放本地 SSD, 加载几秒

万卡: 1000 个节点要同时加载同一个 144GB 的 72B 模型。如果每个节点从本地盘读 → 要提前复制到每个节点。如果从共享存储读 → 1000个节点同时读同一个文件 → 存储打满。

## 共享文件系统

### Lustre (HPC 标配)

```
架构:
  MDS (Metadata Server): 管理文件名、目录结构
  OSS (Object Storage Server): 存实际数据
  客户端: mount 后像本地文件系统一样用

万卡集群典型配置:
  几十台 OSS, 每台几十块 HDD/SSD
  总容量: 几十 PB
  聚合带宽: 几百 GB/s

挂载:
  mount -t lustre 10.0.0.1@tcp:/models /data/models
  
对于推理:
  模型文件放 Lustre → 所有节点都能读
  但加载速度受限于 Lustre 总带宽
```

### GPFS / Spectrum Scale (IBM)

```
类似 Lustre, 企业级:
  支持更细粒度的 QoS
  更好的元数据性能
  常用于金融/气象 + AI 混合集群
```

### WekaFS / JuiceFS

```
新一代并行文件系统:
  WekaFS: 全闪存, 极致性能, NVMe-oF
  JuiceFS: 对象存储 + 缓存, 更便宜
```

## 模型加载优化

### 问题: 1000 个节点同时加载模型

```
72B FP16 = 144GB
1000 节点同时读 = 144TB 数据

Lustre 聚合带宽假设 500GB/s:
  144TB / 500GB/s ≈ 288 秒 ≈ 5 分钟

这 5 分钟内:
  - GPU 空闲等模型加载
  - 网络/存储被打满
  - 影响其他作业

而且这只是一个模型实例!
如果推理服务有 10 个副本:
  10 × 144TB / 500GB/s ≈ 48 分钟!
```

### 优化 1: 模型预缓存到本地 NVMe

```bash
# 每个节点本地 NVMe (如 4×3.84TB)
lsblk | grep nvme

# 首次启动时:
# 1. 从 Lustre 拷贝模型到本地 NVMe
cp -r /data/lustre/models/Qwen2.5-72B /local/nvme/models/

# 2. vLLM 从本地 NVMe 加载
vllm serve /local/nvme/models/Qwen2.5-72B

# 后续重启:
# 本地 NVMe 已经有模型了 → 直接加载 → 30秒
# 模型更新时: 重新拷贝

# Slurm 脚本:
#SBATCH --gres=gpu:8
# 节点本地 NVMe 挂载在 /local/nvme

# Prolog 脚本 (Slurm 作业启动前执行):
if [ ! -d /local/nvme/models/Qwen2.5-72B ]; then
    cp -r /data/lustre/models/Qwen2.5-72B /local/nvme/models/
fi
```

### 优化 2: 内存池预加载

```
如果节点内存够大 (2TB):
  把模型常驻在内存中

  # 首次加载
  vllm serve /data/models/Qwen2.5-72B &
  
  # 进程常驻, 不退出
  # 即使没有请求, GPU 闲置也比重新加载快

  # 或者用 /dev/shm (内存文件系统):
  cp /data/models/Qwen2.5-72B /dev/shm/
  vllm serve /dev/shm/models/Qwen2.5-72B
  # 加载速度: ~100GB/s (内存带宽) → 1.5 秒!
  
代价: 占 144GB 内存 (72B) 或更多
```

### 优化 3: 分层加载

```bash
# vLLM 支持 lazy loading:
# 不是一次性加载全部权重
# 而是用到哪层加载哪层

# 但首次 forward 时要加载所有层 → 第一次请求很慢
# 适合: 模型预热 (warmup)

# 启动后立即发一个最小请求:
curl ... -d '{"max_tokens":1}'  # 触发全部层加载
```

## 模型版本管理

```
生产环境需要管理模型版本:

/data/models/
├── Qwen2.5-72B-v1.0/          ← 当前生产版本
├── Qwen2.5-72B-v2.0-finetuned/ ← 新版本 (灰度中)
├── Qwen2.5-72B-v2.0-fallback/  ← 上一版本 (回滚用)
└── Qwen2.5-72B-INT4/           ← 量化版 (降级用)

灰度发布:
  90% 流量 → v1.0
  10% 流量 → v2.0
  观察 1 小时 → 无异常 → 100% 切到 v2.0

回滚:
  如果 v2.0 有问题 → 直接切回 v1.0 (模型已经在节点上)
  不需要重新加载 (如果内存够, 两个版本常驻)
```

## 容器镜像分发

```
推理服务的 Docker 镜像也很大:
  vllm/vllm-openai:latest ≈ 20GB

1000 个节点拉同一个镜像 → Docker Registry 打满

优化:
  1. 集群内 Registry 镜像:
     docker pull registry.internal.com/vllm/vllm-openai:latest

  2. P2P 分发 (Dragonfly/Kraken):
     节点 A 下载完 → 节点 B 从 A 拿 → 不用全打 Registry

  3. 预缓存:
     用 Slurm prolog 预拉镜像
     docker pull ... → 放本地

  4. 用 squashfs 镜像:
     把 Docker 镜像转成 squashfs → 直接从 Lustre 挂载
     不需要 docker pull
```

## 本机现有存储

```bash
df -h /data
# /dev/sda4  11T  8.9T  1.6T

# 本机 /data 有 1.6T 剩余
# 72B 模型 ~144GB → 可以放
# 但要给日志留空间 (vLLM 日志、系统日志会增长)
```

## 存储故障处理

```
Lustre 卡顿:
  df -h /data/lustre → 卡住
  → 分布式文件系统偶尔会有元数据操作卡顿
  → 不是模型加载的首选 (拷贝到本地后用本地盘)

本地 NVMe 故障:
  nvme list → 少了一块
  → 降级: 从 Lustre 加载 (慢, 但能用)
  → 通知运维换盘
```
