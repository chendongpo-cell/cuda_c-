# Slurm 集群调度

## 场景

万卡集群不是你想用哪张卡就用哪张。所有 GPU 资源由 Slurm 统一管理。提交作业 → Slurm 分配节点/GPU → 你的任务跑在分配的节点上 → 跑完释放。

## 核心概念

```
Slurm 管理的资源:
  Partition (分区): GPU 集群的逻辑分组
    gpu_a800: A800 节点
    gpu_h100: H100 节点 (如果有)
    debug: 调试用, 限制 2 小时

  Node (节点): 一台物理机 (如 8×A800, 2TB 内存)
  
  GPU: 每张 GPU 是一个 GRES (Generic Resource)
    请求: --gres=gpu:8 (需要 8 张 GPU)

  Job (作业): 你提交的一个任务
    有 Job ID, 可以查看状态、日志、取消
```

## 常用命令

### 提交作业

```bash
# === 交互式: 直接分配到 GPU 节点 ===
srun --partition=gpu_a800 \
     --gres=gpu:8 \
     --cpus-per-task=64 \
     --mem=500G \
     --time=04:00:00 \
     --pty bash
# 进入 GPU 节点的一个 shell, 可以手动跑命令
# 适合: 调试、模型探索

# === 批处理: 提交脚本 ===
sbatch my_vllm_job.sh
# 提交后立即返回 Job ID, 任务在后台排队
# 适合: 正式推理服务、长时间运行
```

### 批处理脚本模板

```bash
#!/bin/bash
#SBATCH --job-name=vllm-72b          # 作业名
#SBATCH --partition=gpu_a800         # 分区
#SBATCH --nodes=2                    # 2 个节点
#SBATCH --ntasks-per-node=1          # 每节点 1 个任务
#SBATCH --gres=gpu:8                 # 每节点 8 张 GPU
#SBATCH --cpus-per-task=64           # CPU 核心数
#SBATCH --mem=1000G                  # 内存
#SBATCH --time=7-00:00:00            # 运行 7 天
#SBATCH --output=/data/logs/vllm_%j.out   # 标准输出日志
#SBATCH --error=/data/logs/vllm_%j.err    # 错误日志
#SBATCH --exclusive                 # 独占节点 (不和其他作业共享)

# === Slurm 会自动设这些环境变量 ===
echo "Job ID: $SLURM_JOB_ID"
echo "Nodes: $SLURM_JOB_NODELIST"
echo "GPUs per node: $SLURM_GPUS_ON_NODE"

# 获取分配的节点列表
NODES=$(scontrol show hostnames $SLURM_JOB_NODELIST)
HEAD_NODE=$(echo $NODES | awk '{print $1}')

# === 启动 Ray 集群 ===
# 在所有节点上启动 Ray
srun --ntasks=$SLURM_NNODES --nodes=$SLURM_NNODES \
    ray start --head --port=6379 --block=false \
    --node-ip-address=$HEAD_NODE

# Worker 节点
for node in $NODES; do
    if [ "$node" != "$HEAD_NODE" ]; then
        ssh $node "ray start --address=$HEAD_NODE:6379 --block=false"
    fi
done

# === 启动 vLLM ===
python3 -m vllm.entrypoints.openai.api_server \
    --model /data/models/Qwen2.5-72B-Instruct \
    --tensor-parallel-size 4 \
    --pipeline-parallel-size 2 \
    --host 0.0.0.0 --port 8000

# Slurm 会自动在作业结束时清理: kill 所有进程, 释放 GPU
```

### 查看和管理

```bash
# === 查看队列 ===
squeue                          # 所有作业
squeue -u $USER                 # 我的作业
squeue -p gpu_a800              # 特定分区
squeue --format="%.10i %.10P %.20j %.8u %.2t %.10M %.6D %R"
# JobID, Partition, Name, User, State, Time, Nodes, Reason

# 状态:
#   R (Running): 正在跑
#   PD (Pending): 排队等待 (Reason 列显示为什么: Resources/Priority)
#   CG (Completing): 正在清理

# === 查看作业详情 ===
scontrol show job $SLURM_JOB_ID
# 看分配的节点、GPU 数量、内存等

# === 查看节点 ===
sinfo                           # 所有节点状态
sinfo -p gpu_a800               # 看 GPU 分区的空闲节点
sinfo -N -l                     # 每节点详情
# 状态: idle(空闲), mix(部分占用), alloc(全占用), drain(故障下线)

# === 取消作业 ===
scancel $JOB_ID

# === 查看作业输出 ===
tail -f /data/logs/vllm_$JOB_ID.out
tail -f /data/logs/vllm_$JOB_ID.err

# === 连接到运行中的作业 ===
srun --jobid=$JOB_ID --pty bash
# 进入作业的首节点
```

## 资源配置

```bash
# GPU 请求方式
--gres=gpu:8                    # 8 张任意 GPU
--gres=gpu:a800:8               # 8 张 A800 (如果集群有多种 GPU)
--gres=gpu:a800_80gb:8          # 8 张 80GB A800

# 多节点
--nodes=2                       # 2 个节点
--ntasks-per-node=1             # 每节点 1 个进程 (Ray 管多 GPU)
# 注: vLLM 用 Ray 管多 GPU, 所以 ntasks-per-node=1

# 或精确指定 GPU:
--gpus-per-task=1 --cpus-per-gpu=8 --ntasks=16
# 16 个 task, 每个 1 GPU + 8 CPU (总共 16 GPU, 128 CPU)

# 独占
--exclusive                     # 独占节点 (哪怕只用 1 个 GPU)
# 或
--gres=gpu:8 --cpus-per-gpu=8 --mem-per-gpu=100G
# 精确分配, 允许其他作业用同一节点的剩余资源
```

## 长期推理服务

```bash
#!/bin/bash
# 推理服务需要长期运行 (不像训练有固定结束时间)

# 策略 1: 长时间 walltime (推荐)
#SBATCH --time=30-00:00:00       # 30 天
# 每 30 天重新提交一次 (提前 1 天提交新作业, 新旧并行, 切流量后关旧)

# 策略 2: 使用 reservation
# 和集群管理员申请 reservation (预留资源)
#SBATCH --reservation=vllm_prod
# 这些 GPU 永远不会被分配给其他作业

# 策略 3: 不通过 Slurm, 直接跑
# 如果你们有专属节点, 可以不用 Slurm
# 但通常不推荐 (资源利用不均)
```

## 常见问题

### "作业一直 PD (Pending), Reason=Resources"

```
原因: GPU 资源不够, 在排队

查:
  sinfo -p gpu_a800 -o "%n %t %e %O %G %D"
  # 看多少节点 idle

  squeue -p gpu_a800 -o "%.10i %.10P %.8u %.2t %.10M"
  # 看前面还有多少作业在排队

解决:
  - 减少申请的 GPU 数 (--gres=gpu:4 而不是 8)
  - 缩短 walltime (更容易调度)
  - 提高 QoS/优先级 (和集群管理员沟通)
```

### "作业被 OOM killed"

```
Slurm 默认限制:
  --mem 控制每节点的物理内存
  超出 → Slurm 直接 kill 作业

查看:
  sacct -j $JOB_ID --format=JobID,State,ExitCode,MaxRSS
  # MaxRSS 显示峰值内存

避免:
  --mem=1000G  (给够)
  或监控: watch -n 1 free -h
```

### "Slurm 分配了 GPU, 但 CUDA 看不到"

```
原因: cgroup 隔离问题

解决:
  # 启动脚本开头加:
  export CUDA_VISIBLE_DEVICES=$(seq -s, 0 $(($SLURM_GPUS_ON_NODE - 1)))
  
  # 或 Slurm 自动设的环境变量:
  # SLURM_STEP_GPUS, CUDA_VISIBLE_DEVICES
```

### "跨节点通信失败"

```
Slurm 分配了节点, 但节点间网络不通

查:
  srun --nodes=2 --ntasks-per-node=1 \
       hostname && ping -c 1 <other_node>

  # NCCL 需要节点间 TCP/IB 可达
  # 检查防火墙: sudo iptables -L
```

### "同一个 Slurm 作业内部分 GPU 挂了"

```
万卡集群里这是日常。GPU 挂了一个, 作业不能全挂:

策略:
  export CUDA_DEVICE_ORDER=PCI_BUS_ID  # 确定性 GPU 编号
  # 在代码中:
  if torch.cuda.device_count() < expected:
      # 跳过坏 GPU, 降级运行
      # 或用 /tmp/slurm_gpu_fault 通知 Slurm
```

## Slurm 环境变量速查

```bash
$SLURM_JOB_ID          # 作业 ID
$SLURM_JOB_NODELIST    # 分配的节点列表 (如 node[01-04])
$SLURM_NNODES          # 分配的节点数
$SLURM_GPUS_ON_NODE    # 每节点的 GPU 数
$SLURM_CPUS_ON_NODE    # 每节点的 CPU 数
$SLURM_MEM_PER_NODE    # 每节点内存 (MB)
$SLURM_SUBMIT_DIR      # 提交作业时的目录
```
