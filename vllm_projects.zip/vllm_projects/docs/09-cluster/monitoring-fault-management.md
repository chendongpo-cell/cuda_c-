# 集群监控与故障管理

## 场景

单机: nvidia-smi 看 8 张卡, 坏了就换

万卡: 10000 张 GPU, 每天都有 GPU 坏、NVLink 断、IB 端口 down、节点宕机。目标不是不出故障，而是故障不影响服务。

## 故障率认知

```
万卡集群的日常:
  GPU 故障率: ~2-5%/年 → 每天坏 0.5-1.4 张
  NVLink 故障: 1-2%/年 → 每月断几次
  IB 链路故障: 3-5%/年 → 每周断几次
  节点宕机: ~5%/年 → 每周 1-2 台
  内存 ECC 错误: 常见, 大部分可纠正
  磁盘故障: ~3%/年

所以:
  单卡部署: 假设硬件可靠 → 挂了人工处理
  万卡部署: 假设硬件不可靠 → 自动容错, 对业务无感
```

## DCGM 集群级监控

```
DCGM (Data Center GPU Manager):
  每节点一个 DCGM Exporter (本机已跑: port 9400)
  集群级: Prometheus 采集所有节点的 DCGM 指标
```

### 关键指标

```bash
# GPU 健康
DCGM_FI_DEV_GPU_UTIL             # GPU 利用率
DCGM_FI_DEV_MEM_COPY_UTIL        # 显存带宽利用率
DCGM_FI_DEV_GPU_TEMP             # 温度
DCGM_FI_DEV_POWER_USAGE          # 功耗
DCGM_FI_DEV_SM_CLOCK             # SM 频率
DCGM_FI_DEV_MEM_CLOCK            # 显存频率

# GPU 错误
DCGM_FI_DEV_XID_ERRORS           # XID 错误 (GPU 内部错误码)
DCGM_FI_DEV_ECC_SBE_VOL_TOTAL    # 单比特 ECC 错误 (可纠正)
DCGM_FI_DEV_ECC_DBE_VOL_TOTAL    # 双比特 ECC 错误 (不可纠正!)
DCGM_FI_DEV_RETIRED_SBE          # 因单比特错误退役的显存块
DCGM_FI_DEV_RETIRED_DBE          # 因双比特错误退役的显存块

# NVLink
DCGM_FI_DEV_NVLINK_CRC_FLIT_ERROR_COUNT_TOTAL  # NVLink CRC 错误
DCGM_FI_DEV_NVLINK_CRC_DATA_ERROR_COUNT_TOTAL  # NVLink 数据错误
DCGM_FI_DEV_NVLINK_BANDWIDTH_TOTAL             # NVLink 带宽

# PCIe
DCGM_FI_DEV_PCIE_REPLAY_COUNTER  # PCIe 重传次数 (>0 说明链路不稳定)

# 推理
DCGM_FI_DEV_FB_USED              # Frame Buffer 使用量
DCGM_FI_DEV_FB_FREE              # Frame Buffer 空闲量
```

### 关键告警

```yaml
# Prometheus 告警规则

- alert: GPU_XID_Error
  expr: increase(DCGM_FI_DEV_XID_ERRORS[5m]) > 0
  for: 5m
  annotations:
    summary: "GPU {{ $labels.gpu }} XID error on {{ $labels.node }}"
    description: "XID 错误码: {{ $value }} (查 NVIDIA XID 错误表)"
  # XID=13: 显存 ECC 不可纠正错误 (GPU 挂了)
  # XID=31: GPU 从总线上断开 (硬件故障)
  # XID=48: 显存双比特 ECC → GPU 即将退役
  # XID=74: NVLink 错误

- alert: GPU_ECC_Double_Bit
  expr: increase(DCGM_FI_DEV_ECC_DBE_VOL_TOTAL[1h]) > 0
  annotations:
    summary: "GPU {{ $labels.gpu }} 双比特 ECC 错误 → 需立即更换"

- alert: GPU_Thermal_Throttle
  expr: DCGM_FI_DEV_GPU_TEMP > 85
  for: 5m
  annotations:
    summary: "GPU {{ $labels.gpu }} 温度 {{ $value }}°C → 可能降频"

- alert: NVLink_CRC_Error
  expr: increase(DCGM_FI_DEV_NVLINK_CRC_FLIT_ERROR_COUNT_TOTAL[15m]) > 100
  annotations:
    summary: "NVLink CRC 错误激增 → 检查 NVLink 连接"

- alert: PCIe_Replay_High
  expr: increase(DCGM_FI_DEV_PCIE_REPLAY_COUNTER[1h]) > 1000
  annotations:
    summary: "PCIe 链路不稳定 → 可能降速"

- alert: GPU_Clock_Dropped
  expr: (DCGM_FI_DEV_SM_CLOCK / DCGM_FI_DEV_SM_CLOCK offset 1d) < 0.5
  annotations:
    summary: "GPU SM 频率下降 >50% → 散热或电源问题"

- alert: Node_Down
  expr: up{job="dcgm"} == 0
  for: 2m
  annotations:
    summary: "节点 {{ $labels.node }} DCGM Exporter 挂了 → 节点可能宕机"

- alert: IB_Port_Down
  expr: ib_port_state{state="Down"} == 1
  for: 1m
  annotations:
    summary: "IB 端口 {{ $labels.port }} 挂了"
```

## 故障处理策略

### GPU 故障

```bash
# 1. 检测
DCGM_FI_DEV_XID_ERRORS > 0 → 查 XID 表

# 2. 分级
XID 13/31/48 → 致命, GPU 必须退役
XID 43/45 → 可恢复, 重置 GPU 即可
XID 62/63/64 → 软件问题, 重启进程

# 3. 自动化处理
for bad_gpu in detect_bad_gpus():
    # 排除坏 GPU
    new_cuda_visible = [g for g in range(8) if g != bad_gpu]
    os.environ['CUDA_VISIBLE_DEVICES'] = ','.join(map(str, new_cuda_visible))
    
    # 如果是 TP 推理:
    # 减 TP size, 降级到更少 GPU
    # 或迁移到备用节点
    
    # 标记节点为 drain (告诉 Slurm 别再调度到这个节点)
    os.system(f"scontrol update nodename={hostname} state=drain reason='GPU_{bad_gpu}_XID_{xid_code}'")
```

### 节点故障

```
处理层次:
  Level 1 (秒级): 推理服务自动 failover
    → 请求路由到其他健康节点
    
  Level 2 (分钟级): 自动重建
    → 坏节点标记 drain
    → Slurm/K8s 在健康节点上起新 Pod
    → 新 Pod 从共享存储加载模型
    → 加入服务池
    
  Level 3 (小时级): 人工介入
    → 运维排查硬件
    → 更换 GPU/网卡
    → 节点恢复后取消 drain
```

### NVLink 故障

```bash
# 检测
nvidia-smi nvlink -e          # NVLink 错误计数
nvidia-smi nvlink -s          # NVLink 状态

# 如果某对 GPU 间 NVLink 挂了:
# 那对 GPU 间的通信会 fallback 到 PCIe
# → 带宽从 400GB/s 降到 32GB/s
# → TP 性能断崖式下降

# 处理:
# 1. 避免把那对 GPU 用在同一个 TP group
# 2. 或隔离该节点, 不让它参与 TP>4 的推理
# 3. 标记: scontrol update nodename=xxx state=drain reason='nvlink_fault_gpu3_gpu7'
```

### 推理服务自动容错

```python
# 推理服务中的容错逻辑

class FaultTolerantInference:
    def __init__(self):
        self.healthy_gpus = self._detect_healthy_gpus()
        self.health_check_thread = threading.Thread(target=self._monitor_gpus)
    
    def _detect_healthy_gpus(self):
        """启动时检测可用 GPU"""
        healthy = []
        for i in range(8):
            try:
                torch.cuda.set_device(i)
                # 跑一个小计算验证 GPU 正常
                torch.zeros(1).cuda()
                healthy.append(i)
            except:
                logging.warning(f"GPU {i} not available, skipping")
        return healthy
    
    def _monitor_gpus(self):
        """后台持续监控 GPU 健康"""
        while True:
            for gpu in self.healthy_gpus:
                # 读 DCGM 指标
                xid = read_xid_error(gpu)
                if xid > 0:
                    logging.error(f"GPU {gpu} XID={xid}, removing from pool")
                    self.healthy_gpus.remove(gpu)
                    # 自动降级
                    self._degrade_service()
            time.sleep(10)
    
    def _degrade_service(self):
        """GPU 少了 → 调整 TP size → 重新加载模型"""
        # 代价高, 但比服务全挂好
        pass
```

## 节点健康分级

```
Green (健康):
  所有 GPU 正常, NVLink 正常, IB 正常
  → 全功能推理

Yellow (降级):
  1-2 张 GPU 坏了, 但剩余够跑 TP=4
  → 降级运行, 继续服务

Orange (严重降级):
  3+ 张 GPU 坏了, 只够跑 TP=2
  → 继续服务但性能下降

Red (下线):
  无法满足最低 GPU 要求
  → 标记 drain, 停止接受流量
  → 人工修复
```

## 日常运维检查清单

```bash
# 每天:
□ 检查 DCGM 告警 (有无 GPU XID 错误)
□ 检查节点 drain 列表 (sinfo -R)
□ 检查推理服务 QPS/延迟 (Grafana)

# 每周:
□ 检查 GPU 退役计数 (nvidia-smi -q | grep "Retired")
□ 检查 IB 端口错误 (ibstatus)
□ 检查磁盘使用 (df -h)

# 每月:
□ 全量 NCCL 带宽测试 (找出性能下降的链路)
□ GPU 压力测试 (找出隐性故障的 GPU)
□ 固件/驱动更新评估
```
