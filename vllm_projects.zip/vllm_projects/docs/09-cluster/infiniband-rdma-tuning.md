# InfiniBand / RDMA 网络调优

## 为什么重要

单机推理: NCCL 走 NVLink (400GB/s) → 通信不是瓶颈

万卡集群: NCCL 跨节点走 IB/RoCE (200Gbps = 25GB/s) → 通信是瓶颈。慢 16 倍。

多节点推理的性能上限 = 网络带宽。

## 网络层次

```
节点内部:
  GPU ↔ GPU: NVLink 3.0 (400 GB/s 双向, 每 GPU 对直连)
  GPU ↔ NIC: PCIe 4.0 x16 (~32 GB/s)

节点之间:
  NIC ↔ Switch ↔ NIC: InfiniBand HDR (200 Gbps ≈ 25 GB/s)
                      或 RoCE (RDMA over Converged Ethernet)
  
GPU Direct RDMA (GDR):
  GPU 显存 ↔ NIC (不经过 CPU 内存)
  延迟: ~1-2μs (比经过 CPU 快 10 倍)
  必须开启!
```

## NCCL 跨节点通信方式

### Ring

```
节点0 GPU0 → 节点0 GPU1 → ... → 节点0 GPU7 → 节点1 GPU0 → ... → 节点1 GPU7 → 节点0 GPU0
  ↑ 环上每张卡只和下家通信

优点: 带宽利用率高
缺点: 延迟 = N-1 跳 (N 个 GPU)
适合: 节点内 (NVLink 低延迟)
不太适合: 跨节点 (IB 延迟比 NVLink 高 10-100 倍)
```

### Tree (NCCL 跨节点默认)

```
            GPU0 (root)
           /    |    \
        GPU1  GPU2  GPU3
       /  \    |    /  \
     ... (叶子节点)

优点: 延迟 O(log N)
缺点: 根节点带宽可能成为瓶颈
适合: 跨节点 (减少 IB 通信次数)
```

### NCCL 自动选择

```
NCCL 会根据:
  1. GPU 数量
  2. 节点数量
  3. 网络拓扑 (IB/RoCE)
  4. 数据大小

自动选择 Ring 或 Tree。

一般:
  小数据 (< 1MB): Tree (延迟优先)
  大数据 (> 1MB): Ring (带宽优先)
  跨节点: 优先 Tree
```

## NCCL 关键环境变量

```bash
# ===== 必须设的 =====

# 启用 InfiniBand
export NCCL_IB_DISABLE=0

# GPUDirect RDMA (GDR): GPU显存直接到NIC, 不经过CPU
export NCCL_NET_GDR_LEVEL=5
# 0: 禁用
# 1: 只用 GDR 拷贝 (copy)
# 2: 只用 GDR 异步拷贝
# 3: GDR 拷贝 + GDR 异步拷贝
# 4: 只用 GDR RDMA 写入
# 5: GDR RDMA 写入 + GDR RDMA 读取 (最激进)

# 指定 IB 网卡
export NCCL_IB_HCA=mlx5_0,mlx5_1,mlx5_2,mlx5_3
# 查看本机 IB 网卡:
ibstat | grep "CA name"

# ===== 性能调优 =====

# 跨 NIC 负载均衡
export NCCL_CROSS_NIC=1

# Socket 接口 (如果 IB 不可用, fallback 到 TCP)
export NCCL_SOCKET_IFNAME=eth0

# IB 超时 (万卡集群设大一点)
export NCCL_IB_TIMEOUT=22

# 调试 (排查问题时开)
export NCCL_DEBUG=WARN
# NCCL_DEBUG=INFO    # 看拓扑发现过程
# NCCL_DEBUG=TRACE   # 看每次通信的详情 (巨量日志!)

# ===== 拓扑 =====

# 显式指定 GPU-NIC 亲和性
export NCCL_TOPO_FILE=/etc/nccl_topo.xml

# 或让 NCCL 自动检测:
# NCCL 会读 nvidia-smi topo -m 和 /sys/class/infiniband/
```

## GDR (GPU Direct RDMA) 详解

```
无 GDR:
  GPU 显存 → CPU 内存 (PCIe, ~32GB/s) → NIC (PCIe) → 网络
  两次 PCIe 传输 + CPU 内存拷贝
  延迟: ~10μs

有 GDR:
  GPU 显存 → NIC (PCIe, ~32GB/s) → 网络
  一次 PCIe 传输, 不经过 CPU 内存
  延迟: ~1-2μs

要求:
  1. GPU: A100/A800 及以上 (支持 GPUDirect RDMA)
  2. NIC: ConnectX-5 及以上
  3. PCIe 拓扑: GPU 和 NIC 在同一 PCIe switch 下 (否则多一跳)
  4. 驱动: nvidia-peer-memory 模块加载
  5. NCCL: NCCL_NET_GDR_LEVEL=5
```

### 验证 GDR 是否生效

```bash
# 检查 peer memory 模块
lsmod | grep nvidia_peermem

# 检查 GPU-NIC PCIe 拓扑
nvidia-smi topo -m
# GPU 和 NIC 之间最好 PIX (同 PCIe switch)
# NODE (跨 NUMA) 也可以用, 但延迟稍高

# NCCL 测试
export NCCL_DEBUG=INFO
# 看日志中: "NET/IB: Using GDR" → 生效
# 看日志中: "NET/IB: Using CPU memory" → 未生效, GDR回了CPU
```

## 带宽测试

```bash
# NCCL 自带测试工具
git clone https://github.com/NVIDIA/nccl-tests.git
cd nccl-tests && make

# AllReduce 带宽测试 (2节点, 16GPU):
mpirun -np 16 -H node01:8,node02:8 \
    -x NCCL_IB_DISABLE=0 -x NCCL_NET_GDR_LEVEL=5 \
    ./build/all_reduce_perf -b 1M -e 2G -f 2 -g 1

# -b 1M: 从 1MB 开始
# -e 2G: 到 2GB 结束
# -f 2: 每次翻倍
# -g 1: 每个 MPI 进程 1 个 GPU

# 期望结果:
# 节点内 (NVLink): ~190 GB/s (单向)
# 跨节点 (IB): ~23 GB/s (200Gbps 单向)
# 跨节点 (IB, 双口): ~46 GB/s

# 如果实际值远低于理论值 → GDR 没生效 / 拓扑有问题
```

## 常见问题

### "NCCL 跨节点通信巨慢"

```
1. 检查 IB 是否正常
   ibstat                    # IB 端口状态: Active
   ibstatus                  # 链路速度: 200 Gb/s
   perfquery -x              # 错误计数: 0

2. 检查 GDR
   nvidia-smi topo -m        # GPU-NIC PIX/PXB
   lsmod | grep nvidia_peer  # 模块已加载

3. 检查是否有 fallback 到 TCP
   NCCL_DEBUG=INFO | grep "transport"
   # 看到 NET/IB → 在用 IB
   # 看到 NET/Socket → fallback 到 TCP 了!
   
   强制 IB:
   export NCCL_IB_DISABLE=0
   export NCCL_SOCKET_IFNAME=   # 清空, 不用 socket

4. 检查 PCIe 带宽
   nvidia-smi nvlink -s         # NVLink 状态
   lspci -vv | grep -i "pci.*gen" # PCIe 代数
```

### "GDR 不生效"

```
原因排查:
  1. GPU 不支持: nvidia-smi --query-gpu=gpu_name --format=csv
     → 必须 A100/A800/H100 或更新
     
  2. NIC 不支持: ibstat → CA type
     → 必须 ConnectX-5 或更新
     
  3. PCIe 拓扑: GPU 和 NIC 必须在同一 PCIe switch 下
     → nvidia-smi topo -m 看 PIX/PXB
     
  4. 模块没加载:
     modprobe nvidia-peermem
     # 加到 /etc/modules-load.d/nvidia-peermem.conf

  5. BAR1 大小不够:
     nvidia-smi -q | grep "BAR1"
     # BAR1 Memory Usage 要够装通信 buffer
```

### "NCCL 报 IB timeout"

```
日志: "NCCL WARN NET/IB: Got completion error"
      "NCCL WARN NET/IB: Got async event"

原因:
  1. IB 交换机故障或过载
  2. GPU 算太久 (另一张卡在等 AllReduce)
  3. 超时设得太短

增大超时 (万卡集群可能需要):
  export NCCL_IB_TIMEOUT=22       # 默认 22 秒
  export NCCL_IB_RETRY_CNT=7      # 重试次数

如果持续报:
  → 检查 IB 交换机 (可能是硬件问题)
  → 降级到 TCP socket (性能差但可用)
```

### "跨节点 AllReduce 带宽不稳定"

```
正常现象: 万卡集群的 IB 网络是多租户的
  其他作业也在用 IB → 带宽波动

减少波动:
  1. 用 QoS (和服务商/管理员申请 IB 带宽保障)
  2. 避免和其他大通信作业在同一组 IB 交换机
  3. 监控: 看 IB 端口错误计数
```

### "部分节点 IB 断了"

```
# 检查集群 IB 网络
# Slurm 环境下:
srun --nodes=4 --ntasks-per-node=1 \
    ibstat | grep -E "CA name|State|Rate"

# 正确的输出:
# State: Active
# Physical state: LinkUp
# Rate: 200

# 如果有问题:
# ibportstate -D 0 1 reset   # 重置端口
```
