# 资源管理与多租户 (MIG)

## 场景

万卡集群不是一个人用的。几十个团队、上百个项目共享资源。怎么保证你的推理服务不会因为别人抢 GPU 而挂掉？怎么把一张 A800 切成小块给多个轻量推理服务共享？

## 多租户隔离层次

```
Level 1: Slurm 分区 (物理隔离)
  给推理团队专属的物理节点
  其他团队作业不会调度到这些节点
  
  sinfo -p gpu_inference → 你的专属节点
  优点: 物理隔离, 性能可预测
  缺点: 利用率低 (你的 GPU 空闲时别人也不能用)

Level 2: Slurm QoS (软隔离)
  你的作业优先级更高 → 优先获得资源
  --qos=inference_high
  
  优点: 弹性, GPU 空闲时可被其他低优先级任务用
  缺点: 高峰期可能抢不到资源

Level 3: MIG (GPU 硬件切分)
  一张 A800 切成 7 个小 GPU 实例
  每个推理服务用 1 个小实例
  硬件级隔离, 互不影响
  
  优点: 极致利用, 显存/算力都隔离
  缺点: 只支持 A100/A800/H100, 不能动态调整

Level 4: MPS (多进程共享 GPU)
  多个推理服务共用一张 GPU
  CUDA 软件层的时间片调度
  优点: 更灵活, 可以 oversubscribe
  缺点: 显存不隔离 → 一个 OOM 全挂
```

## MIG (Multi-Instance GPU) 实战

### MIG 切分配置

```
A800 80GB MIG 配置:

1g.10gb  (1/8 算力, 10GB 显存)   × 7 个 → 共 70GB, 剩余 10GB 不可用
2g.20gb  (1/4 算力, 20GB 显存)   × 3 个 → 共 60GB
3g.40gb  (3/8 算力, 40GB 显存)   × 1 个 → 共 40GB (剩下 40GB 不能用)
4g.40gb  (1/2 算力, 40GB 显存)   × 1 个 → 共 40GB (剩下 40GB 不能用)
7g.80gb  (完整 GPU, 1 个实例)     × 1 个 → 完整 GPU

组合: 可以混合
  3g.40gb + 2g.20gb + 2×1g.10gb = 80GB (全用完)
```

### 启用 MIG

```bash
# 1. 开启 MIG 模式
sudo nvidia-smi -i 0 -mig 1
# 或所有 GPU: nvidia-smi -mig 1

# 2. 创建 GPU 实例
sudo nvidia-smi mig -i 0 -cgi 14,14,14,14,14,14,14 -C
# -cgi: Compute GPU Instance profile
#   14 = 1g.10gb
#   9  = 3g.40gb
#   7  = 4g.40gb
#   0  = 7g.80gb (完整 GPU)
# -C: 创建

# 3. 创建计算实例
sudo nvidia-smi mig -i 0 -cci 0,0,0,0,0,0,0 -C
# -cci: Compute Instance (挂载到 GPU Instance 上)

# 4. 查看 MIG 设备
nvidia-smi mig -i 0 -l
# 输出:
# GPU 0:
#   GPU Instance ID: 0 → /dev/nvidia-cube0
#   GPU Instance ID: 1 → /dev/nvidia-cube1
#   ...

# 5. 使用 MIG 设备
CUDA_VISIBLE_DEVICES=MIG-<UUID> python3 -m vllm...
# 或指定 MIG 设备号:
CUDA_VISIBLE_DEVICES=MIG-GPU-<gpu_uuid>/<gi>/<ci>
```

### MIG 用于推理

```bash
# 一张 A800 切成 7 个 1g.10gb:
# 10GB 显存 → 放不下 7B FP16 (需要 14GB)
# 但可以放:
#   - 3B 模型 FP16: ~6GB
#   - 7B 模型 INT4: ~3.5GB
#   - Embedding 模型 BGE-M3: ~1.3GB
#   - Reranker 模型: ~1GB

# 一台 8×A800 机器:
# 每张卡 7 个 MIG → 共 56 个轻量推理实例!

# 适合场景:
#   - Embedding 服务 (BGE, 1.3GB)
#   - Reranker 服务 (BGE-Reranker, 1GB)  
#   - 7B INT4 推理 (3.5GB)
#   - Tokenizer 服务
#   → 一张卡跑 7 个不同类型的小服务
```

### MIG vs 整卡使用

```
用 MIG:                         用整卡:
  7个 1g.10gb → 7个轻量服务       1个 7g.80gb → 1个重量级服务
  适合: Embedding/Reranker        适合: 72B 推理
  
什么时候用 MIG:
  ✅ 有很多小模型需要部署
  ✅ 需要强隔离 (一个服务 OOM 不影响其他)
  ✅ GPU 利用率低, 想提高打包密度

什么时候不用 MIG:
  ❌ 只有大模型 (72B+)
  ❌ 需要灵活的显存分配 (MIG 切了就固定了)
  ❌ 需要高吞吐 (MIG 算力变少, 每 token 时间变长)
```

## MPS (Multi-Process Service)

```
MPS 是 CUDA 软件层的多进程共享:
  多个进程可以同时在一张 GPU 上跑 CUDA kernel
  GPU 在时间片粒度 (<1μs) 切换上下文

配置:
  export CUDA_MPS_PIPE_DIRECTORY=/tmp/mps
  nvidia-cuda-mps-control -d    # 启动 MPS daemon
  
  # 然后所有 CUDA 进程自动共享 GPU
  
限制:
  不支持 MIG 和 MPS 同时开启
  显存不隔离 (一个进程 OOM 所有进程受影响)
  不支持 P2P (多 GPU 直接通信)
  
适合: 多卡 TP 时, 一个推理进程独占 GPU 更好
不适合: 多个独立推理服务共享 GPU
```

## 抢占与优先级

```
万卡集群中的优先级体系:

QoS Level:
  high:   生产推理服务 (不能抢, 不能被抢)
  medium: 在线推理 (可以被 high 抢)
  low:    离线批量 (随时可以被抢)
  best_effort: 填缝任务 (GPU 空闲时跑, 来高优先级立刻让出)

Slurm 抢占:
  # 高优先级作业可以抢低优先级作业的 GPU
  --qos=high --preempt=low  # 可以抢占 low QoS 的作业
  
被抢占的作业:
  Slurm 发 SIGTERM → checkpoint → 重新排队
  (推理服务一般不做 checkpoint → 被抢=重启)

推理服务应该设 high QoS!
```

## 容量规划

```
已知需求:
  10 万日活用户
  每用户日均 20 次请求
  每次请求平均 200 token 输出
  
  峰值 QPS = 100K × 20 / (24 × 3600) × 5(峰值系数)
           ≈ 11.6 QPS (平均), 峰值 ≈ 58 QPS

单实例 Qwen2.5-7B:
  并发 64: 约 600 tokens/s
  每次 200 tokens → 3 req/s
  一台 8×A800: 8 个实例 → 24 req/s

需要: 58/24 ≈ 3 台 8×A800 节点

加上冗余 (2 台备用 + 灰度 1 台):
  共需 6 台 8×A800 节点
```
