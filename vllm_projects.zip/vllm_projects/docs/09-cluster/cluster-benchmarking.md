# 集群 Benchmark

单机看吞吐，集群看扩展效率和故障发现。万卡集群的 Benchmark 不只是压模型，还要压网络、存储、GPU 健康。

## 分层 Benchmark

```
Layer 1: GPU 单卡健康     nvidia-smi + DCGM diagnostics
Layer 2: 节点内通信        NCCL all_reduce_perf (NVLink)
Layer 3: 节点间通信        NCCL all_reduce_perf (IB/RoCE)
Layer 4: 存储带宽          fio / dd (Lustre, NVMe)
Layer 5: 推理微基准        vLLM single node benchmark
Layer 6: 全栈推理          vLLM multi-node + real traffic
```

## Layer 1: GPU 健康检查

```bash
# 1. 基础信息
nvidia-smi --query-gpu=index,name,memory.total,compute_cap,temperature.gpu,power.draw --format=csv

# 2. GPU 诊断 (DCGM)
dcgmi diag -r 1    # Level 1: 快速 (1分钟)
dcgmi diag -r 2    # Level 2: 中等 (5分钟)
dcgmi diag -r 3    # Level 3: 深度 (30分钟, 含显存全量检测)

# 3. 显存带宽测试
# 用 CUDA 自带的 bandwidthTest:
/usr/local/cuda/samples/bin/x86_64/linux/release/bandwidthTest
# 期望: HBM ~1900 GB/s (接近理论 2000)

# 4. 计算能力测试 (GEMM)
# 跑一个 FP16 GEMM → 看 TFLOPS
python3 -c "
import torch, time
N=16384
a=torch.randn(N,N,dtype=torch.float16,device='cuda')
b=torch.randn(N,N,dtype=torch.float16,device='cuda')
torch.cuda.synchronize()
t0=time.time()
for _ in range(100):
    c=a@b
torch.cuda.synchronize()
tflops = 2*N*N*N*100 / (time.time()-t0) / 1e12
print(f'FP16 GEMM: {tflops:.1f} TFLOPS (peak 312)')
"

# 全集群跑 (Slurm):
srun --gres=gpu:a800:8 --nodes=ALL \
    bash -c 'nvidia-smi -q | grep "Product Name\|FB Memory Usage\|GPU Current Temp"'
```

## Layer 2/3: NCCL 通信测试

```bash
# nccl-tests
git clone https://github.com/NVIDIA/nccl-tests.git
cd nccl-tests && make MPI=1

# === 节点内 (8 GPU NVLink) ===
mpirun -np 8 -H localhost:8 \
    ./build/all_reduce_perf -b 1M -e 2G -f 2 -g 1
# 期望: ~190 GB/s (单向, NVLink 理论 200)

# === 跨节点 (16 GPU, 2节点) ===
mpirun -np 16 -H node01:8,node02:8 \
    -x NCCL_IB_DISABLE=0 \
    -x NCCL_NET_GDR_LEVEL=5 \
    ./build/all_reduce_perf -b 1M -e 2G -f 2 -g 1
# 期望: 节点内 ~190GB/s, 跨节点 ~23GB/s (200Gbps IB)

# === 跨节点 (128 GPU, 16节点) ===
mpirun -np 128 -H node[01-16]:8 \
    -x NCCL_IB_DISABLE=0 \
    -x NCCL_NET_GDR_LEVEL=5 \
    ./build/all_reduce_perf -b 8M -e 256M -f 2 -g 1
# 看扩展效率: 128GPU 的带宽应该是 8GPU 的:
#   (128-1)/128 × 23GB/s ÷ (8-1)/8 × 190GB/s
#   应该 ~ 线性扩展 (只是节点间带宽低导致绝对值低)

# === 发现坏链路 ===
# 逐对测试每两个节点之间的 NCCL 带宽
# 如果某对节点明显慢 → IB 链路问题
for n1 in node{01..16}; do
    for n2 in node{01..16}; do
        if [ "$n1" != "$n2" ]; then
            mpirun -np 16 -H $n1:8,$n2:8 ./build/all_reduce_perf -b 1M -e 1G -f 2 -g 1 > /tmp/nccl_${n1}_${n2}.log
            bw=$(grep "BusBw" /tmp/nccl_${n1}_${n2}.log | tail -1 | awk '{print $NF}')
            echo "$n1 ↔ $n2: $bw GB/s"
        fi
    done
done
```

## Layer 4: 存储测试

```bash
# === Lustre 读带宽 ===
# 大文件顺序读
dd if=/data/lustre/large_test_file of=/dev/null bs=1M count=10000
# 期望: > 1GB/s (单客户端)

# Lustre 元数据性能
echo 3 | sudo tee /proc/sys/vm/drop_caches  # 清缓存
time ls -lR /data/lustre/models/ > /dev/null
# 如果很慢 (>5秒) → MDS 性能瓶颈

# === 本地 NVMe ===
fio --name=seqread --ioengine=libaio --iodepth=32 --rw=read \
    --bs=1M --size=10G --numjobs=1 --runtime=30 \
    --filename=/local/nvme/test --direct=1
# 期望: 顺序读 > 6 GB/s

fio --name=randread --ioengine=libaio --iodepth=32 --rw=randread \
    --bs=4K --size=1G --numjobs=4 --runtime=30 \
    --filename=/local/nvme/test --direct=1
# 期望: 随机读 > 500K IOPS
```

## Layer 5: 单节点推理基准

```bash
# 标准 Benchmark
python3 -m vllm.benchmarks.benchmark_serving \
    --backend vllm \
    --host localhost --port 8000 \
    --model Qwen2.5-7B \
    --dataset-name sharegpt \
    --dataset-path ShareGPT_V3_unfiltered_cleaned_split.json \
    --num-prompts 1000 \
    --request-rate inf       # 不限速, 测最大吞吐

# 记录:
#   - Throughput (tokens/s)
#   - TTFT P50/P95/P99
#   - TPOT P50/P95

# 对比不同配置:
#   TP=1 vs TP=2 vs TP=4
#   FP16 vs INT4
#   block_size=16 vs 32
#   max-num-seqs=32 vs 64 vs 128
```

## Layer 6: 全栈多节点

```bash
# 启动多节点 vLLM 服务
# 在 Slurm 作业中
srun --nodes=4 --gres=gpu:8 --ntasks-per-node=1 bash -c '
    ray start --head &
    sleep 5
    python3 -m vllm.entrypoints.openai.api_server \
        --model /data/models/Qwen2.5-72B \
        --tensor-parallel-size 4 \
        --pipeline-parallel-size 2 \
        --host 0.0.0.0 --port 8000 &
    sleep 60
    # 从其他节点发压测
    python3 /shared/benchmark_serving.py \
        --backend vllm --host $(hostname) --port 8000 \
        --num-prompts 5000 --request-rate 10
'

# 重点看:
#   1. 扩展效率: 2节点/4节点的吞吐 vs 单节点
#   2. 延迟分布: 跨节点后 P99 变化
#   3. GPU 利用率: 各节点是否均衡
#   4. IB 带宽利用率: ibmon 或 MLNX perf 工具
```

## 扩展效率分析

```
单节点 (8×A800, TP=8):
  72B: Throughput = 1200 tok/s
  这是 baseline

2 节点 (16×A800, TP=4+PP=2):
  72B: Throughput = 2200 tok/s
  扩展效率 = 2200/(1200×2) = 91.7%
  ↑ 损失 8.3% 是因为 PP bubble + IB 通信

4 节点 (32×A800, TP=4+PP=4):
  72B: Throughput = 3900 tok/s
  扩展效率 = 3900/(1200×4) = 81.3%
  ↑ 损失 18.7% 是因为更大 PP bubble

扩展效率随着节点数增加而下降:
  2节点: ~90%
  4节点: ~80%
  8节点: ~65%
  16节点: ~50%
  再多了不划算 (PP bubble 太大)

所以推理一般不超过 4-8 个节点
要更大吞吐 → 加单节点内的 batch (不多加节点)
```

## 日常巡检脚本

```bash
#!/bin/bash
# daily_cluster_check.sh — 万卡集群每日健康检查

echo "=== $(date) ==="

# GPU 故障
echo "GPU XID Errors (last 24h):"
srun --nodes=ALL --gres=gpu:1 bash -c '
    for gpu in 0 1 2 3 4 5 6 7; do
        xid=$(nvidia-smi -i $gpu -q 2>/dev/null | grep "XID" || echo "N/A")
        if [ "$xid" != "N/A" ] && [ "$xid" != "None" ]; then
            echo "$(hostname) GPU$gpu: $xid"
        fi
    done
'

# 节点 drain
echo "Drain nodes:"
sinfo -R

# 磁盘
echo "Disk usage:"
df -h /data/lustre /local/nvme

# IB 错误
echo "IB Errors:"
srun --nodes=ALL bash -c '
    ibstat | grep -A5 "Port" | grep -E "State|Rate"
'

echo "=== Done ==="
```

## 性能回归检测

```
每次模型更新、框架升级、驱动更新后，跑 baseline benchmark:

baseline:
  模型: Qwen2.5-72B
  TP=4, 单节点
  num-prompts=1000, request-rate=inf
  
  Throughput: 1200 tok/s  (记录下来)
  TTFT P95: 400ms
  TPOT P50: 15ms

新版本:
  任何指标恶化 > 10% → 回滚
```

## 关键指标仪表盘

```
Grafana Dashboard (集群级):

Row 1: 集群总览
  - 总 GPU 数 / 可用 GPU 数 / 故障 GPU 数
  - 总节点数 / drain 节点数
  - 总 QPS / 总 Throughput

Row 2: 推理服务
  - 每模型 QPS (分模型)
  - 每模型 TTFT P95
  - 每模型 TPOT P50
  
Row 3: GPU 资源
  - 每节点 GPU 利用率 (heatmap)
  - 每节点显存使用率
  - GPU 温度 (heatmap, 红色 >85°C)

Row 4: 网络
  - IB 带宽利用率 (Top 10 链路)
  - NCCL AllReduce 带宽 (per job)
  - IB 错误率

Row 5: 存储
  - Lustre IOPS (read/write)
  - NVMe 使用率
```
