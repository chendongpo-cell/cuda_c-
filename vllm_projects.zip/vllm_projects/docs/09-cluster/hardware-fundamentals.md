# 集群硬件基础

搞懂硬件才能理解为什么 Inference 慢、为什么通信是瓶颈、为什么存储总不够。

## CPU 与 GPU 的协作

### 架构差异

```
CPU (Xeon 6248R @ 3.0GHz):
  ┌─────────────────────────────────┐
  │ 24 核心, 每核很强                   │
  │ 每核有独立 L1(32KB)+L2(1MB)       │
  │ 共享 L3(35.75MB)                  │
  │ 乱序执行 + 分支预测 → 低延迟        │
  │                                   │
  │ 擅长的: if-else, 循环, 调度, I/O   │
  │ 类比: 24 个博士, 每个能做很复杂的事  │
  └─────────────────────────────────┘

GPU (A800, 108 SM):
  ┌─────────────────────────────────┐
  │ 108 个 SM, 每个 SM 有 64 CUDA Core │
  │ 总共 6912 个小核心                │
  │ 每条指令 32 个线程执行 (warp)       │
  │ 顺序执行 → 高吞吐量                │
  │                                   │
  │ 擅长的: 矩阵乘法, 大规模并行计算    │
  │ 类比: 6912 个小学生, 每人做简单计算  │
  └─────────────────────────────────┘

在推理中:
  CPU 做的事: Tokenize, 调度, I/O, 控制流
  GPU 做的事: 矩阵乘法, Attention, FFN
```

### PCIe 总线

```
                         ┌──────────┐
                         │   CPU    │
                         │  2个插槽  │
                         └────┬─────┘
                              │
                    ┌─────────┴─────────┐
                    │    PCIe Switch    │
                    └──┬────┬────┬────┬─┘
                       │    │    │    │
                      GPU0 GPU1 NIC  NVMe
                      
PCIe 4.0: 每 lane 16 GT/s ≈ 2 GB/s
  16 lane (x16): 32 GB/s (单向)

为什么 CPU→GPU 拷贝慢?
  从内存拷模型到 GPU 显存:
  72B × 2 bytes = 144 GB
  PCIe 4.0 x16: 144GB / 32GB/s ≈ 4.5 秒
  
  这就是模型加载至少几秒的原因
  (还不包括文件系统读取)

为什么 GPU→NIC 是瓶颈?
  GPU 和 NIC 共用 PCIe 带宽
  如果你的 GPU 和 NIC 不在同一个 PCIe switch 下:
  数据要走 CPU → CPU 内存 → 另一个 PCIe → NIC
  延迟增加 2-3 倍
```

### NUMA 架构

```
双路 Xeon 服务器:

NUMA Node 0:             NUMA Node 1:
  CPU 0 (24核)             CPU 1 (24核)
  本地内存 377GB            本地内存 377GB
  GPU0 GPU1 GPU2 GPU3       GPU4 GPU5 GPU6 GPU7
  NIC0                      NIC1

NUMA 的影响:
  GPU0 访问 Node0 的 CPU 内存: ~100ns, ~100GB/s
  GPU0 访问 Node1 的 CPU 内存: ~200ns, ~50GB/s (跨 NUMA, 慢一倍!)
  
  在推理中:
    - GPU 分配在哪个 NUMA node? → 影响 CPU-GPU 通信
    - NCCL 通信: 同一 NUMA 内的 GPU 间 NVLink 直连更快
    - 内存分配: 尽量在 GPU 所在 NUMA 的本地内存

绑定 NUMA (推荐):
  numactl --cpunodebind=0 --membind=0 python3 -m vllm...
  # 把进程绑定到 NUMA node 0, 避免跨 NUMA
```

## GPU 内部

### SM (Streaming Multiprocessor)

```
A800 的一个 SM:

┌─────────────────────────────────────┐
│  Warp Scheduler × 4                 │
│  (每周期挑 1 个 ready 的 warp 执行)   │
├─────────────────────────────────────┤
│  FP32 Core × 64    (单精度)          │
│  FP64 Core × 32    (双精度)          │
│  Tensor Core × 4   (矩阵乘法)        │
│  LD/ST Unit × 16   (数据读写)        │
│  SFU × 16          (sin/cos/exp)    │
├─────────────────────────────────────┤
│  Register File: 256 KB              │
│  Shared Memory: 164 KB              │
│  L1 Cache: 192 KB                   │
└─────────────────────────────────────┘

每周期可以:
  调度 4 个 warp (4×32=128 线程)
  同时执行 64 个 FP32 操作 + 4 个 Tensor Core 4×4×4 矩阵乘法
```

### 为什么 Decode 慢

```
一次 Decode: 模型 36 层, 每层 ~218M 参数

GPU 视角:
  
  第 1 层:
    1. CPU 发 kernel launch 指令 → GPU 收到
    2. HBM 读 K,V (从 KV Cache block) → 1.4MB, ~0.7μs (理论)
       但实际上: 多个 block 不连续, 多次 DMA, ~20μs
    3. HBM 读权重 W_Q, W_K, W_V → 3 × 16MB = 48MB, ~24μs
    4. Tensor Core 算 Q,K,V (3 个 GEMM)
    5. SRAM 内 FlashAttention (online softmax, ~5μs)
    6. Tensor Core 算 W_O, W_gate, W_up, W_down
    7. 写结果到 HBM
    
    理论耗时: ~50μs
    实际耗时: ~200-300μs (因为 kernel launch gap + HBM 带宽限制)

  第 2-36 层: 同样流程 × 35
  
  总 Decode 一步: ~10-20ms

瓶颈分析:
  HBM 带宽 2TB/s, 需要读 36×(~50MB) ≈ 1.8GB → 900μs 理论
  实际 ~8ms → 8 倍差距 → 因为数据不连续, 小 kernel 太多
```

### 显存带宽为什么是瓶颈

```
A800 HBM2e 带宽: 2039 GB/s (标称)

看起来很快, 但:

每层 Decode 需要从 HBM 读:
  - 权重 (W_Q,W_K,W_V,W_O,W_gate,W_up,W_down + bias): ~200 MB (7B)
  - KV Cache (当前 token 的): ~1-2 MB (短的) 或 ~200 MB (长 seq)

如果 batch=64:
  权重只需读一次 (所有请求共享)
  KV Cache: 64 × 2MB = 128 MB (短 seq)
  
  总读: 200 + 128 = 328 MB/层
  总带宽需求: 328MB / 2000GB/s = 0.16ms (理论)
  
但实际: 每个请求的 KV Cache 在 HBM 中不连续 (PagedAttention!)
  128 个不连续 block × 64 个请求 = 8192 次 mini DMA
  每次 DMA 有启动开销 (~0.5μs) → 8192 × 0.5μs ≈ 4ms
  → 显存带宽有效利用率 ~20%
  
这就是为什么 Decode 是 memory-bound!
显存带宽的标称值没问题, 但不连续访问大幅降低有效带宽
```

## 存储系统

### 存储层次

```
速度           容量          用途           延迟
────────────────────────────────────────────────
GPU 显存(HBM)   80 GB        模型+KV Cache    1ns  (2TB/s)
CPU 内存(DDR4)  754 GB       OS + 缓冲       100ns (200GB/s)
本地 NVMe SSD   3.84 TB      模型缓存         100μs (7GB/s)
本地 HDD        10 TB        日志/数据        10ms  (200MB/s)
Lustre          几十 PB       模型仓库         1ms  (聚合 500GB/s)
```

### 为什么模型要从 Lustre 拷到本地 NVMe

```
Lustre (共享文件系统):
  1000 个节点同时读同一个文件:
    MDS 拥塞 (元数据操作串行化)
    OSS 拥塞 (磁盘带宽分散给 1000 个客户端)
    
  单客户端读 144GB: 
    理想: 144GB / 500GB/s ≈ 0.3s
    实际 (1000 个客户端): 144GB / (500GB/1000) ≈ 288s
    → 因为你只有 1/1000 的带宽!

本地 NVMe:
  独占的: 7GB/s 都是你的
  144GB / 7GB/s ≈ 20s
  → 快 14 倍!

而且 NVMe 是本地资源, 不会影响其他节点
```

## 网络

### InfiniBand vs Ethernet vs NVLink

```
NVLink (GPU 间):
  带宽: 400 GB/s (双向), 每通道 50 GB/s × 8 通道
  延迟: ~1μs
  连接: 全互联 (每对 GPU 直连)
  距离: 板内 (厘米级)
  
InfiniBand (节点间):
  带宽: 200 Gbps (HDR) = 25 GB/s (单向)
  延迟: ~1-2μs (RDMA)
  连接: 通过 IB 交换机
  距离: 机柜内到跨机柜

Ethernet (节点间, fallback):
  带宽: 100 Gbps = 12.5 GB/s
  延迟: ~10-50μs (TCP/IP)
  连接: 通过以太网交换机
  用途: 管理网络, NCCL fallback
```

### 物理拓扑

```
典型万卡集群的机柜布局:

┌────────── 机柜 1 ──────────┐
│  Rack 1-1 (IB 交换机)        │
│  ├── 节点 1 (8×A800)        │
│  ├── 节点 2 (8×A800)        │
│  ├── ...                     │
│  └── 节点 16 (8×A800)       │
│   共 128 GPU, 同 IB 交换机   │
│   延迟: ~1μs                 │
└─────────────────────────────┘
           │ IB 上行
┌────────── 机柜 2 ──────────┐
│  Rack 2-1 (IB 交换机)        │
│  └── 节点 17-32             │
└─────────────────────────────┘
           │
    核心 IB 交换机 (Spine)
    连接所有机柜
    延迟: 机柜间 ~3-5μs

NCCL 通信:
  同机柜: NVLink (GPU间) + IB (节点间, 同一交换机)
  跨机柜: 多一跳 IB → 延迟稍高
  跨 Pod: 经过 Spine → 延迟更高

NCCL 自动感知拓扑:
  同一个 IB 交换机的节点 → lower rank → 更多通信
  跨 IB 交换机的节点 → higher rank → 更少通信
```

### RDMA 原理

```
传统 TCP/IP 通信:
  发送端: 用户态内存 → 内核态 socket buffer → 网卡 → 网络
  接收端: 网络 → 网卡 → 内核态 → 用户态
  
  → 两次内存拷贝 + 内核态切换
  → CPU 占用高, 延迟 ~50μs

RDMA (Remote Direct Memory Access):
  发送端: 用户态内存 → 网卡 (DMA) → 网络
  接收端: 网络 → 网卡 (DMA) → 用户态内存
  
  → 零拷贝! CPU 不参与!
  → 延迟 ~1-2μs

GPUDirect RDMA:
  发送端: GPU 显存 → 网卡 (PCIe DMA) → 网络
  接收端: 网络 → 网卡 → GPU 显存 (PCIe DMA)
  
  → GPU 直接发到对端 GPU
  → CPU 完全不知情
```

## 集群通信拓扑感知

```
多节点 TP 的通信模式:

TP=4, PP=2, 4 个节点:

节点 0: GPU 0-7, TP group A (0,1,2,3), PP stage 0
节点 1: GPU 0-7, TP group A (4,5,6,7), PP stage 0
节点 2: GPU 0-7, TP group B (0,1,2,3), PP stage 1
节点 3: GPU 0-7, TP group B (4,5,6,7), PP stage 1

通信图:
  TP 组内: 每层 AllReduce (大量小数据, 频繁)
    节点 0 ↔ 节点 1: 全部 GPU 参与, IB 全速
    节点 2 ↔ 节点 3: 同上
  
  PP 边界: 每 microbatch 传 activation (少量大数据)
    节点 0 → 节点 2: 一次性传 256MB
    节点 1 → 节点 3: 同上

  拓扑感知优化:
    节点 0 和节点 1 放在同一个 IB 交换机 (TP 最多通信)
    节点 2 和节点 3 放在同一个 IB 交换机
    PP 边界跨交换机 (通信少, 延迟不敏感)
```

## 数据中心供电和散热

```
A800 功耗: 300W (TDP)
8×A800: 2400W + CPU 200W + 系统 200W ≈ 2800W/节点

1000 节点: 2.8 MW
10000 节点: 28 MW

散热:
  2800W 都变成热量
  需要液冷或强力空调
  
  如果散热不够 → GPU 降频 (thermal throttling)
  → SM 频率从 1400MHz 降到 800MHz
  → 推理性能直接腰斩

  监控: nvidia-smi -q | grep "GPU Current Temp"
  告警: >85°C → 检查散热
```

---

## 补充 1: CPU 深度

### 缓存一致性 (Cache Coherency)

```
双路 Xeon, 两个 CPU 各自有 L1/L2/L3 cache:

CPU0 的 L3 cache 里有变量 X 的副本
CPU1 的 L3 cache 里也有变量 X 的副本

CPU0 修改 X: 值变成 42
  问题: CPU1 的副本还是旧值 → 数据不一致!

MESI 协议:
  Modified:  只有我有最新值, 其他 CPU 的副本已失效
  Exclusive: 只有我有, 且值和内存一致
  Shared:    多 CPU 共享, 都是只读
  Invalid:   我的副本无效, 不能用

写流程:
  1. CPU0 要写 X → 发 RFO (Read For Ownership) 到总线
  2. CPU1 收到 → 把自己的 X 标为 Invalid
  3. CPU0 标为 Modified → 写入 42
  4. CPU1 再读 X → Miss → CPU0 回写内存 → CPU1 重新读 → 标 Shared

为什么推理关心:
  CPU 做 cudaMemcpy 前, 如果 cache 里有脏数据:
    先 Writeback 到内存 → GPU 才能 DMA
    → 多一步, +100ns

  用 Write-Combined memory (cudaHostAllocWriteCombined):
    CPU 绕过 cache 直接写 → GPU 直接 DMA
```

### SIMD

```
AVX-512 (Xeon 6248R):
  一条指令处理 16 个 FP32 (512bit / 32bit)
  或 8 个 FP64

  for i in range(16): c[i] = a[i] + b[i]  → 16 条标量指令
  AVX-512: vaddps zmm0, zmm1, zmm2        → 1 条 SIMD 指令

推理中用到 SIMD 的地方:
  - Tokenizer: 字符串匹配可以向量化
  - Embedding: gather 操作
  - Sampling: argmax 可以 SIMD 加速
  - Beam search: 多个 beam 的状态同时算
```

### 内存通道

```
Xeon 6248R: 6 通道 DDR4-2933
每通道: 64-bit × 2933M / 8 ≈ 23.4 GB/s
总带宽: 6 × 23.4 = 140 GB/s

分给两个 NUMA node: 每 node 70 GB/s

GPU 从 CPU 内存读:
  受 PCIe 限制 (32 GB/s), 不是内存带宽瓶颈

但大 batch 时:
  多 GPU 同时从 CPU 内存读
  → 6 通道全部跑满 → cudaMemcpy 变慢
```

---

## 补充 2: GPU 深度

### Warp 调度

```
一个 SM 有 4 个 Warp Scheduler
每个管理 16 个 warp → 64 warp total

每周期: Scheduler 从 16 个 warp 中挑 1 个 ready 的发射指令

Warp 什么时候 stall (不能用)?
  - 等 HBM 数据 (LD/ST latency ~300 cycles)
  - 等长延迟指令 (sin/cos ~16 cycles)
  - 同步屏障 __syncthreads: 等其他 warp

延迟隐藏:
  warp_0 stall (等数据 300 cycles)
  → Scheduler 切到 warp_1 (ready)
  → warp_1 执行 20 cycles, 也 stall
  → Scheduler 切到 warp_2
  → ...
  只要有足够多 ready warp → GPU 一直忙!

如果只有 4 个 warp, 全 stall:
  → SM 空闲 260 cycles → 利用率 20/300 = 6.7%

所以 Occupancy 很重要!
```

### Occupancy 怎么算

```
A800: 每 SM 最多 64 warp

两个限制因素:

1. Register 压力:
  每 SM 有 256KB Register File (65536 × 32bit)
  每个线程用 N 个寄存器 → 每 warp: 32×N
  每 SM 最多 warp = 65536 / (32×N)
  
  如每个线程 128 个寄存器:
    65536 / (32×128) = 16 warp → Occupancy = 16/64 = 25%

2. Shared Memory 压力:
  每 SM 有 164KB SMEM
  每个 block 用 M 字节 → 最多 164/M 个 block
  
  如每个 block 40KB: 164/40 = 4 block
  每 block 256 线程 (8 warp): 4×8 = 32 warp

Register 限制更紧 → Occupancy 25%

解决:
  --maxrregcount 64 (编译器限制寄存器数)
  代价: 不够的寄存器 spill 到 L1 → 慢

FlashAttention: 精心控制 SMEM 和 Register
  让 Occupancy 尽可能高
```

### HBM vs DDR

```
HBM2e (A800):
  8 层 DRAM die 堆叠
  1024-bit 总线 (硅中介层 interconnect)
  2TB/s 总带宽
  不能扩展 (焊接在 GPU 旁)

DDR4-2933 (CPU):
  DIMM 插槽, 可换/加
  6 通道 × 23.4GB/s = 140GB/s
  754GB 容量

为什么 HBM 不能堆更多?
  散热 + 物理距离(离 GPU die 太远延迟高)
  80GB 是 A800 的极限
  所以大模型必须多卡
```

---

## 补充 3: 存储

### NVMe 内部

```
3.84TB NVMe SSD:

┌───────────────────────────────┐
│  NVMe Controller (ARM)         │
│  FTL (逻辑→物理地址映射)        │
│  Wear Leveling (让所有块均匀使用)│
│  GC (回收已删除的块)             │
├───────────────────────────────┤
│  DRAM Buffer: 2GB              │
├───────────────────────────────┤
│  NAND Flash × 16 chips         │
│  每 chip 有 4 dies × 2 planes  │
│  共 128 planes 并行             │
└───────────────────────────────┘

顺序写 (7GB/s): 128 plane × 16KB page = 2MB/次, 3500次/s
随机写 (100MB/s): 每次写前都要查FTL→更新→写, 有效带宽暴跌
```

### Lustre 为什么 ls 会卡

```
读 config.json:
  1. 客户端问 MDS: "config.json 在哪?" → MDS 返回 inode
  2. 客户端问 MDS: "inode 在哪个 OSS?" → MDS 返回 OSS#5
  3. 客户端直接找 OSS#5: "读 inode 的数据"

步骤 1-2 在 MDS, MDS 串行处理元数据请求
1000 个客户端同时做 1-2 → 排队

"ls /lustre" 卡住 = 你的请求排在第 900 位

解决:
  - 减少元数据操作
  - 模型 cp 到本地 NVMe 再加载
  - DNE (分布式元数据)
```

---

## 补充 4: 网络

### IB 交换机 vs TCP

```
                    IB             RoCE v2          TCP
延迟                1-2μs          2-5μs            50μs+
带宽                200Gbps        200Gbps          100Gbps
丢包                无损(ECN)      无损(PFC)        有!
拥塞控制            发送端减速      DCQCN            丢包→慢启动
CPU 参与            无(RDMA)       无(RDMA)         内核协议栈

IB 为什么低延迟:
  1. Cut-Through 转发: 收完 header 就开始转发, 不等整个包
  2. RDMA: 网卡直接读写远端内存, 零 CPU 参与
  3. ECN: 无损, 不需要重传

TCP 为什么高延迟:
  1. Store-and-Forward: 收完整包再转发
  2. 内核协议栈: 要经过 socket buffer, 上下文切换
  3. 丢包重传: 丢 1 个包 → 等超时 → 重传 → 慢启动
```

### 胖树拓扑 (Fat-Tree)

```
         ┌─── Spine (核心交换机) ───┐
         │  64口 IB, 全互联 Leaf     │
         └────────┬──┬──┬──────────┘
                  │  │  │
    ┌─────────────┼──┼──┼─────────────┐
    │ Leaf 0      │  │  │   Leaf N     │
    │ 40口 IB     │  │  │   40口 IB    │
    │ └─节点×16   │  │  │   └─节点×16  │
    └─────────────┼──┼──┼─────────────┘
                  │  │  │

同一 Leaf 内: 全带宽 (200Gbps × 16)
跨 Leaf: 带宽受限于 Spine 上行

NCCL 自动感知:
  同 Leaf → 低 rank → 更多通信
  跨 Leaf → 高 rank → 更少通信
```

### GPUDirect RDMA 的数据路径

```
无 GDR:
  GPU → PCIe → CPU 内存 → PCIe → NIC → 网络
  两次 PCIe + CPU 内存拷贝
  延迟: ~10μs

有 GDR:
  GPU → PCIe → NIC → 网络
  一次 PCIe, 不经过 CPU
  延迟: ~1-2μs

要求:
  GPU 和 NIC 在同一 PCIe Switch (PIX 或 PXB)
  开启 nvidia-peermem 内核模块
  NCCL_NET_GDR_LEVEL=5
```

---

## 补充 5: PCIe

### 拓扑查看

```
lspci -t -v
nvidia-smi topo -m

关键标识:
  PIX: 同一 PCIe Switch → 快
  PXB: 同一 PCIe Bridge → 可接受
  PHB: 不同 PCIe hierarchy → 经过 CPU
  NODE: 跨 NUMA → 慢
  SYS: 跨 CPU 间互联 (UPI) → 最慢
  NV12: NVLink 直连 → 最快

推理中:
  GPU-GPU: NV12 最快 (TP 用)
  GPU-NIC: PIX 最好 (GDR 跨节点通信)
```

### ACS 对性能的影响

```
ACS (Access Control Services): 安全特性, 阻止 P2P DMA

开了 ACS: 所有 device-to-device 通信强制经过 CPU → IOMMU
  → P2P 带宽从 32GB/s 降到 10GB/s
  → GDR 直接失效

检查:
  lspci -vvv | grep "ACSCtl"
  ACSCtl+: SrcValid+ → ACS 开了

BIOS 关 ACS, 或内核参数: pci=realloc pci=noats
```

---

## 补充 6: 推理全链路延迟

```
用户 "Hello" (5 token) → 推理服务:

1. 网络 (用户→服务器):        1-50ms
2. Nginx 解析:                0.1ms
3. Tokenizer (CPU):           0.5ms
4. 调度 (vLLM Scheduler):     0.1ms
5. Prefill (GPU):
   - kernel launch:            5μs
   - 读权重 (HBM):            0.2ms
   - Tensor Core 计算:         0.1ms
   - 写 KV Cache:             0.05ms
   TTFT ≈ 0.5ms (不计网络)

6. Decode (GPU, 每 token):
   - 读 KV Cache (不连续块):   0.2ms
   - 读权重 + 计算:            0.3ms
   - kernel launch gap:        0.1ms
   TPOT ≈ 8-20ms (实际)

7. 采样 + Detokenize (CPU):   0.2ms

8. 网络 (服务器→用户):        1-50ms

主要延迟 = 网络 (物理距离决定) + GPU Decode (HBM带宽决定)
集群侧: 跨节点 TP 多了 IB 通信 (+2-5ms/层边界)
```

---

# 第二部分：操作系统与底层原理

## 虚拟内存

### 为什么需要虚拟内存

```
每个进程以为自己独占所有内存:
  进程A: 看到地址 0x7fff0000 → 物理地址 0x1000 (由 OS 映射)
  进程B: 看到地址 0x7fff0000 → 物理地址 0x5000 (不同物理页!)
  
好处:
  1. 隔离: A 不能访问 B 的内存 (除非共享映射)
  2. 简化: 每个程序从 0 开始, 不用管实际物理内存布局
  3. 超分: 所有进程用到的虚拟内存之和 > 物理内存 → swap 到磁盘
```

### 页表翻译

```
虚拟地址 → 物理地址:

虚拟地址: [页目录索引 9bit][页表索引 9bit][页内偏移 12bit]
          (48-bit 地址空间, 4-level page table on x86-64)

翻译过程:
  1. CR3 寄存器 → 找到 Level 4 页表
  2. Level 4[索引0] → 找到 Level 3 页表
  3. Level 3[索引1] → 找到 Level 2 页表
  4. Level 2[索引2] → 找到物理页帧号
  5. 物理地址 = 页帧号 × 4KB + 偏移

每次内存访问要走 4 次页表查表 → 太慢了!

### TLB (Translation Lookaside Buffer)

TLB 是 CPU 内部的一个小 cache, 缓存最近翻译过的虚拟→物理映射:

有 TLB 命中: 虚拟地址 → TLB → 物理地址 (1 cycle)
无 TLB 命中: 走 4 级页表 (几百 cycles)

GPU 也有 TLB:
  A800: L1 TLB (每 SM) + L2 TLB (所有 SM 共享)
  GPU 的 TLB 比 CPU 小 → 大页(Huge Page)对 GPU 更重要

### 大页 (Huge Pages)

```
普通页: 4KB
大页:    2MB (512 个普通页)
巨页:    1GB

大页的好处:
  1. TLB 覆盖范围更大: 同样数量的 TLB entry, 大页可以覆盖更多内存
  2. 页表层级更少: 2MB 页只用 3 级页表 (省 1 级)
  3. 减少页错误 (page fault)

GPU 推理为什么用大页:
  GPU 显存管理大量 KV Cache block
  每个 block 需要虚拟地址映射
  如果每个 block 用 4KB 页 → TLB miss 严重
  大页 → TLB 覆盖更好 → DMA 更快

启用 GPU 大页:
  # 宿主机
  echo 1024 > /proc/sys/vm/nr_hugepages
  # NVIDIA driver 自动用大页管理 GPU BAR 空间
```

## 进程与线程

### 进程 vs 线程 vs CUDA kernel

```
进程:
  独立地址空间, 独立文件描述符
  进程间通信: pipe, socket, shared memory
  vLLM 中: 每个 Worker 是独立进程 (Ray actor)

线程:
  共享地址空间, 共享文件描述符
  线程间通信: 直接读写共享变量 (需要锁)
  vLLM 中: Tokenizer, HTTP server, scheduler 各在不同线程

CUDA kernel:
  在 GPU 上并行执行的函数
  不是进程也不是线程! 是 GPU 自己的调度单位
  CPU 只能 "launch kernel" 然后等
```

### 上下文切换

```
CPU 做上下文切换时:
  1. 保存当前进程/线程的寄存器
  2. 保存页表基址 (CR3)
  3. 加载新进程/线程的寄存器
  4. 加载新页表基址
  5. 返回
  
  耗时: ~1-10μs (取决于 cache 状态)

上下文切换对推理的影响:
  vLLM scheduler 是 CPU 线程
  如果 CPU 频繁切换 → scheduler 延迟增加 → launch gap 变大
  → 绑定 CPU 核心避免调度: taskset -c 0-15 python3 -m vllm...

GPU 也有上下文切换:
  GPU 多个 CUDA stream 之间切换 → 几乎零成本 (warp scheduler 硬件做)
  但多个 CUDA context (不同进程) 之间切换 → 成本大
  → 一个 GPU 最好只给一个推理进程用
```

## 中断与 DMA

### 中断

```
硬件需要 CPU 关注时, 发中断:

网卡收到包: 发中断 → CPU 停下当前任务 → 调用中断处理程序 → 继续原任务
键盘按键: 发中断 → CPU 处理
定时器: 每秒 1000 次中断 → CPU 调度决策 (时间片到了)

中断对推理的影响:
  太多中断 → CPU 频繁被打断 → scheduler 延迟不稳定
  → 推理服务的 P99 延迟抖动

优化:
  IRQ affinity: 把网卡中断绑定到指定的 CPU 核心
  → 其他 CPU 核心不被打断 → "干净"的核心专门给推理用

  echo 0-7 > /proc/irq/120/smp_affinity_list  # 中断只发到 CPU 0-7
  taskset -c 8-23 python3 -m vllm...           # 推理只用 CPU 8-23
```

### DMA (Direct Memory Access)

```
没有 DMA:
  CPU: "网卡, 把数据拷到内存地址 0x1234"
  CPU: 自己逐字节拷贝 (占用 CPU 时间)

有 DMA:
  CPU: "DMA 控制器, 把网卡数据拷到内存地址 0x1234"
  DMA 控制器: 自己完成 (CPU 可以做别的)
  完成后: DMA 控制器发中断 → CPU 知道数据到了

GPU 也是 DMA master:
  GPU: "DMA, 从 CPU 内存拷 256MB 到显存"
  DMA: 自己做, GPU 可以同时算

这就是 cudaMemcpyAsync + cudaStream 的原理:
  Stream 1: cudaMemcpyAsync (DMA 做的, GPU 不参与)
  Stream 2: kernel 执行 (GPU 在做计算)
  → 拷贝和计算重叠 → 隐藏延迟
```

## 并发原语

### 锁的本质

```
自旋锁 (spinlock):
  while (lock_is_held) {}   // 一直循环, 不放弃 CPU
  acquire_lock();
  
  优点: 如果锁很快释放, 不浪费上下文切换
  缺点: 白白消耗 CPU 周期 (在 wait 时)
  
  GPU 的 __syncthreads 类似自旋锁

互斥锁 (mutex):
  if (lock_is_held):
      sleep()               // 放弃 CPU, 让其他线程运行
  acquire_lock();
  
  优点: 不浪费 CPU
  缺点: 上下文切换开销 ~1-10μs

适用:
  锁持有时间短 → spinlock
  锁持有时间长 → mutex

vLLM 的 Scheduler 用 Python asyncio.Lock():
  基于 mutex 的异步锁
  等待时不阻塞整个线程
```

### 原子操作

```
i++ 在底层是三步:
  1. load i from memory
  2. add 1 to i
  3. store i to memory

如果两个线程同时做 i++:
  线程A: load i=0  →  add 1  →  store 1
  线程B: load i=0  →  add 1  →  store 1
  期望: i=2, 实际: i=1  ← 丢失了一次更新!

原子操作: 这三步不可打断
  atomic_add(&i, 1): load+add+store 一气呵成

GPU 的 atomicAdd:
  多个 warp 同时加, 硬件保证正确
  BlockAllocator 的 allocate() 就用 atomic 保护 free list

CUDA atomic 的例子 (vLLM 内部):
  // 从 free block queue 分配一个 block
  int block_id = atomicAdd(&free_list_head, 1);
  // 多个 warp 同时分配, 每个得到唯一的 block_id
```

### 内存屏障 (Memory Barrier / Fence)

```
CPU/GPU 会乱序执行:
  代码:        实际执行:
  A = 1;       B = 2;     ← CPU 觉得先写 B 更快
  B = 2;       A = 1;

单线程没问题 (最终结果对)
多线程/多设备: 灾难!

  CPU:        GPU:
  data = 42;   while (!ready) {}  // 等 ready flag
  ready = 1;   print(data);       // 期望打印 42

  实际: 可能打印 0!
  原因: CPU 乱序, ready=1 可能比 data=42 先写到内存
       GPU 看到 ready=1 → 读 data → data 还是 0

内存屏障: 强制顺序
  data = 42;
  __sync_synchronize();  // 屏障: 之前的所有写必须完成
  ready = 1;             // 保证 data=42 已在内存中

CUDA 的 __threadfence():
  保证当前线程的写对所有其他线程可见
  用于实现无锁数据结构的正确性
```

## GPU 内存类型

### Pinned Memory (页锁定内存)

```
普通 CPU 内存: 可以被 OS swap 到磁盘
  → GPU DMA 时, 内存可能在磁盘上 → 需要先 load → 慢

Pinned Memory: 锁定在物理内存中, 绝不 swap
  cudaHostAlloc(size, cudaHostAllocDefault)
  
  好处: GPU DMA 可以直接读 (不需要先检查 swap)
  坏处: 占用物理内存, 影响系统整体性能

vLLM 中的 CPU swap space:
  被 swap 到 CPU 的 KV Cache 存在 pinned memory 中
  这样 GPU 再读回来时可以直接 DMA
```

### Unified Memory

```
CUDA Unified Memory:
  同一个指针在 CPU 和 GPU 都能访问
  cudaMallocManaged(&ptr, size)
  
  访问时: GPU 缺页 → 自动从 CPU 内存迁移到 GPU 显存
         CPU 缺页 → 自动从 GPU 显存迁移回来
  
  方便但慢: 需要硬件缺页处理 (A100 起支持)
```

---

## 第三部分: 分布式系统理论

## 为什么分布式难

```
单机程序:
  x = read(file)
  y = x + 1
  write(file, y)
  → x, y 的值是确定的, 一个时间线的

分布式程序 (3 个节点):
  节点0: x = read(file)   ← 从共享存储读
  节点1: x = read(file)   ← 同时读
  节点2: x = read(file)   ← 同时读
  
  节点0: write(file, x+1)
  节点1: write(file, x+2)
  节点2: write(file, x+3)
  
  最终文件里是什么? 不确定! 取决于谁最后写
  
这就是分布式一致性问题
推理中比较简单 (只读模型, 各做各的)
但模型更新 (新版本发布) 就需要一致性
```

## CAP 定理

```
C (Consistency): 所有节点看到相同的数据
A (Availability): 每个请求都得到响应 (不挂)
P (Partition Tolerance): 网络断开还能工作

只能三选二!

推理服务的选择:
  放弃 C (强一致性): 不要求所有节点同时看到新模型
  保留 A (可用性): 服务不能挂
  保留 P (分区容忍): 网络出问题也要继续服务

  所以在灰度发布时:
    有些节点跑 v1.0, 有些跑 v2.0 (放弃了 C)
    但服务持续可用 (A)
    每个节点独立运行, 不依赖其他节点 (P)
```

## 共识算法简介

```
多节点要达成一致决策: "现在切换到新模型版本"

Raft 协议:
  1. 选 Leader
  2. Leader 提议: "切换到 v2.0"
  3. 多数派确认: 3/5 节点 agree
  4. 执行切换
  5. 广播结果

推理中:
  模型分发不需要共识 (共享存储, 各读各的)
  请求级的一致性: 用户问相同问题 → 最好给相同答案
    → 用相同 temperature=0 保证确定性
```

---

## 总结: 一个 Token 的完整旅程 (硬件视角)

```
用户: "Hello"

1. 用户 → 服务器
   光电转换 → 光纤 → IB 交换机 (Cut-Through, ~100ns) → 服务器网卡
   网卡 DMA → CPU 内存 (不经过 CPU!)
   网卡发中断 → CPU 知道数据到了

2. CPU 处理
   Nginx 从 socket buffer 读数据 (DMA 已经放好了)
   解析 HTTP → 路由到 vLLM API server
   vLLM: Tokenizer (CPU SIMD 加速) → 5 个 token IDs
   
3. GPU 推理 (Prefill)
   CPU: cudaMemcpyAsync 拷 input_ids 到 GPU 显存 (PCIe DMA)
   CPU: Launch kernel (写 GPU 寄存器 → 告诉 GPU "开始算")
   GPU: Warp Scheduler 开始调度
        SM 从 HBM 读权重 (2TB/s)
        Tensor Core: FP16 GEMM (312 TFLOPS)
        SMEM: FlashAttention 分块计算
        KV Cache 写回 HBM (PagedAttention 分页)
   GPU: 完成, 发中断给 CPU

4. GPU 推理 (Decode, 重复 N 次)
   和 Prefill 一样, 但只处理 1 token
   → KV Cache 从 HBM 读 (不连续 block → DMA 效率低)
   → HBM 带宽瓶颈 (每 token 0.2ms 理想, 实际 8-20ms)

5. CPU 采样
   从 GPU 读 logits (PCIe DMA)
   Temperature + Top-P + Softmax → 选下一个 token
   Detokenize → 文字

6. 服务器 → 用户
   Nginx 发送 response (SSE streaming)
   CPU: 写数据到 socket buffer
   网卡: DMA 从 CPU 内存读 → 光纤 → 交换机 → 用户

全链路延迟:
  网络: 1-50ms (物理距离)
  CPU 处理: ~1ms
  Prefill: ~1ms (短) ~500ms (长)
  Decode: ~15ms/token × N tokens
  网络: 1-50ms

  对于短 prompt (10 token) + 短输出 (50 token):
    总延迟 ≈ 50 + 1 + 1 + 50×15 + 50 ≈ 850ms
    
  主要时间 = Decode × 输出长度 (50 × 15ms = 750ms)
```
