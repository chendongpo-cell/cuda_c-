# 多节点跨机推理

## 场景

单机 8×A800 只能放下 72B，万卡集群要跑 405B/DeepSeek-V3/更大模型，必须跨节点。

## 跨节点方案总览

```
模型大小        单机能放？        方案
──────────────────────────────────────────
< 80B           ✅               TP=1~4, 单机搞定
80-160B         ⚠️ 紧张          TP=8, 单机
160-400B        ❌               跨节点 TP (张量并行)
400B-1T         ❌               跨节点 TP + PP (张量+流水线)
> 1T (MoE)      ❌               EP (专家并行) + TP + PP
```

## 方案 1: 跨节点张量并行 (TP)

```
2 节点, 每节点 8×A800, 共 16 卡, TP=16

节点0 (8卡, NVLink 400GB/s):
  卡0-7: 持有 W 的 1/16
节点1 (8卡, NVLink 400GB/s):
  卡8-15: 持有 W 的 1/16

每层 Transformer: 2 次 AllReduce (Attention 后 + MLP 后)
跨节点 AllReduce: 数据在节点间通过网络传输

通信分析:
  节点内 AllReduce: NVLink 400GB/s → 几乎无感
  跨节点 AllReduce: InfiniBand/RoCE → 瓶颈就在这里!

  一次 AllReduce (batch=8, seq=4096, hidden=4096):
    数据 = 8 × 4096 × 4096 × 2 bytes = 256 MB
    Ring AllReduce: 2×(N-1)/N × 256MB = 2 × 15/16 × 256 ≈ 480 MB
    
    NVLink (节点内): ~1-2ms
    跨节点 IB (200Gbps): 480MB × 8bits/byte / 200Gbps ≈ 19ms
    
  整个模型 80 层, 160 次 AllReduce:
    跨节点通信总时间: 160 × 19ms ≈ 3 秒
    
  纯计算时间 (TP=16): ~0.5 秒
  
  通信占比 = 3 / (3+0.5) ≈ 86% → 完全不可接受!

结论: 跨节点纯 TP 不可行, 通信太多了
```

## 方案 2: 流水线并行 (PP)

```
4 节点, 每节点 8 卡, PP=4

节点0: Layer 0-19    (TP=8, 80GB/8=10GB 显存/卡)
节点1: Layer 20-39   (TP=8)
节点2: Layer 40-59   (TP=8)
节点3: Layer 60-79   (TP=8)

数据流动:
  microbatch_0 → 节点0 → 节点1 → 节点2 → 节点3
  只传 activation (batch×seq×hidden), 不传权重

  每层边界的通信量:
    batch × seq × hidden × 2bytes = 8 × 4096 × 4096 × 2 = 256 MB
    
  IB 200Gbps: 256MB × 8 / 200Gbps ≈ 10ms
  节点边界只有 2 个 (节点0→1, 1→2, 2→3: 3 个边界)
  
  总通信: 3 × 10ms = 30ms
  总计算: ~2 秒 (TP=8 下)
  
  通信占比 ≈ 1.5% → 可接受!

但 PP 有 bubble:
  PP=4, B=8 microbatches:
  bubble = (PP-1) / B = 3/8 ≈ 37.5%
  → 37.5% 的时间 GPU 空闲

增大 microbatch 数: B=32 → bubble = 3/32 ≈ 9.4%
→ 需要更多显存放 intermediate activation
```

## 方案 3: TP + PP 混合 (推荐)

```
2 台机器 (Node A, Node B), 每台 8×A800

配置: TP=4, PP=2
  节点 A: TP=4 做 Layer 0-39
  节点 B: TP=4 做 Layer 40-79

节点内: TP=4 (NVLink, 通信 ~5%)
节点间: PP=2 (IB, 通信 ~2%)
PP bubble: (2-1)/B → B=8 → 12.5%

总效率: ~80% GPU 利用率
→ 这是最平衡的方案
```

## 方案 4: 专家并行 (EP) for MoE

```
DeepSeek-V3: 671B 总参数, 但每次只激活 37B

MoE 层: 256 个 Expert, 每次激活 8 个

EP=8: 8 个节点, 每个节点存 32 个 Expert
  同时有 TP=4, PP=2:
  总共需要 8×2=16 个节点, 每节点 8 卡 = 128 卡

每个 token:
  Router 决定发给哪些 Expert
  All-to-All 通信: token 发到正确的节点
  Expert 计算: 在自己的节点上算
  All-to-All: 结果传回来

EP 的通信模式:
  不同 token 发到不同 Expert → All-to-All 不是 AllReduce
  通信量: batch × seq × hidden × (EP-1)/EP
  
  batch=32, seq=4096, hidden=7168: 
  每个 All-to-All ≈ 1.7 GB
  
  IB 200Gbps: ~68ms → 两次 All-to-All ≈ 136ms
  计算: ~200ms
  
  通信占比 ≈ 40% → 还行
```

## vLLM 多节点部署

```bash
# 节点0 (head node)
ray start --head --port=6379

# 节点1-3 (worker nodes)
ray start --address='节点0_IP:6379'

# 提交 vLLM 任务
python3 -c "
from vllm import LLM
llm = LLM(
    model='/data/models/Qwen2.5-72B',
    tensor_parallel_size=4,          # 每节点 TP=4
    pipeline_parallel_size=2,        # 2 节点 PP
    distributed_executor_backend='ray',
)
"
```

## 跨节点通信的核心瓶颈

```
InfiniBand HDR (200Gbps):
  实际带宽 ~23 GB/s (单向)
  AllReduce 有效带宽 ~46 GB/s (双向)

RoCE (RDMA over Converged Ethernet):
  200Gbps Ethernet
  RDMA enabled
  ~20 GB/s 实际带宽

NCCL Ring AllReduce 跨节点:
  通信量 = 2×(N-1)/N × data_size
  
  8 节点, 64 卡 (每节点 8 卡):
    节点内: NVLink 全互联
    节点间: IB tree/ring
    
  NCCL 默认算法:
    节点内: Ring (NVLink 快)
    节点间: Tree (减少跨节点通信次数)

调优:
  export NCCL_CROSS_NIC=1           # 跨 NIC 通信
  export NCCL_IB_DISABLE=0          # 启用 IB
  export NCCL_NET_GDR_LEVEL=5       # GPUDirect RDMA
  export NCCL_IB_HCA=mlx5_0,mlx5_1  # 指定 IB 网卡
```

## 实际经验

```
1. 尽量不要跨节点 TP
   节点内 TP=8, 跨节点用 PP
   跨节点 TP 的通信开销远大于 PP 的 bubble

2. 节点数量优化
   2 节点: TP=8 + PP=2 (最优)
   4 节点: 考虑 TP=4 + PP=4
   8+ 节点: PP 的 bubble 开始严重, 考虑 DP(数据并行)

3. 网络拓扑感知
   同一个交换机下的节点 → NCCL 自动用 local rank
   跨交换机 → 延迟更高
   知道物理拓扑才能调 NCCL topology

4. GPU 故障
   万卡集群每天都有 GPU 坏
   训练: 自动跳过坏 GPU, 重新分配
   推理: 备用节点热切换

5. 模型加载时间
   72B 从共享存储加载: 30-60 秒
   405B: 3-5 分钟
   预加载到内存池: <1 秒 (但占内存)
```
