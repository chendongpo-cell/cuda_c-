# RLHF 与 DPO 原理

## 一句话总结
RLHF 三步：收集偏好 → 训 Reward Model → PPO 优化。DPO 巧妙消掉 Reward Model，直接优化模型。DPO 更稳定，已成为主流。

## RLHF 三阶段

### Stage 1: SFT (Supervised Fine-Tuning)
```
用高质量的 (prompt, response) 对微调基础模型
→ 得到一个会跟人正常对话的模型
```

### Stage 2: 训练 Reward Model
```
收集数据: 对同一个 prompt，生成多个 response，人工排序（A > B > C）

Reward Model 训练:
  Loss = -log(σ(r_θ(x, y_w) - r_θ(x, y_l)))
  其中 y_w = chosen (更好的回答), y_l = rejected (更差的回答)

  本质是学一个 Bradley-Terry 偏好模型:
  P(y_w > y_l | x) = σ(r(x, y_w) - r(x, y_l))
```

### Stage 3: PPO 优化
```
优化目标:
  max E[r_θ(x, y)] - β × KL(π_current || π_ref)

  reward term: 让模型生成高分回答
  KL penalty: 防止模型走太远，脱离原始语言能力 (别变成"高分胡言乱语")
```

### RLHF 的问题
- 需要同时加载 4 个模型 (Policy, Reference, Reward, Value/Critic) → 显存爆炸
- PPO 训练不稳定（reward hacking, 模式崩溃）
- 实现复杂，超参多

## DPO (Direct Preference Optimization)

### 核心洞察
```
RLHF 的 PPO 目标函数中，最优策略有解析解:
  π*(y|x) ∝ π_ref(y|x) × exp(r(x,y)/β)

反解: r(x,y) = β × log(π*(y|x)/π_ref(y|x)) + β × log(Z)

代入 Bradley-Terry 偏好模型，消掉 r:
  Loss_DPO = -log σ( β[log π_θ(y_w|x)/π_ref(y_w|x)
                      - log π_θ(y_l|x)/π_ref(y_l|x)] )
```

**不需要 Reward Model！** 只需要：
- 当前策略 π_θ（正在训练的模型）
- 参考策略 π_ref（原始模型，冻结）

### DPO vs RLHF

| 维度 | RLHF | DPO |
|------|------|-----|
| 模型数量 | 4个 | 2个 |
| 训练稳定性 | 差（PPO容易崩） | 好 |
| 显存 | 高 | 中等 |
| 实现难度 | 高 | 低 |
| 数据需求 | 偏好对 | 偏好对（相同） |
| 主流程度 | 逐渐被替代 | 当前主流 |

## 偏好数据格式

```json
{
  "prompt": "解释什么是黑洞",
  "chosen": "黑洞是宇宙中引力极强的天体，连光都无法逃逸...",
  "rejected": "黑洞是黑的洞。"
}
```

## 为什么可以直接DPO不先SFT？
- DPO 理论上可以直接训 base model
- 但实践中建议先 SFT（把模型拉到"会说话"的起点）
- 流程: SFT → DPO（提升对齐质量）

## 下载源

```bash
# DPO 偏好数据集
# https://huggingface.co/datasets/Anthropic/hh-rlhf

# LLaMA-Factory 支持 DPO:
# stage: dpo (而不是 sft)
```
