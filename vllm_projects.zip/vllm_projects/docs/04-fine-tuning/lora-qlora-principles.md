# LoRA/QLoRA 原理深度解析

## 一句话总结
LoRA 假设微调时权重变化 ΔW 是低秩的，用两个小矩阵 B×A 近似 ΔW，可训练参数减少 99%+。QLoRA 进一步把基础模型量化为 NF4 格式，让 7B 模型微调只需 ~4.5GB 显存，消费级显卡也能做。

## 为什么全参数微调不可行

```
全参数微调 Qwen2.5-7B:
  模型参数: 14 GB (FP16)
  优化器 (Adam): 每参数需要:
    momentum (FP32): 4 bytes
    variance (FP32):  4 bytes
    param_copy (FP32): 4 bytes
    → 12 bytes/参数
  优化器状态: 7B × 12 = 84 GB
  梯度 (FP16): 7B × 2 = 14 GB
  
  总计: 14 + 84 + 14 = 112 GB ← 一张 A800 只有 80GB!

全参数微调 Qwen2.5-72B:
  总计: 144 + 864 + 144 ≈ 1152 GB ← 需要 15 张 A800

→ 全参数微调对个人/小团队完全不现实
→ 需要参数高效微调方法 (PEFT)
```

## LoRA (Low-Rank Adaptation)

### 核心假设

```
微调时, 权重的变化 ΔW 是低秩的:
  ΔW ∈ R^{d×k} 
  rank(ΔW) = r << min(d, k)

这意味着可以用两个小矩阵的乘积来近似 ΔW:
  ΔW ≈ B × A
  其中 B ∈ R^{d×r}, A ∈ R^{r×k}

参数节省:
  全量: d×k 个参数
  LoRA: r×(d+k) 个参数
  
  d=4096, k=4096, r=16:
    全量: 16,777,216
    LoRA: 16 × 8192 = 131,072
    节省: 99.2%
```

### 数学形式

```
原始前向:  h = W₀ × x

LoRA 前向: h = W₀ × x + B × A × x
                └─ 冻结 ─┘ └── 训练 ──┘

分开来看:
  base_output = W₀ × x        ← 基础模型输出, W₀ 冻结
  lora_output = B × (A × x)   ← LoRA 贡献, A 和 B 可训练
  final = base_output + lora_output
```

### 为什么低秩假设成立

```
Aghajanyan et al. (ICLR 2021) "Intrinsic Dimensionality":
  对预训练模型的参数空间做随机投影
  发现: 模型越大, 任务适配需要的 "内在维度" 越低

通俗理解:
  大模型已经学会了几乎所有语言知识
  微调只是 "激活" 或 "抑制" 某些已有能力
  不需要改动所有参数, 只需要在少数方向上调
  
Bert: intrinsic dim ≈ 1000 (较大, 小模型不够通用)
GPT-3 175B: intrinsic dim ≈ 2500 (相对非常小!)

LoRA 的 r=16 就对应这 16 个 "内在维度"
```

### 哪些层加 LoRA

```python
# Transformer 中的线性层:
# Q 投影: W_Q [hidden, hidden]
# K 投影: W_K [hidden, hidden]  
# V 投影: W_V [hidden, hidden]
# O 投影: W_O [hidden, hidden]
# Gate:   W_gate [hidden, intermediate]
# Up:     W_up   [hidden, intermediate]
# Down:   W_down [intermediate, hidden]

# LLaMA-Factory lora_target: all
# → 所有 7 个线性层都加 LoRA
# → 总参数量: 7 × r × (hidden + hidden_or_intermediate)
```

### 秩 r 的选择

```
r=4:  Qwen3-8B LoRA 参数 ~70K
  适合: 简单分类、情感分析
  效果: 接近全参微调 90%+

r=8:  LoRA 参数 ~140K
  适合: 命名实体识别、摘要

r=16: LoRA 参数 ~280K  ← 推荐默认值
  适合: 对话、指令遵循、代码生成
  效果: 接近全参微调 95%+

r=32: LoRA 参数 ~560K
  适合: 复杂推理、需要大量知识注入

r=64: LoRA 参数 ~1.1M
  效果提升开始递减
  收益/成本比下降

经验规则:
  r 翻倍 → 参数量翻倍 → 效果提升 ~3-5% → 递减
  大多数任务 r=16 足够
  代码/数学任务可试 r=32
```

### Alpha 和 Dropout

```python
# LoRA 的完整公式:
# h = W₀ × x + (α/r) × B × A × x
#               ^^^^^
#               scaling 因子

# α (alpha): 控制 LoRA 贡献的强度
# 通常 α = 2×r (如 r=16 → α=32)
# 增大 α → LoRA 影响更大 → 模型改变更激进
# 减小 α → LoRA 影响更小 → 更保守
```

## QLoRA: 量化基础模型

### 为什么需要 QLoRA

```
LoRA 已经减少了可训练参数, 但基础模型还是 FP16:
  7B FP16: 14 GB ← 仍然需要 A100/A800 级别
  → 消费级显卡 (RTX 3090 24GB, RTX 4090 24GB) 能跑但不能同时加载 batch

QLoRA: 把基础模型量化为 NF4:
  7B NF4: 14/4 = 3.5 GB ← 单卡轻松!
  加上 LoRA 参数 + 优化器 ~1GB
  总计 ~4.5 GB → RTX 3060 12GB 都能微调 7B
```

### NF4 (NormalFloat4)

```
传统 INT4: 均匀量化, -8,-7,...,0,...,6,7
  → 假设权重均匀分布 → 对正态分布不友好

NF4: 假设权重 ~ N(0, 1), 设计最优 4-bit 表示
  → 值域 [-1, 1] 分成 16 个区间
  → 每个区间的概率质量相等
  → 对神经网络权重最优

对比:
  INT4: 均匀间隔, [-8,7] → 量化误差较大
  NF4:  按正态分布设计 → 量化误差最小
```

### 双重量化 (Double Quantization)

```
QLoRA = NF4 基础模型 + FP16 LoRA + Double Quantization

Double Quantization:
  量化需要 scale 和 zero_point 参数
  这些参数通常也占显存

  第一重: 每 64 个权重一个 scale (FP32)
    一个 7B 模型有 7B/64 ≈ 110M 个 scale × 4 bytes = 440 MB ← 不小!

  第二重: 再对 scale 做 FP8 量化
    440 MB → 110 MB
    节省 ~330 MB → 对 24GB 显存这是实实在在的 1.4%

双重量化让 QLoRA 从 ~4.8GB 降到 ~4.5GB
```

### 显存分解（7B 模型微调）

| 组件 | 全参 FP16 | LoRA FP16 | QLoRA NF4 |
|------|----------|-----------|-----------|
| 基础模型 | 14 GB | 14 GB | **3.5 GB** |
| LoRA 参数 | — | ~0.01 GB | ~0.01 GB |
| 优化器 (Adam) | 84 GB | ~0.1 GB | ~0.1 GB |
| 梯度 | 14 GB | ~0.01 GB | ~0.01 GB |
| 激活值 (bs=1) | ~4 GB | ~4 GB | ~4 GB |
| **总计** | **116 GB** | **~18 GB** | **~8 GB** |
| 最低 GPU | 5×A800 | 1×A800 | **1×RTX 3060** |

## 训练配置详解

### LLaMA-Factory YAML 参数含义

```yaml
per_device_train_batch_size: 4    # 每 GPU 每步的样本数
gradient_accumulation_steps: 8    # 积累 8 步才更新 → effective batch = 4×8 = 32
learning_rate: 5.0e-5             # 学习率: LoRA 建议 1e-4 (比全参大, 因为参数少)
num_train_epochs: 3               # 全量数据过 3 遍 (小数据集可多几遍)
lr_scheduler_type: cosine         # 余弦退火: 学习率从 5e-5 逐渐降到 ~0
warmup_ratio: 0.1                 # 前 10% 步从 0 慢慢涨到 5e-5
bf16: true                        # BF16 混合精度 (不需要 loss scaling)
```

### 学习率怎么选

```
LoRA 学习率建议比全参微调大:
  全参: 1e-5 ~ 5e-5
  LoRA: 1e-4 ~ 5e-4 (因为可训练参数少, 需要更大的步长)
  
太大了: loss 震荡, 不收敛
太小了: 学习太慢, epoch 用完了还没学好

经验: 从 2e-4 开始, 看 loss 曲线
  loss 下降平稳 → 合适
  loss 震荡 → 减半
  loss 几乎不动 → 加倍
```

## 推理时加载 LoRA

```bash
# vLLM 动态加载 LoRA (不需要 merge)
python3 -m vllm.entrypoints.openai.api_server \
    --model /path/to/base-model \
    --enable-lora \
    --lora-modules my-adapter=/path/to/lora-checkpoint \
    --max-lora-rank 64

# API 调用时指定 adapter
curl ... -d '{"model":"my-adapter","messages":[...]}'
```

```python
# 或手动 merge (方便部署)
from peft import PeftModel
base_model = AutoModelForCausalLM.from_pretrained("base-model")
lora_model = PeftModel.from_pretrained(base_model, "lora-checkpoint")
merged_model = lora_model.merge_and_unload()
merged_model.save_pretrained("merged-model")
```

## 实战检查清单

- [ ] 选好基础模型 (Qwen3-8B 推荐)
- [ ] 准备数据 (Alpaca/ShareGPT 格式, 质量 > 数量)
- [ ] 选 r 值 (16 开始)
- [ ] 选学习率 (2e-4 开始)
- [ ] 设置 warmup (10% 步数)
- [ ] 观察 loss 曲线 (稳步下降 = 正常)
- [ ] 在验证集测效果
- [ ] 对比不同 r 的效果
- [ ] 显存不够 → 开 QLoRA 或减 batch size

## 安装命令

```bash
# LLaMA-Factory
git clone https://github.com/hiyouga/LLaMA-Factory.git
pip install -e ".[torch,metrics]"

# 或只用 peft 库
pip install peft bitsandbytes

# bitsandbytes: QLoRA 依赖 (NF4 量化)
# peft: HuggingFace 的 PEFT 库 (LoRA 实现)
```

---

## 微调常见问题排查

### 1. "Loss 不下降 / 震荡"

```
可能原因和解决:

a. 学习率太大 → loss 震荡
   现象: loss 曲线锯齿状, 不收敛
   解决: lr 从 5e-4 降到 2e-4 或 1e-4

b. 学习率太小 → loss 几乎不动
   现象: loss 一直平, 没变化
   解决: lr 从 5e-5 升到 2e-4

c. 数据质量问题
   现象: loss 不降, 但改数据后就好了
   排查: 随机抽 10 条数据看:
     - 输出和指令是否匹配？
     - 有无乱码/格式错误？
     - 有无 answer 太短或太长的问题？

d. batch size 太小
   现象: loss 曲线噪音很大
   解决: 增大 gradient_accumulation_steps

e. warmup 不够
   现象: 前几步 loss 很大然后慢慢降
   解决: warmup_ratio 从 0.1 增到 0.2
```

### 2. "微调完效果反而变差了 (catastrophic forgetting)"

```
现象: 目标任务确实学会了, 但原来会的东西忘了

原因: LoRA rank 太高或学习率太大
  模型在少量数据上 overfit, 把原有能力覆盖了

解决:
  1. 降 lora_rank: 32→16→8
  2. 降学习率: 2e-4→5e-5
  3. 增数据量: 100→500→1000
  4. 加 regularization: lora_dropout=0.1
  5. 混合原始数据: 在微调数据里混 10-20% 通用数据
```

### 3. "加载 LoRA adapter 到 vLLM 报错"

```
常见错误:

"LoRA rank mismatch":
  训练时 r=32, 但 vLLM 启动时 --max-lora-rank 16
  解决: --max-lora-rank 32  (大于等于训练用的 r)

"KeyError: base_model.model.*":
  adapter 保存格式不对
  解决: 用 merge_and_unload() 后再保存, 或检查 peft 版本

"CUDA OOM when loading LoRA":
  基础模型 + LoRA 额外参数 > 显存
  解决: 用 --enable-lora (动态加载, 只在调用时激活)
```

### 4. "GPU 显存够, 但训练报 OOM"

```
这是 optimizer state 炸了 (不是模型参数):

  Qwen3-8B + LoRA r=16:
    模型: 16 GB (冻结)
    LoRA: 0.02 GB
    优化器: ~0.1 GB (只更新 LoRA 参数)
    激活值: B × S × H × L × bytes
      batch=4, seq=2048, hidden=4096, layers=32:
      4×2048×4096×32×2 ≈ 8 GB
  
  → 总显存 = 16 + 0.1 + 8 = 24 GB ← 刚好 A800 够

但如果你 batch=8, seq=4096:
  8×4096×4096×32×2 ≈ 32 GB
  → 总显存 = 16 + 0.1 + 32 = 48 GB

解决:
  1. 减 batch size
  2. 减 cutoff_len (max sequence length)
  3. 开 gradient_checkpointing (用计算换显存, 慢 20%)
  4. 开 QLoRA (NF4 量化, 模型 3.5GB)
```

### 5. "训练完的 LoRA 和基础模型不兼容"

```
症状: 加载 adapter 时报 "unexpected key" 或 "missing key"

原因: LoRA 是附着在特定模型结构上的
  在 Qwen3-8B 上训练的 LoRA → 不能加载到 Qwen2.5-7B

  即使同架构:
  在 Qwen3-8B FP16 上训练的 → Qwen3-8B GPTQ 可能不行
  (因为量化可能改变了某些层的结构)

解决: 微调和推理用同一个基础模型
  如果需要换格式:
    用 merge_and_unload() → 合并成完整模型 → 再量化
    而不是拿 FP16 的 LoRA 往 GPTQ 模型上套
```
