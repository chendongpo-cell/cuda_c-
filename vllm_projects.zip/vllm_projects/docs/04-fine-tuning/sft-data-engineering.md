# SFT 数据工程

## 一句话总结
SFT 的核心不是模型，是数据。数据质量 > 数据数量。格式统一（Alpaca/ShareGPT）、指令多样、答案准确，三个缺一不可。

## 数据格式

### Alpaca 格式（推荐入门）

```json
[
  {
    "instruction": "判断以下新闻属于哪个类别：科技、财经、还是体育。只输出类别名称。",
    "input": "华为发布最新昇腾910C芯片，算力提升3倍。",
    "output": "科技"
  }
]
```

### ShareGPT 格式（多轮对话）

```json
[
  {
    "conversations": [
      {"from": "human", "value": "写一个Python快排"},
      {"from": "gpt", "value": "def quicksort(arr):..."},
      {"from": "human", "value": "加上注释"},
      {"from": "gpt", "value": "def quicksort(arr):\n    # 基线条件..."}
    ]
  }
]
```

## 数据质量原则

### 1. 指令多样性
- 不要全是一种句式："请做X"、"请帮我做X"
- 混入：反问、纠错、多约束、角色扮演等不同风格
- 目标：覆盖实际使用中会遇到的各类指令

### 2. 答案准确性
- 事实性内容必须正确（尤其是知识类问答）
- 代码必须可运行（微调代码模型时）
- 可以用大模型（GPT-4）验证答案质量

### 3. 数据去重
```python
# 简单的相似度去重
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('BAAI/bge-large-zh-v1.5')
embeddings = model.encode(instructions)
# 计算 cosine similarity，去除 >0.95 的重复项
```

### 4. 长度分布
- prompt 长度和 answer 长度要接近实际使用场景
- 避免「训练时全是短答案，推理时用户期望长答案」的 mismatch

## 数据量经验

| 任务复杂度 | 最低数据量 | 推荐数据量 | 收益递减点 |
|-----------|----------|----------|----------|
| 简单分类 | 50-100 | 500 | ~1000 |
| 指令遵循 | 500 | 2000-5000 | ~10000 |
| 代码生成 | 1000 | 5000-10000 | ~20000 |
| 复杂推理 | 5000 | 10000+ | ~50000 |

> LIMA 论文 (Meta): 1000 条高质量数据足以激活大模型的指令遵循能力

## 数据来源

1. **开源数据集**: Alpaca, Dolly, OpenOrca, ShareGPT
2. **自建数据集**: 从业务日志/客服记录/ticket 整理
3. **LLM 合成**: 用 GPT-4 生成 + 人工审核过滤
4. **ModelScope 数据集**: https://www.modelscope.cn/datasets

## 数据清洗清单

- [ ] 去除重复（完全重复 + 语义重复 > 0.95）
- [ ] 去除乱码/无效字符
- [ ] 去除 HTML/Markdown 残留
- [ ] 去除个人信息 (PII)
- [ ] 检查指令-答案是否匹配
- [ ] 检查答案事实正确性（抽样）
- [ ] 检查长度分布是否合理
- [ ] 检查特殊 token 是否干净

## 下载源

```bash
# Alpaca 中文数据集
# https://huggingface.co/datasets/silk-road/alpaca-data-gpt4-chinese

# ModelScope 数据集
# https://www.modelscope.cn/datasets
```
