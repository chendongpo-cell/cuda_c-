# 分布式训练原理

## 一句话总结
大模型训练靠三种并行：数据并行(DP)、模型并行(TP/PP)和 ZeRO 优化。DeepSpeed ZeRO-3 把优化器状态、梯度、参数全部切分，让 13B 模型在单卡上训练成为可能。

## DeepSpeed ZeRO

### ZeRO-1: 切分优化器状态
```
传统: 每卡存完整优化器状态 (Adam: 参数×3)

ZeRO-1: 优化器状态切分到 N 卡
  每卡只存 1/N 的优化器状态
  显存减少: ~4× (Adam: 参数×12 → 参数×4×1/N)
```

### ZeRO-2: + 切分梯度
```
ZeRO-1 基础上，梯度也切分
  计算完梯度 → ReduceScatter 到各卡 → 各卡只存 1/N
  显存减少: ~8×
```

### ZeRO-3: + 切分参数
```
ZeRO-2 基础上，模型参数也切分
  每卡只存 1/N 的参数
  前向时需要某层参数 → AllGather 收集 → 计算 → 释放
  显存减少: 线性于 GPU 数

例: 7B 模型, 8卡
  每卡参数: 14GB → 14/8 = 1.75GB
  训练总显存 (含优化器/梯度): ~8GB/卡
```

## 显存分解 (Adam 优化器)

```
训练时每参数需要的显存:
  参数 (FP16):      2 bytes
  梯度 (FP16):      2 bytes
  优化器 (FP32):    4 + 4 = 8 bytes (momentum + variance)
  参数副本 (FP32):  4 bytes
  ─────────────────
  总计:             16 bytes/参数

即: 训练显存 ≈ 模型参数 × 16 ÷ GPU数 (ZeRO-3)

例: 7B 模型, 1卡: 7B × 16 = 112 GB  ← 无法训练
    7B 模型, 8卡 ZeRO-3: 112/8 = 14 GB/卡 ← 可以！
```

## FSDP (PyTorch 原生)

```
FSDP = Fully Sharded Data Parallel
≈ DeepSpeed ZeRO-3 的 PyTorch 实现

使用:
  from torch.distributed.fsdp import FullyShardedDataParallel
  model = FullyShardedDataParallel(model, ...)

与 DeepSpeed 对比:
  DeepSpeed: 功能更全 (ZeRO-Offload, ZeRO-Infinity)
  FSDP: PyTorch 原生，集成更简单
```

## 混合精度训练

```
FP32 → FP16 的问题: 梯度太小会 underflow (变为0)

混合精度 (AMP):
  前向/反向: FP16 (快)
  权重更新: FP32 (精度)
  loss scaling: 把 loss 放大再反向，避免梯度 underflow

BF16 的优势: 不需要 loss scaling (BF16 指数位够大)
```

## 梯度累积

```
显存放不下大 batch → 梯度累积

for i, batch in enumerate(dataloader):
    loss = model(batch) / accumulation_steps  # 梯度不更新
    loss.backward()
    if (i+1) % accumulation_steps == 0:
        optimizer.step()   # 积累够了才更新
        optimizer.zero_grad()

效果: effective_batch = per_device_batch × accumulation_steps × num_gpus
```

## 训练启动命令

```bash
# 单机多卡
torchrun --nproc_per_node=8 train.py

# 多机多卡
torchrun --nnodes=2 --nproc_per_node=8 \
    --master_addr=10.0.0.1 --master_port=29500 \
    train.py
```

## DeepSpeed 配置示例

```json
{
  "train_batch_size": 32,
  "gradient_accumulation_steps": 4,
  "zero_optimization": {
    "stage": 3,
    "offload_optimizer": {"device": "cpu"},
    "offload_param": {"device": "cpu"}
  },
  "fp16": {"enabled": false},
  "bf16": {"enabled": true}
}
```
