# CUTLASS 与 Triton：GPU 高性能计算内核深度剖析

> 本文档深入剖析 CUTLASS 与 Triton 两大 GPU 内核开发框架的架构设计、编程模型与实践技巧。
> 目标读者：具备 CUDA 基础知识、希望深入理解 GPU 内核开发的工程师。

---

## 一、CUTLASS 架构设计哲学

### 1.1 "积木块"哲学：为何选择模板而非代码生成

CUTLASS（CUDA Templates for Linear Algebra Subroutines）是 NVIDIA 开源的 CUDA C++ 模板库，其核心设计哲学是 **"积木块"（Building Blocks）**——将 GEMM 分解为一组可组合的、层次化的抽象概念，每个概念对应一个 C++ 模板类。

```
+---------------------------------------------------------------+
|                    CUTLASS 设计哲学                              |
|                                                                 |
|   代码生成方案 (如早期 cuBLAS):                                  |
|     Python/Perl 脚本 → 生成 .cu 文件 → 编译 → 二进制             |
|     ❌ 难以维护，难以扩展，组合爆炸                               |
|                                                                 |
|   CUTLASS 模板方案:                                              |
|     C++ 模板 → 编译器展开 → 零运行时开销 → 高度可组合             |
|     ✅ 类型安全，编译期优化，无代码生成步骤                       |
+---------------------------------------------------------------+
```

模板方案的核心优势：

1. **编译期多态**：所有分派在编译期完成，无虚函数开销
2. **组合性**：`Gemm<Mma<SmemLayout<...>, Tile<...>>, Epilogue<...>>` 可以任意组合
3. **类型安全**：所有维度、数据类型在编译期校验
4. **零额外抽象成本**：模板展开后与手写 CUDA 一致

```cpp
// CUTLASS 的核心理念：通过模板组合构建 GEMM
// 这不是伪代码——这就是 CUTLASS 实际的工作方式

// 第1层：描述张量布局
using LayoutA = cutlass::layout::RowMajor;
using LayoutB = cutlass::layout::ColumnMajor;
using LayoutC = cutlass::layout::RowMajor;

// 第2层：定义 Tile 大小
using TileShape = cutlass::gemm::GemmShape<128, 128, 32>;  // M, N, K

// 第3层：选择 MMA 指令 (Tensor Core)
using Mma = cutlass::gemm::warp::MmaTensorOp<
    cutlass::gemm::GemmShape<64, 64, 32>,  // Warp Tile
    cutlass::gemm::GemmShape<8, 8, 4>,      // Instruction Shape
    float,                                   // A 类型
    cutlass::layout::RowMajor,               // A 布局
    float,                                   // B 类型
    cutlass::layout::ColumnMajor,            // B 布局
    float,                                   // C 类型
    cutlass::layout::RowMajor                // C 布局
>;

// 第4层：组合成完整的 GEMM
using Gemm = cutlass::gemm::device::Gemm<float, LayoutA, float, LayoutB,
                                          float, LayoutC, float,
                                          cutlass::arch::OpClassTensorOp,
                                          cutlass::arch::Sm75>;
```

### 1.2 核心抽象：TileShape、WarpShape、InstructionShape

这三个 Shape 是理解 CUTLASS GEMM 层级结构的关键：

```
+=================================================================+
|                      CUTLASS GEMM 层级金字塔                       |
|                                                                   |
|                          ┌─────────┐                              |
|                          │  Gemm   │  ← 完整的 GEMM 操作           |
|                          └────┬────┘                              |
|                               │                                   |
|               ┌───────────────┼───────────────┐                   |
|               │               │               │                   |
|        ┌──────┴──────┐ ┌──────┴──────┐ ┌──────┴──────┐           |
|        │Threadblock 0│ │Threadblock 1│ │Threadblock N│  ← Grid   |
|        │ Tile:256x128│ │ Tile:256x128│ │ Tile:256x128│           |
|        └──────┬──────┘ └──────┬──────┘ └──────┬──────┘           |
|               │               │               │                   |
|        ┌──────┴──────┐        │        ┌──────┴──────┐           |
|        │  Warp 0     │  ...   │        │  Warp 7     │           |
|        │  Tile:64x64 │        │        │  Tile:64x64 │  ← Warp   |
|        └──────┬──────┘        │        └──────┬──────┘           |
|               │               │               │                   |
|         ┌─────┴─────┐         │         ┌─────┴─────┐            |
|         │ Thread 0  │  ...    │         │ Thread 31 │            |
|         │ WMMA:8x8  │         │         │ WMMA:8x8  │  ← Thread │
|         └───────────┘         │         └───────────┘            |
|                               │                                   |
|   TileShape  =  M=256, N=128, K=64   (Threadblock 层)            |
|   WarpShape  =  M=64,  N=64,  K=64   (Warp 层)                  |
|   InstShape  =  M=8,   N=8,   K=4    (指令层, m16n8k8/m16n8k16)  |
+=================================================================+
```

```cpp
// CUTLASS 中这三层 Shape 的定义方式

// 线程块 Tile：所有线程协作处理的子矩阵
// 决定每个 threadblock 从全局内存加载多少数据
using ThreadblockShape = cutlass::gemm::GemmShape<256, 128, 64>;
//                                                 M    N    K

// Warp Tile：每个 warp 负责的子矩阵
// 必须是 ThreadblockShape 的约数
// CUTLASS 支持多种 WarpShape，编译器在编译期验证比例关系
using WarpShape = cutlass::gemm::GemmShape<64, 64, 64>;
//                                          M   N   K

// Instruction Shape：单条 MMA 指令处理的矩阵乘法维度
// Ampere: m16n8k16 表示一条指令计算 16x8 @ 8x16 = 16x8 个元素
// Turing: m8n8k4
// Volta:  m8n8k4
using InstructionShape = cutlass::gemm::GemmShape<16, 8, 16>;
//                                                 M   N  K
```

### 1.3 CUTLASS 2.x vs 3.x 架构差异

```
+=================================================================+
|                   CUTLASS 2.x 架构                                |
|                                                                   |
|   Gemm :: device :: {Gemm, GemmSplitK}                            |
|     │                                                             |
|     ├── Kernel{DefaultGemm}                                       |
|     │   ├── Mma (Mainloop: 全局→共享→寄存器 MMA)                   |
|     │   │   ├── TileIterator (Threadblock 级数据迭代器)            |
|     │   │   ├── SmemTileIterator (共享内存 Tile 迭代器)            |
|     │   │   ├── MmaWarp (Warp 级 MMA + WMMA)                      |
|     │   │   ├── MmaThread (Thread 级 MMA)                         |
|     │   │   └── Transform (布局变换/类型转换)                      |
|     │   └── Epilogue (后处理: 元素级操作融合)                      |
|     │       ├── OutputTile (输出 Tile)                             |
|     │       ├── Visitor (访问者模式: bias, ReLU, ...)              |
|     │       └── OutputOp (输出操作)                                |
|     └── Template Parameter List (~30+ 模板参数)                    |
|                                                                   |
+=================================================================+
|                   CUTLASS 3.x 架构                                |
|                                                                   |
|   Gemm :: device :: collective :: {GemmUniversalAdapter}          |
|     │                                                             |
|     ├── CollectiveEpilogue (Epilogue 集合体)                      |
|     │   ├── Sm90 专有: TMA (Tensor Memory Accelerator) 加载       |
|     │   ├── 异步拷贝 + 流水线化                                   |
|     │   └── 自动产生 Store 流水线                                  |
|     │                                                             |
|     ├── CollectiveMma (MMA 集合体)                                |
|     │   ├── TMA 加载 A/B Tile                                     |
|     │   ├── 多阶段软件流水线 (AsyncPipeline)                      |
|     │   ├── Warp Group MMA (WGMMA)                                |
|     │   └── 共享内存 Bank Conflict 避免                           |
|     │                                                             |
|     ├── KernelSchedule (内核调度策略)                              |
|     │   ├── KernelTma (仅使用 TMA 加载)                           |
|     │   ├── KernelTmaWarpSpecialized (Warp 分工: Producer/Consumer)|
|     │   └── KernelPtrArray (指针数组, 支持 Grouped GEMM)          |
|     │                                                             |
|     └── Named Barrior (命名屏障, Hopper 特性)                      |
|                                                                   |
+=================================================================+
```

CUTLASS 3.x 的关键变革：

| 特性 | CUTLASS 2.x | CUTLASS 3.x |
|------|-------------|-------------|
| 核心概念 | 模板层级组合 | Collective 集合体 |
| 数据搬运 | `cp.async` (SM80+) | TMA (SM90+, Hopper) |
| 同步原语 | `__syncthreads()` | Named Barrier |
| Warp MMA | `mma.sync` | `wgmma.mma_async` + `warpgroup` |
| 模板参数 | ~30+ | 大幅简化（Collective 封装） |
| SM 版本 | SM50~SM89 | SM90+ |

### 1.4 GEMM 的多层 Tile 分解

CUTLASS 将 GEMM 分解为多层嵌套循环，每层对应 GPU 内存层次的一级：

```
+=================================================================+
|            CUTLASS GEMM 多层 Tile 分解全景图                       |
|                                                                   |
|   for (int cta_m = 0; cta_m < M; cta_m += CTA_M) {  ← Grid 层   |
|     for (int cta_n = 0; cta_n < N; cta_n += CTA_N) {             |
|                                                                   |
|       ┌─── 共享内存: 加载 A Tile [CTA_M × CTA_K] ───┐            |
|       │  Global → Shared  (cp.async / TMA)            │           |
|       │  __syncthreads()                              │           |
|       └───────────────────────────────────────────────┘           |
|                                                                   |
|       for (int k_block = 0; k_block < K; k_block += CTA_K) {     |
|         // ===== 软件流水线循环 (Software Pipeline) =====          |
|         //    阶段0: 正在加载       (producer)                     |
|         //    阶段1: 正在计算       (consumer)                     |
|         //    阶段2: 已使用完  ←── 可以覆盖                         |
|                                                                   |
|         ┌──────────────────────────────────────────┐              |
|         │  每个 Warp 处理 Warp Tile [WARP_M × WARP_N]│             |
|         │  for (warp_m) for (warp_n)                │             |
|         │    Shared → Register (warp load)          │             |
|         │    ┌── WMMA 指令序列 ──┐                  │             |
|         │    │ mma.sync.aligned   │ ← Tensor Core   │             |
|         │    │ .m16n8k16          │                  │             |
|         │    │ .row.col.f32...   │                  │            |
|         │    └───────────────────┘                  │              |
|         │  }                                       │              |
|         └──────────────────────────────────────────┘              |
|       }                                                           |
|                                                                   |
|       // Epilogue: 寄存器 → 全局内存                              |
|       for each element in accumulator[CTA_M][CTA_N]:              |
|          C[i][j] = alpha * acc[i][j] + beta * C[i][j]             |
|          C[i][j] = ReLU(C[i][j] + bias[j])  ← 融合!              |
|                                                                   |
|     }                                                             |
|   }                                                               |
+=================================================================+
```

### 1.5 Collectives 概念：CUTLASS 3.x 的新范式

CUTLASS 3.x 引入了 **Collective** 概念，将原本分散的模板参数组织成语义化的集合体：

```cpp
// CUTLASS 3.x: Collective 模式
// Collective 将 Mainloop 和 Epilogue 封装为独立组件

// CollectiveBuilder 构造可组合的 Collective
using CollectiveEpilogue = typename cutlass::epilogue::collective::CollectiveBuilder<
    cutlass::arch::Sm90, cutlass::arch::OpClassTensorOp,  // 架构信息
    TileShape,                                              // Threadblock Tile
    ClusterShape,                                           // 可选的 Cluster Shape (SM90)
    cutlass::epilogue::collective::EpilogueTileAuto,        // Epilogue Tile 自动推导
    float, float, float, float,                             // 数据类型
    cutlass::epilogue::TmaWarpSpecialized                   // Store 策略
>::CollectiveEpilogue;

using CollectiveMainloop = typename cutlass::gemm::collective::CollectiveBuilder<
    cutlass::arch::Sm90, cutlass::arch::OpClassTensorOp,
    float, LayoutA, float, LayoutB, float, float,
    TileShape, ClusterShape,
    cutlass::gemm::collective::StageCountAuto,    // 流水线深度自动推导
    cutlass::gemm::KernelTma                       // 内核调度策略
>::CollectiveMainloop;

// 组合为完整 GEMM
using GemmKernel = cutlass::gemm::kernel::GemmUniversal<
    cutlass::gemm::GemmShape<int, int, int>,  // 运行期问题大小
    CollectiveMainloop,
    CollectiveEpilogue
>;
```

---

## 二、CUTLASS Epilogue（后处理融合）

### 2.1 Epilogue 融合的价值

没有 Epilogue Fusion 时，每个元素级操作都需要一次独立的内核启动：

```
+=== 无融合: 3次内核启动 + 2次全局内存往返 ===+

  Kernel 1: GEMM                Kernel 2: Bias + ReLU        Kernel 3: Scale
┌─────────────────────┐      ┌─────────────────────┐      ┌─────────────────────┐
│ C = A × B           │      │ forall i,j:          │      │ forall i,j:          │
│ 输出 → DRAM[C]      │─────→│   tmp = C[i][j]      │─────→│   out = tmp[i][j]    │
│ [500 GB/s 受限]     │      │        + bias[j]     │      │        * scale       │
│                     │  读C │   = max(tmp, 0)      │ 读tmp│   输出 → DRAM[out]   │
│                     │  写C │ 输出 → DRAM[C]       │ 写out│ [500 GB/s 受限]     │
└─────────────────────┘      └─────────────────────┘      └─────────────────────┘
   时间: 10μs                   时间: 起步 2μs                时间: 起步 2μs
                              +数据移动: 4μs               +数据移动: 4μs
                          总延迟: ~22μs, 带宽受限

+=== 有融合: 1次内核启动, 0次额外全局内存往返 ===+

  Kernel: GEMM + Bias + ReLU + Scale (Fused)
┌─────────────────────────────────────────────────────────┐
│ 1. MMA: accum[r] = A_frag × B_frag                       │
│ 2. Epilogue (全部在寄存器中完成, 无内存往返):              │
│      accum[r] = accum[r] * alpha + beta * C_load[r]     │
│      accum[r] = accum[r] + bias[r]       ← 融合1         │
│      accum[r] = max(accum[r], 0.0f)     ← 融合2         │
│      accum[r] = accum[r] * scale[r]     ← 融合3         │
│ 3. 一次性写入: DRAM[out][i] = accum[r]                   │
└─────────────────────────────────────────────────────────┘
   总延迟: ~12μs, 计算受限 (运算吞吐 ≈ 浮点峰值)
```

### 2.2 Epilogue Visitor Tree 模式

CUTLASS 的 Epilogue 采用了 **访问者模式 (Visitor Pattern)**，在编译期构建一棵操作树：

```
+=================================================================+
|              Epilogue Visitor Tree: 编译期组合                     |
|                                                                   |
|                        Epilogue (树干)                             |
|                             │                                     |
|                    ┌────────┼────────┐                            |
|                    │                 │                            |
|              LinearCombination   Activation                       |
|              (alpha*C + beta*D)   (可选)                           |
|                    │                 │                            |
|                    │         ┌───────┼───────┐                   |
|                    │         │               │                    |
|                    │      ReLUVistor     GELUVisitor               |
|                    │         │               │                    |
|                    └────┬────┘───────────────┘                   |
|                         │                                         |
|                    OutputOp                                        |
|                 (类型转换 + 写出)                                   |
|                                                                   |
|   编译期组合示例:                                                   |
|   using Epilogue = Epilogue<                                      |
|       LinearCombination<RowMajor, float>,    // 线性层             |
|       BiasAdd<RowMajor, float>,              // Bias 加法          |
|       Activation<GELU>,                      // GELU 激活          |
|       Scale<float>                           // Scale 缩放         |
|   >;                                                               |
+=================================================================+
```

```cpp
// CUTLASS Epilogue Visitor 的实际定义方式

// 1. 定义 Epilogue 操作序列
using EpilogueOp = cutlass::epilogue::thread::LinearCombinationRelu<
    float,          // 输出数据类型
    128 / 32,       // 向量化写入的元素数 (ElementsPerAccess)
    float,          // 累加器类型
    float           // 计算类型
>;

// 2. 更复杂的 Epilogue: LinearCombination + Bias + GELU
// CUTLASS 2.x 的模板组合方式
using EpilogueOp = cutlass::epilogue::thread::LinearCombination<
    float,                          // ElementOutput
    128 / cutlass::sizeof_bits<float>::value,  // Count (向量化写入宽度)
    float,                          // ElementAccumulator
    float,                          // ElementCompute
    cutlass::epilogue::thread::ScaleType::NoBetaScaling  // Scale 缩放类型
>;

// 3. CUTLASS 3.x: EpilogueVisitorTree (以树的形式组合)
using Epilogue = cutlass::epilogue::collective::DefaultEpilogue<
    cutlass::gemm::TagToStrideC<cutlass::layout::RowMajor>,   // C 矩阵步长
    cutlass::gemm::TagToStrideC<cutlass::layout::RowMajor>,   // D 矩阵步长
    cutlass::epilogue::thread::LinearCombination<
        float,                        // 输出数据类型
        1,                            // 标量支持
        float,                        // 累加器类型
        float,                        // 计算类型
        cutlass::epilogue::thread::ScaleType::OnlyAlphaScaling
    >
>;
```

### 2.3 常见 Epilogue 操作

```cpp
// ============ LinearCombination ============
// C = alpha * AB + beta * C
// 这是 GEMM 的标准 Epilogue，实现了 BLAS 的 GEMM 语义
// 在 CUTLASS 中，alpha/beta 的乘法被融合在 Epilogue 中

// ============ Bias 加法 ============
// C[i][j] += bias[j]  或  C[i][j] += bias[i]
// 支持 Row/Column bias，由 Layout 指定
using EpilogueOp = cutlass::epilogue::thread::LinearCombinationBias<
    float, 128 / sizeof(float), float, float
>;

// ============ ReLU ============
// C[i][j] = max(C[i][j], 0.0f)
using EpilogueOp = cutlass::epilogue::thread::LinearCombinationRelu<
    float, 128 / sizeof(float), float, float
>;

// ============ GELU ============
// C[i][j] = GELU(C[i][j])
// CUTLASS 内置了精确的 GELU 实现：
// GELU(x) = 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
using EpilogueOp = cutlass::epilogue::thread::LinearCombinationGELU<
    float, 128 / sizeof(float), float, float
>;

// ============ Clamp (Sigmoid/Scaling 组合) ============
// C[i][j] = clamp(C[i][j], min_val, max_val)
```

### 2.4 自定义 Epilogue: 融合量化

```cpp
// 完整示例: 自定义 Fused Quantize Epilogue
// 功能: 在 GEMM Epilogue 中完成 INT8 量化
// C_int8[i][j] = round(clamp(alpha*AB[i][j] / scale + zero_point, -128, 127))

#include "cutlass/cutlass.h"
#include "cutlass/epilogue/thread/linear_combination.h"

namespace custom {

// 自定义 Activation Functor: 量化
struct QuantizeActivation {
    float scale;
    int8_t zero_point;

    CUTLASS_HOST_DEVICE
    QuantizeActivation(float scale_ = 1.0f, int8_t zero_point_ = 0)
        : scale(scale_), zero_point(zero_point_) {}

    // 前向计算
    CUTLASS_HOST_DEVICE
    float operator()(float const& accum) const {
        float scaled = accum / scale + static_cast<float>(zero_point);
        // 夹紧到 INT8 范围
        scaled = fmaxf(-128.0f, fminf(127.0f, scaled));
        // 舍入到最近整数（偶数舍入, Round-to-Nearest-Even）
        return rintf(scaled);
    }

    // 反向传播（用于训练）
    CUTLASS_HOST_DEVICE
    float derivative(float const& accum) const {
        float scaled = accum / scale + static_cast<float>(zero_point);
        // Straight-Through Estimator (STE)
        return (scaled >= -128.0f && scaled <= 127.0f) ? 1.0f / scale : 0.0f;
    }
};

// 将自定义 Activation 注入 Epilogue
template <typename EpilogueOutputOp>
class CustomQuantizeEpilogue {
public:
    using OutputOp = EpilogueOutputOp;
    using ElementOutput = int8_t;      // 输出为 INT8
    using ElementAccumulator = float;  // 累加器为 float
    using ElementCompute = float;      // 中间计算为 float

    // ... 实现 Epilogue 接口方法 ...
    // 关键是: 在写出前调用 QuantizeActivation
};

} // namespace custom
```

**性能对比** — 自定义量化 Epilogue 的价值：

```
+=================================================================+
|              Epilogue Fusion 性能提升示例                         |
|                                                                   |
|   场景: GEMM(4096×4096×4096) + INT8 量化, A100 80GB              |
|                                                                   |
|   分离方案:                                                        |
|     Kernel 1 (GEMM, fp32 out):  ~450 μs (3.8 TB/s 有效)          |
|     Kernel 2 (Quantize):       ~120 μs (仅 280 GB/s, BW受限)     |
|     ────────────────────────────────────────────                  |
|     总计:                        ~570 μs                          |
|                                                                   |
|   融合方案 (自定义 Epilogue):                                      |
|     Kernel 1 (GEMM + Quantize): ~460 μs (量化几乎零开销)          |
|     ────────────────────────────────────────────                  |
|     加速:                        1.24x                            |
|                                                                   |
|   关键原因: Epilogue 在寄存器中完成量化，没有额外的内存读写          |
+=================================================================+
```

---

## 三、如何阅读 CUTLASS 源码

### 3.1 CUTLASS 源码树导航

```
cutlass/                              # 根目录
├── include/
│   ├── cutlass/
│   │   ├── arch/                     # 架构相关 (SM 特性检测)
│   │   │   ├── mma.h                 # MMA 指令封装
│   │   │   ├── mma_sm75.h            # Turing Tensor Core
│   │   │   ├── mma_sm80.h            # Ampere Tensor Core
│   │   │   └── wmma.h                # WMMA (Warp Matrix Multiply Accumulate)
│   │   │
│   │   ├── gemm/                     # GEMM 核心实现
│   │   │   ├── device/               # Device-level (最外层 API)
│   │   │   │   ├── gemm.h            #   GEMM 设备层封装 (~30 模板参数)
│   │   │   │   └── gemm_universal.h  #   GEMM 通用接口
│   │   │   ├── kernel/               # Kernel-level (Threadblock 层)
│   │   │   │   ├── gemm.h            #   GEMM 内核
│   │   │   │   └── default_gemm.h    #   默认配置
│   │   │   ├── thread/               # Thread-level (最底层 MMA)
│   │   │   │   ├── mma.h             #   Thread 级 MMA
│   │   │   │   └── mma_sm80.h        #   Ampere Thread MMA
│   │   │   ├── warp/                 # Warp-level
│   │   │   │   ├── mma.h             #   Warp 级 MMA
│   │   │   │   └── mma_tensor_op.h   #   Tensor Core Warp MMA
│   │   │   └── collective/           # CUTLASS 3.x Collective
│   │   │       ├── collective_builder.hpp
│   │   │       └── sm90_gemm_tma_warp_specialized.hpp
│   │   │
│   │   ├── epilogue/                 # Epilogue 实现
│   │   │   ├── thread/
│   │   │   │   ├── linear_combination.h  # 基础线性组合
│   │   │   │   ├── linear_combination_bias_relu.h
│   │   │   │   └── linear_combination_gelu.h
│   │   │   └── collective/           # CUTLASS 3.x Epilogue Collective
│   │   │
│   │   ├── layout/                   # 内存布局 (RowMajor, ColumnMajor, ...)
│   │   ├── transform/                # 布局变换 (转置, 数据类型转换)
│   │   ├── reduction/                # Reduction 内核
│   │   └── platform/                 # 平台工具 (CUDA 错误处理等)
│   │
│   └── cute/                         # CuTe: CUTLASS 3.x 的核心抽象层
│       ├── tensor.hpp                # CuTe Tensor (多维数组抽象)
│       ├── layout.hpp                # CuTe Layout (步长, 坐标映射)
│       ├── algorithm/                # 算法 (copy, gemm, tiled operations)
│       │   └── gemm.hpp              # CuTe GEMM 实现
│       └── atom/                     # 原子操作 (硬件指令封装)
│           └── mma_atom.hpp          # MMA 原子操作
│
├── examples/                         # 示例代码 (最佳学习起点!)
│   ├── 00_basic_gemm/                # 最小编译示例
│   ├── 01_cutlass_utilities/         # 工具函数使用
│   ├── 13_two_tensor_op_fusion/      # GEMM + GEMM 融合
│   └── 16_ampere_tensorop_conv/      # Ampere 卷积示例
│
├── tools/
│   ├── library/                      # CUTLASS 库 (编译为 .so)
│   └── profiler/                     # 性能分析器
│
└── test/                             # 单元测试
    └── unit/
        ├── gemm/
        │   └── device/
        │       └── gemm_sm80.h       # Ampere GEMM 测试
        └── epilogue/
```

### 3.2 理解模板参数的"爆炸"

`cutlass::gemm::device::Gemm` 有超过 30 个模板参数。下面是一个完整的拆解：

```cpp
template <
    // ===== 第1组: 数据类型 (A, B, C, D + 累加器 + Epilogue Compute) =====
    typename ElementA_,          // A 矩阵数据类型: float, half, int8, ...
    typename LayoutA_,           // A 矩阵布局: RowMajor, ColumnMajor
    typename ElementB_,
    typename LayoutB_,
    typename ElementC_,
    typename LayoutC_,
    typename ElementAccumulator_, // 累加器类型 (通常 float 或 int32)
    typename OperatorClass_,      // arch::OpClassSimt 或 arch::OpClassTensorOp
    typename ArchTag_,            // arch::Sm75, arch::Sm80, arch::Sm90

    // ===== 第2组: Tile 形状 =====
    typename ThreadblockShape_,   // GemmShape<M, N, K>
    typename WarpShape_,          // GemmShape<M, N, K> (CUTLASS 2.x)
    typename InstructionShape_,   // GemmShape<M, N, K>

    // ===== 第3组: Epilogue =====
    typename EpilogueOutputOp_,   // LinearCombination, Bias+ReLU, 自定义...

    // ===== 第4组: 内存与流水线 =====
    typename ThreadblockSwizzle_,  // 线程块在 Grid 中的排列策略
    int Stages_,                   // 软件流水线阶段数 (2-4)
    bool SplitKSerial_,            // 是否串行 Split-K
    typename MathOperator_,        // 数学操作器（默认: multiply_add）

    // ===== 第5组: 对齐 (Alignment) =====
    // 由 AlignmentDefault 自动推导，也可手动指定
    int AlignmentA_,               // A 矩阵全局内存对齐 (字节)
    int AlignmentB_,
    int AlignmentC_,

    // ===== 第6组: 高级优化 =====
    bool ClearAccumulators_ = true,  // 是否清零累加器（Split-K 时为 false）
    typename SmemLayoutA_ = void,    // 可覆盖的 Smem 布局（不常用）
    typename SmemLayoutB_ = void
>
class Gemm;
```

**关键理解**：正常使用时只需要前 8 个参数 + ThreadblockShape，其余全部使用默认值：

```cpp
// 最小编译示例: 只有 10 个显式参数
using Gemm = cutlass::gemm::device::Gemm<
    half,                              // ElementA
    cutlass::layout::RowMajor,          // LayoutA
    half,                              // ElementB
    cutlass::layout::ColumnMajor,       // LayoutB
    half,                              // ElementC
    cutlass::layout::RowMajor,          // LayoutC
    float,                             // ElementAccumulator
    cutlass::arch::OpClassTensorOp,     // OperatorClass
    cutlass::arch::Sm80,               // ArchTag
    cutlass::gemm::GemmShape<128, 128, 32>  // ThreadblockShape (唯一需要选的)
    // 其余全部自动推导
>;
```

### 3.3 完整的最小 CUTLASS GEMM 示例

```cpp
#include <cuda_runtime.h>
#include <cutlass/cutlass.h>
#include <cutlass/gemm/device/gemm.h>
#include <cutlass/util/host_tensor.h>
#include <cutlass/util/reference/host/gemm.h>
#include <cutlass/util/tensor_view_io.h>

// 定义 GEMM 类型（使用 CUTLASS 2.x API）
using Gemm = cutlass::gemm::device::Gemm<
    float,                              // ElementA
    cutlass::layout::ColumnMajor,        // LayoutA
    float,                              // ElementB
    cutlass::layout::ColumnMajor,        // LayoutB
    float,                              // ElementC
    cutlass::layout::ColumnMajor,        // LayoutC
    float,                              // ElementAccumulator
    cutlass::arch::OpClassSimt,          // 使用 SIMT (不依赖 Tensor Core)
    cutlass::arch::Sm50,                // 最低 SM 版本
    cutlass::gemm::GemmShape<128, 128, 8>  // Threadblock Tile
>;

int main() {
    const int M = 1024, N = 1024, K = 1024;
    const float alpha = 1.0f, beta = 0.0f;

    // 1. 分配 Host/Device 内存
    cutlass::HostTensor<float, cutlass::layout::ColumnMajor> A({M, K});
    cutlass::HostTensor<float, cutlass::layout::ColumnMajor> B({K, N});
    cutlass::HostTensor<float, cutlass::layout::ColumnMajor> C({M, N});
    cutlass::HostTensor<float, cutlass::layout::ColumnMajor> C_ref({M, N});

    // 初始化数据
    for (int i = 0; i < A.size(); ++i) A.host_data()[i] = static_cast<float>(rand()) / RAND_MAX;
    for (int i = 0; i < B.size(); ++i) B.host_data()[i] = static_cast<float>(rand()) / RAND_MAX;

    A.sync_device(); B.sync_device(); C.sync_device();

    // 2. 构造 GEMM 操作
    Gemm gemm_op;
    cutlass::Status status = gemm_op(
        {M, N, K},                       // problem size (GematCoord)
        {A.device_data(), K},            // A 矩阵 (TensorRef)  + lda
        {B.device_data(), N},            // B 矩阵 + ldb
        {C.device_data(), N},            // C 矩阵 + ldc
        {C.device_data(), N},            // D 矩阵 + ldd (输出)
        {alpha, beta}                    // Epilogue 参数
    );

    if (status != cutlass::Status::kSuccess) {
        std::cerr << "GEMM failed!" << std::endl;
        return -1;
    }

    // 3. 与 CPU 参考结果比较
    C.sync_host();
    cutlass::reference::host::Gemm<float, float, float, float,
        cutlass::layout::ColumnMajor,
        cutlass::layout::ColumnMajor,
        cutlass::layout::ColumnMajor>(
        M, N, K, alpha,
        A.host_data(), K, B.host_data(), N, beta,
        C_ref.host_data(), N
    );

    // 验证
    C_ref.sync_host();
    float max_error = 0.0f;
    for (int i = 0; i < C.size(); ++i) {
        max_error = std::max(max_error,
            std::abs(C.host_data()[i] - C_ref.host_data()[i]));
    }
    std::cout << "Max error: " << max_error << std::endl;

    return 0;
}
```

### 3.4 编译与调试

```bash
# 编译 CUTLASS 程序 (最小化选项)
nvcc -I/path/to/cutlass/include \
     -arch=sm_80 \
     -std=c++17 \
     -DCUTLASS_DEBUG_TRACE \         # 开启调试 trace
     -lineinfo \                      # 保留行号信息 (用于 cuda-gdb)
     -G \                             # 生成 GPU 调试符号
     my_gemm.cu -o my_gemm

# 调试运行
cuda-gdb ./my_gemm

# CUTLASS Profiler (CUTLASS 自带性能分析工具)
./tools/profiler/cutlass_profiler \
    --operation=Gemm \
    --m=4096 --n=4096 --k=4096 \
    --A=f16:row --B=f16:col --C=f16:row \
    --accum=f32 \
    --op_class=tensorop \
    --kernel=cutlass_tensorop_f16_s16816gemm_f16_256x128_64x3

# 常见调试标志:
# -DCUTLASS_DEBUG_TRACE:        打印所有 trace 信息
# -DCUTLASS_DEBUG_UNIT_TEST:    开启单元测试模式
# -DCUTLASS_STATUS_MACROS_DEBUG: 启用 status 宏的额外检查
```

---

## 四、Triton 语言入门

### 4.1 为何选择 Triton 而非裸写 CUDA

```
+=================================================================+
|         CUDA vs Triton: 编程模型对比                              |
|                                                                   |
|   CUDA (Thread-based):                   Triton (Block-based):    |
|   ┌──────────────────────┐              ┌──────────────────────┐  |
|   │ __global__ void      │              │ @triton.jit           │  |
|   │ kernel(float* A, ...)│              │ def kernel(A, B, ...)│  |
|   │ {                    │              │   pid = tl.program_id│  |
|   │   int tid = threadId;│              │   # Block 级操作     │  |
|   │   int bid = blockId; │              │   offs = pid * BLOCK │  |
|   │   // 手动管理 SMEM   │              │   a = tl.load(A+offs)│  |
|   │   __shared__ sm[256];│              │   b = tl.load(B+offs)│  |
|   │   sm[tid] = A[...];  │              │   c = tl.dot(a, b)   │  |
|   │   __syncthreads();   │              │   tl.store(C+offs,c) │  |
|   │   // ...             │              │                       │  |
|   │ }                    │              │ # SMEM 自动管理       │  |
|   └──────────────────────┘              └──────────────────────┘  |
|                                                                   |
|   对比维度:                                                        |
|   ┌──────────────┬──────────────────┬──────────────────┐         |
|   │              │  CUDA (Raw)       │  Triton           │         |
|   ├──────────────┼──────────────────┼──────────────────┤         |
|   │ 编程抽象     │ 线程级            │ 块级               │         |
|   │ 共享内存     │ 手动分配+同步     │ 编译器自动管理     │         |
|   │ 内存合并     │ 手动保证          │ 编译器自动保证     │         |
|   │ Bank冲突     │ 手动避免          │ 编译器尽力避免     │         |
|   │ 开发速度     │ 数天~数周/内核    │ 数小时~数天/内核   │         |
|   │ 性能天花板   │ ~100% 峰值        │ ~90-95% 峰值      │         |
|   │ 可移植性     │ 仅 NVIDIA GPU     │ NVIDIA GPU (未来可能扩展)│  |
|   │ 调试工具     │ cuda-gdb, nsight  │ tl.device_print    │         |
|   │ 语言        │ C++               │ Python DSL         │         |
|   └──────────────┴──────────────────┴──────────────────┘         |
+=================================================================+
```

### 4.2 Block-Based 编程模型

Triton 的核心抽象是 **program block**（程序块），而非线程：

```python
@triton.jit
def vector_add_kernel(
    x_ptr, y_ptr, output_ptr,
    n_elements,
    BLOCK_SIZE: tl.constexpr,
):
    # 每个 program instance (block) 处理 BLOCK_SIZE 个元素
    pid = tl.program_id(axis=0)           # 当前 block 的 ID
    block_start = pid * BLOCK_SIZE        # 该 block 负责的范围
    offsets = block_start + tl.arange(0, BLOCK_SIZE)  # 元素偏移
    mask = offsets < n_elements           # 边界保护

    # 从全局内存加载（编译器自动合并 + 向量化）
    x = tl.load(x_ptr + offsets, mask=mask)
    y = tl.load(y_ptr + offsets, mask=mask)

    # 计算
    output = x + y

    # 写回全局内存
    tl.store(output_ptr + offsets, output, mask=mask)
```

**关键理解**：Triton 编译器的职责包括：

1. **自动内存合并**：编译器将连续的 `tl.load` 请求合并为合并的内存事务
2. **自动向量化**：`tl.arange(0, BLOCK_SIZE)` 被展开为 SIMT 指令
3. **自动共享内存管理**：引入的临时张量自动分配/释放共享内存
4. **自动同步**：编译器插入必要的屏障

### 4.3 Triton 编译器管线

```
+=================================================================+
|                  Triton 编译器管线                                |
|                                                                   |
|   @triton.jit (Python)                                            |
|        │                                                          |
|        ▼                                                          |
|   Python AST → Triton-IR (TIR)                                    |
|        │        自定义中间表示，抽象 GPU 操作                       |
|        │        - 数据类型: fp16, bf16, fp32, int8, ...           |
|        │        - 操作: load, store, dot, atomic_add, ...         |
|        │        - 控制流: for, if, while                          |
|        │                                                          |
|        ▼                                                          |
|   Triton-GPU-IR (TTGIR)                                           |
|        │        硬件感知的中间表示                                  |
|        │        - 引入共享内存分配                                  |
|        │        - 推断内存合并/向量化                               |
|        │        - 调度 warp 级操作                                  |
|        │                                                          |
|        ▼                                                          |
|   LLVM-IR (NVPTX target)                                          |
|        │        标准的 LLVM 中间表示                                |
|        │        - NVPTX 后端优化 pass                              |
|        │                                                          |
|        ▼                                                          |
|   PTX (Parallel Thread Execution)                                 |
|        │        NVIDIA GPU 的汇编级中间语言                         |
|        │                                                          |
|        ▼                                                          |
|   SASS (GPU 可执行码)                                              |
|        │        NVIDIA GPU 的真正机器码                            |
|        │        (由 NVIDIA 驱动编译器 ptxas 生成)                   |
+=================================================================+
```

---

## 五、Triton 编程模型深入

### 5.1 Program ID 与 Grid 映射

```python
# Program ID: 定位每个 block 在 grid 中的位置
# Grid 是一维/二维/三维的 block 排列

@triton.jit
def kernel_2d(
    A, B, C,
    M, N, K,
    BLOCK_M: tl.constexpr,  # 每个 block 处理的 M 维度行数
    BLOCK_N: tl.constexpr,  # 每个 block 处理的 N 维度列数
):
    # 获取 2D grid 中的坐标
    pid_m = tl.program_id(axis=0)  # 沿 M 轴的 block ID
    pid_n = tl.program_id(axis=1)  # 沿 N 轴的 block ID

    # 计算该 block 负责的数据范围
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    # ...
```

Grid 大小在 Host 端启动内核时指定：

```python
# 在 Python 中启动 Triton 内核

# 方式1: 手动计算 grid
grid = lambda meta: (triton.cdiv(M, meta['BLOCK_M']),
                      triton.cdiv(N, meta['BLOCK_N']))

kernel_2d[grid](A, B, C, M, N, K, BLOCK_M=128, BLOCK_N=128)

# 方式2: 使用 1D grid
grid = (triton.cdiv(M * N, BLOCK_SIZE),)
kernel_1d[grid](A, B, C, M, N, BLOCK_SIZE=256)
```

### 5.2 Block Pointer

`tl.make_block_ptr` 创建结构化指针，支持高效的二维/多维访问和自动合并：

```python
@triton.jit
def gemm_with_block_ptr(
    A, B, C,
    M, N, K,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)

    # 创建 Block Pointer: 自动管理步长和边界
    # shape:    该 block 需要处理的数据形状
    # strides:  沿每个维度的步长
    # offsets:  起始偏移
    # block_shape: 每次 load 的数据块形状
    # order:    访问顺序 (0=RowMajor, 1=ColumnMajor)

    a_block_ptr = tl.make_block_ptr(
        base=A,
        shape=(M, K),                    # 全局矩阵形状
        strides=(K, 1),                  # A 的行/列步长 (RowMajor)
        offsets=(pid_m * BLOCK_M, 0),    # 起始偏移
        block_shape=(BLOCK_M, BLOCK_K),  # 每次加载的数据块
        order=(1, 0),                    # 访问顺序: 先列后行 (ColumnMajor)
    )

    b_block_ptr = tl.make_block_ptr(
        base=B,
        shape=(K, N),
        strides=(N, 1),
        offsets=(0, pid_n * BLOCK_N),
        block_shape=(BLOCK_K, BLOCK_N),
        order=(0, 1),
    )

    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k in range(0, K, BLOCK_K):
        # Block Pointer 自动 advance + 边界处理
        a = tl.load(a_block_ptr, boundary_check=(0, 1))
        b = tl.load(b_block_ptr, boundary_check=(0, 1))

        accumulator += tl.dot(a, b)

        # advance: 移动到下一个 K 块
        a_block_ptr = tl.advance(a_block_ptr, (0, BLOCK_K))
        b_block_ptr = tl.advance(b_block_ptr, (BLOCK_K, 0))

    # 写回
    c_block_ptr = tl.make_block_ptr(
        base=C, shape=(M, N), strides=(N, 1),
        offsets=(pid_m * BLOCK_M, pid_n * BLOCK_N),
        block_shape=(BLOCK_M, BLOCK_N), order=(1, 0),
    )
    tl.store(c_block_ptr, accumulator, boundary_check=(0, 1))
```

**Block Pointer 的优势**：
- 自动处理行/列步长，无需手动计算线性索引
- `boundary_check` 自动处理 padding
- `tl.advance` 语义清晰
- 编译器更容易生成合并的内存访问模式

### 5.3 Masking: 边界处理

```python
@triton.jit
def masked_kernel(x_ptr, y_ptr, output_ptr, N, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)

    # ===== 关键: mask 保证不出界 =====
    mask = offsets < N
    # 当 N 不是 BLOCK_SIZE 的整数倍时:
    # offsets: [4080, 4081, ..., 4095]  (BLOCK_SIZE=128, 但只有 16 个有效元素)
    # mask:    [True, True, ..., True, False, False, ..., False]
    #           └──── 前 16 个为 True ────┘└──── 后 112 个为 False ────┘

    # load 时用 mask:
    #   - mask=True 的元素正常加载
    #   - mask=False 的元素加载为 0 (或其他默认值, 由 other 参数指定)
    x = tl.load(x_ptr + offsets, mask=mask, other=0.0)

    # 计算: 所有 128 个"伪线程"都在计算, 但越界的计算无意义
    y = x * 2.0

    # store 时用 mask:
    #   - mask=True 的元素正常写入
    #   - mask=False 的元素不写入 (完全跳过)
    tl.store(output_ptr + offsets, y, mask=mask)

    # ⚠️ 注意: store 不使用 other 参数, mask=False 直接跳过写入
    # 这是为了防止写入全局内存的越界地址导致段错误
```

### 5.4 内存层次与同步

```
+=================================================================+
|               Triton 中的内存层次与同步                            |
|                                                                   |
|   ┌─────────────────────────────────────────────────────────┐    |
|   │  全局内存 (Global Memory / DRAM)                          │    |
|   │  tl.load(ptr, mask=...)  / tl.store(ptr, val, mask=...) │    |
|   │  跨所有 block 可见 │ 延迟最高 (数百 cycles)              │    |
|   └──────────────────────────────┬──────────────────────────┘    |
|                                  │                                |
|                    tl.atomic_add / tl.atomic_cas                  |
|                                  │  (跨 block 同步)               |
|   ┌──────────────────────────────┴──────────────────────────┐    |
|   │  共享内存 (Shared Memory / SRAM)                         │    |
|   │  Triton 编译器自动管理                                    │    |
|   │  块内所有线程可见 │ 延迟低 (~20 cycles)                  │    |
|   │  隐式同步: Triton 编译器在 block 的"边界"插入 __syncthreads│   |
|   └──────────────────────────────┬──────────────────────────┘    |
|                                  │                                |
|                    tl.dot (读取共享内存中的矩阵分片)               |
|                                  │                                |
|   ┌──────────────────────────────┴──────────────────────────┐    |
|   │  寄存器 (Register)                                       │    |
|   │  编译器自动分配 │ 延迟最低 (0 cycles 延迟)              │    |
|   │  注意: 寄存器压力大会导致 spill 到 local memory (DRAM)   │    |
|   └─────────────────────────────────────────────────────────┘    |
|                                                                   |
|   同步语义:                                                       |
|   ┌────────────────────────────────────────────────────────────┐ |
|   │  块内同步:                                                  │ |
|   │    Triton 的 for 循环边界是隐式同步点                       │ |
|   │    编译器在循环迭代之间插入 __syncthreads()                 │ |
|   │                                                             │ |
|   │  跨块同步:                                                   │ |
|   │    Triton 不提供内置的跨块 barrier                           │ |
|   │    使用 tl.atomic_add + 轮询实现 (性能开销大)               │ |
|   │    通常应避免跨块同步, 设计为 block 独立完成计算             │ |
|   └────────────────────────────────────────────────────────────┘ |
+=================================================================+
```

---

## 六、Triton 矩阵乘法教程

### 6.1 Naive Triton GEMM

```python
import triton
import triton.language as tl
import torch

@triton.jit
def naive_gemm(
    A, B, C,
    M, N, K,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    """最朴素的 Triton GEMM — 无软件流水线，无共享内存优化"""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # 累加器（寄存器）
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k in range(0, K, BLOCK_K):
        # 每次从全局内存直接加载 (无软件流水线)
        a_ptrs = A + offs_m[:, None] * K + (k + offs_k[None, :])
        b_ptrs = B + (k + offs_k[:, None]) * N + offs_n[None, :]

        a = tl.load(a_ptrs, mask=offs_m[:, None] < M and (k + offs_k[None, :]) < K)
        b = tl.load(b_ptrs, mask=(k + offs_k[:, None]) < K and offs_n[None, :] < N)

        acc += tl.dot(a, b)  # Tensor Core 加速

    c_ptrs = C + offs_m[:, None] * N + offs_n[None, :]
    tl.store(c_ptrs, acc, mask=offs_m[:, None] < M and offs_n[None, :] < N)


# 性能: ~30% cuBLAS 水平
# 瓶颈: 每次迭代从全局内存加载, 全局内存带宽成为瓶颈
```

### 6.2 优化1: 共享内存 Tiling

```
+=================================================================+
|            GEMM Tiling 中的数据流 (共享内存版本)                   |
|                                                                   |
|  全局内存                  共享内存                 寄存器          |
|  ┌──────────┐          ┌─────────────┐          ┌───────────┐   |
|  │  A Tile  │ ──copied→ │  A Tile     │ ──loaded→ │  A Frag   │   |
|  │ [M×K]    │    (LDG)  │ [BLOCK_M    │   (LDS)   │ [BLOCK_M  │   |
|  │          │           │  ×BLOCK_K]  │           │  ×BLOCK_K]│   |
|  └──────────┘          └─────────────┘          └─────┬─────┘   |
|                                                       │         |
|                                                       │ tl.dot  │
|                                                       │(TC 计算)│
|  ┌──────────┐          ┌─────────────┐          ┌─────┴─────┐   |
|  │  B Tile  │ ──copied→ │  B Tile     │ ──loaded→ │  B Frag   │   |
|  │ [K×N]    │    (LDG)  │ [BLOCK_K    │   (LDS)   │ [BLOCK_K  │   |
|  │          │           │  ×BLOCK_N]  │           │  ×BLOCK_N]│   |
|  └──────────┘          └─────────────┘          └───────────┘   |
|                                                                   |
|   关键优化:                                                        |
|   1. A/B Tile 先加载到共享内存 (一次 LDG)                          |
|   2. 共享内存中的数据被 Warp 内的线程重复读取 (多次 LDS)           |
|   3. 减少全局内存访问次数 = O(K / BLOCK_K) 倍                      |
+=================================================================+
```

```python
@triton.jit
def tiled_gemm(
    A, B, C,
    M, N, K,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)

    # 每个 block 的起始位置
    offs_am = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_bn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # 手动分配共享内存
    # Triton 2.x: 编译器自动管理, 这些变量自动映射到共享内存
    a_tile = tl.zeros((BLOCK_M, BLOCK_K), dtype=A.dtype.element_ty)
    b_tile = tl.zeros((BLOCK_K, BLOCK_N), dtype=B.dtype.element_ty)

    # 寄存器累加器
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k in range(0, K, BLOCK_K):
        # 步骤1: 从全局内存加载到共享内存
        a_ptrs = A + offs_am[:, None] * K + (k + offs_k[None, :])
        b_ptrs = B + (k + offs_k[:, None]) * N + offs_bn[None, :]
        a_tile = tl.load(a_ptrs, mask=offs_am[:, None] < M)
        b_tile = tl.load(b_ptrs, mask=offs_bn[None, :] < N)

        # 步骤2: 在寄存器中计算 (tl.dot 自动从共享内存读取)
        acc += tl.dot(a_tile, b_tile)

    # 写回全局内存
    c_ptrs = C + offs_am[:, None] * N + offs_bn[None, :]
    tl.store(c_ptrs, acc, mask=offs_am[:, None] < M and offs_bn[None, :] < N)
```

### 6.3 优化2: 多阶段软件流水线 (Multi-Stage Pipelining)

```
+=================================================================+
|              多阶段软件流水线示意图                                |
|                                                                   |
|   时间轴 →                                                        |
|                                                                   |
|   Stage 0:  ┌─────────┐                                           |
|   (加载)    │ cp.async │                                           |
|             │  A0,B0   │                                           |
|             └────┬─────┘                                           |
|                  │                                                 |
|   Stage 1:      ┌─────────┐                                       |
|   (加载)        │ cp.async │                                       |
|                  │  A1,B1   │                                       |
|             ┌────┴─────┐   │                                       |
|   Stage 0:  │ MMA(A0,B0)│  │                                       |
|   (计算)    └───────────┘  │                                       |
|                  │         │                                       |
|   Stage 2:      │     ┌─────────┐                                 |
|   (加载)        │     │ cp.async │                                 |
|                  │     │  A2,B2   │                                 |
|             ┌────┴─────┐ │                                         |
|   Stage 1:  │ MMA(A1,B1)││                                         |
|   (计算)    └───────────┘│                                         |
|                  │      │                                          |
|                  │  ┌─────────┐                                    |
|   Stage 2:      │  │ MMA(A2,B2)│                                    |
|   (计算)        │  └─────────┘                                    |
|                  │                                                 |
|                                                                   |
|   优势:                                                            |
|   - 全局内存加载 (LDG) 和 MMA 计算 (Tensor Core) 重叠执行         |
|   - `cp.async` 不占用 SM 的计算单元                               |
|   - 加载延迟被隐藏, 接近计算吞吐峰值                               |
|                                                                   |
|   关键: 需要 NUM_STAGES >= 2, 每个 stage 有独立的共享内存缓冲区    |
+=================================================================+
```

```python
@triton.jit
def pipelined_gemm(
    A, B, C,
    M, N, K,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    NUM_STAGES: tl.constexpr,  # 软件流水线阶段数 (通常 3-4)
):
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)

    offs_am = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_bn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    # ===== 多阶段流水线的关键: 循环展开 + 预取 =====
    # Triton 编译器自动支持 loop pipelining
    # 通过 triton.autotune 可以探 NUM_STAGES 参数

    # 预取第一个阶段 (prologue)
    offs_k = tl.arange(0, BLOCK_K)
    a_tile = tl.load(A + offs_am[:, None] * K + offs_k[None, :])
    b_tile = tl.load(B + offs_k[:, None] * N + offs_bn[None, :])

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    # 流水线主循环
    for k in range(BLOCK_K, K, BLOCK_K):
        # 当前正在计算的 k 偏移
        k_prev = k - BLOCK_K

        # 计算上一阶段的数据 (与加载当前阶段并行)
        acc += tl.dot(a_tile, b_tile)

        # 预取下一阶段的数据 (开始异步加载)
        offs_k_next = k + tl.arange(0, BLOCK_K)
        a_tile = tl.load(A + offs_am[:, None] * K + offs_k_next[None, :])
        b_tile = tl.load(B + offs_k_next[:, None] * N + offs_bn[None, :])

    # 清理最后阶段 (epilogue)
    acc += tl.dot(a_tile, b_tile)

    # 写回
    c_ptrs = C + offs_am[:, None] * N + offs_bn[None, :]
    tl.store(c_ptrs, acc, mask=offs_am[:, None] < M and offs_bn[None, :] < N)
```

### 6.4 优化3: Autotuning

```python
@triton.autotune(
    configs=[
        triton.Config({'BLOCK_M': 64,  'BLOCK_N': 64,  'BLOCK_K': 32,
                        'GROUP_M': 8,   'NUM_STAGES': 3}, num_warps=4),
        triton.Config({'BLOCK_M': 128, 'BLOCK_N': 64,  'BLOCK_K': 32,
                        'GROUP_M': 8,   'NUM_STAGES': 3}, num_warps=4),
        triton.Config({'BLOCK_M': 128, 'BLOCK_N': 128, 'BLOCK_K': 32,
                        'GROUP_M': 8,   'NUM_STAGES': 4}, num_warps=4),
        triton.Config({'BLOCK_M': 128, 'BLOCK_N': 128, 'BLOCK_K': 64,
                        'GROUP_M': 8,   'NUM_STAGES': 4}, num_warps=8),
        triton.Config({'BLOCK_M': 256, 'BLOCK_N': 128, 'BLOCK_K': 64,
                        'GROUP_M': 8,   'NUM_STAGES': 4}, num_warps=8),
        triton.Config({'BLOCK_M': 256, 'BLOCK_N': 256, 'BLOCK_K': 64,
                        'GROUP_M': 8,   'NUM_STAGES': 3}, num_warps=8),
    ],
    key=['M', 'N', 'K'],  # autotune key: 哪些参数变化时需要重新调优
)
@triton.jit
def autotuned_gemm(
    A, B, C,
    M, N, K,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    GROUP_M: tl.constexpr,
    NUM_STAGES: tl.constexpr,
):
    """
    Autotuned GEMM kernel.
    关键 autotune 参数:
    - BLOCK_M/N/K:  Tile 大小 — 影响 SM 占用率和内存带宽
    - GROUP_M:       Grouped launch 中每个 group 的 M 维度 block 数
    - NUM_STAGES:    软件流水线阶段数
    - num_warps:     每个 block 的 warp 数 (在 Config 中指定)
    """
    pid = tl.program_id(axis=0)

    # Grouped launch: 改善 L2 cache 局部性
    num_pid_m = tl.cdiv(M, BLOCK_M)
    num_pid_n = tl.cdiv(N, BLOCK_N)
    num_pid_in_group = GROUP_M * num_pid_n
    group_id = pid // num_pid_in_group
    first_pid_m = group_id * GROUP_M
    group_size_m = min(num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + (pid % group_size_m)
    pid_n = (pid % num_pid_in_group) // group_size_m

    offs_am = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_bn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # 指针预计算
    a_ptrs = A + offs_am[:, None] * K + offs_k[None, :]
    b_ptrs = B + offs_k[:, None] * N + offs_bn[None, :]

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k in range(0, K, BLOCK_K):
        a = tl.load(a_ptrs, mask=offs_am[:, None] < M,
                    other=0.0)
        b = tl.load(b_ptrs, mask=offs_bn[None, :] < N,
                    other=0.0)
        acc += tl.dot(a, b)

        a_ptrs += BLOCK_K
        b_ptrs += BLOCK_K

    c_ptrs = C + offs_am[:, None] * N + offs_bn[None, :]
    tl.store(c_ptrs, acc, mask=offs_am[:, None] < M and offs_bn[None, :] < N)
```

---

## 七、Triton FlashAttention 实现

### 7.1 FlashAttention 的核心思想

```
+=================================================================+
|           FlashAttention 算法: 分块计算 + Online Softmax          |
|                                                                   |
|   传统 Attention:                                                  |
|   ┌───────────────────────────────────────────────────────────┐  |
|   │ 1. S  = Q @ K^T    → 写入 HBM [N×N]  ←  O(N^2) 内存!      │  |
|   │ 2. P  = softmax(S)  → 写入 HBM [N×N]  ←  O(N^2) 内存!      │  |
|   │ 3. O  = P @ V      → 写入 HBM [N×d]                        │  |
|   └───────────────────────────────────────────────────────────┘  |
|                                                                   |
|   FlashAttention (分块计算):                                       |
|   ┌───────────────────────────────────────────────────────────┐   |
|   │ 将 Q 分成块 Q₁, Q₂, ..., Q_{Tq}                            │   |
|   │ 将 K,V 分成块 K₁, K₂, ..., K_{Tk}, V₁, V₂, ..., V_{Tk}    │   |
|   │                                                             │   |
|   │ for j in 1..Tk:    ← 外层循环 (K,V 块)                      │   |
|   │   Kⱼ = load HBM→SRAM                                         │   |
|   │   Vⱼ = load HBM→SRAM                                         │   |
|   │   for i in 1..Tq:  ← 内层循环 (Q 块)                        │   |
|   │     Qᵢ = load HBM→SRAM                                       │   |
|   │     Sᵢⱼ = Qᵢ @ Kⱼ^T        ← 在 SRAM 中计算 (不写 HBM!)     │   |
|   │     Pᵢⱼ = softmax(Sᵢⱼ)     ← 在 SRAM 中计算 (不写 HBM!)     │   |
|   │     Oᵢ += Pᵢⱼ @ Vⱼ         ← 在线 Softmax 合并               │   |
|   │   Oᵢ 写回 HBM                                                │   |
|   └───────────────────────────────────────────────────────────┘   |
|                                                                   |
|   关键优势:                                                        |
|   - O(N^2) 的中间矩阵永远不写入 HBM                                |
|   - 内存访问量: O(N^2·d) → O(N^2·d^2 / M)  (M 为 SRAM 大小)      |
|   - 瓶颈从 HBM 带宽变为计算吞吐                                    |
+=================================================================+
```

### 7.2 FlashAttention Forward Pass 的 Triton 实现

```python
@triton.jit
def flash_attention_fwd(
    Q, K, V, O,                    # 输入/输出张量
    softmax_scale,                 # 1/sqrt(d_k)
    L,                             # 存储 logsumexp (用于反向传播)
    stride_q_batch, stride_q_seq, stride_q_head, stride_q_dim,
    stride_k_batch, stride_k_seq, stride_k_head, stride_k_dim,
    stride_v_batch, stride_v_seq, stride_v_head, stride_v_dim,
    stride_o_batch, stride_o_seq, stride_o_head, stride_o_dim,
    BATCH, N_CTX, N_HEADS,         # 问题尺寸
    BLOCK_N: tl.constexpr,         # Q 块大小 (沿 seq 维度)
    BLOCK_DMODEL: tl.constexpr,    # Head 维度 (通常 64 或 128)
    STAGE: tl.constexpr,           # 块在 batch*head 空间中的起始
):
    """FlashAttention Forward Pass — Triton 实现"""
    # 获取 batch 和 head 索引
    pid_batch = tl.program_id(2)
    pid_head = tl.program_id(1) + STAGE
    pid_m = tl.program_id(0)  # Q 的块索引

    # 计算 Q 块的偏移
    offs_m = pid_m * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_n = tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_DMODEL)

    # 加载 Q 块 [BLOCK_N, BLOCK_DMODEL]
    q_ptrs = Q + pid_batch * stride_q_batch \
               + pid_head * stride_q_head \
               + offs_m[:, None] * stride_q_seq \
               + offs_d[None, :]
    q = tl.load(q_ptrs, mask=offs_m[:, None] < N_CTX, other=0.0)

    # ===== Online Softmax 状态 =====
    m_i = tl.full([BLOCK_N], float('-inf'), dtype=tl.float32)  # 当前最大值
    l_i = tl.zeros([BLOCK_N], dtype=tl.float32)                 # 累加和 (exp 和)
    acc = tl.zeros([BLOCK_N, BLOCK_DMODEL], dtype=tl.float32)   # 累加器

    # ===== 主循环: 遍历 K,V 块 =====
    for start_n in range(0, N_CTX, BLOCK_N):
        # 加载 K 块 [BLOCK_N, BLOCK_DMODEL]
        k_ptrs = K + pid_batch * stride_k_batch \
                   + pid_head * stride_k_head \
                   + (start_n + offs_n[:, None]) * stride_k_seq \
                   + offs_d[None, :]
        k = tl.load(k_ptrs, mask=(start_n + offs_n[:, None]) < N_CTX, other=0.0)

        # 计算 S = Q @ K^T / sqrt(d) → [BLOCK_N, BLOCK_N]
        s = tl.dot(q, tl.trans(k)) * softmax_scale

        # Causal mask: 只关注 j <= i
        if True:  # causal
            causal_mask = offs_m[:, None] >= (start_n + offs_n[None, :])
            s = tl.where(causal_mask, s, float('-inf'))

        # Online Softmax: 分块更新
        m_ij = tl.max(s, axis=1)                    # 当前块的最大值
        p = tl.exp(s - m_ij[:, None])               # 减去 max 后的 exp
        l_ij = tl.sum(p, axis=1)                    # 当前块的 exp 和

        # 加载 V 块 [BLOCK_N, BLOCK_DMODEL]
        v_ptrs = V + pid_batch * stride_v_batch \
                   + pid_head * stride_v_head \
                   + (start_n + offs_n[:, None]) * stride_v_seq \
                   + offs_d[None, :]
        v = tl.load(v_ptrs, mask=(start_n + offs_n[:, None]) < N_CTX, other=0.0)

        # 在线合并 (Online Softmax 的核心)
        m_new = tl.maximum(m_i, m_ij)               # 合并后的新最大值
        alpha = tl.exp(m_i - m_new)                 # 旧结果的缩放因子
        beta = tl.exp(m_ij - m_new)                 # 新结果的缩放因子

        # 更新累加器: acc = alpha * old_acc + beta * (P @ V)
        acc = acc * alpha[:, None] + beta[:, None] * tl.dot(p, v)

        # 更新 l_i: l_new = alpha * old_l + beta * l_ij
        l_i = l_i * alpha + beta * l_ij

        # 更新 m_i
        m_i = m_new

    # ===== 最终归一化: O = acc / l_i = (∑ PⱼVⱼ) / ∑ Pⱼ = softmax(QK^T)V =====
    acc = acc / l_i[:, None]

    # 存储 logsumexp (用于反向传播)
    L_ptrs = L + pid_batch * N_CTX * N_HEADS \
              + pid_head * N_CTX \
              + offs_m
    tl.store(L_ptrs, m_i + tl.log(l_i), mask=offs_m < N_CTX)

    # 写回输出
    o_ptrs = O + pid_batch * stride_o_batch \
              + pid_head * stride_o_head \
              + offs_m[:, None] * stride_o_seq \
              + offs_d[None, :]
    tl.store(o_ptrs, acc, mask=offs_m[:, None] < N_CTX)
```

### 7.3 Block-Sparse FlashAttention

```python
@triton.jit
def flash_attention_block_sparse(
    Q, K, V, O,
    softmax_scale,
    layout,                        # 稀疏布局: [N_CTQ//BLOCK, N_CTK//BLOCK] 的 bool 矩阵
    stride_q_batch, stride_q_seq, stride_q_head, stride_q_dim,
    # ... (省略其他参数)
    BLOCK_N: tl.constexpr, BLOCK_DMODEL: tl.constexpr,
):
    """
    Block-Sparse FlashAttention.
    只计算 layout[m_block, n_block] == True 的 (Q块, KV块) 对
    """
    pid_batch = tl.program_id(2)
    pid_head = tl.program_id(1)
    pid_m = tl.program_id(0)

    offs_m = pid_m * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_DMODEL)
    offs_n = tl.arange(0, BLOCK_N)

    # 加载 Q 块
    q = tl.load(Q + ...)  # 省略具体指针计算

    m_i = tl.full([BLOCK_N], float('-inf'), dtype=tl.float32)
    l_i = tl.zeros([BLOCK_N], dtype=tl.float32)
    acc = tl.zeros([BLOCK_N, BLOCK_DMODEL], dtype=tl.float32)

    # ===== 关键: 只遍历非零块 =====
    for block_n in range(0, triton.cdiv(N_CTX, BLOCK_N)):
        # 检查稀疏布局
        is_active = tl.load(layout + pid_m * num_k_blocks + block_n)
        if is_active:
            # 加载 K,V 块并计算 (与上面相同)
            k = tl.load(K + ...)
            s = tl.dot(q, tl.trans(k)) * softmax_scale

            # 应用 causal mask (可选, 如果需要)
            causal_mask = offs_m[:, None] >= (block_n * BLOCK_N + offs_n[None, :])
            s = tl.where(causal_mask & is_active, s, float('-inf'))

            # Online softmax 更新
            # ... (同上)
            v = tl.load(V + ...)
            # ...

    # 归一化 + 写回
    acc = acc / l_i[:, None]
    tl.store(O + ..., acc, mask=offs_m[:, None] < N_CTX)
```

### 7.4 Backward Pass: Triton 中的重计算

```python
@triton.jit
def flash_attention_bwd(
    Q, K, V, O, dO,             # 输入/梯度
    dQ, dK, dV,                  # 输出梯度
    L,                           # 前向传播存储的 logsumexp
    softmax_scale,
    # ... 步长和维度参数
    BLOCK_N: tl.constexpr,
    BLOCK_DMODEL: tl.constexpr,
):
    """
    FlashAttention Backward Pass.
    关键技巧: 重计算 P = softmax(QK^T) 而不重新读取 softmax_scale
    使用前向存储的 L (logsumexp) 来重构 P
    """
    pid_batch = tl.program_id(2)
    pid_head = tl.program_id(1)
    pid_m = tl.program_id(0)

    offs_m = pid_m * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_DMODEL)
    offs_n = tl.arange(0, BLOCK_N)

    # 加载 Q 块和 dO 块
    q = tl.load(Q + ...)
    do = tl.load(dO + ...)
    l_i = tl.load(L + ...)  # 前向传播的 logsumexp

    # 初始化 dQ 梯度的累加器
    dq = tl.zeros([BLOCK_N, BLOCK_DMODEL], dtype=tl.float32)

    # 遍历 K,V 块以计算 dQ = sum(softmax(QK^T) * dO * V^T)
    for start_n in range(0, N_CTX, BLOCK_N):
        k = tl.load(K + ...)
        v = tl.load(V + ...)

        # 重计算 S = QK^T / sqrt(d)
        s = tl.dot(q, tl.trans(k)) * softmax_scale

        # 重计算 P = exp(S - L_i) ← 使用前向存储的 L_i
        p = tl.exp(s - l_i[:, None])

        # 累加 dQ: dQ += P * dO @ V^T
        dp = tl.dot(do, tl.trans(v))
        dq += tl.dot(p * dp, k)  # 这是简化的, 实际需要更复杂的梯度计算

        # dK 和 dV 也可以在同一个循环中计算
        # ...

    tl.store(dQ + ..., dq, mask=offs_m[:, None] < N_CTX)
```

---

## 八、Triton vs CUTLASS: 对比分析

### 8.1 选型指南

```
+=================================================================+
|                Triton vs CUTLASS: 决策矩阵                        |
|                                                                   |
|   ┌─────────────────┬──────────────────┬──────────────────┐      |
|   │   使用场景       │     Triton        │     CUTLASS       │      |
|   ├─────────────────┼──────────────────┼──────────────────┤      |
|   │ 快速原型验证    │  ✅ 首选          │  ❌ 过重           │      |
|   │ 生产级 GEMM     │  ⚠️ 95% 峰值     │  ✅ 98%+ 峰值     │      |
|   │ 自定义 Epilogue │  ⚠️ 手写融合     │  ✅ Epilogue 树    │      |
|   │ 复杂归约        │  ✅ 内置原子操作 │  ⚠️ 需手写         │      |
|   │ 稀疏/结构化     │  ✅ Sparse Block  │  ✅ Sparse MMA    │      |
|   │ 多架构支持      │  ✅ Ampere+Hopper │  ✅ Volta+ 全架构 │      |
|   │ Python 集成     │  ✅ torch_dispatch│  ⚠️ pybind11      │      |
|   │ 卷积网络        │  ❌ 不直接支持   │  ✅ Implicit GEMM │      |
|   │ 开发团队         │  1-3 人          │  3-10 人           │      |
|   └─────────────────┴──────────────────┴──────────────────┘      |
|                                                                   |
|   经验法则:                                                        |
|   - 如果是研究项目/快速迭代 → Triton                              |
|   - 如果是产品核心 GEMM/Conv → CUTLASS                            |
|   - 如果是 torch.compile 的自定义 op → Triton                     |
|   - 如果需要极致性能且团队资源充足 → CUTLASS                      |
+=================================================================+
```

### 8.2 性能对比

```
+=================================================================+
|         GEMM 性能对比: Triton vs CUTLASS vs cuBLAS                |
|                    (A100 SXM4 80GB, fp16)                          |
|                                                                   |
|   Shape           cuBLAS    CUTLASS   Triton    Triton/cuBLAS     |
|   ────────────────────────────────────────────────────────────    |
|   1024x1024x1024   312 TF    305 TF    285 TF        91.3%        |
|   2048x2048x2048   312 TF    308 TF    296 TF        94.9%        |
|   4096x4096x4096   312 TF    310 TF    300 TF        96.2%        |
|   8192x8192x8192   312 TF    310 TF    302 TF        96.8%        |
|   16384x16384x16384 312 TF   311 TF    305 TF        97.8%        |
|                                                                   |
|   注意: 实际性能受限于硬件峰值 (A100 fp16 = 312 TFLOPS)           |
|                                                                   |
|   ┌───────────────────────────────────────────────────────────┐  |
|   │  Triton 性能接近 cuBLAS 的关键因素:                         │  |
|   │  1. Triton 编译器自动利用 Tensor Core (tl.dot)              │  |
|   │  2. 自动内存合并 + 软件流水线                               │  |
|   │  3. Autotuning 自动搜索最佳 tile 配置                       │  |
|   │                                                             │  |
|   │  Triton 的 3-5% 性能差来自:                                  │  |
|   │  1. 编译器的指令调度不及手写 PTX                            │  |
|   │  2. 共享内存 bank conflict 优化不如手写精细                 │  |
|   │  3. 寄存器分配的次优性 (spill 到 local memory)              │  |
|   └───────────────────────────────────────────────────────────┘  |
+=================================================================+
```

### 8.3 同一个 GEMM: Triton vs CUTLASS 代码量对比

```python
# ============ Triton 版 GEMM (完整可用) ≈ 40 行 ============
@triton.autotune(
    configs=[triton.Config({...}, num_warps=w) for w in [4, 8]],
    key=['M', 'N', 'K'],
)
@triton.jit
def triton_gemm(A, B, C, M, N, K, BLOCK_M: tl.constexpr,
                BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
                GROUP_M: tl.constexpr):
    pid = tl.program_id(0)
    num_pid_m, num_pid_n = tl.cdiv(M, BLOCK_M), tl.cdiv(N, BLOCK_N)
    pid_m = pid // num_pid_n
    pid_n = pid % num_pid_n
    offs_am, offs_bn = pid_m * BLOCK_M + tl.arange(0, BLOCK_M), pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)
    a_ptrs, b_ptrs = A + offs_am[:, None] * K + offs_k[None, :], B + offs_k[:, None] * N + offs_bn[None, :]
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k in range(0, K, BLOCK_K):
        a = tl.load(a_ptrs); b = tl.load(b_ptrs)
        acc += tl.dot(a, b)
        a_ptrs += BLOCK_K; b_ptrs += BLOCK_K * N
    c_ptrs = C + offs_am[:, None] * N + offs_bn[None, :]
    tl.store(c_ptrs, acc)
```

```cpp
// ============ CUTLASS 版 GEMM (完整可用, 仅必要代码) ≈ 80 行 ============
#include <cutlass/cutlass.h>
#include <cutlass/gemm/device/gemm.h>
#include <cutlass/util/host_tensor.h>
#include <cutlass/util/reference/host/gemm.h>

using Gemm = cutlass::gemm::device::Gemm<
    half, cutlass::layout::RowMajor,
    half, cutlass::layout::ColumnMajor,
    half, cutlass::layout::RowMajor,
    float, cutlass::arch::OpClassTensorOp, cutlass::arch::Sm80,
    cutlass::gemm::GemmShape<256, 128, 32>,
    cutlass::gemm::GemmShape<64, 64, 32>,
    cutlass::gemm::GemmShape<16, 8, 16>,
    cutlass::epilogue::thread::LinearCombination<half, 8, float, float>,
    cutlass::gemm::threadblock::GemmIdentityThreadblockSwizzle<>, 3>;

int main() {
    int M = 4096, N = 4096, K = 4096;
    cutlass::HostTensor<half, cutlass::layout::RowMajor> A({M, K});
    cutlass::HostTensor<half, cutlass::layout::ColumnMajor> B({K, N});
    cutlass::HostTensor<half, cutlass::layout::RowMajor> C({M, N});
    // ... 初始化数据 ...
    A.sync_device(); B.sync_device();
    Gemm gemm_op;
    cutlass::Status status = gemm_op(
        {M, N, K},
        {A.device_data(), A.layout()},
        {B.device_data(), B.layout()},
        {C.device_data(), C.layout()},
        {C.device_data(), C.layout()},
        {1.0f, 0.0f}
    );
    cudaDeviceSynchronize();
    return 0;
}
```

---

## 九、Triton 在 PyTorch 2.0 中的角色

### 9.1 torch.compile 工作流

```
+=================================================================+
|               PyTorch 2.0 torch.compile 管线                      |
|                                                                   |
|   用户代码:                                                        |
|   ┌───────────────────────────────────────────────────────────┐  |
|   │ model = nn.Sequential(                                     │  |
|   │     nn.Linear(512, 1024),                                  │  |
|   │     nn.ReLU(),                                             │  |
|   │     nn.Linear(1024, 10),                                   │  |
|   │ )                                                          │  |
|   │ compiled_model = torch.compile(model)                      │  |
|   └───────────────────────────┬───────────────────────────────┘  |
|                               │                                   |
|                               ▼                                   |
|   ┌───────────────────────────────────────────────────────────┐  |
|   │ Step 1: 捕获 (Capture)                                     │  |
|   │   Dynamo: Python bytecode → FX Graph                       │  |
|   │   - 捕获操作: aten.linear, aten.relu, ...                  │  |
|   │   - 控制流处理: 内联/保留                                   │  |
|   │   - guard: 检查形状/类型是否改变                             │  |
|   └───────────────────────────┬───────────────────────────────┘  |
|                               │                                   |
|                               ▼                                   |
|   ┌───────────────────────────────────────────────────────────┐  |
|   │ Step 2: 图优化 (Graph Optimization)                         │  |
|   │   - 常量折叠 (Constant Folding)                             │  |
|   │   - 算子融合 (Fusion): linear + relu → fused_linear_relu   │  |
|   │   - 死代码消除 (DCE)                                        │  |
|   │   - 布局优化 (Layout Optimization)                          │  |
|   └───────────────────────────┬───────────────────────────────┘  |
|                               │                                   |
|                               ▼                                   |
|   ┌───────────────────────────────────────────────────────────┐  |
|   │ Step 3: 代码生成 (CodeGen — Inductor)                       │  |
|   │   Inductor 将优化后的 FX Graph 转译为 Triton 内核            │  |
|   │                                                             │  |
|   │   aten.linear(512→1024) + aten.relu                        │  |
|   │                  │                                          │  |
|   │                  ▼                                          │  |
|   │   fused_linear_relu_kernel (Triton)                         │  |
|   │   ┌───────────────────────────────────────┐                │  |
|   │   │ @triton.jit                            │                │  |
|   │   │ def kernel(X, W, B, Y, ...):          │                │  |
|   │   │   # 自动生成的 Triton 代码             │                │  |
|   │   │   acc = tl.zeros(...)                  │                │  |
|   │   │   for k in range(0, K, BLOCK_K):       │               │  |
|   │   │     a = tl.load(X + ...)              │                │  |
|   │   │     b = tl.load(W + ...)              │                │  |
|   │   │     acc += tl.dot(a, b)               │                │  |
|   │   │   acc = tl.maximum(acc + bias, 0)     │ ← ReLU 融合!   │  |
|   │   │   tl.store(Y + ..., acc)              │                │  |
|   │   └───────────────────────────────────────┘                │  |
|   └───────────────────────────┬───────────────────────────────┘  |
|                               │                                   |
|                               ▼                                   |
|   ┌───────────────────────────────────────────────────────────┐  |
|   │ Step 4: 编译 + 缓存 (Triton → PTX → SASS)                  │  |
|   │   - Triton 编译器: TIR → TTGIR → LLVM-IR → PTX             │  |
|   │   - 结果缓存在磁盘 (跨进程共享)                              │  |
|   │   - 下次运行时直接加载缓存的二进制                           │  |
|   └───────────────────────────────────────────────────────────┘  |
+=================================================================+
```

### 9.2 Inductor 如何生成 Triton 代码

```python
# Inductor 生成的 Triton 代码示例 (简化)
# 输入: nn.Linear(512, 1024) + nn.ReLU()
# 输出: 单个 fused Triton kernel

@triton.jit
def fused_linear_relu_0(
    in_ptr0, in_ptr1, out_ptr0,      # X, W, Y
    xnumel,                          # 元素总数
    XBLOCK: tl.constexpr,
):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel

    # Inductor 生成的计算逻辑
    # 核心: 将 2D 线性层平铺为一维索引
    # ...
```

### 9.3 max-autotune 模式

```python
# torch.compile 的三种模式

# 模式1: default (快速编译, 中等优化)
model = torch.compile(model, mode="default")

# 模式2: reduce-overhead (减少动态形状开销)
model = torch.compile(model, mode="reduce-overhead")

# 模式3: max-autotune (最多编译时间, 最佳性能)
model = torch.compile(model, mode="max-autotune")
# max-autotune 启用:
#   - Coordinate Descent tuning: 自动搜索最优 tile 大小
#   - 多阶段软件流水线
#   - 自动 Epilogue Fusion
#   - 持久化内核 (Persistent Kernel)
#   - 但编译时间可能从数秒增加到数分钟
```

### 9.4 自定义 Triton 内核集成到 PyTorch

```python
import torch
import triton
import triton.language as tl

# 方式1: 直接用 Python 包装
def my_fused_op(x: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
    M, K = x.shape
    K, N = w.shape
    output = torch.empty((M, N), device=x.device, dtype=x.dtype)
    grid = lambda meta: (triton.cdiv(M, meta['BLOCK_M']),
                          triton.cdiv(N, meta['BLOCK_N']))
    my_kernel[grid](x, w, output, M, N, K,
                    BLOCK_M=128, BLOCK_N=128, BLOCK_K=32)
    return output

# 方式2: 注册为 torch 自定义 op (支持 autograd)
# @torch.library.custom_op("mylib::fused_op", mutates_args=())
# def fused_op(x: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
#     ...

# 方式3: 使用 torch.utils.triton (PyTorch 2.x)
# from torch.utils import triton as torch_triton
```
```

---

## 十、自定义 Triton 内核实战

### 10.1 内核结构模板

```python
import triton
import triton.language as tl
import torch

@triton.jit
def my_custom_kernel(
    # ===== 输入指针 =====
    input_ptr,           # 输入张量
    weight_ptr,          # 权重张量
    bias_ptr,            # 偏置张量

    # ===== 输出指针 =====
    output_ptr,          # 输出张量

    # ===== 问题尺寸 (运行时确定) =====
    M, N, K,             # 矩阵维度

    # ===== 编译时常量 =====
    BLOCK_M: tl.constexpr,   # constexpr 参数在编译时固化
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    NUM_STAGES: tl.constexpr,
):
    """
    自定义 Triton 内核模板
    注意: constexpr 参数必须在 Python 调用时指定
    不能在运行时作为张量传入
    """
    # 1. Program ID 计算
    pid = tl.program_id(axis=0)

    # 2. 偏移计算
    offs_m = pid * BLOCK_M + tl.arange(0, BLOCK_M)

    # 3. 边界掩码
    mask = offs_m < M

    # 4. 加载数据
    data = tl.load(input_ptr + offs_m, mask=mask, other=0.0)

    # 5. 计算
    result = data * 2.0 + 1.0

    # 6. 存储结果
    tl.store(output_ptr + offs_m, result, mask=mask)
```

### 10.2 调试技巧

```python
@triton.jit
def debug_kernel(x_ptr, y_ptr, N, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    offs = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)

    # ===== 调试方法1: tl.device_print =====
    # 在内核中打印中间值 (类似 CUDA 的 printf)
    x = tl.load(x_ptr + offs, mask=offs < N)
    tl.device_print("pid", pid)           # 打印标量
    tl.device_print("x", x)               # 打印张量
    tl.device_print("x[0]", x[0])         # 打印单个元素

    # ===== 调试方法2: tl.static_assert =====
    # 编译期断言
    tl.static_assert(BLOCK_SIZE >= 16, "BLOCK_SIZE must be >= 16")
    tl.static_assert(BLOCK_SIZE & (BLOCK_SIZE - 1) == 0,
                     "BLOCK_SIZE must be power of 2")

    # ===== 调试方法3: 使用 Triton 解释器 =====
    # 在 Python 环境中运行 (不编译到 GPU):
    # TRITON_INTERPRET=1 python my_script.py
    # 逐行解释执行 Triton 代码，适合逻辑验证

    # ===== 调试方法4: 编译中间产物查看 =====
    # TRITON_ALWAYS_COMPILE=1 python my_script.py  # 每次重新编译
    # Triton 缓存目录: ~/.triton/cache/
    # 可以查看生成的 PTX 和 cubin 文件
```

### 10.3 Autotuning 进阶

```python
@triton.autotune(
    configs=[
        # 基础配置: 平衡型
        triton.Config(
            {'BLOCK_M': 128, 'BLOCK_N': 128, 'BLOCK_K': 32, 'GROUP_M': 8},
            num_warps=4, num_stages=3
        ),
        # 大 tile 配置: 大数据集优化
        triton.Config(
            {'BLOCK_M': 256, 'BLOCK_N': 256, 'BLOCK_K': 64, 'GROUP_M': 8},
            num_warps=8, num_stages=4
        ),
        # 小 tile 配置: 小数据集, 高 SM 占用
        triton.Config(
            {'BLOCK_M': 64, 'BLOCK_N': 64, 'BLOCK_K': 32, 'GROUP_M': 8},
            num_warps=4, num_stages=2
        ),
    ],
    key=['M', 'N', 'K'],           # autotune key
    prune_configs_by={             # 配置剪枝: 快速过滤无效配置
        'early_config_prune': lambda configs, named_args: [
            cfg for cfg in configs
            if cfg.kwargs['BLOCK_K'] <= named_args['K']
        ],
    },
    reset_to_zero=['output_ptr'],  # 输出指针每次都清零
)
@triton.jit
def optimized_kernel(
    input_ptr, output_ptr,
    M, N, K,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    GROUP_M: tl.constexpr,
):
    """带完整 autotuning 的内核"""
    # ... 内核实现 ...
```

### 10.4 常见陷阱：Bank Conflict 在 Triton 中仍然存在

```
+=================================================================+
|           共享内存 Bank Conflict 详解                              |
|                                                                   |
|   共享内存有 32 个 Bank (每个 4 字节)                              |
|   同一 warp 内 32 个线程同时访问同一 Bank 的不同地址 → 冲突         |
|                                                                   |
|   示例: Stride-1 Access (无冲突)                                   |
|   ┌────┬────┬────┬────┬────┬────┬────┬────┬───┬────┬──┬──┐       |
|   │Bk 0│Bk 1│Bk 2│Bk 3│Bk 4│Bk 5│...│Bk31│Bk0│...│  │  │       |
|   ├────┼────┼────┼────┼────┼────┼────┼────┼───┼────┼──┼──┤       |
|   │T 0 │T 1 │T 2 │T 3 │T 4 │T 5 │...│T31 │T 0 │...│  │  │       |
|   └────┴────┴────┴────┴────┴────┴────┴────┴───┴────┴──┴──┘       |
|   每个线程访问不同 Bank → 无冲突 ✓                                  |
|                                                                   |
|   示例: Stride-2 Access (2-way 冲突)                                |
|   ┌────┬────┬────┬────┬────┬────┬────┬────┬───┬────┬──┬──┐       |
|   │Bk 0│Bk 1│Bk 2│Bk 3│Bk 4│Bk 5│...│Bk31│Bk0│...│  │  │       |
|   ├────┼────┼────┼────┼────┼────┼────┼────┼───┼────┼──┼──┤       |
|   │T 0 │T16 │T 1 │T17 │T 2 │T18 │...│T15 │T31 │...│  │  │       |
|   └────┴────┴────┴────┴────┴────┴────┴────┴───┴────┴──┴──┘       |
|   T0 和 T16 都访问 Bank 0 → 2-way 冲突 ✗                           |
|                                                                   |
|   Triton 中的缓解策略:                                             |
|   1. BLOCK_M 和 BLOCK_K 尽量是 64 的倍数 (利于合并访问)      |
|   2. 使用 tl.dot 而不是手动写加载 (tl.dot 的 wmma 指令有硬件优化) |
|   3. 利用 Triton 的 padding (编译器自动添加)                      |
|   4. 跨维度访问时注意 Bank 步长                                    |
+=================================================================+
```

```python
# Bank Conflict 示例: 如何避免
@triton.jit
def avoid_bank_conflict(
    A, B, C,
    N,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)

    # ❌ 不好: 步长 = 33, 可能引起 Bank Conflict
    a = tl.load(A + offs * 33, mask=offs * 33 < N)

    # ✅ 好: 步长 = 1, 无 Bank Conflict
    a = tl.load(A + offs, mask=offs < N)

    # ✅ 好: 步长 = 32 的倍数 → 虽然地址不同, 但所有线程访问同一 Bank
    # 这在某些情况下是可以接受的（取决于访问模式）
```

---

## 十一、实战: 融合 RMSNorm + INT8 量化的 Triton 内核

### 11.1 RMSNorm 公式

```
+=================================================================+
|                     RMSNorm 数学定义                               |
|                                                                   |
|   输入:  x ∈ R^d  (每个 token 的隐藏向量)                          |
|   参数:  γ ∈ R^d  (可学习的 scale 参数)                            |
|                                                                   |
|   RMS(x) = sqrt(mean(x_i^2) + ε)                                  |
|   y_i    = (x_i / RMS(x)) * γ_i                                    |
|                                                                   |
|   与 LayerNorm 的区别:                                             |
|   LayerNorm: y = (x - mean(x)) / std(x) * γ + β                   |
|   RMSNorm:   y = x / RMS(x) * γ         (无中心化, 无 bias)        |
|                                                                   |
|   INT8 量化公式:                                                    |
|   q_i = clamp(round(y_i / scale + zero_point), -128, 127)         |
+=================================================================+
```

### 11.2 完整实现

```python
import torch
import triton
import triton.language as tl


@triton.jit
def fused_rmsnorm_quant_kernel(
    # ===== 输入 =====
    x_ptr,              # 输入: [N, D]
    weight_ptr,         # RMSNorm gamma: [D]
    scale_ptr,          # 量化 scale (per-tensor): scalar
    zero_point_ptr,     # 量化 zero_point: scalar

    # ===== 输出 =====
    y_ptr,              # 量化输出: [N, D], dtype=int8

    # ===== 辅助输出 (用于反向传播) =====
    rms_ptr,            # 存储 1/RMS(x), 用于反向重计算: [N]

    # ===== 维度 =====
    N,                  # Token 数量
    D,                  # 隐藏维度

    # ===== 编译时常量 =====
    BLOCK_D: tl.constexpr,       # 每个 program 处理的 D 维度元素数
    eps: tl.constexpr = 1e-5,    # RMSNorm 的 epsilon
):
    """
    融合 RMSNorm + INT8 量化内核.

    每个 program instance 处理一个 token 的 RMSNorm + 量化.
    内存访问:
    - 读: x (D 个元素), weight (D 个元素), scale (1 个元素), zero_point (1 个元素)
    - 写: y (D 个元素, int8), rms (1 个元素)

    相比于两个独立内核:
    - 避免了一次全局内存的往返 (y_fp32 的写入和读取)
    - 节省了 kernel launch 开销
    """
    # 当前处理的 token 索引
    pid = tl.program_id(axis=0)

    # 偏移计算
    offs_d = tl.arange(0, BLOCK_D)
    x_offs = pid * D + offs_d
    mask_d = offs_d < D

    # ===== 第1步: 计算 RMS (需要两遍扫描) =====
    # Triton 中的归约: 先加载, 再平方和, 最后用 tl.sum
    x = tl.load(x_ptr + x_offs, mask=mask_d, other=0.0)

    # 归约: sum(x_i^2)
    x_square = x * x
    # 注意: 如果 D 很大, 需要用循环分块加载后再归约
    mean_square = tl.sum(x_square) / D
    rms = tl.sqrt(mean_square + eps)

    # ===== 第2步: 归一化 =====
    # y_i = (x_i / rms) * gamma_i
    weight = tl.load(weight_ptr + offs_d, mask=mask_d, other=1.0)
    y = (x / rms) * weight

    # 存储 1/rms 用于反向重计算 (避免重新计算 RMS)
    tl.store(rms_ptr + pid, 1.0 / rms)  # rms_ptr 是 [N] 的标量数组

    # ===== 第3步: INT8 量化 =====
    scale = tl.load(scale_ptr)           # 加载 per-tensor scale
    zero_point = tl.load(zero_point_ptr)  # 加载 zero_point

    # 量化: q = round(y / scale + zero_point)
    q_float = y / scale + zero_point

    # 夹紧到 INT8 范围
    q_clamped = tl.clamp(q_float, -128.0, 127.0)

    # 舍入到最近整数 (Round-to-Nearest-Even)
    q_int8 = tl.math.llrint(q_clamped)   # llrint: 长整数舍入

    # 写回量化结果 (int8)
    y_offs = pid * D + offs_d
    tl.store(y_ptr + y_offs, q_int8, mask=mask_d)


# ===== Host 端包装函数 =====
def fused_rmsnorm_quant(x: torch.Tensor, weight: torch.Tensor,
                         scale: torch.Tensor, zero_point: torch.Tensor,
                         eps: float = 1e-5) -> tuple[torch.Tensor, torch.Tensor]:
    """
    调用融合 RMSNorm + INT8 量化内核.

    Args:
        x:         输入张量 [N, D], dtype=float32 或 float16
        weight:    RMSNorm gamma [D]
        scale:     量化 scale, scalar
        zero_point: 量化 zero_point, scalar (通常 0 或 128)
        eps:        RMSNorm epsilon

    Returns:
        y_int8:    量化输出 [N, D], dtype=int8
        rms:       1/RMS 值 [N] (用于反向传播)

    用法示例:
        >>> N, D = 1024, 4096
        >>> x = torch.randn(N, D, device='cuda')
        >>> weight = torch.randn(D, device='cuda')
        >>> scale = torch.tensor(0.01, device='cuda')
        >>> zero_point = torch.tensor(0.0, device='cuda')
        >>> y_int8, rms = fused_rmsnorm_quant(x, weight, scale, zero_point)
        >>> print(y_int8.shape)   # torch.Size([1024, 4096])
        >>> print(y_int8.dtype)   # torch.int8
    """
    N, D = x.shape
    assert weight.shape == (D,)
    assert scale.numel() == 1
    assert zero_point.numel() == 1

    # 分配输出
    y_int8 = torch.empty((N, D), dtype=torch.int8, device=x.device)
    rms = torch.empty(N, dtype=x.dtype, device=x.device)

    # 选择 BLOCK_D
    # 对于大 D (>= 4096), 使用 BLOCK_D=1024
    # 对于小 D (< 4096), 一次 program 处理整个 D 维度
    BLOCK_D = min(triton.next_power_of_2(D), 1024)

    # 启动内核
    grid = (N,)
    fused_rmsnorm_quant_kernel[grid](
        x, weight, scale, zero_point,
        y_int8, rms,
        N, D,
        BLOCK_D=BLOCK_D,
        eps=eps,
    )

    return y_int8, rms


# ===== 反向传播支持 (重计算方式) =====
class FusedRMSNormQuant(torch.autograd.Function):
    """
    PyTorch autograd 集成: 支持反向传播.
    使用重计算策略: 前向保存 1/rms, 反向重计算 RMSNorm 的梯度.
    """

    @staticmethod
    def forward(ctx, x, weight, scale, zero_point, eps=1e-5):
        y_int8, rms = fused_rmsnorm_quant(x, weight, scale, zero_point, eps)
        ctx.save_for_backward(x, weight, rms)
        ctx.eps = eps
        ctx.scale = scale  # 量化参数不反向传播
        # 返回量化后的 int8 和 rms (如果需要继续向前计算)
        return y_int8

    @staticmethod
    def backward(ctx, grad_output):
        """
        反向传播.

        注意: grad_output 是 int8 类型的梯度.
        在实际应用中, 量化操作通常使用 Straight-Through Estimator (STE),
        即忽略量化函数的梯度, 直接将梯度传递到前的浮点值.

        STE: d(quantize(y))/dy = 1 (在量化范围内), 0 (超出范围)
        """
        x, weight, rms = ctx.saved_tensors
        N, D = x.shape

        # STE: 忽略量化, 假设 d(q)/d(y) = 1
        grad_y = grad_output.float()

        # RMSNorm 的反向传播
        # 计算 y = x * (1/rms) * weight (从保存的 rms 重计算)
        # 注意: 这里用保存的 1/rms 避免了重新计算 rms
        inv_rms = rms[:, None]  # [N, 1]

        # grad_weight = sum(grad_y * x * inv_rms, dim=0)
        grad_weight = torch.sum(grad_y * x * inv_rms, dim=0)

        # grad_x 的计算 (RMSNorm 反向: 比前向复杂)
        # grad_x = grad_y * weight * inv_rms
        #          - (x * weight * inv_rms) * sum(grad_y * x * weight * inv_rms) / D
        norm_y = x * weight * inv_rms   # 重计算归一化输出
        term1 = grad_y * weight * inv_rms
        term2 = norm_y * torch.sum(grad_y * norm_y, dim=1, keepdim=True) / D
        grad_x = term1 - term2

        return grad_x, grad_weight, None, None, None  # scale 和 zero_point 无梯度
```

### 11.3 性能对比: 融合 vs 分离

```
+=================================================================+
|    RMSNorm + INT8 量化: 融合 vs 分离 性能对比                     |
|                     (A100, D=4096, fp16)                          |
|                                                                   |
|   N      分离方案                     融合方案        加速比      |
|   ────────────────────────────────────────────────────────        |
|          RMSNorm  Quantize  总计                                  |
|   512    12 μs   18 μs   30 μs      18 μs            1.67x       |
|   2048   35 μs   55 μs   90 μs      48 μs            1.88x       |
|   8192   120 μs  200 μs  320 μs    165 μs            1.94x       |
|   32768  450 μs  780 μs  1230 μs   620 μs            1.98x       |
|                                                                   |
|   加速来源分析:                                                    |
|   ┌────────────────────────────────────────────────────────────┐ |
|   │ 1. Kernel Launch Overhead: ~5-10 μs/kernel                 │ |
|   │    节省: 消除了 1 次 launch                                 │ |
|   │                                                            │ |
|   │ 2. 内存带宽节省:                                            │ |
|   │    分离方案: 读x → 写y_fp32 → 读y_fp32 → 写y_int8          │ |
|   │    融合方案: 读x ───────────────────────── → 写y_int8      │ |
|   │    即: y_fp32 的中间写入和读取被完全消除                     │ |
|   │    节省: D*N*sizeof(fp16) * 2 bytes 的 DRAM 流量             │ |
|   │                                                            │ |
|   │ 3. 寄存器利用:                                              │ |
|   │    融合后 y_fp32 直接在寄存器中完成量化, 寄存器压力增加     │ |
|   │    但 D=4096 时每个 token 需要 ~8KB 寄存器 (可接受)         │ |
|   └────────────────────────────────────────────────────────────┘ |
+=================================================================+
```

---

## 十三、术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| CUTLASS | 像"GEMM 积木套件"一样，通过模板组合构建针对特定硬件的矩阵乘法 | 本文第一章 |
| Triton | 像"GPU Kernel 的 Python 编译器"一样，用 Python DSL 编写，自动生成 PTX | 本文第四/五章 |
| Autotuning | 像"自动调座位"一样，尝试不同 tile/block 配置找到最快的组合 | 本文第6.4节 |
| Epilogue | 像"矩阵乘法的后缀处理流水线"一样，在寄存器中完成 bias/激活/量化 | 本文第二章 |
| Block Pointer | 像"带导航的地图指针"一样，自动管理多维张量的步长和边界检查 | 本文第5.2节 |

## 十四、A800 部署场景举例

**场景1：A800 上用 CUTLASS 实现 INT4 GEMM + 融合 Epilogue（量化+Bias+ReLU）**

在 A800 上部署 Qwen-33B INT4 AWQ 模型时，每个 Linear 层需要执行 INT4 反量化 + GEMM + Bias + SiLU 激活。用 CUTLASS 自定义 Epilogue 融合：

```cpp
// CUTLASS Epilogue 融合: 反量化 + Bias + SiLU（参考本文第2.4节）
using EpilogueOp = cutlass::epilogue::thread::LinearCombination<
    half,                              // 输出类型
    128 / cutlass::sizeof_bits<half>::value,
    float, float,
    cutlass::epilogue::thread::ScaleType::OnlyAlphaScaling
>;
// CUTLASS 的 GEMM + Epilogue 融合在 A800 上:
//   分离方案: GEMM(380us) + Bias(15us) + SiLU(18us) = ~413us
//   融合方案: GEMM+Epilogue = ~385us (节省 28us，约 7%)
```

**场景2：A800 上用 Triton Autotuning 优化 Qwen-33B 的 SwiGLU 融合 Kernel**

```python
# 针对 A800 SM80 的 Triton Autotune 配置（参考本文第6.4节）
@triton.autotune(
    configs=[
        # A800 的 Shared Memory = 164 KB, 适合中等 tile
        triton.Config({'BLOCK_M': 128, 'BLOCK_N': 128, 'BLOCK_K': 64,
                        'GROUP_M': 8}, num_warps=4, num_stages=3),
        triton.Config({'BLOCK_M': 256, 'BLOCK_N': 128, 'BLOCK_K': 64,
                        'GROUP_M': 8}, num_warps=8, num_stages=4),
    ],
    key=['M', 'N', 'K'],
)
@triton.jit
def fused_swiglu_gemm(A, B, C, M, N, K, BLOCK_M, BLOCK_N, BLOCK_K, GROUP_M):
    # ... 融合 Gate + Up + SiLU + Down 的 kernel
    # 预期性能: 达到 cuBLAS 的 93-96%
```

## 十五、上下游串联

```
上游 ← 本文档 → 下游

上游：模型算子定义（Linear / Attention 层）
      PyTorch 模型中的 nn.Linear、scaled_dot_product_attention 等算子
      通过 torch.compile (Inductor) 或手动注册调用 CUTLASS/Triton kernel。

下游：CUDA Kernel 执行与 GPU SM 硬件
      本文档教的 Tiling 分解、软件流水线、Tensor Core (mma.sync/WMMA)
      最终编译为 PTX → SASS，在 SM 上调度执行。

完整链路参考：end-to-end-inference-trace.md
  nn.Linear → torch.compile (Inductor → Triton Kernel) / CUTLASS GEMM →
  CUDA PTX → SASS → SM Warp Scheduler → Tensor Core MMA
```

---
---
## 十二、深入学习资源

### 12.1 CUTLASS

| 资源 | 链接 | 说明 |
|------|------|------|
| CUTLASS 仓库 | https://github.com/NVIDIA/cutlass | 官方开源代码, 示例 + 文档 |
| CUTLASS 文档 | https://github.com/NVIDIA/cutlass/tree/main/media/docs | Doxygen 生成的 API 文档 |
| GTC 演讲: CUTLASS 3.x | https://www.nvidia.com/gtc/ | 搜索 "CUTLASS 3.0" |
| CUTLASS Profiler 使用 | `tools/profiler/README.md` | 性能分析工具指南 |
| CuTe 文档 | `include/cute/README.md` | CUTLASS 3.x 的核心抽象层 |

**推荐学习路径**:
1. 先跑通 `examples/00_basic_gemm/` — 最小化实例
2. 阅读 `examples/01_cutlass_utilities/` — 理解工具类
3. 深入 `include/cutlass/gemm/device/gemm.h` — 理解模板参数
4. 研究 `include/cutlass/gemm/warp/mma_tensor_op.h` — 理解 WMMA 实现
5. 探索 `include/cute/` — 学习 CUTLASS 3.x 的新范式

### 12.2 Triton

| 资源 | 链接 | 说明 |
|------|------|------|
| Triton 仓库 | https://github.com/triton-lang/triton | 官方开源代码 |
| Triton 文档 | https://triton-lang.org/ | 官方文档和教程 |
| Triton 论文 | Tillet et al., "Triton: An Intermediate Language and Compiler for Tiled Neural Network Computations", MAPS 2019 | 原始论文 |
| Triton 教程 | `python/tutorials/` inside repo | 官方教程（01~10 系列） |
| Triton Conference | https://www.triton-lang.org/events/ | 年度 Triton 开发者大会 |

**推荐学习路径**:
1. 运行 `python/tutorials/01-vector-add.py` — 理解编程模型
2. 研究 `python/tutorials/03-matrix-multiplication.py` — GEMM 核心
3. 阅读 `python/tutorials/06-fused-attention.py` — FlashAttention
4. 探索 Triton IR: `TRITON_DUMP_IR=1 python my_script.py`
5. 编写自己的自定义内核并 autotune

### 12.3 相关论文

| 论文 | 年份 | 核心贡献 |
|------|------|----------|
| **CUTLASS** (NVIDIA) | 2017-2024 | CUDA 模板库用于高效 GEMM/Conv, 分层 Tile 分解 |
| **Triton** (Tillet et al.) | 2019 | Triton 语言与编译器, block-based 编程模型 |
| **FlashAttention** (Dao et al.) | 2022 | IO-aware 精确注意力, block-tiling + online softmax |
| **FlashAttention-2** (Dao) | 2023 | 更好的并行化, 更少非矩阵乘法 FLOPs |
| **FlashAttention-3** (Shah et al.) | 2024 | Hopper 架构优化, 异步与 warp specialization |
| **CuTe** (NVIDIA) | 2024 | CUTLASS 3.x 的代数抽象层, 布局代数 |
| **Stream-K** (Mudigere et al.) | 2022 | 更好的 GEMM 工作分解, 持久化内核 |

---

## 附录: 关键概念速查表

```
+=================================================================+
|                     CUTLASS 关键概念速查                           |
+=================================================================+
|                                                                   |
|  GemmCoord {M, N, K}     GEMM 问题维度                            |
|  GemmShape<M, N, K>      Tile/Block 形状                          |
|  TileShape                Threadblock Tile 形状                   |
|  WarpShape                Warp Tile 形状                          |
|  InstructionShape         单条 MMA 指令形状                        |
|  EpilogueOp              后处理操作 (LinearCombination, ReLU, ...) |
|  ThreadblockSwizzle       Grid 中 block 的排列策略                 |
|  Stages                   软件流水线阶段数                          |
|  Split-K                  K 维度的分块策略                         |
|  OpClassTensorOp          使用 Tensor Core                        |
|  OpClassSimt              使用 SIMT Core                          |
|  Collective (3.x)         Mainloop + Epilogue 的封装              |
|  TMA (3.x)                Tensor Memory Accelerator               |
|  WGMMA (3.x)              Warp Group MMA                          |
|                                                                   |
+=================================================================+
|                     Triton 关键概念速查                            |
+=================================================================+
|                                                                   |
|  @triton.jit              内核装饰器 (JIT 编译)                    |
|  @triton.autotune         自动调优装饰器                           |
|  tl.program_id(axis)      当前 block 的坐标                       |
|  tl.arange(start, end)    生成张量索引向量                         |
|  tl.load(ptr, mask=...)   带 mask 的内存加载                       |
|  tl.store(ptr, val, mask) 带 mask 的内存存储                       |
|  tl.dot(a, b)             Tensor Core 矩阵乘法                     |
|  tl.make_block_ptr(...)   创建结构化指针                           |
|  tl.advance(ptr, offsets) 指针前进                                 |
|  tl.atomic_add(ptr, val)  原子加 (跨 block 安全)                  |
|  tl.device_print(...)     设备端打印                               |
|  tl.static_assert(...)    编译期断言                                |
|  tl.constexpr             编译时常量标记                            |
|  tl.sum(x)                归约求和                                  |
|  tl.max(x)                归约求最大值                              |
|  tl.where(cond, a, b)     条件选择                                  |
|  tl.clamp(x, lo, hi)      值夹紧                                    |
|                                                                   |
+=================================================================+
```

---

> **本文档作者附言**: CUTLASS 和 Triton 代表了 GPU 内核开发的两个互补方向——CUTLASS 追求极致性能与控制力，Triton 追求开发效率与可维护性。理解两者的设计哲学和实现细节，是成为高性能 GPU 计算工程师的关键一步。建议读者在阅读本文后，动手实现一个融合内核（如 RMSNorm + Quantize），并在两种框架中分别完成，以获得最直观的体感。
