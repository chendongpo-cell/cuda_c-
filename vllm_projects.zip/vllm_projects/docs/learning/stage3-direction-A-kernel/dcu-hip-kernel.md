# DCU / HIP Kernel 编程深度指南

> 本文档面向具备 CUDA 编程基础的开发者，系统性地介绍国产加速卡生态、HIP 编程模型、ROCm 软件栈，以及从 CUDA 到 HIP 的内核移植方法论。

---

## ## DCU / 国产加速卡 Overview

中国 AI 基础设施正处于从依赖进口 GPU 到自主研发的关键转型期。三大国产加速卡平台——海光 DCU、华为昇腾、寒武纪 MLU——分别代表了三条不同的技术路线。

### ### 海光 DCU 架构概述

DCU (Deep Computing Unit) 是海光信息基于 AMD 授权的 x86 和 GPU 技术自主研发的通用 AI 加速器。其架构演进遵循以下路线：

```
┌─────────────────────────────────────────────────────────┐
│                  海光 DCU 架构概览                         │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │
│  │ Compute Unit│  │ Compute Unit│  │ Compute Unit│ ... │
│  │   (CU 0)    │  │   (CU 1)    │  │   (CU N)    │     │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤     │
│  │ SALU | VALU │  │ SALU | VALU │  │ SALU | VALU │     │
│  │ SIMD16 x4   │  │ SIMD16 x4   │  │ SIMD16 x4   │     │
│  │ SGPR | VGPR │  │ SGPR | VGPR │  │ SGPR | VGPR │     │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘     │
│         │                │                │             │
│  ┌──────┴────────────────┴────────────────┴──────┐     │
│  │              L2 Cache (Shared)                  │     │
│  └──────────────────────┬────────────────────────┘     │
│                         │                               │
│  ┌──────────────────────┴────────────────────────┐     │
│  │         HBM2e Global Memory (32-64 GB)          │     │
│  └────────────────────────────────────────────────┘     │
│                         │                               │
│  ┌──────────────────────┴────────────────────────┐     │
│  │     Infinity Fabric / PCIe Host Interface       │     │
│  └────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────┘
```

DCU 的核心特点：
- **基于 CDNA 架构**：源于 AMD 的 Compute DNA 架构，专为 HPC 和 AI 计算设计
- **Matrix Core**：类似 NVIDIA Tensor Core 的矩阵乘加单元，支持 FP16/BF16/INT8 混合精度
- **HBM2e 显存**：高带宽存储，典型配置 32GB/64GB
- **Infinity Fabric**：支持多卡高速互联
- **ROCm 生态兼容**：完整支持 ROCm/HIP 软件栈

### ### 寒武纪 MLU 架构概述

寒武纪 (Cambricon) MLU (Machine Learning Unit) 是完全自研的 AI 处理器架构，其设计理念与 GPU 有本质差异。

```
┌──────────────────────────────────────────────────────┐
│             寒武纪 MLU370 架构概览                     │
├──────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────┐│
│  │         NFE (Neural Function Engine)              ││
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌───────┐  ││
│  │  │ NFE 0   │ │ NFE 1   │ │ NFE 2   │ │ NFE N │  ││
│  │  │ MAC Array│ │ MAC Array│ │ MAC Array│ │ ...   │  ││
│  │  └─────────┘ └─────────┘ └─────────┘ └───────┘  ││
│  └──────────────────────────────────────────────────┘│
│                       │                               │
│  ┌────────────────────┴────────────────────────┐     │
│  │         NRAM (On-Chip Scratchpad)             │     │
│  └──────────────────────────────────────────────┘     │
│                       │                               │
│  ┌────────────────────┴────────────────────────┐     │
│  │         SRAM (Shared On-Chip Memory)          │     │
│  └──────────────────────────────────────────────┘     │
│                       │                               │
│  ┌────────────────────┴────────────────────────┐     │
│  │    LPDDR5 / HBM Global Memory (24-48 GB)      │     │
│  └──────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────┘
```

寒武纪 MLU 的独特之处：
- **NFE (Neural Function Engine)**：专用的神经网络计算引擎，代替 GPU 的通用 SIMD 单元
- **Cambricon Neuware**：自有软件栈，指令集架构为 Bang (BANG C)
- **NRAM + SRAM 两级片上存储**：不同于 LDS/Shared Memory 的内存层次
- **VLIW 指令集**：超长指令字，编译期静态调度，与 GPU 的动态调度不同

### ### 华为昇腾架构概述

昇腾 (Ascend) 是华为基于达芬奇架构 (Da Vinci Architecture) 自研的 AI 处理器。

```
┌──────────────────────────────────────────────────────┐
│              昇腾910 Da Vinci 架构                     │
├──────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────┐│
│  │             AI Core (32 个)                       ││
│  │  ┌──────────────────────────────────────────┐    ││
│  │  │  Scalar Unit  │  Vector Unit  │ Cube Unit│    ││
│  │  │  (标量计算)    │  (向量计算)     │(矩阵计算) │    ││
│  │  └──────────────────────────────────────────┘    ││
│  │  ┌──────────────────────────────────────────┐    ││
│  │  │         L1 Buffer (1MB / Core)             │    ││
│  │  └──────────────────────────────────────────┘    ││
│  └──────────────────────────────────────────────────┘│
│                       │                               │
│  ┌────────────────────┴────────────────────────┐     │
│  │            L2 Cache (32 MB, Shared)           │     │
│  └──────────────────────────────────────────────┘     │
│                       │                               │
│  ┌────────────────────┴────────────────────────┐     │
│  │        HBM2e Global Memory (32 GB)             │     │
│  └──────────────────────────────────────────────┘     │
│                       │                               │
│  ┌────────────────────┴────────────────────────┐     │
│  │        HCCS (Huawei Cache Coherence System)    │     │
│  │        NVLink-equivalent multi-chip interconnect│     │
│  └──────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────┘
```

昇腾的特点：
- **Cube Unit**：矩阵计算专用单元，对标 Tensor Core，但硬件实现完全不同
- **CANN (Compute Architecture for Neural Networks)**：昇腾自有软件栈
- **Ascend C (原 TBE)**：类似 CUDA C 的编程语言
- **HCCS**：华为自研的高速多卡互联，对标 NVLink

### ### 横向对比表

| 特性 | NVIDIA A100 | 海光 DCU (类似 MI250X) | 昇腾 910 | 寒武纪 MLU370-X8 |
|------|-------------|----------------------|----------|------------------|
| **工艺** | TSMC 7nm | TSMC 6nm | TSMC 7nm+ | TSMC 7nm |
| **FP16 TFLOPS** | 312 (sparse) | ~383 (peak) | 256 | ~128 |
| **FP32 TFLOPS** | 19.5 | ~47.9 | — | ~64 |
| **INT8 TOPS** | 624 (sparse) | ~383 | 512 | ~256 |
| **显存容量** | 40/80 GB HBM2e | 32/64 GB HBM2e | 32 GB HBM2e | 48 GB LPDDR5 |
| **显存带宽** | 1555 GB/s (80GB) | 1638 GB/s | 1228 GB/s | ~307 GB/s |
| **核心架构** | Ampere SM | CDNA2 CU | Da Vinci AI Core | MLU NFE |
| **编程模型** | CUDA | HIP | CANN/Ascend C | BANG C (Neuware) |
| **矩阵单元** | Tensor Core 3rd Gen | Matrix Core | Cube Unit | NFE MAC Array |
| **多卡互联** | NVLink 600GB/s | Infinity Fabric | HCCS | MLU-Link |
| **软件生态成熟度** | 极高 | 中等 | 中等 | 低-中 |
| **PyTorch 支持** | 原生完备 | 基本可用 (ROCm) | 通过 torch_npu | 通过 torch_mlu |

### ### 国产硬件在 AI 基础设施中的定位

```
┌──────────────────────────────────────────────────────────────┐
│                国产 AI 加速卡生态位                            │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│   训练 (Training)              推理 (Inference)               │
│  ┌──────────────┐            ┌──────────────┐                │
│  │ 高: NVIDIA   │            │ 高: 昇腾/DCU │                │
│  │    A100/H100 │            │ 中: MLU      │                │
│  │ 中: 昇腾 910 │            │ 低: 其他     │                │
│  │    DCU       │            │              │                │
│  │ 低: MLU      │            │              │                │
│  └──────────────┘            └──────────────┘                │
│                                                               │
│  ┌────────────────────────────────────────────────────┐       │
│  │ 典型场景:                                            │       │
│  │ • 政务云 / 智慧城市: 昇腾 + 国产框架                 │       │
│  │ • 科研 / HPC: 海光 DCU + ROCm                       │       │
│  │ • 边缘推理: 寒武纪 MLU + Neuware                    │       │
│  │ • 云服务: 多平台混合部署，统一 API 层                │       │
│  └────────────────────────────────────────────────────┘       │
└──────────────────────────────────────────────────────────────┘
```

---

## ## HIP 入门

### ### HIP 概述

HIP (Heterogeneous-compute Interface for Portability) 是 AMD 开发的 C++ Runtime API，旨在提供与 CUDA 高度兼容的 GPU 编程接口。HIP 允许同一个源码文件编译为 NVIDIA GPU 原生的 CUDA 代码，或 AMD GPU 的 ROCm 代码。

```
┌──────────────────────────────────────────────────────────┐
│                    HIP 架构层次                            │
├──────────────────────────────────────────────────────────┤
│                                                           │
│   ┌──────────────────────────────────────────────────┐   │
│   │              Application Code (.cpp / .hip)        │   │
│   │     hipMalloc / hipMemcpy / hipLaunchKernelGGL     │   │
│   └───────────────┬──────────────────┬────────────────┘   │
│                   │                  │                    │
│         ┌─────────▼──────┐   ┌──────▼──────────┐        │
│         │   HIP Runtime  │   │  hipify-clang    │        │
│         │  (header-only) │   │   (transpiler)   │        │
│         └───────┬────────┘   └─────────────────┘        │
│                 │                                         │
│   ┌─────────────┼──────────────────┐                     │
│   │             ▼                  │                     │
│   │  ┌──────────────────┐         │                     │
│   │  │  NVIDIA Backend  │         │                     │
│   │  │  (CUDA Runtime)  │         │                     │
│   │  └────────┬─────────┘         │                     │
│   │           ▼                    │                     │
│   │  ┌──────────────────┐         │                     │
│   │  │   CUDA Driver    │         │                     │
│   │  │   NVIDIA GPU     │         │                     │
│   │  └──────────────────┘         │                     │
│   │                                ▼                     │
│   │                   ┌──────────────────┐              │
│   │                   │  AMD Backend     │              │
│   │                   │  (ROCm Runtime)  │              │
│   │                   └────────┬─────────┘              │
│   │                            ▼                        │
│   │                   ┌──────────────────┐              │
│   │                   │  ROCk Driver     │              │
│   │                   │  AMD GPU (DCU)   │              │
│   │                   └──────────────────┘              │
│   └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

### ### HIP Runtime API 速查

HIP Runtime API 与 CUDA Runtime API 一一对应，以下是核心 API 对照表：

```cpp
// ====== 内存管理 ======
// CUDA
cudaError_t cudaMalloc(void **devPtr, size_t size);
cudaError_t cudaFree(void *devPtr);
cudaError_t cudaMemcpy(void *dst, const void *src, size_t count, cudaMemcpyKind kind);

// HIP (一一对应)
hipError_t hipMalloc(void **devPtr, size_t size);
hipError_t hipFree(void *devPtr);
hipError_t hipMemcpy(void *dst, const void *src, size_t count, hipMemcpyKind kind);

// ====== 设备管理 ======
// CUDA
cudaError_t cudaGetDeviceCount(int *count);
cudaError_t cudaSetDevice(int device);
cudaError_t cudaGetDeviceProperties(cudaDeviceProp *prop, int device);

// HIP
hipError_t hipGetDeviceCount(int *count);
hipError_t hipSetDevice(int device);
hipError_t hipGetDeviceProperties(hipDeviceProp_t *prop, int device);

// ====== 流管理 ======
// CUDA
cudaError_t cudaStreamCreate(cudaStream_t *pStream);
cudaError_t cudaStreamSynchronize(cudaStream_t stream);
cudaError_t cudaStreamDestroy(cudaStream_t stream);

// HIP
hipError_t hipStreamCreate(hipStream_t *pStream);
hipError_t hipStreamSynchronize(hipStream_t stream);
hipError_t hipStreamDestroy(hipStream_t stream);

// ====== 事件管理 ======
// CUDA
cudaError_t cudaEventCreate(cudaEvent_t *event);
cudaError_t cudaEventRecord(cudaEvent_t event, cudaStream_t stream);
cudaError_t cudaEventElapsedTime(float *ms, cudaEvent_t start, cudaEvent_t stop);

// HIP
hipError_t hipEventCreate(hipEvent_t *event);
hipError_t hipEventRecord(hipEvent_t event, hipStream_t stream);
hipError_t hipEventElapsedTime(float *ms, hipEvent_t start, hipEvent_t stop);

// ====== 内核启动 ======
// CUDA: myKernel<<<gridDim, blockDim, sharedMem, stream>>>(args);
// HIP:  hipLaunchKernelGGL(myKernel, gridDim, blockDim, sharedMem, stream, args);
```

### ### hipcc 编译器

hipcc 是 Clang/LLVM 的薄封装，负责将 `.hip` 源码编译为 AMD GPU 可执行代码。

```bash
# 基本编译命令
hipcc -o my_app my_kernel.hip.cpp

# 指定 AMD GPU 架构 (gfx90a = MI200 系列)
hipcc --offload-arch=gfx90a -o my_app my_kernel.hip.cpp

# 开启调试符号
hipcc -g -o my_app_debug my_kernel.hip.cpp

# 查看编译过程
hipcc -v my_kernel.hip.cpp

# 同时指定多个目标架构 (fat binary)
hipcc --offload-arch=gfx908 --offload-arch=gfx90a my_kernel.hip.cpp
```

hipcc 内部编译流程：

```
.hip 源码
    │
    ▼
┌──────────────┐
│  hipcc 前端   │  clang -x hip
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ 设备代码分离  │  → .hip 文件中的 __global__ 函数提取到 GPU 编译路径
└──────┬───────┘
       │
       ▼
┌──────────────────────────────────────┐
│           主机端 clang 编译           │  → x86_64 目标代码 (.o)
└──────────────────────────────────────┘
       │
       ▼ (GPU 代码路径)
┌──────────────┐
│  Clang → LLVM│  → GPU 目标 IR
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  LLVM → AMD  │  → AMDGCN ISA
│  GPU 后端     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ 代码对象链接  │  → .hsaco 或嵌入到 .o 中
└──────────────┘
```

关键头文件：

```cpp
// 基本头文件 — 包含所有 Runtime API
#include <hip/hip_runtime.h>

// 仅 API 声明，不含实现 (适合大型项目分离编译)
#include <hip/hip_runtime_api.h>

// 设备端数学函数
#include <hip/device_functions.h>
```

---

## ## hipify: CUDA → HIP 翻译

### ### hipify 工具链

AMD 提供了两种 hipify 工具：

| 工具 | 类型 | 原理 | 适用场景 |
|------|------|------|----------|
| **hipify-clang** | 基于 Clang AST | 解析 C++ AST 后进行语义变换 | 复杂项目，需要处理宏、模板 |
| **hipify-perl** | 基于正则表达式 | 文本替换 | 简单代码、快速迁移 |

```bash
# hipify-perl: 快速文本转换
hipify-perl my_cuda.cu > my_hip.hip

# hipify-clang: 基于 AST 的精确保留
hipify-clang my_cuda.cu --output=my_hip.hip

# 整个目录递归转换
hipify-perl -inplace src/*.cu

# hipify-clang: 指定 include 路径
hipify-clang src/main.cu \
    -I/usr/local/cuda/include \
    -I./include \
    --cuda-path=/usr/local/cuda \
    -o hip_main.hip
```

### ### hipify 可以自动转换的内容

以下 CUDA API 可以自动转换为 HIP 等价物：

```cpp
// ====== 转换前 (CUDA) ======
cudaMalloc(&d_ptr, size);
cudaMemcpy(d_ptr, h_ptr, size, cudaMemcpyHostToDevice);
cudaDeviceSynchronize();
cudaStreamCreate(&stream);
dim3 grid(256), block(128);
myKernel<<<grid, block, 0, stream>>>(d_ptr, N);
cudaSetDevice(0);
cudaFree(d_ptr);

// ====== 转换后 (HIP) ======
hipMalloc(&d_ptr, size);
hipMemcpy(d_ptr, h_ptr, size, hipMemcpyHostToDevice);
hipDeviceSynchronize();
hipStreamCreate(&stream);
dim3 grid(256), block(128);
hipLaunchKernelGGL(myKernel, grid, block, 0, stream, d_ptr, N);
hipSetDevice(0);
hipFree(d_ptr);
```

### ### hipify 无法自动转换的内容

以下 CUDA 特性需要手动适配：

#### 1. 内联 PTX 汇编

```cpp
// CUDA: 内联 PTX (无法直接转换为 HIP)
__device__ float cuda_asm_add(float a, float b) {
    float result;
    asm volatile("add.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    return result;
}

// HIP: 不支持内联 PTX，需要替换为等价指令或使用 HIP 内联汇编
__device__ float hip_asm_add(float a, float b) {
    float result;
    // AMD GPU 内联汇编语法不同 (GCN ISA)
    asm volatile("v_add_f32 %0, %1, %2" : "=v"(result) : "v"(a), "v"(b));
    return result;
}
// 建议: 尽可能用 C++ 替代内联汇编
// __device__ float add(float a, float b) { return a + b; }
```

#### 2. Warp Shuffle Intrinsics 差异

```cpp
// CUDA: __shfl_sync 显式指定掩码 (CUDA 9+)
float val = __shfl_sync(0xFFFFFFFF, data, src_lane);

// HIP: __shfl 不传掩码，默认整个 wavefront (64 线程) 参与
// 这是最重要的语义差异之一！
float val = __shfl(data, src_lane);
// 注意: CUDA 的 warp size=32, HIP 的 wavefront size=64
// 分治算法必须适配！
```

#### 3. Tensor Core API

```cpp
// CUDA: 使用 WMMA API 访问 Tensor Core
#include <cuda_fp16.h>
#include <mma.h>
using namespace nvcuda;

wmma::fragment<wmma::matrix_a, 16, 16, 16, half, wmma::row_major> a_frag;
wmma::load_matrix_sync(a_frag, a_ptr, lda);
wmma::mma_sync(d_frag, a_frag, b_frag, c_frag);

// HIP: 需要使用 rocWMMA 库
#include <rocwmma/rocwmma.hpp>
rocwmma::fragment<rocwmma::matrix_a, 16, 16, 16, half, rocwmma::row_major> a_frag;
rocwmma::load_matrix_sync(a_frag, a_ptr, lda);
rocwmma::mma_sync(d_frag, a_frag, b_frag, c_frag);
```

#### 4. Cooperative Groups

```cpp
// CUDA: Cooperative Groups (HIP 支持有限)
#include <cooperative_groups.h>
namespace cg = cooperative_groups;
auto block = cg::this_thread_block();
auto tile32 = cg::tiled_partition<32>(block);

// HIP: 目前仅支持基本的 block-level 同步
// 需要回退到传统的 __syncthreads + 手写逻辑
```

#### 5. CUDA Graphs

```cpp
// CUDA: CUDA Graphs API (HIP 自 ROCm 5.2 开始部分支持)
cudaGraphCreate(&graph, 0);
cudaGraphInstantiate(&instance, graph, NULL, NULL, 0);

// HIP: 只是最近才开始支持 (ROCm 6.0+)
// hipGraphCreate(&graph, 0);
// 生产环境建议检查 HIP 版本兼容性
```

### ### 常见的 hipify 模式

#### 模式 1: Header 适配

```cpp
// 跨平台 header 写法
#ifdef __HIPCC__
    // AMD GPU 编译路径
    #include <hip/hip_runtime.h>
    #include <hip/hip_fp16.h>
    #include <rccl/rccl.h>       // RCCL (NCCL 等效)
    #include <rocblas/rocblas.h>  // rocBLAS (cuBLAS 等效)
#elif defined(__CUDACC__)
    // NVIDIA GPU 编译路径
    #include <cuda_runtime.h>
    #include <cuda_fp16.h>
    #include <nccl.h>
    #include <cublas_v2.h>
#else
    #error "No GPU compiler detected"
#endif
```

#### 模式 2: Warp Size 抽象

```cpp
// 抽象 Warp/Wavefront 大小
#ifdef __HIPCC__
    #define WARP_SIZE 64
    #define FULL_MASK 0xFFFFFFFFFFFFFFFFULL
#else
    #define WARP_SIZE 32
    #define FULL_MASK 0xFFFFFFFF
#endif

// 统一的 lane_id 获取
__device__ inline int lane_id() {
    return threadIdx.x % WARP_SIZE;
}
```

#### 模式 3: Shuffle 操作封装

```cpp
// 统一的 warp shuffle 抽象
template<typename T>
__device__ inline T warp_shfl_down(T val, int delta) {
#ifdef __HIPCC__
    // AMD: __shfl_down 在整个 64-thread wavefront 上操作
    return __shfl_down(val, delta);
#else
    return __shfl_down_sync(FULL_MASK, val, delta);
#endif
}
```

### ### 实践中的限制

1. **Warpsize 差异 (32 vs 64)**: 这是移植过程中最常见的 Bug 来源。所有假设 warp size=32 的算法（如 warp-level reduction、矩阵转置分块）都必须重新审计。

2. **Bank Conflict 模式不同**: NVIDIA GPU 的 shared memory 有 32 个 bank（每 bank 4 字节），AMD GPU 的 LDS 也是 32 个 bank，但访问模式导致的冲突行为不完全一致。

3. **寄存器压力差异**: AMD GPU 使用双寄存器文件（SGPR + VGPR），寄存器分配策略与 NVIDIA 不同，可能导致相同的核函数在两种硬件上的占用率差异很大。

4. **原子操作开销**: AMD GPU 上的原子操作（尤其是 global memory 原子操作）延迟通常更高。

---

## ## ROCm 生态系统

### ### ROCm 库全景图

```
┌──────────────────────────────────────────────────────────────────┐
│                      ROCm 软件库生态                              │
├──────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ┌──────────────────┐  ┌──────────────────┐                      │
│  │  深度学习框架     │  │  HPC / 科学计算    │                      │
│  │  PyTorch ROCm    │  │  PETSc / LAMMPS   │                      │
│  │  TF ROCm         │  │  GROMACS          │                      │
│  └────────┬─────────┘  └────────┬─────────┘                      │
│           │                     │                                  │
│  ┌────────▼─────────────────────▼────────────────────┐           │
│  │                AMD 优化库 (level-2)                 │           │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐           │           │
│  │  │ MIOpen   │ │ rocBLAS  │ │ RCCL     │           │           │
│  │  │(cuDNN等效)│ │(cuBLAS等效)│ │(NCCL等效)│           │           │
│  │  └──────────┘ └──────────┘ └──────────┘           │           │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐           │           │
│  │  │ rocFFT   │ │rocSOLVER │ │rocSPARSE │           │           │
│  │  │(cuFFT等效)│ │(cuSOLVER)│ │(cuSPARSE)│           │           │
│  │  └──────────┘ └──────────┘ └──────────┘           │           │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐           │           │
│  │  │ rocThrust│ │ rocPRIM  │ │ hipCUB   │           │           │
│  │  │(Thrust)  │ │(CUB等效) │ │(CUB等效) │           │           │
│  │  └──────────┘ └──────────┘ └──────────┘           │           │
│  └──────────────────────┬─────────────────────────────┘           │
│                         │                                          │
│  ┌──────────────────────▼─────────────────────────────┐           │
│  │                 HIP Runtime (level-1)                │           │
│  │  hipMalloc / hipMemcpy / hipStreamCreate / ...       │           │
│  └──────────────────────┬─────────────────────────────┘           │
│                         │                                          │
│  ┌──────────────────────▼─────────────────────────────┐           │
│  │              ROCm Kernel Driver / ROCk               │           │
│  └──────────────────────┬─────────────────────────────┘           │
│                         │                                          │
│  ┌──────────────────────▼─────────────────────────────┐           │
│  │                  AMD GPU 硬件                         │           │
│  │       MI50 / MI100 / MI250X / MI300X (DCU)          │           │
│  └────────────────────────────────────────────────────┘           │
└──────────────────────────────────────────────────────────────────┘
```

### ### 各库详解

#### rocBLAS (cuBLAS 等效)

```cpp
#include <rocblas/rocblas.h>

// rocBLAS 使用模式与 cuBLAS 几乎一致
rocblas_handle handle;
rocblas_create_handle(&handle);

float alpha = 1.0f, beta = 0.0f;
// SGEMM: C = alpha * A * B + beta * C
rocblas_sgemm(
    handle,
    rocblas_operation_none,   // A 不转置
    rocblas_operation_none,   // B 不转置
    M, N, K,                  // 维度
    &alpha,
    d_A, lda,
    d_B, ldb,
    &beta,
    d_C, ldc
);

rocblas_destroy_handle(handle);
```

#### rocFFT (cuFFT 等效)

```bash
# rocFFT 设计时直接 fork 了 cuFFT 的源码
# API 仅做了最小修改 (cufft → rocfft)
# 具体用法与 cuFFT 几乎完全相同
```

#### hipCUB / rocPRIM (CUB 等效)

hipCUB 是 CUB 的 HIP 移植，提供 warp-level、block-level、device-level 的并行原语：

```cpp
#include <hipcub/hipcub.hpp>

// Block-level reduction (与 CUB 完全一致)
using BlockReduce = hipcub::BlockReduce<float, 256>;
__shared__ typename BlockReduce::TempStorage temp_storage;

float thread_val = compute_value();
float block_sum = BlockReduce(temp_storage).Sum(thread_val);
```

#### MIOpen (cuDNN 等效)

MIOpen 是 AMD 的深度学习卷积/池化/归一化库：

```cpp
#include <miopen/miopen.h>

miopenHandle_t handle;
miopenCreate(&handle);

miopenTensorDescriptor_t input_desc, output_desc, filter_desc;
// ... 设置描述符 ...

miopenConvolutionForward(
    handle,
    &alpha, input_desc, d_input,
    filter_desc, d_filter,
    conv_desc, algo,
    &beta, output_desc, d_output,
    d_workspace, workspace_size
);
```

#### RCCL (NCCL 等效)

```cpp
#include <rccl/rccl.h>

ncclComm_t comm;  // 注意：RCCL 直接复用 nccl 类型名！
ncclUniqueId id;
ncclGetUniqueId(&id);
ncclCommInitRank(&comm, nranks, id, rank);

// All-Reduce (与 NCCL 完全相同的 API)
ncclAllReduce(d_send, d_recv, count, ncclFloat, ncclSum, comm, stream);
// 或使用 rccl 前缀版本
rcclAllReduce(d_send, d_recv, count, rcclFloat, rcclSum, comm, stream);
```

### ### 生态系统成熟度对比

| 类别 | CUDA 生态 | ROCm 生态 | 差距 |
|------|----------|----------|------|
| **深度学习** | cuDNN, cuBLAS, NCCL, TensorRT | MIOpen, rocBLAS, RCCL, MIGraphX | 较小 |
| **并行原语** | CUB, Thrust | hipCUB, rocPRIM, rocThrust | 较小 |
| **线性代数** | cuSOLVER, cuSPARSE, cuTENSOR | rocSOLVER, rocSPARSE, rocTENSOR | 较小 |
| **性能分析** | Nsight Systems, Nsight Compute, nvprof | rocprof, rocgdb, rocminfo | 中等 |
| **图编译** | CUDA Graphs, TensorRT | hipGraph, MIGraphX | 中等 |
| **FP8/稀疏** | 成熟 (H100+) | 追赶中 | 较大 |
| **多节点** | NCCL + NVSwitch 成熟 | RCCL + IF 成熟度较低 | 较大 |
| **调试** | cuda-gdb, compute-sanitizer | rocgdb, ROCm Validation Suite | 较大 |
| **文档/社区** | 极为丰富 | 快速增长但仍不足 | 较大 |

---

## ## AMD GPU 架构演进

### ### GCN (Graphics Core Next) — 前 CDNA 时代

GCN 是 AMD 2011-2019 年的统一 GPU 架构，同时服务图形和计算。其 Compute Unit (CU) 结构如下：

```
┌─────────────────────────────────────────────────────┐
│           GCN Compute Unit (CU) 结构                  │
├─────────────────────────────────────────────────────┤
│                                                       │
│  ┌─────────────────────────────────────────────────┐ │
│  │              指令缓存 / 标量缓存                   │ │
│  └──────────────────────┬──────────────────────────┘ │
│                         │                              │
│      ┌──────────────────┼──────────────────┐          │
│      │                  │                  │          │
│  ┌───▼────┐ ┌───────────▼──┐ ┌───────▼──────┐       │
│  │ SIMD 0 │ │  SIMD 1      │ │ ... SIMD 3   │       │
│  │16 lanes │ │  16 lanes    │ │  16 lanes    │       │
│  └───┬────┘ └──────┬───────┘ └──────┬───────┘       │
│      │              │               │                │
│      └──────────────┼───────────────┘                │
│                     │                                │
│              ┌──────▼──────┐                         │
│              │   LDS       │ 64KB 本地数据共享         │
│              │  32 banks   │                         │
│              └─────────────┘                         │
│                     │                                │
│              ┌──────▼──────┐                         │
│              │  VGPR (256) │ 256 个向量寄存器          │
│              │  64×32-bit  │                         │
│              └─────────────┘                         │
│                     │                                │
│              ┌──────▼──────┐                         │
│              │  SGPR       │ 标量寄存器 (per-wave)     │
│              └─────────────┘                         │
│                     │                                │
│              ┌──────▼──────┐                         │
│              │  纹理单元    │                         │
│              └─────────────┘                         │
└─────────────────────────────────────────────────────┘
```

GCN 核心参数：
- **每 CU 4 组 SIMD16** = 64 条 lane / CU / 周期
- **Wavefront 大小**: 64 线程（NVIDIA 的 warp 是 32 线程）
- **VGPR 数量**: 256 (Vega 20) → 512 (Radeon VII)
- **LDS**: 64KB / CU，32 个 bank，每 bank 4 字节

### ### RDNA (Radeon DNA) — 游戏架构

RDNA (RDNA 1/2/3) 是 AMD 的独立游戏 GPU 架构，虽然也有 ROCm 支持，但不适用于 HPC/AI 计算。关键差异：

| 特性 | GCN | RDNA 2 | 影响 |
|------|-----|--------|------|
| Wavefront 大小 | 64 | 32 | RDNA 改为 32-wide wavefront，不再需要拆分 |
| CU 结构 | 4×SIMD16 | 2×SIMD32 | RDNA 每个 CU 有 2 个 32-lane SIMD |
| 每 CU LDS | 64KB | 128KB | RDNA LDS 容量翻倍 |
| Matrix Core | 无 | 无 (RDNA 3 有 AI Accelerator) | 通用矩阵计算性能弱 |

### ### CDNA (Compute DNA) — 计算架构

CDNA 是 AMD 专为 HPC/AI 计算设计的架构，分三代：

#### CDNA 1 (MI100 — 2020)

```
┌─────────────────────────────────────────────────────┐
│              CDNA 1 Compute Unit                      │
├─────────────────────────────────────────────────────┤
│                                                       │
│  ┌─────────────────────────────────────────────────┐ │
│  │          4 × Matrix Core (第一代)                 │ │
│  │     支持 FP32 / FP64 矩阵运算                     │ │
│  └──────────────────────┬──────────────────────────┘ │
│                         │                              │
│  ┌──────────────────────┼──────────────────────────┐ │
│  │  4 × SIMD16 (Vector) │  标量单元 (Scalar)        │ │
│  │  FP32/FP64 向量运算  │  分支/地址计算             │ │
│  └──────────────────────┴──────────────────────────┘ │
│                         │                              │
│              ┌──────────▼──────────┐                   │
│              │   LDS 64KB / CU     │                   │
│              └─────────────────────┘                   │
└─────────────────────────────────────────────────────┘
```

#### CDNA 2 (MI250X — 2021)

```
┌──────────────────────────────────────────────────────────────┐
│              CDNA 2 — MI250X 架构                             │
├──────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌──────────────────────────────────────────────────────┐    │
│  │                  GCD 0 (Graphics Compute Die)         │    │
│  │  ┌─────────────────────────────────────────────────┐  │    │
│  │  │              110 CUs (220 实际)                  │  │    │
│  │  │  ┌───────────┐  ┌───────────┐  ┌───────────┐   │  │    │
│  │  │  │ CU (CDNA2)│  │ CU (CDNA2)│  │ CU (CDNA2)│...│  │    │
│  │  │  │  - 4x SIMD│  │  - 4x SIMD│  │  - 4x SIMD│   │  │    │
│  │  │  │  - Matrix │  │  - Matrix │  │  - Matrix │   │  │    │
│  │  │  │    Core   │  │    Core   │  │    Core   │   │  │    │
│  │  │  │  - 64KB   │  │  - 64KB   │  │  - 64KB   │   │  │    │
│  │  │  │    LDS    │  │    LDS    │  │    LDS    │   │  │    │
│  │  │  └───────────┘  └───────────┘  └───────────┘   │  │    │
│  │  └─────────────────────────────────────────────────┘  │    │
│  │                         │                               │    │
│  │              ┌──────────▼──────────┐                    │    │
│  │              │   L2 Cache 8MB       │                    │    │
│  │              └─────────────────────┘                    │    │
│  └──────────────────────────┬───────────────────────────┘    │
│                             │                                  │
│                             │ Infinity Fabric                  │
│                             │                                  │
│  ┌──────────────────────────▼───────────────────────────┐    │
│  │                  GCD 1 (同上)                          │    │
│  └──────────────────────────────────────────────────────┘    │
│                             │                                  │
│              ┌──────────────▼──────────────┐                   │
│              │  HBM2e 128 GB (64GB / GCD)  │                   │
│              │  3.2 TB/s 总带宽            │                   │
│              └─────────────────────────────┘                   │
└──────────────────────────────────────────────────────────────┘
```

CDNA 2 的关键改进：
- **Matrix Core 第二代**：支持 FP16、BF16、INT8 混合精度，总算力大幅提升
- **FP64 矩阵运算**：继承 CDNA 1 的强 FP64 能力，适合传统 HPC 负载
- **双 GCD 设计**：MI250X 有两个 GCD，通过 Infinity Fabric 互联，需特殊编程模型

#### CDNA 3 (MI300X — 2023)

CDNA 3 是 AMD 的重大架构革新，核心变化：
- **统一内存架构**: CPU (Zen 4) + GPU (CDNA 3) 共享封装，统一 HBM
- **更多 Matrix Core**: 每 CU 的矩阵算力显著提升
- **更高的 HBM 带宽**: HBM3，5.2 TB/s (MI300X)
- **支持 FP8**: 新增 FP8 数据类型支持，对标 H100
- **192GB HBM3**: 大模型推理的重要优势

### ### CDNA2 CU vs NVIDIA SM 架构对比图

```
┌─────────────────────────────────┐  ┌─────────────────────────────┐
│     CDNA2 CU (AMD MI250X)       │  │     Ampere SM (NVIDIA A100)  │
├─────────────────────────────────┤  ├─────────────────────────────┤
│                                 │  │                             │
│  Wavefront Size: 64             │  │  Warp Size: 32              │
│                                 │  │                             │
│  ┌─────────────────────────┐   │  │  ┌───────────────────────┐   │
│  │ 4x Matrix Core         │   │  │  │ 4x Tensor Core        │   │
│  │ (FP16/BF16/INT8/FP64)  │   │  │  │ (FP16/BF16/TF32/INT8) │   │
│  └─────────────────────────┘   │  │  └───────────────────────┘   │
│                                 │  │                             │
│  ┌─────────────────────────┐   │  │  ┌───────────────────────┐   │
│  │ 4x SIMD16 (向量 ALU)    │   │  │  │ 64x FP32 + 64x INT32  │   │
│  │ = 64 lanes / cycle      │   │  │  │ CUDA Cores             │   │
│  └─────────────────────────┘   │  │  └───────────────────────┘   │
│                                 │  │                             │
│  ┌─────────────────────────┐   │  │  ┌───────────────────────┐   │
│  │ 1x 标量 ALU (SALU)     │   │  │  │ 没有独立的标量单元    │   │
│  └─────────────────────────┘   │  │  └───────────────────────┘   │
│                                 │  │                             │
│  ┌───────────────┐ ┌────────┐ │  │  │  Register File: 65536     │
│  │ VGPR: 512     │ │ SGPR:  │ │  │  │ (per-SM, unified,         │
│  │ (256KB/CU)    │ │ 12.5KB │ │  │  │  per-thread = 255 max)   │
│  └───────────────┘ └────────┘ │  │  └───────────────────────┘   │
│                                 │  │                             │
│  LDS: 64KB, 32 banks, 4B/bank │  │  Shared Memory + L1: 192KB  │
│                                 │  │  32 banks, 4B/bank          │
│  L1 Cache: 16KB (separate)     │  │  (configurable partition)    │
│                                 │  │                             │
│  Max Threads/CU: 2048          │  │  Max Threads/SM: 2048       │
│  Max Wavefronts/CU: 32         │  │  Max Warps/SM: 64           │
└─────────────────────────────────┘  └─────────────────────────────┘
```

---

## ## Wavefront vs Warp 深度剖析

### ### 核心概念

```
┌─────────────────────────────────────────────────────────────┐
│              Warp vs Wavefront 对比                           │
├─────────────────┬─────────────────┬─────────────────────────┤
│   特性          │  NVIDIA Warp    │  AMD Wavefront          │
├─────────────────┼─────────────────┼─────────────────────────┤
│  线程数         │  32             │  64                     │
│  执行宽度       │  32 (1 周期)    │  16 (4 周期完成)         │
│  SIMD 模型      │  SIMT, 32-wide  │  SIMD, 4×16 on VALU    │
│  调度粒度       │  1 warp/周期/SM │  1 wavefront/周期/CU   │
│  指令发射       │  1 instr/warp  │  1 instr/wavefront     │
│  掩码类型       │  32-bit mask   │  64-bit exec mask      │
│  Shuffle 范围   │  32 线程       │  64 线程               │
│  Divergence 代价│  序列化执行     │  序列化执行(更昂贵)      │
└─────────────────┴─────────────────┴─────────────────────────┘
```

### ### Wavefront 执行时序

```
时间 →
─────────────────────────────────────────────────────────────────→

Wavefront (64 线程) 在 16-wide SIMD 上的执行:

周期 0:  ┌──────────────┐
         │ 线程 0-15    │ ← SIMD lane 0-15 执行
         └──────────────┘

周期 1:  ┌──────────────┐
         │ 线程 16-31   │ ← 同一指令，下一组
         └──────────────┘

周期 2:  ┌──────────────┐
         │ 线程 32-47   │
         └──────────────┘

周期 3:  ┌──────────────┐
         │ 线程 48-63   │
         └──────────────┘

总计: 1 条指令 × 4 个周期 = 1 个 wavefront 完成一次指令发射
```

这解释了为什么 AMD 使用 64 的 wavefront：即使硬件执行宽度只有 16，通过 4 个周期的流水可以在吞吐不变的情况下隐藏更多延迟。

### ### 分支发散行为

```cpp
// CUDA: warp 分支发散 (32 线程)
__global__ void cuda_divergence(int *data) {
    int tid = threadIdx.x;
    int warp_id = tid / 32;       // 每 32 线程一个 warp
    int lane_id = tid % 32;

    if (lane_id < 16) {
        // 16 线程执行此路径 (第二个 16 线程等待)
        data[tid] = lane_id * 2;
    } else {
        // 16 线程执行此路径 (第一个 16 线程等待)
        data[tid] = lane_id * 3;
    }
    // 总时间: 2 条路径串行
}

// HIP: wavefront 分支发散 (64 线程)
__global__ void hip_divergence(int *data) {
    int tid = threadIdx.x;
    int wave_id = tid / 64;       // 每 64 线程一个 wavefront
    int lane_id = tid % 64;       // 注意: 0-63

    if (lane_id < 16) {
        // 16 线程执行 (剩余 48 线程等待!)
        // 注意: 在 16-wide SIMD 上需要 1 个周期
        data[tid] = lane_id * 2;
    } else {
        // 48 线程执行 (需要 3 个周期!)
        data[tid] = lane_id * 3;
    }
    // 总时间: 4 条路径串行! (更昂贵)
}
```

**关键结论**: NVIDIA warp 的分支发散代价相对清晰（2-way divergence 代价约 2x），但 AMD wavefront 的分支发散代价更加昂贵，因为 64 线程可能分裂为多个 16 线程的组，每个组都需要各自完成 4 周期流水。

### ### HIP 中的 warpSize 抽象

HIP 提供了 `warpSize` 宏来抽象 wavefront 大小，但背后有陷阱：

```cpp
// hip/hip_runtime.h 中定义
#if defined(__HIP_PLATFORM_AMD__) || defined(__HIP_PLATFORM_SPIRV__)
    #define warpSize 64
#else
    #define warpSize 32
#endif
```

但是，**并非所有 `warpSize` 用法都是安全的**。见下例：

```cpp
// ========== 不安全的模式 ==========
const int WARP_SIZE = 32;  // 硬编码假设! 在 AMD 上跑会出错

// warp-level reduction (在 AMD 上会漏算一半数据)
__device__ float unsafe_warp_reduce(float val) {
    for (int offset = 16; offset > 0; offset /= 2) {
        // 在 AMD 上: offset 从 16 开始 → 只能覆盖 31 个 lane!
        // wavefront 有 64 个 lane，后 32 个 lane 没有被规约!
        val += __shfl_down(val, offset);
    }
    return val;
}

// ========== 安全的模式 ==========
__device__ float safe_warp_reduce(float val) {
    // 使用 warpSize 宏，自适应 wavefront/warp 大小
    for (int offset = warpSize / 2; offset > 0; offset /= 2) {
        val += __shfl_down(val, offset);
    }
    return val;
}
```

### ### Shuffle 操作对比

```
CUDA __shfl_sync 模式                     HIP __shfl 模式
─────────────────────                     ────────────────

mask = 0xFFFFFFFF (32-bit)                无显式掩码 (隐式 64-bit)
范围: 32 线程                             范围: 64 线程

__shfl_sync(mask, val, src_lane)          __shfl(val, src_lane)
  → 第 src_lane 个线程的值广播到所有         → 第 src_lane 个线程的值广播到所有
    32 个线程 (lane 号 0..31)                 64 个线程 (lane 号 0..63)

__shfl_up_sync(mask, val, delta)          __shfl_up(val, delta)
  → 从 lane_id - delta 处取值                → 从 lane_id - delta 处取值
    (越界返回自身或0)                           (越界返回自身)

__shfl_down_sync(mask, val, delta)        __shfl_down(val, delta)
  → 从 lane_id + delta 处取值                → 从 lane_id + delta 处取值

__shfl_xor_sync(mask, val, lane_mask)     __shfl_xor(val, lane_mask)
  → lane_id XOR lane_mask 处的值             → lane_id XOR lane_mask 处的值

关键差异: HIP 的 __shfl 范围是 64 (完整 wavefront)
CUDA 的 __shfl_sync 可指定任意子集 (通过 mask)
```

### ### 规约算法适配示例

#### NVIDIA 32-Thread Butterfly Reduce

```cuda
__device__ float warp_reduce_cuda(float val) {
    // 32-thread butterfly reduction
    val += __shfl_xor_sync(0xFFFFFFFF, val, 16);
    val += __shfl_xor_sync(0xFFFFFFFF, val, 8);
    val += __shfl_xor_sync(0xFFFFFFFF, val, 4);
    val += __shfl_xor_sync(0xFFFFFFFF, val, 2);
    val += __shfl_xor_sync(0xFFFFFFFF, val, 1);
    return val;  // 所有 32 个线程得到同样的总和
}
// 步骤可视化 (32-thread):
// 初始:   [v0  v1  v2  v3 ... v31]
// xor 16: [v0+v16, v1+v17, ..., v15+v31, v16+v0, ..., v31+v15]
// xor 8:  [v0+v8+v16+v24, ...]
// xor 4: ...
// xor 2: ...
// xor 1:  all = sum(v0..v31)
```

#### AMD 64-Thread Butterfly Reduce

```cpp
__device__ float wavefront_reduce_hip(float val) {
    // 64-thread butterfly reduction (wavefront 大小为 64)
    val += __shfl_xor(val, 32);
    val += __shfl_xor(val, 16);
    val += __shfl_xor(val, 8);
    val += __shfl_xor(val, 4);
    val += __shfl_xor(val, 2);
    val += __shfl_xor(val, 1);
    return val;  // 所有 64 个线程得到同样的总和
}

// 步骤可视化 (64-thread):
// 初始:   [v0  v1 ... v63]
// xor 32: [v0+v32, v1+v33, ..., v31+v63, v32+v0, ..., v63+v31]
// xor 16: [v0+v16+v32+v48, ...]
// ...
// xor 1:  all = sum(v0..v63)
```

#### 跨平台统一 Reduce

```cpp
// 可以同时用于 NVIDIA (warp=32) 和 AMD (wavefront=64)
template<typename T>
__device__ inline T warp_reduce_sum(T val) {
    #pragma unroll
    for (int offset = warpSize / 2; offset > 0; offset /= 2) {
        val += __shfl_xor(val, offset);
    }
    return val;
}
// 在 CUDA 上: 展开为 offset=16,8,4,2,1
// 在 HIP 上:  展开为 offset=32,16,8,4,2,1
```

---

## ## LDS (Local Data Share) 深度剖析

### ### AMD LDS 基础

LDS 是 AMD GPU 的片上共享存储，相当于 NVIDIA 的 Shared Memory，但硬件实现有显著差异。

```
┌──────────────────────────────────────────────────────────────┐
│            LDS vs Shared Memory 对比                          │
├───────────────────────┬──────────────────┬───────────────────┤
│   特性                 │  NVIDIA SMEM     │  AMD LDS          │
├───────────────────────┼──────────────────┼───────────────────┤
│  每 CU/SM 容量         │  48-192 KB       │  64 KB            │
│  Bank 数量             │  32              │  32               │
│  每 Bank 宽度          │  4 bytes (32-bit)│  4 bytes          │
│  每 CU 最大线程数       │  2048            │  2048             │
│  与 L1 Cache 关系      │  统一 SRAM 分区   │  独立 SRAM       │
│  Bank 冲突模式          │  N-way conflict  │  N-way conflict   │
│  原子操作支持           │  硬件支持         │  硬件支持         │
│  __shared__ 关键字      │  相同             │  相同             │
└───────────────────────┴──────────────────┴───────────────────┘
```

### ### LDS Bank 冲突模式

```
LDS 地址空间 (每个 CU 独立):

地址 ──→  Bank 0  Bank 1  Bank 2  ...  Bank 31
           │       │       │             │
0x0000     [4B]    [4B]    [4B]    ...   [4B]   ← 128B 跨距 (32 banks × 4B)
0x0080     [4B]    [4B]    [4B]    ...   [4B]
0x0100     [4B]    [4B]    [4B]    ...   [4B]
  ...

Bank = (byte_address / 4) % 32

===================================================

无冲突访问 (1 周期):
  线程 0 访问 Bank 0
  线程 1 访问 Bank 1
  ...
  线程 31 访问 Bank 31
  → 所有 thread 访问不同 bank，无冲突

2-way 冲突 (2 周期):
  线程 0 访问 Bank 0 ← 冲突!
  线程 1 访问 Bank 0 ← 冲突!
  → 两个线程访问同一 bank 的不同地址 → 串行化

32-way 冲突 (32 周期，最坏情况):
  所有 32 个线程访问 Bank 0
  → 完全串行!
```

### ### 常见 Bank Conflict 模式

```cpp
// 模式 1: Strided Access (stride = 32 → 无冲突)
__global__ void stride_32_no_conflict(float *data) {
    __shared__ float smem[32][32];
    int tid = threadIdx.x;
    // 线程 0..31 分别访问 smem[0..31][0]
    // Bank = (row * 32 * 4 / 4) % 32 = row % 32
    // 每个线程访问不同的 row → 不同的 bank → 无冲突!
    float val = smem[tid][0];
}

// 模式 2: Strided Access (stride = 2 → 冲突)
__global__ void stride_2_conflict(float *data) {
    __shared__ float smem[32][32];
    int tid = threadIdx.x;
    // 线程 0→smem[0][0], 线程 16→smem[16][0]
    // Bank(0) = 0, Bank(16) = 16 → 不冲突
    // 但线程 0 和线程 16 访问同一 bank 吗?
    // smem[tid*2][0]: tid=0→Bank0, tid=1→Bank2, ..., tid=16→Bank0 ←冲突!
    float val = smem[tid * 2][0];
}

// 模式 3: Padding 解决冲突
__global__ void padded_no_conflict(float *data) {
    // 在每行末尾添加 1 个 padding 元素
    __shared__ float smem[32][32 + 1];  // 注意 32+1
    int tid = threadIdx.x;
    // 现在每行 132 字节 (33×4)
    // Bank(0) = 0, Bank(16) = (16×33×4/4) % 32 = 16
    // 仍然可能冲突，但模式改变可以减少某些冲突
    float val = smem[tid * 2][0];
}
```

### ### 专用 LDS 指令

AMD GPU 提供了专用的 LDS 访问指令（通常在编写汇编时使用）：

```asm
; LDS 读取 (低延迟)
ds_read_b32    v[dest], v[addr]         ; 读取 32-bit
ds_read_b64    v[dest:dest+1], v[addr]  ; 读取 64-bit (2 个连续 dword)
ds_read_b128   v[dest:dest+3], v[addr]  ; 读取 128-bit (4 个连续 dword)

; LDS 写入
ds_write_b32   v[addr], v[src]          ; 写入 32-bit
ds_write_b64   v[addr], v[src:src+1]    ; 写入 64-bit
ds_write_b128  v[addr], v[src:src+3]    ; 写入 128-bit

; LDS 原子操作
ds_add_rtn_u32 v[dest], v[addr], v[val] ; 原子加，返回旧值
ds_min_rtn_f32 v[dest], v[addr], v[val] ; 原子最小值
ds_cmpst_rtn_b32 ...                     ; 原子比较交换

; LDS 带偏移读取
ds_read_b32 v[dest], v[addr] offset:4095 ; 地址 + 偏移
```

这些指令在 HIP 中可以通过编译器自动生成，但理解它们有助于分析编译产物和性能：

```cpp
// HIP 代码
__shared__ float smem[256];
int tid = threadIdx.x;
float val = smem[tid];  // 编译器将生成 ds_read_b32 指令

// 生成的 GCN 汇编:
// v_mov_b32     v0, s4           ; 将 smem 基地址加载到 VGPR
// v_lshlrev_b32 v1, 2, v1        ; tid * 4 (sizeof float)
// ds_read_b32   v2, v1           ; LDS 读取!
// s_waitcnt     lgkmcnt(0)        ; 等待 LDS 完成
```

---

## ## Vector vs Scalar Registers (AMD 独有特性)

### ### 双寄存器文件架构

AMD GPU 最独特的硬件特性之一就是**双寄存器文件架构**，这是 NVIDIA GPU 没有的设计。

```
┌──────────────────────────────────────────────────────────────┐
│          AMD GPU 双寄存器文件架构                              │
├──────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌───────────────────────────────┐  ┌──────────────────────┐ │
│  │     SGPR (Scalar GPR)         │  │   VGPR (Vector GPR)  │ │
│  │                               │  │                      │ │
│  │  • 每 wavefront 1 份          │  │  • 每线程 1 份       │ │
│  │  • 通常 102-106 个            │  │  • 通常 256-512 个   │ │
│  │  • 4 bytes 每个               │  │  • 4 bytes 每个      │ │
│  │  • 由标量 ALU (SALU) 操作    │  │  • 由向量 ALU (VALU) │ │
│  │  • 同一 wavefront 的所有      │  │  • 每个线程有独立    │ │
│  │    线程共享同一个值            │  │    的值              │ │
│  └───────────────┬───────────────┘  └──────────┬───────────┘ │
│                  │                              │             │
│  ┌───────────────▼───────────────┐  ┌──────────▼───────────┐ │
│  │     SALU (标量 ALU)           │  │   VALU (向量 ALU)    │ │
│  │  • 1 个/CU                    │  │  • 4 个 SIMD16/CU    │ │
│  │  • 操作 SGPR                  │  │  • 操作 VGPR         │ │
│  │  • 可执行分支/地址计算         │  │  • 执行数值计算     │ │
│  │  • 不跨线程                    │  │  • 跨 16 条 SIMD    │ │
│  └───────────────────────────────┘  └──────────────────────┘ │
│                                                                │
│  对比 NVIDIA:                                                  │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  NVIDIA SM: 只有统一寄存器文件 (per-thread)          │    │
│  │  所有寄存器都是 per-thread，无标量/向量之分           │    │
│  │  统一寄存器文件 = 65536 × 32-bit per SM              │    │
│  └──────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────┘
```

### ### SGPR vs VGPR 使用场景

```cpp
// ====== SGPR 友好的模式 ======

// 1. 常量/Uniform 数据 → 编译器会放入 SGPR
__constant__ float const_array[1024];   // 只读常量内存 → SGPR
__device__ void use_constant() {
    float val = const_array[0];  // 整个 wavefront 读取同一地址 → 1 条标量加载
}

// 2. 循环边界 (全 wavefront 相同)
__global__ void uniform_loop(float *out, int N) {
    int tid = threadIdx.x + blockIdx.x * blockDim.x;
    // N 是 kernel 参数 → 编译器放入 SGPR
    // 所有 64 个线程的 N 相同 → 只用 1 个 SGPR
    if (tid < N) {
        out[tid] = tid * 2.0f;
    }
}

// 3. blockIdx, gridDim → SGPR
__global__ void grid_params(float *data) {
    int block_start = blockIdx.x * blockDim.x;  // blockIdx.x → SGPR
    // 整个 block 内所有线程的 blockIdx.x 相同
}

// ====== VGPR 必须使用的模式 ======

// 1. threadIdx.x → VGPR (每个线程不同)
__global__ void per_thread_compute(float *data) {
    int tid = threadIdx.x;  // 线程 0=0, 线程 1=1, ... → 必须 VGPR
    // 64 个不同的值 → 占用 64 个 VGPR
}

// 2. 数据依赖的地址
__global__ void data_dependent(float *data, int *indices) {
    int idx = indices[threadIdx.x];  // 每个线程可能不同 → VGPR
    float val = data[idx];
}

// ====== 利用 SGPR 的优化技巧 ======

// 1. 编译期常量使用模板参数替代 kernel 参数
template<int BLOCK_SIZE>
__global__ void templated_kernel(float *data) {
    __shared__ float smem[BLOCK_SIZE];  // BLOCK_SIZE 编译期确定 → 不占用 GPR
    // 如果 BLOCK_SIZE 是 kernel 参数 → 会占用 SGPR
}

// 2. 显式标注 uniform 数据循环不变量
__global__ void uniform_aware(float *mat, int rows, int cols) {
    // rows 和 cols 对所有线程相同 → SGPR
    // 编译器自动识别
}
```

### ### 寄存器压力与占用率

```
占用率 (Occupancy) 计算:

CUDA (A100):
  Max Threads/SM = 2048
  Max Registers/SM = 65536
  Occupancy = min(active_warps / 64, (65536 / registers_per_thread) / 32)

HIP (MI250X):
  Max Wavefronts/CU = 32 (但仅物理 4 个 SIMD × 可流水 = 逻辑 32)
  Max VGPR/CU = 65536 × 4 bytes = 262 KB
  Max SGPR/CU = 3200 × 4 bytes ≈ 12.5 KB (每个 CU)

  关键限制:
  VGPR 数量决定占用率:
  - 256 VGPR/wavefront: 65536/256 = 256 threads, 256/64 = 4 wavefronts/CU
  - 128 VGPR/wavefront: 65536/128 = 512 threads, 512/64 = 8 wavefronts/CU
  - 64  VGPR/wavefront:  65536/64  = 1024 threads, 1024/64 = 16 wavefronts/CU

  VGPR 压力过大是 ROCm 性能下降的常见原因 ——
  同样的 CUDA kernel 移植到 HIP 可能因为 VGPR 使用更多而导致占用率减半。
```

### ### 移植影响总结

从 CUDA 移植到 HIP 时，双寄存器文件的影响：

1. **SGPR 溢出**: 如果使用了大量 uniform 数据（kernel 参数、常量表），SGPR 可能溢出到 VGPR 或显存，导致性能骤降。

2. **VGPR 压力敏感度更高**: 由于 VGPR 数量直接影响 wavefront 级的占用率，VGPR 压力比 CUDA 更敏感。

3. **分支优化**: 将条件分支的判定条件尽可能使用 uniform 值（SGPR），让 SALU 而非 VALU 处理分支配。这样 CU 中的分支单元更高效。

4. **编译器选项**:
```bash
# 限制 VGPR 使用数量 (强制编译器溢出到栈/LDS)
hipcc -Rpass-analysis=kernel-resource-usage \
      -Xoffload-linker --vgpr-limit=128 \
      my_kernel.cpp
```

---

## ## Porting CUDA Kernels to HIP

### ### 移植检查清单

```
┌──────────────────────────────────────────────────────────────┐
│          CUDA → HIP 内核移植检查清单                          │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  [ ] 1.  Warp Size 检查                                      │
│      - 所有假设 warpSize=32 的硬编码替换为 warpSize 宏        │
│      - warp-level reduction 算法审计                         │
│                                                               │
│  [ ] 2.  Shuffle Intrinsics 检查                             │
│      - __shfl_sync(mask, ...) → __shfl(...)                 │
│      - 注意: HIP __shfl 覆盖所有 64 线程                     │
│                                                               │
│  [ ] 3.  Shared Memory Bank Conflict 审计                    │
│      - 使用宽为 33/34 的 padding 而非 32                     │
│      - 检查 strided access 模式                              │
│                                                               │
│  [ ] 4.  寄存器压力评估                                       │
│      - 相同 kernel 在 HIP 上可能使用更多 VGPR                │
│      - 考虑拆分大 kernel 为多个小 kernel                     │
│                                                               │
│  [ ] 5.  内联 PTX → 等效 C++ 或 AMD 内联汇编                 │
│      - 尽可能用标准 C++ 替代                                 │
│                                                               │
│  [ ] 6.  Tensor Core → rocWMMA 或 hipRTC                     │
│      - 使用 #ifdef __HIPCC__ 分支                            │
│                                                               │
│  [ ] 7.  Cooperative Groups → 回退到 __syncthreads           │
│                                                               │
│  [ ] 8.  CUDA Graphs → hipGraph (检查 ROCm 版本)             │
│                                                               │
│  [ ] 9.  Atomic Operations 审计                              │
│      - AMD GPU 全局内存原子操作延迟较高                      │
│      - 考虑使用 LDS 做局部规约再全局原子                     │
│                                                               │
│  [ ] 10. 计时 API 转换                                       │
│      - cudaEvent → hipEvent                                  │
│                                                               │
│  [ ] 11. 测试覆盖                                            │
│      - 数值精度对比 (FP16/BF16 可能有差异)                   │
│      - 边界条件测试                                          │
│      - 大规模并发测试                                        │
└──────────────────────────────────────────────────────────────┘
```

### ### 工具辅助检查

```bash
# HIP 静态检查工具
hipcc --check my_kernel.hip

# 等价于 CUDA 的:
# nvcc --dryrun my_kernel.cu

# 检查寄存器使用
hipcc -Rpass-analysis=kernel-resource-usage my_kernel.hip

# 输出示例:
# remark: my_kernel(float*, int): VGPR=72, SGPR=40, ScratchSize=0,
#         LDS=8192, Occupancy=8 wavefronts/CU
```

### ### 案例分析：Porting Flash Attention to HIP

Flash Attention 是 LLM 推理中最关键的内核之一，移植到 HIP 面临以下挑战：

```cpp
// ====== 原始 CUDA Flash Attention 核心循环 (简化版) ======
// 来自 Dao-AILab/flash-attention 的 CUDA kernel

// 线程块结构: (B_r, B_c) thread block with 128-256 threads
// B_r = 128 (行分块), B_c = 128 (列分块)

#ifdef __CUDACC__  // NVIDIA 路径
__global__ void flash_attn_fwd_kernel(
    const float* __restrict__ Q,
    const float* __restrict__ K,
    const float* __restrict__ V,
    float* __restrict__ O,
    const int seqlen, const int d_head)
{
    // Shared memory 布局:
    // Q_tile[Br][d] (128 × 128 × 4B = 64KB)
    // K_tile[Bc][d]
    // V_tile[d][Bc]
    extern __shared__ float smem[];
    float* Q_tile = smem;
    float* K_tile = Q_tile + Br * d_head;
    float* V_tile = K_tile + Bc * d_head;

    // 1. 加载 Q tile (coalesced)
    const int tid = threadIdx.x;
    const int row = blockIdx.x * Br;
    for (int i = tid; i < Br * d_head; i += blockDim.x) {
        Q_tile[i] = Q[(row + i / d_head) * d_head + (i % d_head)];
    }
    __syncthreads();

    // 2. Online softmax 状态 (per-thread)
    float m_i = -INFINITY;  // running max
    float l_i = 0.0f;       // running sum exp
    float acc[Br] = {0};    // 累加器 → 每个线程负责 part of Br

    // 3. 主循环: 遍历 K/V 块
    for (int block = 0; block < seqlen / Bc; block++) {
        // 3a. 加载 K, V tile (coalesced)
        __syncthreads();
        for (int i = tid; i < Bc * d_head; i += blockDim.x) {
            K_tile[i] = K[(block * Bc + i / d_head) * d_head + (i % d_head)];
        }
        for (int i = tid; i < Bc * d_head; i += blockDim.x) {
            V_tile[i] = V[(block * Bc + i / d_head) * d_head + (i % d_head)];
        }
        __syncthreads();

        // 3b. S = QK^T → 矩阵乘法
        float S[Br] = {0};
        for (int j = 0; j < d_head; j++) {
            for (int i = 0; i < Br; i++) {
                S[i] += Q_tile[i * d_head + j] * K_tile[j * Bc + ...];
            }
        }

        // 3c. Softmax: m_new = max(m_old, rowmax(S))
        //     P = exp(S - m_new)
        //     l_new = exp(m_old - m_new) * l_old + rowsum(P)
        float m_new = m_i;
        for (int i = 0; i < Br; i++) {
            m_new = fmaxf(m_new, ...);
        }
        // ... (softmax logic)

        // 3d. O += PV
        for (int i = 0; i < Br; i++) {
            for (int j = 0; j < d_head; j++) {
                acc[i * d_head + j] += P[i] * V_tile[??? * Bc + j];
            }
        }
    }

    // 4. 写回
    __syncthreads();
    // ... write O tile ...
}
#endif  // __CUDACC__
```

移植到 HIP 时的关键修改点：

```cpp
#ifdef __HIPCC__  // AMD HIP 路径

// 问题 1: warpSize=64, 共享内存 bank 冲突模式改变
// 共享内存布局需要调整 padding
// K_tile 在 Bc=128 时, 每行 128 个 float = 512B, 正好整除 128B (32 banks × 4B)
// 可能导致 strided access bank conflict, 加入 1 个 padding
#define SMEM_PAD 1
// 实际分配: Q_tile[Br * (d_head + SMEM_PAD)]
// 这样可以打破规则的行列对应关系

// 问题 2: warp-level reduction 需要适配 64-thread
// 原 CUDA 版本:
//   for (int offset = 16; offset > 0; offset /= 2) { ... }
// HIP 版本:
//   for (int offset = warpSize / 2; offset > 0; offset /= 2) { ... }

// 问题 3: 在 AMD 上可能需要调大线程块尺寸以更好利用 wavefront
// CUDA 通常用 128 或 256 线程的 block
// AMD 上考虑: 128 threads = 2 wavefronts, 256 threads = 4 wavefronts
// 推荐使用 256 (4 wavefronts) 更好地隐藏延迟

// 问题 4: 寄存器压力
// 如果 VGPR 使用超过 128, 使用 launch bounds 提示编译器:
__global__ void __launch_bounds__(256, 4)  // 256 threads, min 4 waves/CU
flash_attn_fwd_hip_kernel(...) {
    // ... kernel 体
}

// 问题 5: 全局内存原子操作较慢
// 原来的 kernel 如果使用了 global atomicAdd,
// 改为先在 LDS 中做 block-level reduction, 再写回全局内存

#endif  // __HIPCC__
```

### ### 性能差距及原因分析

Flash Attention 在 A100 vs MI250X 上的性能对比：

| 配置 | A100 (80GB) | MI250X (1 GCD) | 差距 | 主要原因 |
|------|-------------|-----------------|------|----------|
| FA fwd (seq=1024, d=64) | ~120 TFLOPS | ~85 TFLOPS | -29% | 寄存器压力, VGPR溢出 |
| FA fwd (seq=2048, d=64) | ~130 TFLOPS | ~95 TFLOPS | -27% | 类似 |
| FA fwd (seq=4096, d=64) | ~135 TFLOPS | ~100 TFLOPS | -26% | Matrix Core利用率低 |
| FA bwd (seq=1024, d=64) | ~110 TFLOPS | ~70 TFLOPS | -36% | 原子操作/规约开销更大 |

差距来源总结：
1. **VGPR 溢出** -- AMD 编译器可能将溢出的 VGPR 写入 "scratch" (显存), 造成极大延迟
2. **Matrix Core 利用率** -- 软硬件配合优化不如 NVIDIA 积累深厚
3. **原子操作延迟** -- AMD GPU 全局内存原子操作延迟通常是 NVIDIA 的 2-3 倍
4. **RCCL 通信** -- 多 GCD 间通信效率不如 NVLink
5. **编译器优化成熟度** -- AMDGPU LLVM 后端优化不如 NVCC 积累深厚

---

## ## Performance Portability (性能可移植性)

### ### 宏驱动的跨平台抽象

```cpp
// ====== portable_gpu_common.h ======
#pragma once

// ---------- 平台检测 ----------
#if defined(__HIPCC__) || defined(__HIP_PLATFORM_AMD__)
    #define GPU_PLATFORM_AMD 1
    #define GPU_PLATFORM_NAME "AMD/HIP"
#elif defined(__CUDACC__)
    #define GPU_PLATFORM_NVIDIA 1
    #define GPU_PLATFORM_NAME "NVIDIA/CUDA"
#else
    #error "Unsupported GPU platform"
#endif

// ---------- Warp/Wavefront 抽象 ----------
#if GPU_PLATFORM_AMD
    #define GPU_WARP_SIZE 64
    #define GPU_WARP_FULL_MASK 0xFFFFFFFFFFFFFFFFULL
#else
    #define GPU_WARP_SIZE 32
    #define GPU_WARP_FULL_MASK 0xFFFFFFFF
#endif

// ---------- 线程索引抽象 ----------
#define GPU_LANE_ID   (threadIdx.x % GPU_WARP_SIZE)
#define GPU_WARP_ID   (threadIdx.x / GPU_WARP_SIZE)

// ---------- Shuffle 操作抽象 ----------
template<typename T>
__device__ inline T gpu_shfl_xor(T val, int lane_mask) {
#if GPU_PLATFORM_AMD
    return __shfl_xor(val, lane_mask);
#else
    return __shfl_xor_sync(GPU_WARP_FULL_MASK, val, lane_mask);
#endif
}

template<typename T>
__device__ inline T gpu_shfl_down(T val, int delta) {
#if GPU_PLATFORM_AMD
    return __shfl_down(val, delta);
#else
    return __shfl_down_sync(GPU_WARP_FULL_MASK, val, delta);
#endif
}

// ---------- 同步抽象 ----------
#define GPU_SYNC_WARP()   __syncwarp()
#define GPU_SYNC_BLOCK()  __syncthreads()

// ---------- 缓存提示 (HIPT 无等价物时使用 NOP) ----------
#if GPU_PLATFORM_AMD
    #define GPU_PREFETCH_L1(ptr)
    #define GPU_PREFETCH_GLBL(ptr)
#else
    #define GPU_PREFETCH_L1(ptr)   __prefetch(ptr)
    #define GPU_PREFETCH_GLBL(ptr)  __prefetch_global(ptr)
#endif
```

### ### 统一的 Warp Reduce 实现

```cpp
// ====== portable_warp_reduce.h ======
// 同时支持 CUDA (warp=32) 和 HIP (wavefront=64)

template<typename T, int WARP_SZ = GPU_WARP_SIZE>
struct WarpReduce {
    // 编译期确保 WARP_SZ 是 2 的幂
    static_assert((WARP_SZ & (WARP_SZ - 1)) == 0, "WARP_SZ must be power of 2");

    // 求和规约
    __device__ static T Sum(T val) {
        #pragma unroll
        for (int offset = WARP_SZ / 2; offset > 0; offset >>= 1) {
            val += gpu_shfl_xor(val, offset);
        }
        return val;  // lane 0 得到全 warp/wavefront 的和
    }

    // 最大值规约
    __device__ static T Max(T val) {
        #pragma unroll
        for (int offset = WARP_SZ / 2; offset > 0; offset >>= 1) {
            T other = gpu_shfl_xor(val, offset);
            val = (val > other) ? val : other;
        }
        return val;
    }

    // 按 lane 广播 (将 src_lane 的值广播到所有 lane)
    __device__ static T Broadcast(T val, int src_lane) {
#if GPU_PLATFORM_AMD
        return __shfl(val, src_lane);
#else
        return __shfl_sync(GPU_WARP_FULL_MASK, val, src_lane);
#endif
    }
};

// ====== Block-level Reduce (基于 warp reduce) ======
template<typename T, int BLOCK_SIZE>
__device__ T block_reduce_sum(T val, T* shared_mem) {
    int lane = GPU_LANE_ID;
    int warp = GPU_WARP_ID;
    int num_warps = BLOCK_SIZE / GPU_WARP_SIZE;

    // Step 1: Warp-level reduce
    val = WarpReduce<T>::Sum(val);

    // Step 2: 每个 warp 的第 0 号 lane 写入 shared memory
    if (lane == 0) {
        shared_mem[warp] = val;
    }
    __syncthreads();

    // Step 3: 第一个 warp 从 shared memory 读取并做最终规约
    val = (threadIdx.x < num_warps) ? shared_mem[lane] : T(0);
    if (warp == 0) {
        val = WarpReduce<T>::Sum(val);
    }
    __syncthreads();

    // Step 4: 广播结果到所有线程
    return shared_mem[0];
}
```

### ### 其他跨平台方案

```
┌─────────────────────────────────────────────────────────────┐
│              跨平台 GPU 编程方案对比                          │
├─────────────┬──────────────┬──────────────┬─────────────────┤
│   方案       │  支持平台     │  成熟度       │  性能          │
├─────────────┼──────────────┼──────────────┼─────────────────┤
│ HIP         │ AMD, NVIDIA  │  中 (AMD 主推)│ 接近原生        │
│ Kokkos      │ NVIDIA, AMD, │  高           │ 接近原生        │
│             │ Intel, ARM   │              │                 │
│ RAJA        │ 同上         │  高 (美 DOE)  │ 接近原生        │
│ SYCL/DPC++  │ NVIDIA, AMD, │  中-高        │ 良好 (有开销)   │
│             │ Intel, FPGA  │              │                 │
│ OpenMP      │ 几乎所有      │  中           │ 一般 (优化难度大)│
│ OpenCL      │ 几乎所有      │  低 (不再活跃)│ 一般            │
│ Triton      │ NVIDIA, AMD  │  中-高        │ 良好            │
└─────────────┴──────────────┴──────────────┴─────────────────┘
```

#### Kokkos 示例

```cpp
#include <Kokkos_Core.hpp>

// Kokkos 自动适配不同后端的执行空间
using ExecSpace = Kokkos::DefaultExecutionSpace;
using TeamPolicy = Kokkos::TeamPolicy<ExecSpace>;
using TeamMember = typename TeamPolicy::member_type;

// 跨平台的 team-level reduction
Kokkos::parallel_for("my_kernel", TeamPolicy(N_teams, TEAM_SIZE),
    KOKKOS_LAMBDA(const TeamMember& team) {
        float val = /* ... */;

        // 自动使用 warp-level reduction (NVIDIA)
        // 或 wavefront-level reduction (AMD)
        float team_sum;
        Kokkos::parallel_reduce(
            Kokkos::TeamThreadRange(team, N),
            [&](int i, float& lsum) { lsum += data[i]; },
            team_sum
        );
    });
```

#### SYCL 示例

```cpp
#include <sycl/sycl.hpp>

// SYCL 可以运行在 NVIDIA (通过 CUDA backend)、AMD (通过 HIP backend)
// 和 Intel GPU 上。

sycl::queue q(sycl::gpu_selector_v);

q.submit([&](sycl::handler& h) {
    sycl::local_accessor<float, 1> smem(sycl::range<1>(256), h);

    h.parallel_for(
        sycl::nd_range<1>(N, 256),
        [=](sycl::nd_item<1> item) {
            auto sg = item.get_sub_group();  // 自动适配 warp/wavefront
            float val = data[item.get_global_id()];

            // Subgroup (warp/wavefront) shuffle
            for (int off = sg.get_max_local_range()[0] / 2; off > 0; off >>= 1) {
                val += sycl::shift_group_left(sg, val, off);
            }
        });
});
```

---

## ## ROCm Stack 深度剖析

### ### 全栈层次图

```
┌──────────────────────────────────────────────────────────────────┐
│                      ROCm 全栈架构                                │
├──────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  Layer 5: 应用层                                              │ │
│  │  PyTorch / TensorFlow / JAX / ONNX Runtime / ...             │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │  Layer 4: 框架后端                                            │ │
│  │  torch._C (ROCm 编译) / TF XLA / ...                          │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │  Layer 3: 优化库                                              │ │
│  │  MIOpen / rocBLAS / RCCL / rocFFT / rocSOLVER / hipCUB        │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │  Layer 2: HIP Runtime (用户态)                                │ │
│  │  libhiprt.so  —  hipMalloc / hipMemcpy / hipLaunchKernelGGL  │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │  Layer 1: ROCt (HSA Runtime — 用户态)                         │ │
│  │  libhsa-runtime64.so —  设备发现/内存管理/内核调度             │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │  Layer 0: ROCk (Kernel Driver — 内核态)                       │ │
│  │  amdgpu.ko —  GPU 内核驱动 / 硬件访问 / 中断 / DMA            │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │  硬件: AMD GPU / DCU                                          │ │
│  │  MI50 / MI100 / MI250X / MI300X / 海光 DCU                    │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  配套工具层                                                    │ │
│  │  rocprof (profiler)  |  rocgdb (debugger)                     │ │
│  │  rocminfo (device info) | rocm-smi (monitoring)                │ │
│  │  roc-obj-ls (code object) | roc-obj-extract (extract)         │ │
│  │  ROCm Validation Suite (RVS) - 测试与验证                    │ │
│  └─────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

### ### ROCm 安装

```bash
# ===== Ubuntu 22.04 + ROCm 6.x 安装 =====

# 1. 添加 AMD ROCm 仓库
wget -q https://repo.radeon.com/rocm/rocm.gpg.key -O - | \
    sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/rocm.gpg
echo "deb [arch=amd64] https://repo.radeon.com/rocm/apt/6.0.2/ubuntu jammy main" | \
    sudo tee /etc/apt/sources.list.d/rocm.list

# 2. 安装
sudo apt update
sudo apt install rocm-hip-sdk rocm-hip-libraries

# 3. 添加用户到 render 和 video 组
sudo usermod -a -G render,video $USER

# 4. 验证安装
/opt/rocm/bin/rocminfo       # 查看 GPU 信息
/opt/rocm/bin/rocm-smi       # 查看 GPU 状态 (类似 nvidia-smi)

# 5. 配置环境变量
echo 'export ROCM_PATH=/opt/rocm' >> ~/.bashrc
echo 'export HIP_PATH=/opt/rocm/hip' >> ~/.bashrc
echo 'export PATH=$PATH:/opt/rocm/bin' >> ~/.bashrc
source ~/.bashrc
```

### ### 工具链对照表

```
┌─────────────────────────┬───────────────────────────────┐
│        CUDA 工具         │        ROCm 等价工具           │
├─────────────────────────┼───────────────────────────────┤
│ nvidia-smi              │ rocm-smi                      │
│ nvcc                    │ hipcc                         │
│ nvprof                  │ rocprof                       │
│ ncu (Nsight Compute)    │ rocprof --hip-trace           │
│ nsys (Nsight Systems)   │ rocprof --sys-trace           │
│ cuda-gdb                │ rocgdb                        │
│ compute-sanitizer       │ rocm-validation-suite (RVS)  │
│ cuobjdump               │ roc-obj-ls / llvm-objdump    │
│ cuda-memcheck            │ RVS memory test               │
│ GPU assert (printf)      │ GPU assert (works in ROCm)    │
│ ptxas                   │ llvm-mc (AMDGPU assembler)    │
└─────────────────────────┴───────────────────────────────┘
```

#### rocprof 使用示例

```bash
# 基础 profiling
rocprof --hip-trace ./my_app

# 指定收集的 metrics
rocprof --list-basic        # 列出可用 metric
rocprof -i metrics.txt ./my_app   # metrics.txt 中每行一个 metric

# 输出 performance counters
rocprof --timestamp on -d output_dir ./my_app

# 分析 kernel 级别的性能
rocprof --stats ./my_app
```

#### rocminfo 输出解读

```bash
$ rocminfo
# 输出示例:
Agent 1:
  Name:         AMD Instinct MI250X
  Uuid:         GPU-1234567890ABCDEF
  Marketing Name: AMD Instinct MI250X
  Vendor Name:  AMD
  Wavefront Size: 64                    ← 关键参数
  Max Workgroup Size: 1024
  Max Threads Per CU: 2048
  Max Waves Per CU: 32
  LDS Size: 65536 (64 KB)              ← LDS 大小
  VGPR 总数: 65536                      ← 向量寄存器
  SGPR 总数: 3200                       ← 标量寄存器
  Matrix Core: YES                      ← 是否有矩阵核心
  Memory:
    Size:  68619436032 (64 GB)
    Type:  HBM
    Max Clock: 1700 MHz
    Max Bandwidth: 1638 GB/s
```

---

## ## PyTorch ROCm 支持

### ### 安装方式

```bash
# ===== 方式 1: 官方 pip wheel =====
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/rocm6.0

# ===== 方式 2: Docker 镜像 =====
docker pull rocm/pytorch:rocm6.0_ubuntu22.04_py3.10_pytorch_2.1.2
docker run -it --device=/dev/kfd --device=/dev/dri \
    --group-add=video --group-add=render \
    rocm/pytorch:rocm6.0_ubuntu22.04_py3.10_pytorch_2.1.2

# ===== 验证安装 =====
python -c "
import torch
print(f'PyTorch version: {torch.__version__}')
print(f'ROCm version: {torch.version.hip}')
print(f'GPU available: {torch.cuda.is_available()}')
print(f'GPU count: {torch.cuda.device_count()}')
print(f'GPU name: {torch.cuda.get_device_name(0)}')
"
# 预期输出:
# PyTorch version: 2.1.2+rocm6.0
# ROCm version: 6.0.32830-...
# GPU available: True
# GPU count: 1
# GPU name: AMD Instinct MI250X
```

### ### .cuda() 对 ROCm 的兼容性

PyTorch ROCm 的关键设计：`torch.cuda` 模块自动映射到 HIP，用户代码几乎不需要修改。

```python
import torch

# ROCm 上: torch.cuda 自动映射为 HIP
# 以下代码在 CUDA 和 ROCm 上都可以直接运行!
device = torch.device('cuda')  # 等价于 torch.device('hip')
# 注意: torch.device('hip') 也有效，但 'cuda' 更通用

# 张量操作 (完全兼容)
x = torch.randn(1024, 1024, device='cuda')
y = torch.randn(1024, 1024, device='cuda')
z = torch.matmul(x, y)  # 使用 rocBLAS 后端

# 神经网络 (完全兼容)
model = torch.nn.Linear(1024, 512).cuda()
output = model(x)

# 自定义 CUDA Extension → 需要适配 HIP
# 见下文
```

### ### PyTorch ROCm 的限制

1. **算子覆盖**: 部分 CUDA kernel 没有 HIP 实现（某些 fused op、新特性）
2. **性能差距**: 部分 kernel 在 AMD GPU 上未经同等优化
3. **Flash Attention**: 需要从 AMD fork 安装或使用 Triton 版本
4. **量化**: AWQ/GPTQ 支持较晚且不完善
5. **torch.compile**: Inductor 后端对 AMD GPU 支持仍在开发中

```python
# 检查算子是否可用
import torch

# Flash Attention (可能需要额外安装)
try:
    from flash_attn import flash_attn_func
    print("flash-attn available (likely AMD fork)")
except ImportError:
    print("flash-attn NOT available")

# 混合精度训练
scaler = torch.cuda.amp.GradScaler()  # ROCm 上可以使用
with torch.cuda.amp.autocast(dtype=torch.float16):
    output = model(x)
# 注意: BF16 在某些 AMD GPU 上性能不如 A100

# 检查算子是否可用:
print(torch.cuda.is_bf16_supported())  # True on MI250X+
```

### ### 源码编译 PyTorch for ROCm

```bash
# 1. 安装依赖
sudo apt install -y cmake ninja-build python3-dev

# 2. 克隆 PyTorch
git clone --recursive https://github.com/pytorch/pytorch
cd pytorch
git checkout v2.1.2  # 选择特定版本

# 3. 设置环境变量
export PYTORCH_ROCM_ARCH=gfx90a       # MI250X
# export PYTORCH_ROCM_ARCH=gfx908     # MI100
# export PYTORCH_ROCM_ARCH=gfx942     # MI300X
export ROCM_PATH=/opt/rocm
export USE_ROCM=1
export USE_CUDA=0

# 4. 编译 (仅 Python 绑定)
python setup.py develop

# 5. 指定 MIOPEN 的卷积算法搜索策略
# 环境变量优化:
export MIOPEN_FIND_MODE=1          # 第一次运行搜索最优算法
export MIOPEN_DEBUG_FIND_ONLY_SOLVER=0
```

---

## ## vLLM on AMD GPUs

### ### vLLM ROCm 支持现状

```
┌─────────────────────────────────────────────────────────────┐
│          vLLM ROCm 支持架构                                   │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌────────────────────────────────────────────────────────┐  │
│  │             vLLM Python 层                               │  │
│  │  LLM Engine / AsyncLLMEngine / Scheduler                │  │
│  └────────────────────────┬───────────────────────────────┘  │
│                           │                                    │
│  ┌────────────────────────▼───────────────────────────────┐  │
│  │          vLLM CUDA/HIP Kernel 层                         │  │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐    │  │
│  │  │PagedAttention│ │  Activation  │ │   RMS Norm   │    │  │
│  │  │   Kernel     │ │   Kernels    │ │   Kernels    │    │  │
│  │  │              │ │              │ │              │    │  │
│  │  │ .cu / .hip  │ │ .cu / .hip  │ │ .cu / .hip  │    │  │
│  │  └──────────────┘ └──────────────┘ └──────────────┘    │  │
│  └────────────────────────┬───────────────────────────────┘  │
│                           │                                    │
│  ┌────────────────────────▼───────────────────────────────┐  │
│  │         PyTorch + 第三方库                                │  │
│  │  torch (ROCm) / MIOpen / rocBLAS / RCCL                  │  │
│  └─────────────────────────────────────────────────────────┘  │
│                           │                                    │
│  ┌────────────────────────▼───────────────────────────────┐  │
│  │              AMD GPU 硬件                                 │  │
│  └─────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### ### PagedAttention HIP 实现关键点

PagedAttention 是 vLLM 的核心创新——实现 KV Cache 的分页管理，使显存利用率大幅提升。

```cpp
// PagedAttention 的 HIP 实现关键差异 (简化版)

// CUDA 版本使用 thread block tile 技术:
// - 每个 thread block 处理一个 query token
// - 32 个线程协作处理 (1 warp = 32)
// - KV Cache 按 block 加载到 shared memory

// HIP 版本需要适配:
// - wavefront size = 64, 调大 tile 或改变分块策略
// - 使用更多的 shared memory padding 来避免 LDS bank conflict

#ifdef __HIPCC__
// 针对 AMD GPU 优化的 PagedAttention
template<int HEAD_SIZE, int BLOCK_SIZE>
__global__ void paged_attention_hip_kernel(
    float* __restrict__ out,           // [num_seqs, num_heads, head_size]
    const float* __restrict__ q,       // [num_seqs, num_heads, head_size]
    const float* __restrict__ k_cache, // [num_blocks, num_kv_heads, head_size/x, block_size, x]
    const float* __restrict__ v_cache, // [num_blocks, num_kv_heads, head_size, block_size]
    const int* __restrict__ block_tables, // [num_seqs, max_blocks_per_seq]
    const int* __restrict__ context_lens,
    const float scale,
    const int max_context_len
) {
    const int seq_id = blockIdx.x;
    const int head_id = blockIdx.y;
    const int thread_id = threadIdx.x;

    // 使用更多 shared memory padding 避免 LDS bank conflict
    constexpr int PAD = 1;  // 额外 padding (NVIDIA 上可能不需要)
    __shared__ float q_smem[HEAD_SIZE + PAD];
    __shared__ float k_smem[BLOCK_SIZE * HEAD_SIZE + PAD];

    // 加载 query (所有线程协作)
    for (int i = thread_id; i < HEAD_SIZE; i += blockDim.x) {
        q_smem[i] = q[seq_id * num_heads * HEAD_SIZE + head_id * HEAD_SIZE + i];
    }
    __syncthreads();

    // 主循环
    float acc = 0.0f;
    const int context_len = context_lens[seq_id];
    const int num_kv_blocks = (context_len + BLOCK_SIZE - 1) / BLOCK_SIZE;

    for (int block_idx = 0; block_idx < num_kv_blocks; block_idx++) {
        const int physical_block = block_tables[seq_id * max_blocks_per_seq + block_idx];

        // 加载 K tile
        for (int i = thread_id; i < BLOCK_SIZE * HEAD_SIZE; i += blockDim.x) {
            k_smem[i] = k_cache[physical_block * kv_stride + i];
        }
        __syncthreads();

        // 计算 QK^T dot product → 注意 AMD 上的多 warp 协作
        float qk = 0.0f;
        for (int i = thread_id % GPU_WARP_SIZE; i < HEAD_SIZE; i += GPU_WARP_SIZE) {
            qk += q_smem[i] * k_smem[thread_id / GPU_WARP_SIZE * HEAD_SIZE + i];
        }

        // Warp/Wavefront-level reduction
        #pragma unroll
        for (int offset = GPU_WARP_SIZE / 2; offset > 0; offset >>= 1) {
            qk += __shfl_xor(qk, offset);
        }

        // Softmax + V 乘积 ... (省略)
    }

    // 写回 (省略)
}
#endif  // __HIPCC__
```

### ### vLLM 在 A100 和 MI250X 上的性能对比

```
测试配置:
  - 模型: LLaMA-2 7B, 13B, 70B
  - 数据集: ShareGPT (平均 input ~200 tokens, output ~200 tokens)
  - 并发请求: 1, 2, 4, 8, 16, 32, 64, 128
  - Batch: Continuous batching (vLLM 默认)

                     A100 (80GB)    MI250X (1 GCD)   差距
  ──────────────────────────────────────────────────────
  LLaMA-2 7B
    Throughput (tok/s)   ~2500          ~1800          -28%
    TTFT (P50, ms)        ~120           ~155          -29%
    TPOT (P50, ms)         ~42            ~55          -31%

  LLaMA-2 13B
    Throughput (tok/s)   ~1400          ~1000          -29%
    TTFT (P50, ms)        ~210           ~280          -33%
    TPOT (P50, ms)         ~75           ~100          -33%

  LLaMA-2 70B
    Throughput (tok/s)    ~350           ~250          -29%
    TTFT (P50, ms)        ~850          ~1200          -41%
    TPOT (P50, ms)        ~300           ~420          -40%
```

### ### vLLM on ROCm 的已知限制

1. **Flash Attention 集成**: 上游 vLLM 的 Flash Attention 依赖 NVIDIA CUDA kernel，ROCm 上需要使用 Triton 版本或 AMD fork

2. **量化支持**:
   - AWQ: 需要 AMD fork 的 AutoAWQ
   - GPTQ: 需要 ROCm 优化的 GPTQ-for-LLaMA
   - FP8: MI300X 初步支持，MI250X 不支持

3. **Tensor Parallelism**: RCCL 通信效率不如 NCCL + NVLink，大模型 TP 扩展效率可能下降

4. **PagedAttention 性能**: 原版 PagedAttention 在 CUDA 上有深度优化，HIP 版本可能存在性能差距

### ### 部署 vLLM on ROCm

```bash
# ===== 步骤 1: 安装 ROCm 版 vLLM =====
pip install vllm  # 从 PyPI 安装 (自动检测 ROCm)
# 或从源码编译:
git clone https://github.com/vllm-project/vllm.git
cd vllm
pip install -e .

# ===== 步骤 2: 启动 vLLM 服务 =====
# 注意: 需要设置环境变量确保正确使用 ROCm
export HSA_OVERRIDE_GFX_VERSION=9.0.10  # MI250X
# export HSA_OVERRIDE_GFX_VERSION=9.4.2  # MI300X

python -m vllm.entrypoints.openai.api_server \
    --model /path/to/Llama-2-7b-hf \
    --dtype float16 \
    --max-model-len 4096 \
    --gpu-memory-utilization 0.90 \
    --tensor-parallel-size 1 \
    --port 8000

# ===== 步骤 3: 测试 =====
curl http://localhost:8000/v1/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "/path/to/Llama-2-7b-hf",
        "prompt": "What is deep learning?",
        "max_tokens": 100,
        "temperature": 0.0
    }'

# ===== 步骤 4: 查看显存使用 =====
watch -n 1 rocm-smi
# 对比 watch -n 1 nvidia-smi (在 NVIDIA 机器上)
```

---

## ## 曙光平台 DCU 实践

### ### 曙光平台概述

曙光 (Sugon) 是中国最大的高性能计算厂商之一，与海光深度绑定，提供基于 DCU 的 AI 计算平台。

```
┌──────────────────────────────────────────────────────────────┐
│              曙光 DCU AI 平台架构                              │
├──────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │                    应用层                                 │ │
│  │  ├── AI 训练: PyTorch (ROCm) / TensorFlow (ROCm)         │ │
│  │  ├── AI 推理: vLLM / TensorRT-LLM (via deployment kit)  │ │
│  │  └── HPC:   LAMMPS / VASP / GROMACS (ROCm 端口)         │ │
│  └────────────────────┬─────────────────────────────────────┘ │
│                       │                                        │
│  ┌────────────────────▼─────────────────────────────────────┐ │
│  │               曙光 DCU 软件栈                              │ │
│  │  ├── DTP (DCU Tool Platform)     性能分析/调试            │ │
│  │  ├── DPR (DCU Performance Report) 性能报告                │ │
│  │  ├── DOCK (DCU Operations Kit)    运维工具包              │ │
│  │  └── ROCm 基础栈 (HIP / rocBLAS / MIOpen / ...)         │ │
│  └────────────────────┬─────────────────────────────────────┘ │
│                       │                                        │
│  ┌────────────────────▼─────────────────────────────────────┐ │
│  │            曙光服务器硬件层                                 │ │
│  │  ├── 曙光 X785 系列 GPU 服务器                            │ │
│  │  ├── 8× 海光 DCU / 节点                                    │ │
│  │  ├── Intel/海光 x86 CPU + 高速互联                        │ │
│  │  └── Infinity Fabric / PCIe 4.0 x16                       │ │
│  └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

### ### 部署 LLaMA-7B 推理 on DCU

```bash
# ===== 1. 环境准备 =====
# 确认 ROCm 已安装
rocm-smi --showproductname
rocminfo | grep "Marketing Name"

# 确认 PyTorch 可用
python -c "import torch; print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0))"

# ===== 2. 模型权重准备 =====
# 从 Hugging Face 下载 (如果可访问)
huggingface-cli download meta-llama/Llama-2-7b-hf --local-dir /data/models/Llama-2-7b-hf

# 或从内部镜像同步

# ===== 3. 安装 vLLM (ROCm 版) =====
pip install vllm

# ===== 4. 运行推理 =====
python -c "
from vllm import LLM, SamplingParams

# 模型加载
llm = LLM(
    model='/data/models/Llama-2-7b-hf',
    dtype='float16',
    max_model_len=2048,
    gpu_memory_utilization=0.90,
)

# 推理
prompts = ['上海是中国最大的城市，']
sampling_params = SamplingParams(temperature=0.0, max_tokens=100)
outputs = llm.generate(prompts, sampling_params)

for o in outputs:
    print(o.outputs[0].text)
"
```

### ### DCU 性能调优要点

```bash
# 1. 选择正确的 GPU 架构
# 编译时指定正确的 gfx 版本
hipcc --offload-arch=gfx90a my_kernel.cpp  # MI250X 系列 DCU

# 2. 监控显存带宽利用率
rocm-smi --showmemuse       # 显存使用
rocm-smi --showuse          # GPU 使用率
rocm-smi --showmeminfo vram # 显存详细信息

# 3. 使用 rocprof 查找瓶颈
rocprof --hip-trace --stats python my_inference.py
# 查看 kernel 执行时间和显存带宽

# 4. 最大化显存带宽利用
# - 使用大 batch size
# - 使用 float16/bf16 而非 float32
# - 合并小 kernel 为一个大 kernel (kernel fusion)

# 5. 多流重叠
# 使用多个 HIP Stream 重叠 compute 和 transfer
# 注意: DCU 硬件对多流的支持取决于具体型号
```

### ### 常见问题及解决

| 问题 | 现象 | 解决方案 |
|------|------|----------|
| **驱动兼容** | `hipErrorNoDevice` | 检查 kernel 和 ROCm 版本匹配 |
| **显存分配失败** | `hipErrorOutOfMemory` | 降低 `gpu_memory_utilization`，或者减小 batch size |
| **多卡通信失败** | RCCL 初始化超时 | 检查 Infinity Fabric/PCIe 拓扑，确保所有 GPU 可见 |
| **性能远低于预期** | 同 batch 吞吐仅为预期的 50% | 用 rocprof 检查是否有 VGPR 溢出/GDS 未命中 |
| **HSA_OVERRIDE_GFX_VERSION** | 应用报告不支持的 GPU | 设置正确版本，如 `9.0.10` |
| **MIOpen 找不到算法** | 卷积操作失败 | 设置 `MIOPEN_FIND_MODE=1` 让 MIOpen 搜索 |

### ### DCU 专用工具链

```bash
# DTP (DCU Tool Platform) — 类似 Nsight Systems 的集成分析工具
# 功能:
#   - Timeline profiling (kernel 执行时序)
#   - Memory usage 追踪
#   - 多卡通信分析
dtp --timeline python train.py
dtp --memory python train.py
dtp --network python train.py

# DPR (DCU Performance Report) — 性能报告生成
dpr --input rocprof_output --format html > report.html
# 报告内容包括:
#   - 每个 kernel 的耗时占比
#   - 显存带宽利用率
#   - 占用率估计
#   - 热点 kernel 的源代码级分析
```

---

## ## 与 AI Infra 的关联

### ### 国产硬件在 AI 基础设施中的战略地位

```
┌──────────────────────────────────────────────────────────────┐
│          国产 AI 硬件在基础设施中的角色                         │
├──────────────────────────────────────────────────────────────┤
│                                                                │
│   ┌────────────┐     ┌────────────┐     ┌────────────┐       │
│   │  训练集群   │     │  推理集群   │     │  开发/测试  │       │
│   │            │     │            │     │            │       │
│   │  (高算力)  │     │ (高吞吐/   │     │  (灵活/   │       │
│   │            │     │  低延迟)   │     │  低成本)   │       │
│   └─────┬──────┘     └─────┬──────┘     └─────┬──────┘       │
│         │                  │                  │               │
│   ┌─────▼──────────────────▼──────────────────▼──────┐       │
│   │                                                    │       │
│   │  国产替代路径:                                      │       │
│   │                                                    │       │
│   │  阶段 1: 推理先行                                   │       │
│   │    -> 昇腾/DCU 替代 A100 做推理服务                 │       │
│   │    -> 优势: 推理对通信要求相对低, 生态依赖弱        │       │
│   │                                                    │       │
│   │  阶段 2: 小模型训练                                 │       │
│   │    -> < 13B 模型可在 8×DCU 节点上训练               │       │
│   │    -> 需要适配 FSDP/DeepSpeed                        │       │
│   │                                                    │       │
│   │  阶段 3: 大规模训练                                 │       │
│   │    -> 千卡集群训练 70B+ 模型                        │       │
│   │    -> 挑战最大: 需要集群级软件栈成熟                 │       │
│   │                                                    │       │
│   └────────────────────────────────────────────────────┘       │
└──────────────────────────────────────────────────────────────┘
```

### ### 供应链独立性的意义

1. **降低外部依赖**: 在中美科技脱钩背景下，国产算力平台确保 AI 基础设施不会因出口管制而停滞
2. **成本可控**: 长期看，国产芯片单价通常低于进口同级别产品，大规模部署时成本优势明显
3. **定制化可能**: 可以根据国内 AI 厂商的需求定制硬件（算子加速、互联拓扑等）

### ### 国产化替代路径（国产化替代路径）

```
现有 CUDA 生态 → 国产平台迁移路线:

┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│ 阶段 1:      │    │ 阶段 2:      │    │ 阶段 3:      │
│ 工具链适配   │ -> │ 模型/框架    │ -> │ 大规模部署   │
│              │    │ 迁移          │    │              │
└──────────────┘    └──────────────┘    └──────────────┘

工具链适配:
  - hipify CUDA 代码到 HIP
  - 适配 ROCm/CANN/Neuware 依赖库
  - 验证数值精度一致性

模型/框架迁移:
  - PyTorch 模型切换到 ROCm 版 PyTorch
  - 训练脚本适配 (FSDP → 国产版 DeepSpeed)
  - 推理服务迁移 (vLLM/TRT-LLM → ROCm 兼容版)

大规模部署:
  - 多卡/多节点通信调试
  - 性能优化到 < 15% 差距
  - 稳定性压测
  - 生产上线
```

### ### 当前挑战

| 挑战 | 描述 | 影响程度 |
|------|------|----------|
| **生态成熟度** | 国产软件栈（CANN/Neuware）成熟度远不如 CUDA | 高 |
| **性能差距** | 同级别硬件在通用负载上通常有 15-35% 的差距 | 中-高 |
| **软件兼容性** | 第三方库（MMDetection/Transformers）的国产后端集成不完善 | 中 |
| **人才储备** | 熟悉 CUDA 的开发者多，熟悉 HIP/CANN 的少 | 中 |
| **社区活跃度** | 国产平台社区较小，问题解决速度慢 | 中 |
| **文档质量** | 国产软件栈的文档和教程不如 NVIDIA | 中-高 |
| **多框架支持** | 多数国产平台只支持 PyTorch，JAX/TF 支持有限 | 低-中 |

### ### 机遇

1. **自主可控**: 满足政府和关键行业的信创要求（安全可控）
2. **成本优势**: 大规模部署时，国产芯片的性价比通常更高
3. **定制能力**: 与国产芯片厂商合作可以针对特定负载做硬件级优化
4. **Specialized for AI**: 昇腾和寒武纪的原生 AI 架构在某些场景下可能超越通用 GPU
5. **政策支持**: 国产替代获得政策和资金支持，加速生态建设

---

## ## 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| HIP | 像"CUDA 的方言翻译器"一样，同一份代码编译后可在 NVIDIA/AMD GPU 上运行 | 本文 HIP 入门章节 |
| ROCm | 像"AMD 的 CUDA 生态"一样，提供与 CUDA 对等的 runtime、编译器、优化库 | 本文 ROCm 生态章节 |
| Wavefront | 像"AMD 版的 Warp（64人小队）"一样，比 NVIDIA 的 32 线程 Warp 多一倍 | 本文 Wavefront 章节 |
| LDS | 像"AMD 版 Shared Memory"一样，64KB/CU，32 banks | 本文 LDS 章节 |
| hipify | 像"CUDA→HIP 的自动翻译工具"一样，将 cudaMalloc 等 API 自动替换为 hipMalloc | 本文 hipify 章节 |

## A800 部署场景举例

**场景1：曙光 DCU 平台部署 vLLM + Qwen-33B 推理**

在曙光服务器（8×DCU）上部署 vLLM 推理服务：

```bash
# 1. 设置 GPU 架构伪装（DCU 基于 CDNA2，对应 gfx90a）
export HSA_OVERRIDE_GFX_VERSION=9.0.10

# 2. 安装 ROCm 版 vLLM
pip install vllm

# 3. 启动推理服务（单卡运行 Qwen-7B，或 TP=2 运行 Qwen-33B）
python -m vllm.entrypoints.openai.api_server \
    --model /models/Qwen2.5-7B-Instruct \
    --dtype float16 \
    --max-model-len 4096 \
    --gpu-memory-utilization 0.90 \
    --tensor-parallel-size 1

# 4. 验证：rocprof 分析 PagedAttention kernel 性能
rocprof --hip-trace --stats \
    python -c "
from vllm import LLM, SamplingParams
llm = LLM(model='/models/Qwen2.5-7B-Instruct')
llm.generate(['你好'], SamplingParams(max_tokens=50))
"
# 关注指标: VGPR 使用量、LDS bank conflict、显存带宽利用率
```

**场景2：CUDA 到 HIP 的 PagedAttention Kernel 移植检查清单**

将 vLLM 的 PagedAttention v2 kernel 从 CUDA 移植到 HIP 时，按本文移植检查清单逐项审计：

```cpp
// 关键差异适配（参考本文 Wavefront vs Warp 章节）
// 1. warpSize: 32 → 64，所有 warp-level reduction 需要适配
#ifdef __HIPCC__
    #define WARP_SIZE 64
#else
    #define WARP_SIZE 32
#endif

// 2. __shfl_sync(0xFFFFFFFF, val, offset) → __shfl(val, offset)
// 3. Shared Memory padding 调整以适配 DCU LDS 32-bank 架构
// 4. Matrix Core → rocWMMA API
```

移植后预期性能差距约 15-25%（DCU vs A800），主要来自 VGPR 压力和 Matrix Core 利用率差异（见本文移植案例分析）。

## 上下游串联

```
上游 ← 本文档 → 下游

上游：CUDA 生态与 vLLM 推理引擎
      vLLM 的核心 kernel（PagedAttention、量化等）最初以 CUDA 编写，
      本文档教你将这些 CUDA kernel 移植到 HIP，适配 ROCm 生态。

下游：国产 GPU 硬件（DCU / 昇腾 / 寒武纪）
      本文档覆盖的 HIP 是 DCU 的原生编程模型。理解 HIP 后，
      可进一步学习昇腾 CANN 和寒武纪 Neuware，打通全国产 AI 推理链路。

完整链路参考：end-to-end-inference-trace.md
  vLLM Scheduler → Worker → CUDA Kernel (原始) → hipify → HIP Kernel →
  ROCm Runtime → DCU GPU LDS/VGPR/Matrix Core → 推理结果
```

---
---
## 深入学习资源

### ### 官方文档

```
┌──────────────────────────────────────────────────────────────┐
│                  推荐学习资源路线图                             │
├──────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌─ Level 1: 基础 ────────────────────────────────────────┐  │
│  │  • HIP Programming Guide:                               │  │
│  │    https://rocm.docs.amd.com/projects/HIP/en/latest/    │  │
│  │  • HIP API Reference:                                   │  │
│  │    https://rocm.docs.amd.com/projects/HIP/en/latest/    │  │
│  │      reference/api.html                                 │  │
│  │  • ROCm Installation Guide:                             │  │
│  │    https://rocm.docs.amd.com/en/latest/deploy/linux/    │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                                │
│  ┌─ Level 2: 进阶 ────────────────────────────────────────┐  │
│  │  • AMD CDNA Architecture Whitepaper:                    │  │
│  │    https://www.amd.com/en/technologies/cdna.html        │  │
│  │  • "Porting CUDA to HIP" Best Practices Guide:          │  │
│  │    https://rocm.docs.amd.com/en/latest/how-to/          │  │
│  │      llm-fine-tuning-optimization/...                   │  │
│  │  • hipCUB Documentation:                                │  │
│  │    https://rocm.docs.amd.com/projects/hipCUB/en/latest/ │  │
│  │  • rocPRIM Documentation:                               │  │
│  │    https://rocm.docs.amd.com/projects/rocPRIM/en/latest/│  │
│  └────────────────────────────────────────────────────────┘  │
│                                                                │
│  ┌─ Level 3: 国产平台 ────────────────────────────────────┐  │
│  │  • 海光 DCU 开发者文档 (需从海光获取)                    │  │
│  │  • 曙光高性能计算平台文档 (需从曙光获取)                  │  │
│  │  • 昇腾 CANN 文档:                                       │  │
│  │    https://www.hiascend.com/document                    │  │
│  │  • 寒武纪 Cambricon Neuware 文档:                        │  │
│  │    https://www.cambricon.com/docs/                       │  │
│  │  • 昇腾 Ascend C 编程指南:                               │  │
│  │    https://www.hiascend.com/document/detail/zh/...      │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                                │
│  ┌─ Level 4: 实践项目 ────────────────────────────────────┐  │
│  │  • vLLM ROCm fork:                                      │  │
│  │    https://github.com/ROCm/vllm                         │  │
│  │  • Flash Attention ROCm:                                │  │
│  │    https://github.com/ROCm/flash-attention              │  │
│  │  • xformers ROCm fork:                                  │  │
│  │    https://github.com/ROCm/xformers                     │  │
│  │  • AMD Lab Notes (ROCm 开发博客):                       │  │
│  │    https://rocm.blogs.amd.com/                          │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

### ### 推荐论文与文章

- **HIP 设计哲学**: "HIP: A C++ Runtime API and Kernel Language" — AMD 官方概述
- **CDNA 架构**: "AMD Instinct MI250X Accelerator: Elevating Performance for HPC and AI" — HotChips 2021
- **PagedAttention**: "Efficient Memory Management for Large Language Model Serving with PagedAttention" — SOSP 2023 (vLLM 论文)
- **Flash Attention**: "FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness" — NeurIPS 2022
- **跨平台 GPU 编程**: "Performance Portability across Diverse Computer Architectures" — IEEE/ACM 2019
- **ROCm GPU 性能优化**: "Optimizing GPU Kernels for AMD Instinct Accelerators" — AMD ROCm Blog

### ### 实践建议

```
学习路线建议:

第 1 周: 环境搭建
  - 在 DCU/AMD GPU 上安装 ROCm
  - 运行 rocminfo, rocm-smi 熟悉硬件
  - 编写第一个 HIP "Hello World" kernel

第 2 周: HIP Runtime API
  - 将简单的 CUDA 程序 hipify 并运行
  - 理解 warp vs wavefront 差异
  - 手写 warp reduce / scan

第 3 周: 移植实践
  - 选择一个 500 行左右的 CUDA kernel 移植
  - 处理 shuffle / shared memory / 寄存器压力问题
  - 使用 rocprof 分析性能

第 4 周: 深度学习集成
  - 运行 PyTorch ROCm 版本的训练/推理
  - 部署 vLLM on ROCm
  - 编写自定义 PyTorch CUDA Extension 并适配 HIP

第 5-6 周: 深入优化
  - 学习 GCN ISA / 汇编优化
  - LDS bank conflict 分析
  - 多卡 RCCL 通信调优
```

---

> **结语**: DCU/HIP 编程是连接 CUDA 生态和国产算力平台的桥梁。虽然 HIP 在 API 层面与 CUDA 高度兼容，但深入理解 AMD GPU 架构的底层差异——wavefront 64 线程、双寄存器文件、Matrix Core 特性——是写出高性能 HIP kernel 的关键。随着国产 AI 基础设施的建设加速，掌握 HIP/CANN/Neuware 等跨平台编程技术将成为 AI Infra 工程师的核心竞争力。
