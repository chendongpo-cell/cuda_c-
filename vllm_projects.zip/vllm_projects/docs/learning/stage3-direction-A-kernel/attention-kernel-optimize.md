# Attention Kernel 深度优化指南

> 本文档从数学基础出发，逐层深入到工业级 Attention Kernel 的实现细节，涵盖 FlashAttention 1/2/3、PagedAttention、Triton 实现等核心技术，是理解 LLM 推理加速中 Attention 优化的完整指南。

---

## 1. 标准 Attention 背景

### 1.1 Scaled Dot-Product Attention 公式

Transformer 的核心操作是 Scaled Dot-Product Attention，其数学定义如下：

```
Attention(Q, K, V) = softmax(QK^T / √d_k) × V
```

其中：
- **Q** (Query): 形状为 `[batch, num_heads, seq_len, d_k]`，表示"我要找什么"
- **K** (Key): 形状为 `[batch, num_heads, seq_len, d_k]`，表示"我有什么标签"
- **V** (Value): 形状为 `[batch, num_heads, seq_len, d_v]`，表示"我有什么内容"
- **√d_k** 是缩放因子，防止内积值过大导致 softmax 梯度消失

对于单个 batch 和单个 attention head，计算过程如下：

```python
# 简化版：单个 head 的 attention 计算
def scaled_dot_product_attention(Q, K, V, scale=None):
    """
    Q, K, V: [seq_len, d_k] or [seq_len, d_v]
    返回: [seq_len, d_v]
    """
    d_k = Q.shape[-1]
    if scale is None:
        scale = d_k ** 0.5

    # Step 1: 计算注意力分数矩阵 S
    S = Q @ K.T / scale              # [seq_len, seq_len]

    # Step 2: Softmax 归一化
    P = torch.softmax(S, dim=-1)     # [seq_len, seq_len]

    # Step 3: 加权求和
    O = P @ V                         # [seq_len, d_v]

    return O
```

### 1.2 O(N²) 内存问题：存储完整注意力矩阵

上述标准实现会产生一个形状为 `[seq_len, seq_len]` 的中间矩阵 S 和 P。用 ASCII 图表示：

```
           K^T [d_k × N]
    ┌─────────────────────┐
    │                     │
 Q  │   S = Q × K^T       │  S 的形状: [N × N]
[N×d]│                     │
    │   每个元素 S[i,j]    │
    │   表示第 i 个 query  │
    │   对第 j 个 key 的   │
    │   注意力分数         │
    │                     │
    └─────────────────────┘

    内存占用: N² × sizeof(float16) = N² × 2 bytes
```

**具体内存估算**：

| 序列长度 N | 注意力矩阵大小 (fp16) | 说明 |
|-----------|---------------------|------|
| 1,024     | 2 MB                | 可接受 |
| 2,048     | 8 MB                | 可接受 |
| 4,096     | 32 MB               | 已有压力 |
| 8,192     | 128 MB              | 单 head 已很大 |
| 16,384    | 512 MB              | 严重瓶颈 |
| 32,768    | 2 GB                | 单 head 不可行 |
| 131,072   | 32 GB               | 完全不可能 |

对于 Llama-70B 的 64 个 attention heads 和 8K 序列长度：

```
总显存 = 64 heads × (8192² × 2 bytes) = 64 × 128 MB = 8 GB
```

仅是存储所有 head 的 attention 矩阵就需要 8GB 显存，而实际上推理过程中还需要存储 KV cache、模型权重等。这就是 Attention 的内存瓶颈。

### 1.3 内存带宽分析：每个 token 的数据搬运量

GPU 内存层次结构 (A100-80GB 为例)：

```
┌─────────────────────────────────────────────────────────┐
│                    HBM (80 GB)                           │
│              带宽: ~2 TB/s (2039 GB/s)                    │
│  ┌───────────────────────────────────────────────────┐  │
│  │              L2 Cache (40 MB)                      │  │
│  │           带宽: ~4 TB/s                             │  │
│  │  ┌─────────────────┐  ┌─────────────────┐         │  │
│  │  │  SM (108个)     │  │  SM (108个)     │         │  │
│  │  │  SRAM: 192 KB   │  │  SRAM: 192 KB   │  ...    │  │
│  │  │  ~19 TB/s       │  │  ~19 TB/s       │         │  │
│  │  └─────────────────┘  └─────────────────┘         │  │
│  └───────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

每个 A100 SM (Streaming Multiprocessor) 有 192KB SRAM，总 SRAM 约 20MB，带宽约 19TB/s。

**标准 Attention 的数据搬运**：

```
假设: N=2048, d=64, dtype=fp16

Q: 2048 × 64 × 2 = 256 KB
K: 2048 × 64 × 2 = 256 KB
V: 2048 × 64 × 2 = 256 KB

S = QK^T: 2048 × 2048 × 2 = 8 MB      ← 必须写入 HBM 再读回
P = softmax(S): 2048 × 2048 × 2 = 8 MB  ← 必须写入 HBM 再读回
O = PV: 2048 × 64 × 2 = 256 KB

HBM 总读写 ≈ 8 MB + 8 MB = 16 MB (仅大矩阵)
```

每步操作都需要从 HBM 读取数据、计算、再写回 HBM，S 和 P 这两个大矩阵成为了带宽瓶颈。

### 1.4 为什么 Attention 是 Memory-Bound 而非 Compute-Bound

对于大多数序列长度，Attention 是典型的 **memory-bound** 操作。

**计算量 (FLOPS) vs 数据搬运量 (Bytes) 分析**：

```
S = QK^T:     FLOPs = 2 × N × N × d     ≈ 2 × 2048² × 64  = 537M FLOPs
P = softmax(S): FLOPs = 3 × N × N        ≈ 3 × 2048²       = 12.6M FLOPs
O = PV:        FLOPs = 2 × N × N × d     ≈ 537M FLOPs
─────────────────────────────────────────────────────────────
总 FLOPs:      ≈ 1.09G FLOPs

总 HBM 读取/写入: (Q + K + V + S + P + O) × sizeof(fp16)
    = (256K + 256K + 256K + 8M + 8M + 256K) × 2
    ≈ 34 MB

算术强度 = FLOPs / Bytes = 1.09G / 34M ≈ 32 FLOPs/Byte
```

A100 的"屋脊" (Roofline)：

```
计算峰值: 312 TFLOPS (fp16 TC)
带宽峰值: 2039 GB/s

转折点 (ridge point) = 312T / 2039G ≈ 153 FLOPs/Byte
```

因为 32 < 153，所以标准 Attention **明确处于 memory-bound 区域**。这意味着优化的主要方向是减少数据搬运，而非减少计算量。

### 1.5 标准实现的三遍遍历

标准 Attention 的"三遍遍历"实现：

```
第一遍: 计算 S = QK^T / √d
        ┌─────────────────────────┐
        │ 读 Q → 写 S (到 HBM)     │  读取 Q, K / 写入 S (N²)
        └─────────────────────────┘

第二遍: 计算 P = softmax(S)
        ┌─────────────────────────┐
        │ 读 S → 写 P (到 HBM)     │  读取 S / 写入 P (N²)
        │ 包含: max, exp, sum     │
        └─────────────────────────┘

第三遍: 计算 O = P × V
        ┌─────────────────────────┐
        │ 读 P, V → 写 O (到 HBM)  │  读取 P (N²), V / 写入 O
        └─────────────────────────┘

关键问题: S 和 P 都从 HBM 写入并读出，
         HBM 带宽成为瓶颈，SRAM 未被有效利用。
```

---

## 2. FlashAttention 算法

### 2.1 核心洞察：Tiling 避免物化完整 S 矩阵

FlashAttention 的核心思想源于一个简单但深刻的观察：

> **Softmax 可以分块计算，只需要维护一个 running statistics (current_max, sum_exp)，在发现更大值时进行 rescale。**

这意味着我们不需要一次性计算完整的 S 矩阵，而是可以将 Q 分块，每个 Q 块遍历所有 K、V 块，在 SRAM 中逐步累积结果，最终只输出 O。

```
传统方法:
  Q [N×d] × K^T [d×N] → S [N×N] → (写入HBM) → 读回 → softmax → P [N×N] → (写入HBM)
                        → 读回 → × V [N×d] → O [N×d]

FlashAttention:
  Q 分块为 {Q₁, Q₂, ..., Q_Tc}，每个 Q_i 形状 [B_r × d]
  K 分块为 {K₁, K₂, ..., K_Tr}，每个 K_j 形状 [B_c × d]
  V 分块为 {V₁, V₂, ..., V_Tr}，每个 V_j 形状 [B_c × d]

  对每个 Q_i:
    初始化 running stats: m_i = -inf, l_i = 0, O_i = 0
    对每个 K_j, V_j:
      加载 Q_i, K_j, V_j 到 SRAM
      计算 S_ij = Q_i × K_j^T              [B_r × B_c]，留在 SRAM
      计算 m_ij = rowmax(S_ij)             [B_r]
      计算 P_ij = exp(S_ij - m_ij)         [B_r × B_c]
      计算 l_ij = rowsum(P_ij)             [B_r]
      使用 online softmax rescale 更新 O_i
    写回 O_i 到 HBM
```

### 2.2 Tiling 策略详解

FlashAttention 的核心是 Tiling（分块）策略，其关键在于正确选择块大小 `B_r` 和 `B_c`。

**块大小的约束条件**：

```
SRAM 中需要同时容纳:
  - Q 的一个块: B_r × d 个元素
  - K 的一个块: B_c × d 个元素
  - V 的一个块: B_c × d 个元素
  - S 的一个块: B_r × B_c 个元素
  - 中间变量: m, l, O_i (各 B_r 个元素)

约束: B_r × d + B_c × d + B_c × d + B_r × B_c + overhead ≤ SRAM_SIZE

对于 A100: SRAM_SIZE = 192 KB, d = 64, fp16
192 KB = 192 × 1024 / 2 = 98304 个 fp16 元素

B_r × 64 + 2 × B_c × 64 + B_r × B_c ≤ 98304

典型配置: B_r = 128, B_c = 128
验证: 128×64 + 2×128×64 + 128×128 = 8192 + 16384 + 16384 = 40960 ≤ 98304 ✓
```

**分块遍历的 ASCII 图**：

```
K/V 按序列维度分块 (B_c = 128):
    K₁      K₂      K₃      ...     K_Tr
   [128×d] [128×d] [128×d]       [128×d]
    V₁      V₂      V₃      ...     V_Tr
   [128×d] [128×d] [128×d]       [128×d]

Q 按序列维度分块 (B_r = 128):
┌───────┐
│ Q₁    │──→ 遍历 K₁..K_Tr → 计算 O₁ (在外循环结束时写回)
│[128×d]│     ├─ K₁,V₁: S₁₁=Q₁K₁^T, softmax局部, 累积O₁
│       │     ├─ K₂,V₂: S₁₂=Q₁K₂^T, softmax局部, rescale+累积O₁
│       │     └─ ...   K_Tr,V_Tr: ...最终O₁确定
├───────┤
│ Q₂    │──→ 同样的遍历 → O₂
│[128×d]│
├───────┤
│  ...  │
├───────┤
│ Q_Tc  │──→ O_Tc
│[128×d]│
└───────┘

关键: 所有中间矩阵 S_ij 都在 SRAM 中计算和消费，永不到达 HBM。
```

### 2.3 完整 Tiling 图 (块遍历全貌)

```
外循环 i: 遍历 Q 块 (i = 1 到 Tc)
┌─────────────────────────────────────────────────────────────┐
│ 从 HBM 加载 Q_i [B_r × d] 到 SRAM                           │
│ 初始化: m_i = [-inf] × B_r, l_i = [0] × B_r, O_i = [0] × B_r×d │
│                                                             │
│ 内循环 j: 遍历 K/V 块 (j = 1 到 Tr)                          │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 从 HBM 加载 K_j [B_c × d] 到 SRAM                       │ │
│ │ 从 HBM 加载 V_j [B_c × d] 到 SRAM                       │ │
│ │                                                         │ │
│ │ 在 SRAM 中:                                             │ │
│ │   S_ij = Q_i @ K_j^T          [B_r × B_c]              │ │
│ │                                                         │ │
│ │   m_new = max(m_old, rowmax(S_ij))      [B_r]          │ │
│ │   P_ij = exp(S_ij - m_new)             [B_r × B_c]     │ │
│ │   l_new = exp(m_old - m_new) * l_old + rowsum(P_ij)    │ │
│ │                                ^^^^^^^^^^^^^^^          │ │
│ │                                 rescale factor: 当新的  │ │
│ │                                 max 更大时，旧的 sum 需  │ │
│ │                                 要乘以这个因子缩小       │ │
│ │                                                         │ │
│ │   O_i = diag(exp(m_old - m_new)) @ O_i + P_ij @ V_j    │ │
│ │          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^     │ │
│ │          旧累积 rescale + 新块贡献                      │ │
│ │                                                         │ │
│ │   m_old = m_new; l_old = l_new                         │ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                             │
│ 内循环结束, O_i = O_i / l_i (按行归一化)                     │
│ 写 O_i [B_r × d] 回 HBM                                    │
└─────────────────────────────────────────────────────────────┘
```

### 2.4 FlashAttention 伪代码

```
算法: FlashAttention Forward Pass

输入: Q, K, V ∈ R^{N×d}, SRAM 大小 M
输出: O ∈ R^{N×d}

设 B_r = ⌊M / (4d)⌋,  B_c = ⌊M / (4d)⌋  (简化，实际更精细)
分别将 Q, K, V 分块为 T_r = ⌈N/B_r⌉ 和 T_c = ⌈N/B_c⌉ 个块

将 O 初始化为全零矩阵 [N×d]，将 l 初始化为全零向量 [N]
将 m 初始化为 -inf 向量 [N]

// ======== 将 Q 按行分块 ========
for i = 1 to T_r do:
    Q_i = Q[(i-1)*B_r : i*B_r, :]           // [B_r × d]
    O_i = zeros(B_r, d);  l_i = zeros(B_r)
    m_i = (-inf) vector of size B_r

    // ========== 将 K, V 按行分块 ==========
    for j = 1 to T_c do:
        K_j = K[(j-1)*B_c : j*B_c, :]       // [B_c × d]
        V_j = V[(j-1)*B_c : j*B_c, :]       // [B_c × d]

        // ---- 在 SRAM 中计算 ----
        S_ij = Q_i @ K_j^T                  // [B_r × B_c]

        m_ij = rowmax(S_ij)                 // [B_r]
        m_new = max(m_i, m_ij)              // [B_r]

        P_ij = exp(S_ij - m_new[:, None])   // [B_r × B_c]
                                              // m_new 扩展为列向量进行广播

        l_ij = rowsum(P_ij)                 // [B_r]

        // rescale factor: 旧 max 与 新 max 的指数差
        alpha = exp(m_i - m_new)            // [B_r]

        l_i = alpha * l_i + l_ij            // [B_r]

        O_i = diag(alpha) @ O_i + P_ij @ V_j // [B_r × d]

        m_i = m_new                          // 更新 running max

    end for

    // ---- 最终归一化 ----
    O_i = diag(1 / l_i) @ O_i               // [B_r × d]

    // ---- 写回 HBM ----
    O[(i-1)*B_r : i*B_r, :] = O_i
    l[(i-1)*B_r : i*B_r] = l_i
    m[(i-1)*B_r : i*B_r] = m_i           // 用于反向传播

end for

返回 O, l, m  (l 和 m 保存用于 backward pass)
```

---

## 3. Online Softmax 推导

### 3.1 标准 Softmax：三次遍历

标准 softmax 的数值稳定实现需要三次遍历：

```python
def standard_softmax(x):
    """
    x: [N] 向量
    需要三次遍历:
      Pass 1: 找最大值 m = max(x)
      Pass 2: 计算 exp(x_i - m) 并求和
      Pass 3: 除以 sum 得到归一化结果
    """
    m = max(x)                        # Pass 1
    exp_x = [exp(xi - m) for xi in x] # Pass 2 (计算 + 求和)
    s = sum(exp_x)                     # Pass 2 (求和)
    return [e / s for e in exp_x]     # Pass 3
```

这道出了标准 Attention 的问题：我们需要对 S 矩阵的每一行做 softmax，而 S 是 `[seq_len, seq_len]` 的，必须完整存在才能遍历。

### 3.2 Online Softmax：增量计算

Online Softmax 的关键在于：当新的最大值出现时，我们可以通过指数运算来"修正"之前累积的和。

**核心公式**：

```
已知 x[0..k-1] 的:
  m_old = max(x[0..k-1])
  l_old = sum(exp(x[0..k-1] - m_old))

现在加入新元素 x_k:
  如果 x_k <= m_old:
    m_new = m_old
    l_new = l_old + exp(x_k - m_old)
  如果 x_k > m_old:
    m_new = x_k
    l_new = l_old × exp(m_old - m_new) + exp(x_k - m_new)
              ^^^^^^^^^^^^^^^^^^^^^^^^
              关键 rescale 因子!

注意: exp(m_old - m_new) < 1 (因为 m_old < m_new)
      这保证了 rescale 后的值仍然正确
```

### 3.3 Rescale 技巧的数学推导

**引理**：设 `l_old = Σ exp(x_i - m_old)`，新最大值为 `m_new > m_old`，则：

```
正确的 l_new 应为: Σ exp(x_i - m_new)

但我们有 l_old = Σ exp(x_i - m_old)

推导:
  exp(x_i - m_new) = exp(x_i - m_old + m_old - m_new)
                    = exp(x_i - m_old) × exp(m_old - m_new)

因此:
  l_new = Σ exp(x_i - m_new)
        = Σ [exp(x_i - m_old) × exp(m_old - m_new)]
        = exp(m_old - m_new) × Σ exp(x_i - m_old)
        = exp(m_old - m_new) × l_old + exp(x_new - m_new)
```

**完整推导 (Online Softmax 正确性证明)**：

```
对于序列 x = [x_1, x_2, ..., x_n]，分块处理:
  块1: [x_1, ..., x_k1]
  块2: [x_{k1+1}, ..., x_{k2}]
  ...
  块m: [x_{km-1+1}, ..., x_n]

设处理完块 j 后的状态为 (m_j, l_j, 以及隐式的加权和)。

Base case: 块1
  m_1 = max(x[1:k1])
  l_1 = Σ_{i=1}^{k1} exp(x_i - m_1)

Inductive step: 假设块 1..j 已正确处理，状态为 (m_j, l_j)。

处理块 j+1:
  m_local = max(x[kj+1 : kj+1])
  m_{j+1} = max(m_j, m_local)

  Case 1: m_local ≤ m_j (新的 max 不大于旧的)
    l_{j+1} = l_j + Σ_{i=kj+1}^{kj+1} exp(x_i - m_j)

  Case 2: m_local > m_j (新的 max 更大)
    需要 rescale:
    l_{j+1} = l_j × exp(m_j - m_{j+1})  ← rescale 旧和
              + Σ_{i=kj+1}^{kj+1} exp(x_i - m_{j+1})  ← 加新项

    注意 m_{j+1} = m_local
```

### 3.4 数值稳定性证明

```
关键性质: 所有 intermediate 计算都在 [0, 1] 或接近的范围

1) exp(x_i - m) ≤ 1  (因为 m 是最大值，x_i - m ≤ 0)
    → P_ij 的元素值在 (0, 1] 范围内

2) exp(m_old - m_new) ≤ 1  (因为 m_old ≤ m_new)
    → rescale factor 在 (0, 1] 范围内

3) l_i 可能很大 (接近 B_c) 但依然在 fp16 范围内

4) 最关键的稳定性保证: 我们始终用当前最大值做归一化，
   避免了 exp(大正数) 导致的上溢，也避免了 exp(大负数) 的下溢。
```

### 3.5 Online Softmax 代码实现

```python
import torch
import math

def online_softmax_incremental(x_chunks):
    """
    对分块序列进行 online softmax 累积。

    x_chunks: list of tensors, 每块形状 [B_r, 1] 或 [B_r]
    返回: 完整的 softmax 结果 (需要分块加权平均使用)

    在实际 FlashAttention 中，online softmax 与矩阵乘法混合，
    不单独返回 softmax 权重。
    """
    # 初始化: max = -inf, sum = 0
    m = torch.tensor([-float('inf')])  # running max
    l = torch.tensor([0.0])            # running sum

    for x_chunk in x_chunks:
        # 当前块的局部 max
        m_local = x_chunk.max()

        # 新的全局 max
        m_new = max(m, m_local)

        # 如果 max 更新了，需要 rescale 旧的 sum
        if m_new > m:
            # rescale factor
            rescale = torch.exp(m - m_new)
            l = l * rescale

        # 累加当前块
        l = l + torch.sum(torch.exp(x_chunk - m_new))

        # 更新 m
        m = m_new

    return m, l


# 对比验证
def test_online_softmax():
    torch.manual_seed(42)
    x = torch.randn(4096)  # 完整序列
    chunks = x.chunk(32)   # 分成 32 块

    # 标准 softmax
    ref = torch.softmax(x, dim=-1)

    # Online softmax
    m, l = online_softmax_incremental(chunks)

    # 重构完整 softmax 权重
    online_result = torch.exp(x - m) / l

    # 验证
    max_diff = torch.abs(ref - online_result).max()
    print(f"Max difference: {max_diff.item():.2e}")
    assert max_diff < 1e-5, "Online softmax 与标准 softmax 不一致!"
    print("Online softmax 正确!")

test_online_softmax()
```

---

## 4. IO 复杂度分析

### 4.1 标准 Attention 的 HBM 访问量

标准 Attention 的完整数据流：

```
Step 1: S = Q @ K^T
  读 Q:  N×d 元素
  读 K:  N×d 元素
  写 S:  N×N 元素
  HBM 流量: N×d + N×d + N×N = 2Nd + N²

Step 2: P = softmax(S)
  读 S:  N×N 元素
  写 P:  N×N 元素
  HBM 流量: 2N²

Step 3: O = P @ V
  读 P:  N×N 元素
  读 V:  N×d 元素
  写 O:  N×d 元素
  HBM 流量: N² + 2Nd

总 HBM 访问量 (fp16, 单位: 元素个数):
  = (2Nd + N²) + (2N²) + (N² + 2Nd)
  = 4N² + 4Nd
  ≈ 4N²   (当 N >> d 时)
```

### 4.2 FlashAttention 的 HBM 访问量

FlashAttention 通过 tiling 避免了物化 S 和 P：

```
外层分块数: T_r = N / B_r
内层分块数: T_c = N / B_c

每个外层迭代 (一个 Q_i 块):
  读 Q_i:  B_r × d 元素  (一次从 HBM)
  对每个内层迭代:
    读 K_j:  B_c × d 元素
    读 V_j:  B_c × d 元素
  写 O_i:  B_r × d 元素  (一次写回 HBM)
  写 m_i, l_i: B_r 元素 (softmax stats)

HBM 总访问量:
  Q 读取: T_r × B_r × d = N×d
  K 读取: T_r × T_c × B_c × d = (N/B_r) × (N/B_c) × B_c × d = N² × d / B_r
  V 读取: 同上 = N² × d / B_r
  O 写入: N×d
  stats 写入: N

  = N×d + N²d/B_r + N²d/B_r + N×d + N
  ≈ 2N²d / B_r   (主导项)
```

### 4.3 加速比推导

```
标准 Attention HBM: ≈ 4N² 元素
FlashAttention HBM: ≈ 2N²d / B_r 元素

加速比 = 标准 / Flash = (4N²) / (2N²d / B_r) = 2B_r / d
```

关键约束：`B_r` 受 SRAM 大小 M 限制。近似地，`B_r ≈ M / (4d)` 时所有需要的块都能放进 SRAM。

```
加速比 ≈ 2 / d × M / (4d) = M / (2d²)

即: speedup ∝ SRAM大小 / (head_dim)²
```

这个公式揭示了几个重要结论：
- **更大的 SRAM** (M 更大) 意味着更大的加速比
- **更小的 head_dim** 意味着更大的加速比 (因为同样的 SRAM 可以放更大的 B_r)
- 这个分析的结论与实际实验高度吻合

### 4.4 具体数值示例

```
配置: d=64, N=2048, M=192KB (A100 SRAM), fp16

SRAM 容量: 192 × 1024 / 2 = 98,304 个 fp16 元素
B_r ≈ M / (4d) = 98304 / 256 = 384

标准 Attention HBM: 4 × 2048² = 16,777,216 元素 ≈ 32 MB
FlashAttention HBM: 2 × 2048² × 64 / 384 ≈ 1,398,101 元素 ≈ 2.67 MB

理论加速比: 32 / 2.67 ≈ 12×

实际观测加速比: 5-7×
  (差异来自: kernel launch overhead, 非理想分块, 
   softmax stats 存储, 同步开销等)
```

**序列长度与加速比的关系**：

```
d=64, M=192KB, B_r=384:

N=1024:  标准 = 4M 元素, FA = 341K 元素 → 加速 12×
N=2048:  标准 = 16M 元素, FA = 1.4M 元素 → 加速 11.4×
N=4096:  标准 = 64M 元素, FA = 5.5M 元素 → 加速 11.6×
N=8192:  标准 = 256M 元素, FA = 22M 元素  → 加速 11.6×
N=16384: 标准 = 1B 元素, FA = 87M 元素   → 加速 11.5×

加速比基本恒定 (当 N >> d 且 B_r 不变时)
实际加速比随 N 增大略有下降，这是因为 B_r 取整带来的效率损失占比增大
```

---

## 5. FlashAttention-2

### 5.1 主要改进点

FlashAttention-2 (Dao, 2023) 在 FlashAttention-1 的基础上做了以下关键改进：

**1. 减少非矩阵乘法操作**：
FA1 的 forward pass 中有大量 element-wise 操作（rescale, rowmax, rowsum），FA2 将其精简。
FA1 中每次内循环都要做 diag 乘法和 rescale，FA2 优化为向量操作。

**2. 并行策略调整**：
FA1 的并行在 batch 和 head 维度上。
FA2 额外增加了 **序列长度维度** 的并行。

```
并行策略对比:

FlashAttention-1:
  Grid = (batch_size × num_heads) 个 thread blocks
  每个 block 处理一个 (head, batch) 的全部序列

FlashAttention-2:
  Grid = (batch_size × num_heads × T_r) 个 thread blocks
  每个 block 处理 (head, batch) 的一个 Q 块 (B_r 行)
  → 更好的 GPU 利用率，特别是长序列时
```

**3. Causal Mask 优化**：
对于因果注意力（decoder-only 模型），FlashAttention-2 跳过对角线上方的 K/V 块，减少约一半的计算量。

```
Causal Mask: Q_i 只能 attend 到 K_j 当 j ≤ i

┌─────────────────────────────────────┐
│  Q₁  │ ████ │      │      │      │  │  Q₁ 只 attend K₁ (自己及更早)
│  Q₂  │ ████ │ ████ │      │      │  │  Q₂ 只 attend K₁, K₂
│  Q₃  │ ████ │ ████ │ ████ │      │  │  Q₃ 只 attend K₁, K₂, K₃
│  Q₄  │ ████ │ ████ │ ████ │ ████ │  │  Q₄ attend 全部
└─────────────────────────────────────┘
     K₁     K₂     K₃     K₄

██ = 需要计算    空白 = 跳过 (不加载 K_j, V_j)
```

### 5.2 Forward Pass 重构

FA2 的 forward pass 重排了计算顺序：

```
FlashAttention-1 (for each Q_i block):
  init O_i, m_i, l_i
  for j in 1..T_c:                    ← 内层遍历 K,V
    S_ij = Q_i @ K_j^T
    m_new = max(m_i, rowmax(S_ij))
    P_ij = exp(S_ij - m_new)
    l_i = rescale(l_i) + rowsum(P_ij)
    O_i = rescale(O_i) + P_ij @ V_j
  O_i = O_i / l_i

FlashAttention-2 (for each Q_i block):
  init m_i = -inf, l_i = 0
  for j_split in splits_of_T_c:       ← K,V 进一步分组
    O_i_part = 0
    m_i_part = m_i
    l_i_part = 0
    for j in split_range:             ← 组内遍历
      S_ij = Q_i @ K_j^T
      m_ij = rowmax(S_ij)
      ...
      m_ij, l_ij 更新 (partial reduction)
      O_i_part 累积
    end for
    m_i = max(m_i, m_i_part)           ← 跨 split reduction
    O_i += exp(m_i_part - m_i) * O_i_part
    l_i = exp(m_i_part - m_i) * l_i + l_i_part
  end for
```

主要变化：将内循环拆分为多个 split group，每个 group 做 partial reduction，然后跨 group 做一次全局 reduction。这样减少了 rescale 操作的次数。

### 5.3 性能对比

```
基准: A100 80GB, PyTorch 2.0, fp16, head_dim=64

| 配置 (batch, seqlen, nheads) | FA1 (TFLOPS) | FA2 (TFLOPS) | 加速比 |
|------------------------------|--------------|--------------|--------|
| (8, 1K, 16)                   | 89           | 140          | 1.57×  |
| (4, 2K, 16)                   | 95           | 158          | 1.66×  |
| (2, 4K, 16)                   | 102          | 175          | 1.72×  |
| (2, 8K, 16)                   | 108          | 190          | 1.76×  |
| (1, 16K, 16)                  | 115          | 203          | 1.77×  |
| (1, 1K, 16) causal            | 91           | 163          | 1.79×  |
| (1, 8K, 16) causal            | 110          | 215          | 1.95×  |

关键发现:
- causal mask 场景加速更明显 (接近 ~2×)
- 序列越长加速比越高 (更好的 GPU 利用率)
- FA2 接近 A100 的理论峰值利用率
```

---

## 6. FlashAttention-3

### 6.1 Hopper 架构特性利用

FlashAttention-3 针对 NVIDIA Hopper (H100) 架构进行了深度优化，充分利用了以下硬件特性：

```
H100 (Hopper) vs A100 (Ampere):

┌──────────────────────────────────────────────────────┐
│ 特性                │ A100          │ H100            │
├──────────────────────────────────────────────────────┤
│ FP16 TFLOPS         │ 312           │ 990             │
│ FP8 TFLOPS          │ -             │ 1980            │
│ HBM 带宽            │ 2.0 TB/s      │ 3.35 TB/s       │
│ HBM 容量            │ 80 GB         │ 80 GB           │
│ SRAM/SM             │ 192 KB        │ 256 KB          │
│ L2 Cache            │ 40 MB         │ 50 MB           │
│ SM 数量             │ 108           │ 132             │
│ TMA (Tensor Memory  │ 不支持         │ 支持            │
│   Accelerator)      │               │                 │
│ Warp Specialization │ 不支持         │ 支持            │
└──────────────────────────────────────────────────────┘
```

### 6.2 TMA (Tensor Memory Accelerator)

TMA 是 Hopper 架构的新硬件单元，专门用于加速张量数据搬运。

```
传统数据加载 (Ampere):
  Warp 中的线程执行 LDG (load from global) 指令
  → 占用计算资源 (register, warp scheduler slots)
  → 数据搬运与计算无法完全重叠

TMA 数据加载 (Hopper):
  ┌──────────────────────────────┐
  │  SM                           │
  │  ┌─────────┐  ┌────────────┐ │
  │  │ 计算单元 │  │ TMA 单元   │ │
  │  │ (Tensor  │  │ (异步拷贝) │ │
  │  │  Core)   │  │            │ │
  │  └────┬─────┘  └─────┬──────┘ │
  │       │              │        │
  │       ▼              ▼        │
  │  ┌─────────────────────────┐  │
  │  │      Shared Memory      │  │
  │  └─────────────────────────┘  │
  └──────────────────────────────┘
         │              │
         ▼              ▼
  ┌─────────────────────────────┐
  │         HBM (Global)        │
  └─────────────────────────────┘

TMA 优势:
  1. 硬件处理地址计算 (无需软件tiling)
  2. 自动处理边界条件 (bounds checking)
  3. 支持多维张量拷贝 (1D-5D)
  4. 异步执行: 数据搬运不占用 SM 计算资源
  5. 与 async-copy pipeline 集成
```

**TMA 使用示例 (CUDA)**：

```cpp
// Hopper TMA 异步数据加载
#include <cuda/barrier>

// 1. 创建 TMA 描述符
CUtensorMap tensor_map;
// ... 设置描述符: 形状、步长、数据类型等
cudaTensorMapEncodeTiled(&tensor_map, ...);

// 2. 在 kernel 中使用 TMA 加载
__global__ void flash_attn_kernel(__grid_constant__ CUtensorMap q_map,
                                   __grid_constant__ CUtensorMap k_map,
                                   __grid_constant__ CUtensorMap v_map) {
    // 使用异步 barrier 同步
    __shared__ alignas(128) cuda::barrier<cuda::thread_scope::thread> bar;

    if (threadIdx.x == 0) {
        init(&bar, blockDim.x);
        // TMA load: 异步加载 Q 块到 shared memory
        cuda::memcpy_async_tensor(q_smem, q_map, coords, &bar);
    }
    __syncthreads();

    // barrier 到达: 确保数据已经加载完成
    bar.arrive_and_wait();

    // 使用 q_smem 进行计算...
}
```

### 6.3 FP8 数据类型支持

H100 支持 FP8 (E4M3 和 E5M2) 数据类型，FlashAttention-3 利用这个特性进一步加速。

```
FP8 格式:
  E4M3: 1 sign + 4 exponent + 3 mantissa = 8 bits
        范围: max=448, min=2^-8, 精度约 7.8%
  E5M2: 1 sign + 5 exponent + 2 mantissa = 8 bits
        范围: max=57344, min=2^-14, 精度约 25%

FP8 的注意力计算需要 block-wise scaling:

Q, K, V 在 fp8 中每 B 个元素共享一个 scale:

┌────────────────────────────────────────┐
│ Q_fp8 [N×d]                            │
│ ┌─────────┬─────────┬─────┬─────────┐  │
│ │ block_1 │ block_2 │ ... │ block_k │  │
│ │ [B×d]   │ [B×d]   │     │ [B×d]   │  │
│ │ scale_1 │ scale_2 │     │ scale_k │  │
│ └─────────┴─────────┴─────┴─────────┘  │
│                                         │
│ 每个 block 存储为一个 fp8 矩阵           │
│ 和一个 fp32 scale 因子                  │
└────────────────────────────────────────┘

注意: FP8 GEMM 需要特殊处理:
  S = Q_fp8 × K_fp8^T
  但 Q 和 K 各有自己的 scale blocks
  → 需要对齐 scale 或在累积时校正
```

### 6.4 异步执行与 Warp Specialization

FlashAttention-3 采用 warp specialization 将计算和数据搬运分离：

```
Warp Specialization 架构 (FlashAttention-3):

┌──────────────────────────────────────────────────────────┐
│  Thread Block (例如 8 个 Warps)                           │
│                                                          │
│  ┌─────────────────────┐   ┌───────────────────────────┐ │
│  │ Producer Warps      │   │ Consumer Warps             │ │
│  │ (Warp 0, 1)          │   │ (Warp 2-7)                 │ │
│  │                     │   │                            │ │
│  │ 职责:               │   │ 职责:                      │ │
│  │ - TMA 异步加载       │   │ - 矩阵乘法 (MMA/TensorCore)│ │
│  │   Q_i, K_j, V_j     │   │ - softmax 在线计算         │ │
│  │ - 更新 load 指针     │   │ - rescale 和累积          │ │
│  │ - 管理 async barrier │   │ - 写回结果                 │ │
│  │                     │   │                            │ │
│  │ 大部分时间在等待     │   │ 持续计算，不被数据搬运中断  │ │
│  │ TMA 完成             │   │                            │ │
│  └─────────────────────┘   └───────────────────────────┘ │
│                                                          │
│  共享 Shared Memory (软件管理的缓存)                       │
│  ┌───────────┬───────────┬───────────┬───────────┐      │
│  │ Q_smem    │ K_smem    │ V_smem    │ O_smem    │      │
│  │ [ping]    │ [ping]    │ [ping]    │           │      │
│  │ [pong]    │ [pong]    │ [pong]    │           │      │
│  └───────────┴───────────┴───────────┴───────────┘      │
│    使用 ping-pong buffer 实现异步流水线                    │
└──────────────────────────────────────────────────────────┘
```

**Ping-Pong Pipeline 时序图**：

```
时间 ───────────────────────────────────────────────────────>

Producer Warp:  load_Q₁  load_K₁  load_Q₂  load_K₂  load_Q₃ ...
                          load_V₁           load_V₂

Consumer Warp:           compute  compute  compute  compute
                         S₁₁      S₂₁      S₁₂      S₂₂
                                  P₁₁×V₁            P₂₁×V₁
                         +softmax ...               ...

关键: Producer 和 Consumer 重叠执行。
     当 Consumer 在计算 block(j) 时，
     Producer 已经在加载 block(j+1)。
```

### 6.5 Persistent Kernel 设计

传统的 kernel launch 方式，每个 thread block 处理一个 Q 块，需要 `grid = T_r` 个 blocks。对于少量 blocks（短序列），GPU 利用率不高。

FA3 采用 persistent kernel：

```
传统 Kernel:
  grid.x = T_r 个 blocks
  每个 block 处理一个固定的 Q 块
  → 块数少时 GPU SM 闲置

Persistent Kernel:
  grid.x = num_SMs × 常数 (如一维 grid)
  每个 block 内有一个 work loop:
    while (有未处理的 Q 块):
      atomically fetch next Q block index  ← 动态任务分配
      处理该 Q block

  伪代码:
    while true:
      block_idx = atomicAdd(&counter, 1)
      if block_idx >= T_r: break
      process_q_block(block_idx)
```

**优势**：
- 更好地利用所有 SM（即使 T_r 较小）
- 各 SM 负载自然均衡（快的 SM 处理更多块）
- 减少 kernel launch overhead

### 6.6 FP8 GEMM on Hopper 的 API

```cuda
// Hopper FP8 GEMM (使用 CUTLASS 或 cuBLASLt)
#include <cublasLt.h>

// FP8 矩阵乘法 c = a × b
// a: fp8 (E4M3), b: fp8 (E4M3) 或 E5M2
// 输出需要 accumulation in fp32

// cuBLASLt FP8 matmul 配置
cublasLtMatmulDesc_t matmul_desc;
cublasLtMatmulDescCreate(&matmul_desc, CUBLAS_COMPUTE_32F, CUDA_R_32F);

// 设置 FP8 输入类型 (E4M3)
cublasLtMatmulDescSetAttribute(
    matmul_desc,
    CUBLASLT_MATMUL_DESC_INPUT_TYPE,
    &input_type,  // CUDA_R_8F_E4M3
    sizeof(input_type)
);

// 对于 FlashAttention 中的 FP8:
// 需要 block-wise scaling
// 每 128 个元素的 scale factor:
//   output = matmul(Q_fp8, K_fp8^T) × Q_scale × K_scale
// 其中 Q_scale 和 K_scale 需要 broadcast 对齐
```

---

## 7. 反向传播 (Backward Pass)

### 7.1 为什么需要重新计算 Attention

在训练中，backward pass 需要计算 `dQ`、`dK`、`dV`。这些梯度计算依赖于 forward pass 的中间结果（S 或 P 矩阵）。

```
梯度计算需要:
  dQ = dO @ V × softmax_gradient(S)  需要 S 或 P
  dK = dO^T @ Q × softmax_gradient(S) 需要 S 或 P
  dV = P^T @ dO                       需要 P

如果不存储 S 或 P：
  → 需要 O(N²) 内存存储 softmax 统计量
  → 或者 forward 存储 softmax stats (m, l)，backward 重新计算

FlashAttention 选择: 存储 softmax stats, backward 时重新计算
```

### 7.2 重计算策略

```python
# Forward pass 需要保存的信息 (每个 Q 块):
#   - Q, K, V (原始输入，用于重计算)
#   - m (rowmax for each row)          [N] 
#   - l (rowsum for each row)          [N]
#   - dO (output gradient, 来自上游)

# Backward pass:
#   对每个 Q 块重新遍历 K,V 块，利用保存的 m, l
#   重计算 P_ij，然后计算 dQ_i, dK_j, dV_j

def flash_attention_backward(Q, K, V, O, dO, m, l):
    """
    输入:
      Q, K, V: 原始输入 [N×d]
      O: forward 输出 [N×d]
      dO: 输出梯度 [N×d]
      m: rowmax from forward [N]
      l: rowsum from forward [N]
    输出:
      dQ, dK, dV: 输入梯度
    """
    dQ = zeros_like(Q)
    dK = zeros_like(K)
    dV = zeros_like(V)

    for i in range(T_r):  # Q 块
        Q_i = Q_block(i)
        dO_i = dO_block(i)
        O_i = O_block(i)
        m_i = m_block(i)
        l_i = l_block(i)

        # dO_i 预处理: D = rowsum(dO ⊙ O)  (element-wise product)
        D_i = rowsum(dO_i * O_i)  # [B_r]

        for j in range(T_c):  # K,V 块
            K_j = K_block(j)
            V_j = V_block(j)

            # 重计算 S_ij 和 P_ij
            S_ij = Q_i @ K_j^T                       # [B_r × B_c]
            P_ij = exp(S_ij - m_i[:, None])          # [B_r × B_c]
            # 注意: forward 的 l_i 已经包含了全局归一化

            # ---- dV 梯度 ----
            dV_j = dV_block(j) + P_ij^T @ dO_i       # [B_c × d]

            # ---- dP_ij (softmax 梯度) ----
            dP_ij = dO_i @ V_j^T                     # [B_r × B_c]
            dP_ij = dP_ij - D_i[:, None]             # 减去均值修正
            dP_ij = dP_ij * P_ij                     # softmax Jacobian

            # ---- dQ 梯度 ----
            dQ_i = dQ_i + dP_ij @ K_j                # [B_r × d]

            # ---- dK 梯度 ----
            dK_j = dK_block(j) + dP_ij^T @ Q_i       # [B_c × d]

            # 写回 dK_j, dV_j (需要 atomic add 或 separate buffer)

    return dQ, dK, dV
```

### 7.3 梯度公式推导

```
前向传播:
  S = QK^T / √d
  P = softmax(S)
  O = PV

Softmax 的 Jacobian:
  ∂P_i / ∂S_i = diag(P_i) - P_i P_i^T

其中 P_i 是第 i 行。

dO → dP:
  从链式法则: dP = dO @ V^T
  但 softmax 层有额外的约束

dO → dS:
  dS = P ⊙ (dO @ V^T - rowsum((dO @ V^T) ⊙ P)[:, None])
     = P ⊙ (dP_ij - D_i)

简化为代码中的形式。

dQ:
  dQ = dS @ K / √d

dK:
  dK = dS^T @ Q / √d

dV:
  dV = P^T @ dO
```

### 7.4 存储 vs 重计算的权衡

```
策略 A: 存储完整 P 矩阵 (标准实现)
  前向: 计算并保存 P [N×N]
  反向: 直接使用保存的 P
  优点: 反向快 (无重计算)
  缺点: 前向 O(N²) 内存

策略 B: 保存 softmax stats (FlashAttention)
  前向: 保存 m [N], l [N]
  反向: 重计算 S 和 P (仅 O(N²) FLOPs)
  优点: 前向 O(N) 内存
  缺点: 反向多 ~1.5× 计算量

策略 C: 前向 Q,K,V 压缩后保存 (activation checkpointing)
  前向: 丢弃 Q,K,V 块 (节省 HBM)
  反向: 从 HBM 重新加载 Q,K,V
  优点: 最小内存
  缺点: 额外 HBM 读取

FlashAttention 选择策略 B:
  - 训练时 O(N) 内存 vs O(N²)
  - 反向多 1.3-1.5× 计算 (可接受)
  - 实际训练吞吐量提升显著 (更大的 batch size)
```

---

## 8. 内存高效 Attention 替代方案

### 8.1 xFormers Memory-Efficient Attention

xFormers 是 Meta 开源的 memory-efficient attention 库，最初由 Tri Dao 在进入 Stanford 之前开发（后来演变为 FlashAttention）。

```python
import torch
from xformers.ops import memory_efficient_attention

# xFormers API
def xformers_attention(query, key, value, attn_bias=None, p=0.0):
    """
    query: [batch, seq_len, num_heads, head_dim]
    key:   [batch, seq_len, num_heads, head_dim]
    value: [batch, seq_len, num_heads, head_dim]

    返回: [batch, seq_len, num_heads, head_dim]
    """
    return memory_efficient_attention(
        query, key, value,
        attn_bias=attn_bias,
        p=p,  # dropout probability
        scale=None  # 默认使用 1/sqrt(head_dim)
    )

# 支持的可选功能:
# - Causal masking
# - 自定义 attention bias (如 ALiBi)
# - Dropout
# - 多种精度 (fp16, bf16, fp32)

# 使用示例
batch, seq_len, nheads, d = 2, 4096, 32, 64
q = torch.randn(batch, seq_len, nheads, d, dtype=torch.float16, device='cuda')
k = torch.randn(batch, seq_len, nheads, d, dtype=torch.float16, device='cuda')
v = torch.randn(batch, seq_len, nheads, d, dtype=torch.float16, device='cuda')

# xFormers memory-efficient attention
output = memory_efficient_attention(q, k, v, attn_bias=None)
```

xFormers 的实现与 FlashAttention 共享核心算法思想（tiling + online softmax），但 xFormers 最初使用手工优化 CUDA 而非用 CuTe/CUTLASS。

### 8.2 PyTorch 2.0 scaled_dot_product_attention (SDPA)

PyTorch 2.0 集成了统一的高性能 attention API：

```python
import torch
import torch.nn.functional as F

# PyTorch 2.0 统一 Attention API
def pytorch_sdpa(query, key, value, is_causal=False, scale=None):
    """
    PyTorch 自动选择最优 kernel 实现
    支持的后端:
      - FlashAttention (torch.backends.cuda.sdp_kernel)
      - Memory-Efficient Attention (xFormers)
      - Math (纯 PyTorch 实现, 无优化)
      - CUDNN Attention (cuDNN 8.5+)
    """
    return F.scaled_dot_product_attention(
        query, key, value,
        attn_mask=None,
        dropout_p=0.0,
        is_causal=is_causal,
        scale=scale
    )
```

**SDPA 后端选择逻辑**：

```python
# PyTorch SDPA 内部的后端选择逻辑 (简化)

def _select_sdp_backend(query, key, value, attn_mask, dropout_p, is_causal):
    """
    自动选择最优后端的逻辑
    """
    # 优先级由高到低
    backends = []

    # 1. FlashAttention backend
    if _can_use_flash_attention(query, key, value, attn_mask, dropout_p):
        backends.append('flash_attention')

    # 2. Memory-Efficient backend (xFormers)
    if _can_use_mem_efficient_attention(query, key, value, attn_mask, dropout_p):
        backends.append('memory_efficient')

    # 3. cuDNN backend (PyTorch 2.5+)
    if _can_use_cudnn_attention(query, key, value, attn_mask, dropout_p):
        backends.append('cudnn_attention')

    # 4. Math backend (fallback)
    backends.append('math')

    # 从高优先级到低优先级尝试
    for backend in backends:
        try:
            return _run_sdpa_with_backend(query, key, value, backend, ...)
        except Exception:
            continue

    raise RuntimeError("No SDPA backend available")

# 条件判断简化版:
def _can_use_flash_attention(query, key, value, attn_mask, dropout_p):
    # FA 要求:
    # - fp16 或 bf16
    # - head_dim <= 256
    # - 没有自定义 attn_mask (或只支持 causal bool mask)
    # - 在支持的 GPU 上 (SM >= 80, i.e. A100+)
    if query.dtype not in (torch.float16, torch.bfloat16):
        return False
    if query.size(-1) > 256:
        return False
    if attn_mask is not None and not _is_causal_mask(attn_mask):
        return False
    if not torch.cuda.is_available():
        return False
    if torch.cuda.get_device_capability() < (8, 0):
        return False
    return True
```

**显式指定后端**：

```python
# 在特定上下文管理器中使用指定后端
with torch.backends.cuda.sdp_kernel(
    enable_flash=True,
    enable_math=False,
    enable_mem_efficient=False
):
    output = F.scaled_dot_product_attention(q, k, v, is_causal=True)

# 或强制使用 MHA 后端 (PyTorch 2.5+)
with torch.nn.attention.sdpa_kernel(
    backends=[torch.nn.attention.SDPBackend.FLASH_ATTENTION]
):
    output = F.scaled_dot_product_attention(q, k, v)
```

### 8.3 FlashInfer 库

FlashInfer 是专门为 LLM 推理优化的 attention kernel 库，由 CMU Catalyst 和 UW 团队开发。

**核心特性**：

```
FlashInfer 特性矩阵:

┌─────────────────────────────────────────────────────────────┐
│ 场景          │ 描述                         │ 核心 Kernel     │
├──────────────────────────────────────────────────────────────┤
│ Prefill       │ 首次处理全序列, 类似训练前向  │ flash_attn_    │
│ (批量预填充)  │ 可多个请求 batch 在一起        │ with_kvcache   │
├──────────────┼──────────────────────────────┼────────────────┤
│ Decode        │ 单 token 生成, Q=[1,heads,d] │ decode_attn    │
│ (增量解码)    │ 瓶颈是 KV cache 读取           │                │
├──────────────┼──────────────────────────────┼────────────────┤
│ Append        │ 部分 prefill + 部分 decode    │ append_attn    │
│ (追加)        │ 混合场景, 不规则的 seqlen     │                │
└─────────────────────────────────────────────────────────────┘
```

**FlashInfer Prefill kernel**：

```python
import flashinfer

# Prefill: Q shape [total_tokens, num_heads, head_dim]
# 多个请求的 token 拼接在一起，用 kv_indices 和 kv_indptr 区分

# kv_indptr: 累积索引，如 [0, 1024, 2048, ...] 表示每个请求的KV长度
# kv_indices: 对应每个请求在 KV cache 中的位置

flashinfer.single_prefill_with_kv_cache(
    q=q_contiguous,          # [total_tokens, num_heads, head_dim]
    k=kv_cache_k,            # [max_total_tokens, num_heads, head_dim]
    v=kv_cache_v,            # [max_total_tokens, num_heads, head_dim]
    causal=True,
    kv_indptr=kv_indptr,     # 区分不同请求
    kv_indices=kv_indices,   # KV cache 中的位置映射
    kv_last_page_len=...,    # 最后一页的有效长度
    rotary_mode="NONE",      # RoPE 模式
    sm_scale=1.0 / sqrt(d),  # softmax scale
)
```

**FlashInfer Decode kernel**：

```python
# Decode: Q shape [batch, num_heads, head_dim]
# 每个请求一个 token, shared KV cache

flashinfer.single_decode_with_kv_cache(
    q=q_contiguous,          # [batch, num_kv_heads * group_size, head_dim]
    k=kv_cache_k,            # [total_pages, page_size, num_kv_heads, head_dim]
    v=kv_cache_v,            # [total_pages, page_size, num_kv_heads, head_dim]
    kv_indptr=kv_indptr,     # [batch+1] 累积索引
    kv_indices=kv_page_indices,  # [total_pages] 逻辑到物理页映射
    kv_last_page_len=...,    # [batch] 每个请求最后一页的 token 数
    sm_scale=1.0 / sqrt(d),  # softmax scale
    rope_scale=...,          # RoPE scaling
    rope_theta=...,          # RoPE theta
)
```

**Prefill vs Decode 分离的原因**：

```
两个阶段的计算特性完全不同:

┌─────────────────────────────────────────────────────────────┐
│                    │  Prefill          │  Decode              │
├─────────────────────────────────────────────────────────────┤
│ Q 形状             │ [S, heads, d]     │ [1, heads, d]        │
│                     │ S: 可变长度        │ 固定为一个 token      │
├─────────────────────────────────────────────────────────────┤
│ 计算瓶颈           │ Compute-bound     │ Memory-bound         │
│                     │ (大量矩阵乘法)     │ (KV cache 加载主导)   │
├─────────────────────────────────────────────────────────────┤
│ 并行策略           │ 序列维分块         │ batch 维 + KV 分页     │
│                     │ (FlashAttention)  │ (PagedAttention)     │
├─────────────────────────────────────────────────────────────┤
│ 内存访问           │ Q,K,V 均匀访问     │ KV cache 顺序读取    │
│                     │                   │ Q 访问可忽略          │
├─────────────────────────────────────────────────────────────┤
│ 算术强度           │ ~O(d×S) FLOP/B    │ ~O(d) FLOP/B         │
│                     │ (通常 compute)     │ (极低, memory)       │
└─────────────────────────────────────────────────────────────┘

因此需要不同的 kernel 实现来分别优化这两个阶段。
```

---

## 9. PagedAttention Kernel 深度解析

### 9.1 Block Table：逻辑块到物理块的映射

PagedAttention 是 vLLM 的核心创新，借鉴了操作系统的虚拟内存分页机制。

```
OS 虚拟内存                →    PagedAttention KV Cache
┌──────────────────────┐      ┌──────────────────────────────┐
│ 虚拟地址 → 物理地址   │      │ 逻辑 Block → 物理 Block       │
│ 页表 (page table)    │      │ Block Table                  │
│ 页 = 4KB             │      │ Block = 16 tokens (可配置)    │
│ 按需分配             │      │ 按需分配                      │
│ 连续虚拟 + 分散物理  │      │ 连续逻辑序列 + 分散物理 Block  │
└──────────────────────┘      └──────────────────────────────┘
```

**Block Table 数据结构**：

```
一个请求的 Block Table 示例:

逻辑序列: [tok0, tok1, tok2, ..., tok47]  (48 tokens)
Block size = 16

逻辑 Blocks:  Block₀           Block₁           Block₂
              [tok0..tok15]    [tok16..tok31]   [tok32..tok47]

Block Table:  [物理页号] = [7, 42, 13]
              ↑               ↑               ↑
              物理 Block 7    物理 Block 42   物理 Block 13
              (GPA 中任意位置)                  ← 不需要连续

内存布局:
  物理 Block 7:  [16 tokens × num_kv_heads × head_dim]
  物理 Block 42: [16 tokens × num_kv_heads × head_dim]
  物理 Block 13: [16 tokens × num_kv_heads × head_dim]

其他请求也可能使用物理 Block 7, 42, 13 中的空闲部分
→ 零内存碎片! (vs 传统 contiguous pre-allocation)
```

### 9.2 Kernel 中的 Block Table 遍历

```cuda
// PagedAttention v1 Kernel 核心逻辑 (简化)

__global__ void paged_attention_kernel_v1(
    float* __restrict__ out,           // [num_heads, head_dim]
    const float* __restrict__ q,       // [num_heads, head_dim]
    const float* __restrict__ k_cache, // [num_blocks, num_kv_heads, block_size, head_dim]
    const float* __restrict__ v_cache, // [num_blocks, num_kv_heads, block_size, head_dim]
    const int* __restrict__ block_table, // [max_num_blocks]
    const int context_len,             // 上下文长度 (逻辑 token 数)
    const float scale,
    const int block_size,              // 每个 block 的 token 数
    const int num_heads,
    const int num_kv_heads,
    const int head_dim
) {
    // 每个 thread block 处理一个 head
    int head_idx = blockIdx.x;
    int thread_idx = threadIdx.x;
    int kv_head_idx = head_idx / (num_heads / num_kv_heads); // GQA mapping

    // 计算此序列的 block 数量
    int num_blocks = (context_len + block_size - 1) / block_size;

    // ---- 初始化 online softmax state ----
    float m = -INFINITY;  // running max
    float l = 0.0f;        // running sum
    float o_val = 0.0f;    // running output (在 shared memory 中做 reduction)

    // ---- 遍历所有 KV blocks ----
    for (int block_idx = 0; block_idx < num_blocks; block_idx++) {
        // 1. 查询 block table: 逻辑 block_idx → 物理 block_id
        int physical_block_id = block_table[block_idx];

        // 2. 计算此 block 中的有效 token 数
        int valid_tokens = block_size;
        if (block_idx == num_blocks - 1) {
            // 最后一个 block 可能不满
            int remainder = context_len % block_size;
            valid_tokens = (remainder == 0) ? block_size : remainder;
        }

        // 3. 加载 K,V block 到共享内存 (或直接在寄存器中计算)
        //    K_block: [valid_tokens, head_dim] @ physical_block_id
        //    V_block: [valid_tokens, head_dim] @ physical_block_id

        for (int t = 0; t < valid_tokens; t++) {
            // 4. 计算单个 token 的 attention
            //    score = dot(Q[head], K_block[t]) * scale

            // 5. Online softmax 更新
            float score = /* Q @ K[t] */ * scale;
            float m_new = max(m, score);
            float alpha = expf(m - m_new);
            l = alpha * l + expf(score - m_new);
            o_val = alpha * o_val + expf(score - m_new) * V_block[t];
            m = m_new;
        }
    }

    // 6. 最终归一化并写回
    o_val = o_val / l;
    out[head_idx * head_dim + thread_idx] = o_val;
}
```

### 9.3 PagedAttention 与 FlashAttention 的融合

PagedAttention 本质上是在 decode 阶段的 tiled attention，其中：

- **Q** 只有 1 个 token （decode 阶段）
- **K, V** 被分页存储，每个"页"的大小为 `block_size` 个 tokens
- 每个页 = FlashAttention 中的一个 K/V 块
- 不同之处：页不是连续的，需要通过 block_table 查找

```
PagedAttention = FlashAttention 的特化版本 (decode 阶段):

FlashAttention tile:           PagedAttention tile:
┌──────────────────┐           ┌──────────────────────────┐
│ K_j [B_c×d]      │           │ Page j [16×d]            │
│ 连续内存          │     →     │ 物理地址通过 block_table  │
│ 顺序索引          │           │ 查找 (非连续)             │
└──────────────────┘           └──────────────────────────┘
                                     ↓
                    Block Table: [phys_idx₀, phys_idx₁, ...]
                         ↓              ↓
                    Phys Page 7     Phys Page 42
                    (全局 KV Cache 中任意位置)
```

### 9.4 vLLM PagedAttention v1 vs v2 Kernel

```
v1 Kernel (最初版本, CUDA):
  - 每个 seq 一个 thread block
  - 每个 warp 处理一个 head
  - 顺序遍历 block table
  - 简单直接，适用于较短序列

v2 Kernel (优化版本, CUDA):
  - 每个 head 一个 thread block (更好的并行度)
  - 使用 vectorized memory access (float4)
  - interleaved Q @ K 和 rescale 减少寄存器压力
  - 支持 GQA (多个 Q heads 共享一个 KV head)
  - 针对 A100/H100 优化

性能对比 (A100, head_dim=128, fp16):
┌──────────────────────────────────────────────────────┐
│ Context Len  │ v1 (us)  │ v2 (us)  │ 加速比          │
├──────────────────────────────────────────────────────┤
│ 1K           │ 45       │ 20       │ 2.25×           │
│ 4K           │ 180      │ 75       │ 2.4×            │
│ 8K           │ 360      │ 145      │ 2.48×           │
│ 16K          │ 720      │ 285      │ 2.53×           │
│ 32K          │ 1440     │ 560      │ 2.57×           │
└──────────────────────────────────────────────────────┘

v2 接近 HBM 峰值带宽: ~1.8 TB/s on A100 (峰值 2.0 TB/s)
```

### 9.5 内存布局：为什么 head_dim 是最内层维度

KV Cache 的内存布局对性能至关重要：

```
布局 A: [num_blocks, block_size, num_heads, head_dim]
  每个 block 内，按 token 优先排列
  访问模式: 加载一个 token 的 d 维向量时需要跨越 head 维度

布局 B: [num_blocks, num_heads, head_dim, block_size]
  head_dim 在最内层，按 head 优先排列
  访问模式: head_dim 连续有利于向量化加载 (float4 = 4 × 32-bit = 16 bytes)

vLLM 实际布局 (以 v2 kernel 为例):
  K_cache: [num_blocks, num_kv_heads, head_dim // x, block_size, x]
  V_cache: [num_blocks, num_kv_heads, head_dim, block_size]

其中 x = 16 / sizeof(dtype) → 对于 fp16，x = 8
这样 head_dim 维度的 8 个相邻 fp16 元素可以一次 float4 加载。

为什么要这样排列:
  1. 内存合并访问 (coalesced access):
     同一 warp 内多个线程访问连续地址
  2. 向量化加载 (float4 = 16 bytes = 128 bits):
     一次 load 指令加载 8 个 fp16 值
  3. 减少 bank conflict:
     合理 padding 避免 shared memory bank conflict
```

---

## 10. 解码阶段的 Attention 优化

### 10.1 单 Token Query 的特殊性

在自回归解码中，每次只生成一个 token：

```
Q 形状: [1, num_heads, head_dim]          ← 非常小
K 形状: [seq_len, num_kv_heads, head_dim]  ← 可能非常大
V 形状: [seq_len, num_kv_heads, head_dim]

计算: O = softmax(Q @ K^T) @ V

瓶颈分析:
  Q @ K^T:  2 × 1 × seq_len × head_dim FLOPs
           读取 seq_len × head_dim × 2 bytes (K)
           写入 seq_len × 2 bytes (S)
           → 算术强度 ≈ head_dim FLOP / (head_dim + 1) bytes ≈ 1

  对于 head_dim=128, fp16:
  算术强度 ≈ 1 → 严重 memory-bound!
  此时 HBM 带宽是唯一瓶颈。
```

### 10.2 关键技术优化

#### (a) KV Cache 量化 (FP8/INT8)

```python
# KV cache 量化示例 (简化)
import torch

def quantize_kv_cache(k_cache_fp16, v_cache_fp16):
    """
    KV Cache 量化到 INT8 / FP8
    每个 block 或每个 channel 使用独立 scale
    """
    # Per-channel quantization (每个 head_dim 通道独立 scale)
    k_amax = torch.max(torch.abs(k_cache_fp16), dim=-2, keepdim=True)[0]
    v_amax = torch.max(torch.abs(v_cache_fp16), dim=-2, keepdim=True)[0]

    k_scale = k_amax / 127.0  # INT8 max
    v_scale = v_amax / 127.0

    k_cache_int8 = (k_cache_fp16 / k_scale).round().clamp(-128, 127).to(torch.int8)
    v_cache_int8 = (v_cache_fp16 / v_scale).round().clamp(-128, 127).to(torch.int8)

    # 存储时 int8 + scale
    # Attention 计算时先反量化, 再做矩阵乘法
    return k_cache_int8, v_cache_int8, k_scale, v_scale

def quantized_attention_decode(q_fp16, k_int8, v_int8, k_scale, v_scale):
    """
    解码阶段的量化 attention
    """
    # 反量化: K/V 从 int8 回到 fp16
    k_deq = k_int8.float() * k_scale  # [seq_len, heads, d]
    v_deq = v_int8.float() * v_scale

    # 或更高效: 直接在低精度下计算
    # 1. Q @ K^T 时使用反量化后的 K
    scores = q_fp16 @ k_deq.transpose(-1, -2)  # [1, heads, seq_len]

    # 2. softmax (全精度)
    attn = torch.softmax(scores, dim=-1)

    # 3. V 反量化后加权求和
    output = attn @ v_deq  # [1, heads, d]

    return output
```

#### (b) GQA (Grouped Query Attention) 内核

```
GQA: num_kv_heads < num_heads

例如 Llama-3-70B: num_heads=64, num_kv_heads=8 (ratio=8)
每个 KV head 服务于 8 个 Q heads

GQA 的遍历逻辑:

Q:  [num_heads, head_dim]        = [64, 128]
K:  [seqlen, num_kv_heads, head_dim] = [4096, 8, 128]
V:  [seqlen, num_kv_heads, head_dim] = [4096, 8, 128]

┌───────────────────────────────────────────────────────┐
│   Q Heads:    Q₀ Q₁ Q₂ Q₃ Q₄ Q₅ Q₆ Q₇ │ Q₈ Q₉ ...   │
│               ↓  ↓  ↓  ↓  ↓  ↓  ↓  ↓   │  ↓  ↓       │
│   K,V Heads:      KV₀                    │     KV₁     │
│                                          │             │
│  分组: Q[0..7] → KV[0]                   │             │
│        Q[8..15] → KV[1]                  │             │
│        ...                               │             │
└───────────────────────────────────────────────────────┘

Kernel 优化:
  for kv_head in range(num_kv_heads):
      加载 K[kv_head], V[kv_head] → 共享内存 (一次加载，重复使用)
      for q_head in range(group_size):
          使用相同的 K,V 计算 O[q_head]
```

### 10.3 FlashDecoding

FlashDecoding 是专门针对长序列解码的优化，核心思想是沿序列维度并行化。

```
问题: Decode 阶段 Q 只有 1 个 token，序列维度无并行性
      单 thread block 处理所有 K,V → 计算资源浪费

FlashDecoding 方案: 把 KV 沿序列维度分成多个 chunk，
                   每个 chunk 由不同的 thread block 并行处理，
                   最后 reduction 合并结果。

┌──────────────────────────────────────────────────────────┐
│  KV Cache (seq_len=32768)                                │
│  ┌─────────┬─────────┬─────────┬─────┬─────────┬───────┐│
│  │ Split 0 │ Split 1 │ Split 2 │ ... │ Split k-2│Split k-1│
│  │ 4096 t  │ 4096 t  │ 4096 t  │     │ 4096 t  │4096 t ││
│  └────┬────┘────┬────┘────┬────┘     └────┬────┘───┬───┘│
│       │         │         │              │        │     │
│       ▼         ▼         ▼              ▼        ▼     │
│  ┌─────────┬─────────┬─────────┬─────┬─────────┬───────┐│
│  │ Block 0 │ Block 1 │ Block 2 │ ... │ Block k-2│Block k-1│
│  │ O₀,m₀,l₀│ O₁,m₁,l₁│ O₂,m₂,l₂│     │Ok-2,mk-2│Ok-1,mk-1│
│  └────┬────┘────┬────┘────┬────┘     └────┬────┘───┬───┘│
│       │         │         │              │        │     │
│       └─────────┴────┬────┴──────────────┴────────┘     │
│                      ▼                                   │
│              ┌───────────────────────┐                   │
│              │  Global Reduction     │                   │
│              │  (类似 online softmax │                   │
│              │   rescale + 合并)     │                   │
│              └───────────┬───────────┘                   │
│                          ▼                               │
│                     Final O                              │
└──────────────────────────────────────────────────────────┘

每个 split 独立计算:
  m_split = rowmax(S_split)
  l_split = rowsum(exp(S_split - m_split))
  O_split = softmax(S_split) @ V_split

全局 reduction (相同公式):
  m_global = max(m_all_splits)
  l_global = Σ(l_split × exp(m_split - m_global))
  O_global = Σ(O_split × l_split × exp(m_split - m_global)) / l_global
```

### 10.4 SplitK 方法

SplitK 是另一种沿序列维度并行化的方法，最初来自 GEMM 的并行化。

```
SplitK 思路:
  将 K 沿序列维度分成 K 个 splits
  每个 split 计算部分 attention 输出 O_split
  最后做一次 reduction (类似 FlashDecoding)

SplitK vs FlashDecoding:
  - SplitK 是更一般的概念 (来自 cublasLt GEMM SplitK)
  - FlashDecoding 是 SplitK 在注意力中的具体应用
  - 两者都需要最后的 reduction 步骤

cublasLt 的 SplitK GEMM:
  C = α × A × B + β × C
  Split B 沿 K 维度分片 → 多个部分和 → 最终 reduction
  类比: attention 中 S = Q × K^T 沿 K 序列维度分片
```

---

## 11. Sliding Window 与稀疏 Attention

### 11.1 Sliding Window Attention

Mistral 7B 使用的滑动窗口注意力限制了每个 token 的 attend 范围。

```
Sliding Window Attention (window_size = 4096):

对于序列中的 token i:
  token i 只能 attend 到 [i - window_size, i] 范围内的 token

┌───────────────────────────────────────────────────────────┐
│  Token Index:    0   1   2  ...  w  w+1 w+2 ...  N-1      │
│                                                           │
│  Token 0:       [██]                                     │
│  Token 1:       [██ ██]                                   │
│  Token 2:       [██ ██ ██]                                │
│    ...                                                    │
│  Token w:       [██ ██ ██ ... ██]  ← w+1 个               │
│  Token w+1:        [██ ██ ... ██ ██]  ← w+1 个 (滑窗)    │
│  Token w+2:           [██ ... ██ ██ ██]                    │
│    ...                                                    │
│  Token N-1:                      [... ... ... ██]         │
│                                     ← w+1 个              │
│                                                           │
│  ██ = 有效 attention 位置                                  │
│  空白 = 不需要计算 (mask 为 -inf)                           │
└───────────────────────────────────────────────────────────┘

复杂度: O(N × window_size) → O(N)  (window_size 固定)
        而非 O(N²)
```

### 11.2 块级跳过实现

```python
# 滑动窗口 Attention 的 tiled 实现

def flash_sliding_window_attention(Q, K, V, window_size, block_size=128):
    """
    滑动窗口 attention 使用 block-level 跳过

    对于 Q 块 i 和 K 块 j:
      如果 j < i - window_blocks: 跳过整个 K 块
      其中 window_blocks = window_size / block_size
    """
    N = Q.shape[0]
    T_r = N // block_size
    T_c = N // block_size
    window_blocks = window_size // block_size

    O = torch.zeros_like(Q)

    for i in range(T_r):
        Q_i = Q[i*block_size : (i+1)*block_size]
        O_i = torch.zeros_like(Q_i)
        m_i = torch.full((block_size,), -float('inf'), device=Q.device)
        l_i = torch.zeros(block_size, device=Q.device)

        # 只遍历窗口内的 K,V 块
        start_j = max(0, i - window_blocks)
        end_j = i + 1  # causal: 只能看之前的 token

        for j in range(start_j, end_j):
            K_j = K[j*block_size : (j+1)*block_size]
            V_j = V[j*block_size : (j+1)*block_size]

            S_ij = Q_i @ K_j.T  # [B_r, B_c]

            # 如果需要，在此处还可以加更细粒度的 mask
            # 处理块边界处的部分窗口

            # ... (online softmax 累积逻辑，与标准 FA 相同)
            m_new = torch.max(m_i, S_ij.max(dim=-1).values)
            alpha = torch.exp(m_i - m_new)
            P_ij = torch.exp(S_ij - m_new[:, None])
            l_new = alpha * l_i + P_ij.sum(dim=-1)
            O_i = alpha[:, None] * O_i + P_ij @ V_j
            m_i = m_new
            l_i = l_new

        O_i = O_i / l_i[:, None]
        O[i*block_size:(i+1)*block_size] = O_i

    return O
```

### 11.3 Block-Sparse Attention

超长序列中进一步使用预定义的稀疏模式：

```
Longformer / BigBird 的稀疏模式:

Longformer Pattern:
┌───────────────────────────────────────────────────────────┐
│  [██]───[global tokens: 所有位置可见]                       │
│  [██ ██]                                                  │
│  [██ ██ ██]                                               │
│  [   ██ ██ ██  ]  ← sliding window                       │
│  [██    ██ ██ ██     ]                                    │
│  [██       ██ ██ ██    ]                                  │
│  [██          ██ ██ ██   ]                                │
│  [██             ██ ██ ██  ]                              │
│  [██                ██ ██ ██ ]                            │
│  [██                   ██ ██ ██]                          │
│  [█████████████████████████████]  ← global token           │
└───────────────────────────────────────────────────────────┘

BigBird Pattern (三种注意力组合):
  ┌─────────────────────────────────────────────────────┐
  │ 1. Sliding Window (局部窗口)                         │
  │ 2. Random Attention (随机选择的位置)                  │
  │ 3. Global Attention (几个全局 token 可见所有位置)     │
  │                                                     │
  │ 组合后形成稀疏但保持连通性的 attention pattern        │
  └─────────────────────────────────────────────────────┘
```

**Sparse Attention 的 Kernel 实现**：

```cuda
// Block-sparse attention kernel 概念

// 预定义的 sparsity mask (block level)
// mask[i][j] = true 表示 Q block i 需要计算 K block j

__global__ void block_sparse_attention_kernel(
    float* O,
    const float* Q,
    const float* K,
    const float* V,
    const bool* block_mask,  // [T_r × T_c] block-level sparsity mask
    ...
) {
    int q_block = blockIdx.x;

    // 加载 Q 块
    __shared__ float Q_smem[B_r][d];

    // 只遍历 mask 为 true 的 K,V 块
    for (int kv_block = 0; kv_block < T_c; kv_block++) {
        if (!block_mask[q_block * T_c + kv_block]) {
            continue;  // 跳过整个 block → 节省带宽和计算
        }

        // 正常加载 K,V 块并计算
        load_kg_block(K_smem, K, kv_block);
        load_vg_block(V_smem, V, kv_block);
        // ... attention 计算
    }
}
```

---

## 12. Multi-Head Attention 融合

### 12.1 Fusing QKV Projection

标准 MHA 中，Q、K、V 由三个独立的线性投影得到。融合后可以合并为一个 GEMM。

```
标准 MHA:
  Q = x @ W_Q    [seq_len, d_model] @ [d_model, num_heads × head_dim]
  K = x @ W_K    [seq_len, d_model] @ [d_model, num_heads × head_dim]
  V = x @ W_V    [seq_len, d_model] @ [d_model, num_heads × head_dim]

  三个独立的矩阵乘法 → 需要三次 kernel launch + 中间结果存储

融合 QKV Projection:
  W_QKV = concat(W_Q, W_K, W_V) 沿最后一维
        = [W_Q | W_K | W_V]  形状: [d_model, 3 × num_heads × head_dim]

  QKV = x @ W_QKV  [seq_len, 3 × num_heads × head_dim]

  一次矩阵乘法，然后 split 得到 Q, K, V:
  Q = QKV[:, :num_heads*head_dim]
  K = QKV[:, num_heads*head_dim : 2*num_heads*head_dim]
  V = QKV[:, 2*num_heads*head_dim :]

  优势:
  - 减少 kernel launch overhead (3 → 1)
  - 减少 HBM 读写 (输入 x 只需读取一次)
  - 潜在计算量不变，但 memory 效率提升
```

### 12.2 端到端融合 MHA Kernel 结构

```
完整的融合 MHA Kernel 数据流:

┌─────────────────────────────────────────────────────────────┐
│  HBM (全局内存)                                              │
│  ┌───────┐  ┌──────────────┐  ┌──────────────────┐         │
│  │ 输入 x │  │ W_QKV 权重   │  │ 输出 O (写回)    │         │
│  │[N,dm]  │  │[dm,3×h×d]   │  │[N, h×d]          │         │
│  └───┬───┘  └──────┬───────┘  └──────────────────┘         │
│      │             │                                        │
│  ┌───┴─────────────┴────────────────────────────┐           │
│  │            SM SRAM                            │           │
│  │                                              │           │
│  │  ① 加载 x 块 + W_QKV → 计算 QKV 块            │           │
│  │     ┌───┬───┬───┐                            │           │
│  │     │ Q │ K │ V │ (同一次 tile, 在 SRAM 中)    │           │
│  │     └───┴───┴───┘                            │           │
│  │         │                                     │           │
│  │  ② FlashAttention: 分块遍历 K,V               │           │
│  │     ┌─────────────────────┐                   │           │
│  │     │  Q_i @ K_j^T → S_ij │                   │           │
│  │     │  softmax → P_ij     │                   │           │
│  │     │  P_ij @ V_j → O_i   │                   │           │
│  │     └─────────────────────┘                   │           │
│  │         │                                     │           │
│  │  ③ 加载 W_O → 计算 Output Projection          │           │
│  │     O_i @ W_O → 最终输出                       │           │
│  │                                              │           │
│  └──────────────────────────────────────────────┘           │
└─────────────────────────────────────────────────────────────┘

关键: Q, K, V 的产生和消费都在 SRAM 中完成，
     永不到达 HBM。只有输入 x, W 权重, 最终输出 O 访问 HBM。
```

### 12.3 FlashInfer 的融合 Attention

```python
# FlashInfer 融合 attention 示例

import flashinfer

# 场景: 推理中的 fused attention (QKV projection + attention + output projection)

# FlashInfer 的 fused attention 将 QKV projection、attention、output projection
# 融合成一个 CUDA kernel
# 这在 prefill 阶段特别有效

output = flashinfer.fused_mha_with_kv_cache(
    input_x,              # [total_tokens, d_model]  输入 embedding
    w_qkv,                # [d_model, 3*num_heads*head_dim]  融合的投影权重
    w_o,                  # [num_heads*head_dim, d_model]  输出投影权重
    k_cache,              # KV cache [max_blocks, ...]
    v_cache,              # KV cache
    kv_indptr,            # 累积索引
    kv_indices,           # 页表
    causal=True,
    sm_scale=1.0 / sqrt(head_dim),
)
```

### 12.4 CUTLASS Grouped GEMM for Batched QKV

对于批量大小不同的问题（如不同 sequence lengths），CUTLASS grouped GEMM 很有效：

```cpp
// CUTLASS Grouped GEMM 用于 batched QKV projections

#include "cutlass/gemm/grouped/gemm.h"

// 场景: batch 中每个请求的序列长度不同
// seq_lens = [1024, 512, 2048, 256, 768]
// 不能简单 reshape 做 single batch GEMM

// 使用 Grouped GEMM:
// Group 0: 处理 seqlen=1024 的所有 tokens
// Group 1: 处理 seqlen=512 的所有 tokens
// ...

// CUTLASS grouped GEMM 的关键数据结构
struct GroupedGemmArguments {
    int num_groups;
    int* m_sizes;       // 每个 group 的 M 维度
    int* n_sizes;       // 每个 group 的 N 维度 (QKV: n = 3*h*d)
    int* k_sizes;       // 每个 group 的 K 维度 (d_model)
    void** ptr_A;       // 每个 group 的 A 矩阵指针 (输入 x)
    void** ptr_B;       // 每个 group 的 B 矩阵指针 (W_QKV)
    void** ptr_C;       // 每个 group 的 C 矩阵指针 (QKV 输出)
};

// 优势:
// 1. 单次 kernel launch 处理所有 groups
// 2. 每个 group 使用最优 tile size
// 3. 减少 launch overhead
```

---

## 13. 实战：Benchmark 与 Profile

### 13.1 实验环境配置

```python
# benchmark_attention.py
# 环境: A800 80GB, PyTorch 2.0+, FlashAttention 2, CUDA 11.8+

import torch
import torch.nn.functional as F
import time
import argparse
from typing import Callable

# 尝试导入各 attention 后端
try:
    from flash_attn import flash_attn_func
    HAS_FLASH_ATTN = True
except ImportError:
    HAS_FLASH_ATTN = False
    print("Warning: flash_attn not available")

try:
    from xformers.ops import memory_efficient_attention
    HAS_XFORMERS = True
except ImportError:
    HAS_XFORMERS = False
    print("Warning: xformers not available")


def benchmark_attention(
    fn: Callable,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    name: str,
    warmup: int = 10,
    iters: int = 100,
) -> float:
    """运行 benchmark"""
    # Warmup
    for _ in range(warmup):
        fn(q, k, v)

    # 同步并计时
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(iters):
        fn(q, k, v)
    torch.cuda.synchronize()
    end = time.perf_counter()

    elapsed_ms = (end - start) / iters * 1000
    print(f"  {name:40s}: {elapsed_ms:8.3f} ms")
    return elapsed_ms


def run_benchmarks(batch_size: int, seq_len: int, nheads: int,
                   head_dim: int, causal: bool = False, dtype=torch.float16):
    """运行所有 attention 后端的 benchmark"""
    device = torch.device('cuda')
    shape = (batch_size, seq_len, nheads, head_dim)

    q = torch.randn(*shape, dtype=dtype, device=device)
    k = torch.randn(*shape, dtype=dtype, device=device)
    v = torch.randn(*shape, dtype=dtype, device=device)

    # 为标准 attention 准备 mask (如果需要 causal)
    if causal:
        mask = torch.triu(
            torch.ones(seq_len, seq_len, device=device, dtype=torch.bool),
            diagonal=1
        )
    else:
        mask = None

    results = {}

    # 1. PyTorch SDPA (自动选择后端)
    def pytorch_sdpa(q, k, v):
        return F.scaled_dot_product_attention(
            q, k, v, attn_mask=None, dropout_p=0.0, is_causal=causal
        )
    results['torch_sdpa'] = benchmark_attention(
        pytorch_sdpa, q, k, v, "PyTorch SDPA (auto)"
    )

    # 2. PyTorch SDPA with Flash Attention forced
    with torch.backends.cuda.sdp_kernel(
        enable_flash=True, enable_math=False, enable_mem_efficient=False
    ):
        def pytorch_sdpa_flash(q, k, v):
            return F.scaled_dot_product_attention(
                q, k, v, is_causal=causal
            )
        results['torch_flash'] = benchmark_attention(
            pytorch_sdpa_flash, q, k, v, "PyTorch SDPA (flash forced)"
        )

    # 3. PyTorch SDPA with Mem-Efficient forced
    with torch.backends.cuda.sdp_kernel(
        enable_flash=False, enable_math=False, enable_mem_efficient=True
    ):
        def pytorch_sdpa_mem(q, k, v):
            return F.scaled_dot_product_attention(
                q, k, v, is_causal=causal
            )
        results['torch_mem_eff'] = benchmark_attention(
            pytorch_sdpa_mem, q, k, v, "PyTorch SDPA (mem-eff forced)"
        )

    # 4. FlashAttention (直接调用)
    if HAS_FLASH_ATTN:
        def flash_attn(q, k, v):
            # flash_attn_func expects [batch, seqlen, nheads, head_dim]
            return flash_attn_func(q, k, v, causal=causal)
        results['flash_attn'] = benchmark_attention(
            flash_attn, q, k, v, "FlashAttention-2 (direct)"
        )

    # 5. xFormers (直接调用)
    if HAS_XFORMERS:
        attn_bias = None
        if causal:
            from xformers.ops import LowerTriangularMask
            attn_bias = LowerTriangularMask()

        def xformers_attn(q, k, v):
            return memory_efficient_attention(
                q, k, v, attn_bias=attn_bias
            )
        results['xformers'] = benchmark_attention(
            xformers_attn, q, k, v, "xFormers mem-efficient"
        )

    # 6. 标准 PyTorch 实现 (Math backend)
    with torch.backends.cuda.sdp_kernel(
        enable_flash=False, enable_math=True, enable_mem_efficient=False
    ):
        def pytorch_math(q, k, v):
            return F.scaled_dot_product_attention(
                q, k, v, is_causal=causal
            )
        results['torch_math'] = benchmark_attention(
            pytorch_math, q, k, v, "PyTorch SDPA (math forced)"
        )

    return results


def print_summary(configs_results):
    """打印对比总结"""
    print("\n" + "=" * 80)
    print(f"{'Config':<30s} | {'torch_sdpa':>10s} | {'flash_attn':>10s} | "
          f"{'xformers':>10s} | {'math':>10s}")
    print("-" * 80)

    for config, results in configs_results:
        label = f"b={config[0]} s={config[1]} h={config[2]} d={config[3]} c={'Y' if config[4] else 'N'}"
        torch_t = results.get('torch_sdpa', 0)
        flash_t = results.get('flash_attn', 0)
        xf_t = results.get('xformers', 0)
        math_t = results.get('torch_math', 0)
        print(f"{label:<30s} | {torch_t:8.2f}ms | {flash_t:8.2f}ms | "
              f"{xf_t:8.2f}ms | {math_t:8.2f}ms")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch', type=int, default=1)
    parser.add_argument('--seqlen', type=int, nargs='+', default=[1024, 2048, 4096, 8192])
    parser.add_argument('--nheads', type=int, default=32)
    parser.add_argument('--headdim', type=int, default=64)
    parser.add_argument('--causal', action='store_true')
    args = parser.parse_args()

    configs_results = []
    for seq_len in args.seqlen:
        print(f"\n{'='*60}")
        print(f"Benchmark: batch={args.batch}, seqlen={seq_len}, "
              f"nheads={args.nheads}, head_dim={args.headdim}, causal={args.causal}")
        print(f"{'='*60}")

        results = run_benchmarks(
            batch_size=args.batch,
            seq_len=seq_len,
            nheads=args.nheads,
            head_dim=args.headdim,
            causal=args.causal,
        )

        configs_results.append((
            (args.batch, seq_len, args.nheads, args.headdim, args.causal),
            results
        ))

    print_summary(configs_results)
```

### 13.2 Torch Profiler 使用

```python
# profile_attention.py
import torch
import torch.nn.functional as F
from torch.profiler import profile, record_function, ProfilerActivity

def profile_attention_implementations():
    """
    使用 torch.profiler 对不同的 attention 实现进行 profiling
    """
    device = torch.device('cuda')
    batch, seq_len, nheads, head_dim = 1, 4096, 32, 64

    q = torch.randn(batch, seq_len, nheads, head_dim,
                    dtype=torch.float16, device=device)
    k = torch.randn(batch, seq_len, nheads, head_dim,
                    dtype=torch.float16, device=device)
    v = torch.randn(batch, seq_len, nheads, head_dim,
                    dtype=torch.float16, device=device)

    # Profile PyTorch SDPA
    with profile(
        activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
        record_shapes=True,
        with_stack=True,
        with_flops=True,
    ) as prof:
        with record_function("sdpa_forward"):
            output = F.scaled_dot_product_attention(
                q, k, v, is_causal=False
            )
        torch.cuda.synchronize()

    # 打印 CUDA kernel 时间
    print("\n" + "="*80)
    print("PyTorch SDPA CUDA Kernel 时间分析")
    print("="*80)
    print(prof.key_averages().table(
        sort_by="cuda_time_total", row_limit=15
    ))

    # 导出 chrome trace
    prof.export_chrome_trace("sdpa_trace.json")
    print("\nChrome trace 已导出到 sdpa_trace.json")

    # 获得显存使用统计
    print("\n显存使用:")
    print(f"  Peak memory allocated: "
          f"{torch.cuda.max_memory_allocated() / 1024**3:.2f} GB")
    print(f"  Peak memory reserved:  "
          f"{torch.cuda.max_memory_reserved() / 1024**3:.2f} GB")
```

### 13.3 Nsight Systems 使用

```bash
# 使用 Nsight Systems 进行 kernel-level profiling

# 1. 启动 nsys profiling
nsys profile \
    --trace=cuda,nvtx,osrt,cudnn,cublas \
    --output=attention_profile \
    --force-overwrite=true \
    python profile_attention.py

# 2. 分析结果 (命令行)
nsys stats attention_profile.qdrep \
    --report cuda_gpu_kern_sum \
    --format csv \
    --output attention_kernels.csv

# 3. 打开 GUI 分析
# nsys-ui attention_profile.qdrep
```

**Nsight Systems 时间线解读**：

```
Nsight Systems 典型时间线 (Attention Kernel):

┌──────────────────────────────────────────────────────────────────┐
│  Stream 7 (Default)                                              │
│                                                                  │
│  ┌──────────────────────┐  ┌──────────────────────────────┐     │
│  │  QKV Projection      │  │  FlashAttention Kernel        │     │
│  │  (cublas gemm)       │  │  flash_fwd_kernel            │     │
│  │  ~0.5 ms             │  │  ~2.8 ms                     │     │
│  └──────────────────────┘  └──────────────────────────────┘     │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐     │
│  │  Memory operations:                                       │     │
│  │  ┌────────────────┐  ┌──────────┐  ┌──────────┐         │     │
│  │  │HBM→SM (load Q) │  │SM→HBM    │  │SM→HBM    │         │     │
│  │  │                │  │(write O) │  │(stats)   │         │     │
│  │  └────────────────┘  └──────────┘  └──────────┘         │     │
│  └─────────────────────────────────────────────────────────┘     │
│                                                                  │
│  关键指标:                                                        │
│  - SM 占用率: 目标 > 60%                                         │
│  - HBM 带宽利用率: 目标 > 80%                                     │
│  - 寄存器溢出: 理想为 0                                           │
│  - Shared Memory bank conflicts: 理想为 0                        │
└──────────────────────────────────────────────────────────────────┘
```

### 13.4 结果解读

**典型的 benchmark 结果**：

```
预期结果 (A800, batch=1, fp16, causal=False):

| seq_len | nheads | head_dim | torch_sdpa | flash_attn | xformers | math     |
|---------|--------|----------|------------|------------|----------|----------|
| 1024    | 32     | 64       | 0.52ms     | 0.38ms     | 0.55ms   | 2.1ms    |
| 2048    | 32     | 64       | 1.15ms     | 0.82ms     | 1.20ms   | 5.8ms    |
| 4096    | 32     | 64       | 3.10ms     | 2.15ms     | 3.25ms   | 20.5ms   |
| 8192    | 32     | 64       | 10.5ms     | 7.20ms     | 11.0ms   | 78.3ms   |
| 16384   | 32     | 64       | 40.2ms     | 27.5ms     | 42.1ms   | OOM      |

关键发现:
1. FlashAttention 通常是所有实现中最快的 (特别是长序列)
2. PyTorch SDPA 自动选择的后端接近 FlashAttention
3. Math 后端 (O(N²) 内存) 在长序列时 OOM
4. xFormers 在短序列时可能比 FA 慢 (更多 overhead)
5. 加速比随序列长度增大而增大
6. causal=True 时，FA2 的优势更大 (~1.8× faster than non-optimized causal)
```

---

## 14. 简化版 FlashAttention 的 Triton 实现

### 14.1 完整 Triton 实现 (~100 行)

```python
"""
FlashAttention Forward Pass in Triton
简化但完整的实现，展示核心概念:
  - Block tiling
  - Online softmax with rescaling
  - Efficient SRAM usage
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _flash_attn_fwd_kernel(
    # 输入指针
    Q_ptr, K_ptr, V_ptr,
    # 输出指针
    O_ptr,
    # softmax 统计量 (用于 backward)
    L_ptr, M_ptr,
    # 标量参数
    stride_qb, stride_qh, stride_qm, stride_qd,  # Q strides
    stride_kb, stride_kh, stride_kn, stride_kd,  # K strides
    stride_vb, stride_vh, stride_vn, stride_vd,  # V strides
    stride_ob, stride_oh, stride_om, stride_od,  # O strides
    B, H, N, D: tl.constexpr,  # 形状常量
    BLOCK_M: tl.constexpr,      # Q 块大小 (沿序列维)
    BLOCK_N: tl.constexpr,      # K,V 块大小 (沿序列维)
    BLOCK_D: tl.constexpr,      # head_dim 块大小
    SCALE: tl.constexpr,        # 1/√d
):
    """
    每个 program instance 处理一个 (batch, head) 对的一个 Q 块
    """
    # ---- 计算此 block 的任务索引 ----
    pid_batch = tl.program_id(0)
    pid_head = tl.program_id(1)
    pid_m = tl.program_id(2)  # Q 块在序列维上的索引

    # ---- Q 块的起始位置 ----
    q_start = pid_m * BLOCK_M

    # ---- 构造 Q 块的指针 ----
    # Q: [batch, head, seq, d]
    q_block_ptr = tl.make_block_ptr(
        base=Q_ptr,
        shape=(N, D),
        strides=(stride_qm, stride_qd),
        offsets=(q_start, 0),
        block_shape=(BLOCK_M, BLOCK_D),
        order=(1, 0),
    )

    # ---- 加载 Q 块到 SRAM ----
    # Q: [BLOCK_M, BLOCK_D]
    q = tl.load(q_block_ptr, boundary_check=(0, 1))

    # ---- 初始化 online softmax 状态 ----
    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")  # running max
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32)                  # running sum
    o_i = tl.zeros([BLOCK_M, BLOCK_D], dtype=tl.float32)         # running output

    # ---- 遍历 K,V 块 (内循环) ----
    num_kv_blocks = tl.cdiv(N, BLOCK_N)

    for j in range(num_kv_blocks):
        kv_start = j * BLOCK_N

        # ---- 加载 K 块 ----
        k_block_ptr = tl.make_block_ptr(
            base=K_ptr,
            shape=(N, D),
            strides=(stride_kn, stride_kd),
            offsets=(kv_start, 0),
            block_shape=(BLOCK_N, BLOCK_D),
            order=(1, 0),
        )
        k = tl.load(k_block_ptr, boundary_check=(0, 1))

        # ---- 计算 S_ij = Q @ K^T * scale ----
        # S: [BLOCK_M, BLOCK_N]
        # 使用 Triton 的 dot 操作 (在 Tensor Core 上)
        s_ij = tl.dot(q, tl.trans(k), allow_tf32=False)
        s_ij = s_ij * SCALE  # 除以 √d

        # ---- Online Softmax ----
        # 1. 当前块的 row max
        m_ij = tl.max(s_ij, axis=1)  # [BLOCK_M]

        # 2. 新的全局 row max
        m_new = tl.maximum(m_i, m_ij)  # [BLOCK_M]

        # 3. 计算 exp(S_ij - m_new) → P_ij
        #    注意: m_new 需要沿着 BLOCK_N 维 broadcast
        p_ij = tl.exp(s_ij - m_new[:, None])  # [BLOCK_M, BLOCK_N]

        # 4. rescale factor: exp(m_old - m_new)
        alpha = tl.exp(m_i - m_new)  # [BLOCK_M]

        # 5. 更新 running sum: l_new = alpha * l_old + rowsum(P_ij)
        l_ij = tl.sum(p_ij, axis=1)  # [BLOCK_M]
        l_i = alpha * l_i + l_ij

        # 6. 更新 running output: O_new = alpha * O_old + P_ij @ V_j
        #    先 rescale O_i
        o_i = o_i * alpha[:, None]  # [BLOCK_M, BLOCK_D]

        # ---- 加载 V 块并累积 ----
        v_block_ptr = tl.make_block_ptr(
            base=V_ptr,
            shape=(N, D),
            strides=(stride_vn, stride_vd),
            offsets=(kv_start, 0),
            block_shape=(BLOCK_N, BLOCK_D),
            order=(1, 0),
        )
        v = tl.load(v_block_ptr, boundary_check=(0, 1))

        # O_i += P_ij @ V_j
        # 注意: P_ij 是 [BLOCK_M, BLOCK_N], V 是 [BLOCK_N, BLOCK_D]
        o_i = tl.dot(p_ij.to(tl.float16), v.to(tl.float16),
                     accum_dtype=tl.float32, out_dtype=tl.float32,
                     acc=o_i)

        # 7. 更新 running max
        m_i = m_new

    # ---- 最终归一化: O_i = O_i / l_i ----
    o_i = o_i / l_i[:, None]  # [BLOCK_M, BLOCK_D]

    # ---- 写回 HBM ----
    o_block_ptr = tl.make_block_ptr(
        base=O_ptr,
        shape=(N, D),
        strides=(stride_om, stride_od),
        offsets=(q_start, 0),
        block_shape=(BLOCK_M, BLOCK_D),
        order=(1, 0),
    )
    tl.store(o_block_ptr, o_i.to(tl.float16), boundary_check=(0, 1))

    # ---- 保存 softmax stats (用于 backward) ----
    l_start = pid_m * BLOCK_M
    l_ptr_offset = L_ptr + l_start
    l_block_ptr = tl.make_block_ptr(
        base=L_ptr,
        shape=(N,),
        strides=(1,),
        offsets=(l_start,),
        block_shape=(BLOCK_M,),
        order=(0,),
    )
    tl.store(l_block_ptr, l_i, boundary_check=(0,))

    m_block_ptr = tl.make_block_ptr(
        base=M_ptr,
        shape=(N,),
        strides=(1,),
        offsets=(l_start,),
        block_shape=(BLOCK_M,),
        order=(0,),
    )
    tl.store(m_block_ptr, m_i, boundary_check=(0,))


def flash_attn_triton(q, k, v, scale=None):
    """
    FlashAttention Forward in Triton

    Args:
        q: [batch, nheads, seq, head_dim] (contiguous, fp16/bf16)
        k: [batch, nheads, seq, head_dim]
        v: [batch, nheads, seq, head_dim]
        scale: optional, default 1/sqrt(head_dim)

    Returns:
        o: [batch, nheads, seq, head_dim]
        l: [batch, nheads, seq]  (softmax sum, for backward)
        m: [batch, nheads, seq]  (softmax max, for backward)
    """
    B, H, N, D = q.shape
    assert k.shape == q.shape
    assert v.shape == q.shape

    if scale is None:
        scale = D ** -0.5

    # 分配输出和统计量
    o = torch.empty_like(q)
    l = torch.empty(B, H, N, dtype=torch.float32, device=q.device)
    m = torch.empty(B, H, N, dtype=torch.float32, device=q.device)

    # 块大小选择
    # 对于 A100/SM80+: BLOCK_M=128, BLOCK_N=64 for d=64
    # 需要确保所有块 + 中间结果能放入 SRAM (192KB)
    BLOCK_M = 128
    BLOCK_N = 64
    BLOCK_D = triton.next_power_of_2(D)

    # Grid 配置
    grid = lambda META: (
        B,                                # batch
        H,                                # heads
        triton.cdiv(N, META['BLOCK_M']), # Q blocks
    )

    # 启动 kernel
    _flash_attn_fwd_kernel[grid](
        q, k, v, o, l, m,
        q.stride(0), q.stride(1), q.stride(2), q.stride(3),
        k.stride(0), k.stride(1), k.stride(2), k.stride(3),
        v.stride(0), v.stride(1), v.stride(2), v.stride(3),
        o.stride(0), o.stride(1), o.stride(2), o.stride(3),
        B, H, N, D,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        BLOCK_D=BLOCK_D,
        SCALE=scale,
    )

    return o, l, m


# ---- 测试与验证 ----
def test_flash_attn_triton():
    """测试 Triton FlashAttention 实现"""
    device = torch.device('cuda')
    B, H, N, D = 2, 4, 512, 64
    scale = D ** -0.5

    # 创建随机输入
    torch.manual_seed(42)
    q = torch.randn(B, H, N, D, dtype=torch.float16, device=device)
    k = torch.randn(B, H, N, D, dtype=torch.float16, device=device)
    v = torch.randn(B, H, N, D, dtype=torch.float16, device=device)

    # ---- 参考实现 (PyTorch) ----
    q_ref = q.permute(0, 2, 1, 3)  # [B, N, H, D]
    k_ref = k.permute(0, 2, 1, 3)
    v_ref = v.permute(0, 2, 1, 3)

    # 标准 attention (注意: 这会 OOM 当 N 很大)
    attn_weights = torch.matmul(q_ref, k_ref.transpose(-2, -1)) * scale
    attn_weights = torch.softmax(attn_weights, dim=-1)
    o_ref = torch.matmul(attn_weights, v_ref)
    o_ref = o_ref.permute(0, 2, 1, 3)  # [B, H, N, D]

    # ---- Triton FlashAttention ----
    o_triton, l_triton, m_triton = flash_attn_triton(q, k, v, scale)

    # ---- 验证 ----
    max_diff = torch.abs(o_ref - o_triton).max().item()
    mean_diff = torch.abs(o_ref - o_triton).mean().item()

    print(f"FlashAttention Triton vs PyTorch Reference:")
    print(f"  Max absolute difference: {max_diff:.6f}")
    print(f"  Mean absolute difference: {mean_diff:.6f}")

    # fp16 精度下通常差异在 1e-2 量级 (因为不同的求和顺序)
    if max_diff < 0.1:
        print("  Result: PASS (differences within fp16 tolerance)")
    else:
        print("  Result: FAIL (differences exceed tolerance)")

    return o_ref, o_triton


if __name__ == "__main__":
    test_flash_attn_triton()
```

### 14.2 代码详解：逐行注释

**Block Pointer 设置**：

```python
# Triton 的 block pointer 抽象:
# 自动处理边界检测、偏移计算、内存合并访问

q_block_ptr = tl.make_block_ptr(
    base=Q_ptr,           # 基地址
    shape=(N, D),         # 逻辑张量形状
    strides=(stride_qm, stride_qd),  # 各维度的步长
    offsets=(q_start, 0),            # 起始偏移
    block_shape=(BLOCK_M, BLOCK_D),  # 加载的块大小
    order=(1, 0),                    # 访存顺序: order=(1,0) = row-major
)

# order=(1,0): 最内层维度是维度0 (BLOCK_D), 最外层是维度1 (BLOCK_M)
# 这对应 row-major 内存布局: 同行的 head_dim 元素连续
```

**Online Softmax 状态管理**：

```python
# 初始化: 对 Q 块的每一行独立维护
m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")  # 每行的 max
l_i = tl.zeros([BLOCK_M], dtype=tl.float32)                  # 每行的 sum(exp)
o_i = tl.zeros([BLOCK_M, BLOCK_D], dtype=tl.float32)         # 每行的累积输出

# 每次内循环迭代:
# 1. 计算新块的 max → m_ij
# 2. 新的全局 max = max(m_i, m_ij)
# 3. rescale factor = exp(m_i - m_new)
#    - 如果 m_new == m_i (不变), alpha = exp(0) = 1 → 无 rescale
#    - 如果 m_new > m_i (新 max), alpha = exp(负数) < 1 → 旧值缩小
# 4. l_new = alpha * l_i + rowsum(exp(S_ij - m_new))
# 5. O_new = alpha * O_i + P_ij @ V_j
```

**Rescaling Logic 详解**：

```
假设我们处理序列 [2, 5, 1, 8, 3]，按块 [2, 5] 和 [1, 8, 3] 处理:

块1: [2, 5]
  m = 5, l = exp(2-5) + exp(5-5) = exp(-3) + exp(0) ≈ 0.050 + 1.000 = 1.050

块2: [1, 8, 3]
  m_new = max(5, 8) = 8
  alpha = exp(5 - 8) = exp(-3) ≈ 0.050

  rescale: l = 0.050 × 1.050 = 0.0525
  新累加: l += exp(1-8) + exp(8-8) + exp(3-8)
            = exp(-7) + exp(0) + exp(-5)
            ≈ 0.001 + 1.000 + 0.007 = 1.008
  l_new = 0.0525 + 1.008 = 1.0605

验证 (标准方法):
  m = 8, l = exp(2-8) + exp(5-8) + exp(1-8) + exp(8-8) + exp(3-8)
    = exp(-6) + exp(-3) + exp(-7) + exp(0) + exp(-5)
    ≈ 0.0025 + 0.0498 + 0.0009 + 1.000 + 0.0067 = 1.0599

差异来自浮点累积误差，在 fp32 精度下可忽略。
```

---

## 15. 与 AI Infra 的关联

### 15.1 Attention 是长上下文 LLM 推理的瓶颈

在 LLM 推理的整个 pipeline 中，attention 计算是最关键的环节之一：

```
LLM 推理的两个阶段:

1. Prefill (首次处理):
   ┌─────────────────────────────────────────────────────────┐
   │ 输入 tokens → Embedding → [Transformer Layers × N]      │
   │                              │                          │
   │                     ┌────────┴────────┐                 │
   │                     │  Attention      │ ← 计算密集型     │
   │                     │  (QKV, FA)      │   需要 FlashAttention
   │                     └────────┬────────┘                 │
   │                              │                          │
   │                     ┌────────┴────────┐                 │
   │                     │  FFN (MLP)      │ ← 计算密集型     │
   │                     └────────┬────────┘                 │
   │                              │                          │
   │                     ... 重复 N_layers ...               │
   └─────────────────────────────────────────────────────────┘

2. Decode (逐 token 生成):
   ┌─────────────────────────────────────────────────────────┐
   │ 单个 token → Embedding → [Transformer Layers × N]       │
   │                              │                          │
   │                     ┌────────┴────────┐                 │
   │                     │  Attention      │ ← 内存密集型!    │
   │                     │  (load KV cache)│   PagedAttention │
   │                     │  瓶颈: HBM 带宽  │   必须优化       │
   │                     └────────┬────────┘                 │
   │                              │                          │
   │                     ┌────────┴────────┐                 │
   │                     │  FFN (MLP)      │ ← 计算密集型     │
   │                     └─────────────────┘                 │
   └─────────────────────────────────────────────────────────┘
```

**实际系统的延迟构成 (Llama-70B, 8K context, A100)**：

```
Decode 阶段每 token 延迟 ≈ 40ms:

  加载模型权重:       ~5ms  (12.5%)
  KV Cache 加载:      ~15ms (37.5%)  ← PagedAttention 优化的目标
  QKV projection:     ~3ms  (7.5%)
  Attention 计算:     ~5ms  (12.5%)
  FFN 计算:           ~10ms (25.0%)
  其他 (norm, etc.):  ~2ms  (5.0%)

KV Cache 加载占解码阶段近 40% 的时间 → 需要高效的分页和加载策略
```

### 15.2 Attention 优化如何实现更大的上下文窗口

```
上下文窗口增长的历史:

2022: GPT-3 (2048 tokens)
      → 标准 Attention, O(N²), 2048² = 4M 元素，可接受

2023: GPT-4 (8K / 32K), Claude (100K)
      → FlashAttention 使得 32K 训练可行
      → PagedAttention 使得 100K+ 推理可行
      → GQA 减少 KV cache 大小

2024: Gemini (1M+), Claude 3 (200K)
      → RingAttention 分布式长序列
      → 连续的 online softmax reduction
      → 多机多卡协同

2025: 更大的上下文窗口
      → FlashAttention-3 FPGA 级别的优化
      → 层级化的 KV cache (Hot/Cold)
      → 基于注意力的稀疏化
```

### 15.3 在 vLLM 等服务系统中的角色

```
vLLM 系统中的 Attention Kernel:

┌────────────────────────────────────────────────────────────┐
│                     vLLM Scheduler                         │
│  (决定哪些请求进入本轮推理，管理 block table 分配)           │
└───────────────────────────┬────────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────────┐
│                 vLLM Model Runner                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Step 1: Prepare inputs                              │  │
│  │  - 拼接所有 active requests 的 input tokens          │  │
│  │  - 构造 block_tables, kv_indices, kv_indptr          │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Step 2: Model forward                               │  │
│  │  for each Transformer layer:                         │  │
│  │    ├── Attention:                                    │  │
│  │    │    ├── Prefill (FlashInfer / FA2)               │  │
│  │    │    └── Decode  (PagedAttention kernel)          │  │
│  │    └── FFN (MLP)                                     │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Step 3: Sampling                                    │  │
│  │  - 从 logits 中采样 next token                        │  │
│  │  - 更新 block table (添加新 token 到 KV cache)        │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────┘
```

**关键指标追踪**：

```
vLLM 性能监控指标:

1. Time to First Token (TTFT):  Prefill 时间
   → 受 FlashAttention 性能影响
   → 优化方向: 更快的 prefill kernel, prefix caching

2. Time Per Output Token (TPOT):  Decode 每 token 时间
   → 受 PagedAttention 内存带宽利用率影响
   → 优化方向: KV cache 量化 (fp8/int8), 更优的分页策略

3. Throughput (tokens/second):
   → 受整体 batch 利用率影响
   → 优化方向: continuous batching, chunked prefill
```

---

## 17. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| FlashAttention | 像"在草稿纸上算完再誊到账本"一样，中间结果留在 SRAM，不写入 HBM | 本文第2节 |
| Online Softmax | 像"边走边更新最高分"一样，不需要看完所有分数就能开始归一化 | 本文第3节 |
| PagedAttention | 像"虚拟内存分页"一样，KV Cache 用非连续的物理块映射到连续的逻辑序列 | 本文第9节 |
| Tiling (分块) | 像"把大蛋糕切成小块逐块吃"一样，把大矩阵切分成能放进 SRAM 的小块 | 本文第2.3节 |
| Memory-Bound | 像"水管太细水流受限"一样，计算单元在等数据，瓶颈是显存带宽而非算力 | 本文第1.4节 |

## 18. A800 部署场景举例

**场景1：A800 上 FlashAttention-2 加速 Qwen-33B 的长上下文 Prefill**

在 2×A800(TP=2) 上部署 Qwen-33B 进行长文档问答（prompt ~8000 tokens）：

```python
import torch
import torch.nn.functional as F

# A800 的 FA2 配置自动选择
with torch.backends.cuda.sdp_kernel(
    enable_flash=True,      # 强制使用 FlashAttention
    enable_math=False,
    enable_mem_efficient=False
):
    # Prefill 阶段: 8000 tokens 一次前向
    output = F.scaled_dot_product_attention(
        q, k, v, is_causal=True
    )

# 预期效果 (A800, head_dim=128, 8000 tokens):
#   Math backend:  ~85 ms (O(N²) 内存，接近 OOM)
#   FlashAttention: ~28 ms (tiling + online softmax, 约 3x 加速)
```

参考本文第2.4节和第5.3节，A800 的 SRAM 为 192KB/SM，block 大小选择 `B_r=128, B_c=128` 可完全容纳于 SRAM。

**场景2：PagedAttention Kernel 在 DeepSeek-67B Decode 阶段的性能剖析**

DeepSeek-67B 使用 GQA（num_kv_heads=8, num_heads=64），单 token decode 时：

```bash
# 使用 Nsight Systems 查看 PagedAttention kernel 的显存带宽利用率
nsys profile --trace=cuda,nvtx \
    python -c "
from vllm import LLM
llm = LLM(model='deepseek-ai/DeepSeek-V2-Lite')
output = llm.generate(['Hello, world!'])
"

# 关键指标:
# - PagedAttention v2 kernel 在 A800 上达到 ~1.5 TB/s HBM 带宽（75% 峰值）
# - GQA ratio=8 意味着每个 KV head 块被 8 个 Q head 复用（见本文第9.4节）
```

## 19. 上下游串联

```
上游 ← 本文档 → 下游

上游：模型结构与推理引擎（Transformer / vLLM Engine）
      Transformer 定义 Attention 层，vLLM Engine 在 scheduler 调度后
      调用 ModelRunner → Attention 层，需要选择 Prefill 或 Decode kernel。

下游：CUDA/CUTLASS/Triton Kernel 实现层
      本文档教的 FlashAttention 算法 (tiling + online softmax) 在工程上
      由 CUTLASS(手写 CUDA) 或 Triton(DSL 编译) 实现为具体的 GPU kernel。

完整链路参考：end-to-end-inference-trace.md
  Transformer Layer → Attention OP → [Prefill: FlashAttention / Decode: PagedAttention] →
  CUTLASS/CUDA Kernel → Tensor Core MMA → GPU HBM ←→ SRAM tiling
```

---
---
## 16. 深入学习资源

### 16.1 论文

| 论文 | 链接 | 核心贡献 |
|------|------|---------|
| **FlashAttention** (NeurIPS 2022) | https://arxiv.org/abs/2205.14135 | Tiling + Online Softmax, IO-aware 算法 |
| **FlashAttention-2** (2023) | https://arxiv.org/abs/2307.08691 | 序列维并行, Causal 优化, 减少非 GEMM 操作 |
| **FlashAttention-3** (2024) | https://arxiv.org/abs/2407.08608 | Hopper TMA, FP8, Warp Specialization, Async |
| **PagedAttention** (SOSP 2023) | https://arxiv.org/abs/2309.06180 | 虚拟内存分页思想用于 KV Cache |
| **FlashDecoding** (2023) | https://crfm.stanford.edu/2023/10/12/flashdecoding.html | 长序列解码并行化 |
| **Block-Sparse FlashAttention** | FlashAttention repo 内部 | 稀疏 Attention 模式 |
| **xFormers** | https://arxiv.org/abs/2202.08906 (参考) | Memory-efficient attention 早期工作 |

### 16.2 代码仓库

```
核心仓库:

1. FlashAttention (Tri Dao 官方)
   https://github.com/Dao-AILab/flash-attention
   - C++/CUDA 实现 (使用 CuTe)
   - 支持 FA1, FA2, FA3
   - 反向传播实现
   - 关键文件:
     flash_attn/flash_attn_interface.py       ← Python API
     csrc/flash_attn/src/flash_fwd_kernel.h   ← Forward kernel (CuTe)
     csrc/flash_attn/src/flash_bwd_kernel.h   ← Backward kernel

2. vLLM
   https://github.com/vllm-project/vllm
   - PagedAttention 实现
   - 关键文件:
     vllm/attention/ops/paged_attn.py         ← Python wrapper
     csrc/attention/paged_attention_v1.cu     ← v1 CUDA kernel
     csrc/attention/paged_attention_v2.cu     ← v2 CUDA kernel
     csrc/cache_kernels.cu                    ← KV cache 管理

3. FlashInfer
   https://github.com/flashinfer-ai/flashinfer
   - 专门的 LLM 推理 attention kernel
   - Prefill, Decode, Append kernels
   - GQA, RoPE, Paged KV cache 支持
   - 关键文件:
     flashinfer/prefill.py                    ← Prefill API
     flashinfer/decode.py                     ← Decode API
     include/flashinfer/attention/            ← CUDA headers

4. xFormers
   https://github.com/facebookresearch/xformers
   - Memory-efficient attention (早期版本)
   - 关键文件:
     xformers/ops/fmha/                       ← Flash Attention 实现
     xformers/components/attention/csrc/      ← CUDA kernels

5. Triton FlashAttention Tutorial
   https://github.com/triton-lang/triton/tree/main/python/tutorials
   - 06-fused-attention.py                    ← Triton FA 教程
   - 学习 Triton 实现的最佳起点

6. CUTLASS
   https://github.com/NVIDIA/cutlass
   - NVIDIA 官方的 CUDA C++ 模板库
   - 高效 GEMM, Attention kernels
   - examples/ 下有 attention 示例
```

### 16.3 教程与博客

```
推荐阅读顺序:

入门级:
  1. "The Illustrated Transformer" - Jay Alammar
     → 理解 Attention 机制的基础

  2. "Making Deep Learning Go Brrr" - Horace He
     → GPU 性能分析入门

  3. Triton 官方教程: 06-fused-attention.py
     → FlashAttention 的 Triton 实现

进阶级:
  4. "FlashAttention: Fast and Memory-Efficient Exact Attention"
     → Tri Dao 的论文讲解视频 (YouTube @ Stanford MLSys)

  5. "How FlashAttention Works" - Umar Jamil YouTube 视频
     → 从数学推导到代码实现

  6. vLLM Blog: "vLLM: Easy, Fast, and Cheap LLM Serving"
     → PagedAttention 的工程实现细节

深入级:
  7. "Dissecting the A100 GPU Architecture" - NVIDIA
     → 理解 GPU 内存层次的硬件基础

  8. "CUTLASS: Fast Linear Algebra in CUDA C++" - NVIDIA
     → 理解底层 GEMM 实现

  9. FlashAttention-3 论文 - Section 3-5 (Kernel Design)
     → 最新的 GPU kernel 优化技术
```

### 16.4 推荐的动手实践路径

```
路径 1: 从理论到实践
  Week 1: 阅读 Attention 基础 + 实现标准 Attention
  Week 2: 手写 Online Softmax + 验证正确性
  Week 3: Triton FlashAttention tutorial 学习
  Week 4: 在不同的序列长度/head_dim 上 benchmark 对比

路径 2: 从使用到源码
  Week 1: 使用 PyTorch SDPA + FlashAttention 做 benchmark
  Week 2: Reading flash-attention 源码 (CuTe 部分)
  Week 3: Reading vLLM PagedAttention kernel
  Week 4: 尝试修改 block size 并观察性能变化

路径 3: 系统集成视角
  Week 1: 搭建 vLLM 环境, 运行 benchmark
  Week 2: 研究 PagedAttention 与 FlashAttention 的关系
  Week 3: 阅读 FlashInfer 源码, 理解 Prefill/Decode 分离
  Week 4: 尝试将 FlashAttention-3 集成到 vLLM
```

---

> **本文档定位**: 系统性理解 Attention Kernel 优化技术的完整指南，覆盖从数学原理到工业实现的全链路知识。建议配合代码实践阅读，对每个概念进行 benchmark 验证，加深理解。Attention Kernel 优化仍在快速发展中 (FlashAttention-4 已在路上)，持续跟踪最新论文和开源实现是保持技术前沿的关键。
