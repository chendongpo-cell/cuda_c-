# CUDA Kernel 深度剖析

> 本文档深入解析 CUDA Kernel 开发的方方面面，从硬件架构到性能优化，结合 A100/H100 的真实数据，旨在为 AI Infra 工程师提供完整的内核开发知识体系。

---

## CUDA Kernel 解剖学

### Grid、Block、Thread 层次结构

CUDA 的编程模型建立在一个三维的线程层次结构之上。理解这个层次结构是写出高效 Kernel 的第一步。

```
+------------------------------------------------------------------+
|                            GRID                                   |
|  +----------------------------+  +----------------------------+  |
|  |          BLOCK (0,0)       |  |          BLOCK (1,0)       |  |
|  |  +----+ +----+ +----+     |  |  +----+ +----+ +----+     |  |
|  |  |Warp| |Warp| |Warp| ... |  |  |Warp| |Warp| |Warp| ... |  |
|  |  | 0  | | 1  | | 2  |     |  |  | 0  | | 1  | | 2  |     |  |
|  |  +----+ +----+ +----+     |  |  +----+ +----+ +----+     |  |
|  |  [T0..T31]  [T32..T63]    |  |  [T0..T31]  [T32..T63]    |  |
|  +----------------------------+  +----------------------------+  |
|  +----------------------------+  +----------------------------+  |
|  |          BLOCK (0,1)       |  |          BLOCK (1,1)       |  |
|  |         ...                |  |         ...                |  |
|  +----------------------------+  +----------------------------+  |
+------------------------------------------------------------------+
```

**层次关系：**

```
Thread  (线程)     : 最小的执行单元，每个线程执行同一个 Kernel 函数
  └── Warp  (线程束) : 32 个线程为一组，以 SIMT 模式同步执行
       └── Block (线程块) : 最多 1024 个线程，共享 Shared Memory
            └── Grid  (网格)  : 所有 Block 的集合，构成一次 Kernel Launch
```

### Block 到 SM 的映射

```
+----------------------------------------------------------+
|                      GPU (A100)                           |
|  +------------------+  +------------------+              |
|  |    SM 0          |  |    SM 1          |    ...       |
|  |  +------------+  |  |  +------------+  |              |
|  |  | Block 0    |  |  |  | Block 32   |  |              |
|  |  | Block 16   |  |  |  | Block 48   |  |              |
|  |  | (pending)  |  |  |  | (pending)  |  |              |
|  |  +------------+  |  |  +------------+  |              |
|  +------------------+  +------------------+              |
|                                                          |
|  A100: 108 个 SM，每个 SM 最多驻留 32 个 Block            |
|  每个 SM 最多 2048 个线程 = 64 个 Warp                    |
+----------------------------------------------------------+
```

**映射规则：**
- 一个 Block 只能在一个 SM 上执行（不能跨 SM）
- 一个 SM 可以同时驻留多个 Block（并发执行）
- Block 被分配到 SM 的策略由硬件调度器决定，轮询分配

### SIMT 执行模型

SIMT (Single Instruction, Multiple Thread) 是 CUDA 的核心执行模型：

```
时间轴 ──────────────────────────────────────────────>

Warp 0 (32 threads):
  [指令1] [指令2] [指令3 (load)] [──── stall ────] [指令4] ...
    │       │         │              (等待内存)      │
    ▼       ▼         ▼                             ▼
  所有32   所有32    所有32                       所有32
  个线程   个线程    个线程                       个线程
  同时执   同时执    同时执                       同时执
  行       行        行                           行

Warp 1 (32 threads):  (SM 在 Warp 间快速切换)
  [──── stall ────] [指令1] [指令2] [指令3] ...
```

**关键特性：**
- 一个 Warp 内的 32 个线程同时执行同一条指令（锁步）
- 分支发散 (Branch Divergence) 会导致部分线程空闲
- SM 通过在 Warp 之间快速切换来隐藏内存延迟

```cuda
// 分支发散示例
__global__ void branch_divergence_demo(float* data, int n) {
    int tid = threadIdx.x;
    // 如果 tid % 2 == 0 走 if 分支，else 分支的线程等待
    // 同一 Warp 内两个分支都执行，但各自只有一半线程活跃
    if (tid % 2 == 0) {
        data[tid] = data[tid] * 2.0f;   // 16 threads active
    } else {
        data[tid] = data[tid] / 2.0f;   // 16 threads active
    }
    // 总执行时间 ≈ 两个分支之和，有效利用率 50%
}
```

---

## 内存访问模式

### 合并访问 vs 跨步访问

GPU 的全局内存 (Global Memory / HBM) 带宽虽然很高（A100 约 2 TB/s），但延迟也很大（~300-800 cycles）。为了高效利用带宽，必须以合并 (Coalesced) 方式访问。

```
合并访问 (Coalesced) - 行主序:
  Memory Address:  | 0 | 4 | 8 | 12 | 16 | 20 | 24 | 28 | ...
                    |   |   |   |    |    |    |    |    |
  Thread:           T0  T1  T2  T3   T4   T5   T6   T7  ...
  一次 128-byte transaction 服务 32 个线程 (每个 float 4 bytes)

跨步访问 (Strided) - 列主序:
  Memory Address:  | 0 | 4 | 8 | 12 | ... | 1024 | 1028 | 1032 | ...
                    |                               |
  Thread:           T0                              T1
  每个线程访问的地址间隔很大 → 多次 transaction，带宽利用率极低
```

```cuda
// 合并访问：行优先遍历矩阵
__global__ void row_major_access(const float* A, float* B, int N) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < N && col < N) {
        // 同一 Warp 内 threadIdx.x 连续变化
        // T0 访问 a[row*N+0], T1 访问 a[row*N+1] ...
        // 地址连续 → 完美合并访问
        B[row * N + col] = A[row * N + col] * 2.0f;
    }
}

// 跨步访问：列优先遍历矩阵
__global__ void col_major_access(const float* A, float* B, int N) {
    int row = blockIdx.x * blockDim.x + threadIdx.x;  // 注意：行列交换
    int col = blockIdx.y * blockDim.y + threadIdx.y;
    if (row < N && col < N) {
        // 同一 Warp 内 row 连续变化
        // T0 访问 a[0*N+col], T1 访问 a[1*N+col] ...
        // 地址间隔 = N*4 bytes → N 次 transaction
        int idx = row * N + col;
        B[idx] = A[idx] * 2.0f;
    }
}
```

### Global Memory Transaction 大小

GPU 的 L2 缓存行是 32 bytes，但一次 Global Memory 的 transaction 大小取决于访问模式：

```
Transaction 大小 (取决于 GPU 架构和访问模式):

  对齐 & 合并访问:
  +-------+-------+-------+-------+
  | 32B   | 32B   | 32B   | 32B   |  → 一次 128B transaction (A100)
  +-------+-------+-------+-------+
  T0..T7  T8..T15 T16..T23 T24..T31
  (每个线程访问 4 bytes → 共 128 bytes)

  非对齐或非合并访问:
  +---+---+---+---+---+---+---+---+
  |4B |4B |4B |4B |4B |4B |4B |4B |  → 可能退化到 8 次 32B transaction
  +---+---+---+---+---+---+---+---+
  最坏情况: 带宽利用率仅 12.5% (128B 需要 8 次 32B transaction)
```

**实测性能对比（A100，单精度浮点）：**

| 访问模式 | 有效带宽 | 利用率 | 说明 |
|---------|---------|-------|------|
| 合并读/写 | ~1.8 TB/s | ~90% | 接近峰值带宽 |
| 跨步 (stride=2) | ~900 GB/s | ~45% | 一半 transaction 被浪费 |
| 跨步 (stride=16) | ~120 GB/s | ~6% | 严重退化 |
| 完全随机 | ~10 GB/s | ~0.5% | L2 cache miss + 多次 transaction |

```cuda
// 测量实际带宽的微基准测试
__global__ void bandwidth_test(
    const float* __restrict__ src,
    float* __restrict__ dst,
    int N, int stride)
{
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    // stride=1: 合并访问; stride>1: 跨步访问
    int idx = tid * stride;
    if (idx < N) {
        dst[idx] = src[idx];
    }
}
// 使用 cudaEvent 计时:
// effective_bandwidth = (2 * N * sizeof(float)) / elapsed_time
// 乘以 2 是因为读+写
```

---

## Shared Memory 的 Bank Conflict

### 32 Banks 架构

Shared Memory 被组织为 32 个 Bank，每个 Bank 宽度 4 bytes。同一个 Warp 内多个线程访问同一个 Bank 的不同地址会导致 Bank Conflict。

```
Shared Memory Bank 结构 (32 banks × 4 bytes = 128 bytes/cycle):

  Bank 0    Bank 1    Bank 2    ...  Bank 31
  +----+    +----+    +----+         +----+
  | 0  |    | 4  |    | 8  |   ...   |124 |
  +----+    +----+    +----+         +----+
  |128 |    |132 |    |136 |   ...   |252 |
  +----+    +----+    +----+         +----+
  |256 |    |260 |    |264 |   ...   |380 |
  +----+    +----+    +----+         +----+
  |... |    |... |    |... |         |... |
  +----+    +----+    +----+         +----+

  地址 % 128 决定所属 Bank: bank_id = (byte_address / 4) % 32
```

### N-way Bank Conflict 可视化

```
无冲突 (1-way) — 每个线程访问不同 Bank:
  T0  T1  T2  T3  ... T31
  ↓   ↓   ↓   ↓       ↓
  B0  B1  B2  B3  ... B31    ← 一次广播完成，1 cycle

2-way Conflict — 两个线程访问同一 Bank 的不同地址:
  T0  T1  T2  T3  ... T31
  ↓   ↓   ↓   ↓       ↓
  B0  B0  B2  B3  ... B31
   \ /
  冲突! → 需要 2 cycles: 先服务 T0，再服务 T1

32-way Conflict — 所有线程访问同一 Bank:
  T0  T1  T2  ...  T31
   \   |   |        /
    \  |   |       /
     v v   v      v
       Bank 0 (32 个不同地址)
  → 需要 32 cycles，Shared Memory 优势完全丧失
```

### Padding 策略

通过在 Shared Memory 数组末尾添加 padding，可以消除 Bank Conflict：

```cuda
// 无 Padding — 典型的 Transpose Kernel, 32×32 tile
// threadIdx.x 访问 smem[threadIdx.y][threadIdx.x]
// 同一 Warp 的 32 个线程有相同的 threadIdx.y，不同的 threadIdx.x
// 读的时候: 所有线程访问同一列的不同行 → 32-way conflict!
__global__ void transpose_naive(const float* A, float* B, int N) {
    __shared__ float tile[32][32];  // 32 × 32 = 1024 floats

    int x = blockIdx.x * 32 + threadIdx.x;
    int y = blockIdx.y * 32 + threadIdx.y;

    // 合并读取 (行访问) — 无 conflict
    tile[threadIdx.y][threadIdx.x] = A[y * N + x];
    __syncthreads();

    // 这个写操作 — 同 Warp 内 threadIdx.x 不同
    // 但所有线程的 threadIdx.y 相同 (同一 Warp)
    // 此处写 tile[threadIdx.x][threadIdx.y]:
    // T0 写 tile[0][ty], T1 写 tile[1][ty], T2 写 tile[2][ty] ...
    // 4-byte  stride = 32*4 = 128 bytes
    // bank_id = (128 / 4) % 32 = 0 !!
    // 32 个线程全访问 Bank 0 → 32-way conflict!
    B[threadIdx.y * N + threadIdx.x] = tile[threadIdx.x][threadIdx.y];
}

// 有 Padding — 消除 Bank Conflict
__global__ void transpose_padded(const float* A, float* B, int N) {
    __shared__ float tile[32][32 + 1];  // 关键: 32+1 = 33
    //                        ^^^^ padding 1 column!
    // 现在 stride = 33*4 = 132 bytes
    // bank_id = (132 / 4) % 32 = 33 % 32 = 1
    // T0 → Bank 1, T1 → Bank 2, T2 → Bank 3 ...
    // 所有线程访问不同 Bank → 1 cycle!

    int x = blockIdx.x * 32 + threadIdx.x;
    int y = blockIdx.y * 32 + threadIdx.y;

    tile[threadIdx.y][threadIdx.x] = A[y * N + x];
    __syncthreads();

    // 现在访问 tile[threadIdx.x][threadIdx.y] 无 conflict
    B[threadIdx.y * N + threadIdx.x] = tile[threadIdx.x][threadIdx.y];
}
```

**实测性能对比 (A100, 4096×4096 矩阵转置)：**

| 实现 | 有效带宽 | Shared Memory Throughput | 说明 |
|-----|---------|------------------------|------|
| Naive (32×32) | ~450 GB/s | ~60% | 32-way bank conflict |
| Padded (32×33) | ~1.1 TB/s | ~95% | Padding 消除 conflict |

---

## Warp-Level 编程

### Warp Shuffle 指令

Warp Shuffle 允许同一 Warp 内的线程直接交换寄存器值，无需通过 Shared Memory。延迟极低 (~1 cycle)。

```cuda
// __shfl_sync: 从指定线程广播值
// 掩码 0xffffffff 表示所有 32 个线程都参与
float val = __shfl_sync(0xffffffff, data, src_lane);

// __shfl_down_sync: 将值从高 lane 号线程复制到低 lane 号
// delta=1: T0 得到 T1 的值, T1 得到 T2 的值, ...
float val = __shfl_down_sync(0xffffffff, data, delta);

// __shfl_xor_sync: 按 XOR 交换值
// lane_mask=1: 相邻线程两两交换
float val = __shfl_xor_sync(0xffffffff, data, lane_mask);
```

### Warp Reduce (蝴蝶归约)

使用 `__shfl_down_sync` 实现高效的 Warp 内归约：

```
Warp Reduce 蝴蝶模式 (8 线程示例, 实际为 32):

Step 0 (初始状态):
  T0: v0   T1: v1   T2: v2   T3: v3   T4: v4   T5: v5   T6: v6   T7: v7

Step 1: __shfl_down_sync(mask, val, 4)
  T0: v0+v4   T1: v1+v5   T2: v2+v6   T3: v3+v7   T4: v4   T5: v5   T6: v6   T7: v7

Step 2: __shfl_down_sync(mask, val, 2)
  T0: sum(v0,v4,v2,v6)   T1: sum(v1,v5,v3,v7)   T2: ...   T3: ...  (T4-T7 不参与)

Step 3: __shfl_down_sync(mask, val, 1)
  T0: total_sum (所有 8 个值之和)
```

```cuda
// 完整的 Warp Reduce 实现
__inline__ __device__ float warp_reduce_sum(float val) {
    #pragma unroll
    for (int offset = 16; offset > 0; offset /= 2) {
        val += __shfl_down_sync(0xffffffff, val, offset);
    }
    return val;  // 只有 lane 0 持有完整结果
}

// 使用示例：计算一行内的和
__global__ void row_sum_kernel(const float* input, float* output, int N) {
    int row = blockIdx.x;
    int tid = threadIdx.x;
    float val = (tid < N) ? input[row * N + tid] : 0.0f;
    float sum = warp_reduce_sum(val);
    if (tid == 0) output[row] = sum;
}
```

### __ballot_sync: Warp 级条件求值

```cuda
// __ballot_sync 返回一个 32-bit 掩码，每个 bit 表示对应线程的条件是否为 true
__global__ void ballot_demo(const float* data, int* result, int N) {
    int tid = threadIdx.x + blockIdx.x * blockDim.x;
    float val = (tid < N) ? data[tid] : 0.0f;

    // 检查哪些线程的值大于阈值
    unsigned mask = __ballot_sync(0xffffffff, val > 0.5f);

    // __popc 统计 mask 中的 1 的个数 (即满足条件的线程数)
    int count = __popc(mask);

    // 原子累加到全局计数器
    if (tid % 32 == 0) {  // 每个 Warp 的第一个线程执行原子操作
        atomicAdd(result, count);
    }
}
```

### __match_any_sync / __match_all_sync

```cuda
// __match_any_sync: 返回与自己值相同的所有线程的掩码
// 可用于快速分组、哈希表查找等场景
__global__ void match_demo(const int* keys, int* groups) {
    int key = keys[threadIdx.x];
    // 返回 Warp 内所有 key==my_key 的线程掩码
    unsigned mask = __match_any_sync(0xffffffff, key);
    // mask 中为 1 的 bit 对应相同 key 的线程
    groups[threadIdx.x] = mask;
}

// __match_all_sync: 只有当 Warp 内所有线程的值相同时才返回有效掩码
// 常用于全局 barrier、一致性检查
unsigned mask = __match_all_sync(0xffffffff, key, &predicate);
// 如果所有线程 key 相同, predicate=1, mask=0xffffffff
// 否则 predicate=0, mask 无效
```

---

## Tensor Core 编程深度剖析

### mma.sync 指令 (PTX 级别)

Tensor Core 是 NVIDIA Volta 架构引入的专用矩阵乘法加速器。以 A100 上的 FP16 Tensor Core 为例：

```
mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32
  |    |       |       |   |   |   |   |   |   |
  |    |       |       |   |   |   |   |   |   +-- D 类型 (float32 累加器)
  |    |       |       |   |   |   |   |   +------ C 类型 (float32)
  |    |       |       |   |   |   |   +---------- B 类型 (half/FP16)
  |    |       |       |   |   |   +-------------- A 类型 (half/FP16)
  |    |       |       |   |   +------------------ D (输出) 精度
  |    |       |       |   +---------------------- b 的布局 (col-major)
  |    |       |       +-------------------------- a 的布局 (row-major)
  |    |       +---------------------------------- m16n8k16 (矩阵形状)
  |    +------------------------------------------ 对齐要求
  +----------------------------------------------- 同步 Warp 内所有线程
```

**Tensor Core 矩阵形状：**

```
A (M×K):        B (K×N):         C/D (M×N):
  k=16             n=8               n=8
  +--------+       +----+            +----+
m |  FP16  |     k |    |          m |    |
  | matrix |       |FP16|            |FP32|
16|        |     16|    |          16|    |
  +--------+       +----+            +----+

D = A × B + C  (一次 mma.sync 指令完成 16×8×16 = 2048 次乘加)
```

**每个线程持有的 Fragment：**

```
每个 Warp (32 threads) 协作完成一个 16×8×16 的 MMA:

A fragment (线程持有):     B fragment:            C/D fragment:
每个线程 4 个 f16          每个线程 2 个 f16      每个线程 4 个 f32
(共 32×4=128 halfs)       (共 32×2=64 halfs)     (共 32×4=128 floats)
```

### WMMA API vs mma.sync 对比

```cpp
// ============ WMMA API (高层抽象) ============
#include <cuda_fp16.h>
#include <mma.h>
using namespace nvcuda;

__global__ void wmma_gemm(const half* A, const half* B, float* C,
                          int M, int N, int K) {
    // 声明 fragment
    wmma::fragment<wmma::matrix_a, 16, 16, 16, half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, 16, 16, 16, half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, 16, 16, 16, float> c_frag;

    // 加载矩阵 tile
    wmma::load_matrix_sync(a_frag, A + ..., 16);   // lda = 16
    wmma::load_matrix_sync(b_frag, B + ..., 16);
    wmma::fill_fragment(c_frag, 0.0f);

    // 执行乘加
    wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);

    // 存储结果
    wmma::store_matrix_sync(C + ..., c_frag, 16, wmma::mem_row_major);
}
// 优点: 易用，可移植
// 缺点: 固定 tile 大小 (16×16×16)，无法精细控制数据流


// ============ mma.sync (PTX 内联汇编) ============
#include <cuda/barrier>
#include <cuda/ptx>

__global__ void mma_sync_gemm(const half* A, const half* B, float* C,
                               int M, int N, int K) {
    // 每个 Warp 处理 64×64 的 tile
    // 需要循环调用 mma.sync 完成

    // 寄存器中存储 fragment
    uint32_t a_frag[4];  // 4 个 f16x2 (8 个 half)
    uint32_t b_frag[2];  // 2 个 f16x2 (4 个 half)
    float    c_frag[4];  // 4 个 float
    float    d_frag[4];  // 4 个 float

    // 使用内联 PTX 调用 mma.sync
    asm volatile(
        "mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 "
        "{%0, %1, %2, %3}, {%4, %5, %6, %7}, {%8, %9}, {%10, %11, %12, %13};\n"
        : "=f"(d_frag[0]), "=f"(d_frag[1]), "=f"(d_frag[2]), "=f"(d_frag[3])
        : "r"(a_frag[0]), "r"(a_frag[1]), "r"(a_frag[2]), "r"(a_frag[3]),
          "r"(b_frag[0]), "r"(b_frag[1]),
          "f"(c_frag[0]), "f"(c_frag[1]), "f"(c_frag[2]), "f"(c_frag[3])
    );
}
// 优点: 完全控制，支持任意 tile 大小，更高吞吐
// 缺点: 复杂度极高，需要手动管理寄存器分配
```

### 数据布局要求

```
FP16 Tensor Core (A100/H100):
  m16n8k16: A(16×16) f16, B(16×8) f16, C(16×8) f32
  ─────────────────────────────────────────────────────
  典型 layout:
    A: row-major, B: col-major
    或
    A: col-major, B: row-major
  ─────────────────────────────────────────────────────
  对齐要求: 16-byte 对齐
  每个 Warp 负责 16×8 (M×N) 的结果子矩阵

INT8 Tensor Core (A100/H100):
  m16n8k32: A(16×32) int8, B(32×8) int8, C(16×8) int32
  吞吐是 FP16 的 2 倍

TF32 Tensor Core (A100):
  m16n8k8: A(16×8) tf32, B(8×8) tf32, C(16×8) f32
  TF32 是 19-bit 格式: 1 sign + 8 exponent + 10 mantissa
  精度介于 FP16 和 FP32 之间，无需改代码即可加速训练

FP8 Tensor Core (H100, H200):
  m16n8k32: A(16×32) fp8, B(32×8) fp8, C(16×8) f32
  吞吐是 FP16 的 2 倍 (H100 达 1979 TFLOPS FP8)
```

### Tensor Core vs CUDA Core 性能对比

```
                    A100 SXM (80GB)
  ┌────────────────────────────────────────────────┐
  │ 计算吞吐 (TFLOPS):                              │
  │                                                 │
  │  FP32  (CUDA Core):  ████████ 19.5              │
  │  FP16  (CUDA Core):  ████████████████████ 78    │
  │  TF32  (TensorCore): ████████████████████████████████████████████████████████████████ 156   │
  │  FP16  (TensorCore): ████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████ 312   │
  │  INT8  (TensorCore): ████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████ 624   │
  │  FP16  sparse (2:4): ██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████ 624   │
  │                                                 │
  │  H100 SXM:                                      │
  │  FP8   (TensorCore): ████████████████████████████████████████████████████████████████████ 1979  │
  │  FP16  (TensorCore): ███████████████████████████████████████████████████████████████████████████████████████ 990   │
  └────────────────────────────────────────────────┘
```

**关键结论：** Tensor Core 的 FP16 吞吐是 CUDA Core FP32 的 16 倍。这就是为什么几乎所有 AI 推理/训练框架都优先使用 Tensor Core。

### 2:4 结构化稀疏性

```
2:4 Structured Sparsity (Ampere+ 架构):

原始权重向量 (4 个元素):
  [w0  w1  w2  w3]

稀疏化后 (每 4 个值中至少 2 个为 0):
  [w0   0   0  w3]  ← 只有 2 个非零值
  保留  剪枝 剪枝 保留

  或
  [0  w1   0  w3]  ← 其他模式也可以，只要是 2:4 即可

压缩存储:
  原始: [w0  w1  w2  w3  w4  w5  w6  w7]  (8 values)
  稀疏: [w0  w3  |  w4  w7]  (4 values + 2-bit index)
         idx:0,3    idx:0,3

  对于 FP16: 8 elements × 2 bytes = 16 bytes original
  稀疏化后: 4 elements × 2 bytes + 2-bit index = ~8.25 bytes
  压缩比接近 2x，同时 Tensor Core 吞吐也翻倍

实现方式:
  - 训练后剪枝 + 微调
  - 稀疏感知训练 (Sparse-MoE, SparseGPT 等)
  - NVIDIA ASP (Automatic Sparsity) 工具
```

---

## 异步执行

### cp.async: 异步拷贝 Global → Shared Memory

`cp.async` 是 Ampere (SM80) 引入的关键特性，允许在不占用 CUDA Core 的情况下，将数据从 Global Memory 异步拷贝到 Shared Memory。

```
传统同步加载:
  CUDA Core:  [load] [stall ─── 等待 ───] [compute] ...
                              ↑
                        浪费计算单元等待内存

cp.async 异步加载:
  Load Engine:  [cp.async ────── 加载中 ──────] [cp.async ── ...]
  CUDA Core:    [compute stage 0] [compute stage 1] [compute stage 2] ...
                              ↑
                        计算和加载完全重叠
```

```cuda
// cp.async 基本用法
#include <cuda/barrier>
#include <cuda/ptx>

__global__ void async_copy_kernel(const float* global_data,
                                   float* output, int N) {
    __shared__ alignas(16) float smem[1024];

    int tid = threadIdx.x;
    int gid = blockIdx.x * blockDim.x + tid;

    // cp.async 加载 16 bytes (4 floats) 到 Shared Memory
    // 每个线程负责 16 bytes
    if (gid * 4 < N) {
        asm volatile(
            "cp.async.ca.shared.global [%0], [%1], 16;\n"
            :
            : "r"(static_cast<unsigned>(__cvta_generic_to_shared(&smem[tid * 4]))),
              "l"(&global_data[gid * 4])
        );
    }

    // 提交 cp.async 组并等待完成
    asm volatile("cp.async.commit_group;\n" ::);
    asm volatile("cp.async.wait_group 0;\n" ::);
    __syncthreads();

    // 现在使用 smem 中的数据计算...
    output[gid] = smem[tid];
}
```

### Async Pipeline: 多阶段生产者-消费者

```
Async Pipeline (3 stages, Double Buffering):

时间 ──────────────────────────────────────────────>

Stage 0 (Buffer A):  [load A0] [── compute A0 ──]
Stage 1 (Buffer B):            [load B1] [── compute B1 ──]
Stage 2 (Buffer A):                      [load A2] [── compute A2 ──]
Stage 3 (Buffer B):                                  [load B3] ...

  load 和 compute 完全重叠!
  理想情况: 计算时间完全隐藏加载延迟
```

```cuda
// 多阶段异步 Pipeline (使用 cuda::pipeline API)
#include <cuda/pipeline>

__global__ void gemm_async_pipeline(
    const half* A, const half* B, float* C,
    int M, int N, int K)
{
    constexpr int Stages = 4;  // 4 阶段 pipeline (quad buffering)

    __shared__ half As[Stages][128][128];  // 4 个 tile buffer
    __shared__ half Bs[Stages][128][128];

    // 创建 pipeline 对象
    auto pipe = cuda::make_pipeline();

    // Prologue: 预加载前几个 stage
    for (int s = 0; s < Stages - 1; ++s) {
        cuda::memcpy_async(As[s][threadIdx.y][threadIdx.x],
                          &A[... + s * 128 * K],  // 第 s 个 tile
                          sizeof(half) * 128, pipe);
        cuda::memcpy_async(Bs[s][threadIdx.y][threadIdx.x],
                          &B[... + s * 128 * K],
                          sizeof(half) * 128, pipe);
    }
    pipe.commit();  // 提交所有预加载

    // Main loop
    for (int k = 0; k < K; k += 128) {
        pipe.wait_prior<Stages - 2>();  // 等待之前的 stage 完成

        int load_idx = (k / 128 + Stages - 1) % Stages;
        int comp_idx = (k / 128) % Stages;

        // 同时: 预取下一个 tile
        if (k + 128 * (Stages - 1) < K) {
            cuda::memcpy_async(As[load_idx][...], &A[...], ..., pipe);
            cuda::memcpy_async(Bs[load_idx][...], &B[...], ..., pipe);
            pipe.commit();
        }

        // 同时: 计算当前 tile
        // ... 使用 As[comp_idx], Bs[comp_idx] 做矩阵乘法
        // ... mma.sync 或 WMMA 操作

        pipe.wait_prior<Stages - 1>();  // 确保当前 tile 已加载完成
    }
}
```

### Pipeline Memory Barrier

```
cp.async.commit_group 和 cp.async.wait_group 的机制:

  commit_group N:     标记当前 "组" 的结束
  commit_group N+1:   标记下一个组的结束
  wait_group M:       等待除了最近的 M 个组之外的所有组完成

示例:
  cp.async ...         ─┐
  cp.async ...          ├─ Group 0
  cp.async.commit_group ─┘
  cp.async ...         ─┐
  cp.async ...          ├─ Group 1
  cp.async.commit_group ─┘
  cp.async ...         ─┐
  cp.async ...          ├─ Group 2
  cp.async.commit_group ─┘

  cp.async.wait_group 1;  ← 等待除了最近 1 个组之外的所有组
                          即: 等待 Group 0 和 Group 1 完成 (Group 2 可以还在进行)
```

### Double Buffering vs Triple Buffering

```
Double Buffering (2 buffers):

  Buffer 0: [── load tile 0 ──]          [── load tile 2 ──]
  Buffer 1:          [── compute tile 0 ──]        [── compute tile 2 ──]
            但 load tile 1 必须等 compute tile 0 完成后才能开始!

  +--++--++--++--++--++--++--++--+
  |L0||C0||L1||C1||L2||C2||L3||C3|
  +--++--++--++--++--++--++--++--+
  问题: load 和 compute 不能完全重叠 (buffer 冲突)

Triple Buffering (3 buffers):

  Buffer 0: [── load tile 0 ──]                    [── load tile 3 ──]
  Buffer 1:          [── load tile 1 ──]                    [── load tile 4 ──]
  Buffer 2:                    [── compute tile 0 ──]                 [── C3 ──]

  +--+--+--+--+--+--+--+--+
  |L0|L1|C0|L2|C1|L3|C2|L4|
  +--+--+--+--+--+--+--+--+
  3 个 buffer 允许 load 始终领先 compute 一步，实现近似完全重叠

  A100 SM 推荐: 3-4 stages (triple/quad buffering)
  H100 SM 推荐: 4-5 stages (更大的 Shared Memory)
```

---

## CUDA Graphs 深度剖析

### 图捕获机制

CUDA Graphs 允许将一系列 CUDA 操作录制为一个图 (Graph)，然后一次性实例化和启动，从而消除单个 Kernel 的 Launch Overhead。

```cpp
// CUDA Graph 基本流程
cudaStream_t stream;
cudaStreamCreate(&stream);

// === Step 1: 开始捕获 ===
cudaStreamBeginCapture(stream, cudaStreamCaptureModeGlobal);

// === Step 2: 执行一系列操作 (这些操作被记录而不是立即执行) ===
kernel1<<<grid, block, 0, stream>>>(d_A, d_B, N);
kernel2<<<grid, block, 0, stream>>>(d_B, d_C, N);
cudaMemcpyAsync(d_D, d_C, size, cudaMemcpyDeviceToHost, stream);
// ... 更多操作 ...

// === Step 3: 结束捕获，获得图 ===
cudaGraph_t graph;
cudaStreamEndCapture(stream, &graph);

// === Step 4: 实例化图 ===
cudaGraphExec_t graphExec;
cudaGraphInstantiate(&graphExec, graph, NULL, NULL, 0);

// === Step 5: 启动图 (可多次调用) ===
for (int iter = 0; iter < 1000; ++iter) {
    cudaGraphLaunch(graphExec, stream);  // 一次 API 调用启动整个图
}

// === 清理 ===
cudaGraphExecDestroy(graphExec);
cudaGraphDestroy(graph);
cudaStreamDestroy(stream);
```

### 图的节点类型

```
CUDA Graph 节点类型:

+──────────────────────────────────────────────────────────+
│  cudaGraphNodeType:                                      │
│                                                          │
│  +───────────────────+  内核执行节点                      │
│  | Kernel Node       |  (最常用)                         │
│  +───────────────────+                                   │
│                                                          │
│  +───────────────────+  内存拷贝节点                      │
│  | Memcpy Node       |  (H2D, D2H, D2D)                  │
│  +───────────────────+                                   │
│                                                          │
│  +───────────────────+  内存初始化节点                    │
│  | Memset Node       |  (cudaMemset 等价操作)             │
│  +───────────────────+                                   │
│                                                          │
│  +───────────────────+  主机函数节点                      │
│  | Host Node         |  (CPU 回调)                       │
│  +───────────────────+                                   │
│                                                          │
│  +───────────────────+  子图节点                          │
│  | Child Graph Node  |  (嵌套图，复用)                    │
│  +───────────────────+                                   │
│                                                          │
│  +───────────────────+  条件节点 (CUDA 12.3+)             │
│  | Conditional Node  |  (if/else 分支)                   │
│  +───────────────────+                                   │
│                                                          │
│  +───────────────────+  空节点                            │
│  | Empty Node        |  (占位/同步)                       │
│  +───────────────────+                                   │
+──────────────────────────────────────────────────────────+
```

### 条件节点 (CUDA 12.3+)

```cpp
// 条件节点示例: 基于运行时条件的动态分支
#if CUDART_VERSION >= 12030
// 创建条件句柄
cudaGraphConditionalHandle cond_handle;
cudaGraphConditionalHandleCreate(&cond_handle, graph, 0, 0);

// 创建 then 和 else 子图
cudaGraph_t then_graph, else_graph;
// ... 构建 then_graph 和 else_graph ...

cudaGraphNode_t then_node, else_node;
cudaGraphAddChildGraphNode(&then_node, graph, ..., then_graph);
cudaGraphAddChildGraphNode(&else_node, graph, ..., else_graph);

// 创建设置条件值的 kernel
cudaGraphNode_t set_cond_node;
cudaGraphAddKernelNode(&set_cond_node, graph, ..., set_condition_kernel);

// 创建条件节点
cudaGraphNode_t cond_node;
cudaGraphConditionalNodeParams cond_params;
cond_params.type = cudaGraphCondTypeIf;
cond_params.handle = cond_handle;
cond_params.ph.hGraph[0] = then_graph;   // then branch
cond_params.ph.hGraph[1] = else_graph;   // else branch
cond_params.ph.ctx[0] = ...;
cond_params.ph.ctx[1] = ...;
cudaGraphAddNode(&cond_node, graph, ..., &cond_params);
#endif
```

### 图捕获的限制

```
不能捕获的操作:

  1. Host-side Synchronization
     - cudaStreamSynchronize()
     - cudaDeviceSynchronize()
     - cudaEventSynchronize()

  2. Event Operations (部分)
     - cudaEventRecord() 在某些模式

  3. Dynamic Parallelism
     - 子 kernel 启动 (device-side kernel launch)

  4. CUDA Graphs 自身的 API
     - 不能在捕获中嵌套图

  5. External Resource Interop
     - OpenGL/Vulkan/DirectX 互操作

  6. 动态内存分配
     - cudaMalloc / cudaFree (在捕获流中)
     - cudaMallocAsync 可以 (CUDA 11.2+)
```

### 性能收益

```
小型 Kernel 的 Launch Overhead 分析:

  每个 Kernel Launch: ~5-10 μs (CPU 端开销)
  对于 1000 次迭代 × 10 个 Kernel:
    传统方法: 1000 × 10 × 7.5 μs ≈ 75 ms (纯 Launch 开销!)
    CUDA Graph: 1 次 cudaGraphLaunch ≈ 统一的 ~10 μs
    节省: 99.9% 的 Launch Overhead

  典型场景: GNN 训练、推理 serving、小 batch 场景
  ──────────────────────────────────────────────
  vLLM 使用 CUDA Graphs 减少推理时的 Launch 开销
  对于 decode 阶段 (每次只生成 1 个 token) 效果尤其明显
```

---

## Occupancy 计算器

### 理论 Occupancy vs 实际 Occupancy

Occupancy = 每个 SM 上活跃 Warp 数 / 最大 Warp 数

```
A100 每个 SM:
  最大 Warp 数: 64
  最大 Block 数: 32
  最大线程数: 2048
```

```cpp
// CUDA Occupancy API
#include <cuda_runtime.h>

int min_grid_size, block_size;
// 自动计算最佳 Block 大小
cudaOccupancyMaxPotentialBlockSize(
    &min_grid_size, &block_size,
    my_kernel, 0, 0
);

// 计算给定 Block 大小下的最大活跃 Block 数
int num_blocks;
cudaOccupancyMaxActiveBlocksPerMultiprocessor(
    &num_blocks,
    my_kernel,
    block_size,
    0  // dynamic shared memory (bytes)
);

float occupancy = (float)(num_blocks * block_size) / 2048.0f;  // 2048 = 最大线程/SM
printf("Theoretical Occupancy: %.1f%%\n", occupancy * 100);
```

### Register Pressure 与 Occupancy 权衡

```
计算最大 Block/SM 的公式:

  受限于 Register:
    max_blocks_reg = floor(65536 / (regs_per_thread * threads_per_block))
    65536 = A100 SM 的寄存器总数

  受限于 Shared Memory:
    max_blocks_smem = floor(164 * 1024 / smem_per_block)
    164 KB = A100 SM 的 Shared Memory (configurable up to 164KB)

  受限于 Threads:
    max_blocks_thread = floor(2048 / threads_per_block)

  受限于 Warp:
    max_blocks_warp = floor(64 / (threads_per_block / 32))

  最终: max_blocks_per_sm = min(max_blocks_reg, max_blocks_smem,
                                 max_blocks_thread, max_blocks_warp)
```

```
Occupancy 与寄存器数量的关系 (block_size=256):

  Registers    Max Blocks    Occupancy    说明
  per Thread   per SM
  ──────────────────────────────────────────────
  32           8             100%         无限制, 完美
  48           5             62.5%        寄存器限制
  64           4             50%          寄存器限制
  96           2             25%          寄存器限制
  128          2             25%          寄存器限制
  255          1             12.5%        严重寄存器压力!
  ──────────────────────────────────────────────

  使用 --ptxas-options=-v 查看实际寄存器使用:
  $ nvcc kernel.cu -arch=sm_80 --ptxas-options=-v
  ptxas info    : 64 bytes gmem
  ptxas info    : Function properties for _Z6my_kernelPf:
      48 bytes stack frame, 0 bytes spill stores, 0 bytes spill loads
      Used 64 registers, 8192 bytes smem  ← 关键信息
```

### Warp 调度器行为

```
A100 SM 内部 Warp 调度器:

  +────────────────────────────────────────────────────────+
  |                    SM (A100)                           |
  |                                                        |
  |  4 个 Warp Scheduler, 每个可以每 cycle 发射 1 条指令     |
  |                                                        |
  |  Warp Scheduler 0:                                     |
  |    [W0] [W1] [W2] [W3] [W4] [W5] [W6] [W7] ...        |
  |     ↑↓   ↑↓   ↑↓   ↑↓  (持续切换)                       |
  |    run wait run wait run wait run wait                 |
  |                                                        |
  |  延迟隐藏原理:                                          |
  |    内存请求延迟 ~300 cycles                             |
  |    如果有 8 个 Warp 可以切换:                            |
  |      Warp 0 发出 load → 切换到 Warp 1 执行 →             |
  |      Warp 1 发出 load → 切换到 Warp 2 执行 → ...         |
  |      等切回到 Warp 0 时, 数据可能已经到位                 |
  |                                                        |
  |  关键公式: 隐藏延迟需要的 Warp 数 ≈ 延迟 × 吞吐          |
  |    例如: 300 cycles × 4 instr/cycle / 1 instr/warp      |
  |         ≈ 需要 ~75 个 Warp 来隐藏延迟                    |
  |    但 A100 最多 64 Warp/SM, 所以对高延迟操作仍需优化     |
  +────────────────────────────────────────────────────────+
```

---

## Kernel Fusion

### 为什么需要算子融合

AI 推理中最常见的瓶颈不是计算，而是内存带宽。以下面这个典型操作序列为例：

```
典型 Transformer Block 中的操作序列:
  [输入] → [LayerNorm] → [QKV Projection] → [Attention] → ...
                    ↑
              每个中间结果都要写回 Global Memory 再读回来

  假设 N = 4096, fp16:
    每个操作: 读 4096×2 = 8 KB, 写 8 KB = 16 KB
    5 个操作: 80 KB 内存流量
    如果带宽 2 TB/s, 延迟 = 80K / 2T ≈ 40 ns (理论)
    实际延迟更接近 ~5 μs (因为每次都是单独的 kernel launch)
```

### 垂直融合: 生产者-消费者模式

```
垂直融合 (Vertical Fusion):

融合前 (3 个独立 Kernel):
  +-------+     +-------+     +-------+
  |Kernel1|     |Kernel2|     |Kernel3|     HBM: 6次读写
  | RMS   | →   | Mul   | →   | Add   |     (3 reads + 3 writes)
  |Norm   |     |       |     |       |
  +-------+     +-------+     +-------+

融合后 (1 个 Fused Kernel):
  +----------------------------+
  |      Fused Kernel          |
  |  RMSNorm → Mul → Add       |
  |  (Register/Shared Memory)  |
  +----------------------------+
  HBM: 2次读写 (1 read + 1 write)
  带宽节省: 66%!
```

```cuda
// RMSNorm + Residual + Quantize 融合示例
__global__ void rmsnorm_residual_quant_fused(
    const half* __restrict__ input,    // [N, D]
    const half* __restrict__ residual, // [N, D] 输入 residual
    half* __restrict__ output,         // [N, D] 输出 residual (更新后)
    int8_t* __restrict__ quant_out,    // [N, D] INT8 量化输出
    const half* __restrict__ weight,   // [D] RMSNorm weight
    float eps, int D)
{
    // 每个 Block 处理一行
    int row = blockIdx.x;
    int tid = threadIdx.x;

    extern __shared__ half smem[];  // 缓存权重
    // 加载 weight 到 shared memory
    if (tid < D) smem[tid] = weight[tid];
    __syncthreads();

    // Step 1: RMSNorm — 计算 row 的 RMS
    float sum_sq = 0.0f;
    for (int i = tid; i < D; i += blockDim.x) {
        int idx = row * D + i;
        float v = __half2float(input[idx]);
        sum_sq += v * v;
    }
    // Warp + Block reduce
    sum_sq = block_reduce_sum(sum_sq);
    float rms = rsqrtf(sum_sq / D + eps);

    // Step 2: RMSNorm + Residual + Quantize (一次完成)
    float inv_scale = ...;  // 从全局 scale 参数读取

    for (int i = tid; i < D; i += blockDim.x) {
        int idx = row * D + i;
        // RMSNorm
        float normed = __half2float(input[idx]) * rms * __half2float(smem[i]);
        // Residual add
        float residual_val = __half2float(residual[idx]);
        float result = normed + residual_val;
        // 写出更新的 residual
        output[idx] = __float2half(result);
        // 量化并写出 (INT8)
        int8_t qval = (int8_t)roundf(result * inv_scale);
        quant_out[idx] = qval;
    }
}

// 融合前: 3 个 Kernel = 6 × N×D×2 bytes 访存
// 融合后: 1 个 Kernel = 4 × N×D×2 bytes 访存 (input + residual + output + quant_out)
// 节省: ~33% 带宽
```

### 水平融合: 同数据独立操作

```
水平融合 (Horizontal Fusion):

融合前:
  Input → [GEMM_1] → Out1
       → [GEMM_2] → Out2
       → [GEMM_3] → Out3
  共 6 次 HBM 访问

融合后 (Grouped GEMM / Multi-head fusion):
  Input → [Fused Multi-GEMM] → Out1, Out2, Out3
  共 2 次 HBM 访问

  这在 Multi-Head Attention 的 QKV 投影中非常常见:
    Q = X @ W_Q    ←─ 可以融合为一个 grouped GEMM
    K = X @ W_K    ←─ 共享输入 X
    V = X @ W_V    ←─
```

---

## 向量化 Load

### float4 / half2 / uint4

GPU 的 L1/L2 缓存行是 128 bytes。使用向量化 Load/Store 可以一次加载 128 bits (16 bytes)，充分利用缓存行带宽。

```cuda
// 标量加载 (32-bit): 每个线程一次 4 bytes
__global__ void scalar_copy(const float* src, float* dst, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        dst[idx] = src[idx];  // 1 × 4 bytes = 4 bytes/thread/instruction
    }
}
// 每个 Warp: 32 threads × 4 bytes = 128 bytes
// 需要: L1 至少 1 次 128B transaction (假设合并访问)
// 指令数: 32 threads × 1 ld + 1 st = 64 instructions

// 向量化加载 (128-bit): 每个线程一次 16 bytes
__global__ void vectorized_copy(const float4* src, float4* dst, int N4) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N4) {
        dst[idx] = src[idx];  // 1 × 16 bytes = 16 bytes/thread/instruction
    }
}
// 每个 Warp: 32 threads × 16 bytes = 512 bytes
// 需要: L1 至少 4 次 128B transaction
// 指令数: 32 threads × 1 ld.global.v4.f32 + 1 st.global.v4.f32 = 64 instructions
// 但处理了 4 倍的数据量!
```

```cuda
// half2 向量化 (在 FP16 训练/推理中很常用)
__global__ void half2_add_kernel(
    const half2* __restrict__ a,
    const half2* __restrict__ b,
    half2* __restrict__ c, int N2)
{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N2) {
        c[idx] = __hadd2(a[idx], b[idx]);  // 1 条指令完成 2 个 half 的加法
    }
}

// 使用 float4 的优化示例: 内存拷贝
// 对齐要求: 16-byte (float4) 对齐
#define ALIGN_UP(x, a) (((x) + (a) - 1) & ~((a) - 1))

void launch_vectorized_copy(const float* src, float* dst, int N) {
    // 确保 16-byte 对齐
    const int align_bytes = 16;
    int aligned_N = N & ~3;  // 向下对齐到 4 的倍数

    int num_float4 = aligned_N / 4;
    int remainder = N - aligned_N;

    int threads = 256;
    int blocks = (num_float4 + threads - 1) / threads;

    // 向量化部分
    vectorized_copy<<<blocks, threads>>>(
        reinterpret_cast<const float4*>(src),
        reinterpret_cast<float4*>(dst),
        num_float4
    );

    // 处理尾部 (标量)
    if (remainder > 0) {
        scalar_copy<<<1, remainder>>>(src + aligned_N, dst + aligned_N, remainder);
    }
}
```

**实测性能对比 (A100, 4GB 数组拷贝)：**

| 方法 | 有效带宽 | IPC | 说明 |
|-----|---------|-----|------|
| Scalar (float) | ~1.2 TB/s | 3.2 | 基准 |
| float4 vectorized | ~1.8 TB/s | 3.8 | 接近峰值 2 TB/s |
| uint4 vectorized | ~1.9 TB/s | 4.0 | 极致优化 |

---

## Persistent Kernel

### 生产者-消费者与持久化线程块

传统 Kernel Launch 模式中，每个 Kernel 处理一批固定的数据后退出。Persistent Kernel 则不退出，而是持续处理数据流。

```
传统 Launch:
  时间 →
  [Launch K1] [── Exec K1 ──] [Launch K2] [── Exec K2 ──] [Launch K3] ...
          ↑                             ↑
      Launch Overhead (~5-10μs)     Launch Overhead

Persistent Kernel:
  时间 →
  [Launch once] [── Process Tile 0 ──][── Process Tile 1 ──][── Process Tile 2 ──]...
  只启动一次，持续工作直到所有数据完成
```

```cuda
// Persistent Kernel 示例: 使用 Atomic Counter 分配 Tile
__global__ void persistent_gemm(
    const half* A, const half* B, float* C,
    int M, int N, int K)
{
    // 工作分配: 原子计数器
    __shared__ int next_tile;

    if (threadIdx.x == 0) {
        next_tile = 0;  // 初始化为 -1? 不，每个 Block 有自己的计数器
    }
    __syncthreads();

    // 全局原子 tile 分配器
    // 注意: 这里每个 Block 有独立的 tile 计数器在 L1/Shared Memory
    // 更典型的做法是使用 Global Memory 中的原子变量
    extern __device__ int global_tile_counter;  // 或者作为参数传入

    while (true) {
        int tile_idx;
        if (threadIdx.x == 0) {
            tile_idx = atomicAdd(&global_tile_counter, 1);
        }
        tile_idx = __shfl_sync(0xffffffff, tile_idx, 0);

        int m_start = tile_idx * 128;  // 每个 tile 处理 128 行
        if (m_start >= M) break;

        // 处理这个 tile...
        // ... (正常的 GEMM tile 计算逻辑)
    }
}

// 启动方式:
// 明确指定 SM 可容纳的最大 Block 数
int max_blocks_per_sm;
cudaOccupancyMaxActiveBlocksPerMultiprocessor(
    &max_blocks_per_sm, persistent_gemm, 256, shared_mem_size);

int num_sms;
cudaDeviceGetAttribute(&num_sms, cudaDevAttrMultiProcessorCount, device);

int total_blocks = max_blocks_per_sm * num_sms;
persistent_gemm<<<total_blocks, 256, shared_mem_size>>>(...);
```

### Persistent Kernel 的优缺点

```
优点:
  + 消除 Kernel Launch Overhead (尤其是小批次)
  + 更好的延迟隐藏 (数据持续在 L2 cache 中)
  + 适用于迭代型、不可预知工作量的场景

缺点:
  - CPU 端控制力弱 (难以中断/取消)
  - Debug 困难
  - 死锁风险 (所有 Block 可能卡在等待中)
  - 不适合一次性能完成的工作
  - 可能与 CUDA Graphs 冲突

适用场景:
  - Online inference serving (vLLM 的 attention kernel)
  - Real-time processing pipelines
  - Iterative solvers (共轭梯度法等)
```

---

## Register Pressure

### 诊断方法

```bash
# 方法1: nvcc 编译时输出
nvcc -arch=sm_80 kernel.cu --ptxas-options=-v
# 输出示例:
# ptxas info    : 96 bytes gmem
# ptxas info    : Compiling entry function '_Z12my_kernelPf' for 'sm_80'
# ptxas info    : Function properties for _Z12my_kernelPf:
#     0 bytes stack frame, 128 bytes spill stores, 96 bytes spill loads
#     Used 128 registers, 16384 bytes smem
#     ↑ 128 寄存器! 严重溢出了 A100 的 255 上限? 不, 64 registers 才是真实上限
#       超过 64 就会 spill to local memory
#       spill stores/loads > 0 是危险信号!

# 方法2: Nsight Compute
ncu --set full -o report ./my_program
# 在 Nsight Compute GUI 中查看:
#   - Memory Workload Analysis → Local Memory 流量
#   - Launch Statistics → Registers/Thread
```

```bash
# 方法3: cuobjdump 分析编译后的 SASS
nvcc kernel.cu -o kernel.o -arch=sm_80 -c
cuobjdump -sass kernel.o | head -100
# 可以看到每条 SASS 指令, 识别 spill 操作:
#   STL [R2+offset], R100;  ← spill (store to local memory)
#   LDL R100, [R2+offset];  ← fill (load from local memory)
```

### 缓解策略

```cuda
// 策略1: 减少活跃变量 — 及时释放不再使用的寄存器
// Before (bad):
__global__ void bad_kernel(const float* A, const float* B, float* C, int N) {
    float a = A[threadIdx.x];       // R0
    float b = B[threadIdx.x];       // R1
    float temp1 = a * b;            // R2
    float temp2 = a + b;            // R3
    float temp3 = temp1 * a;        // R4
    float temp4 = temp2 * b;        // R5
    // ... a 和 b 之后不再使用, 但仍然占据寄存器! 编译器可能不会优化
    float result1 = temp3 + temp4;  // R6
    // ... 使用 result1 ...
}

// After (good): 手动缩小变量作用域
__global__ void good_kernel(const float* A, const float* B, float* C, int N) {
    float a = A[threadIdx.x];
    float b = B[threadIdx.x];
    float temp1 = a * b;
    float temp2 = a + b;
    // 编译器在 temp1, temp2 计算后可以复用 a, b 的寄存器
    float result1 = (temp1 * a) + (temp2 * b);
    // 注意: 其实编译器优化(-O3)通常能处理好, 关键是避免过多的标量变量
}

// 策略2: Loop Fission — 将大 Kernel 拆分为多个小 Kernel
// 每个小 Kernel 有更少的寄存器需求, 更高的 Occupancy
// 但会增加 Global Memory 流量 (trade-off)

// 策略3: 使用 __launch_bounds__ 提示编译器
__global__ void __launch_bounds__(256, 4)  // 256 threads, min 4 blocks/SM
my_kernel(float* data, int N) {
    // 编译器会努力将寄存器使用控制在 65536/256/4 ≈ 64 以内
}

// 策略4: 将中间结果 spill 到 Shared Memory 而不是 Local Memory
__global__ void smem_spill_kernel(const float* input, float* output, int N) {
    __shared__ float spill_area[256];  // 手动 spill 区域

    float val = input[threadIdx.x];
    // 计算中间值...
    float intermediate = expensive_compute(val);

    // 手动 spill 到 Shared Memory (比 LMEM 快得多! 约 20 cycles vs 300+ cycles)
    spill_area[threadIdx.x] = intermediate;
    __syncthreads();

    // 后续使用...
    float other_val = compute_something_else();
    intermediate = spill_area[threadIdx.x];  // 从 Shared Memory 加载
    output[threadIdx.x] = intermediate + other_val;
}

// 策略5: Explicit register allocation (CUDA 11+)
// 允许显式控制变量在寄存器文件中的生命周期
// 主要在 PTX 级别使用
```

---

## GEMM 优化 Step by Step

以下展示将 Naive GEMM (C = A × B) 从 ~200 GFLOPS 逐步优化到 ~20 TFLOPS 的过程。矩阵大小 4096×4096, FP16, A100。

### Step 0: Naive GEMM (~200 GFLOPS)

```cuda
// Naive GEMM: 直接全局内存计算
__global__ void gemm_naive(
    const half* A, const half* B, half* C,
    int M, int N, int K)
{
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += __half2float(A[row * K + k]) *
                   __half2float(B[k * N + col]);
        }
        C[row * N + col] = __float2half(sum);
    }
}
// 问题:
//   - 每次迭代都从 Global Memory 读取 (约 300+ cycles)
//   - B 的访问是跨步的 (stride = N)
//   - K 次迭代 × 2 次读 = 2K 次 Global Memory 访问 × ~300 cycles
//   - 没有任何数据复用
// 性能: ~200 GFLOPS (不到峰值 312 TFLOPS 的 0.1%)
```

### Step 1: Global Memory Coalescing (~500 GFLOPS)

```cuda
// 改进: 修复合并访问 — 交换 B 的维度访问顺序
__global__ void gemm_v1_coalesced(
    const half* A, const half* B, half* C,
    int M, int N, int K)
{
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            // A: 行优先访问 → 合并 (每个线程相邻的 k)
            // B: 使用转置技巧或重新排列循环
            sum += __half2float(A[row * K + k]) *
                   __half2float(B[col * K + k]);  // B 转置为 [N, K]
        }
        C[row * N + col] = __float2half(sum);
    }
}
// 注意: B 需要预转置为 col-major
// B 转置后: 同一 Warp 内相邻 col 访问 B[col*K + k], k 相同, col 相邻
// → 合并访问!
// 性能: ~500 GFLOPS
```

### Step 2: Shared Memory Tiling (~2 TFLOPS)

```cuda
#define TILE_SIZE 128
#define BLOCK_SIZE 16

__global__ void gemm_v2_smem_tiling(
    const half* A, const half* B, half* C,
    int M, int N, int K)
{
    // Shared Memory tiles
    __shared__ half As[TILE_SIZE][TILE_SIZE];
    __shared__ half Bs[TILE_SIZE][TILE_SIZE];

    int row = blockIdx.y * TILE_SIZE + threadIdx.y;
    int col = blockIdx.x * TILE_SIZE + threadIdx.x;

    float sum = 0.0f;

    // 遍历 K 维度, 每次处理一个 TILE_SIZE 的 tile
    for (int k_tile = 0; k_tile < K; k_tile += TILE_SIZE) {
        // 协作加载 A tile: 每个线程加载一个元素
        // 因为 blockDim.x * blockDim.y = 16*16 = 256 threads
        // 但 tile 有 128*128 = 16384 elements
        // 每个线程需要加载 16384/256 = 64 个元素 (分多次)
        int load_row = threadIdx.y;
        int load_col = threadIdx.x;
        for (int i = load_row; i < TILE_SIZE; i += BLOCK_SIZE) {
            for (int j = load_col; j < TILE_SIZE; j += BLOCK_SIZE) {
                int a_row = blockIdx.y * TILE_SIZE + i;
                int a_col = k_tile + j;
                As[i][j] = (a_row < M && a_col < K) ? A[a_row * K + a_col] : __float2half(0.0f);

                int b_row = k_tile + i;
                int b_col = blockIdx.x * TILE_SIZE + j;
                Bs[i][j] = (b_row < K && b_col < N) ? B[b_row * N + b_col] : __float2half(0.0f);
            }
        }
        __syncthreads();

        // 使用 Shared Memory 进行计算 (延迟 ~20 cycles vs ~300 cycles)
        for (int k = 0; k < TILE_SIZE; ++k) {
            sum += __half2float(As[threadIdx.y][k]) *
                   __half2float(Bs[k][threadIdx.x]);
        }
        __syncthreads();
    }

    if (row < M && col < N) {
        C[row * N + col] = __float2half(sum);
    }
}
// 数据复用: 每个 tile 被 TILE_SIZE 次计算复用
// Shared Memory 延迟 ~20 cycles vs Global Memory ~300 cycles
// Bank Conflict: As[j][i] 访问有 32-way conflict (需要修复!)
// 性能: ~2 TFLOPS
```

### Step 3: Warp Tiling + Register Reuse (~5 TFLOPS)

```cuda
// Step 3: 每个线程计算一个 WM×WN 的 tile (存放在寄存器中)
#define WM 64  // Warp tile M
#define WN 64  // Warp tile N
#define TM 8   // 每个线程处理的 M 方向元素数
#define TN 8   // 每个线程处理的 N 方向元素数

__global__ void gemm_v3_warp_tiling(
    const half* A, const half* B, half* C,
    int M, int N, int K)
{
    // ... Shared Memory tiling 同上 ...

    // 每个线程在寄存器中累积 TM×TN 的 tile
    float accum[TM][TN] = {{0.0f}};

    for (int k = 0; k < TILE_SIZE; ++k) {
        // 从 Shared Memory 加载 TM×1 (A) 和 1×TN (B) 到寄存器
        half a_reg[TM];
        half b_reg[TN];

        #pragma unroll
        for (int i = 0; i < TM; ++i) {
            a_reg[i] = As[threadIdx.y * TM + i][k];
        }
        #pragma unroll
        for (int j = 0; j < TN; ++j) {
            b_reg[j] = Bs[k][threadIdx.x * TN + j];
        }

        // 外积: TM×1 × 1×TN = TM×TN (寄存器中完成)
        #pragma unroll
        for (int i = 0; i < TM; ++i) {
            #pragma unroll
            for (int j = 0; j < TN; ++j) {
                accum[i][j] += __half2float(a_reg[i]) * __half2float(b_reg[j]);
            }
        }
    }

    // 写回结果
    // ...
}
// 关键: 2 层寄存器 tiling
//   - 外层循环 k: Shared Memory → 寄存器 (延迟 ~20 cycles)
//   - 内层循环: 寄存器 → 寄存器 (延迟 ~1 cycle, 外积)
// 每个线程现在计算 8×8=64 个输出元素, 数据和计算都在寄存器中
// 性能: ~5 TFLOPS
```

### Step 4: Double Buffering + cp.async (~8 TFLOPS)

```cuda
// Step 4: 使用 cp.async 和双缓冲隐藏加载延迟
__global__ void gemm_v4_async_pipeline(
    const half* A, const half* B, half* C,
    int M, int N, int K)
{
    // 双缓冲: 0 号 buffer 用于当前计算, 1 号 buffer 用于预取
    __shared__ half As[2][TILE_SIZE][TILE_SIZE];
    __shared__ half Bs[2][TILE_SIZE][TILE_SIZE];

    float accum[TM][TN] = {{0.0f}};

    // Prologue: 预取第一个 tile
    int read_stage = 0;
    load_tile_async(A, B, As[read_stage], Bs[read_stage], 0, M, N, K);
    asm volatile("cp.async.commit_group;\n" ::);
    asm volatile("cp.async.wait_group 0;\n" ::);
    __syncthreads();

    for (int k_tile = 1; k_tile < num_tiles; ++k_tile) {
        int comp_stage = (k_tile - 1) % 2;  // 正在计算的 buffer
        read_stage = k_tile % 2;             // 正在预取的 buffer

        // 启动下一个 tile 的异步加载
        load_tile_async(A, B, As[read_stage], Bs[read_stage],
                        k_tile * TILE_SIZE, M, N, K);
        asm volatile("cp.async.commit_group;\n" ::);

        // 同时计算当前 tile (加载和计算重叠!)
        compute_tile(As[comp_stage], Bs[comp_stage], accum);

        // 等待当前 tile 的加载完成 (上一个 commit_group)
        asm volatile("cp.async.wait_group 0;\n" ::);
        __syncthreads();
    }

    // Epilogue: 最后一个 tile
    compute_tile(As[(num_tiles - 1) % 2], Bs[(num_tiles - 1) % 2], accum);
    // 写回结果...
}
// cp.async 完全隐藏了 Global Memory 加载延迟
// 性能: ~8 TFLOPS
```

### Step 5: Tensor Cores (~20 TFLOPS on FP16)

```cuda
// Step 5: 使用 Tensor Core (mma.sync)
#include <cuda/barrier>
#include <mma.h>
using namespace nvcuda;

__global__ void gemm_v5_tensorcore(
    const half* A, const half* B, float* C,
    int M, int N, int K)
{
    // 使用 WMMA API (易用性)
    wmma::fragment<wmma::matrix_a, 16, 16, 16, half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, 16, 16, 16, half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, 16, 16, 16, float> c_frag;

    wmma::fill_fragment(c_frag, 0.0f);

    // Shared Memory tiling + Tensor Core 计算
    __shared__ half As[TILE_SIZE][TILE_SIZE];
    __shared__ half Bs[TILE_SIZE][TILE_SIZE];

    // Async pipeline (同 Step 4) ...
    
    for (int k = 0; k < TILE_SIZE; k += 16) {
        wmma::load_matrix_sync(a_frag, &As[threadIdx.y * 16][k], TILE_SIZE);
        wmma::load_matrix_sync(b_frag, &Bs[k][threadIdx.x * 16], TILE_SIZE);
        wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
    }

    wmma::store_matrix_sync(&C[...], c_frag, N, wmma::mem_row_major);
}
// 对于更大的矩阵, 使用 mma.sync (PTX 级别) → 可达 ~30-40 TFLOPS+
// 性能: ~20 TFLOPS (WMMA) 到 ~50+ TFLOPS (手写 mma.sync)
```

### 优化历程总结

```
GEMM 优化路径 (FP16, A100, 4096×4096):

  GFLOPS
  50000 │                                           ● mma.sync (PTX)
        │                                        ╱
  40000 │                                  ╱
        │                            ╱
  30000 │                      ╱
        │                 ╱
  20000 │            ╱  ● WMMA (Tensor Core)
        │       ╱
  10000 │  ╱  ● Async Pipeline + Double Buffering
        │ ╱
   5000 │●  Warp Tiling + Register Reuse
        │
   2000 │●  Shared Memory Tiling
        │
    500 │●  Global Memory Coalescing
        │
    200 │●  Naive
        └──┴────────────┴────────────┴────────────┴──→
         Step0  Step1      Step2      Step3  Step4 Step5

  最终: 从 200 GFLOPS → 50+ TFLOPS, 提升 ~250x!
```

---

## Nsight Compute 实战

### Roofline Chart 解读

```
Roofline Model (FP16, A100):

  Performance (FLOP/s)
  312 T ┤ ┌──────────────────────────────────────────────────┐
        │ │              Compute Bound Region                │ (Compute Roofline)
  156 T ┤ ├──────────────────────────────────────────────────┤
        │ │   Kernel D ●         (FP16 Tensor Core ceiling)  │
  78 T  ┤ ├──────────────────────────────────────────────────┤
        │ │                     Kernel C ●                    │
  39 T  ┤ │                                                  │
        │ │          Memory Bound Region                     │
  19.5T ┤ │    ● Kernel A                                    │
        │ │ (内存受限)                                        │
  10 T  ┤ │         ● Kernel B                               │
        │ │  (斜率 = Peak Bandwidth × OI)                     │
   5 T  ┤ │                                                  │
        └─┴──────────────────────────────────────────────────┘
           0.1    1      10     100    1000
           Arithmetic Intensity (FLOP/Byte)

  ● Kernel A: 低计算强度 → Memory Bound (~5% compute utilization)
  ● Kernel B: 中等 → 介于两者之间 (~30%)
  ● Kernel C: 高计算强度 → Compute Bound (~70%)
  ● Kernel D: 极高计算强度 (如大 GEMM) → 接近 Roofline (~93%)
```

### SOL (Speed of Light) 指标

Nsight Compute 的 SOL 指标告诉你距离硬件理论峰值有多近：

```
SOL Metrics (A100):

  Memory Throughput SOL:
    你的 Kernel: 1.6 TB/s
    峰值:       2.0 TB/s
    SOL: 80%  ← 内存带宽利用率 80%

  Compute Throughput SOL:
    你的 Kernel: 120 TFLOPS
    峰值 (FP16 TC): 312 TFLOPS
    SOL: 38.5%  ← 计算吞吐利用率 38.5%

  优化目标: 尽可能接近 100% SOL
  但通常: Memory-bound kernel 追求 Memory SOL, Compute-bound kernel 追求 Compute SOL

  ──────────────────────────────────────────────
  Memory Workload Analysis 解读:
  ──────────────────────────────────────────────
  L1 Cache Hit Rate:  85%  ← 不错
  L2 Cache Hit Rate:  45%  ← L2 miss 意味着要去 DRAM
  DRAM Utilization:   78%  ← 带宽利用率 (对应 Memory SOL)
  
  L1 命中高 → Shared Memory / 寄存器复用做得好
  L2 命中低 → 数据集大, L2 不够, 但 DRAM 利用率高说明访存模式好 (合并访问)
```

### Scheduler Statistics

```
Scheduler Statistics (Nsight Compute):

  Eligible Warps per Cycle:  3.2 / 4 (max)
    → 平均每个 cycle 有 3.2 个 Warp 可以发射指令
    → 接近理论最大值 4, 说明 Occupancy 好

  Stall Reasons (Top 3):
    1. Long Scoreboard (lg/throttle):    42%
       → 等待 Global Memory 数据, 最常见的瓶颈
    2. Short Scoreboard (smem):           18%
       → 等待 Shared Memory
    3. Barrier:                            8%
       → __syncthreads() 等待

  优化方向:
    - Long Scoreboard 高 → 使用 cp.async 预取, 增加 Occupancy
    - Short Scoreboard 高 → 检查 Bank Conflict
    - Barrier 高 → 减少 __syncthreads 或重组计算
```

---

## 真实 vLLM Kernel 分析: PagedAttention

### Kernel 结构概览

vLLM 的核心创新是 PagedAttention，将 KV Cache 分页管理。其 Kernel 实现 (`paged_attention_v1/v2`) 是一个典型的 Memory-Bound Kernel，目标是最大化内存带宽利用率。

```cuda
// vLLM PagedAttention Kernel 简化结构
// 实际源码: vllm/csrc/attention/attention_kernels.cu

template<typename scalar_t, int HEAD_SIZE, int BLOCK_SIZE, int NUM_THREADS>
__global__ void paged_attention_kernel(
    scalar_t* __restrict__ out,           // [num_seqs, num_heads, head_size]
    const scalar_t* __restrict__ q,       // [num_seqs, num_heads, head_size]
    const scalar_t* __restrict__ k_cache, // [num_blocks, num_kv_heads, head_size/x, block_size, x]
    const scalar_t* __restrict__ v_cache, // [num_blocks, num_kv_heads, head_size, block_size]
    const int* __restrict__ block_tables, // [num_seqs, max_num_blocks_per_seq]
    const int* __restrict__ context_lens, // [num_seqs]
    float scale,
    int max_num_blocks_per_seq)
{
    const int seq_idx = blockIdx.y;
    const int head_idx = blockIdx.z;
    const int context_len = context_lens[seq_idx];

    // 每个 Thread Block 负责一个 (sequence, head) 对
    // Block 内的线程协作计算 attention
}
```

### Block Table 遍历

```
Block Table 遍历机制:

  Sequence 0 的 KV Cache Blocks (context_len=500):
    Block Table: [42, 17, 103, 8, 55, ...]
                   │    │    │   │   │
                   ▼    ▼    ▼   ▼   ▼
  Block 42:  ┌─────────────────┐
             │ tokens[  0.. 15]│  ← 每个 Block 存储 BLOCK_SIZE 个 token 的 KV
             └─────────────────┘
  Block 17:  ┌─────────────────┐
             │ tokens[ 16.. 31]│
             └─────────────────┘
  Block 103: ┌─────────────────┐
             │ tokens[ 32.. 47]│
             └─────────────────┘
             ... 共 500/16 ≈ 32 个 Blocks

  Kernel 遍历方式:
    for (int block_idx = 0; block_idx < num_blocks; ++block_idx) {
        int physical_block = block_tables[seq_idx * max_num_blocks_per_seq + block_idx];
        // 从 k_cache[physical_block] 和 v_cache[physical_block] 加载数据
        // 计算 Q·K^T 和 attention weights
    }
```

### KV Cache 访问模式

```
KV Cache 内存布局 (vLLM):

  K Cache shape: [num_blocks, num_kv_heads, head_size/x, block_size, x]
  V Cache shape: [num_blocks, num_kv_heads, head_size, block_size]

  其中 x 是向量化因子 (通常为 8 用于 16-byte float4 加载)

  内存布局优化:
  ┌─────────────────────────────────────────────────┐
  │ Block 0: [K_head0_tok0, K_head0_tok1, ...,      │
  │           K_head1_tok0, K_head1_tok1, ...,      │
  │           V_head0_tok0, V_head0_tok1, ...]      │
  ├─────────────────────────────────────────────────┤
  │ Block 1: [...]                                  │
  └─────────────────────────────────────────────────┘

  关键优化:
  1. Interleaved layout: K 和 V 交错存储, 同一 token 的 K 和 V 在一起
     → 一次 load 可以同时拿到 K 和 V, 提高 cache locality

  2. Vectorized access: 使用 float4 一次加载 4 个 half (8 bytes)
     → 最大化 L2 cache 带宽利用

  3. Head_size padding: 确保 HEAD_SIZE 是向量化宽度的倍数
     → 避免 misaligned access
```

### 性能特征

```
PagedAttention Kernel 性能分析 (A100, HEAD_SIZE=128):

  内存访问量:
    每个 token: 读 K (128 elements × 2 bytes = 256 B)
               + 读 V (128 elements × 2 bytes = 256 B)
               = 512 bytes per head per token

    假设 context_len = 4096 tokens, num_heads = 32:
      总读取量 ≈ 4096 × 32 × 512 bytes = 64 MB

    如果 batch_size = 8, 总读取量 ≈ 512 MB

  带宽分析:
    A100 HBM 带宽: 2 TB/s
    理论最小延迟: 512 MB / 2000 GB/s ≈ 256 μs
    实际延迟: ~350-500 μs (包括 Launch overhead 和计算)
    内存带宽利用率: ~65-80% (非常接近 roofline!)

  为什么是 Memory-Bound:
    计算量 (FLOPs): 2 × 4096 × 128 × 32 = 33.5 MFLOPs
    内存访问: 64 MB
    计算强度: 33.5M / 64M ≈ 0.52 FLOP/Byte
    远低于 A100 的拐点 ~150 FLOP/Byte (FP16 Tensor Core)
    → 明确是 Memory-Bound
```

---

## 与 AI Infra 的关联

### 优化栈全景图

```
AI 推理优化栈 (自顶向下):

┌─────────────────────────────────────────────────────────────┐
│ Algorithm Level (算法层)                                     │
│   - Model Compression (Pruning, Quantization, Distillation) │
│   - Architecture Search (NAS, Efficient Attention)          │
│   - Speculative Decoding, KV Cache Compression              │
├─────────────────────────────────────────────────────────────┤
│ Framework Level (框架层)                                     │
│   - Graph Optimization (算子融合, 常量折叠)                   │
│   - Memory Planning (vLLM PagedAttention, FlashInfer)       │
│   - Scheduling (Continuous Batching, Prefix Caching)        │
├─────────────────────────────────────────────────────────────┤
│ Library Level (库层)                                         │
│   - cuBLAS, cuDNN, CUTLASS, FlashAttention                  │
│   - TensorRT, cuDLA                                         │
├─────────────────────────────────────────────────────────────┤
│ Kernel Level (内核层) ← 本文档的核心                          │
│   - Custom CUDA/Triton Kernels                              │
│   - Memory Layout, Warp Scheduling, Tensor Core             │
│   - Async Copy, Pipeline, CUDA Graphs                       │
├─────────────────────────────────────────────────────────────┤
│ Hardware Level (硬件层)                                      │
│   - GPU Architecture (SM, HBM, NVLink, Tensor Core)         │
│   - Multi-GPU Communication (NCCL, NVSwitch)                │
└─────────────────────────────────────────────────────────────┘
```

### Kernel 性能对端到端延迟的影响

```
端到端推理延迟分解 (LLaMA-70B, A100×8, batch=1):

  Prefill Phase (prompt=1024 tokens):
    ┌────────────────────────────────────────────────────────┐
    │ GEMM (QKV Proj):  ██████████████████████ 45% (~12 ms)  │
    │ Attention Compute:███████████ 25% (~7 ms)              │
    │ MLP (GEMM):       ███████████████ 35% (~10 ms)         │
    │ Other (RMSNorm,etc):██ 5% (~1 ms)                      │
    │ Total: ~30 ms                                          │
    └────────────────────────────────────────────────────────┘

  Decode Phase (per token):
    ┌────────────────────────────────────────────────────────┐
    │ Attention (KV Cache):████████████████████████████ 65%   │
    │ GEMM (QKV Proj):  ██████ 12%                           │
    │ MLP (GEMM):       ████████ 18%                         │
    │ Other:            ██ 5%                                │
    │ Total: ~5 ms per token                                 │
    └────────────────────────────────────────────────────────┘

  关键观察:
    - Decode 阶段, Attention (KV Cache access) 占据 65% 的延迟
    - 这是典型的 Memory-Bound 操作 → Kernel 优化的首要目标是带宽利用率
    - 如果 PagedAttention Kernel 差 10%, 端到端延迟就差 ~6.5%
    - 在 serving 场景中, 这意味着 QPS 直接损失 ~7%

  对于大规模 serving (1000+ QPS):
    延迟降低 5% → 可以减少 5% 的 GPU → 直接节省数十万美元
```

### Kernel 工程师在 AI Infra 团队中的角色

```
AI Infra Kernel 工程师的核心职责:

  1. Performance Profiling & Analysis
     - 识别端到端瓶颈 (使用 Nsight Systems + Nsight Compute)
     - 判断是 Memory-Bound 还是 Compute-Bound
     - 给出定量的优化空间预估

  2. Custom Kernel Development
     - 实现框架中不存在的高效算子 (Fused Operators, Custom Attention)
     - 针对特定 Hardware 做 tuning (A100 vs H100 的最佳 tile 不同)
     - 边界情况处理 (变长序列, GQA/MQA, 稀疏 Attention)

  3. Integration & Deployment
     - 将 Kernel 集成到 PyTorch/TensorFlow 中 (通过 torch.library / custom op)
     - 正确性验证 (数值精度, 边界测试)
     - 多 GPU 环境下的性能回归测试

  4. Technology Foresight
     - 跟踪 CUDA 新特性 (FP8, TMA, DSM, CUTLASS 3.x)
     - 评估新硬件 (H200, B200, GB200) 的优化策略
     - Triton vs CUDA 的 trade-off 分析 (开发效率 vs 极致性能)

  技能树:
    - 深入理解 GPU 架构 (SM, Memory Hierarchy, Tensor Core)
    - 精通 CUDA C++ 和 PTX
    - 熟悉至少一种高层 DSL (Triton 越来越重要)
    - 了解 ML 模型结构 (Transformer, MoE, Diffusion)
    - 性能分析和 Benchmark 能力
```

---

## 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| Occupancy | 像"餐厅翻台率"一样，SM 上活跃 warp 数占最大 warp 数的比例 | 本文 Occupancy 章节 |
| Bank Conflict | 像"32 个人抢 1 个通道"一样，多个线程同时访问同一 Shared Memory Bank | 本文 Shared Memory 章节 |
| Tensor Core | 像"矩阵乘法专用协处理器"一样，一次指令完成 16×8×16 的乘加 | 本文 Tensor Core 章节 |
| Warp | 像"32 人一组的同步小队"一样，锁步执行同一条指令 | 本文 Warp-Level 章节 |
| Shared Memory | 像"SM 内部的黑板"一样，同一 Block 内所有线程可读写，延迟 ~20 cycles | 本文内存访问章节 |

## A800 部署场景举例

**场景1：A800 上 Tensor Core 加速 DeepSeek-67B 的 GEMM**

A800 的 Tensor Core（第三代）FP16 峰值 312 TFLOPS，但前提是矩阵维度对齐到 mma.sync 指令：

```bash
# 编译时指定 A800 的 SM80 架构，启用 Tensor Core
nvcc -arch=sm_80 \
     --ptxas-options=-v \
     -maxrregcount=64 \
     -o gemm_kernel.cubin gemm_kernel.cu

# 查看寄存器使用（A800 每 SM 65536 个寄存器）
# 输出: Used 64 registers, 8192 bytes smem
# 若超过 64 → 严重 register pressure → Occupancy 下降到 50% 以下
```

```cpp
// A800 上最优的 GEMM tile 配置（FP16，本文 GEMM Step 5）
// A800 SM80 特性: 164 KB Shared Memory, 最大 64 warps/SM
using TileShape = cutlass::gemm::GemmShape<256, 128, 64>;  // M, N, K
using WarpShape  = cutlass::gemm::GemmShape<64, 64, 64>;
using InstShape  = cutlass::gemm::GemmShape<16, 8, 16>;    // m16n8k16
// 预期: 理论 Occupancy 50% (4 blocks/SM × 256 threads = 1024 threads < 2048 max)
//       实际吞吐 ~25 TFLOPS (WMMA) 到 ~50 TFLOPS (手写 mma.sync)
```

**场景2：Qwen-33B 推理中 Persistent Kernel 消除 Launch Overhead**

vLLM 的 decode 阶段每次只处理 1 个 token，kernel launch overhead 占总延迟约 15-30%。通过 CUDA Graphs 或 Persistent Kernel 消除：

```python
# vLLM 中启用 CUDA Graph
llm = LLM(
    model="/models/Qwen2.5-32B-Instruct",
    enforce_eager=False,  # 启用 CUDA Graph（默认）
)

# 效果: decode 延迟从 ~16ms/token 降到 ~13ms/token (约 18% 提升)
# 原理: CUDA Graph 将多次 kernel launch 录制为一张图，一次 cudaGraphLaunch 替代
```

## 上下游串联

```
上游 ← 本文档 → 下游

上游：CUTLASS/Triton 高层编程抽象
      CUTLASS 的 GEMM 模板和 Triton 的 @triton.jit 编译为具体的 CUDA kernel。
      本文档教你理解这些 Kernel 如何在 SM 上执行、如何利用 Tensor Core。

下游：GPU SM 硬件执行与性能分析
      本文档教的 Occupancy、Bank Conflict、Register Pressure 等概念
      是使用 Nsight Compute 进行 Roofline 分析和 SOL 指标解读的基础。

完整链路参考：end-to-end-inference-trace.md
  CUTLASS GEMM / Triton Kernel → CUDA PTX → SASS →
  SM Warp Scheduler → Tensor Core MMA → HBM/SMEM/Register
```

---
---
## 深入学习资源

### 必读论文

| 论文 | 主题 | 关键贡献 |
|-----|------|---------|
| FlashAttention (Dao et al., 2022) | IO-Aware Attention | Tiling + Recomputation, 减少 HBM 访问 |
| FlashAttention-2 (Dao, 2023) | 改进版 | 更好的并行策略, 2x 加速 |
| FlashAttention-3 (Shah et al., 2024) | H100 优化 | FP8, Async, TMA, WGMMA |
| CUTLASS (NVIDIA, 2017-) | GEMM 抽象 | 分层分解, CuTe layout algebra |
| MegaBlocks (Gale et al., 2022) | MoE | Block-sparse 计算加速 |
| PagedAttention (Kwon et al., 2023) | KV Cache | 分页管理, vLLM 核心 |

### 必读代码库

1. **CUTLASS** (https://github.com/NVIDIA/cutlass)
   - NVIDIA 官方 GEMM 库, 模板元编程的极致
   - 重点看: `include/cutlass/gemm/` 目录下的 kernel 模板
   - CuTe 子库: Layout algebra, copy atoms, tiling abstractions

2. **FlashAttention** (https://github.com/Dao-AILab/flash-attention)
   - 最好的 Attention Kernel 教科书
   - FlashAttention-2 的 forward kernel 约 500 行 CUDA, 可读性好
   - 重点看: `csrc/flash_attn/src/flash_fwd_kernel.h`

3. **vLLM** (https://github.com/vllm-project/vllm)
   - 生产级 CUDA Kernel, 工程化和性能的平衡
   - 重点看: `csrc/attention/attention_kernels.cu`, `csrc/quantization/`
   - PagedAttention v1, v2, v3 的演进路径

4. **CUB** (https://github.com/NVIDIA/cub)
   - CUDA 基础库, Parallel Primitive (Reduce, Scan, Sort)
   - 学习 Warp-level 和 Block-level 的并行算法

5. **NVIDIA/cuda-samples** (https://github.com/NVIDIA/cuda-samples)
   - 官方示例: Tensor Core, Graphs, Async Copy, etc.

### 必读文档

1. **CUDA C++ Programming Guide** (https://docs.nvidia.com/cuda/cuda-c-programming-guide/)
   - 第 3 章: Programming Model
   - 第 5 章: Performance Guidelines (合并访问, Bank Conflict, Occupancy)
   - 第 7 章: Tensor Core 编程

2. **CUDA C++ Best Practices Guide** (https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/)
   - 优化 Check List
   - 内存优化 vs 计算优化

3. **Parallel Thread Execution ISA** (https://docs.nvidia.com/cuda/parallel-thread-execution/)
   - 第 9.7 章: Matrix multiply-accumulate (mma) 指令
   - 第 9.10 章: Async copy 指令

4. **Nsight Compute Documentation** (https://docs.nvidia.com/nsight-compute/)
   - Metrics Reference
   - Roofline Analysis
   - Memory Workload Analysis

5. **NVIDIA A100/H100 Tuning Guides** (搜索 "NVIDIA A100 Tuning Guide")
   - Architecture-specific optimization tips
   - Memory throughput, compute throughput max

### 推荐书籍

1. **《CUDA C++ Programming Guide》** (NVIDIA 官方, 在线免费)
   - 所有 CUDA 开发者的第一本书

2. **《Programming Massively Parallel Processors》** (Kirk & Hwu)
   - 经典教材, 涵盖 GPU 架构和并行算法

3. **《Professional CUDA C Programming》** (Cheng, Grossman, McKercher)
   - 进阶内容, 优化技巧, Multi-GPU 编程

### 学习路径建议

```
推荐学习路径 (3-6 个月):

  Phase 1: CUDA 基础 (2-4 周)
    ├── CUDA Programming Guide Ch.1-3
    ├── 手写 Vector Add, Matrix Multiply (Naive)
    └── 使用 Nsight Systems 做第一个 Profile

  Phase 2: 内存优化 (4-6 周)
    ├── Coalesced Access, Shared Memory Tiling
    ├── Bank Conflict, Padding, Vectorized Loads
    ├── 手写优化版 GEMM (到 ~5 TFLOPS)
    └── 学习 CUTLASS 的 tile iterator 设计

  Phase 3: Tensor Core & Async (4-6 周)
    ├── WMMA API 入门, mma.sync PTX 深入
    ├── cp.async, Pipeline, Multi-buffering
    ├── 手写 Tensor Core GEMM (~20 TFLOPS+)
    └── 阅读 FlashAttention-2 forward kernel

  Phase 4: 实战 (4-8 周)
    ├── 为 vLLM 添加一个新 Kernel (如 fused rmsnorm+quant)
    ├── CUDA Graphs 集成到 serving pipeline
    ├── Nsight Compute 深度 Profile (roofline, SOL, stall)
    └── 阅读 FlashAttention-3 (H100 新特性)

  Ongoing: 持续学习
    ├── 跟踪 NVIDIA 新硬件 (B200, GB200)
    ├── 学习 Triton (高层 DSL, 开发效率高)
    └── 关注 CUTLASS 更新 (CuTe, SM90 support)
```

---

## 附录: 快速参考卡片

### A100 SM 架构参数

```
+────────────────────────────────────────────+
| A100 SM 关键参数                            |
+────────────────────────────────────────────+
| SM 数量:              108                   |
| 最大线程/SM:          2048                  |
| 最大 Block/SM:        32                    |
| 最大 Warp/SM:         64                    |
| Warp 大小:            32 threads            |
| 寄存器文件/SM:        65536 × 32-bit        |
| Shared Memory/SM:     164 KB (max config)   |
| L1 Cache/SM:          192 KB                |
| Tensor Cores/SM:      4 (3rd gen)           |
| Warp Schedulers/SM:   4                     |
| L2 Cache:             40 MB                 |
| HBM2e Bandwidth:      2.0 TB/s              |
| FP16 TC TFLOPS:       312                   |
+────────────────────────────────────────────+
```

### 常用编译选项

```bash
# 编译 CUDA Kernel
nvcc -O3 -arch=sm_80 \
     --ptxas-options=-v \           # 输出寄存器/Shared Memory 使用
     --use_fast_math \              # 快速数学 (牺牲少量精度)
     --restrict \                   # 允许 restrict 关键字优化
     -maxrregcount=64 \             # 限制寄存器使用量
     -Xptxas -dlcm=ca \             # cache global loads (ca=cache all)
     -lineinfo \                    # Nsight Compute 中显示行号
     -o kernel.cubin kernel.cu

# Nsight Compute Profile
ncu --set full \                    # 完整指标集
    --target-processes all \
    --kernel-name regex:.*gemm.* \  # 只 profile GEMM kernel
    --launch-skip 0 \
    --launch-count 1 \
    -o report \
    ./my_program

# Nsight Compute 查看报告
ncu-ui report.ncu-rep               # GUI
ncu --import report.ncu-rep --page details  # CLI
```

### 延迟参考 (A100)

```
+─────────────────────────────────────────────────+
| 操作                     | 延迟 (cycles)         |
+─────────────────────────────────────────────────+
| 寄存器访问                | ~0 (bypassed)        |
| Shared Memory             | ~20-30               |
| L1 Cache Hit              | ~30-50               |
| L2 Cache Hit              | ~200-300             |
| HBM (DRAM)                | ~300-800             |
| Warp Shuffle              | ~1-2                 |
| cp.async (to shared)      | ~100-200 (pipelined) |
| Tensor Core (mma.sync)    | ~1 inst/sec (piped)  |
| __syncthreads             | ~20-50               |
| Atomic (no contention)    | ~30-50               |
| Atomic (high contention)  | ~1000+               |
+─────────────────────────────────────────────────+
```

---

> **文档版本:** v1.0
> **最后更新:** 2026-07
> **适用范围:** CUDA 12.x, A100 (SM80), H100 (SM90)
