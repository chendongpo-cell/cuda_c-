# DeepSpeed ZeRO：零冗余优化器深度解析

## 目录

1. [DeepSpeed 概述](#1-deepspeed-概述)
2. [大模型训练的内存瓶颈](#2-大模型训练的内存瓶颈)
3. [ZeRO-1：切分优化器状态](#3-zero-1切分优化器状态)
4. [ZeRO-2：切分优化器状态与梯度](#4-zero-2切分优化器状态与梯度)
5. [ZeRO-3：切分优化器状态、梯度与参数](#5-zero-3切分优化器状态梯度与参数)
6. [内存分析对照表](#6-内存分析对照表)
7. [ZeRO-Infinity：CPU 与 NVMe 卸载](#7-zero-infinitycpu-与-nvme-卸载)
8. [ZeRO++：通信优化](#8-zero通信优化)
9. [DeepSpeed 配置文件深度拆解](#9-deepspeed-配置文件深度拆解)
10. [DeepSpeed 与其他框架对比](#10-deepspeed-与其他框架对比)
11. [DeepSpeed 推理引擎](#11-deepspeed-推理引擎)
12. [实际案例与代码](#12-实际案例与代码)
13. [深入学习资源](#13-深入学习资源)

---

## 1. DeepSpeed 概述

DeepSpeed 是微软开源的大规模分布式训练库，核心设计目标是让研究人员能够在有限的 GPU 资源上训练超大模型。它的核心创新是 **ZeRO（Zero Redundancy Optimizer，零冗余优化器）** 协议，以及与其配套的 **ZeRO-Infinity** 卸载技术和 **ZeRO++** 通信优化。

```
┌─────────────────────────────────────────────────────────────────────┐
│                        DeepSpeed 技术栈                              │
│                                                                     │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐     │
│   │  ZeRO Stage 1 │  │  ZeRO Stage 2 │  │   ZeRO Stage 3      │     │
│   │  切分优化器    │  │  切分梯度     │  │   切分参数            │     │
│   └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘     │
│          │                 │                      │                 │
│          └─────────────────┴──────────────────────┘                 │
│                            │                                        │
│   ┌────────────────────────┴──────────────────────────────┐        │
│   │              ZeRO-Infinity（CPU + NVMe 卸载）           │        │
│   └───────────────────────────────────────────────────────┘        │
│                            │                                        │
│   ┌────────────────────────┴──────────────────────────────┐        │
│   │              ZeRO++（通信量化 + 分层分区）              │        │
│   └───────────────────────────────────────────────────────┘        │
│                                                                     │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐     │
│   │ DeepSpeed     │  │ DeepSpeed    │  │ DeepSpeed            │     │
│   │ Inference     │  │ MII          │  │ Chat                 │     │
│   └──────────────┘  └──────────────┘  └──────────────────────┘     │
└─────────────────────────────────────────────────────────────────────┘
```

DeepSpeed 的核心设计理念是在**数据并行（Data Parallelism）** 的基础上，通过消除分布在多 GPU 上的冗余状态来最大化可训练模型规模。它与张量并行（TP）和流水线并行（PP）互补，常组合成 **3D 并行**（DP × TP × PP）。

### 1.1 为什么需要 DeepSpeed

标准数据并行（DDP，Distributed Data Parallel）是最简单的分布式训练方式：每个 GPU 持有一份完整的模型副本，处理不同的 mini-batch，然后对梯度做 all-reduce 来同步参数。它的通信效率很高，但有一个致命缺陷：**每个 GPU 都需要存储完整的模型状态**。

对于大语言模型，这个「完整状态」非常大：

```
┌──────────────────────────────────────────────────────────────────┐
│              标准 DDP 单 GPU 显存占用分解                          │
│                                                                  │
│   ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│   │ 模型参数 Φ   │  │ 梯度 ∂L/∂Φ  │  │ 优化器状态   │             │
│   │ (Params)     │  │ (Gradients) │  │ (States)     │             │
│   │              │  │              │  │              │             │
│   │  FP16: 2×Φ  │  │  FP16: 2×Φ  │  │  Adam: 12×Φ  │             │
│   │  字节        │  │  字节        │  │  字节        │             │
│   └─────────────┘  └─────────────┘  └─────────────┘             │
│          ─────────────────────────────────────                   │
│           总计: (2 + 2 + 12) × Φ = 16 × Φ 字节                     │
│                                                                  │
│   例子: 7B 模型 (FP16) = 16 × 7B = 112 GB（显然放不进单卡）        │
└──────────────────────────────────────────────────────────────────┘
```

ZeRO 的洞察很简单：**这 16×Φ 字节的内存，绝大多数在不同 GPU 之间是冗余的**。如果我们把优化器状态、梯度、甚至参数都切分到不同的 GPU 上，每个 GPU 就只需要存 1/N 的数据，同时通过一次额外的通信来访问其他 GPU 上的数据。

---

## 2. 大模型训练的内存瓶颈

### 2.1 显存占用详细分解

训练期间的 GPU 显存可以被精确地分为以下几类。我们用 Φ 表示模型参数量（以元素个数计）。

```
┌─────────────────────────────────────────────────────────────────┐
│                      模型状态内存 (Model States)     ≈16Φ 字节    │
│                                                                 │
│   ┌───────────────────┐                                        │
│   │  参 数 (Params)    │ ←─ FP16 存储: 2Φ 字节                  │
│   │  所有权重 + 偏置    │   (可以用 FP32 master: 4Φ 字节)        │
│   └───────────────────┘                                        │
│                                                                 │
│   ┌───────────────────┐                                        │
│   │  梯 度 (Grads)    │ ←─ FP16 存储: 2Φ 字节                  │
│   │  反向传播计算得到   │   (可以 FP32 reduce: 4Φ 字节)          │
│   └───────────────────┘                                        │
│                                                                 │
│   ┌───────────────────┐                                        │
│   │ 优化器状态 (Opt)   │ ←─ Adam: 12Φ 字节                      │
│   │  m (动量)   : 4Φ  │    m:      FP32, Φ 个元素 → 4Φ 字节    │
│   │  v (方差)   : 4Φ  │    v:      FP32, Φ 个元素 → 4Φ 字节    │
│   │  fp32 param: 4Φ  │    param:  FP32, Φ 个元素 → 4Φ 字节    │
│   └───────────────────┘                                        │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                      残余状态内存 (Residual States)              │
│                                                                 │
│   激活值 (Activations)    ∝ batch × seq_len × hidden × layers   │
│   临时缓冲区 (Buffers)    ~几 GB（如 all-reduce buffer）         │
│   显存碎片 (Fragmentation) ←─ 动态分配导致，不可忽略             │
│   CUDA 上下文             ~0.5-1 GB                             │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Adam 优化器状态为何是 12 字节 / 参数

```
Adam 更新公式:
─────────────────────────────────────────────────────────────────

对于每个参数 θ:
    m_t = β₁·m_{t-1} + (1-β₁)·g_t         ← FP32, 4 字节/参数
    v_t = β₂·v_{t-1} + (1-β₂)·g_t²        ← FP32, 4 字节/参数
    θ_t = θ_{t-1} - lr · m̂_t / (√v̂_t + ε) ← FP32 master: 4 字节/参数

─────────────────────────────────────────────────────────────────
FP16 混合精度训练 (apex 风格) 的内存布局:

    GPU 显存中的结构:
    ┌──────────────────────────────────────────────────────┐
    │  param_fp16   [H, H]    →  2 × H² 字节               │
    │  param_fp32   [H, H]    →  4 × H² 字节  (master)    │
    │  grad_fp16    [H, H]    →  2 × H² 字节               │
    │  exp_avg (m)  [H, H]    →  4 × H² 字节               │
    │  exp_avg_sq(v)[H, H]    →  4 × H² 字节               │
    │                                                      │
    │  总计: 16 × H² 字节 = 16 × Φ 字节                      │
    └──────────────────────────────────────────────────────┘
```

### 2.3 大模型的内存需求计算

| 模型规模 | 参数量 Φ | FP16 参数 (2Φ) | 模型状态总量 (16Φ) | 仅参数 | 含优化器 |
|---------|----------|----------------|---------------------|--------|----------|
| GPT-2 1.5B | 1.5B | 3 GB | 24 GB | 3 GB | 24 GB |
| GPT-Neo 2.7B | 2.7B | 5.4 GB | 43.2 GB | 5.4 GB | 43.2 GB |
| LLaMA 7B | 7B | 14 GB | 112 GB | 14 GB | 112 GB |
| LLaMA 13B | 13B | 26 GB | 208 GB | 26 GB | 208 GB |
| LLaMA 30B | 30B | 60 GB | 480 GB | 60 GB | 480 GB |
| LLaMA 65B | 65B | 130 GB | 1.04 TB | 130 GB | 1.04 TB |
| GPT-3 175B | 175B | 350 GB | 2.8 TB | 350 GB | 2.8 TB |

```
关键洞察:
────────────────────────────────────────────────────────────
即使只有推理（无优化器、无梯度），7B FP16 模型就需要 14GB。
加上标准优化器和梯度，单 GPU 最多能训 ~1.5B 模型（假设 24GB 显存）。
ZeRO 的核心目标就是把 "16Φ bytes/GPU" 降到 "(16Φ)/N bytes/GPU"。
────────────────────────────────────────────────────────────
```

---

## 3. ZeRO-1：切分优化器状态

### 3.1 基本原理

ZeRO-1 仅切分优化器状态（optimizer states），参数和梯度仍然保持完整副本。

```
ZeRO-1 数据布局（4 GPU）:
────────────────────────────────────────────────────────────────────

    GPU0        GPU1        GPU2        GPU3
    ┌─────┐    ┌─────┐    ┌─────┐    ┌─────┐
    │ Params  │    │ Params  │    │ Params  │    │ Params  │  ← 完整副本
    │  [Φ]   │    │  [Φ]   │    │  [Φ]   │    │  [Φ]   │
    ├─────┤    ├─────┤    ├─────┤    ├─────┤
    │ Grads   │    │ Grads   │    │ Grads   │    │ Grads   │  ← 完整副本
    │  [Φ]   │    │  [Φ]   │    │  [Φ]   │    │  [Φ]   │
    ├─────┤    ├─────┤    ├─────┤    ├─────┤
    │ Opt [0] │    │ Opt [1] │    │ Opt [2] │    │ Opt [3] │  ← 各存 1/4
    │ Φ/4     │    │ Φ/4     │    │ Φ/4     │    │ Φ/4     │
    └─────┘    └─────┘    └─────┘    └─────┘

    每 GPU 内存 = 2Φ (params) + 2Φ (grads) + 12Φ/4 (opt) = 4Φ + 3Φ = 7Φ 字节
    vs DDP: 16Φ → 节省: 56.25%
```

### 3.2 通信模式

ZeRO-1 的通信和标准 DDP 完全相同：使用 all-reduce 聚集梯度。

```
ZeRO-1 一次训练步骤的通信:
══════════════════════════════════════════════════════════════════════

时间轴 ──────────────────────────────────────────────────→

Step 1: 前向传播 (Forward)
  ┌─────────────────────────────────────────┐
  │  每个 GPU 用自己的数据 batch 做 forward   │  ← 无通信
  │  (参数相同，数据不同)                      │
  └─────────────────────────────────────────┘

Step 2: 反向传播 (Backward)
  ┌─────────────────────────────────────────┐
  │  每个 GPU 计算自己的局部梯度               │  ← 无通信
  │  ∂L_i/∂θ                                │
  └─────────────────────────────────────────┘

Step 3: 梯度 All-Reduce
  ┌─────────────────────────────────────────┐
  │  all-reduce(grads)  ← 所有 GPU 的梯度平均  │  ← 通信发生!
  │                                         │
  │  GPU0  ─────────── grad0 ───────────→   │
  │  GPU1  ─────────── grad1 ───────────→   │
  │  GPU2  ─────────── grad2 ───────────→   │   通信量: 2Φ 字节/GPU
  │  GPU3  ─────────── grad3 ───────────→   │   ring all-reduce
  │         ←────── avg(grads) ───────←     │
  └─────────────────────────────────────────┘

Step 4: 优化器更新 (Optimizer Step)
  ┌─────────────────────────────────────────┐
  │  每个 GPU 更新自己负责的参数分片           │  ← 无通信
  │  GPU0: θ[0:Φ/4] 的优化器更新              │
  │  GPU1: θ[Φ/4:Φ/2] 的优化器更新            │
  │  ...                                    │
  └─────────────────────────────────────────┘

Step 5: 参数广播 (All-Gather)
  ┌─────────────────────────────────────────┐
  │  每个 GPU all-gather 更新后的参数         │  ← 通信发生!
  │  这样所有 GPU 又持有完整的参数副本         │     通信量: 2Φ 字节/GPU
  └─────────────────────────────────────────┘

══════════════════════════════════════════════════════════════════════
ZeRO-1 总通信量: 2Φ (grad all-reduce) + 2Φ (param all-gather) = 4Φ
与 DDP 相同（DDP: 2Φ grad all-reduce + 0 param comm = 2Φ? 不对...）
══════════════════════════════════════════════════════════════════════
```

实际上，标准的 DDP 在所有 reduce 梯度后，每个 GPU 各自做 optimizer.step()（参数相同），然后进行下一次 forward（无需额外参数同步）。所以 DDP 的通信量是：**2Φ 字节/步**（仅 gradient all-reduce）。

ZeRO-1 需要额外一次参数 all-gather，总通信量 = 2Φ (grad) + 2Φ (param) = **4Φ 字节/步**。

### 3.3 代码示例

```python
# ZeRO-1 配置示例
import deepspeed
import torch
from transformers import AutoModelForCausalLM

model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-7b-hf")

# DeepSpeed ZeRO-1 配置
ds_config = {
    "train_batch_size": 32,
    "gradient_accumulation_steps": 1,
    "optimizer": {
        "type": "AdamW",
        "params": {
            "lr": 3e-5,
            "betas": [0.9, 0.999],
            "eps": 1e-8,
            "weight_decay": 0.01
        }
    },
    "scheduler": {
        "type": "WarmupDecayLR",
        "params": {
            "total_num_steps": 10000,
            "warmup_min_lr": 0,
            "warmup_max_lr": 3e-5,
            "warmup_num_steps": 1000
        }
    },
    "fp16": {
        "enabled": True
    },
    "zero_optimization": {
        "stage": 1,                    # <-- ZeRO-1
        "reduce_bucket_size": 5e8,     # all-reduce 桶大小
        "allgather_bucket_size": 5e8,   # all-gather 桶大小
    }
}

# 初始化 DeepSpeed 引擎
model_engine, optimizer, _, _ = deepspeed.initialize(
    model=model,
    config=ds_config,
    model_parameters=model.parameters()
)

# 训练循环
for batch in dataloader:
    loss = model_engine(batch)         # forward
    model_engine.backward(loss)        # backward + grad all-reduce
    model_engine.step()                # optimizer step + param all-gather
```

### 3.4 ZeRO-1 内存计算（详细）

```
ZeRO-1 每 GPU 显存 = 参数 + 梯度 + 优化器状态/N + 激活值 + 碎片

浮点格式假设: FP16 参数/梯度, FP32 优化器状态

┌──────────────────┬──────────────┬──────────────┬──────────────┐
│      组件         │   1 GPU      │   8 GPU      │   64 GPU     │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│ 参数 (2Φ)         │   14.00 GB   │   14.00 GB   │   14.00 GB   │
│ 梯度 (2Φ)         │   14.00 GB   │   14.00 GB   │   14.00 GB   │
│ 优化器 (12Φ/N)    │   84.00 GB   │   10.50 GB   │    1.31 GB   │
│ 激活值 (估计)     │    ~5 GB     │    ~5 GB     │    ~5 GB    │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│ 总计 (7B 模型)    │  117.00 GB   │   43.50 GB   │   34.31 GB   │
│ 是否可训练        │     ✗        │  勉强 (A6000)│      ✓       │
└──────────────────┴──────────────┴──────────────┴──────────────┘

注意: 即使 N→∞，ZeRO-1 也无法将内存降到 2Φ+2Φ = 4Φ = 28GB 以下
     因为参数和梯度始终是完整副本。
```

---

## 4. ZeRO-2：切分优化器状态与梯度

### 4.1 基本原理

ZeRO-2 在 ZeRO-1 基础上进一步切分梯度，每个 GPU 只存储它所负责的那部分参数的梯度。

```
ZeRO-2 数据布局（4 GPU）:
────────────────────────────────────────────────────────────────────

    GPU0             GPU1             GPU2             GPU3
    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │ Params    │    │ Params    │    │ Params    │    │ Params    │  ← 完整副本
    │  [Φ]     │    │  [Φ]     │    │  [Φ]     │    │  [Φ]     │
    ├──────────┤    ├──────────┤    ├──────────┤    ├──────────┤
    │ Grads [0] │    │ Grads [1] │    │ Grads [2] │    │ Grads [3] │  ← 各存 1/4
    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │
    ├──────────┤    ├──────────┤    ├──────────┤    ├──────────┤
    │ Opt [0]   │    │ Opt [1]   │    │ Opt [2]   │    │ Opt [3]   │  ← 各存 1/4
    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │
    └──────────┘    └──────────┘    └──────────┘    └──────────┘

    每 GPU 内存 = 2Φ + 2Φ/4 + 12Φ/4 = 2Φ + 3.5Φ = 5.5Φ 字节
    vs DDP: 16Φ → 节省: 65.6%
    vs ZeRO-1: 7Φ → 额外节省: 21.4%
```

### 4.2 通信模式：Reduce-Scatter 替代 All-Reduce

这是 ZeRO-2 最重要的创新。ZeRO-2 使用 **reduce-scatter** 替代 **all-reduce**，将通信量减半。

```
标准 All-Reduce (DDP / ZeRO-1):
══════════════════════════════════════════════════════════════════════

    GPU0: [g₀₀, g₀₁, g₀₂, g₀₃]           GPU0: [g₀, g₁, g₂, g₃]
    GPU1: [g₁₀, g₁₁, g₁₂, g₁₃]   ──→     GPU1: [g₀, g₁, g₂, g₃]
    GPU2: [g₂₀, g₂₁, g₂₂, g₂₃]           GPU2: [g₀, g₁, g₂, g₃]
    GPU3: [g₃₀, g₃₁, g₃₂, g₃₃]           GPU3: [g₀, g₁, g₂, g₃]

    每个 GPU 获得完整的平均梯度 [g₀, g₁, g₂, g₃]，每个梯度段都是 4 个 GPU 的平均。
    通信量: 2 × (N-1)/N × total_size ≈ 2 × total_size per GPU


Reduce-Scatter (ZeRO-2):
══════════════════════════════════════════════════════════════════════

    GPU0: [g₀₀, g₀₁, g₀₂, g₀₃]           GPU0: [g₀, -, -, -]
    GPU1: [g₁₀, g₁₁, g₁₂, g₁₃]   ──→     GPU1: [-, g₁, -, -]
    GPU2: [g₂₀, g₂₁, g₂₂, g₂₃]           GPU2: [-, -, g₂, -]
    GPU3: [g₃₀, g₃₁, g₃₂, g₃₃]           GPU3: [-, -, -, g₃]

    每个 GPU 只获得它所负责的那部分参数的平均梯度。
    通信量: (N-1)/N × total_size ≈ total_size per GPU  ← 减半!

    例如: GPU0 只需要 g₀ = mean(g₀₀, g₁₀, g₂₀, g₃₀)
          它不需要知道 g₁, g₂, g₃。
```

**为什么 reduce-scatter 通信量更少？**

```
All-Reduce 的 Ring 算法:
─────────────────────────────────────────────
  Step 1: Scatter-Reduce (N-1 步，每步发送 Φ/N 数据)
        总发送: Φ × (N-1)/N

  Step 2: All-Gather (N-1 步，每步发送 Φ/N 数据)
        总发送: Φ × (N-1)/N

  总计: 2Φ × (N-1)/N ≈ 2Φ per GPU


Reduce-Scatter 只需要 Step 1:
─────────────────────────────────────────────
  Scatter-Reduce: (N-1 步，每步发送 Φ/N 数据)
        总发送: Φ × (N-1)/N ≈ Φ per GPU

  恰好是 all-reduce 的一半!
```

### 4.3 ZeRO-2 完整训练步骤通信分析

```
ZeRO-2 一次迭代的详细流程:
══════════════════════════════════════════════════════════════════════

Step 1: 前向传播 (Forward)
  ┌─────────────────────────────────────────────────────────┐
  │  参数完整，计算正常 forward                                │
  │  loss = model(batch_i)                                   │
  └─────────────────────────────────────────────────────────┘
                                    通信: 0

Step 2: 反向传播 (Backward)
  ┌─────────────────────────────────────────────────────────┐
  │  计算局部梯度 ∂L_i/∂θ                                    │
  │  在每个参数层计算完梯度后，立即 或 累积后 reduce-scatter  │
  │                                                         │
  │  Bucket 机制:                                           │
  │    - 梯度累积到 reduce_bucket_size 后就做 reduce-scatter │
  │    - 做完的梯度立即释放完整副本，只保留自己负责的分片     │
  │    - 通信可以与计算重叠 (overlap)                        │
  └─────────────────────────────────────────────────────────┘
                                    通信: Φ 字节 (reduce-scatter)

Step 3: 优化器更新 (Optimizer Step)
  ┌─────────────────────────────────────────────────────────┐
  │  每个 GPU 只用它的梯度分片更新对应的参数分片              │
  │  需要 FP32 master 参数 → 从 FP16 参数 cast 到 FP32       │
  │  optimizer.step() → 更新 FP32 master                     │
  │  更新后的 FP16 参数 → cast 回 FP16                        │
  └─────────────────────────────────────────────────────────┘
                                    通信: 0

Step 4: 参数 All-Gather (用于下一次 forward)
  ┌─────────────────────────────────────────────────────────┐
  │  所有 GPU 通过 all-gather 获取更新后的完整参数             │
  │  all_gather(param_shard_i) → 每个 GPU 获得完整参数        │
  │                                                         │
  │  重叠策略: 可以边 all-gather 边开始下一层的 forward       │
  │  (prefetching, 预取)                                    │
  └─────────────────────────────────────────────────────────┘
                                    通信: Φ 字节 (all-gather)

══════════════════════════════════════════════════════════════════════
ZeRO-2 总通信量: Φ (reduce-scatter) + Φ (all-gather) = 2Φ 字节
ZeRO-1 总通信量: 2Φ (all-reduce) + 2Φ (param all-gather) = 4Φ 字节
DDP 总通信量:    2Φ (all-reduce) = 2Φ 字节

结论: ZeRO-2 的通信量与 DDP 相同，但内存只有 DDP 的 ~1/3!
      这是 ZeRO-2 被广泛采用的核心原因。
══════════════════════════════════════════════════════════════════════
```

### 4.4 ZeRO-2 代码示例

```python
# ZeRO-2 配置
ds_config_stage2 = {
    "train_batch_size": 32,
    "gradient_accumulation_steps": 4,
    "optimizer": {
        "type": "AdamW",
        "params": {
            "lr": 1e-4,
            "betas": [0.9, 0.95],
            "eps": 1e-8,
            "weight_decay": 0.1
        }
    },
    "scheduler": {
        "type": "WarmupLR",
        "params": {
            "warmup_min_lr": 0,
            "warmup_max_lr": 1e-4,
            "warmup_num_steps": 500
        }
    },
    "fp16": {
        "enabled": True,
        "loss_scale": 0,              # 动态 loss scaling
        "loss_scale_window": 1000,    # 缩放窗口
        "initial_scale_power": 16,    # 初始缩放因子 2^16
        "hysteresis": 2,              # 延迟缩放因子
        "min_loss_scale": 1           # 最小缩放因子
    },
    "zero_optimization": {
        "stage": 2,                          # <-- ZeRO-2
        "reduce_bucket_size": 5e8,           # 500M 参数/桶
        "allgather_bucket_size": 5e8,        # 500M 参数/桶
        "overlap_comm": True,                # 通信与计算重叠
        "contiguous_gradients": True,        # 连续内存拷贝优化
        "reduce_scatter": True,              # 使用 reduce-scatter
    },
    "gradient_clipping": 1.0,               # 梯度裁剪
    "steps_per_print": 100,
    "wall_clock_breakdown": False
}

model_engine, optimizer, _, _ = deepspeed.initialize(
    model=model,
    config=ds_config_stage2,
    model_parameters=model.parameters()
)

# 在 ZeRO-2 下，梯度会自动被切分
# backward 后，每个 GPU 只保存它所负责部分的梯度
```

---

## 5. ZeRO-3：切分优化器状态、梯度与参数

### 5.1 基本原理

ZeRO-3 是 ZeRO 的终极形态：连参数本身也被切分。每个 GPU 只持有总参数的 1/N。

```
ZeRO-3 数据布局（4 GPU）:
────────────────────────────────────────────────────────────────────

    GPU0             GPU1             GPU2             GPU3
    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │ Params[0]│    │ Params[1]│    │ Params[2]│    │ Params[3]│  ← 各存 1/4
    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │
    ├──────────┤    ├──────────┤    ├──────────┤    ├──────────┤
    │ Grads [0]│    │ Grads [1]│    │ Grads [2]│    │ Grads [3]│  ← 各存 1/4
    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │
    ├──────────┤    ├──────────┤    ├──────────┤    ├──────────┤
    │ Opt [0]  │    │ Opt [1]  │    │ Opt [2]  │    │ Opt [3]  │  ← 各存 1/4
    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │    │  Φ/4     │
    └──────────┘    └──────────┘    └──────────┘    └──────────┘

    每 GPU 内存 = (2Φ + 2Φ + 12Φ) / 4 = 16Φ / 4 = 4Φ 字节
    vs DDP: 16Φ → 节省: 75%
    vs ZeRO-2: 5.5Φ → 额外节省: 27.3%

    关键: ZeRO-3 的内存随 GPU 数量线性缩放!
          16 GPUs → 1Φ/GPU, 64 GPUs → 0.25Φ/GPU
```

### 5.2 核心机制：按需收集与释放参数

因为参数本身被切分，每个 GPU 在做 forward/backward 时需要临时收集完整的参数。

```
ZeRO-3 前向传播详细机制:
══════════════════════════════════════════════════════════════════════

    对于每一层 Layer L_i:

    GPU0                          GPU1                          GPU2
    ┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐
    │ 需要 Layer L_i   │         │ 需要 Layer L_i   │         │ 需要 Layer L_i   │
    │ 的完整参数来做   │         │ 的完整参数来做   │         │ 的完整参数来做   │
    │ forward          │         │ forward          │         │ forward          │
    └────────┬────────┘         └────────┬────────┘         └────────┬────────┘
             │                           │                           │
             └───────────────────────────┼───────────────────────────┘
                                         │
                             ┌───────────▼───────────┐
                             │  All-Gather 操作      │
                             │                       │
                             │  GPU0 发送 Param[0]   │
                             │  GPU1 发送 Param[1]   │
                             │  GPU2 发送 Param[2]   │
                             │                       │
                             │  → 每个 GPU 获得      │
                             │    完整的 Layer L_i   │
                             │    参数                │
                             └───────────┬───────────┘
                                         │
             ┌───────────────────────────┼───────────────────────────┐
             │                           │                           │
    ┌────────▼────────┐         ┌────────▼────────┐         ┌────────▼────────┐
    │ 执行 forward     │         │ 执行 forward     │         │ 执行 forward     │
    │ output = L_i(x)  │         │ output = L_i(x)  │         │ output = L_i(x)  │
    └────────┬────────┘         └────────┬────────┘         └────────┬────────┘
             │                           │                           │
    ┌────────▼────────┐         ┌────────▼────────┐         ┌────────▼────────┐
    │ 释放非本地参数    │         │ 释放非本地参数    │         │ 释放非本地参数    │
    │ 只保留 Param[i]  │         │ 只保留 Param[i]  │         │ 只保留 Param[i]  │
    └─────────────────┘         └─────────────────┘         └─────────────────┘

            继续处理 Layer L_{i+1}...
```

**反向传播同理**：backward 时需要再次 all-gather 该层的完整参数（除非使用了参数缓存）。

### 5.3 通信量分析

```
ZeRO-3 每层每步的通信:
══════════════════════════════════════════════════════════════════════

Forward:
    all-gather(layer_params)      ← 收集完整参数
    通信量: (N-1)/N × 2Φ ≈ 2Φ 字节 (per layer, per step)


Backward:
    all-gather(layer_params)      ← 再次收集完整参数 (或在缓存中)
    通信量: (N-1)/N × 2Φ ≈ 2Φ 字节 (per layer, per step)

    reduce-scatter(layer_grads)   ← 切分梯度
    通信量: (N-1)/N × 2Φ ≈ 2Φ 字节 (per layer, per step)

    总 backward 通信: ≈ 4Φ 字节


══════════════════════════════════════════════════════════════════════
ZeRO-3 总通信量: 2Φ (fw all-gather) + 4Φ (bw all-gather + reduce-scatter)
               = 6Φ 字节 per step
               ≈ 3 × DDP 的通信量

但是内存节省了 N 倍！
这是通信与内存之间经典的权衡。
══════════════════════════════════════════════════════════════════════
```

### 5.4 通信优化技巧

```
技巧 1: Prefetching (预取)
─────────────────────────────────────────────────────────────────
不是等前一层 forward 完才开始 all-gather 下一层的参数，
而是在前一层计算时，后台就开始下一层的 all-gather。

    Layer i-1: [============= compute forward =============]
    Layer i:         [=== all-gather ===][=== compute ===]
    Layer i+1:                           [=== all-gather ===]
    Layer i+2:                                             [...]

    延迟: 理想情况下，all-gather 时间被计算时间完全隐藏。


技巧 2: Overlap (重叠)
─────────────────────────────────────────────────────────────────
将 all-gather 分成小的 bucket，每个 bucket 一到就开始计算。

    all_gather(bucket_0) → compute(bucket_0) →
    all_gather(bucket_1) → compute(bucket_1) →
    ...

    all-gather 和计算在时间轴上交替进行。


技巧 3: 参数缓存
─────────────────────────────────────────────────────────────────
    如果显存充足，可以保留完整的收集后参数直到 backward 完成。
    参数: stage3_param_persistence_threshold

    这样 backward 时就不需要再次 all-gather 参数。
    代价: 显存占用增加（等同 ZeRO-2 的参数部分）。

    在显存和通信之间做权衡:
    - 显存够 → 缓存参数 → 减少 1 次 all-gather → 通信量降到 4Φ
    - 显存紧 → 不缓存 → 两次 all-gather → 通信量 6Φ
```

### 5.5 ZeRO-3 代码示例

```python
# ZeRO-3 完整配置
ds_config_stage3 = {
    "train_batch_size": 64,
    "train_micro_batch_size_per_gpu": 1,
    "gradient_accumulation_steps": 8,
    "optimizer": {
        "type": "AdamW",
        "params": {
            "lr": 5e-5,
            "betas": [0.9, 0.95],
            "eps": 1e-8,
            "weight_decay": 0.1
        }
    },
    "scheduler": {
        "type": "WarmupDecayLR",
        "params": {
            "total_num_steps": 2000,
            "warmup_min_lr": 0,
            "warmup_max_lr": 5e-5,
            "warmup_num_steps": 100
        }
    },
    "fp16": {
        "enabled": True
    },
    "bf16": {
        "enabled": False
    },
    "zero_optimization": {
        "stage": 3,
        # ───────────── 内存优化 ─────────────
        "offload_optimizer": {
            "device": "none",         # "cpu" 或 "nvme"
            "pin_memory": True        # 锁页内存加速传输
        },
        "offload_param": {
            "device": "none",         # "cpu" 或 "nvme"
            "pin_memory": True
        },

        # ───────────── 通信优化 ─────────────
        "overlap_comm": True,          # 通信计算重叠
        "contiguous_gradients": True,  # 梯度连续内存
        "reduce_bucket_size": 5e8,     # reduce-scatter 桶大小
        "allgather_bucket_size": 5e8,  # all-gather 桶大小

        # ───────────── ZeRO-3 特有 ─────────────
        "stage3_prefetch_bucket_size": 5e8,    # 预取桶大小
        "stage3_param_persistence_threshold": 1e6,  # 参数持久化阈值
        #   ↑ 小于这个大小的参数始终保留在 GPU 上（减少小参数的通信开销）
        "stage3_max_live_parameters": 1e9,     # 同时活跃的最大参数量
        "stage3_max_reuse_distance": 1e9,      # 参数重用距离
        "stage3_gather_16bit_weights_on_model_save": True,  # 保存时收集 FP16 权重

        # ───────────── 子模块分组 ─────────────
        "sub_group_size": 1e9,         # 子分组大小（用于收敛速度）
    },
    "gradient_clipping": 1.0,
    "steps_per_print": 10,
    "wall_clock_breakdown": False,
    "activation_checkpointing": {
        "partition_activations": False,  # 是否切分激活值检查点
        "cpu_checkpointing": False,      # 是否将检查点移到 CPU
        "number_checkpoints": None,      # 检查点数量
        "synchronize_checkpoint_boundary": False,
        "profile": False
    }
}

# 初始化
model_engine, optimizer, _, _ = deepspeed.initialize(
    model=model,
    config=ds_config_stage3,
    model_parameters=model.parameters()
)
```

### 5.6 参数分区策略

```
ZeRO-3 的参数如何被分区:
══════════════════════════════════════════════════════════════════════

策略: 按参数顺序均匀切分，按 DP rank 分配到 GPU。

    假设模型有 4 层，每层 2 个参数矩阵 (W1, W2)：
    总共 8 个参数矩阵: [L0W1, L0W2, L1W1, L1W2, L2W1, L2W2, L3W1, L3W2]

    GPU0 持有: [L0W1, L0W2]           ← 前 2 个矩阵的全部参数
    GPU1 持有: [L1W1, L1W2]           ← 接下来 2 个
    GPU2 持有: [L2W1, L2W2]           ← 接下来 2 个
    GPU3 持有: [L3W1, L3W2]           ← 最后 2 个

    Forward Layer 0:
      所有 GPU all-gather L0W1, L0W2 → 临时获得完整参数
      计算 forward
      释放非本地参数

    Forward Layer 1:
      所有 GPU all-gather L1W1, L1W2 → 临时获得完整参数
      计算 forward
      释放非本地参数

    ... 依次类推


更细粒度的分区 (按参数张量内部切分):
────────────────────────────────────────────────────────────────
    对于单个大矩阵 W ∈ R^(H×H):
    GPU0: W[0:H/4, :]     ← 前 1/4 行
    GPU1: W[H/4:H/2, :]   ← 接下来 1/4 行
    GPU2: W[H/2:3H/4, :]  ← 接下来 1/4 行
    GPU3: W[3H/4:H, :]    ← 最后 1/4 行

    例: Llama 7B 的 QKV 投影矩阵 (4096×4096):
    GPU0: 前 1024 行 (4096×1024)
    GPU1: 接下来的 1024 行
    GPU2: 再接下来的 1024 行
    GPU3: 最后 1024 行

    这种切分方式的 all-gather = 按行拼接。
```

---

## 6. 内存分析对照表

### 6.1 不同规模模型的内存需求

以下表格展示不同配置下的单 GPU 内存需求。**激活值未计入**（激活值通常 1-10GB，取决于 batch size 和序列长度）。

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         模型状态显存需求 (单位: GB)                              │
│                         公式: 参数 FP16/FP32 + 梯度 + 优化器状态                    │
├────────────┬─────────┬──────────┬──────────┬───────────┬───────────┬──────────┤
│ 模型规模    │ 参数量   │ 仅参数    │ 仅参数    │  DDP      │  ZeRO-1   │  ZeRO-2  │
│            │         │ FP16     │ FP32     │  (FP16)   │  (8 GPU)  │  (8 GPU) │
├────────────┼─────────┼──────────┼──────────┼───────────┼───────────┼──────────┤
│ 1.5B       │ 1.5B    │   3 GB   │   6 GB   │   24 GB   │  11.6 GB  │  8.3 GB  │
│ 2.7B       │ 2.7B    │  5.4 GB  │ 10.8 GB  │  43.2 GB  │  20.9 GB  │ 14.9 GB  │
│ 7B         │ 7B      │  14 GB   │  28 GB   │  112 GB   │  43.5 GB  │ 36.0 GB  │
│ 13B        │ 13B     │  26 GB   │  52 GB   │  208 GB   │  74.8 GB  │ 59.8 GB  │
│ 30B        │ 30B     │  60 GB   │ 120 GB   │  480 GB   │ 165.0 GB  │135.0 GB  │
│ 65B        │ 65B     │ 130 GB   │ 260 GB   │ 1040 GB   │ 357.5 GB  │292.5 GB  │
│ 175B       │ 175B    │ 350 GB   │ 700 GB   │ 2800 GB   │ 962.5 GB  │787.5 GB  │
└────────────┴─────────┴──────────┴──────────┴───────────┴───────────┴──────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│                     ZeRO-3 单 GPU 显存需求 (单位: GB)                            │
├────────────┬─────────┬──────────┬──────────┬──────────┬──────────┬───────────┤
│ 模型规模    │ 参数量   │ 4 GPU    │ 8 GPU    │ 16 GPU   │ 32 GPU   │ 64 GPU    │
├────────────┼─────────┼──────────┼──────────┼──────────┼──────────┼───────────┤
│ 7B         │ 7B      │ 28.0 GB  │ 14.0 GB  │  7.0 GB  │  3.5 GB  │  1.75 GB  │
│ 13B        │ 13B     │ 52.0 GB  │ 26.0 GB  │ 13.0 GB  │  6.5 GB  │  3.25 GB  │
│ 30B        │ 30B     │120.0 GB  │ 60.0 GB  │ 30.0 GB  │ 15.0 GB  │  7.50 GB  │
│ 65B        │ 65B     │260.0 GB  │130.0 GB  │ 65.0 GB  │ 32.5 GB  │ 16.25 GB  │
│ 175B       │ 175B    │700.0 GB  │350.0 GB  │175.0 GB  │ 87.5 GB  │ 43.75 GB  │
├────────────┴─────────┴──────────┴──────────┴──────────┴──────────┴───────────┤
│ 注: 表中数值 = 16Φ / N。实际总显存 = 表中数值 + 激活值 + 碎片 (~5-15 GB)。       │
│    实际使用中 8×A100(80GB) 可训 175B 模型 (ZeRO-3 + 激活检查点)。                │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 实际训练配置对照

```
典型训练场景配置:
══════════════════════════════════════════════════════════════════════

场景 1: 微调 7B 模型 (单机 8×A100 80GB)
  推荐: ZeRO-2 + BF16
  原因: 通信量低，内存足够，简单高效。
  配置:
    stage: 2
    per_device_batch_size: 4
    gradient_accumulation: 2
    → global_batch: 64

场景 2: 从头训练 7B 模型
  推荐: ZeRO-2 + BF16 + Activation Checkpointing
  原因: 从头训练显存更高 (更大的 batch)，需要激活检查点。
  配置:
    stage: 2
    activation_checkpointing: True
    per_device_batch_size: 1
    gradient_accumulation: 16

场景 3: 微调 30B 模型
  推荐: ZeRO-3 + BF16
  原因: 30B FP16 参数 60GB，8 GPU 下 ZeRO-2 勉强但 ZeRO-3 更安全。
  配置:
    stage: 3
    stage3_param_persistence_threshold: 1e6
    per_device_batch_size: 1
    gradient_accumulation: 8

场景 4: 训练 65B+ 模型 (多机)
  推荐: ZeRO-3 + 激活检查点 + CPU Offload (可选)
  原因: 超大规模，必须每个 GPU 都节省内存。
  配置:
    stage: 3
    offload_optimizer: {device: cpu}
    offload_param: {device: cpu}
    activation_checkpointing: True

场景 5: 训练 175B 模型 (大型集群)
  推荐: ZeRO-3 + TP + PP (3D 并行)
  原因: ZeRO-3 不够，需要组合多种并行策略。
  配合 Megatron-LM 或 DeepSpeed 自己的 3D 并行。
══════════════════════════════════════════════════════════════════════
```

### 6.3 通信量与内存的权衡矩阵

```
══════════════════════════════════════════════════════════════════════
              通信量 vs 内存 vs 可用性 权衡
══════════════════════════════════════════════════════════════════════

             DDP        ZeRO-1      ZeRO-2      ZeRO-3
            ─────       ──────      ──────      ──────
单GPU内存    16Φ         7Φ          5.5Φ        16Φ/N

通信量       2Φ          4Φ          2Φ          6Φ
(per step)

前向通信     0           2Φ          0           2Φ
                            (param     (param all-g 每层)
                             all-g)

后向通信     2Φ          2Φ          2Φ          4Φ
(grad only) (grad all-r)(grad all-r) (grad red-s) (grad red-s
                                                + param all-g)

适用场景    小模型      中等模型    中等-大模型  超大模型
           <1B         <7B         <30B        <100B+

核心权衡   内存 ∝ 通信量 ∝ 训练速度

经验法则:
  显存够 → 用 ZeRO-2（通信量同 DDP，内存省一半）
  显存不够 → 用 ZeRO-3（通信 3 倍，但你能训练了）
  显存完全不够 → ZeRO-3 + offload
══════════════════════════════════════════════════════════════════════
```

---

## 7. ZeRO-Infinity：CPU 与 NVMe 卸载

### 7.1 核心理念

ZeRO-Infinity 是 ZeRO-3 的扩展，将模型状态卸载到 CPU 内存甚至 NVMe SSD 上，GPU 仅持有当前计算所必需的部分。

```
ZeRO-Infinity 的内存层级:
══════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────┐
    │                    GPU HBM (80 GB)                       │
    │  热点数据: 当前层的完整参数 + 激活值 + 计算缓冲区         │
    │  带宽: ~2 TB/s                                          │
    └───────────────────────┬─────────────────────────────────┘
                            │ PCIe/NVLink (50-600 GB/s)
    ┌───────────────────────▼─────────────────────────────────┐
    │                  CPU DRAM (256 GB - 2 TB)                │
    │  温数据: 非当前层参数 + 优化器状态 + 梯度                  │
    │  带宽: ~50 GB/s (DDR5)                                  │
    └───────────────────────┬─────────────────────────────────┘
                            │ PCIe Gen4/5 (8-32 GB/s per SSD)
    ┌───────────────────────▼─────────────────────────────────┐
    │             NVMe SSD (1 TB - 8 TB)                       │
    │  冷数据: 优化器状态全部持久化备份 + 参数检查点             │
    │  带宽: ~7 GB/s (PCIe Gen4 NVMe)                         │
    └─────────────────────────────────────────────────────────┘

    DeepSpeed 的 Offload 引擎自动管理三层之间的数据移动，
    使用 CUDA Stream 异步传输，尽量重叠计算与数据传输。
```

### 7.2 ZeRO-Offload（仅 CPU 卸载）

```
ZeRO-Offload 数据流:
══════════════════════════════════════════════════════════════════════

    ┌─────────────────┐          ┌─────────────────┐
    │      GPU        │  PCIe    │      CPU         │
    │                  │◄────────►│                  │
    │  Forward/Backward│          │  Optimizer Step  │
    │  (参数、激活值)   │          │  (FP32 master)    │
    │                  │          │  m, v 状态        │
    └─────────────────┘          └─────────────────┘
        持有 FP16 参数               持有 FP32 优化器状态
        计算梯度                     执行参数更新

    流程:
    1. GPU 计算 forward/backward → 得到 FP16 梯度
    2. GPU → CPU: 传输梯度 (FP16)
    3. CPU: 将梯度转 FP32，更新 FP32 master 参数
    4. CPU → GPU: 传输更新后的 FP16 参数
    5. GPU: 用新参数做下一轮 forward

    通信量 (per step):
      梯度下载: 2Φ 字节 (GPU→CPU)
      参数上传: 2Φ 字节 (CPU→GPU)
      总计: 4Φ 字节 per step via PCIe

    PCIe 带宽足够吗?
      PCIe Gen4 ×16: ~32 GB/s 单向, ~64 GB/s 双向
      7B 模型: 14 GB params → 14 GB / 32 GB/s ≈ 0.44s 足够
      175B 模型: 350 GB params → 350 / 32 ≈ 11s 可能成为瓶颈
```

### 7.3 ZeRO-Infinity 配置

```python
# ZeRO-3 + CPU Offload + NVMe Offload
ds_config_infinity = {
    "zero_optimization": {
        "stage": 3,
        "offload_optimizer": {
            "device": "cpu",                    # 优化器状态去 CPU
            "pin_memory": True,                 # 锁页内存
            "buffer_count": 4,                  # 缓冲区数量
            "fast_init": False,                 # 快速初始化
            "pipeline_read": False,             # 流水线读取
            "pipeline_write": False,            # 流水线写入
        },
        "offload_param": {
            "device": "cpu",                    # 参数也去 CPU
            "pin_memory": True,
            "buffer_count": 5,
            "buffer_size": 1e8,                 # 1 亿元素/缓冲
            "max_in_cpu": 1e9,                  # CPU 上最多存 1e9 参数
        },
        # NVMe 卸载（用于超大模型）
        "offload_optimizer": {
            "device": "nvme",
            "nvme_path": "/mnt/nvme_fast/offload",  # NVMe 路径
            "buffer_count": 4,
            "buffer_size": 5e8,
        },
        "offload_param": {
            "device": "nvme",
            "nvme_path": "/mnt/nvme_fast/offload",
            "buffer_count": 5,
            "buffer_size": 1e8,
        }
    }
}
```

### 7.4 NVMe 卸载详解

```
NVMe Offload 的工作原理:
══════════════════════════════════════════════════════════════════════

为什么 NVMe 比通过网络传输更好?
─────────────────────────────────────────────────────────────────

场景 A: 2 台机器，每台 8 GPU，NVLink 互联
  GPU 间通信: NVLink 600 GB/s
  跨节点通信: InfiniBand 200 GB/s (或 RoCE 100 GB/s)

  如果做纯 ZeRO-3，跨节点 all-gather 参数：
    每个 GPU 发送: 2Φ × (N-1)/N ≈ 2Φ 字节参数 via IB
    IB 带宽成为瓶颈。

场景 B: 1 台机器 + NVMe Offload
  GPU ↔ NVMe: PCIe Gen4 x4 ≈ 7 GB/s per SSD
  8 块 NVMe RAID0: 8 × 7 = 56 GB/s

  与跨节点网络相比:
    NVMe 56 GB/s (本地) vs IB 200 GB/s (远程，还需考虑延迟)
    但 NVMe 是本地访问，延迟更低 (10us vs 1-10us for IB)
    而且 NVMe 是每台机器独立的，不会竞争网络带宽。

  更重要的是: NVMe 的容量 (TB 级) 远超 GPU HBM (80GB 级) 和 CPU DRAM (TB 级但仍有限)。
```

### 7.5 NVMe Offload 性能模型

```
单层的前向传播时间模型 (with NVMe offload):
─────────────────────────────────────────────────────────────────

    T_layer = max(T_compute, T_data_movement) + T_overhead

    T_compute = FLOPS_layer / GPU_TFLOPS
    T_data_movement = param_size / min(GPU_HBM_bw, PCIe_bw, NVMe_bw)

    以 Llama 7B 的 Attention 层为例:
    - 参数量: ~50M params = 100 MB (FP16)
    - 计算量: ~2× batch × seq × hidden² ≈ 2×1×2048×4096² ≈ 68 GFLOPS
    - GPU 计算时间: 68G / 312 TFLOPS ≈ 0.22 ms

    数据移动时间:
    - GPU HBM: 100 MB / 2000 GB/s ≈ 0.05 ms
    - PCIe (CPU): 100 MB / 50 GB/s ≈ 2 ms
    - NVMe: 100 MB / 7 GB/s ≈ 14 ms

    结论:
    - 纯 GPU: compute-bound (0.22ms > 0.05ms)
    - GPU+CPU: data-bound (2ms >> 0.22ms)  ← CPU offload 成为瓶颈
    - GPU+NVMe: heavily data-bound (14ms >> 0.22ms)  ← 仅用于极端情况

    优化: 增大 batch size 让 compute 时间追平 data movement 时间。
```

---

## 8. ZeRO++：通信优化

ZeRO++ 是 2023 年推出的 ZeRO 通信优化扩展，特别针对**低带宽跨节点网络**场景。

### 8.1 qgZ：量化梯度通信

```
qgZ (Quantized Gradient ZeRO) 原理:
══════════════════════════════════════════════════════════════════════

    标准 ZeRO: all-reduce/reduce-scatter 使用 FP16 梯度
    qgZ: 将梯度量化到 INT4/FP8 再进行通信，到达后再反量化

    ┌──────────────────────────────────────────────────────┐
    │                    qgZ 通信流水线                      │
    │                                                      │
    │  GPU0                                  GPU1          │
    │  ┌──────────┐                          ┌──────────┐ │
    │  │ grad FP16│                          │ grad FP16│ │
    │  │  2 bytes │                          │  2 bytes │ │
    │  └────┬─────┘                          └────┬─────┘ │
    │       │                                     │       │
    │  ┌────▼─────┐                          ┌────▼─────┐ │
    │  │ Quantize │                          │ Quantize │ │
    │  │ → FP8    │                          │ → FP8    │ │
    │  │  1 byte  │                          │  1 byte  │ │
    │  └────┬─────┘                          └────┬─────┘ │
    │       │                                     │       │
    │       └──────────────┬──────────────────────┘       │
    │                      │                              │
    │              ┌───────▼───────┐                      │
    │              │ reduce-scatter│  ← 通信量减半!       │
    │              │ (INT4/FP8)    │                      │
    │              └───────┬───────┘                      │
    │                      │                              │
    │  ┌──────────┐        │        ┌──────────┐         │
    │  │Dequantize│◄───────┘        │Dequantize│         │
    │  │→ FP16    │                  │→ FP16    │         │
    │  └────┬─────┘                  └────┬─────┘         │
    │       │                             │               │
    │  ┌────▼─────┐                  ┌────▼─────┐         │
    │  │grad FP16│                  │grad FP16│         │
    │  │(有损)    │                  │(有损)    │         │
    │  └──────────┘                  └──────────┘         │
    └──────────────────────────────────────────────────────┘

    量化带来的精度损失:
    - INT4: 精度损失较大，可能影响收敛
    - FP8: 精度损失很小，接近无损（用于 H100 等支持 FP8 的硬件）
    - 实践中通常使用 Block-wise 量化（如每 128 个元素一组，共享 scale 因子）
```

### 8.2 hpZ：分层分区

```
hpZ (Hierarchical Partition ZeRO) 原理:
══════════════════════════════════════════════════════════════════════

    问题: 标准 ZeRO-3 的 all-gather 是全局的（所有 GPU 参与），
          跨节点通信带宽低，全局 all-gather 效率差。

    解决方案: 两级分层通信
    ─────────────────────────────────────────────────────────────────

    ┌─────────────────────────────────────────────────────────────────┐
    │                    2 级分层 ZeRO-3                               │
    │                                                                 │
    │  节点 0 (8 GPU, NVLink)          节点 1 (8 GPU, NVLink)         │
    │  ┌───┐ ┌───┐ ┌───┐ ┌───┐       ┌───┐ ┌───┐ ┌───┐ ┌───┐       │
    │  │G0 │ │G1 │ │G2 │ │G3 │       │G8 │ │G9 │ │G10│ │G11│       │
    │  └───┘ └───┘ └───┘ └───┘       └───┘ └───┘ └───┘ └───┘       │
    │  ┌───┐ ┌───┐ ┌───┐ ┌───┐       ┌───┐ ┌───┐ ┌───┐ ┌───┐       │
    │  │G4 │ │G5 │ │G6 │ │G7 │       │G12│ │G13│ │G14│ │G15│       │
    │  └───┘ └───┘ └───┘ └───┘       └───┘ └───┘ └───┘ └───┘       │
    │      │                         │                               │
    │      │ NVLink (600 GB/s)        │ NVLink (600 GB/s)            │
    │      ▼                         ▼                               │
    │  [节点内 all-gather]       [节点内 all-gather]                  │
    │      │                         │                               │
    │      └──────────┬──────────────┘                               │
    │                 │                                              │
    │         InfiniBand (200 GB/s)                                  │
    │                 │                                              │
    │          [节点间 all-gather]                                    │
    │                                                                 │
    │  参数副本策略:                                                  │
    │    节点内: 完整副本 (NVLink 快)                                │
    │    节点间: 部分副本 (IB 慢，按需获取)                          │
    └─────────────────────────────────────────────────────────────────┘

    通信量对比:
    标准 ZeRO-3 全局 all-gather: 每个 GPU 发送 2Φ × 15/16 = 1.875Φ 字节
    hpZ:
      节点内 all-gather: 2Φ × 7/8 = 1.75Φ (NVLink, 很快)
      节点间通信: 只需传送节点内还没聚合的参数差量 (约 2Φ × 1/2 = Φ 字节 via IB)
      总计跨节点通信量减少 ~50%
```

### 8.3 ZeRO++ 配置

```python
# ZeRO++ 配置（需要 DeepSpeed >= 0.10.0）
ds_config_zeropp = {
    "zero_optimization": {
        "stage": 3,
        # ZeRO++ 量化通信
        "zero_quantized_weights": True,      # 量化权重用于通信
        "zero_quantized_gradients": True,    # qgZ: 量化梯度通信
        "zero_quantized_nontrainable_weights": False,  # 不量化不可训练权重

        # ZeRO++ 分层分区
        "zero_hpz_partition_size": 8,        # hpZ: 每个分区的 GPU 数
        # 或使用 auto
        # "zero_hpz_partition_size": "auto",
    }
}
```

---

## 9. DeepSpeed 配置文件深度拆解

### 9.1 完整配置文件模板

```json
{
  "train_batch_size": 64,
  "train_micro_batch_size_per_gpu": 2,
  "gradient_accumulation_steps": 4,

  "optimizer": {
    "type": "AdamW",
    "params": {
      "lr": 1e-4,
      "betas": [0.9, 0.95],
      "eps": 1e-8,
      "weight_decay": 0.1,
      "torch_adam": true
    }
  },

  "scheduler": {
    "type": "WarmupDecayLR",
    "params": {
      "total_num_steps": 10000,
      "warmup_min_lr": 0,
      "warmup_max_lr": 1e-4,
      "warmup_num_steps": 1000,
      "warmup_type": "linear"
    }
  },

  "fp16": {
    "enabled": true,
    "auto_cast": true,
    "loss_scale": 0,
    "initial_scale_power": 16,
    "loss_scale_window": 1000,
    "hysteresis": 2,
    "min_loss_scale": 1
  },

  "bf16": {
    "enabled": false
  },

  "zero_optimization": {
    "stage": 2,
    "offload_optimizer": {"device": "none"},
    "offload_param": {"device": "none"},
    "overlap_comm": true,
    "contiguous_gradients": true,
    "reduce_bucket_size": 5e8,
    "allgather_bucket_size": 5e8,
    "stage3_prefetch_bucket_size": 5e8,
    "stage3_param_persistence_threshold": 1e6,
    "stage3_max_live_parameters": 1e9,
    "stage3_max_reuse_distance": 1e9,
    "stage3_gather_16bit_weights_on_model_save": true,
    "sub_group_size": 1e9,
    "round_robin_gradients": false,
    "zero_quantized_weights": false,
    "zero_quantized_gradients": false,
    "ignore_unused_parameters": true,
    "elastic_checkpoint": true
  },

  "gradient_clipping": 1.0,

  "activation_checkpointing": {
    "partition_activations": false,
    "cpu_checkpointing": false,
    "number_checkpoints": null,
    "synchronize_checkpoint_boundary": false,
    "profile": false
  },

  "communication_data_type": "fp16",
  "compression_training": {},

  "steps_per_print": 10,
  "wall_clock_breakdown": false,
  "dump_state": false,
  "prescale_gradients": false,

  "csv_monitor": {
    "enabled": false,
    "output_path": "./ds_logs/",
    "job_name": "training_job"
  },

  "tensorboard": {
    "enabled": true,
    "output_path": "./ds_logs/",
    "job_name": "training_job"
  },

  "checkpoint": {
    "tag_validation": "WARN",
    "load_universal": false,
    "use_node_local_storage": false
  },

  "data_types": {
    "grad_accum_dtype": "fp32"
  }
}
```

### 9.2 关键参数详解

```
─── 训练批大小相关 ─────────────────────────────────────────────────

train_batch_size: int
  全局批大小。每步训练的有效样本数。
  如果使用梯度累积: train_batch_size = micro_batch_per_gpu × gradient_acc_steps × DP_size
  例如: 2 × 4 × 8 = 64

train_micro_batch_size_per_gpu: int
  每个 GPU 每次前向传播处理的样本数。
  这是真正的"每个 GPU 能放下的最大 batch"。
  太小: GPU 利用率低。太大: OOM。

gradient_accumulation_steps: int
  梯度累积步数。每 accumulation_steps 次 forward/backward 后做一次 optimizer.step()。
  有效增大 batch size 而无需增加显存。


─── 优化器相关 ─────────────────────────────────────────────────────

optimizer.type: str
  优化器类型。"AdamW", "Adam", "SGD", "LAMB", "Lion", "OneBitAdam" 等。

optimizer.params.lr: float
  学习率。这是 ZeRO 管理优化器时的全局学习率。

optimizer.params.torch_adam: bool
  使用 PyTorch 原生 Adam 实现 (更稳定、更快) 还是 DeepSpeed 的 FusedAdam (自定义 CUDA 内核)。
  True: torch.optim.AdamW
  False: deepspeed.ops.adam.FusedAdam (融合内核，可能更快)


─── 调度器相关 ─────────────────────────────────────────────────────

scheduler.type: str
  学习率调度器类型。
  "WarmupLR": 仅预热
  "WarmupDecayLR": 预热 + 线性衰减
  "WarmupCosineLR": 预热 + 余弦衰减
  "OneCycle": 单周期调度
  也可以传 None 然后外部自己管理（如 transformers 的 get_scheduler）。

scheduler.params.warmup_num_steps: int
  预热步数。从 warmup_min_lr 线性增加到 warmup_max_lr。

scheduler.params.total_num_steps: int
  总训练步数。用于计算衰减。


─── 混合精度相关 ────────────────────────────────────────────────────

fp16.enabled: bool
  启用 FP16 混合精度训练。使用 NVIDIA Apex 风格的 loss scaling。

fp16.loss_scale: float
  初始 loss scale。
  0: 动态 loss scaling（推荐）
  >0: 固定 loss scale（用于调试）

fp16.initial_scale_power: int
  动态 loss scaling 的初始缩放因子 = 2^initial_scale_power。
  默认 16 → 初始 scale = 65536。

fp16.loss_scale_window: int
  检查 loss scale 是否需要调整的窗口大小（步数）。
  窗口内没有 NaN/Inf → scale 翻倍。
  窗口内有 NaN/Inf → scale 减半。

fp16.hysteresis: int
  延迟。连续 hysteresis 个窗口没有 NaN/Inf 才增大 loss scale。
  避免 scale 振荡。

bf16.enabled: bool
  启用 BF16 混合精度。
  BF16 有更大的动态范围，不需要 loss scaling。
  需要 Ampere+ (A100) 或更新的 GPU。
  推荐: 能用 BF16 就用 BF16，比 FP16 更稳定。


─── ZeRO 优化相关 ──────────────────────────────────────────────────

zero_optimization.stage: int
  ZeRO 阶段。0=禁用, 1/2/3=对应阶段。
  stage 0: 普通分布式优化器（本质是 DDP）
  stage 1: 切分优化器状态
  stage 2: 切分优化器状态 + 梯度
  stage 3: 切分优化器状态 + 梯度 + 参数

zero_optimization.offload_optimizer.device: str
  优化器状态卸载目标。"none", "cpu", "nvme"
  对于超大模型（无法放进 GPU 显存），设为 "cpu"。

zero_optimization.offload_param.device: str
  参数卸载目标。"none", "cpu", "nvme"

zero_optimization.overlap_comm: bool
  通信与计算是否重叠。利用 CUDA Stream 在计算的同时进行通信。
  True: 更快但可能略增显存（多一个通信 buffer）。
  False: 更简单但 GPU 利用率可能较低。

zero_optimization.contiguous_gradients: bool
  是否将梯度拷贝到连续内存缓冲区再做 reduce。
  可以避免碎片化内存带来的额外拷贝开销。
  推荐: True。

zero_optimization.reduce_bucket_size: int
  reduce-scatter 的分桶大小（参数个数）。
  梯度按 bucket 分组，每个 bucket 一到齐就做 reduce-scatter。
  太小: 通信开销大（太多小消息）。
  太大: overlap 效果差（必须等满一大桶）。
  建议: 5e8 (5 亿参数) ≈ 1 GB (FP16)

zero_optimization.allgather_bucket_size: int
  all-gather 的分桶大小。
  建议: 5e8
  为通信重叠调优: 越大 overlap 越好但延迟越高。

zero_optimization.stage3_prefetch_bucket_size: int
  ZeRO-3 参数预取的桶大小。
  建议: 0.5 × allgather_bucket_size 或相同。

zero_optimization.stage3_param_persistence_threshold: int
  参数持久化阈值（参数个数）。
  小于此阈值的参数（通常是 bias、LayerNorm 参数）始终保留在 GPU 上。
  理由: 小参数的 all-gather 通信开销可能超过保留它的内存开销。
  建议: 1e4 - 1e6 (10K - 1M)

zero_optimization.stage3_max_live_parameters: int
  同时活跃在 GPU 上的最大参数量。
  用于限制 ZeRO-3 的显存峰值。
  建议: 1e9 (10 亿) 或更少。

zero_optimization.sub_group_size: int
  子分组大小。将 DP group 分成更小的子组做 all-reduce。
  可以减少通信参与者数量，降低延迟。
  建议: 1e9 (相当于不分组) 或根据网络拓扑设置。


─── 激活检查点相关 ──────────────────────────────────────────────────

activation_checkpointing.partition_activations: bool
  是否跨 GPU 切分激活检查点。
  进一步减少激活显存，但增加通信。
  通常不需要（激活检查点已经大幅减少显存了）。

activation_checkpointing.cpu_checkpointing: bool
  是否将激活检查点卸载到 CPU。
  极端节省显存，但会引入 PCIe 延迟。

activation_checkpointing.number_checkpoints: int
  检查点数量。如果为 None，每层一个检查点。


─── 其他重要参数 ────────────────────────────────────────────────────

gradient_clipping: float
  梯度裁剪阈值（按 L2 范数）。防止梯度爆炸。

communication_data_type: str
  通信时的数据类型。通常与训练精度相同。

prescale_gradients: bool
  是否在 all-reduce 前预缩放梯度（除以 DP size）。
  可以减少通信次数。

steps_per_print: int
  每隔多少步打印一次训练统计。
  建议: 训练步数的 1/100 或更少。

wall_clock_breakdown: bool
  是否输出详细的计时信息（前向/后向/通信等耗时）。
  用于性能分析，训练时建议关闭（可能影响性能）。
```

### 9.3 常用配置文件模板

```python
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 模板 1: 最简配置（单机 8 GPU，7B 微调）
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
config_lora_simple = {
    "train_batch_size": 32,
    "train_micro_batch_size_per_gpu": 1,
    "gradient_accumulation_steps": 4,
    "optimizer": {
        "type": "AdamW",
        "params": {"lr": 2e-4}
    },
    "scheduler": {
        "type": "WarmupDecayLR",
        "params": {
            "total_num_steps": 1000,
            "warmup_min_lr": 0,
            "warmup_max_lr": 2e-4,
            "warmup_num_steps": 100
        }
    },
    "bf16": {"enabled": True},
    "zero_optimization": {"stage": 2}
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 模板 2: 全参数微调 13B（单机 8×A100 80GB）
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
config_full_finetune = {
    "train_batch_size": 64,
    "train_micro_batch_size_per_gpu": 1,
    "gradient_accumulation_steps": 8,
    "optimizer": {
        "type": "AdamW",
        "params": {
            "lr": 1e-5,
            "betas": [0.9, 0.95],
            "eps": 1e-8,
            "weight_decay": 0.1
        }
    },
    "scheduler": {
        "type": "WarmupDecayLR",
        "params": {
            "total_num_steps": 5000,
            "warmup_min_lr": 0,
            "warmup_max_lr": 1e-5,
            "warmup_num_steps": 500
        }
    },
    "bf16": {"enabled": True},
    "zero_optimization": {
        "stage": 3,
        "overlap_comm": True,
        "contiguous_gradients": True,
        "reduce_bucket_size": 5e8,
        "allgather_bucket_size": 5e8,
        "stage3_prefetch_bucket_size": 5e8,
        "stage3_param_persistence_threshold": 1e5,
        "stage3_max_live_parameters": 1e9
    },
    "gradient_clipping": 1.0,
    "activation_checkpointing": {
        "partition_activations": False
    }
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 模板 3: 大规模训练（多机 64 GPU，30B+ 从头训练）
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
config_large_scale = {
    "train_batch_size": 2048,
    "train_micro_batch_size_per_gpu": 1,
    "gradient_accumulation_steps": 32,
    "optimizer": {
        "type": "AdamW",
        "params": {
            "lr": 1.5e-4,
            "betas": [0.9, 0.95],
            "eps": 1e-8,
            "weight_decay": 0.1
        }
    },
    "scheduler": {
        "type": "WarmupCosineLR",
        "params": {
            "total_num_steps": 50000,
            "warmup_min_lr": 0,
            "warmup_max_lr": 1.5e-4,
            "warmup_num_steps": 2000
        }
    },
    "bf16": {"enabled": True},
    "zero_optimization": {
        "stage": 3,
        "offload_optimizer": {
            "device": "cpu",
            "pin_memory": True
        },
        "offload_param": {
            "device": "cpu",
            "pin_memory": True
        },
        "overlap_comm": True,
        "contiguous_gradients": True,
        "sub_group_size": 1e9,
        "reduce_bucket_size": "auto",
        "stage3_prefetch_bucket_size": "auto",
        "stage3_param_persistence_threshold": "auto",
        "stage3_max_live_parameters": 1e9,
        "stage3_max_reuse_distance": 1e9,
        "stage3_gather_16bit_weights_on_model_save": True
    },
    "gradient_clipping": 1.0,
    "activation_checkpointing": {
        "partition_activations": False,
        "cpu_checkpointing": False,
        "synchronize_checkpoint_boundary": False
    },
    "communication_data_type": "bfp16",
    "steps_per_print": 10,
    "wall_clock_breakdown": False
}
```

---

## 10. DeepSpeed 与其他框架对比

### 10.1 DeepSpeed vs FSDP

```
┌─────────────────────────────────────────────────────────────────┐
│               DeepSpeed ZeRO-3 vs PyTorch FSDP                  │
├─────────────────────┬───────────────────┬───────────────────────┤
│        特性          │    DeepSpeed       │    PyTorch FSDP       │
├─────────────────────┼───────────────────┼───────────────────────┤
│ 核心思想              │ 参数/梯度/优化器切分  │ 相同                   │
│ 成熟度                │ ★★★★★ (2020+)     │ ★★★★  (2022+)         │
│ ZeRO-3 稳定性         │ 更成熟, 久经考验    │ FSDP v1 接近, v2 更好  │
│ offload 支持          │ CPU + NVMe        │ 仅 CPU (参数+优化器)   │
│ 配置文件              │ 丰富 (JSON)       │ 通过 Python API        │
│ 激活检查点集成         │ 原生支持           │ 需要手动包装            │
│ 通信优化              │ ZeRO++ (qgZ+hpZ)  │ 暂无                  │
│ 与 HuggingFace 集成   │ ★★★★★            │ ★★★★★                │
│ 调试工具              │ ds_report, monitor│ PyTorch Profiler      │
│ 推理引擎              │ DeepSpeed Inference│ 无 (推理用其他工具)   │
│ 混合精度              │ FP16+BF16 都原生   │ 需要配合 autocast      │
│ 学习率调度器           │ 内置多种           │ 需要外部传入            │
└─────────────────────┴───────────────────┴───────────────────────┘

推荐:
- 新项目、简单需求 → FSDP (更轻量, 纯 PyTorch)
- 需要 ZeRO-3 + Offload → DeepSpeed (更成熟稳定)
- 多机大规模训练 → DeepSpeed (丰富的 offload 和 ZeRO++ 优化)
- 与 HF Trainer 集成 → 两者都差不多 (HF 有 DS/FSDP 插件)
```

### 10.2 DeepSpeed vs Megatron-LM

```
┌─────────────────────────────────────────────────────────────────────┐
│            DeepSpeed vs Megatron-LM — 互补而非竞争                    │
├───────────────────────────┬─────────────────────────────────────────┤
│        DeepSpeed           │            Megatron-LM                  │
├───────────────────────────┼─────────────────────────────────────────┤
│ 专注于: 数据并行层面优化    │ 专注于: 张量并行 + 流水线并行            │
│ ZeRO: DP 内存优化          │ TP: 单层内矩阵切分                       │
│ ZeRO-Infinity: offload     │ PP: 层间切分                             │
│ ZeRO++: 通信优化           │ Sequence Parallelism: 序列并行            │
│                            │ Distributed Optimizer: 跨 DP 分布优化器  │
├───────────────────────────┼─────────────────────────────────────────┤
│                      实际使用: 两者配合!                              │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │              3D 并行: TP + PP + DP                            │  │
│  │                                                              │  │
│  │  Megatron-LM 负责:                                           │  │
│  │    - TP (张量并行): 层内切分，适合 NVLink 节点内              │  │
│  │    - PP (流水线并行): 层间切分，适合跨节点                    │  │
│  │    - Sequence Parallelism: 减少激活显存                      │  │
│  │                                                              │  │
│  │  DeepSpeed ZeRO 负责:                                        │  │
│  │    - DP (数据并行) 的内存优化                                │  │
│  │    - 优化器状态切分 + 卸载                                    │  │
│  │    - 激活检查点管理                                          │  │
│  │                                                              │  │
│  │  典型配置:                                                   │  │
│  │    1024 GPUs = TP8 × PP8 × DP16                             │  │
│  │    Megatron: 管理 TP8 + PP8 通信                             │  │
│  │    DeepSpeed: 管理 DP16 的 ZeRO 优化                         │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘

常见的组合使用:
- Megatron-DeepSpeed (Megatron-LM + DeepSpeed 深度集成)
- NVIDIA NeMo (基于 Megatron-DeepSpeed)
- Microsoft DeepSpeed + Megatron (官方集成)
```

### 10.3 DeepSpeed vs ColossalAI

```
┌────────────────────────────────────────────────────────────────┐
│                DeepSpeed vs ColossalAI                          │
├─────────────────────┬──────────────────┬───────────────────────┤
│        特性          │    DeepSpeed      │    ColossalAI         │
├─────────────────────┼──────────────────┼───────────────────────┤
│ 开发者              │ 微软              │ HPC-AI Tech (新加坡)   │
│ 首次发布             │ 2020.02           │ 2021.10               │
│ ZeRO 等价实现        │ ZeRO-1/2/3        │ Gemini (类似 ZeRO-3)  │
│ 张量并行             │ 基础支持          │ 完整的 2D/2.5D/3D TP  │
│ 流水线并行            │ 基础支持          │ 1F1B, Interleaved     │
│ Offload              │ CPU + NVMe       │ CPU + NVMe            │
│ 社区活跃度            │ ★★★★★ (最大)     │ ★★★                   │
│ 文档质量              │ ★★★★            │ ★★☆                   │
│ 论文数量              │ VLDB'20, SC'20+ │ SC'21+               │
│ 与 HuggingFace 集成  │ 原生              │ 需要额外工作          │
│ MoE 支持              │ DeepSpeed-MoE    │ 专门的 MoE 模块      │
│ 推理                  │ DeepSpeed-MII   │ Energon-AI            │
└─────────────────────┴──────────────────┴───────────────────────┘

结论:
- DeepSpeed: 更成熟、生态更大、文档更好，适合大多数场景
- ColossalAI: 更学术化，在复杂 TP 方案上有创新，适合研究用途
```

---

## 11. DeepSpeed 推理引擎

### 11.1 DeepSpeed Inference

```
DeepSpeed Inference 架构:
════════════════════════════════════════════════════════════════════

  ┌────────────────────────────────────────────────────────────┐
  │                   DeepSpeed Inference                       │
  │                                                            │
  │  ┌──────────────────┐  ┌──────────────────────────────┐   │
  │  │  Transformer      │  │  通用模型                       │   │
  │  │  优化内核          │  │  推理优化                       │   │
  │  │                   │  │                              │   │
  │  │  - 融合 QKV 投影   │  │  - Kernel Injection          │   │
  │  │  - FlashAttention  │  │  - Weight Quantization       │   │
  │  │  - 融合 MLP        │  │  - Layer Fusion              │   │
  │  │  - 融合残差+Norm  │  │  - Tensor Parallelism        │   │
  │  └──────────────────┘  └──────────────────────────────┘   │
  │                                                            │
  │  ┌──────────────────┐  ┌──────────────────────────────┐   │
  │  │  多 GPU 推理       │  │  量化                         │   │
  │  │                   │  │                              │   │
  │  │  - 张量并行        │  │  - INT8 权重量化              │   │
  │  │  - 流水线并行      │  │  - INT8 KV-Cache 量化        │   │
  │  │  - ZeRO-Inference │  │  - FP8 量化 (H100)           │   │
  │  └──────────────────┘  └──────────────────────────────┘   │
  └────────────────────────────────────────────────────────────┘

主要优化技术:

1. Kernel Injection (内核注入):
   用高度优化的 CUDA 内核替换 PyTorch 的通用内核。
   例如: 将多个小的矩阵运算融合为一个大内核 → 减少 kernel launch 开销。

2. Weight Quantization:
   将 FP16 权重在线量化为 INT8 → 减少内存带宽需求。
   对于内存带宽受限的推理场景，这可以带来 1.5-2× 吞吐提升。

3. Layer Fusion:
   融合相邻操作（如 bias + residual + layernorm + gelu）
   → 减少内存往返次数。

4. ZeRO-Inference:
   将模型参数分布在多 GPU 上（类似 ZeRO-3），推理时按需 all-gather。
   适合模型太大单卡放不下的场景。
```

### 11.2 DeepSpeed-MII

```
DeepSpeed-MII (Model Implementations for Inference):
════════════════════════════════════════════════════════════════════

  MII 是 DeepSpeed 推理引擎的高层包装，提供了:

  ┌───────────────────────────────────────────────────────────┐
  │  MII Pipeline:                                            │
  │                                                           │
  │  用户请求 → Tokenizer → Inference Engine → Post-processing │
  │     │           │              │               │           │
  │     │      HuggingFace   DeepSpeed       Response         │
  │     │      FastTokenizer  Inference       Formatting       │
  │     │                      Engine                         │
  │     │                                                      │
  │  HTTP/gRPC API ←───────────────────────────────────────── │
  └───────────────────────────────────────────────────────────┘

  MII vs vLLM:
  ─────────────────────────────────────────────────────────────────

  对比维度:
  ┌───────────────────┬────────────────┬─────────────────────┐
  │     特性            │   DeepSpeed-MII│    vLLM              │
  ├───────────────────┼────────────────┼─────────────────────┤
  │ 核心优化            │ kernel inject  │ PagedAttention      │
  │ KV-Cache 管理       │ 连续内存       │ 分页虚拟内存 (核心创新)│
  │ 内存效率             │ 中等          │ 极高                 │
  │ 连续批处理           │ 支持          │ 原生支持 (更高效)     │
  │ 吞吐量 (高并发)      │ 一般           │ 显著更高 (2-5×)      │
  │ 易用性               │ pip install   │ pip install          │
  │ 社区活跃度            │ 较小          │ 极大                 │
  │ API 兼容             │ 自定 API      │ OpenAI-compatible    │
  └───────────────────┴────────────────┴─────────────────────┘

  结论: 推理场景首选 vLLM 或 SGLang。
        DeepSpeed Inference 适合已将 DeepSpeed 用作训练的团队的统一部署。
```

### 11.3 DeepSpeed Chat (RLHF)

```
DeepSpeed-Chat: 完整的 RLHF 流水线
════════════════════════════════════════════════════════════════════

  ┌───────────────────────────────────────────────────────────────┐
  │                 DeepSpeed-Chat (RLHF Pipeline)                 │
  │                                                               │
  │  Step 1: SFT (Supervised Fine-Tuning)                        │
  │    ┌─────────────────────────────────────────┐               │
  │    │  预训练模型 + 指令数据集                   │               │
  │    │  DeepSpeed ZeRO + Hybrid Engine          │               │
  │    │  → 生成 SFT 模型                          │               │
  │    └─────────────────────────────────────────┘               │
  │                         │                                     │
  │  Step 2: Reward Model Training                               │
  │    ┌─────────────────────────────────────────┐               │
  │    │  SFT 模型 + 偏好数据对                     │               │
  │    │  → 训练奖励模型 (Reward Model)             │               │
  │    └─────────────────────────────────────────┘               │
  │                         │                                     │
  │  Step 3: PPO Reinforcement Learning                          │
  │    ┌─────────────────────────────────────────┐               │
  │    │  ┌───────────┐  ┌───────────┐           │               │
  │    │  │ Actor模型  │  │ Ref模型   │           │               │
  │    │  │ (SFT init)│  │ (冻结SFT) │           │               │
  │    │  └───────────┘  └───────────┘           │               │
  │    │  ┌───────────┐  ┌───────────┐           │               │
  │    │  │Critic模型  │  │Reward模型 │           │               │
  │    │  │(Reward init)│ │(冻结)     │           │               │
  │    │  └───────────┘  └───────────┘           │               │
  │    │                                         │               │
  │    │  Hybrid Engine: 训练+推理自动切换         │               │
  │    │  → 生成 PPO 优化后的模型                   │               │
  │    └─────────────────────────────────────────┘               │
  └───────────────────────────────────────────────────────────────┘

Hybrid Engine 是 DeepSpeed Chat 的核心创新:
- 训练阶段 (PPO update): 使用 ZeRO 优化训练
- 推理阶段 (generation/rollout): 自动切换到推理引擎
- 避免在同一个进程中维护两套引擎
- 内存管理更高效
```

---

## 12. 实际案例与代码

### 12.1 完整的 DeepSpeed 训练脚本

```python
#!/usr/bin/env python3
"""
完整的 DeepSpeed ZeRO-3 训练脚本
支持: 检查点恢复、混合精度、梯度累积、激活检查点
"""

import argparse
import os
import torch
import deepspeed
from torch.utils.data import DataLoader, Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    get_linear_schedule_with_warmup
)


class SimpleTextDataset(Dataset):
    """简单的文本数据集"""
    def __init__(self, texts, tokenizer, max_length=512):
        self.encodings = tokenizer(
            texts,
            truncation=True,
            padding="max_length",
            max_length=max_length,
            return_tensors="pt"
        )

    def __len__(self):
        return len(self.encodings["input_ids"])

    def __getitem__(self, idx):
        return {
            "input_ids": self.encodings["input_ids"][idx],
            "attention_mask": self.encodings["attention_mask"][idx],
            "labels": self.encodings["input_ids"][idx],
        }


def get_ds_config(args):
    """构建 DeepSpeed 配置"""
    config = {
        "train_batch_size": args.global_batch_size,
        "train_micro_batch_size_per_gpu": args.per_device_batch_size,
        "gradient_accumulation_steps": args.gradient_accumulation_steps,
        "optimizer": {
            "type": "AdamW",
            "params": {
                "lr": args.learning_rate,
                "betas": [0.9, 0.95],
                "eps": 1e-8,
                "weight_decay": args.weight_decay,
            }
        },
        "scheduler": {
            "type": "WarmupDecayLR",
            "params": {
                "total_num_steps": args.max_steps,
                "warmup_min_lr": 0,
                "warmup_max_lr": args.learning_rate,
                "warmup_num_steps": args.warmup_steps,
            }
        },
        "zero_optimization": {
            "stage": args.zero_stage,
            "offload_optimizer": {
                "device": args.offload_optimizer,
                "pin_memory": True
            } if args.offload_optimizer != "none" else {"device": "none"},
            "offload_param": {
                "device": args.offload_param,
                "pin_memory": True
            } if args.offload_param != "none" else {"device": "none"},
            "overlap_comm": True,
            "contiguous_gradients": True,
            "reduce_bucket_size": 5e8,
            "allgather_bucket_size": 5e8,
            "stage3_prefetch_bucket_size": 5e8,
            "stage3_param_persistence_threshold": 1e5,
            "stage3_max_live_parameters": 1e9,
            "stage3_gather_16bit_weights_on_model_save": True,
        },
        "bf16": {
            "enabled": args.use_bf16
        } if args.use_bf16 else {
            "enabled": False
        },
        "fp16": {
            "enabled": not args.use_bf16,
            "loss_scale": 0,
            "initial_scale_power": 16,
            "loss_scale_window": 1000,
        },
        "gradient_clipping": args.max_grad_norm,
        "steps_per_print": args.logging_steps,
        "wall_clock_breakdown": False,
    }

    if args.activation_checkpointing:
        config["activation_checkpointing"] = {
            "partition_activations": False,
            "cpu_checkpointing": False,
            "number_checkpoints": None,
            "synchronize_checkpoint_boundary": False,
        }

    return config


def main():
    parser = argparse.ArgumentParser()
    # 模型参数
    parser.add_argument("--model_name", type=str, default="meta-llama/Llama-2-7b-hf")
    parser.add_argument("--max_length", type=int, default=2048)

    # 训练参数
    parser.add_argument("--zero_stage", type=int, default=3)
    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--global_batch_size", type=int, default=64)
    parser.add_argument("--learning_rate", type=float, default=1e-5)
    parser.add_argument("--weight_decay", type=float, default=0.1)
    parser.add_argument("--warmup_steps", type=int, default=100)
    parser.add_argument("--max_steps", type=int, default=1000)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--logging_steps", type=int, default=10)

    # 优化参数
    parser.add_argument("--use_bf16", action="store_true", default=True)
    parser.add_argument("--offload_optimizer", type=str, default="none")
    parser.add_argument("--offload_param", type=str, default="none")
    parser.add_argument("--activation_checkpointing", action="store_true", default=True)

    # 检查点参数
    parser.add_argument("--output_dir", type=str, default="./checkpoints")
    parser.add_argument("--resume_from_checkpoint", type=str, default=None)

    # DeepSpeed 参数 (通过命令行传给 deepspeed.initialize)
    parser.add_argument("--local_rank", type=int, default=-1,
                        help="DeepSpeed 本地 rank，启动时自动设置")

    args = parser.parse_args()

    # 初始化 DeepSpeed 分布式环境
    deepspeed.init_distributed()

    # 加载模型和分词器
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        args.model_name,
        torch_dtype=torch.bfloat16 if args.use_bf16 else torch.float16,
        trust_remote_code=True,
    )

    # 激活检查点 (可选)
    if args.activation_checkpointing:
        model.gradient_checkpointing_enable()

    # 构建 DeepSpeed 配置
    ds_config = get_ds_config(args)

    # 构建数据集和数据加载器
    train_texts = ["示例文本 1", "示例文本 2"] * 1000  # 替换为真实数据
    dataset = SimpleTextDataset(train_texts, tokenizer, args.max_length)
    dataloader = DataLoader(dataset, batch_size=args.per_device_batch_size, shuffle=True)

    # 初始化 DeepSpeed 引擎
    model_engine, optimizer, training_dataloader, lr_scheduler = deepspeed.initialize(
        model=model,
        config=ds_config,
        model_parameters=model.parameters(),
        training_data=dataset,
    )

    # 恢复检查点
    if args.resume_from_checkpoint:
        load_path, client_state = model_engine.load_checkpoint(
            args.resume_from_checkpoint
        )
        print(f"Resumed from checkpoint: {load_path}")

    # 训练循环
    global_step = 0
    for epoch in range(10):
        model_engine.train()
        total_loss = 0.0

        for step, batch in enumerate(training_dataloader):
            # 将数据移到 GPU
            batch = {k: v.to(model_engine.device) for k, v in batch.items()}

            # 前向传播
            outputs = model_engine(**batch)
            loss = outputs.loss

            # 反向传播 (ZeRO 在 backward 中自动做梯度 reduce-scatter)
            model_engine.backward(loss)

            # 梯度累积后的优化器步进
            model_engine.step()

            total_loss += loss.item()
            global_step += 1

            # 日志
            if global_step % args.logging_steps == 0:
                avg_loss = total_loss / args.logging_steps
                print(
                    f"Step: {global_step}, "
                    f"Loss: {avg_loss:.4f}, "
                    f"LR: {lr_scheduler.get_last_lr()[0]:.2e}"
                )
                total_loss = 0.0

            # 保存检查点
            if global_step % 500 == 0:
                model_engine.save_checkpoint(
                    args.output_dir,
                    tag=f"step_{global_step}"
                )

            if global_step >= args.max_steps:
                break

        if global_step >= args.max_steps:
            break

    # 最终保存
    model_engine.save_checkpoint(args.output_dir, tag="final")


if __name__ == "__main__":
    main()
```

### 12.2 启动命令

```bash
# 单机 8 GPU
deepspeed --num_gpus=8 train_ds.py \
    --model_name meta-llama/Llama-2-7b-hf \
    --zero_stage 3 \
    --per_device_batch_size 1 \
    --gradient_accumulation_steps 8 \
    --learning_rate 1e-5 \
    --output_dir ./checkpoints \
    --use_bf16

# 多机训练 (2 节点，每节点 8 GPU)
deepspeed --num_gpus=8 --num_nodes=2 \
    --master_addr=10.0.0.1 --master_port=29500 \
    train_ds.py --zero_stage 3 ...

# 使用 hostfile
deepspeed --hostfile=hostfile.txt train_ds.py ...

# hostfile.txt 内容:
# node1 slots=8
# node2 slots=8
```

### 12.3 性能优化实战技巧

```
══════════════════════════════════════════════════════════════════════
                    DeepSpeed 性能优化清单
══════════════════════════════════════════════════════════════════════

1. 选择合适的 ZeRO Stage:
   □ 显存充足 → ZeRO-2 (通信最少)
   □ 显存紧张 → ZeRO-3
   □ 极度紧张 → ZeRO-3 + CPU Offload

2. Bucket Size 调优:
   □ reduce_bucket_size = 5e8 (500M params, ~1GB FP16)
   □ allgather_bucket_size = 5e8
   □ stage3_prefetch_bucket_size = 5e8
   □ 显存充足时增大 bucket → 更好的 overlap
   □ 显存不足时减小 bucket → 更低的显存峰值

3. 通信-计算重叠:
   □ overlap_comm = True  ← 必须开启
   □ contiguous_gradients = True  ← 减少内存碎片
   □ 确保 CUDA Stream 够用

4. 激活检查点调优:
   □ 每 N 层一个检查点而非每层 ← 减少检查点开销
   □ 不需要 partition_activations (增加通信)

5. 梯度累积策略:
   □ 累积步数 = global_batch / (per_device_batch × DP_size)
   □ 累积步数越多 → 通信次数越少 → 效率越高
   □ 但 accumulation 过多可能 OOM (激活值累积)

6. 数据类型选择:
   □ A100/H100 → 使用 BF16 (更稳定)
   □ 旧 GPU → 使用 FP16 + loss scaling
   □ 通信数据类型与计算数据类型保持一致

7. ZeRO-3 特有优化:
   □ stage3_param_persistence_threshold: 小参数常驻 GPU
   □ stage3_max_live_parameters: 限制活跃参数数量
   □ 使用 sub_group_size 减少通信组大小

8. 瓶颈分析流程:
   1) 开启 wall_clock_breakdown: True → 找到最慢的环节
   2) 用 nsys/ncu profile CUDA kernel
   3) 查看通信耗时 vs 计算耗时
   4) 如果 compute-bound → 增大 batch size
   5) 如果 communication-bound → 减小 bucket size，增加 overlap
   6) 如果 memory-bound → 升级 ZeRO stage，开启 offload
══════════════════════════════════════════════════════════════════════
```

### 12.4 检查点与恢复

```python
# DeepSpeed 检查点操作详解

# ─── 保存检查点 ─────────────────────────────────────────
# ZeRO-3 下每个 GPU 默认只保存自己持有的参数分片
model_engine.save_checkpoint(
    save_dir="./checkpoints",
    tag="step_1000",                    # 子目录名
    client_state={
        "step": 1000,
        "epoch": 5,
        "custom_metric": 0.95           # 自定义状态
    },
    save_latest=True                    # 同时保存到 "latest" 目录
)

# 检查点目录结构:
# checkpoints/
#   step_1000/
#     bf16_zero_pp_rank_0_mp_00_optim_states.pt  ← 优化器状态 (仅分片)
#     bf16_zero_pp_rank_1_mp_00_optim_states.pt
#     ...
#     bf16_zero_pp_rank_0_mp_00_model_states.pt  ← 模型参数 (仅分片)
#     ...
#     latest                                 ← 指向最近检查点的符号链接
#   latest -> step_1000/

# ─── 加载检查点 ─────────────────────────────────────────
# ZeRO-3: 必须用相同的 world_size 加载
_, client_state = model_engine.load_checkpoint(
    load_dir="./checkpoints/step_1000",
    tag=None,                            # 如果 load_dir 已经是完整路径
    load_optimizer_states=True,
    load_lr_scheduler_states=True,
    load_module_only=False,              # True = 只加载模型权重
)

# ─── 合并 ZeRO-3 分片为完整模型 ──────────────────────────
# 用于推理或转换 (需要单 GPU 脚本)
import deepspeed
from deepspeed.utils.zero_to_fp32 import (
    get_fp32_state_dict_from_zero_checkpoint
)

# 方法 1: 使用 DeepSpeed 工具
# deepspeed.utils.zero_to_fp32 会自动从所有 rank 的分片中合并
state_dict = get_fp32_state_dict_from_zero_checkpoint(
    "./checkpoints/step_1000"
)
torch.save(state_dict, "./merged_model/pytorch_model.bin")

# 方法 2: 命令行工具
# $ python -m deepspeed.utils.zero_to_fp32 \
#     ./checkpoints/step_1000 \
#     ./merged_model/pytorch_model.bin

# ─── 弹性检查点 (不同 world_size 加载) ───────────────────
# 需要: elastic_checkpoint: True 在 zero_optimization 配置中
# 允许用不同的 GPU 数量加载检查点
# 例如: 8 GPU 保存 → 4 GPU 加载
```

---

## 14. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| ZeRO Stage 1 | 只切优化器状态，参数和梯度仍完整 —— 省 56% 显存，通信代价小 | Ch.3 |
| ZeRO Stage 2 | 再切梯度，用 Reduce-Scatter 代替 All-Reduce —— 通信量与 DDP 持平但显存减半 | Ch.4 |
| ZeRO Stage 3 | 连参数也切分，前向/反向时按需 All-Gather 收集 —— 显存随 GPU 数线性缩放 | Ch.5 |
| Reduce-Scatter | 各 GPU 先求和再各自只保留一部分结果 —— All-Reduce 的一半通信量，ZeRO-2/3 的核心 | Ch.4.2 |
| ZeRO-Offload | 将优化器状态搬到 CPU 内存，GPU 只做前向/反向计算 —— 单卡可训 13B 模型 | Ch.7 |
| ZeRO-Infinity | Offload 的终极形态：GPU HBM → CPU DRAM → NVMe SSD 三级卸载，可训万亿参数 | Ch.7 |

## 15. A800 部署场景举例

**场景 1：单机 8×A800 80GB 用 ZeRO-2 + BF16 微调 Qwen2.5-7B**

```
硬件: 1 节点 8×A800 80GB, NVSwitch NVLink 600 GB/s
策略: ZeRO Stage 2 + BF16 + activation checkpointing

DeepSpeed 配置 (ds_config.json):
{
  "train_batch_size": 64,
  "train_micro_batch_size_per_gpu": 2,
  "gradient_accumulation_steps": 4,
  "bf16": {"enabled": true},
  "zero_optimization": {
    "stage": 2,
    "overlap_comm": true,
    "contiguous_gradients": true,
    "reduce_bucket_size": 5e8,
    "allgather_bucket_size": 5e8
  },
  "gradient_clipping": 1.0
}

启动命令:
  deepspeed --num_gpus=8 train.py --deepspeed ds_config.json

每 GPU 显存:
  ZeRO-2 显存 = 2Φ(params) + 2Φ/N(grads) + 12Φ/N(opt) 
  7B FP16: 14 + 14/8 + 84/8 = 14 + 1.75 + 10.5 ≈ 26.3 GB
  80GB 非常充裕，activation checkpointing 后激活值 ~5GB
  单步耗时 ≈ 400-600ms，通信几乎被 NVLink 隐藏
```

**场景 2：单机 8×A800 用 ZeRO-3 + CPU Offload 训练 13B 模型（显存不足时）**

```
场景: 13B FP16 参数 = 26GB，单卡 80GB 也不够全参数 DDP
ZeRO-3 将每 GPU 显存压到: 16×13B/8 ≈ 26 GB + 激活值 ≈ 35 GB

配置:
  "zero_optimization": {
    "stage": 3,
    "offload_optimizer": {"device": "cpu", "pin_memory": true},
    "offload_param": {"device": "cpu", "pin_memory": true},
    "overlap_comm": true,
    "stage3_prefetch_bucket_size": 5e8,
    "stage3_param_persistence_threshold": 1e5
  }

GPU ↔ CPU PCIe Gen4 x16 带宽 ≈ 32 GB/s:
  每层参数 100MB → 传输约 3ms → 与计算重叠后几乎不影响吞吐

经验: 在 8×A800 上 13B 模型用 ZeRO-2 可能 OOM，切 ZeRO-3 大概率能跑；
      还不行就加 CPU offload，代价是吞吐降 10-20%
```

## 16. 上下游串联

```
                   AI Infra 训练栈 — DeepSpeed ZeRO 的位置
                   
    ┌───────────────────────────────────────────────────────────┐
    │  分布式训练基础 (DDP, NCCL, All-Reduce, 混合精度)          │
    │  ZeRO 本质上是对 DDP 的内存增强 —— DDP 是 ZeRO Stage 0    │
    └───────────────────────────┬───────────────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        ▼                       ▼                       ▼
    ┌───────────┐     ┌─────────────────┐     ┌───────────────┐
    │ ★ 本份文档│     │ Megatron-LM     │     │ Pipeline      │
    │ DeepSpeed │     │ (TP + SP)       │     │ Parallelism   │
    │ ZeRO-1/2/3│     │ 层内矩阵切分     │     │ (GPipe/1F1B) │
    │ Offload   │     │ Attention+MLP   │     │ 层间流水线    │
    │ ZeRO++    │     │ 每层 4×all-reduce│    │ P2P send/recv │
    └─────┬─────┘     └────────┬────────┘     └───────┬───────┘
          │                   │                      │
          └───────────────────┼──────────────────────┘
                              │
                              ▼
    ┌───────────────────────────────────────────────────────────┐
    │  3D 并行: DP (ZeRO) × TP (Megatron) × PP                 │
    │  Megatron-DeepSpeed 集成 → NVIDIA NeMo                   │
    │  例如: 1024 GPU = DP16 × TP8 × PP8                       │
    └───────────────────────────────────────────────────────────┘
                              │
                              ▼
    ┌───────────────────────────────────────────────────────────┐
    │  推理部署: DeepSpeed Inference / MII / vLLM              │
    │  (训练好的模型用 ZeRO-Inference 做多 GPU 推理)            │
    └───────────────────────────────────────────────────────────┘
```

DeepSpeed ZeRO 在训练栈中的定位是**数据并行（DP）维度的内存优化层**。它不改模型结构，只改优化器/梯度/参数的存储和通信方式。与 Megatron 的 TP（层内张量切分）和 PP（层间流水线）正交互补。实际生产中三者组合：TP 放节点内利用 NVLink，PP 跨节点减少通信，ZeRO 在 DP 维度压榨最后的显存冗余。ZeRO-3 的 All-Gather/Reduce-Scatter 通信模式与 FSDP 等价，选型取决于对 offload 和生态（HuggingFace 集成、配置声明式 vs Python API）的偏好。

---

## 13. 深入学习资源

### 13.1 必读论文

| 论文 | 标题 | 会议 | 要点 |
|------|------|------|------|
| ZeRO | "ZeRO: Memory Optimizations Toward Training Trillion Parameter Models" | SC '20 | ZeRO 三阶段的形式化分析，内存模型 |
| ZeRO-Offload | "ZeRO-Offload: Democratizing Billion-Scale Model Training" | ATC '21 | 单 GPU + CPU 卸载方案 |
| ZeRO-Infinity | "ZeRO-Infinity: Breaking the GPU Memory Wall for Extreme Scale Deep Learning" | SC '21 | NVMe 卸载、Infinity 架构 |
| ZeRO++ | "ZeRO++: Extremely Efficient Collective Communication for Giant Model Training" | arXiv '23 | 量化通信、分层分区 |

### 13.2 官方文档与代码

```
1. DeepSpeed GitHub: https://github.com/microsoft/DeepSpeed
   - 完整源码、示例、教程
   - DeepSpeedExamples 仓库: 各种模型/场景的参考实现

2. DeepSpeed 官方文档: https://www.deepspeed.ai/
   - 配置参数详细说明
   - ZeRO 教程 (Getting Started → ZeRO)
   - API 参考文档

3. DeepSpeed 训练教程:
   - https://www.deepspeed.ai/tutorials/zero/
   - https://huggingface.co/docs/transformers/main_classes/deepspeed

4. HuggingFace + DeepSpeed 集成:
   - https://huggingface.co/docs/transformers/deepspeed
   - Trainer 中使用 DeepSpeed 的完整指南
```

### 13.3 视频课程

```
1. DeepSpeed 官方讲座系列 (YouTube: Microsoft Research):
   - "ZeRO: Memory Optimizations for Training Large Models"
   - "DeepSpeed: Extreme-Scale Model Training for Everyone"

2. Nvidia Deep Learning Institute:
   - "Building Transformer-Based Natural Language Processing Applications"
   - 包含分布式训练实践

3. Stanford CS324: Large Language Models
   - 课程网站: https://stanford-cs324.github.io/winter2022/
   - Lecture on Parallelism and Distributed Training
```

### 13.4 进阶阅读

```
1. Megatron-LM 论文:
   - "Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism"
   - "Efficient Large-Scale Language Model Training on GPU Clusters Using Megatron-LM"
   - 理解 TP + PP 如何与 DeepSpeed 互补

2. PyTorch FSDP 文档:
   - https://pytorch.org/docs/stable/fsdp.html
   - 对比 DeepSpeed vs FSDP 的设计选择

3. NVIDIA Transformer Engine:
   - https://github.com/NVIDIA/TransformerEngine
   - FP8 训练 + FP8 通信的最新实践

4. 性能分析工具:
   - NVIDIA Nsight Systems (nsys): 系统级性能分析
   - NVIDIA Nsight Compute (ncu): CUDA kernel 级别分析
   - DeepSpeed Monitor (ds_monitor): DeepSpeed 内置监控
   - PyTorch Profiler: trace 导出到 Chrome Trace Viewer

5. 实际大规模训练案例:
   - BLOOM 训练日志: https://bigscience.huggingface.co/
   - OPT 训练日志: https://github.com/facebookresearch/metaseq
   - LLaMA 训练技术报告: https://arxiv.org/abs/2302.13971
   - GPT-4 技术报告 (系统部分): https://arxiv.org/abs/2303.08774
```

### 13.5 社区与讨论

```
1. DeepSpeed GitHub Issues:
   https://github.com/microsoft/DeepSpeed/issues
   搜索你遇到的问题，常见问题如:
   - OOM despite ZeRO-3
   - Checkpoint loading with different world size
   - Communication hanging / timeout

2. HuggingFace Forums:
   https://discuss.huggingface.co/
   搜索 "deepspeed" 获取社区经验

3. PyTorch Forums:
   https://discuss.pytorch.org/
   分布式训练相关问题，尤其是 FSDP 与 DeepSpeed 对比

4. Reddit:
   r/MachineLearning - 论文讨论
   r/LocalLLaMA - 模型训练实践经验

5. Twitter/X:
   关注 @DeepSpeed (官方账号)
   @MSFTResearch (微软研究院)
   获取最新论文和发布公告
```

### 13.6 学习路径建议

```
══════════════════════════════════════════════════════════════════════
                  DeepSpeed 学习路线图
══════════════════════════════════════════════════════════════════════

阶段 1: 基础理解 (1-2 周)
  □ 阅读 ZeRO 论文的 Introduction 和 Section 3
  □ 理解 DDP 和 all-reduce 的工作原理
  □ 理解 Adam 优化器的内存组成 (m, v, master params)
  □ 用 DeepSpeed Examples 中的 HelloWorld 示例跑通单 GPU 训练

阶段 2: 动手实践 (2-3 周)
  □ 在 2-4 GPU 上用 ZeRO-2 微调一个 7B 模型
  □ 理解配置文件中每个参数的作用
  □ 对比 ZeRO-1/2/3 的内存和速度差异
  □ 尝试梯度累积和激活检查点

阶段 3: 进阶调优 (3-4 周)
  □ 在 8+ GPU 上用 ZeRO-3 训练大模型
  □ 使用 wall_clock_breakdown 分析性能瓶颈
  □ 调优 bucket size 和 overlap 参数
  □ 尝试 CPU offload 和 NVMe offload
  □ 理解检查点保存/恢复的不同策略

阶段 4: 大规模实战 (4-8 周)
  □ 多机多 GPU 训练 (>16 GPUs)
  □ 配置 IB/RoCE 网络
  □ 组合 Megatron-LM + DeepSpeed (3D 并行)
  □ 分析跨节点通信瓶颈
  □ 实现训练过程的弹性恢复和容错

阶段 5: 深入研究 (持续)
  □ 阅读 ZeRO-Infinity 和 ZeRO++ 论文全文
  □ 研究 DeepSpeed 源码中的通信调度
  □ 对比 FSDP 和其他框架的实现
  □ 关注最新的分布式训练研究
  □ 尝试为 DeepSpeed 贡献代码
══════════════════════════════════════════════════════════════════════
```

---

> **结语**: DeepSpeed 的核心价值在于让有限资源训练大模型成为可能。理解 ZeRO 的三个阶段及其通信-内存权衡，是构建高效分布式训练系统的关键基础。实际上手操作、调优参数、分析瓶颈，才能将知识转化为真正的工程能力。
