# FSDP 与 torch.distributed 深度解析

## 目录

1. [FSDP 概述：PyTorch 原生全分片数据并行](#1-fsdp-概述pytorch-原生全分片数据并行)
2. [FSDP 核心工作原理](#2-fsdp-核心工作原理)
3. [FSDP 封装策略与包装策略](#3-fsdp-封装策略与包装策略)
4. [混合精度与 FSDP](#4-混合精度与-fsdp)
5. [FSDP CPU Offloading](#5-fsdp-cpu-offloading)
6. [FSDP v1 vs v2 深度对比](#6-fsdp-v1-vs-v2-深度对比)
7. [FSDP vs DeepSpeed ZeRO-3 全面对比](#7-fsdp-vs-deepspeed-zero-3-全面对比)
8. [torch.distributed 基础架构](#8-torchdistributed-基础架构)
9. [集合通信 API 详解](#9-集合通信-api-详解)
10. [torchrun：分布式启动器](#10-torchrun分布式启动器)
11. [分布式检查点 (DCP)](#11-分布式检查点-dcp)
12. [Device Mesh 与多维并行](#12-device-mesh-与多维并行)
13. [完整训练脚本与实战](#13-完整训练脚本与实战)
14. [深入学习资源](#14-深入学习资源)

---

## 1. FSDP 概述：PyTorch 原生全分片数据并行

### 1.1 什么是 FSDP

FSDP（Fully Sharded Data Parallel，全分片数据并行）是 PyTorch 从 1.11 版本开始引入的分布式训练 API。它的设计目标与 DeepSpeed ZeRO-3 完全一致：**将模型参数、梯度和优化器状态切分到多个 GPU 上，从而大幅降低单 GPU 的显存占用**。

```
┌─────────────────────────────────────────────────────────────────┐
│                    FSDP 在 PyTorch 生态中的位置                    │
│                                                                 │
│   ┌───────────────────────────────────────────────────────┐    │
│   │                   PyTorch                              │    │
│   │                                                        │    │
│   │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │    │
│   │  │  DDP        │  │  FSDP       │  │  TP (DTensor)│   │    │
│   │  │  (数据并行)  │  │  (全分片DP) │  │  (张量并行)   │   │    │
│   │  │  v1.0+      │  │  v1.11+     │  │  v2.0+       │   │    │
│   │  └─────────────┘  └─────────────┘  └─────────────┘   │    │
│   │                                                        │    │
│   │  ┌─────────────────────────────────────────────────┐  │    │
│   │  │       torch.distributed (底层通信原语)            │  │    │
│   │  │  NCCL | GLOO | MPI | UCC                        │  │    │
│   │  └─────────────────────────────────────────────────┘  │    │
│   │                                                        │    │
│   │  ┌─────────────────────────────────────────────────┐  │    │
│   │  │       Device Mesh (多维并行编制)                  │  │    │
│   │  │  DP × TP × PP 组合布局                            │  │    │
│   │  └─────────────────────────────────────────────────┘  │    │
│   └───────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 FSDP 解决的核心问题

```
标准 DDP 的内存困境:
══════════════════════════════════════════════════════════════════════

   GPU 0:  [完整参数]  [完整梯度]  [完整优化器]  [激活值]
   GPU 1:  [完整参数]  [完整梯度]  [完整优化器]  [激活值]
   GPU 2:  [完整参数]  [完整梯度]  [完整优化器]  [激活值]
   ...
   GPU N:  [完整参数]  [完整梯度]  [完整优化器]  [激活值]

   每个 GPU 的模型状态完全冗余 → 单 GPU 内存 = 16Φ 字节 (FP16 + Adam)

FSDP 的解决方案:
══════════════════════════════════════════════════════════════════════

   GPU 0:  [Param₀]  [Grad₀]  [Opt₀]  [激活值]     ← 各有 1/N
   GPU 1:  [Param₁]  [Grad₁]  [Opt₁]  [激活值]
   GPU 2:  [Param₂]  [Grad₂]  [Opt₂]  [激活值]
   ...
   GPU N:  [Paramₙ]  [Gradₙ]  [Optₙ]  [激活值]
               ↑                    ↑              ↑
         切分参数 (flat)     切分梯度 (flat)   切分优化器状态 (flat)

   需要时通过 all-gather 临时收集完整参数
   单 GPU 内存 = 16Φ / N 字节 (理想情况，加上激活值后约为 20Φ/N)
```

---

## 2. FSDP 核心工作原理

### 2.1 前向传播（Forward Pass）

```
FSDP 前向传播精确流程:
══════════════════════════════════════════════════════════════════════

  Step 1: 参数重建 (All-Gather)
  ─────────────────────────────────────────────────────────────────
    FSDP 单元 (wrapped module) 在进入 forward 前:
    
    ┌─────────────────────────────────────────────────────────┐
    │               All-Gather 操作                            │
    │                                                         │
    │  GPU 0: [W₀▯▯▯] ───┐                                   │
    │  GPU 1: [▯W₁▯▯] ───┤                                   │
    │  GPU 2: [▯▯W₂▯] ───┤  all-gather  →  每个 GPU 获得     │
    │  GPU 3: [▯▯▯W₃] ───┘  [W₀, W₁, W₂, W₃] 完整权重        │
    │                                                         │
    └─────────────────────────────────────────────────────────┘
    
    通信量 per unit: (N-1)/N × size(W)

  Step 2: 执行前向计算
  ─────────────────────────────────────────────────────────────────
    有了完整参数后，正常执行该层的 forward
    
    output = module(input)  # 使用刚 all-gather 到的完整参数

  Step 3: 释放非本地参数 (Free)
  ─────────────────────────────────────────────────────────────────
    前向计算完成后，如果没有设置 reshard_after_forward=False，
    则立即释放非本地参数分片（释放显存）
    
    GPU 0 保留 [W₀▯▯▯]，释放 [W₁, W₂, W₃]
    GPU 1 保留 [▯W₁▯▯]，释放 [W₀, W₂, W₃]
    ...

  Step 4: 移动到下一层
  ─────────────────────────────────────────────────────────────────
    继续处理下一个 FSDP 单元，重复 Step 1-3
```

**时间线可视化：**

```
FSDP 层与层之间的参数生命周期:
══════════════════════════════════════════════════════════════════════

时间 →
───────────────────────────────────────────────────────────────────

Layer 0:
  [=== All-Gather W0 ===][==== Forward L0 ====][= Free W0 =]
                                                  │
Layer 1:                                          │
           [=== All-Gather W1 ===][==== Forward L1 ====][= Free W1 =]
                                                     │
Layer 2:                                             │
              [=== All-Gather W2 ===][==== Forward L2 ====][= Free W2 =]

  │←─── 这一层在 GPU 上的时间 ──→│
  │    (W 占满显存)               │

  在任何时刻，GPU 上只持有:
    1 个完整层的参数 (当前正在计算的层) +
    自己负责的 N 个层的参数分片 (持久存储)

  内存峰值由「最大的一层」决定，而非整个模型。
```

### 2.2 反向传播（Backward Pass）

```
FSDP 反向传播精确流程:
══════════════════════════════════════════════════════════════════════

  对于每一层 (从最后一层到第一层):

  Step 1: 参数重建 (All-Gather)
  ─────────────────────────────────────────────────────────────────
    与 forward 相同，all-gather 收集该层的完整参数
    
    注意: 如果设置了 reshard_after_forward=False，
          参数还在内存中，可以省去这次 all-gather。
          代价: 显存占用更高 (参数不释放)。

  Step 2: 计算局部梯度
  ─────────────────────────────────────────────────────────────────
    反向传播计算该层参数的梯度
    
    ∂L/∂W = autograd.backward()  局部梯度

  Step 3: 梯度 Reduce-Scatter
  ─────────────────────────────────────────────────────────────────
    ┌─────────────────────────────────────────────────────────┐
    │              Reduce-Scatter 操作                        │
    │                                                         │
    │  每个 GPU 计算的是不同数据样本的梯度，                   │
    │  需要取平均 (reduce)，然后每个 GPU 只保留自己的分片     │
    │  (scatter)。                                             │
    │                                                         │
    │  GPU 0: ∇W₀, ∇W₁, ∇W₂, ∇W₃  ──→ reduce-scatter → GPU0: ∇W₀_avg
    │  GPU 1: ∇W₀, ∇W₁, ∇W₂, ∇W₃  ──→ reduce-scatter → GPU1: ∇W₁_avg
    │  GPU 2: ∇W₀, ∇W₁, ∇W₂, ∇W₃  ──→ reduce-scatter → GPU2: ∇W₂_avg
    │  GPU 3: ∇W₀, ∇W₁, ∇W₂, ∇W₃  ──→ reduce-scatter → GPU3: ∇W₃_avg
    │                                                         │
    └─────────────────────────────────────────────────────────┘

  Step 4: 释放非本地参数
  ─────────────────────────────────────────────────────────────────
    释放 all-gather 来的完整参数 (如果还持有的话)


通信量总结 (per layer):
══════════════════════════════════════════════════════════════════════

  reshard_after_forward=True (默认, 省显存):
    Forward:  1 × all-gather  = (N-1)/N × size(W)
    Backward: 1 × all-gather + 1 × reduce-scatter = 2 × (N-1)/N × size(W)
    总计: 3 × (N-1)/N × size(W) ≈ 3 × size(W)

  reshard_after_forward=False (更快, 省通信):
    Forward:  1 × all-gather  = (N-1)/N × size(W)
    Backward: 0 × all-gather + 1 × reduce-scatter = (N-1)/N × size(W)
    总计: 2 × (N-1)/N × size(W) ≈ 2 × size(W)

  对比:
    DeepSpeed ZeRO-3: forward 1 次 all-gather + backward 2 次 (1 all-gather + 1 reduce-scatter)
    = 同样约 3 × size(W) 通信量
```

### 2.3 优化器更新

```
FSDP 优化器更新流程:
══════════════════════════════════════════════════════════════════════

  在 optimizer.step() 时:

  ┌─────────────────────────────────────────────────────────────────┐
  │  每个 GPU 独立地:                                                │
  │                                                                  │
  │  1. 将 FP16/BF16 参数分片 → 转换为 FP32 master 分片              │
  │                                                                  │
  │  2. 用局部梯度分片更新 FP32 master 分片:                         │
  │       m_t = β₁·m_{t-1} + (1-β₁)·∇W                              │
  │       v_t = β₂·v_{t-1} + (1-β₂)·∇W²                             │
  │       W_t = W_{t-1} - lr · m̂_t / (√v̂_t + ε)                    │
  │                                                                  │
  │  3. 将更新后的 FP32 参数分片 → 转换回 FP16/BF16 分片             │
  │                                                                  │
  │  4. 缩放因子 (注意: 梯度已经在 reduce-scatter 中平均)            │
  │                                                                  │
  └─────────────────────────────────────────────────────────────────┘

  关键: FSDP 的优化器更新不需要任何通信！
        每个 GPU 只用本地数据更新自己负责的参数分片。
        这与 ZeRO-3 完全一致。
```

### 2.4 FSDP 的完整训练步骤

```
FSDP 一次迭代的完整 pythonic 过程:
══════════════════════════════════════════════════════════════════════

  1:  for batch in dataloader:
  2:      # ─── Forward ───
  3:      # FSDP 自动在每层前做 all-gather, 后做 free
  4:      output = model(batch)
  5:      loss = criterion(output, labels)
  6:
  7:      # ─── Backward ───
  8:      # FSDP 自动在每层后做 all-gather (如需要) 和 reduce-scatter
  9:      loss.backward()
 10:
 11:      # ─── Optimizer Step ───
 12:      # FSDP 的优化器只更新本地的参数分片
 13:      optimizer.step()
 14:      optimizer.zero_grad()
 15:
 16:      # ─── 下一轮 ───
 17:      # 下一次 forward 时，参数已经自动就绪
 18:
 19:  # 注意: FSDP 的所有通信 (all-gather, reduce-scatter) 都是
 20:  # 通过 PyTorch 的 autograd hooks 自动触发的!
 21:  # 用户不需要手动调用任何通信函数。

══════════════════════════════════════════════════════════════════════

FSDP 的 pre-forward hook 和 post-forward hook 机制:

    module.register_full_backward_pre_hook(pre_backward_hook)
    
    ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
    │ pre-forward   │ ──→ │   forward    │ ──→ │ post-forward │
    │ hook:         │     │   execution  │     │ hook:        │
    │ all-gather    │     │              │     │ free params  │
    └──────────────┘     └──────────────┘     └──────────────┘
                                                    │
                                   ┌────────────────┘
                                   ▼
    ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
    │ pre-backward  │ ──→ │   backward   │ ──→ │post-backward │
    │ hook:         │     │   execution  │     │ hook:        │
    │ all-gather    │     │              │     │ free params, │
    │ (如需要)       │     │              │     │red-scatter   │
    └──────────────┘     └──────────────┘     └──────────────┘
```

---

## 3. FSDP 封装策略与包装策略

### 3.1 什么是 Wrapping Policy

FSDP 不是全局切分所有参数的。它将模型切分成多个 **FSDP 单元 (FSDP units)**，每个单元内的参数被统一管理。

```
FSDP Wrapping 的概念:
══════════════════════════════════════════════════════════════════════

  原始模型 (20 层 Transformer):
  ┌────────────────────────────────────────────────────────────────┐
  │ Embedding │ L0 │ L1 │ L2 │ ... │ L18 │ L19 │ LM Head │ LayerNorm│
  └────────────────────────────────────────────────────────────────┘

  不做 wrapping (整个模型 1 个 FSDP 单元):
  ┌─────────────────────────────────────────────────────────────────┐
  │                    FSDP(整个模型)                                │
  │  一次 all-gather → 收集整个模型的参数 → OOM!                    │
  │  一个巨大的 FSDP 单元 = 参数切分 + 但 all-gather 时整模型加载   │
  └─────────────────────────────────────────────────────────────────┘

  按层 wrapping (每层 1 个 FSDP 单元):
  ┌───────┐ ┌───────┐ ┌───────┐       ┌───────┐ ┌───────┐ ┌───────┐
  │FSDP(Emb)│ │FSDP(L0)│ │FSDP(L1)││ ... │ │FSDP(L18)│ │FSDP(L19)│ │FSDP(Head)│
  └───────┘ └───────┘ └───────┘       └───────┘ └───────┘ └───────┘
     ↑           ↑         ↑               ↑         ↑         ↑
  独立单元    独立单元   独立单元         独立单元   独立单元   独立单元

  每层独立 all-gather → 峰值显存 = max(每层大小) + 切分参数
  推荐! 这是最常用的策略。
```

### 3.2 三种 Wrapping Policy

#### 3.2.1 SIZE_BASED（基于大小）

```python
from torch.distributed.fsdp.wrap import size_based_auto_wrap_policy

# 使用参数数量阈值决定是否封装
# 参数数 > min_num_params 的 module 会被 FSDP 封装

fsdp_model = FullyShardedDataParallel(
    model,
    auto_wrap_policy=size_based_auto_wrap_policy,
    min_num_params=1e6,  # 100 万参数以上的 module 会被封装
    # 如果 module 参数 < 1e6，则与其兄弟模块或父模块合并封装
)
```

#### 3.2.2 Transformer Wrapping Policy（基于类型）

```python
from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
from transformers.models.llama.modeling_llama import LlamaDecoderLayer

# 将每个 TransformerBlock 封装为一个 FSDP 单元
# 这是训练 LLM 最推荐的策略

fsdp_model = FullyShardedDataParallel(
    model,
    auto_wrap_policy=partial(
        transformer_auto_wrap_policy,
        transformer_layer_cls={
            LlamaDecoderLayer,  # 将这个类的实例封装为 FSDP 单元
        },
    ),
)
```

#### 3.2.3 手动封装

```python
# 完全手动控制哪些子模块被封装
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP

# 先对子模块做 FSDP
for i, layer in enumerate(model.layers):
    model.layers[i] = FSDP(layer)

# 再对最外层做 FSDP
model = FSDP(model)
```

### 3.3 Wrapping Policy 选择指南

```
选择合适的 Wrapping Policy:
══════════════════════════════════════════════════════════════════════

┌─────────────────────────┬──────────────┬──────────────────────────┐
│ 场景                     │ 推荐 Policy   │ 原因                      │
├─────────────────────────┼──────────────┼──────────────────────────┤
│ 简单 MLP / CNN          │ SIZE_BASED   │ 没有标准化的层边界         │
│ Transformer (HuggingFace)│ transformer  │ 每层大小均匀，适合独立     │
│                          │ _auto_wrap   │ all-gather               │
│ 自定义模型 + 需要细控     │ 手动封装     │ 完全控制显存和通信        │
│ 小模型 (<100M params)   │ SIZE_BASED   │ 或不用 FSDP，直接用 DDP   │
│ 大模型 (>1B params)     │ transformer  │ 必须逐层封装              │
└─────────────────────────┴──────────────┴──────────────────────────┘

经验法则:
  - FSDP 单元越大 → all-gather 通信越少 (更少但更大的消息)
                    → 但 all-gather 的内存峰值越大
  - FSDP 单元越小 → all-gather 通信越多 (更多但更小的消息)
                    → 但 all-gather 的内存峰值越小
                    → 也意味着更好的通信-计算重叠机会

  Transformer 按层 wrapping 是最佳平衡点：
    1. 每层大小适中 (可放入显存)
    2. 层间边界清晰，autograd hooks 自然衔接
    3. all-gather 和计算可以重叠
```

### 3.4 Forward Prefetch 与 Backward Prefetch

```
FSDP 的 Prefetch 机制:
══════════════════════════════════════════════════════════════════════

  forward_prefetch=True (默认):
  ─────────────────────────────────────────────────────────────────
    在处理当前层时，后台异步 all-gather 下一层的参数

    ┌─────────────────────────────────────────────────────────────┐
    │ Layer i-1 compute │ Prefetch Layer i │                     │
    │                   │ (all-gather)     │                     │
    └───────────────────┼─────────────────┼─────────────────────┘
                        │                 │
    ┌─────────────────────────────────────────────────────────────┐
    │                   │  Layer i compute │ Prefetch Layer i+1  │
    │                   │                  │ (all-gather)        │
    └───────────────────┼─────────────────┼─────────────────────┘
                        │                 │
    效果: all-gather 的时间被前一层计算时间"隐藏"

  backward_prefetch="pre" (默认, 在 backward 前 prefetch):
  ─────────────────────────────────────────────────────────────────
    在当前层 backward 完成前，预制下一层的参数

    backward_prefetch="post" (在 backward 后 prefetch):
    向后兼容，一般不推荐 (通信-计算重叠差)

  forward_prefetch 和 backward_prefetch 可以独立设置:
    fsdp_model = FSDP(
        model,
        forward_prefetch=True,       # 前向预取
        backward_prefetch=BackwardPrefetch.BACKWARD_PRE,  # 后向预取
    )
```

---

## 4. 混合精度与 FSDP

### 4.1 数据类型体系

```
FSDP 中的三种数据类型:
══════════════════════════════════════════════════════════════════════

  ┌─────────────────────────────────────────────────────────────┐
  │  param_dtype:  参数的存储/通信类型                           │
  │  ─────────────────────────────────────────────────────────  │
  │  各 GPU 上持久存储的参数分片的数据类型                       │
  │  也决定了 all-gather 时通信的数据类型                        │
  │                                                             │
  │  常见选择:                                                   │
  │    torch.float16  用于 FP16 混合精度                         │
  │    torch.bfloat16 用于 BF16 (A100+, 更推荐)                  │
  │    torch.float32  用于需要高精度的场景                        │
  └─────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────┐
  │  reduce_dtype:  梯度 reduce-scatter 时的数据类型              │
  │  ─────────────────────────────────────────────────────────  │
  │  在 reduce-scatter 收集梯度时使用                            │
  │                                                             │
  │  推荐: torch.float32 (确保梯度数值精度)                     │
  │  在高 batch size 时可考虑 BF16/FP16 (节省通信量, 但可能     │
  │    引入噪声)                                                 │
  └─────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────┐
  │  buffer_dtype:  缓冲区 (buffers) 的数据类型                   │
  │  ─────────────────────────────────────────────────────────  │
  │  例如 BatchNorm 的 running_mean, running_var 等              │
  │  通常保持与 param_dtype 一致                                 │
  └─────────────────────────────────────────────────────────────┘
```

### 4.2 混合精度配置代码

```python
import torch
from torch.distributed.fsdp import (
    FullyShardedDataParallel as FSDP,
    MixedPrecision,
    ShardingStrategy
)

# ─── FP16 混合精度 ─────────────────────────────────
# 需要 loss scaling
fp16_policy = MixedPrecision(
    param_dtype=torch.float16,      # 参数存储为 FP16
    reduce_dtype=torch.float32,     # 梯度 reduce 为 FP32 (保证精度)
    buffer_dtype=torch.float16,     # 缓冲区为 FP16
    cast_forward_inputs=True,       # 将输入 cast 为 FP16
)

# ─── BF16 混合精度 ─────────────────────────────────
# 推荐用于 A100/H100
bf16_policy = MixedPrecision(
    param_dtype=torch.bfloat16,
    reduce_dtype=torch.float32,     # BF16 reduce 可能丢失精度
    buffer_dtype=torch.bfloat16,
    cast_forward_inputs=True,
)

# ─── FP32 全精度 (调试用) ──────────────────────────
fp32_policy = MixedPrecision(
    param_dtype=torch.float32,
    reduce_dtype=torch.float32,
    buffer_dtype=torch.float32,
)

# ─── 应用到 FSDP ───────────────────────────────────
model = FSDP(
    model,
    mixed_precision=bf16_policy,
    sharding_strategy=ShardingStrategy.FULL_SHARD,  # ZeRO-3 等价
    # 或 ShardingStrategy.SHARD_GRAD_OP  # ZeRO-2 等价
    # 或 ShardingStrategy.NO_SHARD       # DDP 等价
)

# ─── 使用 autocast 进行前向计算 ────────────────────
# FSDP 的 cast_forward_inputs=True 已经处理了输入
# 但通常还需要 autocast 来处理内部运算
with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
    output = model(batch)
    loss = loss_fn(output, labels)
```

### 4.3 精度选择指南

```
══════════════════════════════════════════════════════════════════════
              精度选择决策树
══════════════════════════════════════════════════════════════════════

你的 GPU 是什么?
  │
  ├── H100/H800/B200 ──→ 使用 FP8 (通过 Transformer Engine 或 torch.float8)
  │                      需要: NVIDIA Transformer Engine + TE 集成
  │
  ├── A100/A800/L40S  ──→ 使用 BF16
  │                      param_dtype=BF16, reduce_dtype=FP32
  │                      BF16 不需要 loss scaling，更稳定
  │
  ├── V100/T4/A10     ──→ 使用 FP16
  │                      param_dtype=FP16, reduce_dtype=FP32
  │                      需要 loss scaling (GradScaler)
  │
  └── 老 GPU          ──→ 使用 FP32 (慎用 FP16，精度损失大)
                         或考虑使用 CPU offload + FP32

══════════════════════════════════════════════════════════════════════
```

---

## 5. FSDP CPU Offloading

### 5.1 CPU Offload 机制

```
FSDP CPU Offload 工作方式:
══════════════════════════════════════════════════════════════════════

  当参数不在前向/后向计算中时，自动将其从 GPU 移到 CPU

  ┌─────────────────────┐         ┌─────────────────────┐
  │       GPU HBM       │  PCIe   │      CPU DRAM       │
  │                     │◄───────►│                     │
  │  [当前层参数]        │         │  [其他层参数]        │
  │  (热数据，正在计算)   │         │  (冷数据，等待使用)   │
  │                     │         │                     │
  │  [当前层梯度]        │         │  [优化器状态]        │
  │  [当前层激活值]      │         │  m, v, master params│
  └─────────────────────┘         └─────────────────────┘

  生命周期:
  1. 下一个 FSDP 单元需要参数 → CPU → GPU 传输 (通过 all-gather)
  2. 当前 FSDP 单元计算完 → GPU → CPU 传输 (释放参数)
  3. 优化器更新后 → GPU → CPU 传输 (更新后的参数回到 CPU)

  PCIe 带宽需求:
  ─────────────────────────────────────────────────────────────────
    PCIe Gen4 x16: ~32 GB/s (单向)
    7B 模型参数: 14 GB (FP16)
    完整传输: 14 / 32 ≈ 0.44 秒
    
    与计算时间重叠后，可能不太影响吞吐量
    (前提是 batch size 足够大，计算时间 > 传输时间)
```

### 5.2 代码配置

```python
from torch.distributed.fsdp import (
    FullyShardedDataParallel as FSDP,
    CPUOffload,
)

# CPU Offload 配置
cpu_offload = CPUOffload(
    offload_params=True,   # 将参数 offload 到 CPU
    # 注意: offload_params=True 会自动 offload 优化器状态
    # 因为优化器状态与参数绑定
)

model = FSDP(
    model,
    cpu_offload=cpu_offload,
    # 其他参数...
)

# 也可以分步指定:
# 仅 offload 优化器状态 (不 offload 参数):
# 这需要自定义优化器 + FSDP 的组合
```

---

## 6. FSDP v1 vs v2 深度对比

### 6.1 版本演进

```
FSDP 版本演进时间线:
══════════════════════════════════════════════════════════════════════

  PyTorch 1.11 (2022.03):
    FSDP v1 首次发布 → 基本的功能性 FSDP

  PyTorch 1.12 (2022.06):
    增加 mixed precision 支持、CPU offload、更多的 wrapping policy

  PyTorch 2.0 (2023.03):
    FSDP v2 预览 (torch.distributed.fsdp._fully_shard)
    per-parameter sharding: 参数逐元素切分而非逐层切分
    更接近 ZeRO-3 的行为

  PyTorch 2.1 (2023.10):
    FSDP v2 稳定 → torch.distributed._composable.fsdp.fully_shard
    DTensor 集成

  PyTorch 2.2+ (2024+):
    FSDP v2 成熟 → 推荐的默认 FSDP 实现
    FSDP1 保留用于向后兼容
```

### 6.2 FSDP v1 (flat-parameter sharding)

```
FSDP v1 的 Flat Parameter 机制:
══════════════════════════════════════════════════════════════════════

  在 FSDP v1 中，每个 FSDP 单元内的所有参数被"展平"到一个大张量中:

  ┌────────────────────────────────────────────────────────────────┐
  │  TransformerBlock (被 FSDP 封装)                                │
  │                                                                 │
  │  原始参数:                                                       │
  │    self_attn.q_proj.weight  [4096, 4096]                       │
  │    self_attn.k_proj.weight  [4096, 4096]                       │
  │    self_attn.v_proj.weight  [4096, 4096]                       │
  │    self_attn.o_proj.weight  [4096, 4096]                       │
  │    mlp.gate_proj.weight     [11008, 4096]                      │
  │    mlp.up_proj.weight       [11008, 4096]                      │
  │    mlp.down_proj.weight     [4096, 11008]                      │
  │    ...                      共 ~130M 参数                       │
  │                                                                 │
  │  展平后:                                                        │
  │    flat_param = torch.cat([all params flattened])              │
  │    一个 1-D 张量，大小 = 130M 个元素                            │
  │                                                                 │
  │  FSDP v1 按这个 flat_param 切分:                               │
  │    GPU 0: flat_param[0 : 130M/4]                               │
  │    GPU 1: flat_param[130M/4 : 130M/2]                          │
  │    GPU 2: flat_param[130M/2 : 3*130M/4]                        │
  │    GPU 3: flat_param[3*130M/4 : 130M]                          │
  │                                                                 │
  └────────────────────────────────────────────────────────────────┘

  FSDP v1 优缺点:
    ✓ 通信效率高: 一次大 all-gather 比多次小 all-gather 更高效
    ✓ 实现简单: flat_param 是一个连续内存块
    ✗ 需要额外内存来创建 flat_param 的副本
    ✗ 灵活性差: 所有参数被均匀切分, 不能针对特定参数调整
    ✗ 与 DTensor 集成差: DTensor 是 per-tensor/per-dim 的
```

### 6.3 FSDP v2 (per-parameter sharding)

```
FSDP v2 的 Per-Parameter Sharding:
══════════════════════════════════════════════════════════════════════

  不再展平参数，而是为每个参数独立创建 DTensor:

  ┌─────────────────────────────────────────────────────────────────┐
  │ 使用 DTensor 的 FSDP v2:                                         │
  │                                                                  │
  │  self_attn.q_proj.weight:                                       │
  │    → DTensor(local=[1024,4096], mesh=(0,), placements=[Shard(0)])│
  │    GPU0: weight[0:1024, :]                                      │
  │    GPU1: weight[1024:2048, :]                                   │
  │    GPU2: weight[2048:3072, :]                                   │
  │    GPU3: weight[3072:4096, :]                                   │
  │                                                                  │
  │  mlp.gate_proj.weight:                                          │
  │    → DTensor(local=[2752,4096], mesh=(0,), placements=[Shard(0)])│
  │    GPU0: weight[0:2752, :]                                      │
  │    GPU1: weight[2752:5504, :]                                   │
  │    GPU2: weight[5504:8256, :]                                   │
  │    GPU3: weight[8256:11008, :]                                  │
  │                                                                  │
  │  每个参数都是独立的 DTensor，有自己的 sharding                  │
  │                                                                  │
  └─────────────────────────────────────────────────────────────────┘

  FSDP v2 核心 API:
  ─────────────────────────────────────────────────────────────────

  from torch.distributed._composable.fsdp import (
      fully_shard,
      MixedPrecisionPolicy,
  )

  # 对每个 Transformer 层做 FSDP
  for layer in model.layers:
      fully_shard(layer)

  # 对整个模型做 FSDP
  fully_shard(model)

  # 配置混合精度
  mp_policy = MixedPrecisionPolicy(
      param_dtype=torch.bfloat16,
      reduce_dtype=torch.float32,
  )
  fully_shard(model, mp_policy=mp_policy)


  FSDP v1 vs FSDP v2 对比:
  ┌─────────────────────────┬─────────────────────┬─────────────────────┐
  │        特性               │   FSDP v1           │   FSDP v2            │
  ├─────────────────────────┼─────────────────────┼─────────────────────┤
  │ 切分粒度                  │ flat_param (模块级)  │ per-parameter (DT)   │
  │ 底层技术                  │ 自定义 flat_param   │ DTensor              │
  │ 内存效率                  │ 需要 flat_param 缓存 │ 更好的内存效率       │
  │ activations 切分          │ 不支持              │ 支持 (DTensor)       │
  │ 与 TP 组合                │ 困难               │ 原生 (via DeviceMesh) │
  │ 与 PP 组合                │ 手动组合            │ 原生 (via DeviceMesh) │
  │ 异构硬件                  │ 有限               │ 支持                 │
  │ API 风格                  │ wrapper             │ composable API       │
  │ 稳定性                     │ ★★★★★              │ ★★★★☆               │
  │ 社区采用                   │ 广泛               │ 快速增长             │
  └─────────────────────────┴─────────────────────┴─────────────────────┘
```

---

## 7. FSDP vs DeepSpeed ZeRO-3 全面对比

```
┌──────────────────────────────────────────────────────────────────────────┐
│                   FSDP vs DeepSpeed ZeRO-3 深度逐项对比                     │
├───────────────────────────────┬────────────────────┬──────────────────────┤
│           维度                  │       FSDP         │    DeepSpeed ZeRO-3  │
├───────────────────────────────┼────────────────────┼──────────────────────┤
│ 核心算法                       │ 参数+梯度+优化器分片 │ 完全相同             │
│ 实现方式                       │ PyTorch autograd hook│ 自定义 C++/CUDA 引擎│
│ Forward all-gather             │ 每层自动             │ 每层自动             │
│ Backward reduce-scatter        │ 每层自动             │ 每层自动             │
├───────────────────────────────┼────────────────────┼──────────────────────┤
│ 通信量 (per step)              │ ~3× 参数大小         │ ~3× 参数大小         │
│ 显存节省 (理想)                │ 1/N (N = GPU 数量)  │ 1/N                  │
│ 显存节省 (实际)                │ 略多于 ZeRO-3       │ 更接近理论值         │
├───────────────────────────────┼────────────────────┼──────────────────────┤
│ 配置方式                       │ Python API          │ JSON 配置文件         │
│ 易用性                         │ 更 Pythonic         │ 配置文件更声明式      │
│ 灵活性                         │ 更高 (手动控制 hook) │ 更高 (丰富的参数)    │
│ 文档质量                       │ ★★★★☆              │ ★★★★★               │
│ 调试工具                       │ PyTorch Profiler    │ wall_clock_breakdown │
├───────────────────────────────┼────────────────────┼──────────────────────┤
│ Offload 支持                   │ CPU only            │ CPU + NVMe           │
│ 优化器选择                     │ 任意 PyTorch 优化器 │ 内置 + 任意          │
│ 学习率调度器                   │ 外部管理             │ 内置多种              │
│ 混合精度                       │ MixedPrecision 策略 │ fp16/bf16 配置块     │
├───────────────────────────────┼────────────────────┼──────────────────────┤
│ 激活检查点                     │ 需手动包装或 HF 集成 │ 原生配置              │
│ 梯度累积                       │ 手动或 HF 集成      │ 配置自动管理          │
├───────────────────────────────┼────────────────────┼──────────────────────┤
│ 与 HuggingFace 集成            │ ★★★★☆ (FSDPTrainer)│ ★★★★★ (Trainer+DS)   │
│ 与 Megatron-LM 集成            │ 有限                │ 深度集成              │
│ TP 组合                        │ FSDP2 + DTensor     │ 需 Megatron          │
│ PP 组合                        │ 手动 H-SDP          │ 支持的               │
├───────────────────────────────┼────────────────────┼──────────────────────┤
│ 适用场景: 简单微调             │ FSDP (更轻量)       │ 都可以               │
│ 适用场景: 复杂大规模训练       │ FSDP2              │ DeepSpeed (更成熟)    │
│ 适用场景: 极度显存受限          │ FSDP + offload     │ DS + CPU+NVMe offload │
│ 适用场景: 跨节点训练            │ FSDP2              │ DS + ZeRO++          │
└───────────────────────────────┴────────────────────┴──────────────────────┘

选择决策流程:
══════════════════════════════════════════════════════════════════════

  你是新手且想快速上手?
    → 如果跟 HF Trainer 用 → DeepSpeed (更简单, 配置驱动)
    → 如果想纯 PyTorch → FSDP (更 Pythonic)

  你需要 NVMe offload?
    → DeepSpeed (FSDP 不支持)

  你需要和 DTensor (TP) 结合?
    → FSDP v2 (原生 DTensor 集成)

  你需要在 64+ GPU 上稳定训练?
    → DeepSpeed (更久经考验, 坑少)

  你想减少外部依赖?
    → FSDP (纯 PyTorch, 不需要装 DeepSpeed)

  你在训练 175B+ 的模型?
    → DeepSpeed + Megatron (3D 并行生态更成熟)
══════════════════════════════════════════════════════════════════════
```

---

## 8. torch.distributed 基础架构

### 8.1 初始化与进程组

```python
"""
torch.distributed 基础示例
展示初始化、进程组管理、环境变量
"""

import os
import torch
import torch.distributed as dist


# ═══════════════════════════════════════════════════════════════
# 方法 1: 使用环境变量初始化 (最常见)
# torchrun 会自动设置这些环境变量
# ═══════════════════════════════════════════════════════════════

def init_method_env():
    """使用环境变量初始化"""

    # torchrun 自动设置的环境变量:
    # MASTER_ADDR = "localhost" 或 IP 地址
    # MASTER_PORT = "29500" 或其他端口
    # WORLD_SIZE  = 总进程数 (GPU 总数)
    # RANK        = 当前进程的全局 rank
    # LOCAL_RANK  = 当前节点上的本地 rank

    # 使用默认环境变量初始化
    dist.init_process_group(
        backend="nccl",          # GPU: "nccl", CPU: "gloo"
        init_method="env://",    # 从环境变量读取配置
    )

    # 或手动指定超时
    dist.init_process_group(
        backend="nccl",
        init_method="env://",
        timeout=datetime.timedelta(minutes=30),  # 超时设置
    )


# ═══════════════════════════════════════════════════════════════
# 方法 2: TCP 初始化
# ═══════════════════════════════════════════════════════════════

def init_method_tcp():
    """使用 TCP 地址初始化"""

    # 所有进程使用相同的 master 地址和端口
    dist.init_process_group(
        backend="nccl",
        init_method="tcp://10.0.0.1:29500",  # 主节点的 IP:端口
        world_size=8,
        rank=0,                               # 每个进程需指定自己的 rank
    )


# ═══════════════════════════════════════════════════════════════
# 方法 3: 共享文件系统初始化
# ═══════════════════════════════════════════════════════════════

def init_method_file():
    """使用共享文件系统初始化"""

    dist.init_process_group(
        backend="nccl",
        init_method="file:///mnt/shared/rendezvous_file",
        world_size=8,
        rank=0,
    )


# ═══════════════════════════════════════════════════════════════
# 进程组管理
# ═══════════════════════════════════════════════════════════════

def process_group_management():
    """进程组的高级管理"""

    # 获取基本信息
    rank = dist.get_rank()                     # 当前进程的全局 rank
    world_size = dist.get_world_size()         # 全局进程数
    local_rank = int(os.environ.get("LOCAL_RANK", 0))  # 本地 rank

    # 获取默认进程组
    default_pg = dist.group.WORLD  # 预定义的全局进程组

    # 创建子进程组 (用于 TP/PP 等场景)
    # 例如: 8 GPU 分成 2 个 TP 组
    tp_ranks = [[0, 1, 2, 3], [4, 5, 6, 7]]
    for group_ranks in tp_ranks:
        if rank in group_ranks:
            subgroup = dist.new_group(ranks=group_ranks)
            break

    # 销毁进程组
    # dist.destroy_process_group()  # 使用完毕时调用

    return rank, world_size, local_rank


# ═══════════════════════════════════════════════════════════════
# 通信后端选择
# ═══════════════════════════════════════════════════════════════

"""
┌──────────┬──────────────┬─────────────────────────────────────┐
│ 后端      │ 适用硬件      │ 特点                                │
├──────────┼──────────────┼─────────────────────────────────────┤
│ NCCL     │ NVIDIA GPU   │ GPU 间通信的标准选择                  │
│          │              │ 支持 all-reduce, all-gather 等       │
│          │              │ 利用 NVLink, InfiniBand, RoCE        │
├──────────┼──────────────┼─────────────────────────────────────┤
│ GLOO     │ CPU / GPU    │ CPU 通信, 或 GPU 的 fallback         │
│          │              │ 支持部分集合通信操作                  │
│          │              │ 通常用于初始化和小规模通信            │
├──────────┼──────────────┼─────────────────────────────────────┤
│ MPI      │ CPU / GPU    │ 传统的 MPI 通信后端                   │
│          │              │ 需要安装 MPI 库 (OpenMPI, MPICH)      │
│          │              │ 在 HPC 环境中更常用                   │
├──────────┼──────────────┼─────────────────────────────────────┤
│ UCC      │ NVIDIA GPU   │ 统一的集合通信库 (实验性)             │
│          │              │ 据称在特定场景下优于 NCCL             │
└──────────┴──────────────┴─────────────────────────────────────┘

  推荐: GPU 训练 → NCCL, CPU 训练 → GLOO, HPC 系统 → MPI
"""
```

### 8.2 环境变量详解

```
torch.distributed 使用的环境变量:
══════════════════════════════════════════════════════════════════════

  MASTER_ADDR:
    主节点的 IP 地址或主机名
    所有进程需要能够解析和连接到这个地址
    单机: localhost 或 127.0.0.1
    多机: 主节点的实际 IP

  MASTER_PORT:
    主节点的端口号
    必须是一个可用的空闲端口
    默认: 29500
    如果被占用，自动递增尝试 (torchrun --master_port=...)

  WORLD_SIZE:
    所有进程的总数 (通常 = GPU 总数)
    单机 8 GPU: WORLD_SIZE=8
    2 节点 8 GPU/节点: WORLD_SIZE=16

  RANK:
    当前进程的全局 rank，范围 [0, WORLD_SIZE-1]
    每个进程有唯一的 RANK

  LOCAL_RANK:
    当前进程在所在节点上的本地 rank，范围 [0, LOCAL_WORLD_SIZE-1]
    通常用于指定使用哪个 GPU: torch.cuda.set_device(LOCAL_RANK)

  LOCAL_WORLD_SIZE:
    当前节点上的进程数

  GROUP_RANK:
    节点组 rank (多节点场景)

  TORCHELASTIC_MAX_RESTARTS:
    弹性训练的最大重启次数 (默认: 0)

  TORCHELASTIC_RUN_ID:
    弹性训练的 run ID (自动生成)


  典型的多机环境变量设置:
  ────────────────────────────────────────────────────────────────

  节点 0 (主节点, IP: 10.0.0.1):
    export MASTER_ADDR=10.0.0.1
    export MASTER_PORT=29500
    export WORLD_SIZE=16
    # RANK 和 LOCAL_RANK 由 torchrun 自动设置

  节点 1 (IP: 10.0.0.2):
    export MASTER_ADDR=10.0.0.1  ← 指向主节点
    export MASTER_PORT=29500
    export WORLD_SIZE=16
```

---

## 9. 集合通信 API 详解

### 9.1 通信原语概览

```
PyTorch 集合通信原语家族:
══════════════════════════════════════════════════════════════════════

  ┌─────────────────────────────────────────────────────────────────┐
  │                     集合通信原语 (Collectives)                    │
  │                                                                  │
  │  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐          │
  │  │  all_reduce   │ │  all_gather   │ │reduce_scatter │          │
  │  │  所有→平均/求和 │ │  收集→所有     │ │  规约→分散    │          │
  │  └───────────────┘ └───────────────┘ └───────────────┘          │
  │                                                                  │
  │  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐          │
  │  │  broadcast    │ │   scatter     │ │   reduce      │          │
  │  │  广播→所有     │ │  分散→所有     │ │  规约→一个    │          │
  │  └───────────────┘ └───────────────┘ └───────────────┘          │
  │                                                                  │
  │  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐          │
  │  │  all_to_all   │ │   barrier     │ │  send/recv    │          │
  │  │  全交换        │ │  同步屏障      │ │  点对点        │          │
  │  └───────────────┘ └───────────────┘ └───────────────┘          │
  └─────────────────────────────────────────────────────────────────┘
```

### 9.2 All-Reduce

```
all_reduce 详解:
══════════════════════════════════════════════════════════════════════

  操作: 每个 GPU 的局部数据 → 所有 GPU 获得相同的规约结果

  ┌─────────────────────────────────────────────────────────────────┐
  │  GPU0: [a₀, b₀, c₀, d₀]                                        │
  │  GPU1: [a₁, b₁, c₁, d₁]                                        │
  │  GPU2: [a₂, b₂, c₂, d₂]                                        │
  │  GPU3: [a₃, b₃, c₃, d₃]                                        │
  │                        │                                        │
  │              all_reduce(op=SUM)                                  │
  │                        │                                        │
  │                        ▼                                        │
  │  GPU0: [Σa, Σb, Σc, Σd]   ← 所有 GPU 获得相同结果               │
  │  GPU1: [Σa, Σb, Σc, Σd]                                        │
  │  GPU2: [Σa, Σb, Σc, Σd]                                        │
  │  GPU3: [Σa, Σb, Σc, Σd]                                        │
  └─────────────────────────────────────────────────────────────────┘

  通信量: 2(N-1)/N × data_size ≈ 2 × data_size per GPU
  (ring all-reduce: scatter-reduce + all-gather)

  代码:
  ─────────────────────────────────────────────────────────────────

  tensor = torch.ones(1000).cuda() * rank  # 每个 GPU 不同的值

  # SUM: 求和
  dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
  # 所有 GPU 的 tensor 都变成: sum of all GPUs' tensors

  # AVG: 平均 (没有直接的 AVG op，用 SUM/N)
  dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
  tensor /= world_size

  # PRODUCT: 乘积
  dist.all_reduce(tensor, op=dist.ReduceOp.PRODUCT)

  # MIN/MAX: 最小值/最大值
  dist.all_reduce(tensor, op=dist.ReduceOp.MIN)
```

### 9.3 All-Gather

```
all_gather 详解:
══════════════════════════════════════════════════════════════════════

  操作: 每个 GPU 的局部数据 → 所有 GPU 收集全部数据

  ┌─────────────────────────────────────────────────────────────────┐
  │  GPU0: [A₀]            →  GPU0: [A₀, A₁, A₂, A₃]               │
  │  GPU1: [A₁]            →  GPU1: [A₀, A₁, A₂, A₃]               │
  │  GPU2: [A₂]            →  GPU2: [A₀, A₁, A₂, A₃]               │
  │  GPU3: [A₃]            →  GPU3: [A₀, A₁, A₂, A₃]               │
  └─────────────────────────────────────────────────────────────────┘

  通信量: (N-1)/N × data_size per GPU ≈ data_size per GPU

  代码:
  ─────────────────────────────────────────────────────────────────

  # 每个 GPU 的局部数据
  local_data = torch.ones(100).cuda() * rank  # [100], 值=rank

  # 输出列表: 存放收集到的所有 GPU 数据
  gathered_list = [torch.zeros(100).cuda() for _ in range(world_size)]

  dist.all_gather(gathered_list, local_data)

  # gathered_list[0] = GPU0 的数据
  # gathered_list[1] = GPU1 的数据
  # ...

  # 也可以收集到单个大张量中:
  output = torch.zeros(world_size * 100).cuda()
  dist.all_gather_into_tensor(output, local_data)
```

### 9.4 Reduce-Scatter

```
reduce_scatter 详解:
══════════════════════════════════════════════════════════════════════

  操作: 规约所有 GPU 的数据 → 分散结果，每个 GPU 只获得一部分

  ┌─────────────────────────────────────────────────────────────────┐
  │  GPU0: [A₀, B₀, C₀, D₀]                                         │
  │  GPU1: [A₁, B₁, C₁, D₁]                                         │
  │  GPU2: [A₂, B₂, C₂, D₂]                                         │
  │  GPU3: [A₃, B₃, C₃, D₃]                                         │
  │                        │                                        │
  │          reduce_scatter(op=SUM)                                  │
  │                        │                                        │
  │                        ▼                                        │
  │  GPU0: [ΣA,  _,  _,  _]   ← GPU0 只获得第 1 部分的规约结果      │
  │  GPU1: [ _, ΣB,  _,  _]   ← GPU1 只获得第 2 部分                │
  │  GPU2: [ _,  _, ΣC,  _]   ← GPU2 只获得第 3 部分                │
  │  GPU3: [ _,  _,  _, ΣD]   ← GPU3 只获得第 4 部分                │
  └─────────────────────────────────────────────────────────────────┘

  通信量: (N-1)/N × total_data_size per GPU ≈ data_size per GPU
  恰好是 all_reduce 的一半!

  代码:
  ─────────────────────────────────────────────────────────────────

  # 每个 GPU 持有完整的大张量
  full_tensor = torch.randn(world_size * 100).cuda()

  # reduce_scatter 后的输出 (每个 GPU 只获得一部分)
  output = torch.zeros(100).cuda()

  dist.reduce_scatter(output, [full_tensor], op=dist.ReduceOp.SUM)

  # 等价于: output = sum over GPUs of full_tensor[rank*100 : (rank+1)*100]

  # 注: 在 FSDP 中，gradient reduce-scatter 就是用的这个操作
```

### 9.5 Broadcast 与 Barrier

```
broadcast 详解:
══════════════════════════════════════════════════════════════════════

  操作: 将一个进程的数据广播到所有进程

  ┌─────────────────────────────────────────────────────────────────┐
  │  GPU0 (src=0): [DATA₀]                                          │
  │  GPU1:         [??????]  ──→ broadcast ──→ [DATA₀]              │
  │  GPU2:         [??????]  ──→            ──→ [DATA₀]              │
  │  GPU3:         [??????]  ──→            ──→ [DATA₀]              │
  └─────────────────────────────────────────────────────────────────┘

  通信量: 0 (src) / data_size (非 src) per GPU
  实际上是一个高效的树形/链式传播

  代码:
  ─────────────────────────────────────────────────────────────────

  if rank == 0:
      data = torch.tensor([42.0]).cuda()
  else:
      data = torch.zeros(1).cuda()

  dist.broadcast(data, src=0)
  # 现在所有 GPU 的 data 都是 [42.0]


barrier 详解:
══════════════════════════════════════════════════════════════════════

  操作: 所有进程在此处同步，等待所有进程到达后才继续

  代码:
  ─────────────────────────────────────────────────────────────────

  # 所有进程在这里等待，直到大家都到达
  dist.barrier()

  # 带超时
  dist.barrier()  # 如果超时则抛出异常

  # 仅子组内 barrier
  dist.barrier(group=my_subgroup)

  注意: barrier 是一种同步点，在调试时很有用，
        但在性能敏感的代码中应尽量避免。
```

### 9.6 Send/Recv (点对点)

```
send 和 recv 详解:
══════════════════════════════════════════════════════════════════════

  操作: 点对点数据传输 (不同于集合通信)

  ┌─────────────────────────────────────────────────────────────────┐
  │  GPU0 (rank=0)                             GPU1 (rank=1)       │
  │  ┌──────────┐                              ┌──────────┐        │
  │  │  data    │──── send ──────────────────→ │  recv     │        │
  │  │          │                              │          │        │
  │  └──────────┘                              └──────────┘        │
  └─────────────────────────────────────────────────────────────────┘

  代码:
  ─────────────────────────────────────────────────────────────────

  if rank == 0:
      data = torch.ones(1000).cuda()
      # 发送给 rank 1, tag=0
      dist.send(data, dst=1, tag=0)
  elif rank == 1:
      data = torch.zeros(1000).cuda()
      # 从 rank 0 接收, tag=0
      dist.recv(data, src=0, tag=0)

  # 非阻塞版本 (异步)
  if rank == 0:
      req = dist.isend(data, dst=1)
      req.wait()  # 等待发送完成
  elif rank == 1:
      req = dist.irecv(data, src=0)
      req.wait()  # 等待接收完成

  # 在流水线并行中，send/recv 是最常用的原语
```

### 9.7 All-to-All

```
all_to_all 详解:
══════════════════════════════════════════════════════════════════════

  操作: 每个 GPU 分散自己的数据到所有 GPU，同时收集所有 GPU 发来的数据

  ┌─────────────────────────────────────────────────────────────────┐
  │  GPU0: [A₀, B₀, C₀, D₀]  ──→  [A₀, A₁, A₂, A₃]               │
  │  GPU1: [A₁, B₁, C₁, D₁]  ──→  [B₀, B₁, B₂, B₃]               │
  │  GPU2: [A₂, B₂, C₂, D₂]  ──→  [C₀, C₁, C₂, C₃]               │
  │  GPU3: [A₃, B₃, C₃, D₃]  ──→  [D₀, D₁, D₂, D₃]               │
  └─────────────────────────────────────────────────────────────────┘

  用于: MoE (Mixture of Experts) 中的 token routing、Sequence Parallelism

  代码:
  ─────────────────────────────────────────────────────────────────

  input_list = [torch.ones(10).cuda() * (i * world_size + rank)
                for i in range(world_size)]
  output_list = [torch.zeros(10).cuda() for _ in range(world_size)]

  dist.all_to_all(output_list, input_list)
```

---

## 10. torchrun：分布式启动器

### 10.1 基本使用

```bash
# ═══════════════════════════════════════════════════════════════════
#                      torchrun 常用命令
# ═══════════════════════════════════════════════════════════════════

# 单机多 GPU (使用所有可用 GPU)
torchrun --nproc_per_node=8 train.py --batch_size 32

# 单机，指定 GPU 数量
torchrun --nproc_per_node=4 train.py

# 单机，指定使用哪些 GPU
CUDA_VISIBLE_DEVICES=0,1,2,3 torchrun --nproc_per_node=4 train.py

# 多机训练 (需要在每个节点上都运行此命令)
# 节点 0:
torchrun --nproc_per_node=8 --nnodes=2 \
    --node_rank=0 \
    --master_addr=10.0.0.1 \
    --master_port=29500 \
    train.py

# 节点 1:
torchrun --nproc_per_node=8 --nnodes=2 \
    --node_rank=1 \
    --master_addr=10.0.0.1 \
    --master_port=29500 \
    train.py

# 弹性训练 (允许动态增减节点)
torchrun --nproc_per_node=8 --nnodes=1:4 \
    --max_restarts=3 \
    --rdzv_backend=c10d \
    --rdzv_endpoint=10.0.0.1:29500 \
    train.py
```

### 10.2 Rendezvous 机制

```
Rendezvous (会合) 机制详解:
══════════════════════════════════════════════════════════════════════

  torchrun 使用 rendezvous 机制来让分布式进程相互发现。

  ┌─────────────────────────────────────────────────────────────────┐
  │                     Rendezvous 流程                              │
  │                                                                  │
  │  Step 1: 每个节点启动 torchrun，发起 rendezvous 连接              │
  │                                                                  │
  │  Step 2: torchrun 启动 N 个 worker 进程 (N = nproc_per_node)    │
  │                                                                  │
  │  Step 3: Worker 进程从环境变量中读取 rendezvous 信息              │
  │                                                                  │
  │  Step 4: 初始化 process group → 连接建立                         │
  │                                                                  │
  │  ┌──────────────┐                                                │
  │  │  Node 0      │ ──┐                                           │
  │  │  torchrun    │   │                                           │
  │  │  ├ w0 (R=0)  │   │   ┌─────────────────────┐                │
  │  │  ├ w1 (R=1)  │   ├──►│  Rendezvous Server   │                │
  │  │  └ ...       │   │   │  (c10d / etcd / ...) │                │
  │  └──────────────┘   │   └─────────────────────┘                │
  │                     │                                           │
  │  ┌──────────────┐   │                                           │
  │  │  Node 1      │ ──┘                                           │
  │  │  torchrun    │                                                │
  │  │  ├ w0 (R=4)  │                                                │
  │  │  ├ w1 (R=5)  │                                                │
  │  │  └ ...       │                                                │
  │  └──────────────┘                                                │
  └─────────────────────────────────────────────────────────────────┘

  Rendezvous 后端:
  ─────────────────────────────────────────────────────────────────

  --rdzv_backend=c10d:
    PyTorch 原生 rendezvous 实现
    使用 TCP store，最简单
    适合大多数场景

  --rdzv_backend=etcd:
    使用 etcd 分布式键值存储
    适合大规模集群
    需要预先部署 etcd 集群

  --rdzv_backend=etcd-v2:
    etcd v2 API 支持
    更新的实现
```

### 10.3 弹性训练

```
弹性训练 (Elastic Training):
══════════════════════════════════════════════════════════════════════

  弹性训练允许在训练过程中动态增减 GPU 节点，而无需从头开始。

  ┌─────────────────────────────────────────────────────────────────┐
  │                 Elastic Training 工作流程                        │
  │                                                                  │
  │  初始状态: 4 节点 (32 GPU)                                       │
  │    ┌───┐ ┌───┐ ┌───┐ ┌───┐                                     │
  │    │N0 │ │N1 │ │N2 │ │N3 │  → checkpoint at step 5000          │
  │    └───┘ └───┘ └───┘ └───┘                                     │
  │                                                                  │
  │  节点 2 宕机:                                                    │
  │    ┌───┐ ┌───┐      ┌───┐                                       │
  │    │N0 │ │N1 │      │N3 │  → 自动检测并触发 restart              │
  │    └───┘ └───┘      └───┘                                       │
  │                                                                  │
  │  从检查点恢复:                                                    │
  │    ┌───┐ ┌───┐      ┌───┐                                       │
  │    │N0 │ │N1 │      │N3 │  → load checkpoint                    │
  │    └───┘ └───┘      └───┘  → reshuffle data loaders            │
  │                             → continue from step 5000            │
  │                                                                  │
  │  新增节点 4:                                                     │
  │    ┌───┐ ┌───┐      ┌───┐ ┌───┐                                │
  │    │N0 │ │N1 │      │N3 │ │N4 │  → 扩展为 4 节点                │
  │    └───┘ └───┘      └───┘ └───┘                                │
  │                                                                  │
  └─────────────────────────────────────────────────────────────────┘

  弹性训练的关键要素:
  ─────────────────────────────────────────────────────────────────

  1. TORCHELASTIC_MAX_RESTARTS: 最大重试次数
  2. TORCHELASTIC_RUN_ID: 唯一的 run ID
  3. 支持不同 world_size 加载检查点 (resharding)
  4. 数据加载器需要能适应不同的 worker 数量
```

---

## 11. 分布式检查点 (DCP)

### 11.1 传统检查点的问题

```
传统检查点 (torch.save / torch.load) 的问题:
══════════════════════════════════════════════════════════════════════

  问题 1: 单一文件巨大
  ─────────────────────────────────────────────────────────────────
    torch.save(model.state_dict(), "model.pt")
    
    对于 70B 模型:
      FP16: 140 GB 单文件! → 读写极慢
      FP32: 280 GB → 几乎不可能


  问题 2: 无法切分保存
  ─────────────────────────────────────────────────────────────────
    FSDP 或 ZeRO-3 下，每个 GPU 只持有 1/N 的参数
    如果每个 GPU 都保存完整参数到同一个文件 → 冲突
    如果每个 GPU 保存自己的分片 → 难以合并恢复


  问题 3: 无法动态恢复
  ─────────────────────────────────────────────────────────────────
    8 GPU 保存的检查点 → 无法在 4 GPU 上恢复
    → 需要手动 resharding


  问题 4: 内存压力
  ─────────────────────────────────────────────────────────────────
    FSDP 保存时，需要先 all-gather 完整参数到 CPU → OOM!
```

### 11.2 DCP (Distributed Checkpoint) 方案

```
DCP 架构:
══════════════════════════════════════════════════════════════════════

  ┌─────────────────────────────────────────────────────────────────┐
  │                torch.distributed.checkpoint (DCP)                │
  │                                                                  │
  │  ┌─────────────────────────────────────────────────────────┐    │
  │  │                   Planning Phase                         │    │
  │  │  确定每个 rank 保存什么、保存在哪里                      │    │
  │  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐    │    │
  │  │  │ Plan R0  │ │ Plan R1  │ │ Plan R2  │ │ Plan R3  │    │    │
  │  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘    │    │
  │  └─────────────────────────────────────────────────────────┘    │
  │                              │                                   │
  │  ┌─────────────────────────────────────────────────────────┐    │
  │  │                   Writing Phase                          │    │
  │  │  每个 rank 独立写入自己的分片                            │    │
  │  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐    │    │
  │  │  │ Write R0 │ │ Write R1 │ │ Write R2 │ │ Write R3 │    │    │
  │  │  │  shard_0 │ │  shard_1 │ │  shard_2 │ │  shard_3 │    │    │
  │  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  存储布局 (文件系统):                                             │
│  ───────────────────────────────────────────────────────────────│
│                                                                  │
│  checkpoints/step_1000/                                         │
│    .metadata          ← 元数据 (tensor 名称, shape, dtype 等)    │
│    __0_0.distcp       ← rank 0 的数据分片                        │
│    __1_0.distcp       ← rank 1 的数据分片                        │
│    __2_0.distcp       ← rank 2 的数据分片                        │
│    __3_0.distcp       ← rank 3 的数据分片                        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 11.3 DCP 代码示例

```python
"""
torch.distributed.checkpoint 使用示例
"""
import torch
import torch.distributed as dist
import torch.distributed.checkpoint as dcp
from torch.distributed.checkpoint.state_dict import (
    get_state_dict,
    set_state_dict,
)
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP


# ═══════════════════════════════════════════════════════════════
# 保存检查点
# ═══════════════════════════════════════════════════════════════

def save_checkpoint(model, optimizer, step, save_dir):
    """保存 DCP 分布式检查点"""

    # 获取模型和优化器的 state_dict
    # FSDP 会自动处理分片 state_dict
    model_state_dict, optimizer_state_dict = get_state_dict(
        model, optimizer
    )

    # 构建完整的 state_dict
    state_dict = {
        "model": model_state_dict,
        "optimizer": optimizer_state_dict,
        "step": torch.tensor(step),
    }

    # 使用 DCP 保存
    # 每个 rank 只保存自己的分片!
    storage_writer = dcp.FileSystemWriter(
        path=save_dir,
        thread_count=4,  # 写入线程数
    )

    dcp.save(
        state_dict=state_dict,
        storage_writer=storage_writer,
    )

    print(f"Rank {dist.get_rank()}: Checkpoint saved to {save_dir}")


# ═══════════════════════════════════════════════════════════════
# 加载检查点 (相同 world_size)
# ═══════════════════════════════════════════════════════════════

def load_checkpoint(model, optimizer, load_dir):
    """加载 DCP 分布式检查点"""

    # 获取当前的 state_dict 结构 (空壳)
    model_state_dict, optimizer_state_dict = get_state_dict(
        model, optimizer
    )

    state_dict = {
        "model": model_state_dict,
        "optimizer": optimizer_state_dict,
    }

    # 使用 DCP 加载
    storage_reader = dcp.FileSystemReader(load_dir)

    dcp.load(
        state_dict=state_dict,
        storage_reader=storage_reader,
    )

    # 将加载的数据设置回模型和优化器
    set_state_dict(
        model,
        optimizer,
        model_state_dict=state_dict["model"],
        optimizer_state_dict=state_dict["optimizer"],
    )

    print(f"Rank {dist.get_rank()}: Checkpoint loaded")


# ═══════════════════════════════════════════════════════════════
# Resharding: 不同 world_size 加载
# ═══════════════════════════════════════════════════════════════

def load_checkpoint_with_reshard(model, optimizer, load_dir):
    """从不同 world_size 保存的检查点加载 (resharding)"""

    from torch.distributed.checkpoint.state_dict_loader import load
    from torch.distributed.checkpoint.format_utils import dcp_to_torch_save

    # DCP 天然支持 resharding!
    # 当用不同的 world_size 加载时，DCP 会自动重新分配分片

    model_state_dict, optimizer_state_dict = get_state_dict(
        model, optimizer
    )

    state_dict = {
        "model": model_state_dict,
        "optimizer": optimizer_state_dict,
    }

    storage_reader = dcp.FileSystemReader(load_dir)
    dcp.load(state_dict=state_dict, storage_reader=storage_reader)
    set_state_dict(model, optimizer,
                   model_state_dict=state_dict["model"],
                   optimizer_state_dict=state_dict["optimizer"])

    # 示例: 8 GPU 保存 → 4 GPU 加载
    # 原来的 8 个分片自动重新分布到 4 个 GPU


# ═══════════════════════════════════════════════════════════════
# 检查点转换: DCP → 单文件 (用于推理)
# ═══════════════════════════════════════════════════════════════

def convert_dcp_to_single_file(dcp_dir, output_path):
    """将 DCP 检查点转换为单个 .pt 文件"""
    dcp_to_torch_save(dcp_dir, output_path)
    print(f"Converted DCP checkpoint to: {output_path}")
```

### 11.4 FSDP 检查点最佳实践

```
FSDP 检查点保存策略:
══════════════════════════════════════════════════════════════════════

策略 1: SHARDED_STATE_DICT (推荐, 默认)
  ─────────────────────────────────────────────────────────────────
  每个 GPU 保存自己的参数分片 → 使用 DCP
  优点: 快速、内存高效、支持 resharding
  缺点: 需要 DCP 工具加载
  适合: 训练中频繁保存

  代码:
    with FSDP.state_dict_type(model, StateDictType.SHARDED_STATE_DICT):
        state_dict = model.state_dict()
        # 使用 DCP 保存


策略 2: FULL_STATE_DICT
  ─────────────────────────────────────────────────────────────────
  All-gather 完整参数 → 保存为单一 state_dict
  优点: 与标准 PyTorch 检查点完全兼容
  缺点: all-gather 需要额外显存和通信时间
  适合: 训练结束后的最终保存

  代码:
    with FSDP.state_dict_type(model, StateDictType.FULL_STATE_DICT):
        state_dict = model.state_dict()
        if rank == 0:
            torch.save(state_dict, "model_full.pt")
      # 注意: FULL_STATE_DICT 只在 rank 0 上 rank 0 有完整 state_dict
      #       其他 rank 上是空的


策略 3: LOCAL_STATE_DICT
  ─────────────────────────────────────────────────────────────────
  仅保存本地分片 (不做 flatten)
  优点: 快速，无通信
  缺点: 仅用于调试
  适合: 调试和快速分析
```

---

## 12. Device Mesh 与多维并行

### 12.1 Device Mesh 概念

```
Device Mesh (设备网格):
══════════════════════════════════════════════════════════════════════

  Device Mesh 是 PyTorch 2.0+ 引入的多维并行编排抽象，
  用于在 GPU 之间定义多维的通信拓扑。

  ┌─────────────────────────────────────────────────────────────────┐
  │                   Device Mesh 概念图                             │
  │                                                                  │
  │  一维 Mesh (仅 DP):                                              │
  │  ┌──────┬──────┬──────┬──────┬──────┬──────┬──────┬──────┐     │
  │  │ GPU0 │ GPU1 │ GPU2 │ GPU3 │ GPU4 │ GPU5 │ GPU6 │ GPU7 │     │
  │  └──────┴──────┴──────┴──────┴──────┴──────┴──────┴──────┘     │
  │  ←───────────────── dp (8 GPUs) ─────────────────→             │
  │                                                                  │
  │  二维 Mesh (TP × DP):                                           │
  │          tp_dim (2)                                              │
  │        ┌──────┬──────┐                                         │
  │        │ GPU0 │ GPU1 │   ← dp_group_0                          │
  │        ├──────┼──────┤                                         │
  │  dp_dim│ GPU2 │ GPU3 │   ← dp_group_1                          │
  │  (4)   ├──────┼──────┤                                         │
  │        │ GPU4 │ GPU5 │   ← dp_group_2                          │
  │        ├──────┼──────┤                                         │
  │        │ GPU6 │ GPU7 │   ← dp_group_3                          │
  │        └──────┴──────┘                                         │
  │         ↑      ↑                                                │
  │     tp_group_0  tp_group_1                                     │
  │                                                                  │
  │  三维 Mesh (PP × TP × DP):                                     │
  │          tp_dim                                                  │
  │        ┌──────┬──────┐                                         │
  │        │ G0   │ G1   │──┐                                      │
  │        ├──────┼──────┤  │ pp_dim                               │
  │  dp_dim│ G2   │ G3   │──┤                                      │
  │        ├──────┼──────┤  │                                      │
  │        │ G4   │ G5   │──┘                                      │
  │        └──────┴──────┘                                         │
  └─────────────────────────────────────────────────────────────────┘
```

### 12.2 Device Mesh 代码示例

```python
"""
Device Mesh 实现多维并行
展示: TP (张量并行) × DP (数据并行) 的组合
"""
import torch
import torch.distributed as dist
from torch.distributed.device_mesh import init_device_mesh
from torch.distributed.tensor.parallel import (
    parallelize_module,
    ColwiseParallel,
    RowwiseParallel,
)
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP


# ═══════════════════════════════════════════════════════════════
# 步骤 1: 创建 2D Device Mesh
# ═══════════════════════════════════════════════════════════════

def create_2d_mesh():
    """创建 TP × DP 二维设备网格"""

    # 8 个 GPU: TP=2, DP=4
    # GPU 映射:
    #   [GPU0, GPU1]  TP group 0, DP ranks 0,2,4,6
    #   [GPU2, GPU3]  TP group 1, DP ranks 1,3,5,7
    #   [GPU4, GPU5]
    #   [GPU6, GPU7]

    tp_size = 2
    dp_size = 4

    mesh = init_device_mesh(
        "cuda",
        (dp_size, tp_size),          # (DP, TP) 维度
        mesh_dim_names=("dp", "tp"),  # 命名维度
    )

    # mesh["tp"]: 返回 tp 维度的子 mesh
    # mesh["dp"]: 返回 dp 维度的子 mesh

    return mesh


# ═══════════════════════════════════════════════════════════════
# 步骤 2: 应用张量并行 (使用 DTensor)
# ═══════════════════════════════════════════════════════════════

def apply_tensor_parallelism(model, tp_mesh):
    """对 Transformer 模型应用张量并行"""

    from torch.distributed.tensor.parallel import (
        ParallelStyle,
        RowwiseParallel,
        ColwiseParallel,
        SequenceParallel,
    )

    # 对每个 Transformer 层的 Attention 和 MLP 块做 TP
    for layer in model.layers:
        # Attention 的 TP 布局:
        #   Q, K, V → 按列切分 (ColwiseParallel)
        #   Output → 按行切分 (RowwiseParallel)
        parallelize_module(
            module=layer.self_attn,
            device_mesh=tp_mesh,
            parallelize_plan={
                "q_proj": ColwiseParallel(),
                "k_proj": ColwiseParallel(),
                "v_proj": ColwiseParallel(),
                "o_proj": RowwiseParallel(),
            },
        )

        # MLP 的 TP 布局:
        parallelize_module(
            module=layer.mlp,
            device_mesh=tp_mesh,
            parallelize_plan={
                "gate_proj": ColwiseParallel(),
                "up_proj": ColwiseParallel(),
                "down_proj": RowwiseParallel(),
            },
        )

    return model


# ═══════════════════════════════════════════════════════════════
# 步骤 3: 组合 FSDP (DP) + TP → 2D 并行
# ═══════════════════════════════════════════════════════════════

def create_2d_parallel_model(model):
    """构建 TP × DP 2D 并行模型"""

    mesh = create_2d_mesh()

    # 获取本 rank 在 mesh 中的位置
    dp_mesh = mesh["dp"]  # DP 维度的子 mesh
    tp_mesh = mesh["tp"]  # TP 维度的子 mesh

    # 第一步: 应用 TP
    model = apply_tensor_parallelism(model, tp_mesh)

    # 第二步: 应用 FSDP (在 DP 维度上)
    # FSDP 只会在 dp_mesh 上的 GPU 之间通信
    model = FSDP(
        model,
        device_mesh=dp_mesh,          # 指定 DP 的 mesh
        sharding_strategy=...,
        mixed_precision=...,
        use_orig_params=True,         # 使用原始参数 (用于 DTensor)
    )

    return model


# ═══════════════════════════════════════════════════════════════
# 步骤 4: 3D 并行 (PP × TP × DP)
# ═══════════════════════════════════════════════════════════════

def create_3d_mesh():
    """创建 PP × TP × DP 三维设备网格"""

    pp_size = 2   # 流水线并行维度
    tp_size = 2   # 张量并行维度
    dp_size = 4   # 数据并行维度

    # 总共需要 16 个 GPU
    mesh = init_device_mesh(
        "cuda",
        (pp_size, tp_size, dp_size),
        mesh_dim_names=("pp", "tp", "dp"),
    )

    # 访问子 mesh:
    # mesh["pp", "tp"] → 获取 PP×TP 的子 mesh (8 GPUs)
    # mesh["dp"] → 获取 DP 维度的子 mesh (4 GPUs)

    return mesh


# ═══════════════════════════════════════════════════════════════
# 设备 mesh 与子进程组的关系
# ═══════════════════════════════════════════════════════════════

"""
Device Mesh 内部实现:
─────────────────────────────────────────────────────────────────

  init_device_mesh("cuda", (4, 2), mesh_dim_names=("dp", "tp"))

  内部创建了以下进程组:

  全局组 (8 GPUs): [0, 1, 2, 3, 4, 5, 6, 7]

  TP 子组:
    tp_group_0: [0, 1]  ← GPU 0,1 组成一个 TP 组
    tp_group_1: [2, 3]
    tp_group_2: [4, 5]
    tp_group_3: [6, 7]

  DP 子组:
    dp_group_0: [0, 2, 4, 6]  ← GPU 0,2,4,6 组成一个 DP 组
    dp_group_1: [1, 3, 5, 7]

  通信规则:
    - TP 通信 (all-reduce) 在 tp_group 内进行 → 仅在 GPU 0↔1, 2↔3, ... 之间
    - DP 通信 (FSDP all-gather/reduce-scatter) 在 dp_group 内进行 → GPU 0↔2↔4↔6, ...
    - 两组通信完全独立，可以同时进行!
"""
```

### 12.3 并行策略组合指南

```
══════════════════════════════════════════════════════════════════════
                    并行策略选择决策图
══════════════════════════════════════════════════════════════════════

                        模型有多大?
                            │
                ┌───────────┼───────────┐
                ▼           ▼           ▼
             <1B 参数    1B-10B      >10B 参数
                │           │           │
                ▼           ▼           ▼
            单 GPU      DDP/ZeRO-2  需要组合策略
            或 DDP                     │
                           ┌───────────┼───────────┐
                           ▼           ▼           ▼
                       单卡能装下    单卡装不下   单卡远远装不下
                       整个模型      整个模型     整个模型
                           │           │           │
                           ▼           ▼           ▼
                        ZeRO-2      ZeRO-3    ZeRO-3+TP+PP
                       或 FSDP     或 FSDP        (3D)

并行策略组合建议:

1. 单机 8×A100 (80GB):
   - 7B: ZeRO-2 / FSDP (SHARD_GRAD_OP)
   - 13B: ZeRO-3 / FSDP (FULL_SHARD)
   - 30B: ZeRO-3 + activation checkpointing
   - 65B: ZeRO-3 + CPU offload 或 ZeRO-3 + TP=2

2. 多机 (16-64 GPUs):
   - 70B: ZeRO-3 + TP=2 (1 节点 TP, 跨节点 DP)
   - 175B: ZeRO-3 + TP=4 + PP=4 (或 TP=8 + DP=8)
   - 530B: TP=8 + PP=8 + DP=... (纯 3D)

3. 极大规模 (512+ GPUs, >500B):
   - TP=8 (节点内)
   - PP=16 (跨节点)
   - DP=剩余 GPUs/(TP×PP)
   - ZeRO-1 或 ZeRO-2 (优化器状态切分)
══════════════════════════════════════════════════════════════════════
```

---

## 13. 完整训练脚本与实战

### 13.1 完整的 FSDP 训练脚本

```python
#!/usr/bin/env python3
"""
完整的 FSDP 分布式训练脚本
支持: FSDP v1/v2, 混合精度, activation checkpointing,
      梯度累积, DCP 检查点, 性能监控
"""

import os
import time
import argparse
from functools import partial
from typing import Optional

import torch
import torch.nn as nn
import torch.distributed as dist
import torch.distributed.checkpoint as dcp

from torch.distributed.fsdp import (
    FullyShardedDataParallel as FSDP,
    MixedPrecision,
    ShardingStrategy,
    BackwardPrefetch,
    CPUOffload,
    StateDictType,
)
from torch.distributed.fsdp.wrap import (
    transformer_auto_wrap_policy,
    size_based_auto_wrap_policy,
)
from torch.distributed.fsdp.fully_sharded_data_parallel import (
    FullStateDictConfig,
    ShardedStateDictConfig,
)

from torch.utils.data import DataLoader, Dataset
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR


# ═══════════════════════════════════════════════════════════════
# 命令行参数
# ═══════════════════════════════════════════════════════════════

def parse_args():
    parser = argparse.ArgumentParser(description="FSDP Training Script")

    # 模型参数
    parser.add_argument("--model_name", type=str,
                        default="meta-llama/Llama-2-7b-hf")
    parser.add_argument("--max_seq_length", type=int, default=2048)

    # 训练参数
    parser.add_argument("--global_batch_size", type=int, default=64)
    parser.add_argument("--per_device_batch_size", type=int, default=1)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--learning_rate", type=float, default=1e-5)
    parser.add_argument("--weight_decay", type=float, default=0.1)
    parser.add_argument("--warmup_steps", type=int, default=100)
    parser.add_argument("--max_steps", type=int, default=1000)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)

    # FSDP 参数
    parser.add_argument("--fsdp_version", type=int, default=1,
                        choices=[1, 2])
    parser.add_argument("--sharding_strategy", type=str,
                        default="full_shard",
                        choices=["full_shard", "shard_grad_op", "no_shard"])
    parser.add_argument("--wrapping_policy", type=str,
                        default="transformer",
                        choices=["transformer", "size_based", "none"])
    parser.add_argument("--min_num_params", type=int, default=1e6)

    # 优化参数
    parser.add_argument("--use_bf16", action="store_true", default=True)
    parser.add_argument("--cpu_offload", action="store_true", default=False)
    parser.add_argument("--activation_checkpointing",
                        action="store_true", default=True)
    parser.add_argument("--forward_prefetch", action="store_true",
                        default=True)
    parser.add_argument("--backward_prefetch", type=str,
                        default="backward_pre",
                        choices=["backward_pre", "backward_post"])

    # 检查点参数
    parser.add_argument("--output_dir", type=str, default="./checkpoints")
    parser.add_argument("--save_steps", type=int, default=500)
    parser.add_argument("--resume_from_checkpoint", type=str, default=None)
    parser.add_argument("--use_dcp", action="store_true", default=True)

    # 日志参数
    parser.add_argument("--logging_steps", type=int, default=10)

    return parser.parse_args()


# ═══════════════════════════════════════════════════════════════
# FSDP 配置构建
# ═══════════════════════════════════════════════════════════════

def build_fsdp_config(args):
    """构建 FSDP 的 MixedPrecision 和 ShardingStrategy"""

    # 策略映射
    strategy_map = {
        "full_shard": ShardingStrategy.FULL_SHARD,         # ZeRO-3 等价
        "shard_grad_op": ShardingStrategy.SHARD_GRAD_OP,   # ZeRO-2 等价
        "no_shard": ShardingStrategy.NO_SHARD,             # DDP 等价
    }
    sharding_strategy = strategy_map[args.sharding_strategy]

    # 混合精度策略
    if args.use_bf16:
        mp_policy = MixedPrecision(
            param_dtype=torch.bfloat16,
            reduce_dtype=torch.float32,
            buffer_dtype=torch.bfloat16,
            cast_forward_inputs=True,
        )
    else:
        mp_policy = MixedPrecision(
            param_dtype=torch.float16,
            reduce_dtype=torch.float32,
            buffer_dtype=torch.float16,
            cast_forward_inputs=True,
        )

    # CPU Offload
    cpu_offload = None
    if args.cpu_offload:
        cpu_offload = CPUOffload(offload_params=True)

    # Backward Prefetch
    prefetch_map = {
        "backward_pre": BackwardPrefetch.BACKWARD_PRE,
        "backward_post": BackwardPrefetch.BACKWARD_POST,
    }
    backward_prefetch = prefetch_map[args.backward_prefetch]

    return {
        "sharding_strategy": sharding_strategy,
        "mixed_precision": mp_policy,
        "cpu_offload": cpu_offload,
        "backward_prefetch": backward_prefetch,
        "forward_prefetch": args.forward_prefetch,
    }


# ═══════════════════════════════════════════════════════════════
# 主训练函数
# ═══════════════════════════════════════════════════════════════

def main():
    args = parse_args()

    # 初始化分布式环境
    dist.init_process_group(backend="nccl")
    local_rank = int(os.environ["LOCAL_RANK"])
    rank = dist.get_rank()
    world_size = dist.get_world_size()

    torch.cuda.set_device(local_rank)
    print(f"Rank {rank}/{world_size} initialized on GPU {local_rank}")

    # 加载模型
    from transformers import AutoModelForCausalLM, AutoTokenizer
    # (实际使用时取消注释)
    # tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    # model = AutoModelForCausalLM.from_pretrained(
    #     args.model_name,
    #     torch_dtype=torch.bfloat16 if args.use_bf16 else torch.float16,
    # )

    # 示例: 创建一个简单的 Transformer 模型用于演示
    model = nn.Sequential(*[
        nn.TransformerEncoderLayer(
            d_model=768,
            nhead=12,
            dim_feedforward=3072,
            batch_first=True,
        )
        for _ in range(12)
    ])

    # 激活检查点
    if args.activation_checkpointing:
        from torch.distributed.algorithms._checkpoint.checkpoint_wrapper import (
            apply_activation_checkpointing,
            checkpoint_wrapper,
            CheckpointImpl,
        )
        non_reentrant_wrapper = partial(
            checkpoint_wrapper,
            checkpoint_impl=CheckpointImpl.NO_REENTRANT,
        )
        # 对每个 TransformerBlock 应用激活检查点
        def check_fn(submodule):
            return isinstance(submodule, nn.TransformerEncoderLayer)
        apply_activation_checkpointing(
            model, checkpoint_wrapper_fn=non_reentrant_wrapper,
            check_fn=check_fn
        )

    # 构建 FSDP wrapping policy
    if args.wrapping_policy == "transformer":
        # 对于 HuggingFace 模型:
        # from transformers.models.llama.modeling_llama import LlamaDecoderLayer
        # auto_wrap_policy = partial(
        #     transformer_auto_wrap_policy,
        #     transformer_layer_cls={LlamaDecoderLayer},
        # )
        auto_wrap_policy = partial(
            transformer_auto_wrap_policy,
            transformer_layer_cls={nn.TransformerEncoderLayer},
        )
    elif args.wrapping_policy == "size_based":
        auto_wrap_policy = partial(
            size_based_auto_wrap_policy,
            min_num_params=args.min_num_params,
        )
    else:
        auto_wrap_policy = None

    # 构建 FSDP 配置
    fsdp_config = build_fsdp_config(args)

    # 应用 FSDP
    model = FSDP(
        model,
        auto_wrap_policy=auto_wrap_policy,
        **fsdp_config,
        device_id=torch.cuda.current_device(),
        sync_module_states=True,  # 加载模型时同步参数
        use_orig_params=True,     # 保持原始参数名称
    )

    # 优化器和调度器
    optimizer = AdamW(
        model.parameters(),
        lr=args.learning_rate,
        betas=(0.9, 0.95),
        weight_decay=args.weight_decay,
    )
    scheduler = CosineAnnealingLR(optimizer, T_max=args.max_steps)

    # 计算每步的实际 batch size
    grad_accum = args.gradient_accumulation_steps
    effective_batch = args.per_device_batch_size * grad_accum * world_size
    print(f"Effective batch size: {effective_batch}")

    # 训练循环
    model.train()
    global_step = 0
    total_loss = 0.0
    start_time = time.time()

    # 模拟数据
    dummy_batch = torch.randn(args.per_device_batch_size, 768).cuda()

    for step in range(args.max_steps):
        # 前向传播
        output = model(dummy_batch)
        loss = output.mean()  # 简化的 loss

        # 反向传播 (FSDP 自动处理通信)
        loss.backward()

        total_loss += loss.item()

        # 梯度累积
        if (step + 1) % grad_accum == 0:
            # 梯度裁剪
            if args.max_grad_norm > 0:
                model.clip_grad_norm_(args.max_grad_norm)

            # 优化器步进
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()

            global_step += 1

            # 日志
            if global_step % args.logging_steps == 0:
                elapsed = time.time() - start_time
                avg_loss = total_loss / args.logging_steps
                tokens_per_sec = (
                    effective_batch * args.max_seq_length
                    * args.logging_steps / elapsed
                )
                print(
                    f"Step: {global_step}/{args.max_steps}, "
                    f"Loss: {avg_loss:.4f}, "
                    f"Tokens/sec: {tokens_per_sec:.0f}, "
                    f"LR: {scheduler.get_last_lr()[0]:.2e}"
                )
                total_loss = 0.0
                start_time = time.time()

            # 保存检查点
            if global_step % args.save_steps == 0:
                save_dir = os.path.join(
                    args.output_dir, f"step_{global_step}"
                )
                os.makedirs(save_dir, exist_ok=True)

                if args.use_dcp:
                    # DCP 分布式检查点
                    with FSDP.state_dict_type(
                        model, StateDictType.SHARDED_STATE_DICT
                    ):
                        state_dict = {
                            "model": model.state_dict(),
                            "optimizer": optimizer.state_dict(),
                            "step": torch.tensor(global_step),
                        }
                    dcp.save(state_dict,
                             storage_writer=dcp.FileSystemWriter(save_dir))
                else:
                    # 传统检查点 (仅在 rank 0 保存)
                    with FSDP.state_dict_type(
                        model, StateDictType.FULL_STATE_DICT,
                        FullStateDictConfig(rank0_only=True, offload_to_cpu=True)
                    ):
                        state_dict = model.state_dict()
                    if rank == 0:
                        torch.save(state_dict, os.path.join(
                            save_dir, "model.pt"
                        ))

                if rank == 0:
                    print(f"Checkpoint saved at step {global_step}")


if __name__ == "__main__":
    main()
```

### 13.2 性能分析工具

```python
# ═══════════════════════════════════════════════════════════════
# 使用 PyTorch Profiler 分析 FSDP 性能
# ═══════════════════════════════════════════════════════════════

from torch.profiler import profile, record_function, ProfilerActivity

def training_step_with_profile(model, batch, optimizer, scheduler):
    """带 profiler 的训练步骤"""

    with profile(
        activities=[
            ProfilerActivity.CPU,
            ProfilerActivity.CUDA,
        ],
        schedule=torch.profiler.schedule(
            wait=1,          # 等待 1 步
            warmup=1,        # 预热 1 步
            active=3,        # 记录 3 步
            repeat=1,        # 重复 1 次
        ),
        on_trace_ready=torch.profiler.tensorboard_trace_handler(
            "./profiler_logs"
        ),
        record_shapes=True,
        profile_memory=True,
        with_stack=True,
    ) as prof:
        for step in range(10):
            with record_function("forward"):
                output = model(batch)
                loss = output.mean()

            with record_function("backward"):
                loss.backward()

            with record_function("optimizer_step"):
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()

            prof.step()  # 通知 profiler 进入下一步

    # 查看结果:
    # $ tensorboard --logdir=./profiler_logs
    # 在 Chrome 中打开 http://localhost:6006
    # 可以看到 FSDP 各层的 all-gather, reduce-scatter 时间线


# ═══════════════════════════════════════════════════════════════
# 使用 torch.cuda.memory_stats 分析显存
# ═══════════════════════════════════════════════════════════════

def print_memory_stats(prefix=""):
    """打印 GPU 显存统计信息"""

    allocated = torch.cuda.memory_allocated() / 1024**3
    reserved = torch.cuda.memory_reserved() / 1024**3
    max_allocated = torch.cuda.max_memory_allocated() / 1024**3

    print(
        f"{prefix} GPU Memory: "
        f"allocated={allocated:.2f}GB, "
        f"reserved={reserved:.2f}GB, "
        f"max_allocated={max_allocated:.2f}GB"
    )

    # 更详细的信息
    stats = torch.cuda.memory_stats()
    print(f"  Active: {stats.get('active_bytes.all.current', 0) / 1e9:.2f}GB")
    print(f"  Inactive: {stats.get('inactive_split_bytes.all.current', 0) / 1e9:.2f}GB")


# ═══════════════════════════════════════════════════════════════
# 通信-计算重叠验证
# ═══════════════════════════════════════════════════════════════

def verify_communication_overlap():
    """验证 FSDP 通信是否与计算重叠"""

    import torch.cuda.nvtx as nvtx

    # 使用 NVTX 标记 (需要 NVIDIA Nsight Systems)
    with nvtx.range("training_step"):
        # ... training code ...

    # 在 nsys 中查看:
    # $ nsys profile -o profile_output python train.py
    # 在 Nsight Systems GUI 中打开 profile_output.qdrep
    # 查看 CUDA Stream 的时间线:
    #   - 如果 all-gather 和 compute 在同一时间段内 → 成功重叠
    #   - 如果它们是串行的 → 需要调整 bucket size 或 prefetch 设置
```

---

## 15. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| FSDP (Fully Sharded Data Parallel) | PyTorch 原生等效 ZeRO-3 —— 模型参数/梯度/优化器全部切片分布，按需 All-Gather | Ch.2 |
| Wrapping Policy | 决定哪些子模块被包裹为一个 FSDP 单元 —— 太粗 OOM，太细通信多，按 TransformerBlock 包裹刚好 | Ch.3 |
| Device Mesh | 将 GPU 编组为多维网格（如 dp×tp），每个维度独立管理通信子组 —— PyTorch 2.0+ 多维并行的核心抽象 | Ch.12 |
| DTensor | 带 sharding 元数据的分布式张量，FSDP v2 用它对每个参数独立切分 —— 替代 v1 的 flat_param 方案 | Ch.6.3 |
| DCP (Distributed Checkpoint) | 每个 rank 各自保存自己的参数分片，加载时自动 resharding —— 解决大模型检查点 OOM 和跨 world_size 恢复问题 | Ch.11 |
| MixedPrecision (param/reduce/buffer dtype) | 分别控制参数存储、梯度规约、buffer 的精度 —— FSDP 的精度「三板斧」 | Ch.4 |

## 16. A800 部署场景举例

**场景 1：单机 8×A800 80GB 用 FSDP FULL_SHARD + BF16 训练 Qwen2.5-7B**

```
硬件: 1 节点 8×A800 80GB, NVSwitch NVLink 600 GB/s
策略: FSDP (FULL_SHARD, 即 ZeRO-3 等价) + BF16 + transformer_auto_wrap_policy

PyTorch FSDP 核心代码:
  from torch.distributed.fsdp import (
      FullyShardedDataParallel as FSDP,
      MixedPrecision, ShardingStrategy, BackwardPrefetch,
  )
  from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
  from functools import partial
  from transformers.models.qwen2 import Qwen2DecoderLayer  # 示例

  mp_policy = MixedPrecision(
      param_dtype=torch.bfloat16,
      reduce_dtype=torch.float32,
      buffer_dtype=torch.bfloat16,
      cast_forward_inputs=True,
  )
  wrapping_policy = partial(
      transformer_auto_wrap_policy,
      transformer_layer_cls={Qwen2DecoderLayer},
  )
  model = FSDP(
      model,
      auto_wrap_policy=wrapping_policy,
      sharding_strategy=ShardingStrategy.FULL_SHARD,
      mixed_precision=mp_policy,
      backward_prefetch=BackwardPrefetch.BACKWARD_PRE,
      forward_prefetch=True,
      device_id=torch.cuda.current_device(),
      use_orig_params=True,
  )

启动命令:
  torchrun --standalone --nnodes=1 --nproc_per_node=8 train_fsdp.py

每 GPU 显存 ≈ 16×7B/8 + 激活值 ≈ 14 + 8 GB ≈ 22 GB (80GB 充裕)
单步耗时: FSDP 通信模式与 ZeRO-3 相同 (6Φ total),
          NVLink 下 all-gather + reduce-scatter 约占总时间 10-15%
```

**场景 2：保存检查点 —— DCP vs FULL_STATE_DICT**

```python
# 训练中频繁保存（推荐 DCP）:
from torch.distributed.fsdp import StateDictType
with FSDP.state_dict_type(model, StateDictType.SHARDED_STATE_DICT):
    state_dict = {"model": model.state_dict(), "optimizer": optimizer.state_dict()}
    dcp.save(state_dict, storage_writer=dcp.FileSystemWriter("./ckpt/step_1000"))
# 优点: 每个 rank 只写自己的分片，无 all-gather，内存友好，支持 resharding

# 最终保存完整模型（用于推理部署）:
from torch.distributed.fsdp import FullStateDictConfig
with FSDP.state_dict_type(
    model, StateDictType.FULL_STATE_DICT,
    FullStateDictConfig(rank0_only=True, offload_to_cpu=True)
):
    if rank == 0:
        torch.save(model.state_dict(), "model_full.pt")
# 优点: 标准 PyTorch checkpoint，可直接加载推理
```

## 17. 上下游串联

```
                    AI Infra 训练栈 — FSDP / torch.distributed 的位置
                    
    ┌──────────────────────────────────────────────────────────┐
    │  分布式训练基础 (DDP, NCCL, torchrun, 弹性训练)           │
    │  torch.distributed 是这一切的底层通信库                   │
    └──────────────────────────┬───────────────────────────────┘
                               │
    ┌──────────────────────────┴───────────────────────────┐
    │  ★ 本份文档：FSDP + torch.distributed                │
    │  ┌───────────────────┐  ┌────────────────────────┐   │
    │  │ FSDP v1/v2        │  │ torch.distributed      │   │
    │  │ (FULL_SHARD,      │  │ (init_process_group,    │   │
    │  │  SHARD_GRAD_OP)   │  │  all-reduce/gather/    │   │
    │  │ Wrapping Policy   │  │  reduce-scatter/bcast, │   │
    │  │ MixedPrecision    │  │  send/recv, barrier)   │   │
    │  │ DCP 检查点         │  │ Device Mesh            │   │
    │  └───────────────────┘  └────────────────────────┘   │
    └──────────────────────────┬───────────────────────────┘
                               │
              ┌────────────────┼───────────────────┐
              ▼                ▼                   ▼
    ┌───────────────┐  ┌──────────────┐  ┌─────────────────┐
    │ DeepSpeed     │  │ Megatron-LM  │  │ Pipeline        │
    │ ZeRO-3 (对比) │  │ TP (DTensor) │  │ Parallelism     │
    └───────────────┘  └──────────────┘  └─────────────────┘
              │                │                   │
              └────────────────┼───────────────────┘
                               ▼
    ┌──────────────────────────────────────────────────────────┐
    │  2D/3D 并行 (FSDP2 × TP via DeviceMesh × PP)            │
    │  TorchTitan (Meta) / FSDP + DTensor 组合                 │
    │  例如: 8 GPU = (dp=4, tp=2) 2D Mesh                     │
    └──────────────────────────────────────────────────────────┘
```

FSDP 与 torch.distributed 互为表里：FSDP 是高层 API（自动管理参数分片和通信），torch.distributed 是底层通信库（提供所有集合通信原语）。在 PyTorch 2.0+ 生态中，FSDP2 与 DTensor/Device Mesh 原生集成，使得 FSDP + TP 的 2D 并行可以在一个 unified mesh 上声明式配置。与 DeepSpeed 相比，FSDP 更轻量（纯 PyTorch 无额外依赖），DeepSpeed 更成熟（offload 选项丰富，久经大规模考验）。两者 API 风格不同，但底层通信模式（All-Gather + Reduce-Scatter）完全一致。

---

## 14. 深入学习资源

### 14.1 官方文档与教程

```
PyTorch FSDP 官方文档:
  1. FSDP API 参考:
     https://pytorch.org/docs/stable/fsdp.html

  2. FSDP 入门教程:
     https://pytorch.org/tutorials/intermediate/FSDP_tutorial.html

  3. FSDP 高级教程:
     https://pytorch.org/tutorials/intermediate/FSDP_adavnced_tutorial.html

  4. Getting Started with Fully Sharded Data Parallel (FSDP):
     https://pytorch.org/blog/introducing-pytorch-fully-sharded-data-parallel-api/

  5. FSDP v2 (DTensor-based):
     https://pytorch.org/docs/stable/distributed.fsdp.html

  6. torch.distributed 文档:
     https://pytorch.org/docs/stable/distributed.html

  7. Device Mesh 文档:
     https://pytorch.org/docs/stable/distributed.tensor.parallel.html

  8. PyTorch Distributed Checkpoint:
     https://pytorch.org/docs/stable/distributed.checkpoint.html
```

### 14.2 论文与博文

```
必读论文:
  1. "ZeRO: Memory Optimizations Toward Training Trillion Parameter Models"
     (理解 FSDP 背后的理论基础)

  2. "PyTorch FSDP: Experiences on Scaling Fully Sharded Data Parallel"
     (Meta 分享的大规模 FSDP 实践经验)
     https://arxiv.org/abs/2304.11277

  3. "Cozmo: A Practical Framework for Large Model Training with FSDP"
     (FSDP 在大模型训练中的实践)

推荐博客:
  1. HuggingFace FSDP 指南:
     https://huggingface.co/docs/transformers/fsdp

  2. PyTorch 官方博客:
     - "Introducing PyTorch Fully Sharded Data Parallel (FSDP) API"
     - "Scaling PyTorch models on Cloud TPUs with FSDP"

  3. Meta AI 博客:
     - "Training large models with FSDP"

  4. Lightning AI 博客:
     - "FSDP vs DeepSpeed: A Comprehensive Comparison"
```

### 14.3 代码仓库与示例

```
1. PyTorch FSDP 示例:
   https://github.com/pytorch/examples/tree/main/distributed/FSDP

2. HuggingFace Transformers + FSDP 示例:
   https://github.com/huggingface/transformers/tree/main/examples/pytorch/language-modeling
   (run_clm.py 支持 FSDP)

3. TorchTitan (Meta 的大模型训练框架, 使用 FSDP2):
   https://github.com/pytorch/torchtitan

4. Lit-GPT (使用 FSDP):
   https://github.com/Lightning-AI/lit-gpt

5. Megatron-LM (TP/PP 参考):
   https://github.com/NVIDIA/Megatron-LM

6. PyTorch DTensor 示例:
   https://github.com/pytorch/pytorch/tree/main/test/distributed/tensor/parallel
```

### 14.4 调试与性能分析

```
调试工具:
  1. torch.cuda.memory_summary() → 显存使用详细报告
  2. TORCH_DISTRIBUTED_DEBUG=DETAIL → 分布式调试模式
  3. TORCH_CPP_LOG_LEVEL=INFO TORCH_DISTRIBUTED_DEBUG=DETAIL → 详细日志
  4. torch.distributed.barrier() → 同步点调试

性能分析:
  1. PyTorch Profiler + TensorBoard
  2. NVIDIA Nsight Systems (nsys) → 系统级时间线
  3. NVIDIA Nsight Compute (ncu) → CUDA kernel 级别分析
  4. torch.cuda.Event → 精确计时

常见问题排查:
  - FSDP 下显存还是太高:
    → 检查 wrapping policy (是否每层独立 FSDP)
    → 检查 reshard_after_forward (是否设为 True)
    → 检查 activation checkpointing (是否只包装了需要的层)
    → 减少 bucket 大小或 batch size

  - FSDP 训练速度慢:
    → 检查是否存在通信瓶颈 (用 profiler 看 all-gather 耗时)
    → 确保 forward_prefetch=True
    → 调整 bucket size (更大的 bucket → 更少的通信次数)
    → 检查 GPU 利用率 (nvidia-smi dmon)
    → 考虑使用 FSDP v2 (per-parameter sharding, 更好的通信调度)

  - 梯度/参数出现 NaN:
    → 检查混合精度配置 (reduce_dtype 应为 FP32)
    → 检查 loss scaling (FP16 训练时需要)
    → 降低学习率
```

### 14.5 学习路线图

```
══════════════════════════════════════════════════════════════════════
                    FSDP 与分布式训练学习路线
══════════════════════════════════════════════════════════════════════

第 1 阶段: 分布式基础 (1 周)
  □ 理解 DDP 的工作原理和 all-reduce 通信
  □ 用 torch.distributed 手写一个简单的分布式训练脚本
  □ 熟悉 torchrun 的使用
  □ 掌握 NCCL 和 GLOO 后端的区别

第 2 阶段: FSDP 入门 (1-2 周)
  □ 阅读 FSDP 官方教程并复现示例
  □ 理解 FSDP 的三个 wrapping policy
  □ 在 2-4 GPU 上用 FSDP 微调一个 1-7B 模型
  □ 对比 DDP vs FSDP 的显存和速度

第 3 阶段: FSDP 进阶 (2-3 周)
  □ 理解 FSDP 的 forward/backward hook 机制
  □ 调优 mixed precision、prefetch、bucket size
  □ 尝试 CPU offload 和 activation checkpointing
  □ 使用 PyTorch Profiler 分析通信-计算重叠
  □ 实现 DCP 检查点保存与恢复

第 4 阶段: 多维并行 (3-4 周)
  □ 学习 DTensor 和 Device Mesh
  □ 实现 TP (张量并行) 与 FSDP 的组合 (2D 并行)
  □ 对比 FSDP2 (per-parameter) 与 FSDP1
  □ 在 8+ GPU 上训练 13B+ 模型
  □ 配置多机训练并解决跨节点通信问题

第 5 阶段: 大规模实战 (持续)
  □ 使用 TorchTitan 进行大规模训练
  □ 阅读 FSDP 源码理解实现细节
  □ 跟随 PyTorch 社区的 RFC 了解 FSDP 的未来方向
  □ 针对特定模型/硬件优化 FSDP 配置
  □ 贡献 FSDP 相关的 bug 修复或功能完善
══════════════════════════════════════════════════════════════════════
```

---

> **结语**: FSDP 是 PyTorch 原生的分布式训练核心组件，它与 torch.distributed 的集合通信、torchrun 的启动机制、Device Mesh 的多维并行编排共同构成了 PyTorch 的大规模训练生态系统。DeepSpeed 提供了更丰富的配置选项和更广泛的硬件支持，FSDP 则提供了更深度集成的 PyTorch 原生体验。两者不是对立的，而是可以互补的工具。
