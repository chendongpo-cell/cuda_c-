# 流水线并行（Pipeline Parallelism）深度解析

## 目录

1. [流水线并行的核心思想](#1-流水线并行的核心思想)
2. [Bubble 问题深度分析](#2-bubble-问题深度分析)
3. [调度策略全面对比](#3-调度策略全面对比)
4. [GPipe：前向全部→后向全部](#4-gpipe前向全部后向全部)
5. [1F1B (PipeDream)：交错前向与后向](#5-1f1b-pipedream交错前向与后向)
6. [Interleaved 1F1B：多重阶段调度](#6-interleaved-1f1b多重阶段调度)
7. [内存分析：激活值存储策略](#7-内存分析激活值存储策略)
8. [通信模式与带宽分析](#8-通信模式与带宽分析)
9. [PP vs TP 全面对比](#9-pp-vs-tp-全面对比)
10. [混合并行：DP x TP x PP](#10-混合并行dp--tp--pp)
11. [时序图与调度可视化](#11-时序图与调度可视化)
12. [实际代码实现](#12-实际代码实现)
13. [深入学习资源](#13-深入学习资源)

---

## 1. 流水线并行的核心思想

### 1.1 问题起源

当模型太大，即使使用了 ZeRO-3 或 FSDP（全分片数据并行），单 GPU 仍然无法容纳时，我们需要将模型**按层切分**到不同的 GPU 上。这就是流水线并行的用武之地。

```
为什么需要流水线并行:
══════════════════════════════════════════════════════════════════════

  场景: 训练一个 175B 参数的模型

  ZeRO-3 (8 GPU, 80GB A100 单卡):
    每 GPU 模型状态 = 16 x 175B / 8 = 350 GB  x (2/16) ~ 43.75 GB
    加上激活值 ~20 GB -> 总计 ~64 GB -> 勉强可以!
    
    但如果是 530B 参数呢?
    每 GPU 模型状态 = 16 x 530B / 8 ~ 132.5 GB -> 远超 80GB -> OOM!

  ZeRO-3 (64 GPU):
    每 GPU 模型状态 = 16 x 530B / 64 ~ 16.6 GB -> 可以!
    但 64 个 GPU 做全局 all-gather: 通信开销极大!
    (64 个 GPU 的 ring all-gather 需要更多步数)

  PP 的解决方案:
  ─────────────────────────────────────────────────────────────────
    将模型的 100 层 Transformer 切分成 4 组，每组放在 1 个 GPU 上:
    
    ┌─────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │  GPU 0  │    │  GPU 1   │    │  GPU 2   │    │  GPU 3   │
    │         │    │          │    │          │    │          │
    │ L00-L24 │───>│ L25-L49  │───>│ L50-L74  │───>│ L75-L99  │
    │         │    │          │    │          │    │          │
    └─────────┘    └──────────┘    └──────────┘    └──────────┘
       Stage 0        Stage 1        Stage 2        Stage 3

    每 GPU 只存储 25 层参数 -> 内存需求降为 1/4!
    与 DP 组合: 每组 GPU 内部做 DP (ZeRO)，组间做 PP。
```

### 1.2 PP 的通信模式

```
PP 的通信与 TP/DP 的根本区别:
══════════════════════════════════════════════════════════════════════

  TP (张量并行):
  ─────────────────────────────────────────────────────────────────
    ┌──────┐ ┌──────┐
    │ GPU0 │<->│ GPU1 │  <- all-reduce 每层多次
    └──────┘ └──────┘
    通信模式: 集合通信 (collective)，所有 GPU 参与
    通信粒度: 每层、每步都需要
    
  DP (数据并行):
  ─────────────────────────────────────────────────────────────────
    ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
    │ GPU0 │<->│ GPU1 │<->│ GPU2 │<->│ GPU3 │  <- all-reduce 梯度
    └──────┘ └──────┘ └──────┘ └──────┘
    通信模式: 集合通信 (collective)，所有 GPU 参与
    通信粒度: 每步一次

  PP (流水线并行):
  ─────────────────────────────────────────────────────────────────
    ┌──────┐     ┌──────┐     ┌──────┐     ┌──────┐
    │ GPU0 │────>│ GPU1 │────>│ GPU2 │────>│ GPU3 │
    └──────┘     └──────┘     └──────┘     └──────┘
            send        send        send
            <────────── <────────── <──────────
            recv        recv        recv
        
    通信模式: 点对点 (P2P, send/recv)，仅相邻 GPU 通信
    通信粒度: 每层边界、每 microbatch 一次
    通信量: 远小于 TP (无需全局 all-reduce)
```

---

## 2. Bubble 问题深度分析

### 2.1 什么是 Bubble

Bubble（气泡）是流水线并行中 GPU 空闲等待的时间。这是 PP 性能损失的根本原因。

```
Bubble 的直观理解:
══════════════════════════════════════════════════════════════════════

  想象一条流水线，每个工人负责一个工序:

  工人 0 -> 工人 1 -> 工人 2 -> 工人 3

  如果没有流水（1 个产品）:
  ─────────────────────────────────────────────────────────────────
  
  时间 ->
  工人0: [==工序 0==] [..........等待..........] [..........等待..........] [..........等待..........]
  工人1: [....等待....] [==工序 1==] [..........等待..........] [..........等待..........]
  工人2: [....等待....] [....等待....] [==工序 2==] [..........等待..........]
  工人3: [....等待....] [....等待....] [....等待....] [==工序 3==]
         │            │            │            │            │
         └──工人0 做完了，但工人1才开始，工人0只能等着──┘
                      │            │            │
                      └──工人1 做完了，工人2才开始──┘
     
  Bubble 占比 = 3/4 = 75%!  (PP_size - 1) / PP_size

  没有微批次时:
    Total bubble = sum_{i=1}^{PP-1} (PP - i) x T_stage = (PPx(PP-1)/2) x T_stage
    有效工作时间 = PP x T_stage  (每个 GPU 只工作了 1 个 stage)
    
    Bubble 比例 = Bubble / Total_time
                = (PP-1) / (2xPP)  [如果考虑总时间 = PP x PP x T_stage]
    当 PP=4: (4-1)/(2x4) = 3/8 = 37.5%
```

### 2.2 微批次如何减少 Bubble

```
引入微批次 (Micro-Batches):
══════════════════════════════════════════════════════════════════════

  把一个大的 mini-batch 切成 M 个小的 micro-batch:
  
  Mini-batch = [MB0, MB1, MB2, MB3]  (M=4 个微批次)
  
  ┌─────────────────────────────────────────────────────────────────┐
  │                   GPipe 调度 (4 微批次, 4 阶段)                  │
  │                                                                  │
  │  时间 ->                                                        │
  │                                                                  │
  │  GPU0: [F0][F1][F2][F3]                 [B0][B1][B2][B3]        │
  │  GPU1:     [F0][F1][F2][F3]             [B0][B1][B2][B3]        │
  │  GPU2:         [F0][F1][F2][F3]         [B0][B1][B2][B3]        │
  │  GPU3:             [F0][F1][F2][F3]     [B0][B1][B2][B3]        │
  │                                                                  │
  │  总时间:                                                        │
  │    前向: (M + PP - 1) x T_forward                                │
  │    后向: (M + PP - 1) x T_backward                               │
  │                                                                  │
  │  Bubble 时间:                                                    │
  │    前向: (PP - 1) x T_forward (预热阶段的泡沫)                    │
  │    后向: (PP - 1) x T_backward (冷却阶段的泡沫)                   │
  │                                                                  │
  │  有效工作: M x PP x T                                             │
  │  总时间: (M + PP - 1) x PP x T                                    │
  │  Bubble 比例 = (PP-1) / (M + PP - 1)                             │
  │                                                                  │
  │  M=1   -> (PP-1)/PP        -> 极大                              │
  │  M=4   -> 3/(4+3) = 3/7    -> 42.8%                             │
  │  M=32  -> 3/(32+3) = 3/35  -> 8.6%                              │
  │  M=128 -> 3/131            -> 2.3%                              │
  │  M->infinity -> 0%  <- 微批次越多，bubble 越少                   │
  │                                                                  │
  └─────────────────────────────────────────────────────────────────┘

Bubble 公式总结:
══════════════════════════════════════════════════════════════════════

  GPipe / Naive:
    Bubble = (PP_size - 1) / (num_microbatches + PP_size - 1)

  1F1B (PipeDream):
    Bubble = (PP_size - 1) / (num_microbatches + PP_size - 1)
    (与 GPipe 相同的 bubble 比例，但内存更低!)

  Interleaved 1F1B (VPP):
    Bubble = (PP_size - 1) / (num_microbatches x V + PP_size - 1)
    其中 V 是每个 GPU 的虚拟阶段数
    V=2 时 bubble 约减半!

══════════════════════════════════════════════════════════════════════
```

### 2.3 Bubble 计算的具体例子

```
不同规模下的 Bubble 占比:
══════════════════════════════════════════════════════════════════════

  设 PP_size = 4

  ┌──────────────┬──────────────────┬──────────────────┐
  │  微批次 M     │  Bubble 时间      │  Bubble 占比      │
  ├──────────────┼──────────────────┼──────────────────┤
  │       1      │    3T            │    75.0%         │
  │       2      │    3T            │    60.0%         │
  │       4      │    3T            │    42.9%         │
  │       8      │    3T            │    27.3%         │
  │      16      │    3T            │    15.8%         │
  │      32      │    3T            │     8.6%         │
  │      64      │    3T            │     4.5%         │
  │     128      │    3T            │     2.3%         │
  │     256      │    3T            │     1.2%         │
  └──────────────┴──────────────────┴──────────────────┘

  关键洞察:
  ─────────────────────────────────────────────────────────────────
  1. Bubble 的时间是固定的 (PP-1) 段等待时间
  2. 增加微批次 M 增加了总有用工作 -> 降低了 bubble 占比
  3. 但 M 不能无限增加:
     - 每个微批次的 batch size 不能太小 (否则 GPU 利用率低)
     - 激活值存储 ∝ M (GPipe 下)
     - M x micro_batch = global_batch -> M 受 global_batch 约束
  4. 实际选择: M >= 4 x PP_size 是一个好的经验值
```

---

## 3. 调度策略全面对比

### 3.1 四种调度策略一览

```
══════════════════════════════════════════════════════════════════════
              四种流水线调度策略对比总览
══════════════════════════════════════════════════════════════════════

┌──────────────┬────────────────┬──────────────┬──────────────────┐
│   策略        │   调度方式      │  激活值内存   │   Bubble         │
├──────────────┼────────────────┼──────────────┼──────────────────┤
│ 1. Naive     │ 逐完整批处理    │ 最低          │ 最大             │
│    (无微批次) │ F->B->F->B->..│ O(1)         │ (PP-1)/PP        │
├──────────────┼────────────────┼──────────────┼──────────────────┤
│ 2. GPipe     │ 先全部F,后全部B │ 最高          │ 中等             │
│              │                │ O(M x PP)    │ (PP-1)/(M+PP-1)  │
├──────────────┼────────────────┼──────────────┼──────────────────┤
│ 3. 1F1B      │ 交错F和B       │ 中等          │ 中等             │
│  (PipeDream) │ 1F->1B->...   │ O(PP)        │ (PP-1)/(M+PP-1)  │
├──────────────┼────────────────┼──────────────┼──────────────────┤
│ 4. Interleaved│ 交错 + 多阶段 │ 中等-高       │ 最小             │
│  1F1B (VPP)  │ 每GPU多阶段    │ O(PPxV)      │ (PP-1)/(MxV+...) │
└──────────────┴────────────────┴──────────────┴──────────────────┘
```

---

## 4. GPipe：前向全部->后向全部

### 4.1 调度模式

```
GPipe 调度详细时序图:
══════════════════════════════════════════════════════════════════════

  配置: PP_size=2, M=3 微批次
  
  时间 -> (每个 F/B 方块代表一个微批次的前向/后向计算)

  GPU0: ┌────┐┌────┐┌────┐                     ┌────┐┌────┐┌────┐
        │F_M0││F_M1││F_M2│                     │B_M0││B_M1││B_M2│
        └────┘└──┬─┘└──┬─┘                     └──┬─┘└──┬─┘└────┘
                 │     │    send activations       │     │
  ───────────────┼─────┼──────────────────────────┼─────┼─────────
                 │     │                          │     │
  GPU1:     ┌────┼──┐┌─┼───┐┌────┐          ┌────┼──┐┌─┼───┐┌────┐
            │F_M0│  ││F_M1 ││F_M2│          │B_M0│  ││B_M1││B_M2│
            └────┘  └└────┘└────┘          └────┘  └└────┘└────┘
             recv activations               recv gradients

  Bubble 区域 (GPU 空闲):
  ─────────────────────────────────────────────────────────────────
  GPU0 bubble: 前向结束后到后向开始前 (等待 GPU1 完成所有前向)
  GPU1 bubble: 前向开始前 (等待 GPU0 发送第一个微批次)

  总时间: (M + PP - 1) x T_fw + (M + PP - 1) x T_bw
         = (3 + 2 - 1) x T_fw + (3 + 2 - 1) x T_bw
         = 4T_fw + 4T_bw

  Bubble 占比:
    (PP-1) / (M + PP - 1)
    = 1 / 4 = 25%
```

### 4.2 GPipe 的激活值内存爆炸

```
GPipe 的最大缺陷: 激活值存储
══════════════════════════════════════════════════════════════════════

  在 GPipe 中，先做完所有微批次的前向传播，再做后向传播。
  这意味着前向过程中的所有激活值都必须存储，直到后向需要它们。

  ┌─────────────────────────────────────────────────────────────────┐
  │  GPU0 的激活值存储情况 (PP_size=2, M=4)                         │
  │                                                                  │
  │  时间: F0 -> F1 -> F2 -> F3 -> B0 -> B1 -> B2 -> B3            │
  │                                                                  │
  │  激活值缓冲区:                                                    │
  │    ┌────┐┌────┐┌────┐┌────┐                                    │
  │    │A_F0││A_F1││A_F2││A_F3│   <- 4 个微批次的激活值全部在显存中   │
  │    └────┘└────┘└────┘└────┘                                    │
  │                                                                  │
  │  激活值总量: M x activation_size_per_microbatch                   │
  │                                                                  │
  │  例如: 4096 hidden, 2048 seq_len, batch=1                        │
  │    每层激活值 ~ 2 x seq_len x hidden x num_layers / dtype_bytes   │
  │    ~ 2 x 2048 x 4096 x 25 layers x 2 bytes (FP16)               │
  │    ~ 800 MB per microbatch per GPU                               │
  │                                                                  │
  │  M=32  -> 32 x 800 MB = 25.6 GB 激活值存储 (仅 GPU0!)            │
  │  M=128 -> 128 x 800 MB = 102.4 GB -> OOM!                       │
  └─────────────────────────────────────────────────────────────────┘

  GPipe 的激活值内存 ∝ M (微批次数量)
  虽然 M 越大 bubble 越小，但 M 越大内存越大 -> 矛盾!
```

### 4.3 GPipe 代码示例

```python
"""
GPipe 风格的流水线并行伪代码
"""
import torch
import torch.distributed as dist

def gpipe_forward_backward(stage_module, microbatches, pp_rank, pp_size):
    """
    GPipe 调度: 前向全部微批次 -> 后向全部微批次

    Args:
        stage_module: 当前 GPU 负责的模型阶段
        microbatches: 微批次列表 [mb_0, mb_1, ..., mb_{M-1}]
        pp_rank: 当前 GPU 在流水线中的 rank (0 到 pp_size-1)
        pp_size: 流水线中的 GPU 总数
    """
    M = len(microbatches)

    # ═══════════════════════════════════════════════════════════
    # 阶段 1: 所有微批次的前向传播
    # ═══════════════════════════════════════════════════════════

    all_activations = []  # 存储所有微批次的激活值 (GPipe 的主要内存开销)
    all_inputs = []       # 存储所有微批次的输入 (用于后向)

    for m in range(M):
        mb = microbatches[m]

        # 如果不是第一个阶段，从上一个 GPU 接收激活值
        if pp_rank > 0:
            input_data = recv_forward(pp_rank - 1)
        else:
            input_data = mb

        # 前向计算
        with torch.enable_grad():
            output = stage_module(input_data)

        # 存储激活值 (用于后向)
        all_activations.append(output)
        all_inputs.append(input_data)

        # 如果不是最后一个阶段，发送激活值到下一个 GPU
        if pp_rank < pp_size - 1:
            send_forward(output, pp_rank + 1)

    # ═══════════════════════════════════════════════════════════
    # 阶段 2: 所有微批次的后向传播 (从最后一个微批次开始)
    # ═══════════════════════════════════════════════════════════

    for m in reversed(range(M)):
        # 重新获得该微批次的计算图引用
        output = all_activations[m]

        # 如果不是最后一个阶段，从下一个 GPU 接收梯度
        if pp_rank < pp_size - 1:
            grad_output = recv_backward(pp_rank + 1)
        else:
            # 最后一个阶段: 计算 loss
            loss = compute_loss(output)
            loss.backward()
            # grad_output 在 autograd 内部就处理好了
            continue

        # 后向计算
        output.backward(grad_output)

        # 如果不是第一个阶段，发送梯度到上一个 GPU
        if pp_rank > 0:
            grad_input = all_inputs[m].grad
            send_backward(grad_input, pp_rank - 1)

        # 释放该微批次的激活值
        del all_activations[m]
        del all_inputs[m]


# ═══════════════════════════════════════════════════════════════
# P2P 通信辅助函数
# ═══════════════════════════════════════════════════════════════

def send_forward(tensor, dst_rank):
    """发送前向激活值"""
    dist.send(tensor, dst=dst_rank)

def recv_forward(src_rank):
    """接收前向激活值"""
    # 先接收 shape，再接收数据
    shape = torch.zeros(3, dtype=torch.int64).cuda()
    dist.recv(shape, src=src_rank)
    tensor = torch.zeros(tuple(shape.tolist()),
                         dtype=torch.float16).cuda()
    dist.recv(tensor, src=src_rank)
    return tensor

def send_backward(tensor, dst_rank):
    """发送后向梯度"""
    dist.send(tensor, dst=dst_rank)

def recv_backward(src_rank):
    """接收后向梯度"""
    shape = torch.zeros(3, dtype=torch.int64).cuda()
    dist.recv(shape, src=src_rank)
    tensor = torch.zeros(tuple(shape.tolist()),
                         dtype=torch.float16).cuda()
    dist.recv(tensor, src=src_rank)
    return tensor

def compute_loss(output):
    """计算损失"""
    return output.mean()
```

---

## 5. 1F1B (PipeDream)：交错前向与后向

### 5.1 调度模式

```
1F1B (One-Forward-One-Backward) 调度:
══════════════════════════════════════════════════════════════════════

  与 GPipe 不同，1F1B 在前向传播过程中穿插后向传播，
  从而减少激活值存储。

  配置: PP_size=4, M=8 微批次
  
  时间 ->
  ═══════════════════════════════════════════════════════════════════

  GPU0: F0 F1 F2 F3 F4 B0 B1 B2 B3 B4 F5 F6 F7 B5 B6 B7
  GPU1:    F0 F1 F2 F3 F4 B0 B1 B2 B3 B4 F5 F6 F7 B5 B6 B7
  GPU2:       F0 F1 F2 F3 F4 B0 B1 B2 B3 B4 F5 F6 F7 B5 B6 B7
  GPU3:          F0 F1 F2 F3 F4 B0 B1 B2 B3 B4 F5 F6 F7 B5 B6 B7
                │                ││                │
                └── 预热阶段 ────┘└── 稳定阶段 ────┘
                 (Warmup)         (Steady State)

  详细解释 (GPU0 的视角):
  ─────────────────────────────────────────────────────────────────

  预热阶段 (Warmup Phase):
  ┌─────────────────────────────────────────────────────────────┐
  │  GPU0 做 PP_size - 1 = 3 次前向 (F0, F1, F2)，填充流水线   │
  │  实际上做 PP_size 次前向来完成预热                           │
  └─────────────────────────────────────────────────────────────┘

  稳定阶段 (Steady State):
  ┌─────────────────────────────────────────────────────────────┐
  │  1F1B: 每个时段 = 1 次前向 + 1 次后向                      │
  │                                                             │
  │  规则:                                                      │
  │    - 已做的前向次数 < 已做的后向次数 + PP_size              │
  │      且还有前向没做 -> 做一次前向                          │
  │    - 否则 -> 做一次后向                                    │
  │                                                             │
  │  当所有前向都做完:                                          │
  │    -> 只做后向，直到所有后向完成 (Cooldown Phase)          │
  └─────────────────────────────────────────────────────────────┘


  为什么 1F1B 能减少内存?
  ─────────────────────────────────────────────────────────────────

  GPipe:   F0 F1 F2 F3                     B0 B1 B2 B3
           存储 A0+A1+A2+A3 <- 4 个激活值

  1F1B:    F0 F1 F2 F3 F4 B0 B1 B2 B3 B4 ...
           此时存储的激活值:
            在做 F4 时: A0, A1, A2, A3, A4 (5 个)
            做完 B0 后: A1, A2, A3, A4 (4 个, 释放了 A0)
            做完 B1 后: A3, A4 (更少，取决于 F 进度)
            
  实际上是: 在稳定阶段，同时存在的激活值 ~ PP_size
            (因为流水线中有 PP 个微批次在飞行)
            
  对比 GPipe: 同时存在的激活值 = M (所有微批次)
            当 M >> PP 时，1F1B 的节省是巨大的!
```

### 5.2 1F1B 内存分析

```
1F1B 稳定阶段的内存占用:
══════════════════════════════════════════════════════════════════════

  设 PP_size = P，M = 微批次总数

  在稳定阶段，流水线中的"飞行中"微批次数量 ~ P
  (每个 GPU 处理 1 个微批次的前向或后向)

  GPU0 同时持有的激活值:
  ─────────────────────────────────────────────────────────────────
    
    时间段: GPU0 正在做微批次 j 的后向
    此时 GPU0 已经完成了微批次 j 的前向，正在做 j 的后向
    GPU1 正在做微批次 j-1 的后向 (或前向)
    ...依次类推

    激活值存储数量:
    ┌─────────────────────────────────────────────────────────────┐
    │  i_th stage (GPU i), 在做微批次 k 的后向:                   │
    │                                                              │
    │  需要存储的激活值:                                           │
    │    - 微批次 k, k+1, ..., k+P-1-i 的激活值                   │
    │      (这些微批次的前向已做，后向还没做)                      │
    │                                                              │
    │  最坏情况下 (GPU0 在预热结束时):                             │
    │    存储 P 个微批次的激活值                                   │
    │                                                              │
    │  稳定阶段:                                                   │
    │    大约存储 (in_flight_microbatches) 个激活值                │
    │    ~ O(P) 而非 GPipe 的 O(M)                                │
    └─────────────────────────────────────────────────────────────┘

    当 M=128, P=4:
      GPipe: 128 个激活值
      1F1B: ~4 个激活值
      节省: 32x!
```

### 5.3 1F1B 代码示例

```python
"""
1F1B (PipeDream) 调度实现
"""
import torch
import torch.distributed as dist
from collections import deque

def pipe_dream_1f1b(stage_module, microbatches, pp_rank, pp_size):
    """
    1F1B 流水线调度

    调度逻辑:
      - 预热阶段: 做 PP_size 次前向
      - 稳定阶段: 交替 1F 1B
      - 冷却阶段: 做 PP_size 次后向
    """
    M = len(microbatches)
    P = pp_size

    # ─── 状态追踪 ───
    num_fw_done = 0       # 已完成的前向次数
    num_bw_done = 0       # 已完成的后向次数

    # ─── 激活值存储 ───
    # Key: microbatch_id, Value: activations
    # 1F1B 的典型内存: O(P) 个微批次同时存储
    activation_buffers = {}

    def do_forward(mb_id):
        """执行一个微批次的前向传播"""
        nonlocal num_fw_done

        mb = microbatches[mb_id]

        # 接收输入
        if pp_rank > 0:
            input_data = recv_tensor(pp_rank - 1)
        else:
            input_data = mb

        # 前向计算
        output = stage_module(input_data)

        # 存储激活值 (保存计算图用于 autograd)
        activation_buffers[mb_id] = output

        # 发送输出
        if pp_rank < P - 1:
            dist.send(output.detach(), dst=pp_rank + 1)

        num_fw_done += 1

    def do_backward(mb_id):
        """执行一个微批次的后向传播"""
        nonlocal num_bw_done

        output = activation_buffers.pop(mb_id)

        # 接收梯度
        if pp_rank < P - 1:
            grad_output = recv_tensor(pp_rank + 1)
            output.backward(grad_output)
        else:
            # 最后一个阶段: 计算 loss
            loss = output.mean()
            loss.backward()

        # 获取输入梯度并发送
        if pp_rank > 0:
            # 假设 stage_module.input 保存了输入引用
            grad_input = stage_module.get_input_gradient()
            dist.send(grad_input, dst=pp_rank - 1)

        num_bw_done += 1

    # ═══════════════════════════════════════════════════════════
    # 主调度循环
    # ═══════════════════════════════════════════════════════════

    next_fw_id = 0    # 下一个要做前向的微批次 ID
    next_bw_id = 0    # 下一个要做后向的微批次 ID

    while num_bw_done < M:
        # 决策: 做前向还是后向?
        do_fw = (
            num_fw_done < M
            and num_fw_done - num_bw_done < P
        )

        if do_fw:
            do_forward(next_fw_id)
            next_fw_id += 1
        else:
            if next_bw_id in activation_buffers:
                do_backward(next_bw_id)
                next_bw_id += 1


def recv_tensor(src_rank):
    """接收张量"""
    shape = torch.zeros(3, dtype=torch.int64).cuda()
    dist.recv(shape, src=src_rank)
    tensor = torch.zeros(tuple(shape.tolist()),
                         dtype=torch.float16).cuda()
    dist.recv(tensor, src=src_rank)
    return tensor
```

---

## 6. Interleaved 1F1B：多重阶段调度

### 6.1 核心概念

```
Interleaved 1F1B (VPP - Virtual Pipeline Parallelism):
══════════════════════════════════════════════════════════════════════

  每个物理 GPU 负责多个"虚拟阶段"(Virtual Stages)，
  进一步减少 bubble。

  标准 PP (PP_size=4):
  ─────────────────────────────────────────────────────────────────
    
    GPU0: [L0-L24]        <- 1 个阶段，25 层
    GPU1: [L25-L49]
    GPU2: [L50-L74]
    GPU3: [L75-L99]

  Interleaved PP (PP_size=4, V=2 虚拟阶段):
  ─────────────────────────────────────────────────────────────────
    
    模型被切成 P x V = 4 x 2 = 8 个阶段:
    
    GPU0: [L0-L12]   [L52-L64]    <- 2 个虚拟阶段，1 个物理 GPU
           Stage 0    Stage 4
    
    GPU1: [L13-L25]  [L65-L77]
           Stage 1    Stage 5
    
    GPU2: [L26-L38]  [L78-L90]
           Stage 2    Stage 6
    
    GPU3: [L39-L51]  [L91-L99]
           Stage 3    Stage 7

  ┌─────────────────────────────────────────────────────────────────┐
  │  为什么 Interleaved 能减少 Bubble?                              │
  │                                                                  │
  │  每个 GPU 有 2 个虚拟阶段，意味着每个 GPU 可以:                  │
  │    1. 在处理 Stage 0 的前向时，在适当时候切换到 Stage 4          │
  │    2. 微批次在流水线中的"分辨率"翻倍 (细粒度)                    │
  │                                                                  │
  │  公式: Bubble = (PP-1) / (M x V + PP - 1)                       │
  │         V=2 时 bubble ~ 减半                                    │
  │                                                                  │
  │  代价:                                                          │
  │    1. 通信量翻倍 (更多 send/recv 因为阶段边界更多)              │
  │    2. GPU 上的调度更复杂                                        │
  │    3. 微批次必须在不同虚拟阶段之间切换 -> context switch 开销   │
  └─────────────────────────────────────────────────────────────────┘
```

### 6.2 Interleaved 调度时序

```
Interleaved 1F1B 时序 (PP=4, V=2, M=8):
══════════════════════════════════════════════════════════════════════

  微批次编号: 0,1,2,3,4,5,6,7
  虚拟阶段: Stage0(v0), Stage1(v1), Stage2(v2), Stage3(v3),
           Stage4(v4), Stage5(v5), Stage6(v6), Stage7(v7)

  调度规则:
  ─────────────────────────────────────────────────────────────────
  每个微批次穿过所有 8 个虚拟阶段。
  但每个 GPU 处理 2 个虚拟阶段。
  
  例如: 微批次 0
    GPU0(Stage0) -> GPU1(Stage1) -> GPU2(Stage2) -> GPU3(Stage3)
    -> GPU0(Stage4) -> GPU1(Stage5) -> GPU2(Stage6) -> GPU3(Stage7)

  时间线 (详细):
  ═══════════════════════════════════════════════════════════════════

  时间 ->
  GPU0(v0): F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5      B6 B7
  GPU1(v1):    F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5    B6 B7
  GPU2(v2):       F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5    B6 B7
  GPU3(v3):          F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5    B6 B7
  ──────────────────────────────────────────────────────────────────
  GPU0(v4):             F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5    B6 B7
  GPU1(v5):                F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5  B6 B7
  GPU2(v6):                   F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5
  GPU3(v7):                      F0 F1 F2 B0 F3 B1 F4 B2 F5 B3 F6 B4 F7 B5
  
  注意: v0 和 v4 在同一个物理 GPU (GPU0) 上! 它们在时间上是交错的。

  Bubble 分析:
  ─────────────────────────────────────────────────────────────────

  有效虚拟阶段数: P' = P x V = 8
  Bubble = (P' - 1) / (M + P' - 1) = 7 / (8 + 7) = 7/15 ~ 46.7%

  对比标准 1F1B (P=8, V=1): bubble 相同，但需要 8 个 GPU!
  Interleaved 用 4 个 GPU 达到了 8 个 GPU 的效果
  (代价: 每个 GPU 的双倍负载和双倍通信)
```

### 6.3 Interleaved 1F1B 代码框架

```python
"""
Interleaved 1F1B (VPP) 调度框架
"""
import torch
import torch.distributed as dist

class InterleavedPipelineEngine:
    """Interleaved 流水线并行引擎"""

    def __init__(self, stages, pp_rank, pp_size, num_virtual_stages=2):
        """
        Args:
            stages: List[List[nn.Module]], 每个虚拟阶段的模型列表
            pp_rank: 当前 GPU 的流水线 rank
            pp_size: 流水线中的 GPU 数量
            num_virtual_stages: 每个 GPU 的虚拟阶段数
        """
        self.stages = stages  # len(stages) = num_virtual_stages
        self.pp_rank = pp_rank
        self.pp_size = pp_size
        self.V = num_virtual_stages

        # 总虚拟阶段数
        self.total_virtual_stages = pp_size * num_virtual_stages

        # 为每个虚拟阶段维护独立的状态
        self.fw_counters = [0] * self.V
        self.bw_counters = [0] * self.V
        self.activation_buffers = [{} for _ in range(self.V)]

    def get_global_virtual_rank(self, local_virtual_idx):
        """
        获取虚拟阶段在全局流水线中的 rank
        例如 GPU0(pp_rank=0), V=2:
          local=0 -> global=0
          local=1 -> global=4
        """
        return self.pp_rank + local_virtual_idx * self.pp_size

    def schedule_next_operation(self, virtual_stage_idx):
        """决定虚拟阶段下一步做什么"""
        global_vrank = self.get_global_virtual_rank(virtual_stage_idx)
        fw_done = self.fw_counters[virtual_stage_idx]
        bw_done = self.bw_counters[virtual_stage_idx]

        warmup_depth = global_vrank

        if fw_done < self.M and fw_done - bw_done < warmup_depth + 1:
            return ("forward", fw_done)
        elif bw_done < fw_done:
            return ("backward", bw_done)
        else:
            return ("wait", None)

    def run(self, microbatches):
        """执行 Interleaved 流水线调度"""
        self.M = len(microbatches)

        all_done = False
        while not all_done:
            all_done = True

            for v_idx in range(self.V):
                op, mb_id = self.schedule_next_operation(v_idx)

                if op == "wait":
                    continue

                all_done = False

                if op == "forward":
                    self.execute_forward(v_idx, mb_id)
                    self.fw_counters[v_idx] += 1
                elif op == "backward":
                    self.execute_backward(v_idx, mb_id)
                    self.bw_counters[v_idx] += 1

    def execute_forward(self, v_idx, mb_id):
        """执行虚拟阶段的前向传播"""
        stage_model = self.stages[v_idx]

        global_vrank = self.get_global_virtual_rank(v_idx)
        if global_vrank > 0:
            input_data = self.recv_fw(global_vrank - 1)
        else:
            input_data = self.microbatches[mb_id]

        output = stage_model(input_data)
        self.activation_buffers[v_idx][mb_id] = output

        if global_vrank < self.total_virtual_stages - 1:
            self.send_fw(output.detach(), global_vrank + 1)

    def execute_backward(self, v_idx, mb_id):
        """执行虚拟阶段的后向传播"""
        output = self.activation_buffers[v_idx].pop(mb_id)

        global_vrank = self.get_global_virtual_rank(v_idx)

        if global_vrank < self.total_virtual_stages - 1:
            grad_output = self.recv_bw(global_vrank + 1)
            output.backward(grad_output)
        else:
            loss = output.mean()
            loss.backward()

        if global_vrank > 0:
            grad_input = self.get_input_gradient(v_idx)
            self.send_bw(grad_input, global_vrank - 1)

    def send_fw(self, tensor, dst_global_vrank):
        dst_physical_rank = dst_global_vrank % self.pp_size
        dist.send(tensor, dst=dst_physical_rank)

    def recv_fw(self, src_global_vrank):
        src_physical_rank = src_global_vrank % self.pp_size
        # ... recv logic ...

    def send_bw(self, tensor, dst_global_vrank):
        dst_physical_rank = dst_global_vrank % self.pp_size
        dist.send(tensor, dst=dst_physical_rank)

    def recv_bw(self, src_global_vrank):
        src_physical_rank = src_global_vrank % self.pp_size
        # ... recv logic ...
```

---

## 7. 内存分析：激活值存储策略

### 7.1 各调度策略的内存对比

```
激活值存储对比:
══════════════════════════════════════════════════════════════════════

  ┌─────────────────────────────────────────────────────────────────┐
  │                    激活值内存使用                                │
  │                                                                  │
  │  Naive (无微批次):                                              │
  │  ────────────────────────────────────────────────────────────  │
  │    F0 -> B0 -> F1 -> B1 -> ...                                 │
  │    每个 GPU 只存储 1 个微批次的激活值                            │
  │    内存 = 1 x A_microbatch                                       │
  │                                                                  │
  │  GPipe:                                                         │
  │  ────────────────────────────────────────────────────────────  │
  │    F0 F1 F2 ... F_{M-1} -> B0 B1 B2 ... B_{M-1}                │
  │    每个 GPU 存储所有 M 个微批次的激活值                          │
  │    内存 = M x A_microbatch                                       │
  │                                                                  │
  │  1F1B (PipeDream):                                              │
  │  ────────────────────────────────────────────────────────────  │
  │    F0 F1 ... B0 F_{PP} B1 F_{PP+1} B2 ...                       │
  │    在稳定阶段，飞行中的微批次 ~ PP_size                          │
  │    内存 ~ (PP_size + 1) x A_microbatch                           │
  │    = O(PP) x A_microbatch                                        │
  │                                                                  │
  │  Interleaved 1F1B:                                              │
  │  ────────────────────────────────────────────────────────────  │
  │    飞行中的微批次更多 (因为虚拟阶段翻倍)                         │
  │    内存 ~ O(P x V) x A_microbatch                                │
  │                                                                  │
  └─────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────┐
  │              详细对比 (PP=4, warmup_depth=3)                    │
  ├──────────────┬────────────────────┬──────────────────────────────┤
  │  M=微批次     │  GPipe 激活值      │  1F1B 激活值 (max in flight)│
  ├──────────────┼────────────────────┼──────────────────────────────┤
  │      2       │  2 x A            │  2 x A                      │
  │      4       │  4 x A            │  4 x A                      │
  │      8       │  8 x A            │  4 x A                      │
  │     16       │  16 x A           │  4 x A                      │
  │     32       │  32 x A  (OOM?)   │  4 x A                      │
  │     64       │  64 x A  (OOM!)   │  4 x A                      │
  │    128       │ 128 x A  (OOM!)   │  4 x A                      │
  └──────────────┴────────────────────┴──────────────────────────────┘

  结论: 当 M >> PP 时，1F1B 的内存优势非常显著!
        这使得 1F1B 可以用大量微批次来减少 bubble，而不会 OOM。
```

### 7.2 激活值大小的计算

```
激活值大小精确计算公式:
══════════════════════════════════════════════════════════════════════

  每层的激活值取决于模型架构。

  对于标准 Transformer 层 (如 LLaMA):

  ┌─────────────────────────────────────────────────────────────────┐
  │  需要存储的激活值 (用于后向传播):                                │
  │                                                                  │
  │  1. Attention 层的输入:                                          │
  │     input_hidden_states: [batch, seq_len, hidden]                │
  │     = B x S x H x 2 bytes (FP16)                                │
  │                                                                  │
  │  2. Q, K, V 投影输出:                                            │
  │     Q: [batch, num_heads, seq_len, head_dim]                     │
  │     K: [batch, num_heads, seq_len, head_dim]                     │
  │     V: [batch, num_heads, seq_len, head_dim]                     │
  │     总计: 3 x B x S x H x 2 bytes                                │
  │                                                                  │
  │  3. Softmax 前的注意力分数 (可选，取决于实现):                   │
  │     [batch, num_heads, seq_len, seq_len]                         │
  │     = B x nH x S^2 x 2 bytes                                    │
  │     <- 这是大头! 当 S=2048 时: S^2=4M 远大于 S=2048            │
  │     <- FlashAttention 不需要存储这个!                             │
  │                                                                  │
  │  4. MLP 层的输入:                                                │
  │     [batch, seq_len, hidden]                                     │
  │     = B x S x H x 2 bytes                                       │
  │                                                                  │
  │  5. MLP 中间激活值 (gate + up projection 后):                    │
  │     [batch, seq_len, intermediate] x 2                          │
  │     = B x S x (2 x I) x 2 bytes                                  │
  │     I ~ 4H (LLaMA 的 intermediate size)                          │
  │     = B x S x 8H x 2 bytes                                      │
  └─────────────────────────────────────────────────────────────────┘

  实际数值示例 (LLaMA 7B, 1 microbatch):
  ─────────────────────────────────────────────────────────────────

  B=1, S=2048, H=4096, I=11008, PP=4, 25 layers per GPU

  每层激活值 (有 FlashAttention):
    1. input: 16 MB
    2. Q,K,V: 48 MB
    4. MLP input: 16 MB
    5. MLP intermediate: 88 MB
    + LayerNorm stats: ~1 MB
    总计: ~169 MB per layer

  25 层 per GPU: 25 x 169 MB = 4.2 GB per microbatch

  GPipe (M=32): 32 x 4.2 GB = 134 GB -> OOM!
  1F1B (M=32, PP=4): ~4 x 4.2 GB = 16.8 GB -> 可行!

  使用 FlashAttention + 1F1B 可以大幅降低激活值存储!
```

### 7.3 激活重新计算 (Activation Recomputation)

```
Activation Recomputation (Activation Checkpointing) 结合 PP:
══════════════════════════════════════════════════════════════════════

  ┌─────────────────────────────────────────────────────────────────┐
  │  Full Activation (无检查点):                                    │
  │    Forward:  [计算 + 全部存储]                                   │
  │    Backward: [直接使用存储的激活值]                               │
  │    显存: 高 (全部激活值)                                         │
  │    计算: 1x Forward + 1x Backward                               │
  │                                                                  │
  │  Selective Checkpointing (每 N 层 1 个检查点):                   │
  │    显存: 中 (仅存储检查点 + 重新计算的中间激活值)                │
  │    计算: 1x Forward + 1x Backward + 重新计算 N-1 层的 Forward    │
  │                                                                  │
  │  Full Checkpointing (每层 1 个检查点):                           │
  │    显存: 最低 (仅存储每层的输入)                                  │
  │    计算: 1x Forward + 1x Backward + 重新计算 1x Forward          │
  │          = 约 2x 计算量                                         │
  └─────────────────────────────────────────────────────────────────┘

  在 PP 中使用 Selective Checkpointing:
  ─────────────────────────────────────────────────────────────────
    结合 1F1B + Selective Checkpointing:
      1. 预热阶段正常存储激活值
      2. 稳定阶段，每 N 层只保留 1 个检查点
      3. 后向时从最近的检查点重新计算
    
    这可以将 1F1B 的 O(PP) x A_layer 进一步减少:
      O(PP) x A_layer_per_checkpoint << O(PP) x A_layer
```

---

## 8. 通信模式与带宽分析

### 8.1 PP 通信量详细计算

```
PP 通信量分析:
══════════════════════════════════════════════════════════════════════

  每个阶段边界，每个微批次需要的通信:

  ┌─────────────────────────────────────────────────────────────────┐
  │  Forward: 前向激活值 (hidden states)                            │
  │  数据大小: batch_size x seq_length x hidden_dim x dtype_bytes    │
  │  例如: B=1, S=2048, H=4096, FP16 -> 16 MB/boundary/microbatch  │
  │                                                                  │
  │  Backward: 梯度 (与 forward 大小相同)                            │
  │  数据大小: 相同 -> 16 MB                                        │
  └─────────────────────────────────────────────────────────────────┘

  每个阶段边界，每个微批次:
    总通信 = 前向 16 MB + 后向 16 MB = 32 MB

  对于整个流水线:
    有 PP_size - 1 个边界
    总通信 = (PP-1) x M x 2 x B x S x H x dtype_bytes

  例如: PP=4, M=32, B=1, S=2048, H=4096, FP16
    总通信 = 3 x 32 x 32 MB = 3072 MB = 3 GB total
    每 GPU = 0.75 GB (均匀分布)


  对比 TP 的通信量:
  ─────────────────────────────────────────────────────────────────
    TP 每个 Transformer 层需要:
      每层: 4 次 all-reduce x 2 x B x S x H x dtype_bytes
      对于 100 层模型, TP=2:
        100 x 8 x (2-1)/2 x 16 MB = 6400 MB = 6.4 GB per GPU!
    
    PP 的通信量远少于 TP (因为 PP 只在边界通信，TP 每层都通信)。
    但 PP 有 bubble 问题。
```

### 8.2 通信带宽需求

```
不同网络拓扑下的 PP 通信分析:
══════════════════════════════════════════════════════════════════════

  ┌─────────────────────────────────────────────────────────────────┐
  │  场景 1: 单节点 8xA100 (NVLink 600 GB/s)                      │
  │                                                                  │
  │  通信时间: 16 MB / 600 GB/s ~ 0.027 ms                          │
  │  前向计算: ~0.1-0.5 ms per layer                                │
  │  结论: NVLink 下 PP 通信几乎忽略不计                             │
  ├─────────────────────────────────────────────────────────────────┤
  │  场景 2: InfiniBand HDR 200 Gb/s (~25 GB/s)                    │
  │                                                                  │
  │  通信时间: 16 MB / 25 GB/s ~ 0.64 ms                            │
  │  M=32: 32 x 0.64 = 20.5 ms per step                             │
  │  可能成为瓶颈 (取决于计算时间)                                   │
  ├─────────────────────────────────────────────────────────────────┤
  │  场景 3: RoCE 100 Gb/s (~12.5 GB/s)                            │
  │                                                                  │
  │  通信时间: 16 MB / 12.5 GB/s ~ 1.28 ms                          │
  │  M=32: 32 x 1.28 = 41 ms -> 严重的通信瓶颈!                     │
  │  不推荐 PP 跨 RoCE 节点                                         │
  └─────────────────────────────────────────────────────────────────┘

  通信-计算比:
  ═══════════════════════════════════════════════════════════════════

  C = 通信时间 / 计算时间 (per microbatch per stage)

  理想: C << 1 (通信可被计算隐藏)
  可接受: C < 0.5
  瓶颈: C > 0.5

  影响因素:
    1. B x S 越大 -> 通信和计算都线性增 -> C 基本不变
    2. H 越大 -> 通信线性增，计算平方增 -> C 反比于 H
    3. 带宽越高 -> C 越小
```

---

## 9. PP vs TP 全面对比

### 9.1 详细对比表

```
┌──────────────────────────────────────────────────────────────────────────┐
│                  Pipeline Parallelism vs Tensor Parallelism               │
├───────────────────────────┬────────────────────┬──────────────────────────┤
│         维度               │  Pipeline Parallel  │   Tensor Parallel       │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 切分维度                   │  按层切分 (纵向)     │ 按参数/激活切分 (横向)    │
│                           │  层 0-49 -> GPU0     │ 矩阵按行/列切分到 GPU   │
│                           │  层 50-99 -> GPU1    │                         │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 通信类型                   │  点对点 (P2P)       │ 集合通信 (Collective)    │
│                           │  send/recv          │  all-reduce             │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 通信频率                   │  每阶段边界          │ 每层                   │
│                           │  (PP-1) 次/步       │  2-4 次/层              │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 通信量 per step            │  O(BxSxHxPP)       │  O(BxSxHxL)            │
│                           │  与层数 L 无关!      │  与层数 L 成正比!        │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ GPU 利用率                 │  有 bubble          │ 无 bubble               │
│                           │  (PP-1)/(M+PP-1)    │  100% 利用率             │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 延迟敏感性                 │  不敏感             │ 敏感                   │
│                           │  (可容忍较高延迟)    │  (需要低延迟)            │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 带宽需求                   │  中等               │ 极高                   │
│                           │  P2P 数据小         │  all-reduce 需高带宽     │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 跨节点适用性               │  较好               │ 差                     │
│                           │  P2P 对延迟容忍高   │  all-reduce 需低延迟    │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 最佳规模                   │  2-8 个阶段          │ 2-4 个 GPU              │
│  (受通信效率和 bubble 限制)│                    │ (受 all-reduce 效率限制) │
├───────────────────────────┼────────────────────┼──────────────────────────┤
│ 最佳实践                   │  跨节点使用          │ 节点内使用              │
└───────────────────────────┴────────────────────┴──────────────────────────┘
```

### 9.2 选择决策树

```
══════════════════════════════════════════════════════════════════════
              PP vs TP 选择决策
══════════════════════════════════════════════════════════════════════

  节点内 (NVLink)?
    -> 优先 TP (无 bubble, 效率高)
    -> TP size <= 4 时 all-reduce 高效
  
  跨节点 (IB/RoCE)?
    -> 优先 PP (P2P 对延迟不敏感)
    -> TP 跨节点不推荐 (all-reduce 通信开销大)

  常用组合:
    节点内 TP=8, 节点间 PP=8 -> 适合跨节点大模型
    节点内 TP=4, PP=2 -> 适合单/双节点场景
    纯 ZeRO-3 + TP=2 (节点内) -> 适合 13B-30B 模型

  实际经验:
    < 10B 参数: 不需要 PP, ZeRO-3 或 TP 即可
    10B-100B: 可能需要 PP, 取决于 GPU 数量和显存
    > 100B: 几乎必须用 PP (配合 TP 和 DP)
══════════════════════════════════════════════════════════════════════
```

---

## 10. 混合并行：DP x TP x PP

### 10.1 3D 并行架构

```
三维并行 (3D Parallelism) 完整架构:
══════════════════════════════════════════════════════════════════════

  ┌────────────────────────────────────────────────────────────────┐
  │                      3D 并行层次结构                            │
  │                                                                 │
  │   ┌─────────────────────────────────────────────────────────┐  │
  │   │  数据并行 (DP): 复制完整模型到不同数据组                 │  │
  │   │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │  │
  │   │  │ DP Group0│  │ DP Group1│  │ DP Group2│  │ DP Group3│ │  │
  │   │  │ (8 GPUs) │  │ (8 GPUs) │  │ (8 GPUs) │  │ (8 GPUs) │ │  │
  │   │  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │  │
  │   │       │              │              │              │      │  │
  │   │       ▼              ▼              ▼              ▼      │  │
  │   ├─────────────────────────────────────────────────────────┤  │
  │   │  张量并行 (TP) + 流水线并行 (PP): 在每个 DP 组内         │  │
  │   │                                                         │  │
  │   │  ┌─────────────────────────────────────────────────┐    │  │
  │   │  │          PP (4 个阶段)                           │    │  │
  │   │  │  PP Stage 0:  ┌───┬───┐                         │    │  │
  │   │  │  (L0-L24)     │G0 │G1 │  <- TP=2               │    │  │
  │   │  │               └───┴───┘                         │    │  │
  │   │  │                    │ send/recv                     │    │  │
  │   │  │  PP Stage 1:  ┌───┬───┐                         │    │  │
  │   │  │  (L25-L49)    │G2 │G3 │  <- TP=2               │    │  │
  │   │  │               └───┴───┘                         │    │  │
  │   │  │                    │ send/recv                     │    │  │
  │   │  │  PP Stage 2:  ┌───┬───┐                         │    │  │
  │   │  │  (L50-L74)    │G4 │G5 │                         │    │  │
  │   │  │               └───┴───┘                         │    │  │
  │   │  │                    │ send/recv                     │    │  │
  │   │  │  PP Stage 3:  ┌───┬───┐                         │    │  │
  │   │  │  (L75-L99)    │G6 │G7 │                         │    │  │
  │   │  │               └───┴───┘                         │    │  │
  │   │  └─────────────────────────────────────────────────┘    │  │
  │   │  共 8 GPU per DP group: PP=4 x TP=2 = 8 GPUs           │  │
  │   │  总 GPU: DP=4 x 8 = 32 GPUs                             │  │
  │   └─────────────────────────────────────────────────────────┘  │
  └────────────────────────────────────────────────────────────────┘


  GPU 拓扑与映射:
  ─────────────────────────────────────────────────────────────────

  ┌─────────────────────────┐  ┌─────────────────────────┐
  │  Node 0 (NVLink)        │  │  Node 1 (NVLink)        │
  │  ┌────┐ ┌────┐         │  │  ┌────┐ ┌────┐         │
  │  │ G0 │<->│ G1 │         │  │  │ G4 │<->│ G5 │         │
  │  └────┘ └────┘         │  │  └────┘ └────┘         │
  │  ┌────┐ ┌────┐         │  │  ┌────┐ ┌────┐         │
  │  │ G2 │<->│ G3 │         │  │  │ G6 │<->│ G7 │         │
  │  └────┘ └────┘         │  │  └────┘ └────┘         │
  │  TP within node:        │  │  TP within node:        │
  │    G0<->G1 (TP group0)  │  │    G4<->G5 (TP group2)  │
  │    G2<->G3 (TP group1)  │  │    G6<->G7 (TP group3)  │
  │  PP across nodes:       │  │  PP across nodes:       │
  │    G0<->G4 via IB       │  │    via IB <-------------┘
  └─────────────────────────┘  └─────────────────────────┘

  通信组:
    TP groups: [G0,G1], [G2,G3], [G4,G5], [G6,G7]
    PP groups: [G0,G4], [G1,G5], [G2,G6], [G3,G7]
    DP groups: 同位置 GPU 横跨多个 Node
```

### 10.2 3D 并行的计算分配

```
3D 并行的设备分配示例:
══════════════════════════════════════════════════════════════════════

  模型: GPT-3 175B (96 层 Transformer)
  硬件: 128 x A100 80GB
  3D 配置: DP=4 x TP=8 x PP=4

  ┌─────────────────────────────────────────────────────────────────┐
  │                     GPU 分配矩阵                                │
  │                                                                  │
  │         TP dimension (8 GPUs, within node)                      │
  │                                                                  │
  │  PP ↓   ┌────┬────┬────┬────┬────┬────┬────┬────┐              │
  │  (4)    │G0  │G1  │G2  │G3  │G4  │G5  │G6  │G7  │ PP Stage 0  │
  │         │L0- │L0- │L0- │L0- │L0- │L0- │L0- │L0- │ (L0-L23)    │
  │         │L23 │L23 │L23 │L23 │L23 │L23 │L23 │L23 │              │
  │         ├────┼────┼────┼────┼────┼────┼────┼────┤              │
  │         │G8  │G9  │G10│G11│G12│G13│G14│G15│ PP Stage 1  │
  │         │L24-│L24-│L24-│L24-│L24-│L24-│L24-│L24-│ (L24-L47)  │
  │         │L47 │L47 │L47 │L47 │L47 │L47 │L47 │L47 │              │
  │         ├────┼────┼────┼────┼────┼────┼────┼────┤              │
  │         │G16│G17│G18│G19│G20│G21│G22│G23│ PP Stage 2  │
  │         │L48-│L48-│L48-│L48-│L48-│L48-│L48-│L48-│ (L48-L71)  │
  │         │L71 │L71 │L71 │L71 │L71 │L71 │L71 │L71 │              │
  │         ├────┼────┼────┼────┼────┼────┼────┼────┤              │
  │         │G24│G25│G26│G27│G28│G29│G30│G31│ PP Stage 3  │
  │         │L72-│L72-│L72-│L72-│L72-│L72-│L72-│L72-│ (L72-L95)  │
  │         │L95 │L95 │L95 │L95 │L95 │L95 │L95 │L95 │              │
  │         └────┴────┴────┴────┴────┴────┴────┴────┘              │
  │                                                                  │
  │  这 32 个 GPU 组成 1 个 DP Group                                │
  │  DP=4: 共 4 个这样的 DP Group -> 128 GPUs 总计                   │
  └─────────────────────────────────────────────────────────────────┘

  每 GPU 的内存分配:
  ─────────────────────────────────────────────────────────────────
    175B 参数, PP=4, TP=8:
    每 stage: 175B / 4 = 43.75B 参数 (24 层)
    每 GPU (TP=8): 43.75B / 8 = 5.47B 参数

    FP16 参数: 5.47B x 2 bytes = 10.9 GB
    加上 ZeRO-1 (DP=4): 优化器 ~ 16.4 GB
    激活值 ~ 15 GB
    
    总计 per GPU: ~ 42 GB -> 80GB A100 完全可行!
```

### 10.3 真实案例：大模型训练的 3D 配置

```
══════════════════════════════════════════════════════════════════════
              实际大型模型训练的 3D 并行配置
══════════════════════════════════════════════════════════════════════

1. GPT-3 175B (OpenAI):
  配置: DP=64 x TP=1 x PP=1 (早期, 未使用 3D)
  GPUs: ~10,000 V100

2. OPT-175B (Meta):
  配置: DP=..., 使用 FSDP
  GPUs: 992 x A100 80GB

3. BLOOM-176B (BigScience):
  配置: DP=12 x TP=4 x PP=12
  GPUs: 384 x A100 80GB

4. LLaMA 65B (Meta):
  配置: FSDP + activation checkpointing
  GPUs: 2048 x A100 80GB

5. Megatron-Turing NLG 530B (NVIDIA+Microsoft):
  配置: DP=280 x TP=8 x PP=35
  GPUs: ~2240 x A100 80GB

  常见配置模式:
  ┌─────────────────────┬──────────┬──────────┬──────────────────┐
  │ 模型规模             │   TP     │   PP     │  节点拓扑         │
  ├─────────────────────┼──────────┼──────────┼──────────────────┤
  │  7B-13B (单节点)    │  1-2     │  1       │  1 节点 x 8 GPU  │
  │  7B-13B (多节点)    │  1       │  1       │  N 节点, ZeRO-3  │
  ├─────────────────────┼──────────┼──────────┼──────────────────┤
  │  30B-65B (多节点)   │  2-4     │  1-2     │  2-4 节点 x 8 GPU │
  ├─────────────────────┼──────────┼──────────┼──────────────────┤
  │  175B-530B          │  4-8     │  4-8     │  8+ 节点          │
  └─────────────────────┴──────────┴──────────┴──────────────────┘
══════════════════════════════════════════════════════════════════════
```

---

## 11. 时序图与调度可视化

### 11.1 完整 Gantt 图对比

```
══════════════════════════════════════════════════════════════════════
                    四种调度策略的 Gantt 图对比
                    配置: PP_size=4, M=8
══════════════════════════════════════════════════════════════════════

1. Naive (M=1):
───────────────────────────────────────────────────────────────────

  GPU0: |FFFF|                                                    |BBBB|
  GPU1:      |FFFF|                                          |BBBB|
  GPU2:           |FFFF|                                |BBBB|
  GPU3:                |FFFF|                      |BBBB|
        Bubble ~ 75%

2. GPipe (M=8):
───────────────────────────────────────────────────────────────────

  GPU0: |F0|F1|F2|F3|F4|F5|F6|F7|                    |B7|B6|B5|B4|B3|B2|B1|B0|
  GPU1:    |F0|F1|F2|F3|F4|F5|F6|F7|              |B7|B6|B5|B4|B3|B2|B1|B0|
  GPU2:       |F0|F1|F2|F3|F4|F5|F6|F7|        |B7|B6|B5|B4|B3|B2|B1|B0|
  GPU3:          |F0|F1|F2|F3|F4|F5|F6|F7|  |B7|B6|B5|B4|B3|B2|B1|B0|
        <- 预热 -><-------- 稳定期 (全部GPU满载) -----------><-冷却->
        Bubble = (4-1)/(8+3) ~ 27.3%

3. 1F1B (M=8):
───────────────────────────────────────────────────────────────────

  GPU0: |F0|F1|F2|F3|B0|F4|B1|F5|B2|F6|B3|F7|B4|B5|B6|B7|
  GPU1:    |F0|F1|F2|F3|B0|F4|B1|F5|B2|F6|B3|F7|B4|B5|B6|B7|
  GPU2:       |F0|F1|F2|F3|B0|F4|B1|F5|B2|F6|B3|F7|B4|B5|B6|B7|
  GPU3:          |F0|F1|F2|F3|B0|F4|B1|F5|B2|F6|B3|F7|B4|B5|B6|B7|
        <-预热-><------------- 1F1B 稳定阶段 ----------------><-冷却->
        Bubble 与 GPipe 相同，但激活值存储大幅减少!

4. Interleaved 1F1B (V=2, M=8):
───────────────────────────────────────────────────────────────────

  物理 GPU0 (v0+v4):
    v0:|F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|
    v4:   |F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|

  物理 GPU1 (v1+v5):
    v1:   |F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|
    v5:      |F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|

  物理 GPU2 (v2+v6):
    v2:      |F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|
    v6:         |F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|

  物理 GPU3 (v3+v7):
    v3:         |F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|
    v7:            |F0|F1|B0|F2|B1|F3|B2|F4|B3|F5|B4|F6|B5|F7|B6|B7|

        更快填满流水线! 但每个 GPU 的负载翻倍 (2 个虚拟阶段)
        每个 GPU 的通信也翻倍 (更多的 send/recv)
```

---

## 12. 实际代码实现

### 12.1 Megatron-LM 风格的 PP 实现

```python
"""
Megatron-LM 风格的流水线并行实现 (简化版)

参考: https://github.com/NVIDIA/Megatron-LM
"""
import torch
import torch.nn as nn
import torch.distributed as dist
from typing import List


class PipelineModule(nn.Module):
    """流水线并行模块"""

    def __init__(self, layers: List[nn.Module], pp_rank: int, pp_size: int):
        super().__init__()
        self.layers = nn.ModuleList(layers)
        self.pp_rank = pp_rank
        self.pp_size = pp_size
        self.input_tensor = None
        self.output_tensor = None

    def set_input_tensor(self, input_tensor):
        """设置输入张量"""
        self.input_tensor = input_tensor

    def forward(self):
        """执行该 stage 的前向传播"""
        assert self.input_tensor is not None
        x = self.input_tensor
        for layer in self.layers:
            x = layer(x)
        self.output_tensor = x
        return x


class PipelineEngine:
    """流水线调度引擎 (支持 1F1B 和 Interleaved 1F1B)"""

    def __init__(self, pipeline_module: PipelineModule,
                 pp_rank: int, pp_size: int,
                 schedule: str = "1f1b"):
        self.module = pipeline_module
        self.pp_rank = pp_rank
        self.pp_size = pp_size
        self.schedule = schedule
        self.activations = {}

    def train_step_1f1b(self, microbatches: List[torch.Tensor]):
        """使用 1F1B 调度执行一次训练步骤"""
        M = len(microbatches)
        P = self.pp_size

        num_fw = 0    # 已完成的前向次数
        num_bw = 0    # 已完成的后向次数
        fw_mb_idx = 0
        bw_mb_idx = 0

        total_loss = 0.0

        while num_bw < M:
            if num_fw < M and (num_fw - num_bw) < P:
                # 前向传播
                mb = microbatches[fw_mb_idx]

                if self.pp_rank > 0:
                    input_data = self.recv_forward_from(self.pp_rank - 1, mb.shape)
                else:
                    input_data = mb

                self.module.set_input_tensor(input_data)
                output = self.module.forward()
                self.activations[fw_mb_idx] = output

                if self.pp_rank < P - 1:
                    self.send_forward_to(self.pp_rank + 1, output.detach())

                num_fw += 1
                fw_mb_idx += 1
            else:
                # 后向传播
                output = self.activations.pop(bw_mb_idx)

                if self.pp_rank < P - 1:
                    grad_output = self.recv_backward_from(
                        self.pp_rank + 1, output.shape
                    )
                    output.backward(grad_output)
                else:
                    loss = output.mean()
                    total_loss += loss.item()
                    loss.backward()

                if self.pp_rank > 0:
                    grad_input = self.module.input_tensor.grad
                    self.send_backward_to(self.pp_rank - 1, grad_input)

                num_bw += 1
                bw_mb_idx += 1

        return total_loss / M

    def send_forward_to(self, dst_rank, tensor):
        dist.send(tensor, dst=dst_rank)

    def recv_forward_from(self, src_rank, shape):
        tensor = torch.empty(shape, dtype=torch.float16, device="cuda")
        dist.recv(tensor, src=src_rank)
        return tensor

    def send_backward_to(self, dst_rank, tensor):
        dist.send(tensor, dst=dst_rank)

    def recv_backward_from(self, src_rank, shape):
        tensor = torch.empty(shape, dtype=torch.float16, device="cuda")
        dist.recv(tensor, src=src_rank)
        return tensor
```

### 12.2 PyTorch 2.4+ Pipeline API

```python
"""
PyTorch 2.4+ 的新 Pipeline API (torch.distributed.pipelining)

参考: https://pytorch.org/docs/stable/distributed.pipelining.html
"""
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.distributed.pipelining import (
    pipeline,
    ScheduleGPipe,
    Schedule1F1B,
    ScheduleInterleaved1F1B,
    SplitPoint,
)


def create_pipeline_with_new_api(model, pp_size, schedule_type="1f1b"):
    """使用 PyTorch 2.4+ 的新 Pipeline API"""

    num_layers = len(model.layers)
    layers_per_stage = num_layers // pp_size

    split_spec = {}
    for i in range(1, pp_size):
        split_spec[f"layers.{i * layers_per_stage}"] = SplitPoint.END

    pipe = pipeline(
        module=model,
        num_stages=pp_size,
        split_spec=split_spec,
    )

    if schedule_type == "gpipe":
        schedule = ScheduleGPipe(pipe, num_microbatches=8)
    elif schedule_type == "1f1b":
        schedule = Schedule1F1B(pipe, num_microbatches=8)
    elif schedule_type == "interleaved":
        schedule = ScheduleInterleaved1F1B(
            pipe, num_microbatches=8, num_model_chunks=2
        )
    else:
        raise ValueError(f"Unknown schedule: {schedule_type}")

    return pipe, schedule


def train_with_pipeline():
    """使用新 Pipeline API 的训练循环"""

    pipe, schedule = create_pipeline_with_new_api(
        model, pp_size=4, schedule_type="1f1b"
    )

    pp_rank = dist.get_rank()
    stage_module = pipe.get_stage_module(pp_rank)

    for epoch in range(10):
        for batch in dataloader:
            microbatches = batch.chunk(8)  # 8 个微批次
            loss = schedule.step(microbatches)
            optimizer.zero_grad()
            optimizer.step()
            print(f"Step loss: {loss.item():.4f}")
```

---

## 14. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| Pipeline Parallelism (PP) | 把模型按层切成多段，每段放一个 GPU，像工厂流水线一样前后传递数据 | Ch.1 |
| Bubble | 流水线中 GPU 等待上游/下游的空闲时间 —— PP 性能损失的根本原因 | Ch.2 |
| Micro-batch | 把一个大 batch 切成 M 个小份，让流水线中的 GPU 都有活干 —— M 越多 Bubble 越小 | Ch.2.2 |
| 1F1B (One-Forward-One-Backward) | 预热完后交替做一次前向和一次后向 —— 相比 GPipe，激活值存储从 O(M) 降到 O(PP) | Ch.5 |
| Interleaved 1F1B (VPP) | 每个物理 GPU 管多个虚拟阶段，微批次交替穿过 —— Bubble 可再减半，代价是通信翻倍 | Ch.6 |
| Activation Recomputation | 反向时重新计算前向的中间激活值，而非全部存储 —— 用 33% 额外计算换大幅显存节省 | Ch.7.3 |

## 15. A800 部署场景举例

**场景 1：单节点 8×A800 为何不推荐 PP**

```
单机 8×A800 80GB, NVSwitch NVLink 600 GB/s:
  PP 在单机内通常不是好选择 —— Bubble 带来的 GPU 空闲远大于收益。
  
  8 GPU 用 TP=8 即可把单层参数量压到 1/8，且无 Bubble（100% GPU 利用）。
  如果 8×A800 TP=8 仍然放不下模型 → 说明模型 > 80B → 需要多节点。

单机的最佳方案:
  7B-13B: ZeRO-2/FSDP (通信最少)
  30B: ZeRO-3/FSDP + activation checkpointing
  65B: ZeRO-3 + CPU offload 或 TP=2 + ZeRO-3

PP 的用武之地: 多节点、超大模型 (>100B)，TP 跨节点通信量太大时
```

**场景 2：4 节点 32×A800 用 TP=8 + PP=4 训练 175B 模型**

```
硬件: 4 节点, 每节点 8×A800 80GB, 节点内 NVSwitch, 节点间 200Gbps IB
策略: TP=8（节点内）+ PP=4（节点间, 1 node per PP stage）

Megatron-LM 配置:
  --tensor-model-parallel-size 8   # 节点内 NVSwitch
  --pipeline-model-parallel-size 4 # 跨节点 IB (P2P 通信)
  --num-layers 96 --hidden-size 12288 --num-attention-heads 96
  --micro-batch-size 1 --global-batch-size 1536
  --bf16 --use-flash-attn

PP=4 下 Bubble 计算 (M=48 microbatches, 1F1B):
  Bubble = (4-1)/(48+4-1) = 3/51 ≈ 5.9%

每 GPU 显存:
  175B / (TP×PP) = 175B/(8×4) ≈ 5.47B 参数 per GPU
  FP16 参数: 10.9 GB, 优化器 (ZeRO-1 DP): ~16.4 GB
  激活值: ~15 GB, 总计 ~42 GB → 80GB 充裕

PP 边界通信 (per microbatch per boundary):
  数据量 = B×S×H × 2 bytes × 2 (send+recv) 
  = 1×2048×12288×2×2 ≈ 100 MB
  IB 200Gbps ≈ 25GB/s → ~4ms per boundary
  M=48 microbatches × 3 边界 = 144 次, 总通信约 576ms
  占一整步的比例约 5-8%，可接受

经验: PP 跨节点时用 1F1B (不用 GPipe)，因为 GPipe 的 O(M) 激活值存储
      在 M=48 时会导致 OOM。1F1B 只存 ~PP=4 个 micro-batch 的激活值。
```

## 16. 上下游串联

```
                     AI Infra 训练栈 — Pipeline Parallelism 的位置
                     
    ┌──────────────────────────────────────────────────────────────┐
    │  分布式训练基础 (DDP, NCCL, torchrun)                        │
    │  提供: send/recv P2P 通信, 多进程管理                        │
    └───────────────────────────┬──────────────────────────────────┘
                                │
    ┌───────────────────────────┼───────────────────────────────┐
    │                           ▼                               │
    │  ┌──────────────┐  ┌──────────────┐  ┌────────────────┐  │
    │  │ DeepSpeed    │  │ Megatron-LM  │  │ ★ 本份文档     │  │
    │  │ ZeRO (DP)   │  │ TP (张量并行) │  │ Pipeline       │  │
    │  │ 内存优化      │  │ 层内矩阵切分  │  │ Parallelism    │  │
    │  │              │  │              │  │ 层间流水线      │  │
    │  └──────┬───────┘  └──────┬───────┘  └───────┬────────┘  │
    │         │                │                  │            │
    └─────────┼────────────────┼──────────────────┼────────────┘
              │                │                  │
              └────────────────┼──────────────────┘
                               │
                               ▼
    ┌──────────────────────────────────────────────────────────────┐
    │  3D 并行: DP × TP × PP (同一训练任务三者同时使用)            │
    │  ┌────────────────────────────────────────────────────────┐ │
    │  │ PP: 层间切分 → 跨节点 P2P (通信量小, 容忍延迟)          │ │
    │  │ TP: 层内切分 → 节点内 all-reduce (NVLink 高带宽)        │ │
    │  │ DP: 数据切分 → 跨 TP/PP 组 gradient all-reduce         │ │
    │  └────────────────────────────────────────────────────────┘ │
    │  典型: 1024 GPU = DP=16 × TP=8 × PP=8                     │
    └──────────────────────────────────────────────────────────────┘
                               │
                               ▼
    ┌──────────────────────────────────────────────────────────────┐
    │  PyTorch 2.4+ torch.distributed.pipelining (原生 PP API)     │
    │  ScheduleGPipe / Schedule1F1B / ScheduleInterleaved1F1B     │
    └──────────────────────────────────────────────────────────────┘
```

Pipeline Parallelism 解决的是「模型层数太多，单 GPU 显存放不下所有层」的问题。它与 TP 的关键区别：TP 在每层内部做 all-reduce（通信量大但无 Bubble），PP 只在层边界做 P2P（通信量小但有 Bubble）。实际工程中 TP 放 NVLink 节点内、PP 跨节点是黄金组合。理解 Bubble 公式 `(PP-1)/(M+PP-1)` 是评估 PP 效率的核心——M 越大越好但受显存（GPipe）或 global batch size 限制，1F1B 打破了显存限制使得 M 可以很大。本份文档是理解 3D 并行中 PP 维度的入门和深入材料。

---

## 13. 深入学习资源

### 13.1 必读论文

```
流水线并行的核心论文:
─────────────────────────────────────────────────────────────────

1. GPipe (Google, 2019):
   "GPipe: Efficient Training of Large Neural Networks
    using Pipeline Parallelism"
   NeurIPS 2019
   https://arxiv.org/abs/1811.06965
   要点: 微批次概念、前向全部-后向全部、激活值重计算

2. PipeDream (Microsoft/Stanford, 2019):
   "PipeDream: Generalized Pipeline Parallelism for DNN Training"
   SOSP 2019
   https://arxiv.org/abs/1806.03377
   要点: 1F1B 调度、weight stashing

3. PipeDream-2BW (Microsoft, 2021):
   "Memory-Efficient Pipeline-Parallel DNN Training"
   ICML 2021
   https://arxiv.org/abs/2006.09503
   要点: Double Buffered Weight Updates、减少内存

4. Megatron-LM v2 (NVIDIA, 2021):
   "Efficient Large-Scale Language Model Training on GPU Clusters
    Using Megatron-LM"
   SC 2021
   https://arxiv.org/abs/2104.04473
   要点: Interleaved 1F1B、3D 并行、PTD-P 技术

5. Chimera (2021):
   "Chimera: Efficiently Training Large-Scale Neural Networks
    with Bidirectional Pipelines"
   SC 2021
   要点: 双向流水线

6. TeraPipe (2021):
   "TeraPipe: Token-Level Pipeline Parallelism for Training
    Large-Scale Language Models"
   ICML 2021
   要点: Token 级别流水线 (比 microbatch 更细粒度)
```

### 13.2 官方文档与代码仓库

```
官方文档:
─────────────────────────────────────────────────────────────────

1. PyTorch Pipeline Parallelism:
   https://pytorch.org/docs/stable/distributed.pipelining.html

2. Megatron-LM:
   https://github.com/NVIDIA/Megatron-LM

3. DeepSpeed Pipeline Parallelism:
   https://www.deepspeed.ai/tutorials/pipeline/

4. FairScale (Meta, 已归档到 PyTorch):
   https://github.com/facebookresearch/fairscale

5. torchgpipe (Kakao Brain):
   https://github.com/kakaobrain/torchgpipe
```

### 13.3 教程与博客

```
推荐阅读:
─────────────────────────────────────────────────────────────────

1. HuggingFace: "Training Large Models: A Deep Dive on GPU Performance"
   https://huggingface.co/blog/large-models-gpu

2. Lilian Weng: "How to Train Really Large Models on Many GPUs?"
   https://lilianweng.github.io/posts/2021-09-25-train-large/

3. PyTorch Tutorial: "Distributed Pipeline Parallelism Using RPC"
   https://pytorch.org/tutorials/intermediate/dist_pipeline_parallel_tutorial.html

4. ColossalAI: "Pipeline Parallelism"
   https://colossalai.org/docs/concepts/paradigms_of_parallelism/
```

### 13.4 调试与性能分析

```
PP 调试清单:
─────────────────────────────────────────────────────────────────

- 确认每个 GPU 收到了正确数量的微批次
- 检查 send/recv 的顺序: 必须严格按微批次顺序
- 确认前向和后向之间没有死锁
- 检查激活值是否正确存储和释放 (避免内存泄漏)
- 验证 bubble 占比是否接近理论值

常见问题:
─────────────────────────────────────────────────────────────────

1. 死锁 (Deadlock):
   症状: 训练一直卡住不动
   原因: send/recv 顺序错误
   解决: 仔细检查 PP rank 的 send/recv 配对，使用异步通信

2. 内存泄漏:
   症状: 显存逐渐增长，最终 OOM
   原因: 激活值没有及时释放
   解决: 在 .pop() 后添加 torch.cuda.empty_cache()

3. Bubble 过大:
   症状: GPU 利用率低
   原因: M 太小
   解决: 增加微批次数量或切换到 1F1B
```

### 13.5 学习路线图

```
══════════════════════════════════════════════════════════════════════
                     流水线并行学习路线
══════════════════════════════════════════════════════════════════════

阶段 1: 理论基础 (1 周)
  - 理解为什么需要 PP: 模型太大，单卡放不下
  - 理解 Bubble 的概念和公式
  - 用纸和笔画出 GPipe 和 1F1B 的 Gantt 图
  - 理解微批次如何减少 bubble 和增加内存

阶段 2: 简单实现 (1-2 周)
  - 用 PyTorch 的 send/recv 实现一个简单的 2-stage PP
  - 实现 GPipe 调度 (在 2 GPU 上验证)
  - 实现 1F1B 调度 (在 2 GPU 上验证)
  - 验证 Bubble 公式的正确性

阶段 3: 进阶实践 (2-3 周)
  - 在 4 GPU 上实现完整的 1F1B 调度
  - 理解 Interleaved 1F1B 的概念
  - 实现与 Activation Checkpointing 的结合
  - 对比 PP 通信和 TP 通信的性能差异

阶段 4: 大规模实战 (3-4 周)
  - 阅读 Megatron-LM 的 PP 实现源码
  - 在 8+ GPU 上配置 3D 并行 (TP+PP+DP)
  - 使用 NCCL 的 P2P 通信替代 dist.send/recv
  - 性能调优: 调优 M, PP size, bucket size

阶段 5: 深入学习 (持续)
  - 阅读全部核心论文
  - 了解最新的 PP 研究 (TeraPipe, Chimera)
  - 研究不同大模型训练的实际配置
  - 尝试为 PyTorch Pipeline API 贡献代码
══════════════════════════════════════════════════════════════════════
```

---

> **结语**: 流水线并行是训练超大规模模型不可或缺的工具。理解 Bubble 的成因和调度策略的权衡，掌握通信模式与 TP 的对比，以及学习如何配置 3D 并行，是成为分布式训练专家的必经之路。GPipe 简单直观，1F1B 内存高效，Interleaved 进一步减少 Bubble -- 每一种策略都有它的用武之地。实际训练中，PP 通常与 TP（节点内）和 DP（跨节点/组内）组合成 3D 并行，以最大化 GPU 利用率和最小化通信开销。
