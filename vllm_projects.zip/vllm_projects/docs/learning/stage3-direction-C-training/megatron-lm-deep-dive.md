# Megatron-LM 深度解析：从数学原理到工程实践

---

## 目录

1. [Megatron-LM 是什么](#1-megatron-lm-是什么)
2. [为什么 NVIDIA 要造 Megatron-LM](#2-为什么-nvidia-要造-megatron-lm)
3. [模型并行分类学](#3-模型并行分类学)
4. [Tensor Parallelism：完整数学分析](#4-tensor-parallelism完整数学分析)
5. [Sequence Parallelism：序列维度拆分](#5-sequence-parallelism序列维度拆分)
6. [Pipeline Parallelism in Megatron](#6-pipeline-parallelism-in-megatron)
7. [3D 并行：DP x TP x PP](#7-3d-并行dp-x-tp-x-pp)
8. [实战案例：GPT-3 175B on 1024 A100](#8-实战案例gpt-3-175b-on-1024-a100)
9. [Megatron-Core 与 Transformer Engine](#9-megatron-core-与-transformer-engine)
10. [代码走读：ColumnParallelLinear 和 RowParallelLinear](#10-代码走读columnparallellinear-和-rowparallellinear)
11. [选型决策：Megatron vs DeepSpeed vs FSDP](#11-选型决策megatron-vs-deepspeed-vs-fsdp)
12. [总结](#12-总结)

---

## 1. Megatron-LM 是什么

### 1.1 一句话定义

**Megatron-LM** 是 NVIDIA 开源的、专为大语言模型（LLM）训练设计的**模型并行框架**。它的核心贡献是提出了高效、通用、可组合的 **Tensor Parallelism（张量并行）** 方法，让单个 Transformer 层的计算可以分布到多个 GPU 上，从而突破单 GPU 显存限制，训练超大模型。

### 1.2 关键里程碑

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Megatron-LM 演化时间线                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  2019.09  Megatron-LM (v1) 论文发布                                          │
│           ├── 提出 Tensor Parallelism for Transformer                       │
│           ├── 在 512 GPU 上训练 83 亿参数 GPT-2                              │
│           └── 核心：Column Parallel + Row Parallel Linear                    │
│                                                                             │
│  2021.04  Megatron-LM v2 (Efficient Large-Scale Language Model Training)     │
│           ├── 将 TP 扩展到新的架构和函数                                     │
│           ├── 提出 Interleaved 1F1B Pipeline Schedule                        │
│           ├── 提出 Sequence Parallelism                                      │
│           └── 在 3072 A100 上训练 1T 参数模型                                │
│                                                                             │
│  2021.10  Megatron-Turing NLG 530B                                           │
│           ├── 微软 + NVIDIA 联合训练                                         │
│           ├── 5300 亿参数，使用 4480 A100                                    │
│           └── 混合精度 + 3D 并行 (DP=70, TP=8, PP=35)                        │
│                                                                             │
│  2022.09  Megatron-Core 发布                                                 │
│           ├── 模块化重构，与 NeMo 框架集成                                   │
│           ├── 支持 Transformer Engine (FP8 训练)                             │
│           └── 更灵活的 API，更易定制                                         │
│                                                                             │
│  2023-24  持续演进                                                           │
│           ├── FP8 训练正式支持                                               │
│           ├── Expert Parallelism for MoE                                     │
│           ├── 更好的融合内核 (fused kernels)                                 │
│           └── 与 NeMo 2.0 深度整合                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.3 Megatron-LM 解决了什么问题

```
问题：一个 175B 参数的 GPT-3 模型有多大？

    ┌─────────────────────────────────────────────────────┐
    │ 每个参数 = 2 bytes (FP16)                           │
    │ 模型参数 = 175B × 2 = 350 GB                        │
    │                                                     │
    │ 梯度 = 350 GB                                       │
    │ 优化器状态 (Adam) = 2 × 350 = 700 GB                │
    │                                                     │
    │ 总需求 ≈ 350 + 350 + 700 = 1400 GB = 1.4 TB         │
    │                                                     │
    │ 单张 A100 (80GB) 显存 = 80 GB                       │
    │ 需要的 GPU 数（仅存储）= 1.4TB / 80GB ≈ 18 张       │
    │                                                     │
    │ 实际上还需要：                                       │
    │   - 激活值存储 (activation memory)                  │
    │   - 临时缓冲区                                       │
    │   - CUDA context 开销                                │
    │                                                     │
    │ 结论：单个 GPU 绝对装不下，必须拆分到多 GPU          │
    └─────────────────────────────────────────────────────┘
```

---

## 2. 为什么 NVIDIA 要造 Megatron-LM

### 2.1 动机

在 Megatron-LM 之前，分布式训练主要有两种方式：

1. **数据并行 (Data Parallelism, DP)**：每个 GPU 持有完整模型副本，处理不同数据。通信量小，但显存不共享。
2. **模型并行 (Model Parallelism, 早期)**：将模型层切开放在不同 GPU 上，但通信效率低，GPU 利用率差。

NVIDIA 的目标是：

```
┌────────────────────────────────────────────────────────────────┐
│                                                                │
│   目标 1: 让小模型训练在几千张 GPU 上高效扩展                   │
│       - 传统的 DP 在几百张卡后通信成为瓶颈                     │
│       - Megatron 的 TP 与 DP 正交，可以组合使用                │
│                                                                │
│   目标 2: 让大模型（百亿、千亿、万亿参数）可以被训练            │
│       - TP 让单层参数分布到多个 GPU                            │
│       - PP 让不同层分布到不同 GPU                              │
│       - 组合使用，突破单 GPU 限制                              │
│                                                                │
│   目标 3: 最小化通信开销                                       │
│       - 在 Transformer 内部做 TP，通信只在层边界               │
│       - 行列并行的巧妙设计让通信量和计算量比值可控             │
│                                                                │
│   目标 4: 推动 NVIDIA GPU 在 AI 训练中的主导地位               │
│       - 充分利用 NVLink 高带宽                                  │
│       - 展示大规模 GPU 集群的能力                              │
│       - 建立工业标准                                           │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

### 2.2 设计哲学

```
Megatron-LM 的核心设计哲学：

    "一个 MLP 和一个 Self-Attention 块中的矩阵乘法
     可以在不影响计算正确性的前提下，自然地分布到多个 GPU 上。"

具体来说：
    - 把矩阵乘法的列/行按 GPU 数切开
    - 在需要时插入 all-reduce / reduce-scatter 通信
    - 通信和计算尽可能地重叠 (overlap)
```

---

## 3. 模型并行分类学

### 3.1 五维并行全景图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                        现代大模型训练的并行策略                                │
│                                                                             │
│   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐                     │
│   │ Data         │   │ Tensor       │   │ Pipeline     │                     │
│   │ Parallelism  │   │ Parallelism  │   │ Parallelism  │                     │
│   │ (DP)         │   │ (TP)         │   │ (PP)         │                     │
│   │              │   │              │   │              │                     │
│   │ 拆分 Batch   │   │ 拆分矩阵乘法 │   │ 拆分模型层   │                     │
│   │ 每卡完整模型 │   │ 每卡部分参数 │   │ 每卡部分层   │                     │
│   │ 同步梯度     │   │ 同步激活值   │   │ 传递激活/梯度│                     │
│   └──────┬───────┘   └──────┬───────┘   └──────┬───────┘                     │
│          │                  │                  │                             │
│   ┌──────┴───────┐   ┌──────┴───────┐   ┌──────┴───────┐                     │
│   │ Sequence     │   │ Expert       │   │ Context      │                     │
│   │ Parallelism  │   │ Parallelism  │   │ Parallelism  │                     │
│   │ (SP)         │   │ (EP)         │   │ (CP)         │                     │
│   │              │   │              │   │              │                     │
│   │ 拆分序列长度 │   │ 拆分 MoE 专家│   │ 拆分上下文   │                     │
│   │ 配合 TP 使用 │   │ 配合 DP 使用 │   │ 长序列场景   │                     │
│   └──────────────┘   └──────────────┘   └──────────────┘                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 各并行策略对比

```
┌──────────────┬──────────────────┬──────────────────┬──────────────────┐
│   并行策略    │   拆分维度        │   通信操作        │   通信量         │
├──────────────┼──────────────────┼──────────────────┼──────────────────┤
│ DP           │ Batch 维度        │ All-reduce 梯度  │ O(模型大小)     │
│ TP           │ 矩阵的列/行       │ All-reduce 激活  │ O(B×S×H×层数)   │
│ PP           │ 模型的层          │ P2P send/recv    │ O(B×S×H)        │
│ SP           │ 序列 T 维度       │ All-gather/      │ O(B×S×H/TP)     │
│              │                   │ Reduce-scatter   │                  │
│ EP           │ MoE 专家          │ All-to-all       │ O(B×S×H×专家数) │
└──────────────┴──────────────────┴──────────────────┴──────────────────┘

关键洞察：
    TP 的通信发生在每层内部，所以通信量和层数成正比
    PP 的通信只在层边界（P2P），通信量和层数无关
    DP 的通信只在反向传播后同步梯度，频率最低但数据量等于模型大小
```

### 3.3 GPU 互联拓扑与并行策略的关系

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     GPU 互联拓扑 → 并行策略映射                               │
│                                                                             │
│   单机 8 GPU (NVSwitch / NVLink Full Mesh):                                  │
│   ┌───┐   ┌───┐   ┌───┐   ┌───┐   ┌───┐   ┌───┐   ┌───┐   ┌───┐           │
│   │ 0 │───│ 1 │───│ 2 │───│ 3 │───│ 4 │───│ 5 │───│ 6 │───│ 7 │           │
│   └───┘   └───┘   └───┘   └───┘   └───┘   └───┘   └───┘   └───┘           │
│   每对之间: 900 GB/s (NVLink 3.0)  或  600 GB/s 双向 (NVSwitch)              │
│   → TP 在节点内非常高效 (TP ≤ 8)                                             │
│                                                                             │
│   多机互联 (InfiniBand / RoCE):                                              │
│   ┌──────────────┐         ┌──────────────┐                                 │
│   │  Node 0      │   IB    │  Node 1      │                                 │
│   │  GPU 0...7   │◄══════►│  GPU 0...7   │                                 │
│   └──────────────┘ 400GB/s└──────────────┘                                 │
│   → DP/PP 跨节点可行，TP 跨节点通信量大，不推荐                              │
│                                                                             │
│   经验法则：                                                                  │
│   ├── TP: 同一节点内 (NVLink 带宽大)                                         │
│   ├── PP: 跨节点也可 (通信量小)                                              │
│   └── DP: 跨节点也可 (频率低，通信量 = 模型大小)                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Tensor Parallelism：完整数学分析

这是 Megatron-LM 最核心的贡献。我们从头推导每一个矩阵运算和通信操作。

### 4.1 前置知识：Transformer 层的计算图

一个标准 Transformer 层包含两个子层：

```
┌────────────────────────────────────────────────────────────────┐
│                    一个 Transformer 层                          │
│                                                                │
│   Input: X ∈ R^(B×S×H)                                        │
│       │                                                        │
│       ▼                                                        │
│   ┌─────────────────────────────────────┐                      │
│   │  Self-Attention 子层                 │                      │
│   │                                     │                      │
│   │  LN → QKV_Projection → Attention    │                      │
│   │     → Output_Projection → Dropout   │                      │
│   └──────────────┬──────────────────────┘                      │
│                  │ + (残差连接)                                 │
│                  ▼                                              │
│   ┌─────────────────────────────────────┐                      │
│   │  MLP 子层                            │                      │
│   │                                     │                      │
│   │  LN → FC1 (h→4h) → GELU →          │                      │
│   │       FC2 (4h→h) → Dropout         │                      │
│   └──────────────┬──────────────────────┘                      │
│                  │ + (残差连接)                                 │
│                  ▼                                              │
│   Output: Y ∈ R^(B×S×H)                                        │
│                                                                │
│   B = Batch size   S = Sequence length   H = Hidden size       │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

### 4.2 Column Parallel Linear（列并行线性层）

#### 4.2.1 数学定义

传统的全连接层:

```
    Y = X × A

    其中:
        X ∈ R^(B×S×H_in)     输入
        A ∈ R^(H_in × H_out)  权重矩阵
        Y ∈ R^(B×S×H_out)     输出
```

**Column Parallel** 意味着将权重矩阵 A 按**列**切成 N 份 (N = TP 度数):

```
    A = [A₁ | A₂ | ... | A_N]

    其中 A_i ∈ R^(H_in × H_out/N)

    每个 GPU i 持有 A_i，都持有完整的 X

    前向计算:
        Y_i = X × A_i  ∈ R^(B×S × H_out/N)

    每个 GPU 得到部分结果 Y_i，需要拼接才能得到完整的 Y:
        Y = [Y₁ | Y₂ | ... | Y_N]
```

#### 4.2.2 前向传播图解

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Column Parallel Linear 前向传播 (TP=4)                     │
│                                                                             │
│   参数分布:                                                                  │
│                                                                             │
│             H_out (完整维度)                                                 │
│   ┌─────────────────────────────────────────┐                               │
│   │      A₁     │     A₂     │     A₃     │     A₄     │                    │
│   │  H_out/4   │  H_out/4  │  H_out/4  │  H_out/4  │  ← 按列切          │
│   └─────────────────────────────────────────┘                               │
│     GPU 0        GPU 1       GPU 2       GPU 3                              │
│                                                                             │
│   前向计算:                                                                  │
│                                                                             │
│   GPU 0: X (完整, B×S×H_in) × A₁ → Y₁ (B×S × H_out/4)                      │
│                          ┌─────────┐                                        │
│   GPU 1: X (完整, B×S×H_in) × A₂ → Y₂ (B×S × H_out/4)   每个 GPU            │
│                          ┌─────────┐                        持有完整的       │
│   GPU 2: X (完整, B×S×H_in) × A₃ → Y₃ (B×S × H_out/4)   X               │
│                          ┌─────────┐                                        │
│   GPU 3: X (完整, B×S×H_in) × A₄ → Y₄ (B×S × H_out/4)                      │
│                                                                             │
│   通信 (如果需要完整 Y):                                                     │
│                   all-gather {Y₁, Y₂, Y₃, Y₄}                               │
│                        ↓                                                    │
│                Y = [Y₁|Y₂|Y₃|Y₄]  (所有 GPU 都有完整 Y)                     │
│                                                                             │
│   关键：如果输入 X 已经是按列切分后的（来自 Row Parallel 的输出），            │
│         则 Column Parallel 的输入 X 不需要先 all-gather！                    │
│         这就是 "省掉一个 all-reduce" 的诀窍。                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 4.2.3 反向传播

```
Column Parallel Linear 的反向传播:

  已知: ∂L/∂Y (从上游传来的梯度)

  GPU i 计算:
    ∂L/∂X_i = ∂L/∂Y_i × A_i^T            ← 对输入的梯度 (部分)
    ∂L/∂A_i = X^T × ∂L/∂Y_i              ← 对权重的梯度

  需要通信的部分:
    all-reduce {∂L/∂X_i} → ∂L/∂X          ← 每个 GPU 需要完整 ∂L/∂X

  (权重的梯度不需要通信，每个 GPU 只更新自己的 A_i)
```

### 4.3 Row Parallel Linear（行并行线性层）

#### 4.3.1 数学定义

**Row Parallel** 意味着将权重矩阵 A 按**行**切成 N 份:

```
    Y = X × A

    A 按行切:
        A = [A₁; A₂; ...; A_N]^T  (真正的拼接是垂直的)

    其中 A_i ∈ R^(H_in/N × H_out)

    输入 X 按列切:
        X = [X₁ | X₂ | ... | X_N], X_i ∈ R^(B×S × H_in/N)

    每个 GPU i 持有 A_i 和 X_i

    前向计算:
        Y_i = X_i × A_i  ∈ R^(B×S × H_out)

    需要通信来得到最终 Y:
        Y = Y₁ + Y₂ + ... + Y_N
          = all-reduce(Y_i)  或者  reduce-scatter(Y_i)
```

#### 4.3.2 前向传播图解

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Row Parallel Linear 前向传播 (TP=4)                      │
│                                                                             │
│   参数分布:                                                                  │
│                                                                             │
│     A₁  ← GPU 0, H_in/4 行 × H_out 列                                      │
│     A₂  ← GPU 1, H_in/4 行 × H_out 列                                      │
│     A₃  ← GPU 2, H_in/4 行 × H_out 列                                      │
│     A₄  ← GPU 3, H_in/4 行 × H_out 列                                      │
│                                                                             │
│    按行切 ← A_i 的 i 在行方向分布                                            │
│                                                                             │
│   前向计算:                                                                  │
│                                                                             │
│   GPU 0: X₁ (B×S×H_in/4) × A₁ → Y₁ (B×S×H_out)                            │
│   GPU 1: X₂ (B×S×H_in/4) × A₂ → Y₂ (B×S×H_out)                            │
│   GPU 2: X₃ (B×S×H_in/4) × A₃ → Y₃ (B×S×H_out)                            │
│   GPU 3: X₄ (B×S×H_in/4) × A₄ → Y₄ (B×S×H_out)                            │
│                                                                             │
│   Y_i 都 ∈ R^(B×S×H_out)，但每个 Y_i 只是部分和                             │
│                                                                             │
│   需要通信:                                                                  │
│                                                                             │
│   Y = Y₁ + Y₂ + Y₃ + Y₄                                                     │
│                                                                             │
│   方案 A: all-reduce SUM                                                    │
│           每个 GPU 都得到完整 Y (B×S×H_out)                                  │
│           通信量 = 2(N-1)/N × B×S×H_out                                     │
│                                                                             │
│   方案 B: reduce-scatter SUM                                                │
│           每个 GPU 得到 Y 的 1/N (又按列切分了)                              │
│           通信量 = (N-1)/N × B×S×H_out  ← 更少！                           │
│           适用于下一层也是 Column Parallel 的情况                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.4 通信量精确计算

#### 4.4.1 All-Reduce 的通信量

```
All-Reduce (Ring-based):

  步骤 1: Reduce-Scatter (N-1 步)
           每步传输 1/N 的数据
           总传输 = (N-1)/N × data_size

  步骤 2: All-Gather (N-1 步)
           每步传输 1/N 的数据
           总传输 = (N-1)/N × data_size

  总通信量 = 2(N-1)/N × data_size

  例如 N=8: 通信量 = 2×7/8 × data_size = 1.75 × data_size
  例如 N=4: 通信量 = 2×3/4 × data_size = 1.50 × data_size
  例如 N=2: 通信量 = 2×1/2 × data_size = 1.00 × data_size
```

#### 4.4.2 Reduce-Scatter 的通信量

```
Reduce-Scatter:

  步骤 1: 逐段 Reduce + Scatter
           总传输 = (N-1)/N × data_size

  例如 N=8: 通信量 = 7/8 × data_size = 0.875 × data_size
  例如 N=4: 通信量 = 3/4 × data_size = 0.750 × data_size
```

#### 4.4.3 All-Gather 的通信量

```
All-Gather:

  步骤 1: 环形传播
           总传输 = (N-1)/N × data_size

  例如 N=8: 通信量 = 7/8 × data_size = 0.875 × data_size
```

### 4.5 Attention 块中的 TP

#### 4.5.1 标准 Attention 的计算流程

```
QKV 投影:
    Q = X × W_Q      W_Q ∈ R^(H × H)
    K = X × W_K      W_K ∈ R^(H × H)
    V = X × W_V      W_V ∈ R^(H × H)

    注意：实际上 QKV 投影通常合并为一个大矩阵:
    [Q, K, V] = X × W_QKV
    W_QKV ∈ R^(H × 3H)
    这样更高效。

Attention 计算:
    A = softmax(Q × K^T / √d_k) × V
    A ∈ R^(B×S×H)

Output 投影:
    O = A × W_O
    W_O ∈ R^(H × H)
```

#### 4.5.2 Attention 的 TP 切分方案

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Attention 块的 Tensor Parallelism (TP=4)                │
│                                                                             │
│   Step 1: QKV Projection — Column Parallel                                  │
│   ┌──────────────────────────────────────────────────────┐                  │
│   │  X ∈ R^(B×S×H)  -- 每个 GPU 都有完整的 X              │                  │
│   │                                                      │                  │
│   │  W_QKV 按列切:                                       │                  │
│   │    GPU i 持有 W_QKV_i ∈ R^(H × 3H/4)                │                  │
│   │                                                      │                  │
│   │  [Q_i, K_i, V_i] = X × W_QKV_i  ∈ R^(B×S × 3H/4)   │                  │
│   │                                                      │                  │
│   │  每个 GPU 有自己的 Q_i, K_i, V_i (各有 H/4 个头)     │                  │
│   └──────────────────────────────────────────────────────┘                  │
│                          │                                                  │
│                          ▼                                                  │
│   Step 2: Self-Attention — 本地计算，无需通信                                │
│   ┌──────────────────────────────────────────────────────┐                  │
│   │  GPU i 计算它拥有的 H/4 个头的 Attention:             │                  │
│   │                                                      │                  │
│   │    A_i = softmax(Q_i × K_i^T / √d_k) × V_i           │                  │
│   │    A_i ∈ R^(B×S × H/4)                               │                  │
│   │                                                      │                  │
│   │  因为 Head 是独立的，Head 切分天然无通信！            │                  │
│   └──────────────────────────────────────────────────────┘                  │
│                          │                                                  │
│                          ▼                                                  │
│   Step 3: Output Projection — Row Parallel                                   │
│   ┌──────────────────────────────────────────────────────┐                  │
│   │  W_O 按行切:                                         │                  │
│   │    GPU i 持有 W_O_i ∈ R^(H/4 × H)                    │                  │
│   │                                                      │                  │
│   │  O_i = A_i × W_O_i  ∈ R^(B×S × H)                   │                  │
│   │                                                      │                  │
│   │  通信: all-reduce(O_i) → 每个 GPU 得到完整的 O       │                  │
│   └──────────────────────────────────────────────────────┘                  │
│                                                                             │
│   Attention 块的通信总计:                                                    │
│     fwd: 0 (ColumnParallel) + 1 all-reduce (RowParallel) = 1 次 all-reduce  │
│     bwd: 1 all-reduce (ColumnParallel的梯度) + 0 (RowParallel) = 1 次        │
│                                                                             │
│     总共 2 次 all-reduce                                                    │
│                                                                             │
│   注意：QKV Projection 是 ColumnParallel，其输入 X 来自上一层 RowParallel  │
│         的输出。因为上一层做了 all-reduce，所以 X 在每个 GPU 上都是完整的。  │
│         这里没有 "省掉 all-reduce" 的优化。                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.6 MLP 块中的 TP

#### 4.6.1 MLP 的 TP 切分方案

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MLP 块的 Tensor Parallelism (TP=4)                     │
│                                                                             │
│   Step 1: FC1 (h → 4h) — Column Parallel                                    │
│   ┌──────────────────────────────────────────────────────┐                  │
│   │  Y₁ = GeLU(X × W₁)                                   │                  │
│   │                                                      │                  │
│   │  W₁ 按列切:                                          │                  │
│   │    GPU i 持有 W₁_i ∈ R^(H × 4H/4 = H × H)            │                  │
│   │                                                      │                  │
│   │  Z_i = X × W₁_i  ∈ R^(B×S × H)                      │                  │
│   │  A_i = GeLU(Z_i)   ∈ R^(B×S × H)   (本地计算)        │                  │
│   │                                                      │                  │
│   │  要点：X 来自 Attention 的 RowParallel 输出，         │                  │
│   │       如果 Attention 做了 all-reduce 则 X 完整        │                  │
│   │       如果通过 reduce-scatter 则 X 已切分             │                  │
│   │       ← 后面讨论 "省一个 all-reduce"                   │                  │
│   └──────────────────────────────────────────────────────┘                  │
│                          │                                                  │
│                          ▼                                                  │
│   Step 2: FC2 (4h → h) — Row Parallel                                       │
│   ┌──────────────────────────────────────────────────────┐                  │
│   │  Y₂ = A × W₂                                         │                  │
│   │                                                      │                  │
│   │  W₂ 按行切:                                          │                  │
│   │    GPU i 持有 W₂_i ∈ R^(H × H)                       │                  │
│   │    (因为 W₂ ∈ R^(4H×H)，H_in=4H，每个 GPU 拿到 4H/4=H 行)│               │
│   │                                                      │                  │
│   │  O_i = A_i × W₂_i  ∈ R^(B×S × H)                    │                  │
│   │                                                      │                  │
│   │  通信: all-reduce(O_i) → 完整 O                       │                  │
│   └──────────────────────────────────────────────────────┘                  │
│                                                                             │
│   MLP 块的通信总计:                                                          │
│     fwd: 0 (ColumnParallel) + 1 all-reduce (RowParallel) = 1 次 all-reduce  │
│     bwd: 1 all-reduce (ColumnParallel的梯度) + 0 (RowParallel) = 1 次        │
│                                                                             │
│     总共 2 次 all-reduce                                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.7 "省掉一个 All-Reduce" 的诀窍

这是 Megatron-LM 最精妙的设计。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    省掉一个 All-Reduce 的核心技巧                              │
│                                                                             │
│   回顾: MLP 的 FC1 是 ColumnParallel，需要在每个 GPU 上有完整的 X            │
│        Attention 的 Output Projection 是 RowParallel，输出需要 all-reduce    │
│                                                                             │
│   常规做法 (2 次 all-reduce):                                                │
│   ─────────────────────────────────────────────                             │
│   Attention O/P (RowParallel):                                              │
│       每个 GPU 都有不完整的结果 O_i                                          │
│       → all-reduce(O_i) → 每个 GPU 都有完整 O                               │
│                                                                             │
│   MLP FC1 (ColumnParallel):                                                 │
│       每个 GPU 已有完整 X (= O + residual)                                  │
│       → X × W₁_i → 不需要通信                                               │
│                                                                             │
│   优化做法 (1 次 all-reduce + 1 次 reduce-scatter 替代):                     │
│   ────────────────────────────────────────────────────                     │
│   Attention O/P (RowParallel) 改用 reduce-scatter:                          │
│       每个 GPU 有 O_i (完整大小的中间结果)                                  │
│       → reduce-scatter SUM → 每个 GPU 得到 1/N 大小的 O 片段               │
│       → 此时每个 GPU 只有部分 O，但恰好匹配 MLP FC1 的列切分输入！           │
│                                                                             │
│   MLP FC1 (ColumnParallel):                                                 │
│       每个 GPU 的输入 X_i (1/N 大小) × W₁_i → Z_i                           │
│       注意 W₁_i 的列数是 H (4H/N 取 N=4 则=H)，                             │
│       所以输入 X_i (大小=B×S×H/4) × W₁_i (H/4 × H) = Z_i (B×S×H)          │
│       但是 GELU 后仍然是按列切分的！                                        │
│                                                                             │
│   MLP FC2 (RowParallel):                                                    │
│       GELU(Z_i) (B×S×H/4) × W₂_i (H/4 × H) = O_i (B×S×H)                  │
│       → all-reduce(O_i) → 完整 O                                            │
│                                                                             │
│   所以 MLP 只需要 1 次 all-reduce (FC2 的 RowParallel 输出)                  │
│                                                                             │
│   ───────────────────────────────────────────────────────────────────       │
│                                                                             │
│   总结一个完整 Transformer 层的通信:                                          │
│                                                                             │
│   Attention QKV (ColumnParallel):  不需要通信 (X 来自上一层的 all-reduce)     │
│   Attention O/P (RowParallel):     all-reduce (或 reduce-scatter)            │
│   MLP FC1 (ColumnParallel):        不需要通信 (如果前一步用了 reduce-scatter) │
│   MLP FC2 (RowParallel):           all-reduce                               │
│                                                                             │
│   前向总计: 2 次 all-reduce                                                 │
│   反向总计: 2 次 all-reduce                                                 │
│   每层总计: 4 次 all-reduce                                                 │
│                                                                             │
│   等效方案 (全部用 all-reduce):                                              │
│   Attention O/P: all-reduce (gives complete X for next)                      │
│   MLP FC2: all-reduce                                                       │
│   也是 2+2=4 次，但方案中可以用 reduce-scatter 减少通信量                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.8 每层通信量精确计算

```
设:
    B = Batch size (per GPU)
    S = Sequence length
    H = Hidden size
    bytes_per_elem = 2 (FP16) or 1 (FP8)

一次 all-reduce 的数据量:
    data_size = B × S × H × bytes_per_elem

一次 all-reduce 的通信量 (Ring):
    comm = 2(N-1)/N × data_size

一次 reduce-scatter 的通信量:
    comm = (N-1)/N × data_size

一个 Transformer 层 4 次 all-reduce:
    总通信量 = 4 × 2(N-1)/N × B × S × H × bytes_per_elem

    在 TP=8 下:
        = 4 × 2 × 7/8 × B × S × H × bytes_per_elem
        = 7 × B × S × H × bytes_per_elem

数值例子 (GPT-3 风格, TP=8, FP16):
    B = 8 (micro-batch)
    S = 2048
    H = 12288

    data_size = 8 × 2048 × 12288 × 2 = 402,653,184 bytes ≈ 384 MB

    4 次 all-reduce 通信量:
        = 4 × 2(7/8) × 384 MB = 4 × 1.75 × 384 = 2688 MB ≈ 2.6 GB

    如果使用 NVLink 600 GB/s 双向:
        时间 ≈ 2.6 GB / 300 GB/s ≈ 8.7 ms

    而一个 Transformer 层的计算时间 (A100):
        ≈ 15-20 ms

    通信/计算比 ≈ 8.7 / 17.5 ≈ 50%
    这是一个显著的通信开销，也是 TP 的主要限制因素。
```

---

## 5. Sequence Parallelism：序列维度拆分

### 5.1 动机

在 TP 模式下，LayerNorm 和 Dropout 层的输入/输出在每个 GPU 上都是**相同的完整数据**：

```
问题：Activation Memory 瓶颈

    TP=8 时，每个 GPU 都需要存储:
        ├── 完整的 B×S×H 激活值 (LayerNorm, Dropout 需要完整 Tensor)
        ├── 1/8 的模型参数
        └── 1/8 的优化器状态

    但激活值并没有减少！即使切分了模型参数。
    对于大 Batch × 长 Sequence × 大 Hidden，激活内存可能成为瓶颈。

Sequence Parallelism 的解决方案:
    沿着 Sequence (T) 维度也切分!
```

### 5.2 Sequence Parallelism 的工作原理

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Sequence Parallelism (SP) + Tensor Parallelism (TP)       │
│                                                                             │
│   没有 SP (仅 TP):                                                           │
│   ────────────────                                                          │
│   LayerNorm (完整 B×S×H, 所有 GPU 重复)                                     │
│     → ColumnParallel Linear (B×S×H × H×H/tp) = B×S×H/tp, GPU 不同         │
│     → RowParallel Linear (B×S×H/tp × H/tp×H) = B×S×H, all-reduce → 完整   │
│   → LayerNorm (完整 B×S×H, 所有 GPU 重复) ← 空间浪费！                     │
│                                                                             │
│   有 SP:                                                                     │
│   ───────                                                                   │
│   在每个 "过渡区域" (LayerNorm/Dropout 前后) 做 all-gather / reduce-scatter  │
│                                                                             │
│   前向传播流程:                                                              │
│                                                                             │
│         [完整 B×S×H]                                                        │
│              │                                                               │
│              ▼                                                               │
│   ┌─────────────────────┐                                                   │
│   │ f (LayerNorm, etc.) │  ← f 操作作用在 T 维度上做归一化                   │
│   │ 输入: B×S×H/tp      │     但 LayerNorm 需要完整序列统计量 (mean, var)   │
│   │                     │     SP 方案: 每个 GPU 只有 S/tp 的片段             │
│   │                     │     需要 all-gather 来恢复完整 S                   │
│   └─────────┬───────────┘                                                   │
│              │                                                               │
│              ▼                                                               │
│   ┌─────────────────────┐                                                   │
│   │ all-gather 沿 T 维度│ ← GPU 间交换序列片段                               │
│   │ B×S/tp×H → B×S×H   │     通信量 = (N-1)/N × B×S×H                     │
│   └─────────┬───────────┘                                                   │
│              │                                                               │
│              ▼                                                               │
│         [完整 B×S×H]                                                        │
│              │                                                               │
│              ▼                                                               │
│   ┌─────────────────────┐                                                   │
│   │ g (ColumnParallel   │ ← 需要完整输入 (与没有 SP 的 TP 一样)              │
│   │    Linear, etc.)    │                                                   │
│   └─────────┬───────────┘                                                   │
│              │                                                               │
│              ▼                                                               │
│         [B×S×H/tp]  ← 列切分后的输出                                        │
│              │                                                               │
│              ▼                                                               │
│   ┌─────────────────────┐                                                   │
│   │ g' (RowParallel     │ ← 需要部分输入                                     │
│   │     Linear, etc.)   │                                                   │
│   └─────────┬───────────┘                                                   │
│              │                                                               │
│              ▼                                                               │
│         [B×S×H]  但这是部分和不完整的结果                                    │
│              │                                                               │
│              ▼                                                               │
│   ┌─────────────────────┐                                                   │
│   │ reduce-scatter      │ ← 沿 T 维度做 reduce-scatter                       │
│   │ 沿 T 维度            │     通信量 = (N-1)/N × B×S×H                     │
│   │ B×S×H → B×S/tp×H   │                                                   │
│   └─────────┬───────────┘                                                   │
│              │                                                               │
│              ▼                                                               │
│         [B×S/tp×H]  ← 序列维度已切分                                        │
│              │                                                               │
│              ▼                                                               │
│   ┌─────────────────────┐                                                   │
│   │ f⁻¹ (下一个 LN,     │                                                   │
│   │      Dropout, etc.) │ ← 和层首的 f 对称                                  │
│   └─────────────────────┘                                                   │
│                                                                             │
│   关键收益:                                                                  │
│   ├── LayerNorm/Dropout 的激活值内存从 B×S×H 降为 B×S/tp×H                  │
│   ├── 激活值内存减少约 TP 倍                                                 │
│   └── 总通信量与全部 all-reduce 等效                                          │
│        (1 all-gather + 1 reduce-scatter = 2× (N-1)/N×data)                  │
│        (2 all-reduce = 2× 2(N-1)/N×data = 4(N-1)/N×data)                   │
│        实际上 SP 用 1 reduce-scatter + 1 all-gather 替换了 1 all-reduce      │
│        减少了约一半的通信量！                                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.3 SP 通信量分析

```
SP 取代了一对 all-reduce:

    原始 (无 SP，全部用 all-reduce):
        Attention O/P RowParallel:   all-reduce = 2(N-1)/N × data
        MLP FC2 RowParallel:         all-reduce = 2(N-1)/N × data
        总 = 4(N-1)/N × data × 2 (fwd+bwd)

    使用 SP 后:
        Attention 块末尾:  reduce-scatter = (N-1)/N × data
        MLP 块开始:         all-gather     = (N-1)/N × data
        MLP 块末尾:         reduce-scatter = (N-1)/N × data
        下一个 Attention:   all-gather     = (N-1)/N × data

        总 = 4(N-1)/N × data × 2 (fwd+bwd)

    通信量在这里相同，但 SP 额外减少了激活值内存！

    更重要的是，SP 与 TP 组合时，能够在不增加额外通信开销的前提下，
    将 LayerNorm/Dropout 的激活内存减少 TP 倍。
```

---

## 6. Pipeline Parallelism in Megatron

### 6.1 GPipe：朴素流水线

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    GPipe 调度 (PP=4, M=8 micro-batches)                       │
│                                                                             │
│   时间 →                                                                     │
│                                                                             │
│   GPU 0: │F1│F2│F3│F4│F5│F6│F7│F8│                         │B8│B7│B6│B5│B4│B3│B2│B1│
│   GPU 1: │  │F1│F2│F3│F4│F5│F6│F7│F8│             │B8│B7│B6│B5│B4│B3│B2│B1│  │
│   GPU 2: │  │  │F1│F2│F3│F4│F5│F6│F7│F8│ │B8│B7│B6│B5│B4│B3│B2│B1│  │  │
│   GPU 3: │  │  │  │F1│F2│F3│F4│F5│F6│F7│F8│B8│B7│B6│B5│B4│B3│B2│B1│  │  │  │
│                                                                             │
│   F = Forward, B = Backward, 数字 = micro-batch index                       │
│   空格 = GPU 空闲 (Bubble)                                                   │
│                                                                             │
│   Bubble 大小:                                                               │
│   总 time slots = PP + M - 1 + PP + M - 1 = 2(PP + M - 1)                  │
│   有效计算 = 2 × PP × M                                                     │
│   Bubble = 2(PP+M-1) - 2M = 2(PP-1)                                        │
│   Bubble ratio = 2(PP-1) / 2(PP+M-1) = (PP-1)/(PP+M-1)                     │
│                                                                             │
│   M >> PP 时: bubble ≈ (PP-1)/M                                             │
│   例如 PP=4, M=32: bubble = 3/35 ≈ 8.6%                                     │
│   例如 PP=4, M=128: bubble = 3/131 ≈ 2.3%                                   │
│                                                                             │
│   激活值内存: M × (一层的激活值)，需要保存所有 M 个 micro-batch 的激活值      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 1F1B：交错调度以节省内存

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    1F1B 调度 (PP=4, M=8 micro-batches)                        │
│                                                                             │
│   时间 →                                                                     │
│                                                                             │
│   GPU 0: │F1│F2│F3│F4│B1│F5│B2│F6│B3│F7│B4│F8│B5│  │B6│  │B7│  │B8│
│   GPU 1: │  │F1│F2│F3│F4│B1│F5│B2│F6│B3│F7│B4│F8│B5│  │B6│  │B7│  │B8│
│   GPU 2: │  │  │F1│F2│F3│F4│B1│F5│B2│F6│B3│F7│B4│F8│B5│  │B6│  │B7│  │B8│
│   GPU 3: │  │  │  │F1│F2│F3│F4│B1│F5│B2│F6│B3│F7│B4│F8│B5│  │B6│  │B7│  │B8│
│                                                                             │
│   阶段:                                                                      │
│   ├── Warmup (PP-1 步): 填充流水线                                          │
│   │   每个 GPU 先做 PP - rank 个前向                                        │
│   │                                                                          │
│   ├── Steady State (2M - 2(PP-1) 步): 1F + 1B 交替                          │
│   │   每个时间步: 1 个前向 + 1 个反向                                        │
│   │                                                                          │
│   └── Cool-down (PP-1 步): 排空流水线                                        │
│       只做剩余的反向传播                                                     │
│                                                                             │
│   关键区别 vs GPipe:                                                          │
│   ├── 激活内存: 只存 PP 个 micro-batch 的激活值 (vs GPipe 的 M 个)           │
│   │   当 M=128, PP=4: 1F1B 存 4 个, GPipe 存 128 个                         │
│   │   内存节省 ≈ M/PP = 128/4 = 32 倍！                                      │
│   │                                                                          │
│   └── Bubble: 与 GPipe 相同 = (PP-1)/(PP+M-1) ≈ (PP-1)/M                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.3 Interleaved 1F1B：更小 Bubble

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Interleaved 1F1B (PP=4, V=2 virtual stages)              │
│                                                                             │
│   模型层分配 (假设共 8 层):                                                  │
│   ┌────────────────────────────────────────────────────────────┐            │
│   │ GPU 0: Layer 1, Layer 5                                   │            │
│   │ GPU 1: Layer 2, Layer 6                                   │            │
│   │ GPU 2: Layer 3, Layer 7                                   │            │
│   │ GPU 3: Layer 4, Layer 8                                   │            │
│   └────────────────────────────────────────────────────────────┘            │
│                                                                             │
│   每个 GPU 有 V=2 个 virtual pipeline stages                                 │
│   总 virtual stages = PP × V = 8                                            │
│                                                                             │
│   调度:                                                                      │
│   时间 →                                                                     │
│                                                                             │
│   GPU 0: │F1│F2│F3│F4│F5│F6│F7│F8│B1│F9│B2│F10│B3│F11│B4│F12│B5│...        │
│   GPU 1: │  │F1│F2│F3│F4│F5│F6│F7│F8│B1│F9│B2│F10│B3│F11│B4│F12│...        │
│   GPU 2: │  │  │F1│F2│F3│F4│F5│F6│F7│F8│B1│F9│B2│F10│B3│F11│B4│...        │
│   GPU 3: │  │  │  │F1│F2│F3│F4│F5│F6│F7│F8│B1│F9│B2│F10│B3│F11│...        │
│                                                                             │
│   Bubble 分析:                                                               │
│   ────────────                                                              │
│   总 virtual stages = PP × V = P_V                                          │
│   总的 micro-batch 数 = M (在 virtual stages 间流动)                         │
│                                                                             │
│   Warmup: P_V - 1 步                                                        │
│   每个 GPU 处理 V 个不同的 micro-batch，交替在不同层上                       │
│                                                                             │
│   Bubble ratio ≈ (PP-1) / (PP × V + M - V + 1)                              │
│                                                                             │
│   例如 V=2, PP=4, M=128:                                                    │
│       bubble ≈ 3 / (8 + 128 - 2 + 1) = 3/135 ≈ 2.2%                        │
│                                                                             │
│   对比标准 1F1B (V=1):                                                       │
│       bubble ≈ 3 / (4 + 128 - 1 + 1) = 3/132 ≈ 2.3%                        │
│                                                                             │
│   当 M 较小时差距更明显:                                                      │
│       M=32, V=2, PP=4: bubble ≈ 3/39 ≈ 7.7%                                │
│       M=32, V=1, PP=4: bubble ≈ 3/36 ≈ 8.3%                                │
│                                                                             │
│   代价:                                                                      │
│   ├── 每个 GPU 的层跨越更大，通信次数翻倍                                    │
│   └── 更多的 P2P 通信 (每个 virtual stage 边界都需要 send/recv)              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. 3D 并行：DP x TP x PP

### 7.1 拓扑结构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          3D 并行拓扑 (DP=4, TP=2, PP=3)                      │
│                                                                             │
│   TP Group 0             TP Group 1             TP Group 2                  │
│   (同一列)               (同一列)                (同一列)                     │
│   ┌──────┐               ┌──────┐               ┌──────┐                    │
│   │GPU 0 │               │GPU 2 │               │GPU 4 │  ← PP Stage 0     │
│   │GPU 1 │               │GPU 3 │               │GPU 5 │                    │
│   └──────┘               └──────┘               └──────┘                    │
│   ┌──────┐               ┌──────┐               ┌──────┐                    │
│   │GPU 6 │               │GPU 8 │               │GPU10 │  ← PP Stage 1     │
│   │GPU 7 │               │GPU 9 │               │GPU11 │                    │
│   └──────┘               └──────┘               └──────┘                    │
│   ┌──────┐               ┌──────┐               ┌──────┐                    │
│   │GPU12 │               │GPU14 │               │GPU16 │  ← PP Stage 2     │
│   │GPU13 │               │GPU15 │               │GPU17 │                    │
│   └──────┘               └──────┘               └──────┘                    │
│                                                                             │
│   DP Group 0 (同一行)    DP Group 1 (同一行)    DP Group 2 (同一行)          │
│                                                                             │
│   总共: 18 GPUs (DP × TP × PP = 3 × 2 × 3)                                 │
│                                                                             │
│   通信域:                                                                    │
│   ├── TP: 组内 all-reduce (NVLink 高带宽)                                   │
│   ├── PP: 组内 P2P send/recv (节点内 NVLink 或跨节点 IB)                     │
│   └── DP: 跨 TP/PP 组的 all-reduce (跨节点 IB)                              │
│                                                                             │
│   通信顺序 (典型):                                                           │
│   ├── 先做 TP 通信 (层内)                                                    │
│   ├── 再做 PP 通信 (层边界)                                                  │
│   └── 最后做 DP 通信 (反向后的梯度同步)                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 7.2 总通信量分析

```
设:
    PP_size = P
    TP_size = T
    DP_size = D
    总 GPU = P × T × D

每种并行的通信:

    TP 通信 (每层):
        ～ 8 × B × S × H × 2 × bytes_per_elem  (4 次 all-reduce, fwd+bwd)
        但只在 TP group 内通信 (T 个 GPU)
        使用 NVLink 高带宽

    PP 通信 (每层边界):
        每个边界: 2 × B × S × H × bytes_per_elem (send + recv)
        总共 (P-1) 个边界
        使用 P2P (可能是跨节点 IB)

    DP 通信 (每个迭代):
        1 次 all-reduce 梯度的通信量 = 模型参数量 × bytes_per_elem
        在 D 个 GPU 间
        可以与其他计算重叠

设计原则:
    ├── 最大化 T 在 NVLink 域内 (通常 T ≤ 8)
    ├── P 选择使得每 GPU 有足够内存
    └── D = 总 GPU / (P × T)，尽可能大（DP 扩展性最好）
```

---

## 8. 实战案例：GPT-3 175B on 1024 A100

### 8.1 模型规格

```
GPT-3 175B 配置:

    Layers (L):            96
    Hidden size (H):       12288
    Attention heads:        96
    Head dimension (d):     128
    Sequence length (S):    2048
    Batch size (global):    1536 (≈ 3M tokens)
    Vocabulary size:        50257

    参数量计算:
        Embedding:          50257 × 12288 ≈ 617M
        每层 Self-Attention: 4 × 12288² ≈ 604M (Q, K, V, O)
        每层 MLP:             2 × 12288 × 49152 ≈ 1.21B (FC1, FC2)
        每层参数:             604M + 1.21B ≈ 1.81B
        96 层:               96 × 1.81B ≈ 173.8B
        + Embedding + LN:    ≈ 175B

    显存需求:
        模型参数 (FP16):              350 GB
        梯度 (FP16):                   350 GB
        Adam 优化器 (FP32×2):        1400 GB
        ─────────────────────────────────
        总计:                         2100 GB (仅参数/梯度/优化器)
        每 A100 (80GB): 2100/80 ≈ 27 张 (仅存储)
        加上激活值: 远不止 27 张
```

### 8.2 并行配置

```
配置方案: DP=16, TP=8, PP=8

    总 GPU = 16 × 8 × 8 = 1024

    每 GPU:
        ├── 参数:  175B / (8 × 8) = 2.73B × 2 bytes = 5.5 GB
        ├── 梯度:  同样 ≈ 5.5 GB
        └── Adam:  ≈ 22 GB (FP32 × 2)

    模型参数/梯度/优化器显存 ≈ 33 GB

    激活值显存 (估算):
        每层激活 ≈ B_micro × S × H × bytes × TP_factor
        = 2 × 2048 × 12288 × 2 / 8 ≈ 12.6 MB/层
        96 层: 12.6 × 96 ≈ 1.2 GB (使用 activation checkpointing)

    总显存 ≈ 33 + 1.2 + 临时缓冲 ≈ 40-50 GB
    单卡 80GB，非常充裕。

    通信分析:
    ──────────
    TP (8 GPU 间, 每层):
        每层通信: 8 × micro_batch × S × H × bytes_per_elem
        = 8 × 2 × 2048 × 12288 × 2 / 1e9 = 0.805 GB
        总 (96 层, fwd+bwd): 96 × 0.805 = 77.3 GB

    PP (8 个 Stage 间, 跨节点):
        每 micro-batch 每边界: B × S × H × bytes × 2 (send+recv)
        = 2 × 2048 × 12288 × 2 × 2 / 1e9 ≈ 0.2 GB
        每个 Stage 边界: 8 micro-batches × 0.2 GB = 1.6 GB

    DP (16 GPU 间, 每个迭代末):
        模型大小 = 175B × 2 = 350 GB (all-reduce)
        Ring all-reduce: 2(15/16) × 350 ≈ 656 GB
        但 DP 分布式在不同节点，可能通过分桶/分层来优化
        (例如 Hierarchical All-Reduce)

    TP 在 NVSwitch 域内 (单机 8 GPU, 900 GB/s):
        每层 TP 时间 ≈ 0.805 GB / 300 GB/s ≈ 2.7 ms
        每层计算时间 ≈ 15 ms
        TP 通信/计算比 ≈ 2.7/15 ≈ 18%  (可接受)
```

### 8.3 训练吞吐量估算

```
Micro-batch size = 2
每 GPU 每 micro-batch 的 FLOPs (前向):
    每层 ≈ 8 × B × S × H² + 4 × B × S² × H  (Transformer 的 FLOPs)
    ≈ 8 × 2 × 2048 × 12288² + 4 × 2 × 2048² × 12288
    ≈ 8 × 2 × 2048 × 1.51e8 + 4 × 2 × 4.19e6 × 12288
    ≈ 4.95e12 + 4.12e11
    ≈ 5.36 TFLOPs

总 micro-batches 每迭代 (gradient accumulation + PP):
    M = 1536 / (2 × 16) = 48 (16 DP 组, 每组 global_batch/DP = 96, M=96/2=48)

每迭代每 GPU 总 FLOPs:
    前向: 96 层 × 5.36 × 48 = 24,660 TFLOPs
    反向 ≈ 2 × 前向 = 49,320 TFLOPs
    总 ≈ 74,000 TFLOPs / GPU

A100 FP16 峰值: 312 TFLOPs
预计利用率: 50-55%
有效 TFLOPs: ~160 TFLOPs / GPU

预计时间/迭代:
    74,000 / 160 ≈ 463 秒 ≈ 7.7 分钟/迭代

(token 吞吐量):
    tokens/迭代 = 1536 × 2048 ≈ 3.15M tokens
    tokens/秒 = 3.15M / 463 ≈ 6,800 tokens/秒 (总计 1024 GPU)
    tokens/秒/GPU ≈ 6.6
```

---

## 9. Megatron-Core 与 Transformer Engine

### 9.1 Megatron-Core 架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         Megatron-Core 架构                                    │
│                                                                             │
│   ┌──────────────────────────────────────────────────────────────┐          │
│   │                    NeMo Framework (高层)                       │          │
│   │   训练循环、数据加载、检查点、日志、评估...                     │          │
│   └───────────────────────────┬──────────────────────────────────┘          │
│                               │                                              │
│   ┌───────────────────────────┴──────────────────────────────────┐          │
│   │              Megatron-Core (核心模块层)                        │          │
│   │                                                                │          │
│   │   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │          │
│   │   │ tensor_parallel│  │ pipeline_par │  │ transformer  │        │          │
│   │   │ .layers       │  │ .schedules   │  │ .transformer │        │          │
│   │   │ .mappings     │  │ .p2p_comm    │  │ .module      │        │          │
│   │   │ .random       │  │              │  │ .spec        │        │          │
│   │   └──────────────┘  └──────────────┘  └──────────────┘        │          │
│   │                                                                │          │
│   │   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │          │
│   │   │ distributed  │  │ inference    │  │ fusions      │        │          │
│   │   │ .fsdp        │  │ .gpt         │  │ .bias_gelu   │        │          │
│   │   │ .tp_overlap  │  │ .text_gen    │  │ .bias_dropout│        │          │
│   │   └──────────────┘  └──────────────┘  └──────────────┘        │          │
│   │                                                                │          │
│   └───────────────────────────┬──────────────────────────────────┘          │
│                               │                                              │
│   ┌───────────────────────────┴──────────────────────────────────┐          │
│   │               Transformer Engine (FP8 训练)                   │          │
│   │   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │          │
│   │   │ fp8_cast     │  │ delayed      │  │ recipe        │        │          │
│   │   │ transpose    │  │ scaling      │  │               │        │          │
│   │   └──────────────┘  └──────────────┘  └──────────────┘        │          │
│   └──────────────────────────────────────────────────────────────┘          │
│                                                                             │
│   关键模块说明:                                                              │
│                                                                             │
│   tensor_parallel.layers:                                                    │
│   ├── ColumnParallelLinear: f 和 g 操作                                     │
│   ├── RowParallelLinear:    g 操作后接 all-reduce                           │
│   └── VocabParallelEmbedding: 词表并行                                      │
│                                                                             │
│   tensor_parallel.mappings:                                                  │
│   ├── copy_to_tensor_model_parallel_region: TP 内通信包装                    │
│   ├── reduce_from_tensor_model_parallel_region: all-reduce                  │
│   ├── scatter_to_tensor_model_parallel_region: reduce-scatter               │
│   └── gather_from_tensor_model_parallel_region: all-gather                  │
│                                                                             │
│   tensor_parallel.random:                                                    │
│   └── TP 模式下保持 dropout 随机性一致                                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 9.2 Transformer Engine (FP8)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         Transformer Engine FP8 训练                          │
│                                                                             │
│   为什么需要 FP8:                                                            │
│   ──────────────                                                            │
│   H100 GPU 的 FP8 Tensor Core 是 FP16 的 2 倍吞吐                           │
│   显存占用减半                                                               │
│                                                                             │
│   FP8 的挑战:                                                               │
│   ────────────                                                              │
│   E4M3: 指数 4 位, 尾数 3 位 (范围有限: max=448, min=0.00195)              │
│   E5M2: 指数 5 位, 尾数 2 位 (更大范围: max=57344, min=6.1e-5)             │
│   容易上溢/下溢                                                             │
│                                                                             │
│   Delayed Scaling 策略:                                                      │
│   ┌──────────────────────────────────────────────────────┐                  │
│   │                                                      │                  │
│   │  FP16 Input → cast to FP8 → FP8 MatMul → FP16 Output │                  │
│   │       │                          │                   │                  │
│   │       │              ┌───────────┘                   │                  │
│   │       │              │ scaling factor from           │                  │
│   │       │              │ previous iteration            │                  │
│   │       │              │                               │                  │
│   │       │              ▼                               │                  │
│   │       └── 计算当前迭代的 amax ──→ 用于下一个迭代     │                  │
│   │                                                      │                  │
│   └──────────────────────────────────────────────────────┘                  │
│                                                                             │
│   流程:                                                                      │
│   1. 用上一次迭代的 amax 计算缩放因子                                        │
│   2. 将 FP16 输入缩放后转为 FP8                                             │
│   3. 在 FP8 Tensor Core 中做矩阵乘法                                         │
│   4. 结果转回 FP16                                                          │
│   5. 计算当前迭代的 amax，存储供下一次迭代使用                               │
│                                                                             │
│   为什么用 "延迟" 缩放:                                                     │
│   ├── 如果每次在线计算 amax（在线缩放），需要额外遍历整个 Tensor            │
│   └── 用上一次的 amax 近似本次，误差可控                                     │
│                                                                             │
│   混合精度方案:                                                              │
│   ├── 前向 GEMM: FP8 输入 × FP8 权重 → FP16 输出                           │
│   ├── 反向 GEMM: FP8 梯度 × FP8 权重 → FP16 梯度                            │
│   ├── 优化器: FP32 主参数 (master weights)                                  │
│   ├── LayerNorm/GELU/Dropout/Softmax: FP16/FP32                             │
│   └── 注意力: FlashAttention (FP16/BF16)                                    │
│                                                                             │
│   性能收益 (H100):                                                           │
│   ├── 训练吞吐提升 1.5-2x (vs FP16)                                         │
│   ├── 显存占用减少 ~30-40%                                                   │
│   └── 模型精度损失 < 0.1% (perplexity)                                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 10. 代码走读：ColumnParallelLinear 和 RowParallelLinear

### 10.1 ColumnParallelLinear

```python
# =============================================================================
# ColumnParallelLinear 的实现 (简化版，基于 Megatron-Core 源码)
# =============================================================================

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributed import all_reduce, reduce_scatter, all_gather

class ColumnParallelLinear(nn.Module):
    """
    列并行线性层。

    权重 A ∈ R^(in_features × out_features) 按列切分成 N 份:
        A = [A_1 | A_2 | ... | A_N]
        每份 A_i ∈ R^(in_features × out_features/N)

    前向: Y_i = X × A_i  (每个 GPU 得到部分输出)
         然后根据 gather_output 参数决定是否 all-gather 拼成完整 Y

    反向: 对输入的梯度 ∂L/∂X 需要 all-reduce
          对权重的梯度 ∂L/∂A_i 是局部的 (各 GPU 更新自己的列)
    """

    def __init__(
        self,
        in_features: int,         # 输入特征维度
        out_features: int,        # 输出特征维度 (会被 TP 切分)
        bias: bool = True,
        gather_output: bool = True,  # 是否在前向收集完整输出
        tp_group=None,               # TP 通信组
        tp_size: int = 1,            # TP 度数
        skip_bias_add: bool = False, # 是否跳过 bias 相加 (优化)
        init_method=nn.init.xavier_normal_,
    ):
        super().__init__()

        self.in_features = in_features
        self.out_features = out_features
        self.gather_output = gather_output
        self.tp_size = tp_size
        self.skip_bias_add = skip_bias_add

        # 每个 GPU 持有 out_features / tp_size 列
        self.output_size_per_partition = out_features // tp_size

        # 初始化权重 (按列切分)
        # 实际上使用 setattr 和 Parameter 来注册
        self.weight = nn.Parameter(
            torch.empty(
                self.output_size_per_partition,  # 每个 GPU 的部分列
                in_features
            )
        )
        init_method(self.weight)

        if bias:
            self.bias = nn.Parameter(
                torch.empty(self.output_size_per_partition)
            )
            # 初始化 bias
            with torch.no_grad():
                self.bias.zero_()
        else:
            self.register_parameter('bias', None)

    def forward(self, input_: torch.Tensor) -> tuple:
        """
        Args:
            input_: (batch, seq_len, in_features) 或 (batch, in_features)

        Returns:
            output: (batch, seq_len, out_features) 如果 gather_output=True
                    否则 (batch, seq_len, out_features/tp_size)
            bias: 如果 skip_bias_add，单独返回 bias tensor
        """

        # ============================================
        # Step 1: 矩阵乘法 (本地，无需通信)
        # ============================================
        # input_  shape: (batch, seq_len, in_features)
        # weight  shape: (out_features/tp_size, in_features)
        # output_parallel shape: (batch, seq_len, out_features/tp_size)

        output_parallel = F.linear(input_, self.weight)

        # ============================================
        # Step 2: 是否收集完整输出 (all-gather)
        # ============================================
        if self.gather_output:
            # all-gather 沿最后一维 (列方向)
            # 每个 GPU 有 (B,S,H/N), 需要拼成 (B,S,H)
            # all-gather 需要在通信组内进行
            output = gather_from_tensor_model_parallel_region(
                output_parallel
            )
        else:
            output = output_parallel  # 保持切分状态

        # ============================================
        # Step 3: Bias (如果不需要 skip)
        # ============================================
        if self.bias is not None and not self.skip_bias_add:
            output = output + self.bias
            output_bias = None
        else:
            output_bias = self.bias

        return output, output_bias


def gather_from_tensor_model_parallel_region(tensor):
    """
    All-gather 沿最后一维。
    每个 GPU 有 tensor of shape (..., H/N)
    拼接后得到 (..., H)
    """
    world_size = torch.distributed.get_world_size()
    # 创建列表存放来自每个 rank 的 tensor
    tensor_list = [torch.empty_like(tensor) for _ in range(world_size)]
    all_gather(tensor_list, tensor)
    # 沿最后一维拼接
    output = torch.cat(tensor_list, dim=-1)
    return output


def reduce_from_tensor_model_parallel_region(tensor):
    """
    All-reduce 求和。
    用于反向传播中整合各 GPU 的部分梯度。
    """
    all_reduce(tensor)
    return tensor


def scatter_to_tensor_model_parallel_region(tensor):
    """
    Reduce-scatter 沿最后一维。
    每个 GPU 输入完整 tensor，求和后按最后一维切分。
    """
    world_size = torch.distributed.get_world_size()
    # ...
    return tensor_chunk
```

### 10.2 RowParallelLinear

```python
class RowParallelLinear(nn.Module):
    """
    行并行线性层。

    权重 A ∈ R^(in_features × out_features) 按行切分成 N 份:
        A_1, A_2, ..., A_N, 每份 A_i ∈ R^(in_features/N × out_features)

    每个 GPU 持有 1/N 的输入列和 1/N 的权重行。

    前向: Y_i = X_i × A_i  (每个 GPU 得到完整大小的部分结果)
          然后 all-reduce 求和得到完整 Y

    反向: 对输入的梯度 ∂L/∂X_i = ∂L/∂Y × A_i^T
          不需要额外的通信 (∂L/∂Y 已经在每个 GPU 上完整可用)
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        input_is_parallel: bool = True,  # 输入已经按列切分
        tp_group=None,
        tp_size: int = 1,
        skip_bias_add: bool = False,
        init_method=nn.init.xavier_normal_,
    ):
        super().__init__()

        self.in_features = in_features
        self.out_features = out_features
        self.input_is_parallel = input_is_parallel
        self.tp_size = tp_size
        self.skip_bias_add = skip_bias_add

        # 每个 GPU 持有 in_features / tp_size 行
        self.input_size_per_partition = in_features // tp_size

        # 权重按行切分
        # 注意: 权重形状是 (out_features, in_features/tp_size)
        self.weight = nn.Parameter(
            torch.empty(
                out_features,
                self.input_size_per_partition
            )
        )
        init_method(self.weight)

        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
            with torch.no_grad():
                self.bias.zero_()
        else:
            self.register_parameter('bias', None)

    def forward(self, input_: torch.Tensor) -> tuple:
        """
        Args:
            input_: (batch, seq_len, in_features/tp_size)  如果 input_is_parallel
                    否则 (batch, seq_len, in_features)

        Returns:
            output: (batch, seq_len, out_features)  完整输出
            bias: optional
        """

        # ============================================
        # Step 1: 矩阵乘法 (本地)
        # ============================================
        # input_  shape: (batch, seq_len, in_features/tp_size)
        # weight  shape: (out_features, in_features/tp_size)
        # output_parallel shape: (batch, seq_len, out_features)
        #
        # 注意: 这里每个 GPU 得到的是完整大小的输出!

        output_parallel = F.linear(input_, self.weight)

        # ============================================
        # Step 2: All-Reduce 求和 (关键通信步骤!)
        # ============================================
        # 每个 GPU 的部分结果求和得到最终结果
        output = reduce_from_tensor_model_parallel_region(
            output_parallel
        )

        # ============================================
        # Step 3: Bias
        # ============================================
        if self.bias is not None and not self.skip_bias_add:
            output = output + self.bias
            output_bias = None
        else:
            output_bias = self.bias

        return output, output_bias
```

### 10.3 完整的 TP Transformer 层

```python
class ParallelTransformerLayer(nn.Module):
    """
    一个完整的、使用 TP 的 Transformer 层。

    前向通信路径:
        Attention:
            QKV Projection (ColumnParallel)  → 不通信
            Attention 计算                     → 不通信
            Output Projection (RowParallel)    → all-reduce
        MLP:
            FC1 (ColumnParallel)               → 不通信
            GELU                                → 不通信
            FC2 (RowParallel)                  → all-reduce

    前向总计: 2 次 all-reduce
    """

    def __init__(self, hidden_size, ffn_hidden_size, num_heads, tp_size):
        super().__init__()
        self.hidden_size = hidden_size
        self.ffn_hidden_size = ffn_hidden_size
        self.num_heads = num_heads
        self.tp_size = tp_size

        # Attention
        self.qkv = ColumnParallelLinear(
            hidden_size, 3 * hidden_size,
            gather_output=False,  # 不需要收集完整输出
            tp_size=tp_size       # Q,K,V 已经按 head 在 TP 组中分布
        )
        self.attention_out = RowParallelLinear(
            hidden_size, hidden_size,
            input_is_parallel=True,  # 输入来自 attention 后，是按 head 分布的
            tp_size=tp_size
        )

        # MLP
        self.fc1 = ColumnParallelLinear(
            hidden_size, ffn_hidden_size,
            gather_output=False,  # 不需要收集完整输出
            tp_size=tp_size        # 因为接下来 GELU 可以按列独立计算
        )
        self.fc2 = RowParallelLinear(
            ffn_hidden_size, hidden_size,
            input_is_parallel=True,  # GELU 输出仍然是按列切分的
            tp_size=tp_size
        )

        # LayerNorm (如果使用 SP，这里的 LN 输入是切分后的)
        self.ln1 = nn.LayerNorm(hidden_size)
        self.ln2 = nn.LayerNorm(hidden_size)

    def forward(self, x):
        # --- Self-Attention ---
        residual = x
        x = self.ln1(x)

        # QKV: ColumnParallel → 不通信
        qkv, _ = self.qkv(x)
        # qkv shape: (B, S, 3H/tp_size)

        # Attention: 本地计算
        attn_output = self._attention(qkv)

        # Output: RowParallel → all-reduce
        attn_output, _ = self.attention_out(attn_output)
        x = residual + attn_output

        # --- MLP ---
        residual = x
        x = self.ln2(x)

        # FC1: ColumnParallel → 不通信
        fc1_out, _ = self.fc1(x)

        # GELU: 本地计算
        fc1_out = F.gelu(fc1_out)

        # FC2: RowParallel → all-reduce
        fc2_out, _ = self.fc2(fc1_out)
        x = residual + fc2_out

        return x

    def _attention(self, qkv):
        """简单的注意力计算"""
        B, S, _ = qkv.shape
        H = self.hidden_size // self.num_heads // self.tp_size

        q, k, v = qkv.chunk(3, dim=-1)
        q = q.view(B, S, self.num_heads // self.tp_size, H).transpose(1, 2)
        k = k.view(B, S, self.num_heads // self.tp_size, H).transpose(1, 2)
        v = v.view(B, S, self.num_heads // self.tp_size, H).transpose(1, 2)

        attn = torch.matmul(q, k.transpose(-2, -1)) / (H ** 0.5)
        attn = F.softmax(attn, dim=-1)
        out = torch.matmul(attn, v)

        out = out.transpose(1, 2).contiguous().view(
            B, S, H * (self.num_heads // self.tp_size)
        )
        return out
```

### 10.4 通信操作的低层实现

```python
# =============================================================================
# Megatron-Core 中的通信原语 (基于 torch.distributed)
# =============================================================================

import torch.distributed as dist

# 获取 TP 通信组 (从全局变量或上下文)
_TP_GROUP = None

def get_tp_group():
    return _TP_GROUP

# ---- 四个 TP 通信原语 ----

def _reduce(input_: torch.Tensor) -> torch.Tensor:
    """
    All-reduce 求和，就地操作。

    用法:
        RowParallelLinear 前向末尾
        ColumnParallelLinear 反向 (对输入梯度)

    通信量: 2(N-1)/N × size(input_)
    """
    if get_tp_group().size() == 1:
        return input_
    dist.all_reduce(input_, group=get_tp_group())
    return input_


def _split(input_: torch.Tensor) -> torch.Tensor:
    """
    Reduce-Scatter 沿最后一维。

    用法:
        配合 Sequence Parallelism,
        将完整 tensor 分散为 T 维切分的块

    通信量: (N-1)/N × size(input_)
    """
    if get_tp_group().size() == 1:
        return input_

    # 沿最后一维切分
    dim = input_.dim() - 1
    chunks = input_.chunk(get_tp_group().size(), dim=dim)

    # 获取当前 rank 的 chunk
    output = torch.empty_like(chunks[get_tp_group().rank()])
    dist.reduce_scatter(output, list(chunks), group=get_tp_group())
    return output


def _gather(input_: torch.Tensor) -> torch.Tensor:
    """
    All-Gather 沿最后一维。

    用法:
        ColumnParallelLinear (gather_output=True)
        或 Sequence Parallelism 中恢复完整 tensor

    通信量: (N-1)/N × size(gathered tensor)
    """
    if get_tp_group().size() == 1:
        return input_

    # 最后一维
    dim = input_.dim() - 1
    gather_list = [
        torch.empty_like(input_) for _ in range(get_tp_group().size())
    ]
    dist.all_gather(gather_list, input_, group=get_tp_group())
    output = torch.cat(gather_list, dim=dim)
    return output


def _reduce_scatter_along_first_dim(input_: torch.Tensor) -> torch.Tensor:
    """
    Reduce-Scatter 沿第一维 (针对 Sequence Parallelism 的 T 维)。

    通信量: (N-1)/N × size(input_)
    """
    if get_tp_group().size() == 1:
        return input_

    world_size = get_tp_group().size()
    # input shape: (B, S, H)
    # 沿 dim=1 (S 维) 切分
    dim = 1
    input_chunks = input_.chunk(world_size, dim=dim)
    output = torch.empty_like(input_chunks[get_tp_group().rank()])
    dist.reduce_scatter(output, list(input_chunks), group=get_tp_group())
    return output


def _gather_along_first_dim(input_: torch.Tensor) -> torch.Tensor:
    """
    All-Gather 沿第一维 (Sequence Parallelism)。

    通信量: (N-1)/N × size(gathered tensor)
    """
    if get_tp_group().size() == 1:
        return input_

    world_size = get_tp_group().size()
    dim = 1
    gather_list = [
        torch.empty_like(input_) for _ in range(world_size)
    ]
    dist.all_gather(gather_list, input_, group=get_tp_group())
    output = torch.cat(gather_list, dim=dim)
    return output
```

---

## 11. 选型决策：Megatron vs DeepSpeed vs FSDP

### 11.1 三方对比总览

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Megatron vs DeepSpeed vs FSDP 对比                         │
│                                                                             │
│   ┌──────────────────┬─────────────────┬─────────────────┬─────────────────┐ │
│   │                  │   Megatron-LM   │   DeepSpeed     │  PyTorch FSDP   │ │
│   ├──────────────────┼─────────────────┼─────────────────┼─────────────────┤ │
│   │ 开发者           │ NVIDIA          │ Microsoft       │ Meta / PyTorch  │ │
│   │ 核心并行方式     │ TP + PP + DP    │ ZeRO + PP       │ ZeRO-3 (FSDP)   │ │
│   │ TP 支持          │ 原生, 最完善    │ 通过 Megatron   │ torch.TensorPar  │ │
│   │                  │                 │ 集成            │ allel (试验性)   │ │
│   │ 1F1B / Pipe      │ 内置            │ 内置            │ PiPPy (试验性)  │ │
│   │ ZeRO-1 (OS)      │ 通过 DDP        │ 原生            │ 原生 (DDP+ZeRO) │ │
│   │ ZeRO-2 (OS+G)    │ 通过 DDP        │ 原生            │ 类似 SHARD_GRAD  │ │
│   │ ZeRO-3 (OS+G+P)  │ 通过 FSDP       │ 原生            │ 原生 FSDP       │ │
│   │ CPU Offload      │ 有限            │ 原生, 最完善    │ 原生 (torch)    │ │
│   │ NVMe Offload     │ 无              │ 原生            │ 无              │ │
│   │ FP8 训练         │ Transformer     │ 无 (依赖 TE)   │ 无 (依赖 TE)    │ │
│   │                  │ Engine 原生     │                 │                 │ │
│   │ 3D 并行 API      │ 复杂但灵活      │ 简化配置        │ 拼装式          │ │
│   │ 社区文档         │ 中等            │ 较好            │ 最好 (官方)     │ │
│   │ NVIDIA GPU 优化  │ 最佳            │ 良好            │ 良好            │ │
│   │ 非 NVIDIA 支持   │ 不可用          │ 支持 AMD        │ 通用            │ │
│   │ 学习曲线         │ 陡峭            │ 中等            │ 中等            │ │
│   │ 代码侵入性       │ 高 (需重写层)   │ 低 (config)     │ 中等            │ │
│   └──────────────────┴─────────────────┴─────────────────┴─────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 11.2 场景决策矩阵

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        选型决策矩阵                                          │
│                                                                             │
│   场景 1: 小模型 (< 7B)，单机 8 GPU                                          │
│   ─────────────────────────────────                                         │
│   推荐: FSDP (ZeRO-3) 或 DeepSpeed ZeRO-3                                   │
│   理由: TP/PP 引入的通信开销不值得，FSDP/ZeRO-3 简单够用                    │
│   配置: FSDP + bf16 + activation checkpointing                              │
│                                                                             │
│   场景 2: 中等模型 (7B - 70B)，单机或多机                                     │
│   ──────────────────────────────────────                                     │
│   推荐: DeepSpeed ZeRO-3 + 可能加 PP                                        │
│   理由: ZeRO-3 有最好的 CPU Offload 支持，PP 降低跨节点通信                  │
│   配置: ZeRO-3 + bf16 + activation checkpointing + 可选 CPU offload         │
│                                                                             │
│   场景 3: 大模型 (70B - 175B)，多机集群                                      │
│   ────────────────────────────────────                                       │
│   推荐: Megatron-LM (TP=8 + PP=N)  或  DeepSpeed + Megatron TP              │
│   理由: 单独的 ZeRO-3 不够，需要 TP + PP 来增加并行度                        │
│   配置: TP=8 (节点内) + PP=8-16 + DP, FP16/BF16                             │
│                                                                             │
│   场景 4: 超大模型 (175B+ - 1T)，大规模集群                                  │
│   ────────────────────────────────────────                                   │
│   推荐: Megatron-LM (TP + PP + DP) + Transformer Engine (FP8)               │
│   理由: 需要所有并行手段，且最优化通信                                       │
│   配置: TP=8 + PP=32+ + DP, FP8 + activation recompute                      │
│                                                                             │
│   场景 5: 微调 (Fine-tuning)，已有预训练模型                                  │
│   ─────────────────────────────────────────                                 │
│   推荐: FSDP 或 DeepSpeed ZeRO-2/3 + LoRA/QLoRA                             │
│   理由: 微调不需要 TP，梯度检查点 + ZeRO 足够                                │
│   配置: ZeRO-2 + LoRA + bf16 + gradient checkpointing                       │
│                                                                             │
│   场景 6: MoE 模型训练                                                        │
│   ───────────────────                                                        │
│   推荐: DeepSpeed (MoE 支持最完善) 或 Megatron + 手动 EP                     │
│   理由: DeepSpeed 有原生的 Expert Parallelism + 负载均衡                      │
│   配置: ZeRO-1 + EP + 可选的 TP/PP                                          │
│                                                                             │
│   场景 7: 非 NVIDIA GPU (AMD, Ascend 等)                                     │
│   ──────────────────────────────────────                                     │
│   推荐: FSDP / DeepSpeed (非 CUDA 部分)                                      │
│   理由: Megatron 的 TE 等模块深度依赖 CUDA/NCCL，不跨平台                     │
│   配置: FSDP + 对应厂商的通信后端                                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 11.3 组合使用的实际情况

```
在实际项目中，三者经常不是互斥的，而是组合使用:

    常见组合:
    ├── Megatron-LM (TP+PP) + DeepSpeed (ZeRO-DP)
    │   利用 Megatron 的 TP/PP + DeepSpeed 的 ZeRO 优化器
    │   NVIDIA NeMo 框架原生支持这种组合
    │
    ├── FSDP (ZeRO-3) + Tensor Parallel (torch.TensorParallel)
    │   PyTorch 2.0+ 的 2D 并行方案
    │   device_mesh 统一管理 TP 和 DP 通信组
    │
    └── DeepSpeed ZeRO-3 + Pipeline Parallelism
        中等规模模型最常用的组合
        代码侵入性最小
```

---

## 13. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| Tensor Parallelism (TP) | 把一个大矩阵乘法按列/行拆到多个 GPU 上同时算 —— 单层内的「分而治之」 | Ch.4 |
| ColumnParallelLinear | 权重按列切分，输入完整，输出需要 all-gather 拼接 —— TP 的前半拍 | Ch.4.2 |
| RowParallelLinear | 权重按行切分，输入已按列切分，输出需要 all-reduce 求和 —— TP 的后半拍 | Ch.4.3 |
| Sequence Parallelism (SP) | 沿序列长度维度切分 LayerNorm/Dropout 的激活值，配合 TP 省显存而不增通信 | Ch.5 |
| Interleaved 1F1B | 每个 GPU 管多个虚拟阶段，微批次在虚拟阶段间更细粒度流转，进一步压榨 Bubble | Ch.6.3 |
| 3D Parallelism | 同一训练任务同时使用 DP（数据切分）、TP（层内切分）、PP（层间切分）三种并行 | Ch.7 |

## 14. A800 部署场景举例

**场景 1：单机 8×A800 80GB 用 Megatron TP=8 训练 30B 模型**

```
硬件: 1 节点 8×A800 80GB, NVSwitch 全互联, NVLink 600 GB/s 双向
策略: TP=8（节点内）+ DP（如果多节点则跨节点）

Megatron-LM 启动命令示例:
  torchrun --nproc_per_node=8 pretrain_gpt.py \
    --tensor-model-parallel-size 8 \
    --pipeline-model-parallel-size 1 \
    --num-layers 48 --hidden-size 7168 --num-attention-heads 64 \
    --seq-length 2048 --micro-batch-size 1 \
    --global-batch-size 256 --lr 1.5e-4 \
    --bf16

TP=8 时每层 4 次 all-reduce（fwd+bwd）:
  激活值大小 ≈ B×S×H = 1×2048×7168×2 bytes ≈ 28 MB
  单次 all-reduce (Ring, 8 GPU): 通信量 = 2×(8-1)/8 × 28 MB ≈ 49 MB
  每层 4 次: ~196 MB
  48 层总计: ~9.4 GB 通信量/step
  NVLink 600 GB/s 下: ~15.7 ms —— 在可接受范围

关键注意: TP 必须在 NVLink 域内（同节点），跨 IB 做 TP 通信量太大不推荐
```

**场景 2：2 节点 16×A800 用 TP=8 + PP=2 训练**

```
硬件: 2 节点 16×A800, 节点内 NVSwitch, 节点间 200Gbps InfiniBand
策略: TP=8（节点内）+ PP=2（跨节点）

为何不跨节点做 TP:
  跨节点 TP 每层需 all-reduce 28MB × 2×(7/8) ≈ 49MB  via IB
  IB 200Gbps ≈ 25 GB/s → 约 2ms/层（仅通信），48 层 = 96ms 额外通信
  NVLink 下仅 0.05ms/层 → 跨节点慢 40 倍

TP 放节点内、PP 放节点间是标准做法:
  PP 通信量 = B×S×H × 2 = 56MB/boundary/microbatch（远小于 TP）
  PP=2 只有 1 个边界，且 P2P 对延迟容忍度高

配置:
  --tensor-model-parallel-size 8 --pipeline-model-parallel-size 2
```

## 15. 上下游串联

```
                    AI Infra 训练栈 — Megatron-LM 的位置
                    
    ┌──────────────────────────────────────────────────────────┐
    │  分布式训练基础 (DDP, NCCL, 混合精度, 梯度累积)           │
    │  提供: 所有并行策略复用的通信原语和训练范式                │
    └──────────────────────────┬───────────────────────────────┘
                               │
              ┌────────────────┼──────────────────┐
              ▼                ▼                  ▼
    ┌──────────────┐  ┌────────────────┐  ┌──────────────┐
    │ DeepSpeed    │  │ ★ 本份文档     │  │ Pipeline     │
    │ ZeRO-1/2/3   │  │ Megatron-LM   │  │ Parallelism  │
    │ 优化器/梯度/  │  │ TP + SP       │  │ GPipe/1F1B   │
    │ 参数分片      │  │ 层内的矩阵拆分 │  │ 层间的流水线  │
    └──────┬───────┘  └───────┬────────┘  └──────┬───────┘
           │                 │                   │
           └─────────┬───────┴─────────┬─────────┘
                     │                 │
                     ▼                 ▼
    ┌─────────────────────────────────────────────────────────┐
    │  3D 并行 (DP × TP × PP) + Sequence Parallelism          │
    │  Megatron-DeepSpeed / NVIDIA NeMo                       │
    │  例如: 1024 A100 = DP=16 × TP=8 × PP=8                 │
    └─────────────────────────────────────────────────────────┘
                               │
                               ▼
    ┌─────────────────────────────────────────────────────────┐
    │  Transformer Engine (FP8 训练)                           │
    │  Megatron-Core 模块化层                                  │
    └─────────────────────────────────────────────────────────┘
```

Megatron-LM 的核心贡献是**在 Transformer 层内部做 TP**。它与 DeepSpeed ZeRO（优化数据并行的显存效率）和 Pipeline Parallelism（跨层切分模型）是**正交且互补**的关系。实际大模型训练中，三者通常同时使用：在 NVLink 节点内用 TP（充分利用高带宽），跨节点用 PP（通信量小），跨 TP/PP 组之间用 ZeRO-DP 做优化器状态分片。本份文档的 Column/Row Parallel Linear 设计是连接这些模块的关键抽象。

---

## 12. 总结

### 12.1 核心要点回顾

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Megatron-LM 核心要点                                 │
│                                                                             │
│   1. Tensor Parallelism 是 Megatron 最核心的创新:                            │
│      ├── Column Parallel: 权重按列切，输入完整，输出部分                     │
│      ├── Row Parallel:   权重按行切，输入部分，输出完整后 all-reduce          │
│      └── 每层仅需 4 次 all-reduce (fwd+bwd)                                 │
│                                                                             │
│   2. Sequence Parallelism 减少激活内存 TP 倍:                                │
│      ├── 用 reduce-scatter + all-gather 替代部分 all-reduce                 │
│      └── LayerNorm/Dropout 只在 T 维片段上计算                               │
│                                                                             │
│   3. 五维并行体系:                                                            │
│      ├── DP:  拆分 batch           → 梯度同步                                │
│      ├── TP:  拆分矩阵乘法的列/行  → 激活值同步                              │
│      ├── PP:  拆分模型层           → 激活/梯度传递                            │
│      ├── SP:  拆分序列长度         → 配合 TP 减少激活内存                    │
│      └── EP:  拆分 MoE 专家        → all-to-all                              │
│                                                                             │
│   4. 3D 并行 = DP × TP × PP:                                                │
│      ├── TP 在节点内 (NVLink)                                               │
│      ├── PP 跨节点 (通信量小)                                               │
│      └── DP 跨所有节点                                                       │
│                                                                             │
│   5. 选型指南:                                                               │
│      ├── 小模型 (<7B):     FSDP / DeepSpeed ZeRO                           │
│      ├── 中模型 (7-70B):   DeepSpeed ZeRO-3 + PP                            │
│      ├── 大模型 (70-175B): Megatron TP + PP                                 │
│      └── 超大 (>175B):     全栈 Megatron + FP8                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 12.2 引用与进一步阅读

- Megatron-LM v1 论文: "Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism" (Shoeybi et al., 2019)
- Megatron-LM v2 论文: "Efficient Large-Scale Language Model Training on GPU Clusters Using Megatron-LM" (Narayanan et al., 2021)
- Sequence Parallelism: "Reducing Activation Recomputation in Large Transformer Models" (Korthikanti et al., 2022)
- Interleaved Pipeline: "Memory-Efficient Pipeline-Parallel DNN Training" (Narayanan et al., 2021)
- Megatron-Core 代码: https://github.com/NVIDIA/Megatron-LM
- NeMo Framework: https://github.com/NVIDIA/NeMo
- Transformer Engine: https://github.com/NVIDIA/TransformerEngine

---

*本文档旨在提供 Megatron-LM 的深入技术分析，涵盖数学原理、工程实现和实战指导。*
*所有代码示例均为简化版，完整实现请参阅官方仓库。*
