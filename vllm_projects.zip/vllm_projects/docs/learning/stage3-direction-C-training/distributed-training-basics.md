# 分布式训练基础：从单GPU到多GPU的完整指南

## 目录

1. [为什么要分布式训练](#1-为什么要分布式训练)
2. [数据并行 (Data Parallelism)](#2-数据并行-data-parallelism)
3. [PyTorch DDP 深度解析](#3-pytorch-ddp-深度解析)
4. [通信原语与 NCCL](#4-通信原语与-nccl)
5. [梯度累积](#5-梯度累积)
6. [混合精度训练](#6-混合精度训练)
7. [梯度裁剪](#7-梯度裁剪)
8. [分布式检查点](#8-分布式检查点)
9. [容错与弹性训练](#9-容错与弹性训练)
10. [torchrun：多节点启动器](#10-torchrun多节点启动器)
11. [FSDP 入门](#11-fsdp-入门)
12. [计算-通信重叠](#12-计算-通信重叠)
13. [实战：8×A800 训练 Qwen-7B](#13-实战8a800-训练-qwen-7b)
14. [深入学习资源](#14-深入学习资源)

---

## 1. 为什么要分布式训练

### 1.1 三大驱动力

在深度学习领域，模型的规模增长远超单GPU的能力增长。我们面临三个刚性约束：

```
+------------------+     +------------------+     +------------------+
|   模型太大        |     |   数据太多        |     |   时间太紧        |
|   (Model Size)   |     |   (Data Volume)  |     |   (Time Budget)  |
+------------------+     +------------------+     +------------------+
| GPT-3:   175B    |     | 预训练数据:       |     | 单GPU训练         |
| LLaMA:   65B     |     | 数TB文本          |     | GPT-3 需要        |
| Qwen:    72B     |     |                  |     | 约355年           |
|                   |     | 单GPU吃不消       |     |                   |
| 单张A800(80G)    |     | 数据加载速度      |     | 分布式后:          |
| FP16下只能装      |     | 成为瓶颈          |     | ~3-4个月          |
| ~40B参数模型     |     |                  |     |                   |
+------------------+     +------------------+     +------------------+
```

**具体数字来说：**

- 以GPT-3 175B为例，FP32存储需要 175B × 4 bytes = 700GB 显存
- 单张A800(80GB)连模型都装不下，更别提优化器状态和激活值
- 即便是7B的Qwen，FP16训练时：模型14GB + 优化器(Adam)56GB + 梯度14GB + 激活值若干 ≈ 100GB+
- 单卡80GB也无法完整训练7B模型

### 1.2 显存构成分析

训练时显存的完整构成：

```
训练一个参数量为 Φ 的模型，显存占用 = 以下各项之和：

1. 模型权重 (Model Weights):
   - FP32: Φ × 4 bytes
   - FP16: Φ × 2 bytes
   - 混合精度: Φ × 2 (FP16) + Φ × 4 (FP32 master copy)
            = Φ × 6 bytes

2. 梯度 (Gradients):
   - FP32: Φ × 4 bytes
   - FP16: Φ × 2 bytes

3. 优化器状态 (Optimizer States) - 以Adam为例:
   - 一阶动量 m: Φ × 4 bytes
   - 二阶动量 v: Φ × 4 bytes
   - 如果是AdamW带有FP32 master权重: 再加 Φ × 4 bytes
   - 合计: Φ × 8 (Adam) 或 Φ × 12 (AdamW + FP32 master)

4. 激活值 (Activations):
   - 与 batch_size × seq_len × hidden_size × num_layers 成正比
   - 对于大模型，激活值常常是最大的显存消费者
   - 可以通过激活检查点 (activation checkpointing) 来交换计算换显存

总计 (混合精度 + Adam) ≈ Φ × 16 bytes
对于7B模型: 7B × 16 = 112GB → 单卡80GB放不下！
对于175B模型: 175B × 16 = 2800GB → 需要35张80GB卡！

实际显存还要加上：
- KV Cache (推理时)
- 通信缓冲区
- CUDA context 开销
- 碎片化开销
```

### 1.3 分布式策略总览

```
                    分布式训练策略分类
                          |
          +---------------+---------------+
          |               |               |
    数据并行 (DP)    模型并行 (MP)    混合并行
          |               |               |
    +-----+-----+    +----+----+    +----+----+
    |           |    |         |    |         |
   DDP        FSDP  TP        PP   3D并行
 (单机多卡)  (ZeRO) (张量并行)(流水线)
```

---

## 2. 数据并行 (Data Parallelism)

### 2.1 基本原理

数据并行是最直观的分布式策略：每个GPU上复制一份完整的模型，但训练不同的数据子集。

```
单GPU训练 (batch_size = 8):
+---------------------------+
| GPU 0                     |
|  模型副本                  |
|  输入: X[0:8]            |
|  前向 → Loss → 反向 → 更新|
+---------------------------+

数据并行 (batch_size = 32, 4 GPUs):
+---------------+---------------+---------------+---------------+
| GPU 0         | GPU 1         | GPU 2         | GPU 3         |
| 模型副本       | 模型副本       | 模型副本       | 模型副本       |
| 输入: X[0:8]  | 输入: X[8:16] | 输入: X[16:24]| 输入: X[24:32]|
+---------------+---------------+---------------+---------------+
        |               |               |               |
    本地损失        本地损失        本地损失        本地损失
        |               |               |               |
    本地梯度        本地梯度        本地梯度        本地梯度
        |               |               |               |
        +-------+-------+-------+-------+
                |  All-Reduce  |
                |  (梯度平均)   |
                +---------------+
                        |
                  平均后的梯度
                        |
            +-----------+-----------+
            |           |           |
        更新GPU0     更新GPU1    更新GPU2     更新GPU3
        (模型权重现在完全一致)
```

### 2.2 数学形式

设有 K 个GPU，每个处理一个大小为 B 的micro-batch。

```
全局batch_size = K × B

每个GPU k 的数据子集为: D_k = {(x_i, y_i)}_{i=kB}^{(k+1)B-1}

局部损失: L_k(θ) = (1/B) × Σ_{(x,y)∈D_k} l(f(x;θ), y)

全局损失: L(θ) = (1/K) × Σ_{k=0}^{K-1} L_k(θ)

局部梯度: g_k = ∇_θ L_k(θ)

全局梯度 (All-Reduce之后): G = (1/K) × Σ_{k=0}^{K-1} g_k

参数更新: θ_{t+1} = θ_t - η × G
```

### 2.3 朴素 DP (DataParallel) vs DDP

PyTorch 提供了两种数据并行实现：

```
torch.nn.DataParallel (DP) - 单进程多线程:
============================================
主进程 (GPU0)
    │
    ├──→ 将输入scatter到各GPU
    ├──→ 将模型参数broadcast到各GPU (每步都做！)
    ├──→ 各GPU并行计算前向
    ├──→ 输出gather回GPU0
    ├──→ GPU0计算loss、反向传播
    ├──→ 各GPU上的梯度gather回GPU0
    └──→ GPU0更新参数
    问题: GPU0负载不均, Python GIL竞争, 每步都broadcast参数


torch.nn.parallel.DistributedDataParallel (DDP) - 多进程:
==========================================================
每个GPU一个独立进程
    │
    ├──→ 初始化时sync一次参数 (broadcast)
    ├──→ 每个进程独立加载数据子集
    ├──→ 前向计算 (各进程独立)
    ├──→ 反向计算 (各进程独立)
    ├──→ All-Reduce梯度 (ring all-reduce)
    ├──→ 各进程独立更新 (梯度相同 → 权重保持同步)
    └──→ 不需要再次broadcast参数！
    优势: 多进程无GIL, GPU0无瓶颈, 通信高效
```

**一句话总结：DP是Python级别的多线程方案，慢且不稳定；DDP是C++级别的多进程方案，是工业标准。**

---

## 3. PyTorch DDP 深度解析

### 3.1 DDP 如何包装模型

DDP 本质上是一个 wrapper，它在模型上注册 hooks 来拦截反向传播的梯度。

```python
# ============================================
# DDP 的核心包装逻辑 (简化版源码解读)
# ============================================

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP

# ---- 用户代码 ----
model = MyTransformerModel().cuda()
ddp_model = DDP(model, device_ids=[local_rank])

# ---- DDP 内部做了什么 (概念层面) ----
class SimplifiedDDP:
    def __init__(self, module, device_ids):
        self.module = module  # 原始模型
        self.device_ids = device_ids

        # 1. 将参数广播到所有GPU (只在构造时做一次)
        for param in self.module.parameters():
            dist.broadcast(param.data, src=0)

        # 2. 注册 backward hooks (这是核心！)
        # 每个需要梯度的参数都注册一个 hook
        # 当该参数的梯度被计算出来后，hook 被触发
        for param in self.module.parameters():
            if param.requires_grad:
                # 将参数按大小分桶 (bucketing)
                # 注册 hook: 当梯度就绪时，触发对应的 bucket 的 all-reduce
                param.register_hook(self._make_gradient_hook(param))

    def _make_gradient_hook(self, param):
        def hook(grad):
            # 当这个参数的梯度计算完毕时被调用
            # ... 将梯度加入对应bucket
            # ... 当bucket满时，启动异步all-reduce
            pass
        return hook

    def forward(self, *args, **kwargs):
        # 前向计算：直接调用原始模型，无任何通信
        return self.module(*args, **kwargs)
```

### 3.2 梯度分桶 (Gradient Bucketing)

这是 DDP 最核心的优化技术。不是每计算出一个参数的梯度就立即 all-reduce，而是将梯度按大小分组，一组一组地做 all-reduce，从而减少通信次数、提高带宽利用率。

```
梯度分桶的工作流程:
====================

                       模型所有参数 (按反向传播的逆序排列)
    +-------+-------+-------+-------+-------+-------+-------+-------+
    |  p1   |  p2   |  p3   |  p4   |  p5   |  p6   |  p7   |  p8   |
    +-------+-------+-------+-------+-------+-------+-------+-------+
      32MB    32MB    8MB     8MB     1MB    1MB     1MB     1MB

                    ↓ 按大小分桶 (bucket_size_limit=25MB)
    +---------------------------+---------------------------+
    |       Bucket 1            |       Bucket 2            |
    |  p1 (32MB → 单独桶)       |  p3+p4+p5+p6+p7+p8        |
    +---------------------------+  = 20MB < 25MB            |
    |  p2 (32MB → 单独桶)       +---------------------------+
    +---------------------------+

当反向传播计算出 p1 的梯度时:
  → p1 的 bucket 只有一个参数，满了
  → 立即启动异步 all-reduce (bucket 1)

当反向传播按顺序计算出 p3, p4, ..., p8 的梯度时:
  → 累积到 bucket 2
  → 当 p8 的梯度就绪时，bucket 2 满了
  → 启动异步 all-reduce (bucket 2)

为什么有效？
- 将很多小参数的梯度打包成一个大 message
- 大 message 的带宽利用率远高于多个小 message
- 每个 message 的延迟开销只付一次
```

**分桶对通信效率的影响：**

```
通信时间 = 延迟 + 数据量 / 带宽

假设: 延迟 = 10μs, 带宽 = 300GB/s (NVLink A800)

小梯度逐个all-reduce (100个参数，每个100KB):
  N=8 GPUs, ring all-reduce
  每个: time = 2×(N-1) × (10μs + 100KB/300GB/s)
            = 14 × (10μs + 0.33μs) ≈ 144.7μs
  总计: 100 × 144.7μs = 14.47ms

分桶后 (1个大桶，10MB):
  time = 14 × (10μs + 10MB/300GB/s)
       = 14 × (10μs + 33.3μs) ≈ 606.7μs
  节省: 14.47ms → 0.607ms ≈ 24x 加速！
```

### 3.3 通信-计算重叠 (Overlap)

DDP 的另一个关键优化：在计算当前 bucket 的 all-reduce 时，反向传播继续计算后续层的梯度。

```
通信-计算重叠时间线:
====================

没有重叠 (naive DDP):
|------- 前向传播 -------|------- 反向传播 -------|-- all-reduce 全部梯度 --|
                                                  ^^^^^^^^^^^^^^^^^^^^^^
                                                          串行

有重叠 (DDP with bucketing):
|------- 前向传播 -------|------- 反向传播 -------|
                          |  back bucket3 |  back bucket2 |  back bucket1 |
                          |   compute     |   compute     |   compute     |
                          |               |  all-reduce   |  all-reduce   |
                          |               |  bucket3 grad |  bucket2 grad |
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                          计算和通信同时进行！等待时间大幅减少。
```

**实际效果：**

- 理想情况下，通信时间可以完全隐藏在计算时间中
- 前提：bucket 的梯度计算时间 >= bucket 的 all-reduce 时间
- 对于大模型（bucket较大的情况），这个条件通常成立
- 实测：通信开销从总时间的 30-40% 降低到 5-10%

### 3.4 完整代码示例：10行转换

```python
# ============================================
# 从单GPU到多GPU DDP的10行代码
# ============================================

# ---------- 单GPU训练 ----------
import torch
from torch.utils.data import DataLoader, Dataset

model = MyModel().cuda()
dataset = MyDataset()
dataloader = DataLoader(dataset, batch_size=32)
optimizer = torch.optim.AdamW(model.parameters())

for epoch in range(epochs):
    for batch in dataloader:
        x, y = batch[0].cuda(), batch[1].cuda()
        optimizer.zero_grad()
        loss = model(x, y)
        loss.backward()
        optimizer.step()


# ---------- 多GPU DDP训练 (10行改动) ----------
import torch
import torch.distributed as dist                     # 新增 1
from torch.nn.parallel import DistributedDataParallel as DDP  # 新增 2
from torch.utils.data import DataLoader, Dataset
from torch.utils.data.distributed import DistributedSampler  # 新增 3

# 新增 4: 初始化进程组
dist.init_process_group(backend="nccl")
local_rank = int(os.environ["LOCAL_RANK"])
torch.cuda.set_device(local_rank)

model = MyModel().cuda()
ddp_model = DDP(model, device_ids=[local_rank])      # 新增 5: 包装模型

dataset = MyDataset()
sampler = DistributedSampler(dataset)                 # 新增 6: 分布式采样器
dataloader = DataLoader(dataset, batch_size=32,
                        sampler=sampler)              # 新增 7: 使用sampler

optimizer = torch.optim.AdamW(ddp_model.parameters())

for epoch in range(epochs):
    sampler.set_epoch(epoch)                          # 新增 8: 设置epoch保证shuffle
    for batch in dataloader:
        x, y = batch[0].cuda(), batch[1].cuda()
        optimizer.zero_grad()
        loss = ddp_model(x, y)                        # 新增 9: 使用ddp_model
        loss.backward()
        optimizer.step()

dist.destroy_process_group()                          # 新增 10: 清理
```

**关键细节说明：**

1. `DistributedSampler`：确保每个GPU看到不重叠的数据子集
2. `sampler.set_epoch(epoch)`：没有这行，每个epoch的数据划分相同，失去随机性
3. `DDP(model, device_ids=[local_rank])`：自动处理梯度同步
4. `local_rank` vs `rank`：`local_rank` 是本机内的GPU编号，`rank` 是全局编号

---

## 4. 通信原语与 NCCL

### 4.1 NCCL 简介

NCCL (NVIDIA Collective Communications Library) 是NVIDIA为GPU间通信优化的库。它是DDP和所有分布式训练框架的通信后端。

```
NCCL 的核心能力:
================
- 拓扑感知: 自动检测 GPU 互联拓扑 (NVLink, PCIe, InfiniBand)
- Ring和Tree算法: 根据数据量和拓扑自动选择最优算法
- GPU Direct: GPU显存到GPU显存，不经过CPU
- GPUDirect RDMA: 跨节点GPU显存直接传输，不经CPU内存
- 非阻塞操作: 所有通信都可以异步执行
```

### 4.2 All-Reduce

这是训练中最核心的通信操作。All-Reduce 将每个GPU的值求和（或求平均），然后广播到所有GPU。

```
All-Reduce 示意图:
==================

输入 (每个GPU有不同的值):
  GPU0: a₀    GPU1: a₁    GPU2: a₂    GPU3: a₃

输出 (每个GPU得到相同的汇总值):
  GPU0: Σa    GPU1: Σa    GPU2: Σa    GPU3: Σa
```

#### Ring All-Reduce 算法

这是NCCL中最常用的算法，带宽最优。

```
Ring All-Reduce 详细过程 (4 GPUs):
====================================

Step 1: Reduce-Scatter (3轮, 在环中传递)
---------

第1轮: 每个GPU发送(N-1)/N的数据到邻居
  GPU0 → GPU1: (1/4) of data
  GPU1 → GPU2: (1/4) of data
  GPU2 → GPU3: (1/4) of data
  GPU3 → GPU0: (1/4) of data

  同时每个GPU将收到的数据加到自己的相应块上。

第2轮: 继续传递
  GPU0 → GPU1: 之前收到并累加后的数据块
  ...

第3轮: 最后一轮传递

第3轮结束后:
  GPU0: 拥有完整累加后的 chunk₀
  GPU1: 拥有完整累加后的 chunk₁
  GPU2: 拥有完整累加后的 chunk₂
  GPU3: 拥有完整累加后的 chunk₃

Step 2: All-Gather (3轮)
---------

第1轮:
  GPU0 → GPU1: chunk₀ (完整累加的)
  GPU1 → GPU2: chunk₁
  ...

第3轮结束后:
  每个GPU都拥有所有完整的chunk → 所有GPU都有完整的汇总结果！


Ring All-Reduce 数学分析:
=========================

设:
  N = GPU 数量
  D = 数据大小 (bytes)
  L = 单次通信延迟
  B = 带宽 (bytes/sec)

总步骤数: 2 × (N - 1)  (N-1步 reduce-scatter + N-1步 all-gather)

每步传输数据量: D / N  (每个GPU每次发送1/N的数据)

总通信时间: T = 2 × (N - 1) × (L + D / (N × B))

简化: T ≈ 2 × (N - 1) × D / (N × B)  (当 D 很大时，延迟可忽略)

带宽利用率: 有效带宽 = D / T ≈ (N / (2×(N-1))) × B

当 N=2:  利用率 = 2/2 = 1.0B   (理论最优)
当 N=4:  利用率 = 4/6 ≈ 0.67B
当 N=8:  利用率 = 8/14 ≈ 0.57B
当 N→∞: 利用率 → 0.5B           (极限为带宽的一半)

这就是为什么大N值时通信效率下降的根本原因！
```

#### Tree All-Reduce

对于较小数据量（延迟敏感），NCCL可能使用树形算法：

```
Tree All-Reduce (二叉树):
=========================

        GPU0 (root)
       /          \
    GPU1          GPU2
    /   \        /   \
  GPU3  GPU4  GPU5  GPU6

Reduce 阶段 (从叶子到根):
  叶子→父节点: 发送数据
  父节点: 求和后发送给自己的父节点
  根节点: 得到最终结果

Broadcast 阶段 (从根到叶子):
  根→子节点: 发送最终结果
  递归广播到所有叶子

时间复杂度: O(log₂N) 步, 但每步传输完整数据 D
总数据量: 2 × (N-1) × D / N (与Ring相同)
每GPU发送量: 2D

对比:
  Ring:  O(N) 步, 每步 D/N 数据 → 延迟高但带宽好
  Tree:  O(logN) 步, 每步 D 数据 → 延迟低但带宽利用率低

NCCL 自动选择: 大数据用Ring, 小数据用Tree
```

### 4.3 All-Gather

将每个GPU的数据收集后广播给所有GPU。

```
All-Gather (Ring):
==================

初始状态:
  GPU0: [a₀]    GPU1: [a₁]    GPU2: [a₂]    GPU3: [a₃]

最终状态:
  GPU0: [a₀, a₁, a₂, a₃]
  GPU1: [a₀, a₁, a₂, a₃]
  GPU2: [a₀, a₁, a₂, a₃]
  GPU3: [a₀, a₁, a₂, a₃]

步骤: N-1 步, 每步发送 D/N 数据
总时间: T = (N-1) × (L + D/(N×B))
       ≈ (N-1) × D / (N×B)

训练中的使用:
- TP (Tensor Parallelism) 中 Column Parallel 反向传播时需要
- 序列并行中合并激活值
```

### 4.4 Reduce-Scatter

All-Reduce的第一阶段。先分散reduce，每GPU得到最终结果的一部分。

```
Reduce-Scatter:
===============

初始状态:
  GPU0: [a₀, a₁, a₂, a₃]
  GPU1: [b₀, b₁, b₂, b₃]
  GPU2: [c₀, c₁, c₂, c₃]
  GPU3: [d₀, d₁, d₂, d₃]

最终状态:
  GPU0: [a₀+b₀+c₀+d₀]    (只有第0块)
  GPU1: [a₁+b₁+c₁+d₁]    (只有第1块)
  GPU2: [a₂+b₂+c₂+d₂]    (只有第2块)
  GPU3: [a₃+b₃+c₃+d₃]    (只有第3块)

步骤: N-1 步, 每步发送 D/N (与all-gather相同)
总时间: ≈ (N-1) × D / (N×B)

训练中的使用:
- TP (Tensor Parallelism) 中 Row Parallel 前向时的替代方案
- FSDP 中梯度聚合 (ZeRO-2)
```

### 4.5 Broadcast

从一个GPU发送数据到所有GPU。

```
Broadcast:
==========

  root (GPU0): [data]
       |
  +----+----+----+
  |    |    |    |
GPU1  GPU2 GPU3 GPU4 (都收到 [data])

树形广播: O(logN) 步
环形广播: O(N) 步

训练中的使用:
- DDP初始化时广播模型参数
- 某些框架中广播数据
```

### 4.6 各原语的通信量对比

```
+------------------+------------------+------------------+------------------+
| 原语             | 每GPU发送量      | 延迟 (步数)      | 训练中的典型用途  |
+------------------+------------------+------------------+------------------+
| All-Reduce       | 2(N-1)/N × D    | 2(N-1) (Ring)   | DDP梯度同步      |
|                  |                  | 2log₂N (Tree)   | TP中的聚合       |
+------------------+------------------+------------------+------------------+
| All-Gather       | (N-1)/N × D     | N-1 (Ring)      | TP中收集完整输出 |
|                  |                  | log₂N (Tree)    | SP中合并激活值   |
+------------------+------------------+------------------+------------------+
| Reduce-Scatter   | (N-1)/N × D     | N-1            | FSDP梯度聚合     |
|                  |                  |                 | TP中替代all-reduce|
+------------------+------------------+------------------+------------------+
| Broadcast        | D               | log₂N          | 初始化时广播参数 |
+------------------+------------------+------------------+------------------+
| Reduce           | D               | log₂N          | 仅root得到结果   |
+------------------+------------------+------------------+------------------+
| Scatter          | D/N             | log₂N          | 分发数据         |
+------------------+------------------+------------------+------------------+
| Gather           | D               | log₂N          | 收集数据到root   |
+------------------+------------------+------------------+------------------+
```

### 4.7 通信性能实操

```python
# ============================================
# 测量NCCL通信性能的实用代码
# ============================================

import torch
import torch.distributed as dist
import time

dist.init_process_group(backend="nccl")
local_rank = dist.get_rank()
world_size = dist.get_world_size()
torch.cuda.set_device(local_rank)

def benchmark_all_reduce(size_mb, warmup=10, trials=100):
    """测试指定大小的 all-reduce 性能"""
    num_elements = (size_mb * 1024 * 1024) // 4  # float32
    tensor = torch.randn(num_elements, device="cuda")

    # Warmup
    for _ in range(warmup):
        dist.all_reduce(tensor)

    torch.cuda.synchronize()
    start = time.perf_counter()

    for _ in range(trials):
        dist.all_reduce(tensor)

    torch.cuda.synchronize()
    elapsed = time.perf_counter() - start

    avg_time_ms = (elapsed / trials) * 1000
    bandwidth_gb = (size_mb / 1024) / (avg_time_ms / 1000)

    if local_rank == 0:
        print(f"Size: {size_mb:6.1f}MB | Time: {avg_time_ms:8.4f}ms | "
              f"Bandwidth: {bandwidth_gb:6.2f} GB/s")

if local_rank == 0:
    print(f"World size: {world_size}")
    print(f"{'Size':>8} | {'Time':>10} | {'Bus BW':>10}")
    print("-" * 35)

for size in [1, 4, 16, 64, 256, 1024]:
    benchmark_all_reduce(size)

dist.destroy_process_group()

# 典型输出 (8×A800, NVLink):
# World size: 8
#     Size |       Time |     Bus BW
# -----------------------------------
#      1MB |    0.0450ms |   22.22 GB/s
#      4MB |    0.0612ms |   65.36 GB/s
#     16MB |    0.0987ms |  162.11 GB/s
#     64MB |    0.2103ms |  304.33 GB/s
#    256MB |    0.7512ms |  340.87 GB/s
#   1024MB |    2.9800ms |  343.62 GB/s
# 小数据带宽低是因为延迟占比大
# 大数据趋近理论带宽极限 (NVLink 3.0: 600GB/s,
# bus BW ≈ 600 × N/(2(N-1)) = 600 × 8/14 ≈ 342GB/s ✓)
```

---

## 5. 梯度累积

### 5.1 为什么需要梯度累积

问题：大模型训练需要大 batch 来稳定训练，但单GPU显存放不下。

解决方案：用梯度累积模拟大 batch，不需要同时存所有数据。

```
梯度累积原理:
==============

没有梯度累积:
  一次前向+反向处理 batch_size=128 的数据
  显存需求: 需要同时存储128个样本的激活值

有梯度累积:
  每次前向+反向处理 batch_size=16 (micro-batch)
  累积8次后更新一次权重
  显存需求: 只需要同时存储16个样本的激活值
  等效batch_size: 16 × 8 = 128

关键: loss.backward() 不会清零梯度，而是累加！
      optimizer.step() 才清零梯度。
```

### 5.2 数学推导

```
正常训练 (无梯度累积):
  θ_{t+1} = θ_t - η × (1/B) × Σᵢ ∇L(xᵢ; θ_t)

梯度累积 (accumulation_steps = K):
  令每个 micro_batch 大小为 B/K
  g = 0
  for k in range(K):
      g += (K/B) × Σ_{i=kB/K}^{(k+1)B/K-1} ∇L(xᵢ; θ_t)  # 注意缩放因子！
  θ_{t+1} = θ_t - η × g

等价性条件: Σ across micro-batches = full batch gradient

注意: 有些框架在 loss.backward() 时已经除以了 micro_batch_size
      这时每个 micro_batch 的梯度贡献是 (1/K)/B × Σ...
      需要 K 次累积才能得到正确的 (1/B) × Σ

关键: 必须保证每个micro-batch的loss计算使用正确的缩放，
      或者像下面代码中做 loss/accumulation_steps
```

### 5.3 完整实现

```python
# ============================================
# 带梯度累积的DDP训练
# ============================================

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler

# 配置
per_gpu_batch_size = 8          # 每个GPU的micro-batch大小
gradient_accumulation_steps = 4  # 累积步数
world_size = 8                   # GPU数量

# 有效batch size
effective_batch_size = (
    per_gpu_batch_size *
    gradient_accumulation_steps *
    world_size
)
# = 8 × 4 × 8 = 256

# 初始化
dist.init_process_group(backend="nccl")
local_rank = dist.get_rank()
torch.cuda.set_device(local_rank)

model = MyModel().cuda()
ddp_model = DDP(model, device_ids=[local_rank])

sampler = DistributedSampler(dataset, shuffle=True)
dataloader = DataLoader(dataset, batch_size=per_gpu_batch_size,
                        sampler=sampler, num_workers=4,
                        pin_memory=True)
optimizer = torch.optim.AdamW(ddp_model.parameters(), lr=1e-4)

# 训练循环
for epoch in range(num_epochs):
    sampler.set_epoch(epoch)
    optimizer.zero_grad()  # 在accumulation循环外清零！

    for step, batch in enumerate(dataloader):
        x, y = batch[0].cuda(non_blocking=True), batch[1].cuda(non_blocking=True)

        # DDP的no_sync: 在前accumulation_steps-1步不同步梯度
        # 只在最后一步同步 (关键优化！)
        sync_context = (ddp_model.no_sync()
                        if (step + 1) % gradient_accumulation_steps != 0
                        else torch.enable_grad())

        with sync_context:
            loss = ddp_model(x, y)
            loss = loss / gradient_accumulation_steps  # 关键: 缩放loss
            loss.backward()

        # 累积足够步数后更新
        if (step + 1) % gradient_accumulation_steps == 0:
            # 梯度裁剪 (在all-reduce之后！)
            torch.nn.utils.clip_grad_norm_(ddp_model.parameters(), max_norm=1.0)
            optimizer.step()
            optimizer.zero_grad()

        # 可选: logging
        if local_rank == 0 and step % 100 == 0:
            print(f"Epoch {epoch}, Step {step}, Loss: {loss.item():.4f}")

dist.destroy_process_group()
```

### 5.4 no_sync 优化

`ddp_model.no_sync()` 是 DDP 的一个关键特性：

```
没有 no_sync:
  micro_batch 1 → backward (all-reduce梯度)
  micro_batch 2 → backward (all-reduce梯度)
  micro_batch 3 → backward (all-reduce梯度)
  micro_batch 4 → backward (all-reduce梯度)
  → 4次all-reduce，只有最后一次有意义！

有 no_sync:
  micro_batch 1 → backward (不同步，本地累加)
  micro_batch 2 → backward (不同步，本地累加)
  micro_batch 3 → backward (不同步，本地累加)
  micro_batch 4 → backward (all-reduce一次)
  → 1次all-reduce，与全batch等价！

性能提升: 节省了3/4的梯度通信时间
```

### 5.5 等效Batch Size公式

```
effective_batch_size = per_gpu_micro_batch × accumulation_steps × world_size

或者等价地:

global_batch_size = micro_batch_size × accumulation_steps
effective_batch_size = global_batch_size × world_size

常见的配置:
- Qwen-7B 预训练: per_gpu=4, acc_steps=8, world_size=8 → eff_bs=256
- LLaMA-7B 预训练: per_gpu=4, acc_steps=32, world_size=128 → eff_bs=16384
- GPT-3 175B: 总batch ≈ 3.2M tokens → 约 1536 sequences
```

---

## 6. 混合精度训练

### 6.1 为什么需要混合精度

FP32 显存大、计算慢；FP16 显存小、计算快但范围有限。

```
数值精度对比:
==============

FP32 (float32):
  范围: ±3.4 × 10³⁸
  最小正数: ~1.4 × 10⁻⁴⁵
  精度: ~7位十进制有效数字
  内存: 4 bytes/元素

FP16 (float16):
  范围: ±65504
  最小正数: ~6.0 × 10⁻⁸
  精度: ~3位十进制有效数字
  内存: 2 bytes/元素

BF16 (bfloat16):
  范围: ±3.4 × 10³⁸  (与FP32相同！)
  最小正数: ~1.2 × 10⁻³⁸
  精度: ~2位十进制有效数字
  内存: 2 bytes/元素

FP16的问题:
  - 范围太小，大的梯度值会溢出到inf
  - 精度太低，小的梯度值会下溢到0 (underflow)
  
BF16的优势:
  - 指数位与FP32相同 (8位) → 范围相同
  - 不会溢出！缺点: 精度比FP16低
  - A100/H100/A800上有BF16硬件支持
```

### 6.2 FP16混合精度训练

核心思想：前向和反向用FP16（快、省内存），但维护一份FP32的master权重（精度高、用于更新）。

```
FP16混合精度架构:
==================

                 +------------+
                 | FP32 Master |
                 |   Weights   |
                 +-----+------+
                       |
                    (cast)
                       ↓
                 +------------+
        +------->| FP16 Weights|--------+
        |        +-----+------+       |
        |              |              ↓
        |           Forward        FP16 Activations
        |              |              |
        |              ↓              ↓
        |         FP16 Loss ←--- FP16 Output
        |              |
        |           Scaling
        |              ↓
        |         Scaled Loss
        |              |
        |           Backward
        |              |
        |              ↓
        |        FP16 Gradients
        |              |
        |           Unscale
        |              ↓
        |        FP32 Gradients
        |              |
        |              ↓
        +------←  Optimizer Step
                     |
                     ↓
              Updated FP32
              Master Weights
```

### 6.3 损失缩放 (Loss Scaling)

FP16 的最小正数是 ~6×10⁻⁸。如果某个梯度值 < 6×10⁻⁸，它在FP16下就变成0了。

```
损失缩放的原理:
================

问题:
  损失很小 → 梯度很小 → 梯度 < FP16的min → 变成0 → 参数不更新

解决:
  1. 训练前: 将loss乘以一个大因子 (如 2¹⁶ = 65536)
  2. 前向: loss_scaled = loss × scale_factor
  3. 反向: grad_scaled = ∂(loss_scaled)/∂θ = scale_factor × original_grad
     → 梯度被放大，不会下溢
  4. 更新前: grad = grad_scaled / scale_factor  → 恢复真实梯度
  5. 更新: θ = θ - η × grad

动态损失缩放:
  初始scale = 2¹⁶
  for each iteration:
      if no inf/nan in gradients:
          scale *= 2  (逐渐增大，追求更好的精度)
      else:
          scale /= 2  (出现溢出，减小scale)
          skip this iteration (不更新)
```

### 6.4 PyTorch AMP 完整实践

```python
# ============================================
# FP16混合精度训练的完整DDP + AMP代码
# ============================================

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.cuda.amp import autocast, GradScaler

# 初始化
dist.init_process_group(backend="nccl")
local_rank = dist.get_rank()
torch.cuda.set_device(local_rank)

# 模型
model = MyTransformerModel().cuda()
ddp_model = DDP(model, device_ids=[local_rank])

# 优化器和GradScaler
optimizer = torch.optim.AdamW(ddp_model.parameters(), lr=1e-4)
scaler = GradScaler()  # 损失缩放器 (FP16专用)

# 数据
sampler = DistributedSampler(dataset, shuffle=True)
dataloader = DataLoader(dataset, batch_size=per_gpu_batch,
                        sampler=sampler,
                        num_workers=4,
                        pin_memory=True)

for epoch in range(num_epochs):
    sampler.set_epoch(epoch)

    for step, batch in enumerate(dataloader):
        x, y = batch[0].cuda(non_blocking=True), batch[1].cuda(non_blocking=True)

        optimizer.zero_grad()

        # autocast: 自动将FP32操作转为FP16
        # 哪些操作保持FP32? softmax, layer_norm, loss通常是FP32
        with autocast():
            output = ddp_model(x)
            loss = torch.nn.functional.cross_entropy(output, y)

        # GradScaler执行:
        # 1. loss × scale → scaled_loss
        # 2. scaled_loss.backward() → scaled_gradients
        # 3. 检测inf/nan
        # 4. 如果没有inf/nan: unscaled_gradients = scaled_gradients / scale
        #    然后 optimizer.step()
        # 5. 如果有inf/nan: 跳过此次更新, 减小scale
        # 6. 尝试增大scale
        scaler.scale(loss).backward()

        # 梯度裁剪需要在unscale之后
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(ddp_model.parameters(), max_norm=1.0)

        scaler.step(optimizer)
        scaler.update()  # 动态调整scale

        if local_rank == 0 and step % 100 == 0:
            print(f"Step {step}, Loss: {loss.item():.4f}, "
                  f"Scale: {scaler.get_scale()}")

dist.destroy_process_group()
```

### 6.5 BF16：更简单的选择

```python
# ============================================
# BF16训练 (不需要loss scaling!)
# ============================================

# BF16与FP16的关键区别:
# - BF16: 8位指数 (与FP32相同范围) + 7位尾数
# - FP16: 5位指数 + 10位尾数
# - 由于指数范围大，BF16天然不会溢出
# - 不需要GradScaler！代码更简单！

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP

dist.init_process_group(backend="nccl")
local_rank = dist.get_rank()
torch.cuda.set_device(local_rank)

model = MyTransformerModel().cuda()
ddp_model = DDP(model, device_ids=[local_rank])

optimizer = torch.optim.AdamW(ddp_model.parameters(), lr=1e-4)
# 注意: BF16不需要GradScaler!

for batch in dataloader:
    x, y = batch[0].cuda(), batch[1].cuda()
    optimizer.zero_grad()

    # 使用BF16 autocast (不需要loss scaling!)
    with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        output = ddp_model(x)
        loss = torch.nn.functional.cross_entropy(output, y)

    loss.backward()  # 直接backward，无需scaler.scale(loss).backward()
    torch.nn.utils.clip_grad_norm_(ddp_model.parameters(), max_norm=1.0)
    optimizer.step()  # 直接step，无需scaler.step()

# BF16 总结:
# 优点:
# 1. 不需要 loss scaling，代码更简洁
# 2. 不会因溢出而跳过更新
# 3. 训练通常更稳定
# 4. 与 FP32 的 dynamic range 相同
#
# 缺点:
# 1. 精度略低于 FP16 (7位尾数 vs 10位尾数)
# 2. 旧GPU (V100等) 不支持 (A100/H100/A800 支持)
# 3. 小模型上可能有精度损失
#
# 实际建议: 在A100/H100/A800上优先用BF16
```

### 6.6 混合精度显存节省计算

```
混合精度显存分析 (7B 模型, 8 GPU DDP):
==========================================

                        FP32全精度     FP16混合精度     BF16混合精度
模型参数 (主副本)        28 GB          14 GB + 28 GB   14 GB + 28 GB
                        (FP32 × Φ)     (FP16 + FP32)   (BF16 + FP32)
梯度                     28 GB          14 GB           14 GB
优化器状态 (Adam)         56 GB          56 GB           56 GB
激活值 (估计)             ~60 GB         ~30 GB          ~30 GB
                        (FP32)         (FP16)          (BF16)
--------------------------------------------------------------
每GPU总计                ~172 GB        ~142 GB         ~142 GB
                        (÷ 8 GPU)      (÷ 8 GPU)       (÷ 8 GPU)
                        ≈ 21.5 GB      ≈ 17.8 GB       ≈ 17.8 GB

节省: FP16/BF16 vs FP32 = 约17%显存
```

---

## 7. 梯度裁剪

### 7.1 为什么大模型需要梯度裁剪

在大batch训练中，梯度范数可能变得很大，导致训练不稳定。

```python
# ============================================
# 分布式梯度裁剪的正确姿势
# ============================================

# ❌ 错误做法 (在all-reduce之前裁剪):
# 每个GPU各自裁剪自己的局部梯度
# 但这会导致全局梯度被过度裁剪或不一致
for param in model.parameters():
    if param.grad is not None:
        param.grad = param.grad / max(1.0, param.grad.norm() / max_norm)

# ✅ 正确做法 (在all-reduce之后裁剪):
# DDP已经自动完成了all-reduce，每个GPU有相同的梯度
# 此时裁剪是一致的
torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

# 完整流程:
# 1. loss.backward() → DDP自动all-reduce梯度
# 2. clip_grad_norm_() → 裁剪全局梯度
# 3. optimizer.step() → 更新参数
```

### 7.2 梯度裁剪的数学

```
梯度裁剪公式:
==============

给定 max_norm (通常是 1.0, 5.0, 或 10.0):

total_norm = sqrt( Σ_p ||grad_p||² )  对所有参数p

if total_norm > max_norm:
    scaling_factor = max_norm / total_norm
    for all parameters p:
        grad_p = grad_p × scaling_factor

即: 梯度的L2范数被限制在max_norm以内
这意味着每次参数更新的步长是有界的

对于Transformer:
  - 预训练通常: max_norm = 1.0
  - 微调通常: max_norm = 5.0 或 10.0
  - 值越小越稳定但收敛越慢
```

---

## 8. 分布式检查点

### 8.1 检查点包含什么

```
训练检查点的内容:
==================

{
    "model_state_dict": {...},      // 模型参数
    "optimizer_state_dict": {...},  // 优化器状态 (m, v, step等)
    "lr_scheduler_state_dict": {...}, // 学习率调度器
    "epoch": 5,                     // 当前epoch
    "global_step": 12500,           // 全局步数
    "rng_state": {...},             // 随机数状态 (可选)
    "scaler_state": {...},          // GradScaler状态 (FP16用)
}
```

### 8.2 保存和加载

```python
# ============================================
# 分布式检查点保存与加载
# ============================================

import torch
import torch.distributed as dist

def save_checkpoint(model, optimizer, scaler, scheduler,
                    epoch, global_step, save_dir, is_main=True):
    """只在rank 0保存检查点 (DDP模式)"""
    if dist.get_rank() != 0:
        return
    # No extra local_rank check — use dist.get_rank()

    checkpoint = {
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict(),
        "scaler_state_dict": scaler.state_dict() if scaler else None,
        "epoch": epoch,
        "global_step": global_step,
    }
    path = f"{save_dir}/checkpoint_step_{global_step}.pt"
    torch.save(checkpoint, path)
    print(f"Checkpoint saved to {path}")


def save_checkpoint_sharded(model, optimizer, scaler, scheduler,
                            epoch, global_step, save_dir):
    """每个rank保存自己的分片 (FSDP模式)"""
    rank = dist.get_rank()
    # FSDP有专门的sharded checkpoint API
    # 这里展示概念
    checkpoint = {
        "model_state_dict": model.state_dict(),  # 仅包含本地分片
        "optimizer_state_dict": optimizer.state_dict(),  # 仅包含本地分片
        "epoch": epoch,
        "global_step": global_step,
    }
    path = f"{save_dir}/checkpoint_step_{global_step}_rank_{rank}.pt"
    torch.save(checkpoint, path)


def load_checkpoint(model, optimizer, scaler, scheduler, checkpoint_path):
    """加载检查点"""
    # DDP: 所有rank加载相同的checkpoint
    checkpoint = torch.load(checkpoint_path, map_location="cuda")
    model.load_state_dict(checkpoint["model_state_dict"])
    optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
    if scaler and checkpoint.get("scaler_state_dict"):
        scaler.load_state_dict(checkpoint["scaler_state_dict"])
    return checkpoint["epoch"], checkpoint["global_step"]


def save_consolidated_model(model, save_path):
    """将DDP模型保存为单文件 (用于推理部署)"""
    if dist.get_rank() == 0:
        # DDP.module 是去掉DDP包装后的原始模型
        torch.save(model.module.state_dict(), save_path)
        print(f"Consolidated model saved to {save_path}")
```

### 8.3 FSDP下的分片检查点

```
FSDP Checkpoint 策略:
======================

选项1: 全量检查点 (FULL_STATE_DICT)
  每个rank的state_dict包含完整模型
  缺点: 大模型时OOM

选项2: 分片检查点 (SHARDED_STATE_DICT)
  每个rank只保存自己的参数分片
  优点: 显存友好
  缺点: 加载时需要相同数量的GPU

选项3: 局部检查点 (LOCAL_STATE_DICT)
  类似分片但使用本地命名
  适用于单机多卡的场景

from torch.distributed.fsdp import FullyShardedDataParallel as FSDP
from torch.distributed.fsdp import StateDictType

# 保存分片检查点:
with FSDP.state_dict_type(model, StateDictType.SHARDED_STATE_DICT):
    state_dict = model.state_dict()
    torch.save(state_dict, f"ckpt_rank_{rank}.pt")

# 保存完整检查点 (仅rank 0):
with FSDP.state_dict_type(model, StateDictType.FULL_STATE_DICT):
    state_dict = model.state_dict()
    if rank == 0:
        torch.save(state_dict, "ckpt_full.pt")
```

---

## 9. 容错与弹性训练

### 9.1 为什么需要容错

在大规模训练中，故障是常态而非例外：

```
训练规模与故障概率:
====================

GPU数量     | MTBF (平均无故障时间) | 训练1个月不出故障的概率
------------+-----------------------+------------------------
   8        | ~30-90天              | ~72%-36%
  64        | ~10-20天              | ~5%-22%
 512        | ~1-5天               | ~0%
1024        | ~数小时               | ~0%

结论: 超过100张GPU时，一次完整训练几乎必然遇到硬件故障。
```

### 9.2 elastic training (torchelastic)

弹性训练的核心：允许训练过程中动态增减GPU数量。

```
弹性训练工作流:
================

正常训练:
  [GPU0] [GPU1] [GPU2] [GPU3]  →  world_size=4
    |       |       |       |
    +---+---+---+---+---+---+
               |
         训练进行中...

GPU2故障:
  [GPU0] [GPU1] [FAIL] [GPU3]
    |       |               |
    +---+---+---  M - E - T - A - D - A - T - A  ---+
               |                                      |
         检测到故障                                    |
                                                   重新集合 (re-rendezvous)
                                                      |
  [GPU0] [GPU1] [GPU3]  →  world_size=3              |
    |       |       |                                  |
    +---+---+---+---+                                  |
               |                                       |
         加载最近检查点 <--------------------------------+
               |
         从断点恢复训练
```

### 9.3 torchrun 弹性训练配置

```python
# ============================================
# 弹性训练的代码适配
# ============================================

import torch
import torch.distributed as dist
import torch.distributed.elastic as elastic

def main():
    # 1. 初始化 (torchrun会自动设置环境变量)
    dist.init_process_group(backend="nccl")
    local_rank = int(os.environ["LOCAL_RANK"])
    rank = dist.get_rank()
    world_size = dist.get_world_size()

    torch.cuda.set_device(local_rank)

    # 2. 创建模型
    model = MyModel().cuda()
    ddp_model = DDP(model, device_ids=[local_rank])
    optimizer = torch.optim.AdamW(ddp_model.parameters())
    scaler = GradScaler()  # if FP16

    # 3. 尝试加载检查点
    start_epoch = 0
    global_step = 0
    checkpoint_path = find_latest_checkpoint("/checkpoints/")
    if checkpoint_path:
        start_epoch, global_step = load_checkpoint(
            ddp_model, optimizer, scaler, checkpoint_path)
        if rank == 0:
            print(f"Resumed from {checkpoint_path}, "
                  f"epoch={start_epoch}, step={global_step}")

    # 4. 数据加载器: 需要考虑world_size变化
    sampler = DistributedSampler(dataset, num_replicas=world_size,
                                 rank=rank, shuffle=True)
    dataloader = DataLoader(dataset, batch_size=per_gpu_bs,
                            sampler=sampler)

    # 5. 训练循环 (与之前相同)
    for epoch in range(start_epoch, num_epochs):
        sampler.set_epoch(epoch)
        for step, batch in enumerate(dataloader):
            # ... 训练代码
            if global_step % checkpoint_interval == 0:
                save_checkpoint(model, optimizer, scaler,
                                epoch, global_step, "/checkpoints/")
                # 关键: 保存后barrier确保所有rank都完成
                dist.barrier()
            global_step += 1

    dist.destroy_process_group()


if __name__ == "__main__":
    main()
```

### 9.4 节点故障恢复策略

```
故障恢复的层次:
================

层次1: Job级别 (torchrun/torchelastic)
  - 检测进程崩溃
  - 自动重启所有进程
  - 从最新检查点恢复
  - 重新建立集合通信组

层次2: 训练框架级别
  - 自动保存检查点 (每隔N步)
  - 监控GPU健康状态
  - 日志和指标持久化

层次3: 集群级别 (Kubernetes/Slurm)
  - 节点健康检查
  - 自动重新调度
  - 资源分配

最佳实践:
  1. 每100-500步保存检查点
  2. 保留最近K个检查点 (防止检查点损坏)
  3. 验证检查点完整性 (计算hash)
  4. 独立保存state_dict (不依赖pickle的完整性)
```

---

## 10. torchrun：多节点启动器

### 10.1 什么是 torchrun

torchrun 是 PyTorch 官方提供的多节点多GPU训练启动器。它取代了旧的 `torch.distributed.launch`。

```
torchrun 的功能:
=================
1. 在多台机器的多个GPU上启动训练进程
2. 设置所有必要的环境变量 (RANK, WORLD_SIZE, LOCAL_RANK等)
3. 处理故障恢复 (elastic模式)
4. 管理进程的启动和终止
```

### 10.2 基本用法

```bash
# ============================================
# torchrun 命令行示例
# ============================================

# 单机8GPU:
torchrun --nproc_per_node=8 train.py

# 多机多GPU (2节点, 每节点8GPU):
# 在主节点上:
torchrun \
  --nnodes=2 \
  --nproc_per_node=8 \
  --node_rank=0 \
  --master_addr="192.168.1.100" \
  --master_port=29500 \
  train.py

# 在从节点上:
torchrun \
  --nnodes=2 \
  --nproc_per_node=8 \
  --node_rank=1 \
  --master_addr="192.168.1.100" \
  --master_port=29500 \
  train.py

# 弹性训练模式:
torchrun \
  --nnodes=1:4 \        # 最少1个节点, 最多4个节点
  --nproc_per_node=8 \
  --max_restarts=3 \     # 最多自动重启3次
  --rdzv_backend=c10d \  # rendezvous后端
  --rdzv_endpoint="192.168.1.100:29500" \
  train.py
```

### 10.3 Rendezvous 机制

Rendezvous（集合）是所有节点互相发现并建立通信组的过程。

```
Rendezvous 工作流程:
====================

                     +------------------+
                     | Rendezvous Server|
                     | (C10d backend)   |
                     +--------+---------+
                              |
             +----------------+----------------+
             |                |                |
    +--------v--------+  +---v-----------+  +-v--------------+
    |  Node 0 (rank=0)|  | Node 1        |  | Node 2         |
    |  join group     |  | join group    |  | join group     |
    +-----------------+  +---------------+  +-----------------+

1. 每个节点/进程向 rendezvous server 注册
2. Server 等待所有参与者到齐 (min_nodes ≤ 实际节点数 ≤ max_nodes)
3. 所有参与者到齐后，server 分配 rank
4. 通过 all_gather 交换网络地址信息
5. 建立全局通信组
6. 开始训练

如果 elastic:
  - 训练过程中 monitor thread 监控成员变化
  - 检测到成员离开 → 通知所有进程
  - 所有进程重新 rendezvous
  - 从检查点恢复
```

### 10.4 环境变量

```python
# ============================================
# torchrun 设置的环境变量 (在训练脚本中使用)
# ============================================

import os

# 全局信息
LOCAL_WORLD_SIZE = int(os.environ["LOCAL_WORLD_SIZE"])  # 本机GPU数
WORLD_SIZE = int(os.environ["WORLD_SIZE"])              # 全局GPU总数
RANK = int(os.environ["RANK"])                          # 全局rank
LOCAL_RANK = int(os.environ["LOCAL_RANK"])              # 本机内rank (0到LOCAL_WORLD_SIZE-1)

# 网络信息
MASTER_ADDR = os.environ["MASTER_ADDR"]   # 主节点IP
MASTER_PORT = os.environ["MASTER_PORT"]   # 主节点端口

# Rendezvous 信息
GROUP_RANK = int(os.environ.get("GROUP_RANK", 0))  # 节点组rank
ROLE_RANK = int(os.environ.get("ROLE_RANK", RANK))  # 角色内rank

print(f"Global: rank={RANK}/{WORLD_SIZE}, "
      f"Local: rank={LOCAL_RANK}/{LOCAL_WORLD_SIZE}, "
      f"Master: {MASTER_ADDR}:{MASTER_PORT}")
```

---

## 11. FSDP 入门

### 11.1 DDP 的局限与 FSDP 的动机

```
DDP的问题:
===========
每个GPU存储完整的:
- 模型参数 (FP16: 2×Φ bytes)
- 梯度 (FP16: 2×Φ bytes)
- 优化器状态 (FP32: 8×Φ bytes for Adam)
总计: 12×Φ bytes per GPU

对于7B模型: 7B × 12 = 84GB → 勉强能放进80GB A800
对于13B模型: 13B × 12 = 156GB → 单卡放不下！
对于70B模型: 70B × 12 = 840GB → 需要11张卡才能做DDP！

FSDP (Fully Sharded Data Parallelism):
=======================================
核心思想: 不只在数据上分片，在模型参数上也分片！
不要在每个GPU上存完整模型，而是把参数切分到所有GPU。

FSDP = DDP + ZeRO-3
源自 Microsoft DeepSpeed ZeRO 论文的思想
```

### 11.2 FSDP 的参数量化

```
FSDP 显存节省分析 (8 GPUs, 7B模型, Adam优化器, FP16):
======================================================

                    DDP         FSDP (ZeRO-3)
参数 (FP16):        14 GB       14/8 = 1.75 GB
参数 (FP32 master): 28 GB       28/8 = 3.50 GB
梯度:               14 GB       14/8 = 1.75 GB
优化器 (Adam):      56 GB       56/8 = 7.00 GB
激活值:            ~30 GB      ~30 GB
-------------------------------------------------
每GPU总计:         ~142 GB     ~44.0 GB

节省: ~69% 显存！
```

### 11.3 FSDP 工作原理

```
FSDP 训练一步的流程:
=====================

All-Gather 阶段 (收集参数分片):
  [P₀]  [P₁]  [P₂]  [P₃]  →  All-Gather  →  [P_all] [P_all] [P_all] [P_all]
  (每个GPU持有1/4的参数)                       (每个GPU获得全部参数)

前向计算:
  [P_all] → forward → activations
  计算完成后 → 释放非本地参数分片 (释放显存!)

反向计算:
  再次 All-Gather 参数分片
  compute gradients
  只保留本地分片的梯度 → 释放非本地梯度

Reduce-Scatter 梯度:
  [g₀] [g₁] [g₂] [g₃] → Reduce-Scatter → [G₀] [G₁] [G₂] [G₃]
  (每个GPU保留一份聚合梯度分片)

优化器更新:
  只更新本地参数分片 (因为优化器状态也只在本地的分片上)

关键: 前向和反向时短暂All-Gather获取完整参数, 用完立刻释放!
     "用得着才拿, 用完就放"
```

### 11.4 FSDP 代码示例

```python
# ============================================
# FSDP 基础用法
# ============================================

import torch
import torch.distributed as dist
from torch.distributed.fsdp import (
    FullyShardedDataParallel as FSDP,
    MixedPrecision,
    ShardingStrategy,
    BackwardPrefetch,
    StateDictType,
)
from torch.distributed.fsdp.wrap import (
    transformer_auto_wrap_policy,
    size_based_auto_wrap_policy,
)

# 初始化
dist.init_process_group(backend="nccl")
local_rank = dist.get_rank()
torch.cuda.set_device(local_rank)

# 创建模型
model = MyTransformerModel().cuda()

# FSDP配置
mixed_precision_policy = MixedPrecision(
    param_dtype=torch.bfloat16,      # 参数用BF16存储
    reduce_dtype=torch.bfloat16,     # 梯度reduce用BF16
    buffer_dtype=torch.bfloat16,     # buffer用BF16
)

# 自动包装策略: 每个TransformerBlock成为一个FSDP unit
from my_model import TransformerBlock
auto_wrap_policy = functools.partial(
    transformer_auto_wrap_policy,
    transformer_layer_cls={TransformerBlock},
)

# 应用FSDP
fsdp_model = FSDP(
    model,
    auto_wrap_policy=auto_wrap_policy,
    sharding_strategy=ShardingStrategy.FULL_SHARD,  # ZeRO-3
    mixed_precision=mixed_precision_policy,
    backward_prefetch=BackwardPrefetch.BACKWARD_PRE, # 预取下一层参数
    device_id=torch.cuda.current_device(),
    cpu_offload=False,  # 是否offload到CPU
)

optimizer = torch.optim.AdamW(fsdp_model.parameters(), lr=1e-4)

for batch in dataloader:
    x, y = batch[0].cuda(), batch[1].cuda()
    optimizer.zero_grad()
    # autocast与FSDP配合
    with torch.autocast("cuda", dtype=torch.bfloat16):
        output = fsdp_model(x)
        loss = torch.nn.functional.cross_entropy(output, y)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(fsdp_model.parameters(), max_norm=1.0)
    optimizer.step()
```

### 11.5 FSDP 的 Sharding 策略

```
FSDP Sharding Strategies:
==========================

1. NO_SHARD: 等效DDP, 不分片
2. SHARD_GRAD_OP: 只分片梯度和优化器 (ZeRO-2)
3. FULL_SHARD: 分片参数、梯度和优化器 (ZeRO-3)
4. HYBRID_SHARD: 节点内FULL_SHARD, 节点间NO_SHARD

选择建议:
- 模型放得下: DDP + gradient accumulation
- 模型勉强放下: FSDP + SHARD_GRAD_OP (ZeRO-2)
- 模型放不下: FSDP + FULL_SHARD (ZeRO-3)
- 多节点: FSDP + HYBRID_SHARD (平衡通信)
```

---

## 12. 计算-通信重叠

### 12.1 重叠的核心原则

```
理想情况: 通信时间完全被计算时间遮蔽
========================================

没有重叠:
  |--- compute ---|-- all-reduce --|--- compute ---|-- all-reduce --|
  |   layer N     | (wait!)        |   layer N-1   | (wait!)        |
  time →                                          wasted!

有重叠:
  |--- compute ---|---- compute ----|
  |   layer N     |   layer N-1     |
  |-- all-reduce -|-- all-reduce ---|
  |   layer N+1   |   layer N       |
  time →                      all-reduce 被完全隐藏！
```

### 12.2 梯度预除 (Gradient Pre-Division)

```python
# ============================================
# 梯度预除: 让all-reduce更快
# ============================================

# 默认行为:
# 1. backward计算梯度 g_i  (每个GPU)
# 2. all-reduce(Σg_i)      (求和)
# 3. g = Σg_i / world_size (求平均)

# 梯度预除:
# 1. backward计算梯度 g_i
# 2. g_i = g_i / world_size  (先在本GPU除！)
# 3. all-reduce(Σ(g_i / world_size))
#    注意: all_reduce默认是SUM
#    如果用SUM: Σ(g_i / world_size) = (Σg_i) / world_size ✓
#    如果用AVG: AVG(g_i / world_size) = (Σg_i) / world_size² ✗

# DDP中启用梯度预除:
ddp_model = DDP(
    model,
    device_ids=[local_rank],
    gradient_as_bucket_view=True,  # 使用bucket view (零拷贝)
    # PyTorch 2.0+ 已内置梯度预除优化
)
```

### 12.3 异步 All-Reduce 与 CUDA Stream

```
CUDA Stream 与通信:
====================

默认流 (Stream 0):
  所有操作都在同一个流上，串行执行

多流 (Multiple Streams):
  Stream 1: 计算后续层的梯度
  Stream 2: 通信 (all-reduce) 前序层的梯度
  两个流可以真正并行！

DDP内部实现:
  for param in reversed(parameters):
      # 在计算流上启动反向传播
      param.backward_hook(grad):
          bucket.add(param.grad)
          if bucket.full():
              # 在独立的通信流上启动异步all-reduce
              work = dist.all_reduce(bucket, async_op=True)
              # 计算流继续反向传播，不等待all-reduce完成

  在optimizer.step()之前:
      # 确保所有通信完成
      for work in pending_all_reduce_works:
          work.wait()
```

### 12.4 InfiniBand 网络拓扑

```
多节点通信拓扑:
================

单节点内 (NVLink/NVSwitch):
  GPU0 ←─ NVLink 600GB/s ─→ GPU1
  GPU2 ←─────────────────→ GPU3
  ... (all-to-all through NVSwitch)

跨节点 (InfiniBand / RoCE):
  Node 0                         Node 1
  +--------+                     +--------+
  | GPU0 ──|── NIC0 ──── IB ────|── NIC0 ──|── GPU0 |
  | GPU1 ──|── NIC1 ──── IB ────|── NIC1 ──|── GPU1 |
  +--------+                     +--------+

  HCA (Host Channel Adapter): 每张GPU对应一张网卡 (rail-optimized)
  这确保了跨节点通信的满带宽
```

---

## 13. 实战：8×A800 训练 Qwen-7B

### 13.1 硬件配置

```
硬件环境:
==========

8 × NVIDIA A800 80GB PCIe
  - 显存: 80GB HBM2e
  - 带宽: 2TB/s
  - NVLink: 600GB/s (双向) through NVSwitch
  - PCIe 4.0 ×16: ~32GB/s
  - FP16算力: 312 TFLOPS

1 × NVSwitch
  - 全互联: 任意两GPU间600GB/s

网络: 2 × 200Gbps InfiniBand HDR (跨节点)
  - 有效带宽: ~25GB/s per NIC
```

### 13.2 模型配置

```
Qwen-7B 配置:
==============

参数总量: 7.7B
层数: 32
隐藏维度: 4096
中间维度: 11008 (≈ 4096 × 2.68)
注意力头数: 32
KV头数: 32 (MHA非GQA)
词表大小: 151936
最大序列长度: 8192
```

### 13.3 完整训练脚本

```python
#!/usr/bin/env python3
# ============================================
# train_qwen_7b_ddp.py
# 使用 8×A800 DDP 训练 Qwen-7B
# ============================================

import os
import math
import logging
import argparse
from pathlib import Path

import torch
import torch.nn as nn
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler
from torch.cuda.amp import autocast, GradScaler
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    get_cosine_schedule_with_warmup,
)
from datasets import load_dataset

# ============================================
# 配置
# ============================================
class TrainingConfig:
    # 模型
    model_name = "Qwen/Qwen-7B"

    # 分布式
    num_gpus = 8

    # 数据
    per_gpu_batch_size = 2         # 每个GPU的micro batch
    gradient_accumulation_steps = 16 # 梯度累积
    # effective_batch_size = 2 × 16 × 8 = 256
    max_seq_length = 2048

    # 优化器
    learning_rate = 3e-4
    weight_decay = 0.1
    adam_beta1 = 0.9
    adam_beta2 = 0.95
    max_grad_norm = 1.0

    # 学习率调度
    warmup_steps = 2000
    total_steps = 100000
    lr_schedule = "cosine"

    # 混合精度
    use_bf16 = True                # A800支持BF16

    # 检查点
    save_dir = "/checkpoints/qwen-7b"
    save_interval = 1000           # 每1000步保存
    log_interval = 10


# ============================================
# 训练主函数
# ============================================
def main():
    config = TrainingConfig()
    args = parse_args()

    # 1. 初始化分布式
    dist.init_process_group(backend="nccl")
    local_rank = int(os.environ["LOCAL_RANK"])
    rank = dist.get_rank()
    world_size = dist.get_world_size()

    torch.cuda.set_device(local_rank)

    if rank == 0:
        logging.basicConfig(level=logging.INFO)
        logging.info(f"World size: {world_size}")
        logging.info(f"Effective batch size: "
                     f"{config.per_gpu_batch_size} × "
                     f"{config.gradient_accumulation_steps} × "
                     f"{world_size} = "
                     f"{config.per_gpu_batch_size * config.gradient_accumulation_steps * world_size}")

    # 2. 加载模型
    if rank == 0:
        logging.info("Loading model...")
    model = AutoModelForCausalLM.from_pretrained(
        config.model_name,
        torch_dtype=torch.bfloat16 if config.use_bf16 else torch.float16,
        trust_remote_code=True,
        use_cache=False,  # 训练时关闭KV cache
    )
    model.gradient_checkpointing_enable()  # 激活检查点
    model = model.cuda()

    # 3. 包装为DDP
    ddp_model = DDP(
        model,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=False,  # 提高效率
        gradient_as_bucket_view=True,
    )

    # 4. 优化器
    # 分离weight decay参数
    decay_params = []
    no_decay_params = []
    for name, param in ddp_model.named_parameters():
        if not param.requires_grad:
            continue
        if "bias" in name or "layernorm" in name or "norm" in name:
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    optimizer = torch.optim.AdamW(
        [
            {"params": decay_params, "weight_decay": config.weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ],
        lr=config.learning_rate,
        betas=(config.adam_beta1, config.adam_beta2),
        eps=1e-8,
    )

    # 5. 学习率调度
    scheduler = get_cosine_schedule_with_warmup(
        optimizer,
        num_warmup_steps=config.warmup_steps,
        num_training_steps=config.total_steps,
    )

    # 6. 数据加载
    tokenizer = AutoTokenizer.from_pretrained(
        config.model_name, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    dataset = load_dataset(args.dataset_path, split="train")

    def tokenize_fn(examples):
        return tokenizer(
            examples["text"],
            max_length=config.max_seq_length,
            truncation=True,
            padding="max_length",
        )

    tokenized_dataset = dataset.map(
        tokenize_fn, batched=True, remove_columns=dataset.column_names)

    sampler = DistributedSampler(
        tokenized_dataset,
        num_replicas=world_size,
        rank=rank,
        shuffle=True,
    )
    dataloader = DataLoader(
        tokenized_dataset,
        batch_size=config.per_gpu_batch_size,
        sampler=sampler,
        num_workers=4,
        pin_memory=True,
        drop_last=True,
    )

    # 7. 混合精度
    scaler = None if config.use_bf16 else GradScaler()

    # 8. 训练循环
    global_step = 0
    total_loss = 0.0
    optimizer.zero_grad()

    for epoch in range(10):  # 简化的epoch数
        sampler.set_epoch(epoch)

        for batch_idx, batch in enumerate(dataloader):
            # ---- 前向 ----
            input_ids = batch["input_ids"].cuda(non_blocking=True)
            attention_mask = batch["attention_mask"].cuda(non_blocking=True)
            labels = batch.get("labels")
            if labels is not None:
                labels = labels.cuda(non_blocking=True)
            else:
                labels = input_ids.clone()  # 自回归

            # no_sync: 优化梯度累积
            is_last_micro_step = (
                (batch_idx + 1) % config.gradient_accumulation_steps == 0
            )
            sync_context = (
                ddp_model.no_sync()
                if not is_last_micro_step
                else torch.enable_grad()
            )

            with sync_context:
                if config.use_bf16:
                    with autocast(dtype=torch.bfloat16):
                        outputs = ddp_model(
                            input_ids=input_ids,
                            attention_mask=attention_mask,
                            labels=labels,
                        )
                        loss = outputs.loss
                        loss = loss / config.gradient_accumulation_steps
                    loss.backward()
                else:
                    with autocast():
                        outputs = ddp_model(
                            input_ids=input_ids,
                            attention_mask=attention_mask,
                            labels=labels,
                        )
                        loss = outputs.loss
                        loss = loss / config.gradient_accumulation_steps
                    scaler.scale(loss).backward()

            total_loss += loss.item()

            # ---- 更新 ----
            if is_last_micro_step:
                if config.use_bf16:
                    # 梯度裁剪
                    torch.nn.utils.clip_grad_norm_(
                        ddp_model.parameters(), config.max_grad_norm)
                    optimizer.step()
                else:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        ddp_model.parameters(), config.max_grad_norm)
                    scaler.step(optimizer)
                    scaler.update()

                scheduler.step()
                optimizer.zero_grad()
                global_step += 1

                # ---- 日志 ----
                if rank == 0 and global_step % config.log_interval == 0:
                    avg_loss = total_loss / (
                        config.log_interval * config.gradient_accumulation_steps
                    )
                    current_lr = scheduler.get_last_lr()[0]
                    logging.info(
                        f"Step: {global_step:6d} | "
                        f"Loss: {avg_loss:.4f} | "
                        f"LR: {current_lr:.2e} | "
                        f"Scale: {scaler.get_scale() if scaler else 'N/A'}"
                    )
                    total_loss = 0.0

                # ---- 检查点 ----
                if (global_step % config.save_interval == 0 and
                        rank == 0):
                    checkpoint = {
                        "model": ddp_model.module.state_dict(),
                        "optimizer": optimizer.state_dict(),
                        "scheduler": scheduler.state_dict(),
                        "global_step": global_step,
                    }
                    save_path = os.path.join(
                        config.save_dir, f"step_{global_step}.pt")
                    torch.save(checkpoint, save_path)
                    logging.info(f"Checkpoint saved: {save_path}")

    dist.destroy_process_group()


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_path", type=str, required=True)
    return parser.parse_args()


if __name__ == "__main__":
    main()
```

### 13.4 启动命令

```bash
#!/bin/bash
# ============================================
# launch_training.sh
# ============================================

# 单机8GPU
torchrun \
    --standalone \
    --nnodes=1 \
    --nproc_per_node=8 \
    train_qwen_7b_ddp.py \
    --dataset_path /data/pretrain_corpus

# 多机32GPU (4节点,每节点8GPU)
# 在主节点 (node-0) 上执行:
torchrun \
    --nnodes=4 \
    --nproc_per_node=8 \
    --node_rank=0 \
    --master_addr="node-0" \
    --master_port=29500 \
    train_qwen_7b_ddp.py \
    --dataset_path /data/pretrain_corpus

# 在其他节点 (node-1, node-2, node-3) 上执行 (只需改--node_rank):
torchrun \
    --nnodes=4 \
    --nproc_per_node=8 \
    --node_rank=1 \  # 对应节点号
    --master_addr="node-0" \
    --master_port=29500 \
    train_qwen_7b_ddp.py \
    --dataset_path /data/pretrain_corpus
```

### 13.5 性能分析与优化建议

```
训练性能瓶颈分析:
==================

对于Qwen-7B在8×A800上的DDP训练，典型性能数据:

                      单步时间 (ms)     占比
前向传播               ~150             30%
反向传播 (计算)        ~250             50%
All-Reduce 通信        ~50              10%
优化器更新             ~30               6%
其他 (数据加载等)      ~20               4%
-------------------------------------------------
总计                   ~500             100%

优化建议:
1. 前向: 使用FlashAttention-2 → 预期节省30%前向时间
2. 反向: 使用activation checkpointing (已启用) → 交换计算换显存
3. 通信: 使用gradient pre-division (已默认) → 减少通信量
4. 数据: 增加num_workers, 使用prefetch → 消除数据加载瓶颈
5. 编译: torch.compile (PyTorch 2.0+) → 预期10-20%加速
6. 使用BF16而非FP16 → 省去loss scaling开销

预期优化后:
  单步时间: ~350ms (约30%加速)
```

---

## 15. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| DDP (DistributedDataParallel) | 每个 GPU 持有完整模型副本，梯度通过 All-Reduce 同步 —— 分布式训练的「入门方案」 | Ch.3 |
| NCCL (NVIDIA Collective Communications Library) | GPU 间通信的「高速公路」，所有分布式训练框架的底层通信引擎 | Ch.4 |
| All-Reduce | 所有 GPU 的梯度求平均后广播回每个 GPU —— DDP 每步必须完成的核心通信操作 | Ch.4.2 |
| 梯度累积 (Gradient Accumulation) | 多次 micro-batch 反向传播累积梯度后再更新参数，用时间换显存的「分期付款」策略 | Ch.5 |
| 混合精度 (BF16/FP16 + FP32) | 前向/反向用低精度提速省显存，master 权重用 FP32 保精度 —— A800 默认首选 BF16 | Ch.6 |
| Loss Scaling | FP16 训练时放大 loss 防止小梯度下溢为 0，BF16 不需要 —— A800 上推荐直接用 BF16 | Ch.6.3 |

## 16. A800 部署场景举例

**场景 1：单机 8×A800 80GB 用 DDP 训练 Qwen2.5-7B**

```
硬件: 1 节点 8×A800 80GB (NVSwitch 全互联, NVLink 600 GB/s 双向)
策略: DDP + BF16 + 梯度累积 + activation checkpointing

启动命令:
  torchrun --standalone --nnodes=1 --nproc_per_node=8 \
    train_ddp.py --per_gpu_batch_size 2 --gradient_accumulation_steps 16

等效 global batch size = 2 × 16 × 8 = 256
每 GPU 显存占用 ≈ 17 GB (模型 14GB + 优化器 ~1.8GB + 激活值若干)，80GB 充裕
单步耗时 ≈ 350-500ms，其中 All-Reduce 通信约 50ms（占比 ~10%）

验证通信带宽:
  python -c "
  import torch, torch.distributed as dist
  dist.init_process_group(backend='nccl')
  t = torch.randn(128*1024*1024//4, device='cuda')  # 128MB
  dist.all_reduce(t)  # 测时，预期 bus BW ≈ 340 GB/s (8 GPU ring)
  "
```

**场景 2：单机 8×A800 对梯度累积 + no_sync 的优化效果**

```
不做 no_sync: 每个 micro-step 都触发一次 All-Reduce → 16 次通信/step
使用 no_sync: 只有最后 1 个 micro-step 触发 All-Reduce → 1 次通信/step
通信时间节省: ~15/16 ≈ 93.75%

关键代码:
  with ddp_model.no_sync() if not is_last_step else contextlib.nullcontext():
      loss = ddp_model(x, y) / accumulation_steps
      loss.backward()
  # 只有 is_last_step 时触发梯度同步
```

## 17. 上下游串联

```
                          AI Infra 训练栈 — 本份文档的位置
                          
    ┌─────────────────────────────────────────────────────────┐
    │  数据加载 & 预处理                                       │
    │  (DistributedSampler, DataLoader, num_workers,          │
    │   pin_memory, prefetch)                                 │
    └──────────────────────────┬──────────────────────────────┘
                               │
                               ▼
    ┌─────────────────────────────────────────────────────────┐
    │  ★ 本份文档：分布式训练基础                               │
    │  ┌──────────┐ ┌──────────┐ ┌──────────────┐            │
    │  │ DDP 原理 │ │ NCCL 通信│ │ 混合精度 AMP │            │
    │  │ All-Reduce│ │ 梯度累积 │ │ 弹性训练     │            │
    │  └──────────┘ └──────────┘ └──────────────┘            │
    │  提供: 单机/多机数据并行的完整知识和实践代码              │
    └──────────────────────────┬──────────────────────────────┘
                               │
              ┌────────────────┼────────────────┐
              ▼                ▼                ▼
    ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐
    │ FSDP/       │  │ Megatron-LM │  │ Pipeline        │
    │ DeepSpeed   │  │ (TP)        │  │ Parallelism     │
    │ (ZeRO-1/2/3)│  │ 张量并行     │  │ (GPipe/1F1B)   │
    │ 内存优化     │  │ 层内拆分     │  │ 层间拆分        │
    └──────┬──────┘  └──────┬──────┘  └───────┬─────────┘
           │                │                 │
           └────────────────┼─────────────────┘
                            │
                            ▼
    ┌─────────────────────────────────────────────────────────┐
    │  3D 并行 (DP × TP × PP)                                  │
    │  Megatron-DeepSpeed / NeMo / ColossalAI                 │
    └─────────────────────────────────────────────────────────┘
```

本份文档（分布式训练基础）是整个训练栈的**入门层**。理解 DDP 和 NCCL 通信原语之后，才能理解 FSDP/ZeRO（在 DDP 基础上切分参数以省显存）和 Megatron TP（在单层内引入 All-Reduce 来切分矩阵乘法）。当前文档中的梯度累积、混合精度、elastic training 是每一层上游框架都会复用的基础设施。

---

## 14. 深入学习资源

### 14.1 论文

1. **PyTorch Distributed: Experiences on Accelerating Data Parallel Training**
   - Li et al., VLDB 2020
   - DDP设计和实现的权威文档
   - 链接: https://arxiv.org/abs/2006.15704

2. **ZeRO: Memory Optimizations Toward Training Trillion Parameter Models**
   - Rajbhandari et al., SC 2020
   - 提出了ZeRO-1/2/3三种优化级别，DeepSpeed的理论基础
   - 链接: https://arxiv.org/abs/1910.02054

3. **Mixed Precision Training**
   - Micikevicius et al., ICLR 2018
   - 改变了深度学习训练的方式
   - 链接: https://arxiv.org/abs/1710.03740

4. **Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism**
   - Shoeybi et al., 2019
   - 张量并行的奠基之作
   - 链接: https://arxiv.org/abs/1909.08053

5. **Efficient Large-Scale Language Model Training on GPU Clusters Using Megatron-LM**
   - Narayanan et al., SC 2021
   - 3D并行的全面分析
   - 链接: https://arxiv.org/abs/2104.04473

6. **GPipe: Efficient Training of Large Neural Networks using Pipeline Parallelism**
   - Huang et al., NeurIPS 2019
   - 流水线并行的开创性工作
   - 链接: https://arxiv.org/abs/1811.06965

7. **PyTorch FSDP: Experiences on Scaling Fully Sharded Data Parallel**
   - Zhao et al., VLDB 2023
   - FSDP设计的详细分析
   - 链接: https://arxiv.org/abs/2304.11277

### 14.2 官方文档与代码

1. **PyTorch Distributed 文档**
   - https://pytorch.org/docs/stable/distributed.html
   - 包含了DDP, FSDP, RPC, 通信后端的完整文档

2. **NCCL 官方文档**
   - https://docs.nvidia.com/deeplearning/nccl/user-guide/docs/
   - 通信算法的详细说明和性能调优指南

3. **torchrun 文档**
   - https://pytorch.org/docs/stable/elastic/run.html
   - 弹性训练的完整使用指南

4. **DeepSpeed GitHub**
   - https://github.com/microsoft/DeepSpeed
   - ZeRO优化的完整实现，代码质量高，适合学习

5. **FSDP 源码**
   - https://github.com/pytorch/pytorch/tree/main/torch/distributed/fsdp
   - PyTorch官方的FSDP实现

6. **NVIDIA Megatron-LM**
   - https://github.com/NVIDIA/Megatron-LM
   - 工业级的大模型训练框架，TP/PP的实现参考

7. **FlashAttention**
   - https://github.com/Dao-AILab/flash-attention
   - IO-aware的注意力实现，已成为标配

### 14.3 教程与博客

1. **PyTorch Distributed Overview (官方教程)**
   - https://pytorch.org/tutorials/beginner/dist_overview.html
   - 适合入门分布式训练的初学者

2. **Training Larger Models on a Single GPU with FSDP**
   - https://pytorch.org/tutorials/intermediate/FSDP_tutorial.html
   - 手把手教你使用FSDP

3. **Lilian Weng: How to Train Really Large Models on Many GPUs?**
   - https://lilianweng.github.io/posts/2021-09-25-train-large/
   - 全面的分布式训练综述，配图精美

4. **Hugging Face: Efficient Training on Multiple GPUs**
   - https://huggingface.co/docs/transformers/perf_train_gpu_many
   - HuggingFace生态中的分布式训练最佳实践

5. **NVIDIA Deep Learning Performance Documentation**
   - https://docs.nvidia.com/deeplearning/performance/
   - GPU训练性能优化的官方指南

### 14.4 实践建议

1. **从小规模开始**: 先在2-GPU上跑通DDP，再扩展到8-GPU，最后到多节点。
2. **用nsight systems profile**: NVIDIA Nsight Systems是理解你的训练瓶颈的最佳工具。
3. **注意batch normalization**: DDP下batch norm的统计量需要特殊处理（使用SyncBatchNorm）。
4. **随机种子**: 确保每个rank使用不同的种子，但保证可复现性。
5. **Pin memory**: 总是使用 `pin_memory=True` 在DataLoader中，减少CPU到GPU的数据传输延迟。
6. **non_blocking**: 使用 `non_blocking=True` 在 `.cuda()` 调用中，允许CPU和GPU的重叠。
7. **梯度检查点**: `model.gradient_checkpointing_enable()` 可以节省30-40%的激活内存。
8. **监控通信**: 使用 `torch.distributed.monitored_barrier` 检测死锁。

---

*本文档由分布式训练实践者编写，旨在提供从理论到实践的完整知识链条。分布式训练是一个快速发展的领域，建议持续关注PyTorch、DeepSpeed和Megatron-LM的最新进展。*
