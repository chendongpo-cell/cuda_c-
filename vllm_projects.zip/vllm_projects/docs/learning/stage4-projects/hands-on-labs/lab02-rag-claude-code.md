# 实验二：为 Claude Code 构建本地 RAG 系统

> **难度**: 进阶 | **预计时间**: 4-6 小时 | **前置知识**: Python, FastAPI, 向量检索基础  
> **目标**: 从零构建一个完整的 RAG（检索增强生成）系统，并通过 OpenAI 兼容 API 接入 Claude Code，使 Claude Code 能够回答基于你私有知识库的领域问题。

---

## 目录

1. [架构总览](#1-架构总览)
2. [环境准备](#2-环境准备)
3. [搭建 BGE-large-zh 嵌入服务](#3-搭建-bge-large-zh-嵌入服务)
4. [构建向量索引](#4-构建向量索引)
5. [实现检索-重排序-生成流水线](#5-实现检索-重排序-生成流水线)
6. [暴露 OpenAI 兼容 API](#6-暴露-openai-兼容-api)
7. [配置 Claude Code 使用本地端点](#7-配置-claude-code-使用本地端点)
8. [测试与验证](#8-测试与验证)
9. [性能优化](#9-性能优化)
10. [关键要点总结](#10-关键要点总结)
11. [深入学习资源](#11-深入学习资源)

---

## 1. 架构总览

### 1.1 整体架构图

```
+------------------------------------------------------------------+
|                        Claude Code (客户端)                        |
|   claude --api-base http://localhost:8000/v1                       |
|   用户提问  ──────────────────────────────────────►  本地 RAG API   |
+------------------------------------------------------------------+
                              │
                              ▼
+------------------------------------------------------------------+
|                    FastAPI 服务 (localhost:8000)                    |
|                                                                   |
|   POST /v1/chat/completions                                       |
|         │                                                         |
|         ▼                                                         |
|   ┌─────────────────────────────────────────────────────────┐    |
|   │              RAG Pipeline (检索增强生成流水线)              │    |
|   │                                                           │    |
|   │   用户问题                                                 │    |
|   │      │                                                    │    |
|   │      ▼                                                    │    |
|   │   ┌──────────┐    ┌──────────┐    ┌──────────┐          │    |
|   │   │ 1.嵌入   │───►│ 2.检索   │───►│ 3.重排序 │          │    |
|   │   │ Query    │    │ Top-K    │    │ Reranker │          │    |
|   │   └──────────┘    └──────────┘    └──────────┘          │    |
|   │                         │              │                  │    |
|   │                         ▼              ▼                  │    |
|   │                    ┌──────────────────────┐              │    |
|   │                    │   4.上下文拼接 + 生成  │              │    |
|   │                    │   Prompt Template → LLM│              │    |
|   │                    └──────────────────────┘              │    |
|   └─────────────────────────────────────────────────────────┘    |
|                                                                   |
+------------------------------------------------------------------+
                              │
                              ▼
+------------------------------------------------------------------+
|                        外部依赖服务                                 |
|                                                                   |
|   ┌──────────────────┐  ┌──────────────────┐  ┌───────────────┐  |
|   │ BGE-large-zh     │  │ FAISS/Chroma     │  │ LLM Backend   │  |
|   │ Embedding 服务    │  │ 向量数据库        │  │ (Claude/本地)  │  |
|   │ Port: 9001       │  │ 本地文件/内存     │  │               │  |
|   └──────────────────┘  └──────────────────┘  └───────────────┘  |
+------------------------------------------------------------------+
```

### 1.2 数据流详解

```
时间轴 ─────────────────────────────────────────────────────────────►

用户: "Claude Code 的 MCP 协议支持哪些传输方式？"
  │
  │ (1) HTTP POST /v1/chat/completions
  ▼
FastAPI 接收请求，提取 messages 数组
  │
  │ (2) 取最后一条 user message 作为查询
  ▼
Query Embedding
  query: "Claude Code 的 MCP 协议支持哪些传输方式？"
  │
  │ POST http://localhost:9001/embed
  │ Body: {"texts": ["Claude Code 的 MCP 协议支持..."]}
  ▼
Embedding Service (BGE-large-zh)
  返回: [1536-dim float vector]
  │
  │ (3) 向量检索
  ▼
FAISS Index.search(query_vector, top_k=10)
  返回: [(doc_id, distance), ...] 共 10 条
  │
  │ (4) 重排序 (Rerank)
  ▼
BGE-Reranker 或 Cross-Encoder
  对 10 条候选重新打分，保留 top_k=5
  返回: [(doc_id, rerank_score, text), ...] 共 5 条
  │
  │ (5) Prompt 构造
  ▼
System Prompt + Retrieved Context + User Query
  │
  │ (6) 调用 LLM
  ▼
LLM 生成回答 (可流式返回)
  │
  │ (7) 返回给 Claude Code
  ▼
Claude Code 收到 OpenAI 格式的响应
```

### 1.3 技术选型

| 组件 | 技术选型 | 理由 |
|------|---------|------|
| 嵌入模型 | BGE-large-zh-v1.5 (BAAI) | C-MTEB 中文榜单 Top-3，1024 维，本地部署 |
| 向量数据库 | FAISS (CPU) | 轻量级，无需额外服务，支持多种索引类型 |
| 重排序模型 | BGE-Reranker-v2-m3 (BAAI) | 多语言 Cross-Encoder，提升检索精度 |
| LLM 后端 | 多种选项 (见下文) | 支持 Anthropic API、本地模型、Ollama 等 |
| API 框架 | FastAPI + uvicorn | 异步支持、自动 OpenAPI 文档、高性能 |
| 嵌入服务 | 独立 Flask/FastAPI 进程 | 模型加载一次，多请求复用 |

---

## 2. 环境准备

### 2.1 系统要求

```
最低配置:
  - CPU: 4 核
  - 内存: 8 GB (推荐 16 GB)
  - 磁盘: 10 GB 可用空间
  - Python: 3.10+
  - 操作系统: Linux / macOS / WSL2

GPU 加速 (可选):
  - NVIDIA GPU + CUDA 11.8+
  - 显存: 4 GB+ (嵌入模型约 1.5 GB, 重排序约 2 GB)
```

### 2.2 项目目录结构

```
lab02-rag-claude-code/
├── data/
│   ├── raw/                  # 原始文档 (txt, pdf, md)
│   ├── chunks/               # 分块后的文本
│   └── index/                # FAISS 索引文件
├── models/                   # 下载的模型 (可选，或使用缓存)
├── src/
│   ├── embedding_service.py  # 嵌入服务
│   ├── build_index.py        # 构建向量索引
│   ├── rag_pipeline.py       # RAG 流水线核心
│   ├── reranker.py           # 重排序模块
│   ├── api_server.py         # FastAPI 服务
│   └── config.py             # 配置文件
├── tests/
│   ├── test_retrieval.py     # 检索质量测试
│   └── test_api.py           # API 测试
├── docs/                     # 领域文档 (示例)
├── requirements.txt
├── .env                      # 环境变量
└── README.md
```

### 2.3 创建项目并安装依赖

```bash
# 1. 创建项目目录
mkdir -p ~/lab02-rag-claude-code/{data/{raw,chunks,index},models,src,tests,docs}
cd ~/lab02-rag-claude-code

# 2. 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # Linux/macOS
# venv\Scripts\activate   # Windows

# 3. 升级 pip 和安装基础工具
pip install --upgrade pip setuptools wheel
```

**requirements.txt:**

```txt
# 核心依赖
fastapi==0.111.0
uvicorn[standard]==0.30.1
pydantic==2.7.4
python-dotenv==1.0.1

# 嵌入与 NLP
sentence-transformers==3.0.1
FlagEmbedding==1.2.11
torch==2.3.1

# 向量数据库
faiss-cpu==1.8.0
# 如果有 GPU: pip install faiss-gpu
chromadb==0.5.4

# API 客户端
httpx==0.27.0
openai==1.35.3
anthropic==0.31.1

# 文本处理
tiktoken==0.7.0
langchain-text-splitters==0.2.2

# 工具
rich==13.7.1
click==8.1.7
```

```bash
# 安装依赖
pip install -r requirements.txt

# 验证安装
python -c "import torch; print(f'PyTorch {torch.__version__}, CUDA: {torch.cuda.is_available()}')"
python -c "import faiss; print(f'FAISS {faiss.__version__}')"
```

### 2.4 配置文件

**src/config.py:**

```python
"""
全局配置文件
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# 加载 .env 文件
load_dotenv(Path(__file__).parent.parent / ".env")

# ── 项目路径 ───────────────────────────────────────────
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
CHUNKS_DIR = DATA_DIR / "chunks"
INDEX_DIR = DATA_DIR / "index"
MODELS_DIR = PROJECT_ROOT / "models"

# ── 嵌入模型配置 ───────────────────────────────────────
EMBEDDING_MODEL_NAME = os.getenv(
    "EMBEDDING_MODEL_NAME",
    "BAAI/bge-large-zh-v1.5"
)
EMBEDDING_DIM = 1024  # bge-large-zh-v1.5 输出维度
EMBEDDING_SERVICE_URL = os.getenv(
    "EMBEDDING_SERVICE_URL",
    "http://localhost:9001"
)
EMBEDDING_BATCH_SIZE = 32

# ── 重排序模型配置 ─────────────────────────────────────
RERANKER_MODEL_NAME = os.getenv(
    "RERANKER_MODEL_NAME",
    "BAAI/bge-reranker-v2-m3"
)

# ── 分块配置 ──────────────────────────────────────────
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "512"))    # 每个 chunk 的 token 数
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "64"))  # 重叠 token 数

# ── 检索配置 ──────────────────────────────────────────
RETRIEVAL_TOP_K = int(os.getenv("RETRIEVAL_TOP_K", "10"))   # 初检返回数
RERANK_TOP_K = int(os.getenv("RERANK_TOP_K", "5"))          # 重排序后保留数
SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", "0.0"))

# ── LLM 后端配置 ──────────────────────────────────────
LLM_BACKEND = os.getenv("LLM_BACKEND", "anthropic")  # anthropic | openai | ollama | local
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-4-20250514")

# Anthropic
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

# OpenAI 兼容
LLM_API_BASE = os.getenv("LLM_API_BASE", "https://api.anthropic.com")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")

# ── 服务配置 ──────────────────────────────────────────
API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", "8000"))
EMBEDDING_SERVICE_HOST = os.getenv("EMBEDDING_SERVICE_HOST", "0.0.0.0")
EMBEDDING_SERVICE_PORT = int(os.getenv("EMBEDDING_SERVICE_PORT", "9001"))

# ── 确保目录存在 ──────────────────────────────────────
for d in [DATA_DIR, RAW_DATA_DIR, CHUNKS_DIR, INDEX_DIR, MODELS_DIR]:
    d.mkdir(parents=True, exist_ok=True)
```

**.env 文件示例:**

```bash
# LLM Backend
LLM_BACKEND=anthropic
ANTHROPIC_API_KEY=sk-ant-api03-your-key-here
LLM_MODEL=claude-sonnet-4-20250514

# Embedding
EMBEDDING_MODEL_NAME=BAAI/bge-large-zh-v1.5

# Retrieval
CHUNK_SIZE=512
CHUNK_OVERLAP=64
RETRIEVAL_TOP_K=10
RERANK_TOP_K=5

# Service
API_HOST=0.0.0.0
API_PORT=8000
EMBEDDING_SERVICE_PORT=9001
```

---

## 3. 搭建 BGE-large-zh 嵌入服务

### 3.1 为什么独立部署嵌入服务

```
┌──────────────────────────────────────────────────────────────┐
│                  独立嵌入服务的优势                             │
│                                                              │
│  1. 模型常驻内存 ─ 避免每次请求都加载模型 (节省 5-10 秒)        │
│  2. 独立扩缩 ─ 嵌入和 API 可分开部署到不同机器                  │
│  3. GPU 独占 ─ 嵌入服务独占 GPU, API 服务用 CPU                │
│  4. 多消费者 ─ 多个 API 实例可共享一个嵌入服务                  │
│  5. 故障隔离 ─ 嵌入崩溃不影响 API 路由层                       │
└──────────────────────────────────────────────────────────────┘
```

### 3.2 BGE 模型介绍

```
BGE (BAAI General Embedding) 系列 ─ BAAI (北京智源人工智能研究院)

  bge-large-zh-v1.5:
  ├── 参数量:    326M
  ├── 向量维度:  1024
  ├── 最大长度:  512 tokens
  ├── 训练数据:  C-MTEB 中文基准 (检索、聚类、语义相似度等)
  ├── 指令格式:  "为这个句子生成表示以用于检索相关文章：" + text
  ├── 归一化:    是 (L2 归一化后用于余弦相似度)
  └── 优势:      中文检索精度高，支持 instruction-aware 嵌入

  查询 vs 文档的嵌入方式不同:
  ┌──────────────────────────────────────────────────┐
  │  查询嵌入:                                        │
  │    encode(queries, instruction="为这个句子生成...") │
  │                                                   │
  │  文档嵌入:                                        │
  │    encode(documents, instruction="")  (空指令)     │
  └──────────────────────────────────────────────────┘
```

### 3.3 嵌入服务完整代码

**src/embedding_service.py:**

```python
"""
BGE-large-zh 嵌入服务
独立进程运行，接受 HTTP 请求返回向量

启动: python src/embedding_service.py
端口: 9001 (可配置)
"""

import sys
import time
import logging
from pathlib import Path
from contextlib import asynccontextmanager
from typing import List, Optional

import torch
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.config import (
    EMBEDDING_MODEL_NAME,
    EMBEDDING_SERVICE_HOST,
    EMBEDDING_SERVICE_PORT,
    EMBEDDING_BATCH_SIZE,
)

# ── 日志配置 ──────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("embedding-service")

# ── 全局模型实例 ──────────────────────────────────────
embedding_model = None
device = None


# ═══════════════════════════════════════════════════════════════
# 数据模型
# ═══════════════════════════════════════════════════════════════

class EmbedRequest(BaseModel):
    """嵌入请求"""
    texts: List[str] = Field(
        ..., min_length=1, max_length=256,
        description="待嵌入的文本列表，每条约 512 tokens 内"
    )
    instruction: Optional[str] = Field(
        default=None,
        description="BGE 查询指令。查询时使用指令，文档嵌入时留空"
    )
    normalize: bool = Field(
        default=True,
        description="是否 L2 归一化输出向量"
    )


class EmbedResponse(BaseModel):
    """嵌入响应"""
    embeddings: List[List[float]] = Field(..., description="向量列表")
    shape: List[int] = Field(..., description="[num_texts, dim]")
    model: str = Field(..., description="模型名称")
    elapsed_ms: float = Field(..., description="耗时 (毫秒)")


class HealthResponse(BaseModel):
    status: str
    model: str
    device: str
    dim: int


# ═══════════════════════════════════════════════════════════════
# 模型加载
# ═══════════════════════════════════════════════════════════════

def load_embedding_model(model_name: str):
    """
    加载 BGE 嵌入模型

    使用 sentence-transformers 加载模型。
    如果 GPU 可用则自动使用 CUDA。
    """
    global embedding_model, device

    logger.info(f"正在加载嵌入模型: {model_name}")

    # 检测设备
    if torch.cuda.is_available():
        device = "cuda"
        logger.info(f"检测到 GPU: {torch.cuda.get_device_name(0)}")
        logger.info(f"显存: {torch.cuda.get_device_properties(0).total_mem / 1024**3:.1f} GB")
    else:
        device = "cpu"
        logger.info("未检测到 GPU，使用 CPU 推理")

    try:
        from sentence_transformers import SentenceTransformer

        embedding_model = SentenceTransformer(
            model_name,
            device=device,
            trust_remote_code=True  # 部分 BGE 模型需要
        )

        # 预热 ─ 避免首次请求冷启动
        logger.info("预热模型中...")
        _ = embedding_model.encode(
            ["预热文本"],
            normalize_embeddings=True,
            show_progress_bar=False
        )

        dim = embedding_model.get_sentence_embedding_dimension()
        logger.info(f"模型加载完成 | 设备: {device} | 维度: {dim}")

        # 打印显存使用 (GPU 时)
        if device == "cuda":
            allocated = torch.cuda.memory_allocated() / 1024**2
            logger.info(f"GPU 显存占用: {allocated:.1f} MB")

        return embedding_model, dim

    except Exception as e:
        logger.error(f"模型加载失败: {e}")
        raise


# ═══════════════════════════════════════════════════════════════
# FastAPI 应用
# ═══════════════════════════════════════════════════════════════

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时加载模型
    logger.info("=" * 60)
    logger.info("BGE 嵌入服务启动中...")
    logger.info("=" * 60)

    model, dim = load_embedding_model(EMBEDDING_MODEL_NAME)
    app.state.model = model
    app.state.dim = dim

    logger.info(f"服务就绪 | 端口: {EMBEDDING_SERVICE_PORT} | 设备: {device}")
    yield

    # 关闭时清理
    logger.info("嵌入服务正在关闭...")
    if device == "cuda":
        torch.cuda.empty_cache()
    logger.info("嵌入服务已关闭")


app = FastAPI(
    title="BGE Embedding Service",
    version="1.0.0",
    lifespan=lifespan,
)


# ═══════════════════════════════════════════════════════════════
# API 路由
# ═══════════════════════════════════════════════════════════════

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """健康检查端点"""
    return HealthResponse(
        status="ok",
        model=EMBEDDING_MODEL_NAME,
        device=device or "unknown",
        dim=app.state.dim if app.state.dim else 0,
    )


@app.post("/embed", response_model=EmbedResponse)
async def embed_texts(request: EmbedRequest):
    """
    文本嵌入端点

    支持批量文本嵌入。查询时传 instruction，
    文档嵌入时 instruction 留空。

    Example:
      curl -X POST http://localhost:9001/embed \\
        -H "Content-Type: application/json" \\
        -d '{"texts": ["查询文本"], "instruction": "为这个句子生成表示以用于检索相关文章："}'
    """
    if app.state.model is None:
        raise HTTPException(status_code=503, detail="模型未加载")

    t_start = time.perf_counter()

    try:
        # BGE 模型的 instruction 前缀处理
        if request.instruction:
            texts_to_embed = [request.instruction + t for t in request.texts]
        else:
            texts_to_embed = request.texts

        # 批量编码
        embeddings = app.state.model.encode(
            texts_to_embed,
            normalize_embeddings=request.normalize,
            batch_size=EMBEDDING_BATCH_SIZE,
            show_progress_bar=False,
            convert_to_numpy=True,
        )

        elapsed_ms = (time.perf_counter() - t_start) * 1000

        logger.info(
            f"嵌入完成 | 文本数: {len(request.texts)} | "
            f"维度: {embeddings.shape[1]} | "
            f"耗时: {elapsed_ms:.1f} ms | "
            f"每条: {elapsed_ms / len(request.texts):.1f} ms"
        )

        return EmbedResponse(
            embeddings=embeddings.tolist(),
            shape=list(embeddings.shape),
            model=EMBEDDING_MODEL_NAME,
            elapsed_ms=elapsed_ms,
        )

    except Exception as e:
        logger.error(f"嵌入失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/embed/query")
async def embed_query(text: str):
    """
    便捷端点 ─ 单条查询嵌入 (自动添加 BGE 指令前缀)

    Example:
      curl -X POST "http://localhost:9001/embed/query?text=什么是RAG"
    """
    if not text or not text.strip():
        raise HTTPException(status_code=400, detail="text 参数不能为空")

    request = EmbedRequest(
        texts=[text],
        instruction="为这个句子生成表示以用于检索相关文章："
    )
    return await embed_texts(request)


@app.post("/embed/document")
async def embed_documents(texts: List[str]):
    """
    便捷端点 ─ 批量文档嵌入 (无指令前缀)

    Example:
      curl -X POST http://localhost:9001/embed/document \\
        -H "Content-Type: application/json" \\
        -d '["文档段落1", "文档段落2"]'
    """
    request = EmbedRequest(texts=texts, instruction="")
    return await embed_texts(request)


# ═══════════════════════════════════════════════════════════════
# 启动入口
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    uvicorn.run(
        "embedding_service:app",
        host=EMBEDDING_SERVICE_HOST,
        port=EMBEDDING_SERVICE_PORT,
        workers=1,  # 嵌入模型只能单 worker (显存限制)
        log_level="info",
    )
```

### 3.4 启动嵌入服务

```bash
# 终端 1 ─ 启动嵌入服务
cd ~/lab02-rag-claude-code
source venv/bin/activate
python src/embedding_service.py

# 预期输出:
# ============================================================
# BGE 嵌入服务启动中...
# ============================================================
# 正在加载嵌入模型: BAAI/bge-large-zh-v1.5
# 检测到 GPU: NVIDIA GeForce RTX 4090  (或 CPU)
# 预热模型中...
# 模型加载完成 | 设备: cuda | 维度: 1024
# GPU 显存占用: 1245.3 MB
# 服务就绪 | 端口: 9001 | 设备: cuda
# INFO:     Uvicorn running on http://0.0.0.0:9001
```

### 3.5 测试嵌入服务

```bash
# 终端 2 ─ 测试服务是否正常

# 1. 健康检查
curl -s http://localhost:9001/health | python -m json.tool
# 输出: {"status":"ok","model":"BAAI/bge-large-zh-v1.5","device":"cuda","dim":1024}

# 2. 单条查询嵌入
curl -s -X POST "http://localhost:9001/embed/query?text=什么是向量检索" | python -m json.tool
# 输出: 包含 1024 维向量的 JSON

# 3. 批量文档嵌入
curl -s -X POST http://localhost:9001/embed/document \
  -H "Content-Type: application/json" \
  -d '["文档段落一：RAG 是检索增强生成技术", "文档段落二：向量数据库用于存储嵌入向量"]' \
  | python -c "import sys,json; d=json.load(sys.stdin); print(f'Shape: {d[\"shape\"]}, Time: {d[\"elapsed_ms\"]:.1f}ms')"
# 输出: Shape: [2, 1024], Time: 15.2ms
```

---

## 4. 构建向量索引

### 4.1 文档处理流程

```
原始文档                       向量索引
─────────────────────────────────────────────────────────────►

  docs/                    chunks/              index/
  ├── claude-code.md  ─┐   ├── chunk_001.txt ─┐  ├── faiss.index
  ├── mcp-protocol.md  ├─► ├── chunk_002.txt  ├─► ├── metadata.json
  ├── api-guide.md    ─┘   ├── chunk_003.txt  │  └── id_map.pkl
  └── ...                  └── ...           ─┘

  步骤:
  1. 读取文档         → 原始文本
  2. 文本分块         → 重叠滑动窗口分块
  3. 调用嵌入服务     → 每个 chunk → 向量
  4. 构建 FAISS 索引  → 向量 → IndexFlatIP (内积/余弦相似度)
  5. 保存到磁盘       → 索引文件 + 元数据
```

### 4.2 准备领域文档

在本实验中，我们使用 Claude Code 官方文档作为领域知识。你也可以使用任何中文技术文档。

```bash
# 创建一些示例领域文档
cd ~/lab02-rag-claude-code

# 示例文档 1: Claude Code 入门
cat > docs/claude-code-intro.txt << 'EOF'
# Claude Code 概述

Claude Code 是 Anthropic 推出的一款命令行 AI 编程助手。它在终端中运行，
能够理解你的代码库并通过自然语言帮助你完成编程任务。

## 核心功能

1. 代码理解：Claude Code 能够理解整个代码库的上下文，包括函数调用关系、
   类继承体系等。

2. 文件编辑：可以直接创建、修改、删除文件，支持精确的字符串替换。

3. 命令执行：能够在沙箱环境中执行 bash 命令，运行测试、安装依赖等。

4. Git 操作：支持 git 工作流，能够创建分支、提交代码、创建 PR。

5. MCP 协议：通过 Model Context Protocol (MCP) 连接外部工具和数据源。

## 安装方式

npm install -g @anthropic-ai/claude-code
# 或者
claude  # 首次运行自动安装

## 认证

运行 claude 后，按照提示完成 Anthropic 账号认证。
支持 API Key 认证和 OAuth 登录两种方式。
EOF

# 示例文档 2: MCP 协议
cat > docs/mcp-protocol.txt << 'EOF'
# Model Context Protocol (MCP) 详解

MCP 是 Anthropic 推出的开放协议，用于标准化 AI 模型与外部工具、数据源
之间的通信。

## 核心概念

MCP 采用客户端-服务器架构：
- MCP Host: 运行 AI 模型的应用 (如 Claude Code)
- MCP Client: 与 MCP Server 建立连接的组件
- MCP Server: 提供工具、资源、提示词模板的服务端

## 传输方式

MCP 支持多种传输层协议：

1. stdio (标准输入输出)
   - 最常用的本地传输方式
   - MCP Server 作为子进程运行
   - 通过 stdin/stdout 进行 JSON-RPC 通信
   - 低延迟、零网络开销

2. SSE (Server-Sent Events) over HTTP
   - 适用于远程 MCP Server
   - 服务端通过 SSE 推送事件
   - 客户端通过 HTTP POST 发送请求
   - 支持跨网络部署

3. WebSocket (计划中)
   - 双向全双工通信
   - 适用于需要实时双向通信的场景

## 工具定义

MCP Server 通过 tools/list 方法暴露可用工具：

```json
{
  "name": "search_docs",
  "description": "搜索技术文档",
  "inputSchema": {
    "type": "object",
    "properties": {
      "query": {"type": "string", "description": "搜索关键词"}
    },
    "required": ["query"]
  }
}
```

## 资源配置

MCP Server 还可以暴露资源 (Resources) 和提示词模板 (Prompts)：
- Resources: 文件、数据库记录、API 响应等结构化数据
- Prompts: 预定义的提示词模板，帮助用户快速开始常见任务
EOF

# 示例文档 3: Claude Code 配置
cat > docs/claude-code-config.txt << 'EOF'
# Claude Code 配置指南

## 配置文件

Claude Code 使用 JSON 格式的配置文件，支持多个层级：

### 全局配置 (~/.claude/settings.json)

适用于所有项目的全局设置：

```json
{
  "model": "claude-sonnet-4-20250514",
  "theme": "dark",
  "permissions": {
    "allow": [
      "Bash(npm test:*)",
      "Bash(git:*)",
      "Read(/home/user/projects/*)"
    ],
    "deny": [
      "Bash(rm -rf /*)"
    ]
  }
}
```

### 项目配置 (.claude/settings.json)

项目级别的配置，覆盖全局设置：

```json
{
  "apiKeyHelper": "1password-cli get anthropic-api-key",
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit",
        "hooks": [{"command": "npx prettier --write $FILE_PATH"}]
      }
    ]
  }
}
```

### 本地配置 (.claude/settings.local.json)

个人本地覆盖，不提交到版本控制：

```json
{
  "model": "claude-opus-4-20250514",
  "env": {
    "DEBUG": "true",
    "NODE_ENV": "development"
  }
}
```

## API Base 配置

可以配置 Claude Code 使用自定义 API 端点：

```bash
# 命令行方式
claude --api-base http://localhost:8000/v1

# 环境变量方式
export ANTHROPIC_API_BASE=http://localhost:8000/v1
claude

# 配置文件方式
{
  "apiBase": "http://localhost:8000/v1"
}
```

这个功能使得我们可以将 Claude Code 指向本地的 RAG 代理服务。
EOF
```

### 4.3 文本分块器

**src/chunker.py:**

```python
"""
文本分块器 ─ 将文档拆分为适合嵌入和检索的段落
"""

import re
import json
import hashlib
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict

import tiktoken


@dataclass
class Chunk:
    """文档块"""
    chunk_id: str          # 唯一 ID
    doc_name: str          # 来源文档名
    text: str              # 文本内容
    token_count: int       # token 数量
    chunk_index: int       # 在文档中的序号
    start_char: int        # 在原文中的起始位置
    end_char: int          # 在原文中的结束位置
    metadata: Dict = None  # 额外元数据

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class TextChunker:
    """
    文本分块器

    使用滑动窗口方式将长文档分割为有重叠的文本块。
    支持中文和英文，使用 tiktoken 估算 token 数。

    ASCII 示意图:

        文档: "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        参数: chunk_size=8, chunk_overlap=2

        Chunk 0: [ABCDEFGH]
                      ────
        Chunk 1:     [GHIJKLMN]    (与 Chunk 0 重叠 "GH")
                          ────
        Chunk 2:         [MNOPQRST]
                              ────
        Chunk 3:             [STUVWXYZ]
    """

    def __init__(
        self,
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        tokenizer_name: str = "cl100k_base",
    ):
        """
        Args:
            chunk_size: 每个 chunk 的目标 token 数
            chunk_overlap: 相邻 chunk 的重叠 token 数
            tokenizer_name: tiktoken 分词器名称
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        try:
            self.tokenizer = tiktoken.get_encoding(tokenizer_name)
        except Exception:
            # 回退到简单字符估算 (中文约 1.5 字符/token)
            self.tokenizer = None

    def count_tokens(self, text: str) -> int:
        """估算文本的 token 数"""
        if self.tokenizer:
            return len(self.tokenizer.encode(text))
        # 回退: 中文约 1.5 字符/token, 英文约 4 字符/token
        chinese_chars = len(re.findall(r'[一-鿿]', text))
        other_chars = len(text) - chinese_chars
        return int(chinese_chars / 1.3 + other_chars / 3.5)

    def _split_by_paragraphs(self, text: str) -> List[str]:
        """先按段落分割"""
        # 按双换行或 Markdown 标题分割
        paragraphs = re.split(r'\n\s*\n|(?=\n#{1,6}\s)', text)
        return [p.strip() for p in paragraphs if p.strip()]

    def chunk_text(self, text: str, doc_name: str = "unknown") -> List[Chunk]:
        """
        将文本分割为 chunks

        策略:
          1. 先按段落分割
          2. 短段落合并直到接近 chunk_size
          3. 超长段落按句子进一步分割
          4. 相邻 chunk 保留 overlap

        Args:
            text: 原始文本
            doc_name: 文档名称

        Returns:
            Chunk 列表
        """
        paragraphs = self._split_by_paragraphs(text)
        chunks: List[Chunk] = []
        current_chunk_texts: List[str] = []
        current_tokens = 0
        chunk_index = 0
        char_position = 0

        for para in paragraphs:
            para_tokens = self.count_tokens(para)

            # 如果加入当前段落会超出 chunk_size
            if current_tokens + para_tokens > self.chunk_size and current_chunk_texts:
                # 保存当前 chunk
                chunk_text = "\n\n".join(current_chunk_texts)
                chunk_id = self._make_chunk_id(doc_name, chunk_text, chunk_index)

                chunks.append(Chunk(
                    chunk_id=chunk_id,
                    doc_name=doc_name,
                    text=chunk_text,
                    token_count=current_tokens,
                    chunk_index=chunk_index,
                    start_char=char_position,
                    end_char=char_position + len(chunk_text),
                    metadata={"source": doc_name},
                ))

                # 为 overlap 保留最后一个段落
                overlap_text = current_chunk_texts[-1] if self.chunk_overlap > 0 else ""
                current_chunk_texts = [overlap_text] if overlap_text else []
                current_tokens = self.count_tokens(overlap_text) if overlap_text else 0
                chunk_index += 1

            # 如果单个段落就超过 chunk_size，按句子拆分
            if para_tokens > self.chunk_size:
                sub_chunks = self._split_long_paragraph(
                    para, doc_name, chunk_index
                )
                chunks.extend(sub_chunks)
                chunk_index += len(sub_chunks)
                current_chunk_texts = []
                current_tokens = 0
            else:
                current_chunk_texts.append(para)
                current_tokens += para_tokens

            char_position += len(para) + 2  # +2 for \n\n

        # 处理最后一个 chunk
        if current_chunk_texts:
            chunk_text = "\n\n".join(current_chunk_texts)
            chunk_id = self._make_chunk_id(doc_name, chunk_text, chunk_index)
            chunks.append(Chunk(
                chunk_id=chunk_id,
                doc_name=doc_name,
                text=chunk_text,
                token_count=current_tokens,
                chunk_index=chunk_index,
                start_char=char_position,
                end_char=char_position + len(chunk_text),
                metadata={"source": doc_name},
            ))

        return chunks

    def _split_long_paragraph(
        self, text: str, doc_name: str, start_index: int
    ) -> List[Chunk]:
        """将超长段落按句子分割"""
        sentences = re.split(r'(?<=[。！？.!?])\s*', text)
        sentences = [s.strip() for s in sentences if s.strip()]

        chunks: List[Chunk] = []
        current_texts: List[str] = []
        current_tokens = 0
        chunk_index = start_index

        for sent in sentences:
            sent_tokens = self.count_tokens(sent)
            if current_tokens + sent_tokens > self.chunk_size and current_texts:
                chunk_text = "".join(current_texts)
                chunks.append(Chunk(
                    chunk_id=self._make_chunk_id(doc_name, chunk_text, chunk_index),
                    doc_name=doc_name,
                    text=chunk_text,
                    token_count=current_tokens,
                    chunk_index=chunk_index,
                    start_char=0, end_char=len(chunk_text),
                    metadata={"source": doc_name},
                ))
                # overlap
                overlap = current_texts[-1] if self.chunk_overlap > 0 and len(current_texts) > 1 else ""
                current_texts = [overlap] if overlap else []
                current_tokens = self.count_tokens(overlap) if overlap else 0
                chunk_index += 1
            current_texts.append(sent)
            current_tokens += sent_tokens

        if current_texts:
            chunk_text = "".join(current_texts)
            chunks.append(Chunk(
                chunk_id=self._make_chunk_id(doc_name, chunk_text, chunk_index),
                doc_name=doc_name,
                text=chunk_text,
                token_count=current_tokens,
                chunk_index=chunk_index,
                start_char=0, end_char=len(chunk_text),
                metadata={"source": doc_name},
            ))

        return chunks

    @staticmethod
    def _make_chunk_id(doc_name: str, text: str, index: int) -> str:
        """生成唯一的 chunk ID"""
        content_hash = hashlib.md5(text.encode()).hexdigest()[:8]
        doc_slug = re.sub(r'[^a-zA-Z0-9_-]', '_', Path(doc_name).stem)[:30]
        return f"{doc_slug}_{index:04d}_{content_hash}"


def chunk_directory(
    input_dir: Path,
    output_dir: Path,
    chunk_size: int = 512,
    chunk_overlap: int = 64,
    file_extensions: tuple = (".txt", ".md", ".rst"),
) -> List[Chunk]:
    """
    对目录下所有文档进行分块

    Args:
        input_dir: 原始文档目录
        output_dir: 输出 chunks 的目录
        chunk_size: chunk 大小
        chunk_overlap: 重叠大小
        file_extensions: 支持的文件扩展名

    Returns:
        所有 Chunk 的列表
    """
    chunker = TextChunker(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    all_chunks: List[Chunk] = []

    output_dir.mkdir(parents=True, exist_ok=True)

    for file_path in sorted(input_dir.rglob("*")):
        if file_path.suffix not in file_extensions:
            continue
        if file_path.name.startswith("."):
            continue

        print(f"处理: {file_path.name}")
        try:
            text = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            print(f"  跳过 (编码错误): {file_path.name}")
            continue

        chunks = chunker.chunk_text(text, doc_name=file_path.name)
        all_chunks.extend(chunks)
        print(f"  生成 {len(chunks)} 个 chunks")

    # 保存 chunks 到 JSON
    output_file = output_dir / "all_chunks.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(
            [asdict(c) for c in all_chunks],
            f,
            ensure_ascii=False,
            indent=2,
        )

    print(f"\n总计: {len(all_chunks)} 个 chunks → {output_file}")
    print(f"平均大小: {sum(c.token_count for c in all_chunks) / max(len(all_chunks), 1):.0f} tokens/chunk")

    return all_chunks


# ── CLI 入口 ──────────────────────────────────────────
if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from src.config import RAW_DATA_DIR, CHUNKS_DIR, CHUNK_SIZE, CHUNK_OVERLAP

    chunks = chunk_directory(
        input_dir=RAW_DATA_DIR,
        output_dir=CHUNKS_DIR,
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
    )

---

## 4. 构建向量索引 (续)

### 4.4 运行分块

```bash
# 将准备好的文档复制到 data/raw/
cp docs/*.txt data/raw/

# 运行分块脚本
cd ~/lab02-rag-claude-code
source venv/bin/activate
python src/chunker.py

# 预期输出:
# 处理: claude-code-intro.txt
#   生成 3 个 chunks
# 处理: claude-code-config.txt
#   生成 5 个 chunks
# 处理: mcp-protocol.txt
#   生成 4 个 chunks
# 总计: 12 个 chunks → data/chunks/all_chunks.json
# 平均大小: 450 tokens/chunk
```

### 4.5 构建 FAISS 向量索引

**src/build_index.py:**

```python
"""
构建 FAISS 向量索引

从 chunks 目录读取文档块，调用嵌入服务获取向量，
构建 FAISS 索引并保存到磁盘。

工作流:
  chunks.json → 嵌入服务 → numpy 向量 → FAISS Index → 磁盘文件
"""

import sys
import json
import time
import pickle
from pathlib import Path
from typing import List, Dict, Tuple

import numpy as np
import faiss
import httpx
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.table import Table

sys.path.insert(0, str(Path(__file__).parent.parent))
from src.config import (
    CHUNKS_DIR, INDEX_DIR, EMBEDDING_SERVICE_URL,
    EMBEDDING_BATCH_SIZE, EMBEDDING_DIM,
)

console = Console()


def load_chunks(chunks_file: Path) -> List[Dict]:
    """加载分块数据"""
    with open(chunks_file, "r", encoding="utf-8") as f:
        chunks = json.load(f)
    console.print(f"[green]加载了 {len(chunks)} 个文档块[/green]")
    return chunks


def get_embeddings_batch(
    texts: List[str],
    service_url: str = EMBEDDING_SERVICE_URL,
    batch_size: int = EMBEDDING_BATCH_SIZE,
    max_retries: int = 3,
) -> np.ndarray:
    """
    批量获取文本嵌入向量

    向嵌入服务发送请求，支持分批和重试。

    Args:
        texts: 文本列表
        service_url: 嵌入服务地址
        batch_size: 每批处理的文本数
        max_retries: 最大重试次数

    Returns:
        numpy 数组，shape = (len(texts), EMBEDDING_DIM)
    """
    all_embeddings: List[np.ndarray] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
    ) as progress:
        task = progress.add_task(
            "[cyan]获取嵌入向量...", total=len(texts)
        )

        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]

            for attempt in range(max_retries):
                try:
                    response = httpx.post(
                        f"{service_url}/embed/document",
                        json=batch_texts,
                        timeout=60.0,
                    )
                    response.raise_for_status()
                    data = response.json()
                    embeddings = np.array(data["embeddings"], dtype=np.float32)
                    all_embeddings.append(embeddings)
                    break
                except Exception as e:
                    if attempt == max_retries - 1:
                        console.print(f"[red]批次 {i} 嵌入失败: {e}[/red]")
                        raise
                    console.print(f"[yellow]重试 {attempt + 1}/{max_retries}...[/yellow]")
                    time.sleep(2 ** attempt)

            progress.update(task, advance=len(batch_texts))

    result = np.vstack(all_embeddings)
    console.print(f"[green]向量矩阵: {result.shape}[/green]")
    return result


def build_faiss_index(
    embeddings: np.ndarray,
    index_type: str = "FlatIP",
    nlist: int = 100,
) -> faiss.Index:
    """
    构建 FAISS 索引

    支持多种索引类型:
    - FlatIP: 精确内积搜索 (适合小规模数据集)
    - IVF,Flat: 倒排索引 + 精确搜索 (适合中等规模)
    - IVF,PQ: 倒排索引 + 乘积量化 (适合大规模)

    内积 (IP) vs L2 距离:
    - 我们的向量已 L2 归一化，内积等价于余弦相似度
    - 内积越大 → 越相似

    Args:
        embeddings: 嵌入向量矩阵 (N, D)
        index_type: 索引类型
        nlist: IVF 的聚类中心数

    Returns:
        FAISS 索引对象
    """
    dim = embeddings.shape[1]
    n = embeddings.shape[0]

    console.print(f"\n[bold]构建 FAISS 索引[/bold]")
    console.print(f"  向量数: {n}")
    console.print(f"  维度: {dim}")
    console.print(f"  索引类型: {index_type}")

    if index_type == "FlatIP":
        # 最简单、最精确的索引 ─ 内积搜索
        # 时间复杂度: O(N*D) per query
        index = faiss.IndexFlatIP(dim)

    elif index_type == "IVFFlat":
        # IVF (Inverted File) ─ 先粗糙聚类，再在最近的几个聚类中精确搜索
        # 需要训练
        quantizer = faiss.IndexFlatIP(dim)
        index = faiss.IndexIVFFlat(quantizer, dim, nlist, faiss.METRIC_INNER_PRODUCT)
        console.print(f"  训练 IVF 索引 (nlist={nlist})...")
        index.train(embeddings)

    elif index_type == "IVFPQ":
        # IVF + 乘积量化 ─ 压缩向量，大幅减少内存
        m = dim // 4  # 子向量数
        bits = 8       # 每个子向量的编码位数
        quantizer = faiss.IndexFlatIP(dim)
        index = faiss.IndexIVFPQ(quantizer, dim, nlist, m, bits)
        console.print(f"  训练 IVFPQ 索引 (nlist={nlist}, m={m})...")
        index.train(embeddings)

    else:
        raise ValueError(f"不支持的索引类型: {index_type}")

    # 添加向量
    t_start = time.perf_counter()
    index.add(embeddings)
    elapsed = time.perf_counter() - t_start

    console.print(f"  索引构建完成 | 耗时: {elapsed:.2f}s")
    console.print(f"  索引大小: {index.ntotal} 个向量")

    return index


def save_index(
    index: faiss.Index,
    chunks: List[Dict],
    embeddings: np.ndarray,
    output_dir: Path,
):
    """
    保存索引和元数据到磁盘

    输出文件:
    - faiss.index: FAISS 索引文件
    - chunks.json: 文档块元数据 (text, doc_name, etc.)
    - embeddings.npy: 原始嵌入向量 (用于调试)
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # 保存 FAISS 索引
    index_file = output_dir / "faiss.index"
    faiss.write_index(index, str(index_file))
    console.print(f"[green]FAISS 索引 → {index_file}[/green]")

    # 保存 chunks 元数据
    chunks_file = output_dir / "chunks.json"
    with open(chunks_file, "w", encoding="utf-8") as f:
        json.dump(chunks, f, ensure_ascii=False, indent=2)
    console.print(f"[green]Chunks 元数据 → {chunks_file}[/green]")

    # 保存嵌入向量
    emb_file = output_dir / "embeddings.npy"
    np.save(emb_file, embeddings)
    console.print(f"[green]嵌入向量 → {emb_file}[/green]")

    # 保存索引信息摘要
    info = {
        "num_vectors": int(index.ntotal),
        "dim": int(embeddings.shape[1]),
        "index_type": str(type(index).__name__),
        "model": "bge-large-zh-v1.5",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    info_file = output_dir / "index_info.json"
    with open(info_file, "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
    console.print(f"[green]索引信息 → {info_file}[/green]")


def load_index(index_dir: Path) -> Tuple[faiss.Index, List[Dict]]:
    """
    从磁盘加载索引和元数据

    Returns:
        (faiss_index, chunks_list)
    """
    index_file = index_dir / "faiss.index"
    chunks_file = index_dir / "chunks.json"

    if not index_file.exists():
        raise FileNotFoundError(f"索引文件不存在: {index_file}")
    if not chunks_file.exists():
        raise FileNotFoundError(f"元数据文件不存在: {chunks_file}")

    index = faiss.read_index(str(index_file))
    with open(chunks_file, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    console.print(f"[green]加载索引: {index.ntotal} 个向量[/green]")
    return index, chunks


def test_index(index: faiss.Index, chunks: List[Dict], query: str):
    """快速测试索引 ─ 单条查询"""
    import httpx

    # 获取查询嵌入
    resp = httpx.post(
        f"{EMBEDDING_SERVICE_URL}/embed/query",
        params={"text": query},
        timeout=30,
    )
    query_vec = np.array(resp.json()["embeddings"][0], dtype=np.float32).reshape(1, -1)

    # 搜索
    distances, indices = index.search(query_vec, k=5)

    # 打印结果
    table = Table(title=f"检索结果: {query}")
    table.add_column("Rank", style="cyan")
    table.add_column("Score", style="green")
    table.add_column("Chunk ID", style="yellow")
    table.add_column("Preview", style="white")

    for rank, (dist, idx) in enumerate(zip(distances[0], indices[0]), 1):
        if idx < 0 or idx >= len(chunks):
            continue
        chunk = chunks[idx]
        preview = chunk["text"][:80].replace("\n", " ")
        table.add_row(
            str(rank),
            f"{dist:.4f}",
            chunk["chunk_id"][:30],
            preview + "...",
        )

    console.print(table)


# ═══════════════════════════════════════════════════════════════
# CLI 入口
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="构建 FAISS 向量索引")
    parser.add_argument(
        "--index-type", default="FlatIP",
        choices=["FlatIP", "IVFFlat", "IVFPQ"],
        help="FAISS 索引类型"
    )
    parser.add_argument("--test", action="store_true", help="构建后测试检索")
    args = parser.parse_args()

    # 1. 加载 chunks
    chunks_file = CHUNKS_DIR / "all_chunks.json"
    if not chunks_file.exists():
        console.print("[red]请先运行 chunker.py 生成分块文件[/red]")
        sys.exit(1)

    chunks = load_chunks(chunks_file)
    texts = [c["text"] for c in chunks]

    # 2. 获取嵌入
    embeddings = get_embeddings_batch(texts)

    # 3. 构建索引
    index = build_faiss_index(embeddings, index_type=args.index_type)

    # 4. 保存
    save_index(index, chunks, embeddings, INDEX_DIR)

    # 5. 可选测试
    if args.test:
        console.print("\n[bold]索引测试[/bold]")
        test_queries = [
            "MCP 协议支持哪些传输方式？",
            "如何配置 Claude Code 的 API 端点？",
        ]
        for q in test_queries:
            test_index(index, chunks, q)
            console.print()
```

### 4.6 运行索引构建

```bash
# 确保嵌入服务正在运行 (终端 1):
# python src/embedding_service.py

# 终端 2 ─ 构建索引
cd ~/lab02-rag-claude-code
source venv/bin/activate
python src/build_index.py --test

# 预期输出:
# 加载了 16 个文档块
# 获取嵌入向量... ━━━━━━━━━━━━━━━━━━ 100%
# 向量矩阵: (16, 1024)
#
# 构建 FAISS 索引
#   向量数: 16
#   维度: 1024
#   索引类型: FlatIP
#   索引构建完成 | 耗时: 0.00s
#   索引大小: 16 个向量
# FAISS 索引 → data/index/faiss.index
# Chunks 元数据 → data/index/chunks.json
# 嵌入向量 → data/index/embeddings.npy
#
# 索引测试
#       检索结果: MCP 协议支持哪些传输方式？
# ┌──────┬─────────┬────────────────────────────┬──────────────────┐
# │ Rank │ Score   │ Chunk ID                   │ Preview          │
# ├──────┼─────────┼────────────────────────────┼──────────────────┤
# │ 1    │ 0.8234  │ mcp-protocol_0001_abc12345 │ # MCP 协议支持...│
# │ 2    │ 0.7891  │ mcp-protocol_0002_def67890 │ 传输方式包括...  │
# │ 3    │ 0.6543  │ claude-code-intro_0002_... │ MCP 协议通过...  │
# └──────┴─────────┴────────────────────────────┴──────────────────┘
```

---

## 5. 实现检索-重排序-生成流水线

### 5.1 重排序模块

**src/reranker.py:**

```python
"""
重排序 (Rerank) 模块

使用 Cross-Encoder 模型对初步检索结果进行精细排序。
Cross-Encoder 同时编码 query 和 document，精度远高于 Bi-Encoder。

    初检 (Bi-Encoder)              重排序 (Cross-Encoder)
  ┌──────────────────┐         ┌──────────────────────────┐
  │ query → [向量]    │         │ [CLS] query [SEP] doc    │
  │ doc1 → [向量]     │   top-k │       ↓                   │
  │ doc2 → [向量]     │ ──────► │   Cross-Encoder           │
  │ ... → [...]       │   传入   │       ↓                   │
  │ 余弦相似度排序    │         │   [0.92, 0.45, ...]      │
  │ 返回 top-k        │         │   更精确的相关性分数       │
  └──────────────────┘         └──────────────────────────┘
"""

import sys
import time
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional

import torch
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))
from src.config import RERANKER_MODEL_NAME

logger = logging.getLogger("reranker")


class Reranker:
    """
    Cross-Encoder 重排序器

    使用 BGE-Reranker-v2-m3 或类似模型对对候选文档进行精细排序。

    优势:
    - 同时编码 query 和 document，捕捉细粒度语义关系
    - 精度远超 Bi-Encoder 的余弦相似度

    劣势:
    - 速度较慢 (每条 (query, doc) 对都需要完整前向传播)
    - 因此只在初检结果的 top-k 上运行 (如 top-10 或 top-20)
    """

    def __init__(
        self,
        model_name: str = None,
        device: str = None,
        max_length: int = 512,
    ):
        """
        Args:
            model_name: 重排序模型名称
            device: 推理设备 ("cuda", "cpu", 或 None=自动)
            max_length: 最大输入长度
        """
        self.model_name = model_name or RERANKER_MODEL_NAME
        self.max_length = max_length

        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        self.model = None
        self.tokenizer = None
        self._loaded = False

    def load(self):
        """加载模型 (延迟加载，节省内存)"""
        if self._loaded:
            return

        logger.info(f"加载重排序模型: {self.model_name}")

        try:
            from transformers import AutoModelForSequenceClassification, AutoTokenizer

            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModelForSequenceClassification.from_pretrained(
                self.model_name
            )
            self.model.to(self.device)
            self.model.eval()

            self._loaded = True

            if self.device == "cuda":
                mem = torch.cuda.memory_allocated() / 1024**2
                logger.info(f"重排序模型加载完成 | 显存: {mem:.1f} MB")
            else:
                logger.info("重排序模型加载完成 (CPU)")

        except ImportError:
            logger.warning(
                "transformers 未安装，使用简化版重排序器 (基于关键词匹配)"
            )
            self._loaded = True  # 标记为已加载，使用 fallback
        except Exception as e:
            logger.error(f"重排序模型加载失败: {e}")
            raise

    def rerank(
        self,
        query: str,
        candidates: List[Dict],
        top_k: int = 5,
    ) -> List[Dict]:
        """
        重排序候选文档

        Args:
            query: 查询文本
            candidates: 候选文档列表
                每个文档是一个 dict，需包含 'text' 字段
            top_k: 返回的文档数量

        Returns:
            排序后的文档列表，每个文档包含额外的 'rerank_score' 字段
        """
        if not candidates:
            return []

        t_start = time.perf_counter()

        if self.model is not None:
            scores = self._cross_encode_rerank(query, candidates)
        else:
            # Fallback: 基于关键词重叠的简单重排序
            scores = self._keyword_rerank(query, candidates)

        # 添加分数并排序
        for candidate, score in zip(candidates, scores):
            candidate["rerank_score"] = float(score)

        candidates.sort(key=lambda x: x.get("rerank_score", 0), reverse=True)

        elapsed = (time.perf_counter() - t_start) * 1000
        logger.info(
            f"重排序完成 | 候选数: {len(candidates)} → 返回: {min(top_k, len(candidates))} | "
            f"耗时: {elapsed:.1f} ms"
        )

        return candidates[:top_k]

    def _cross_encode_rerank(
        self, query: str, candidates: List[Dict]
    ) -> List[float]:
        """使用 Cross-Encoder 计算相关性分数"""
        scores = []

        for candidate in candidates:
            text = candidate.get("text", "")

            # 截断过长文本
            if len(text) > self.max_length * 4:  # 粗略估算
                text = text[:self.max_length * 4]

            inputs = self.tokenizer(
                query, text,
                max_length=self.max_length,
                truncation=True,
                padding=True,
                return_tensors="pt",
            ).to(self.device)

            with torch.no_grad():
                outputs = self.model(**inputs)
                # 取 logits 作为相关性分数
                score = outputs.logits.squeeze().cpu().item()
                scores.append(score)

        return scores

    def _keyword_rerank(
        self, query: str, candidates: List[Dict]
    ) -> List[float]:
        """Fallback 重排序: 基于关键词重叠"""
        # 分词 (简单按字/词分割)
        query_tokens = set(query.lower())

        scores = []
        for candidate in candidates:
            text = candidate.get("text", "").lower()
            text_tokens = set(text)

            # Jaccard 相似度 + 覆盖度
            if not query_tokens:
                scores.append(0.0)
                continue

            intersection = query_tokens & text_tokens
            union = query_tokens | text_tokens
            jaccard = len(intersection) / len(union) if union else 0
            coverage = len(intersection) / len(query_tokens) if query_tokens else 0

            # 组合分数
            score = 0.6 * jaccard + 0.4 * coverage
            scores.append(score)

        return scores


# ── 单例模式 ──────────────────────────────────────────
_reranker_instance: Optional[Reranker] = None


def get_reranker() -> Reranker:
    """获取全局重排序器实例"""
    global _reranker_instance
    if _reranker_instance is None:
        _reranker_instance = Reranker()
        _reranker_instance.load()
    return _reranker_instance
```

### 5.2 RAG 流水线核心

**src/rag_pipeline.py:**

```python
"""
RAG 流水线核心模块

整合检索、重排序、上下文拼接、LLM 生成等全部步骤。

    用户查询
       │
       ▼
   Query 嵌入 (调用嵌入服务)
       │
       ▼
   FAISS 向量检索 (top_k=10)
       │
       ▼
   Cross-Encoder 重排序 (保留 top_k=5)
       │
       ▼
   上下文拼接 (Prompt Template)
       │
       ▼
   LLM 生成 (Anthropic / OpenAI / 本地)
       │
       ▼
   返回回答
"""

import sys
import json
import time
import logging
from pathlib import Path
from typing import List, Dict, Optional, AsyncIterator

import numpy as np
import faiss
import httpx

sys.path.insert(0, str(Path(__file__).parent.parent))
from src.config import (
    INDEX_DIR, EMBEDDING_SERVICE_URL,
    RETRIEVAL_TOP_K, RERANK_TOP_K,
    LLM_BACKEND, LLM_MODEL, ANTHROPIC_API_KEY,
    LLM_API_BASE, LLM_API_KEY, SIMILARITY_THRESHOLD,
)
from src.reranker import get_reranker

logger = logging.getLogger("rag-pipeline")


# ═══════════════════════════════════════════════════════════════
# Prompt 模板
# ═══════════════════════════════════════════════════════════════

RAG_SYSTEM_PROMPT = """你是一个基于知识库的智能助手。请根据下方提供的参考资料回答用户问题。

回答规则:
1. 优先使用参考资料中的信息，如果资料不足以回答，请如实说明。
2. 引用资料时，注明来源 (如 "根据文档 A")。
3. 回答要准确、简洁、有条理。
4. 如果参考资料中有代码示例，可以引用代码。
5. 不要编造参考资料中没有的信息。

---

## 参考资料

{context}

---

请基于以上参考资料回答用户的问题。"""


RAG_SYSTEM_PROMPT_EN = """You are a knowledge-base assistant. Answer the user's question
based on the reference materials provided below.

Rules:
1. Prioritize information from the reference materials. If insufficient, state so honestly.
2. Cite sources when referencing materials.
3. Be accurate, concise, and organized.
4. You may quote code examples from the materials.
5. Do not fabricate information not in the reference materials.

---

## Reference Materials

{context}

---

Answer the user's question based on the reference materials above."""


# ═══════════════════════════════════════════════════════════════
# RAG Pipeline 类
# ═══════════════════════════════════════════════════════════════

class RAGPipeline:
    """
    检索增强生成 (RAG) 流水线

    使用示例:

        pipeline = RAGPipeline()
        pipeline.load_index()

        answer = await pipeline.query("什么是 MCP 协议？")
        print(answer)

        # 流式
        async for chunk in pipeline.query_stream("MCP 的传输方式？"):
            print(chunk, end="")
    """

    def __init__(self):
        self.index: Optional[faiss.Index] = None
        self.chunks: List[Dict] = []
        self.reranker = None
        self._ready = False

    def load_index(self):
        """加载 FAISS 索引和文档块元数据"""
        logger.info("加载向量索引...")

        index_file = INDEX_DIR / "faiss.index"
        chunks_file = INDEX_DIR / "chunks.json"

        if not index_file.exists():
            raise FileNotFoundError(
                f"索引文件不存在: {index_file}\n"
                f"请先运行: python src/build_index.py"
            )

        self.index = faiss.read_index(str(index_file))
        with open(chunks_file, "r", encoding="utf-8") as f:
            self.chunks = json.load(f)

        logger.info(f"索引加载完成: {self.index.ntotal} 个向量, "
                     f"{len(self.chunks)} 个文档块")

        # 延迟加载重排序器
        self.reranker = get_reranker()

        self._ready = True

    async def _get_query_embedding(self, query: str) -> np.ndarray:
        """获取查询文本的嵌入向量"""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{EMBEDDING_SERVICE_URL}/embed/query",
                params={"text": query},
                timeout=30.0,
            )
            resp.raise_for_status()
            data = resp.json()
            return np.array(data["embeddings"][0], dtype=np.float32)

    async def retrieve(self, query: str) -> List[Dict]:
        """
        检索相关文档块

        步骤:
        1. 查询嵌入
        2. FAISS 向量检索 (top_k=10)
        3. 重排序 (保留 top_k=5)

        Args:
            query: 用户查询

        Returns:
            排序后的相关文档块列表，每个包含:
            - chunk_id, text, doc_name, chunk_index
            - score: 向量检索分数
            - rerank_score: 重排序分数
        """
        if not self._ready:
            raise RuntimeError("请先调用 load_index()")

        t_total = time.perf_counter()

        # 步骤 1: 查询嵌入
        t_embed = time.perf_counter()
        query_vec = await self._get_query_embedding(query)
        query_vec = query_vec.reshape(1, -1)
        t_embed = time.perf_counter() - t_embed

        # 步骤 2: FAISS 向量检索
        t_search = time.perf_counter()
        distances, indices = self.index.search(query_vec, k=RETRIEVAL_TOP_K)
        t_search = time.perf_counter() - t_search

        # 构建候选列表
        candidates = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < 0 or idx >= len(self.chunks):
                continue
            if dist < SIMILARITY_THRESHOLD:
                continue  # 过滤低相关度结果

            chunk = dict(self.chunks[idx])  # 复制
            chunk["score"] = float(dist)
            candidates.append(chunk)

        # 步骤 3: 重排序
        t_rerank = time.perf_counter()
        if self.reranker and len(candidates) > 1:
            candidates = self.reranker.rerank(query, candidates, top_k=RERANK_TOP_K)
        t_rerank = time.perf_counter() - t_rerank

        t_total = time.perf_counter() - t_total

        logger.info(
            f"检索完成 | Query: {query[:50]}... | "
            f"嵌入: {t_embed*1000:.0f}ms | "
            f"搜索: {t_search*1000:.0f}ms | "
            f"重排序: {t_rerank*1000:.0f}ms | "
            f"总耗时: {t_total*1000:.0f}ms | "
            f"结果数: {len(candidates)}"
        )

        return candidates

    def _build_context(self, retrieved: List[Dict]) -> str:
        """将检索结果拼接为上下文字符串"""
        parts = []
        for i, doc in enumerate(retrieved, 1):
            source = doc.get("doc_name", "unknown")
            text = doc.get("text", "")

            parts.append(
                f"[文档 {i}] 来源: {source}\n"
                f"{text}\n"
            )

        context = "\n---\n".join(parts)
        return context

    def _build_messages(
        self, user_query: str, retrieved: List[Dict],
        conversation_history: List[Dict] = None,
    ) -> List[Dict]:
        """
        构建发送给 LLM 的完整消息列表

        Args:
            user_query: 用户当前问题
            retrieved: 检索到的相关文档
            conversation_history: 之前的对话历史

        Returns:
            OpenAI 格式的 messages 列表
        """
        context = self._build_context(retrieved)
        system_prompt = RAG_SYSTEM_PROMPT.format(context=context)

        messages = [{"role": "system", "content": system_prompt}]

        # 添加对话历史 (最近 N 轮)
        if conversation_history:
            messages.extend(conversation_history[-6:])  # 最近 3 轮对话

        messages.append({"role": "user", "content": user_query})

        return messages

    async def query(
        self,
        user_query: str,
        conversation_history: List[Dict] = None,
        temperature: float = 0.3,
    ) -> Dict:
        """
        完整 RAG 查询 ─ 非流式

        Returns:
            {
                "answer": "生成的回答",
                "sources": [...],    # 引用的文档块
                "timing": {...},     # 各步骤耗时
            }
        """
        timing = {}

        # 步骤 1: 检索
        t0 = time.perf_counter()
        retrieved = await self.retrieve(user_query)
        timing["retrieval_ms"] = (time.perf_counter() - t0) * 1000

        # 步骤 2: 构建消息
        messages = self._build_messages(user_query, retrieved, conversation_history)

        # 步骤 3: LLM 生成
        t0 = time.perf_counter()
        answer = await self._llm_generate(messages, temperature=temperature)
        timing["generation_ms"] = (time.perf_counter() - t0) * 1000

        return {
            "answer": answer,
            "sources": [
                {
                    "chunk_id": d.get("chunk_id"),
                    "doc_name": d.get("doc_name"),
                    "score": d.get("score"),
                    "rerank_score": d.get("rerank_score"),
                    "preview": d.get("text", "")[:200],
                }
                for d in retrieved
            ],
            "timing": timing,
        }

    async def query_stream(
        self,
        user_query: str,
        conversation_history: List[Dict] = None,
        temperature: float = 0.3,
    ) -> AsyncIterator[str]:
        """流式 RAG 查询 ─ 逐 token 返回"""
        retrieved = await self.retrieve(user_query)
        messages = self._build_messages(user_query, retrieved, conversation_history)

        async for token in self._llm_generate_stream(messages, temperature):
            yield token

    # ── LLM 后端 ────────────────────────────────────────

    async def _llm_generate(
        self, messages: List[Dict], temperature: float = 0.3,
    ) -> str:
        """非流式 LLM 生成"""
        if LLM_BACKEND == "anthropic":
            return await self._anthropic_generate(messages, temperature)
        else:
            return await self._openai_compatible_generate(messages, temperature)

    async def _llm_generate_stream(
        self, messages: List[Dict], temperature: float = 0.3,
    ) -> AsyncIterator[str]:
        """流式 LLM 生成"""
        if LLM_BACKEND == "anthropic":
            async for token in self._anthropic_generate_stream(messages, temperature):
                yield token
        else:
            async for token in self._openai_compatible_stream(messages, temperature):
                yield token

    async def _openai_compatible_generate(
        self, messages: List[Dict], temperature: float,
    ) -> str:
        """通用 OpenAI 兼容 API 调用"""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{LLM_API_BASE}/chat/completions",
                headers={
                    "Authorization": f"Bearer {LLM_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": LLM_MODEL,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": 2048,
                },
                timeout=120.0,
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

    async def _openai_compatible_stream(
        self, messages: List[Dict], temperature: float,
    ) -> AsyncIterator[str]:
        """通用 OpenAI 兼容流式调用"""
        async with httpx.AsyncClient() as client:
            async with client.stream(
                "POST",
                f"{LLM_API_BASE}/chat/completions",
                headers={
                    "Authorization": f"Bearer {LLM_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": LLM_MODEL,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": 2048,
                    "stream": True,
                },
                timeout=120.0,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data_str)
                            delta = chunk["choices"][0].get("delta", {})
                            content = delta.get("content", "")
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue

    async def _anthropic_generate(
        self, messages: List[Dict], temperature: float,
    ) -> str:
        """Anthropic Messages API 调用"""
        import anthropic

        # 提取 system prompt
        system_msg = None
        api_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                api_messages.append(msg)

        client = anthropic.AsyncAnthropic(api_key=ANTHROPIC_API_KEY)
        response = await client.messages.create(
            model=LLM_MODEL,
            system=system_msg,
            messages=api_messages,
            temperature=temperature,
            max_tokens=2048,
        )
        return response.content[0].text

    async def _anthropic_generate_stream(
        self, messages: List[Dict], temperature: float,
    ) -> AsyncIterator[str]:
        """Anthropic Messages API 流式调用"""
        import anthropic

        system_msg = None
        api_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                api_messages.append(msg)

        client = anthropic.AsyncAnthropic(api_key=ANTHROPIC_API_KEY)
        async with client.messages.stream(
            model=LLM_MODEL,
            system=system_msg,
            messages=api_messages,
            temperature=temperature,
            max_tokens=2048,
        ) as stream:
            async for text in stream.text_stream:
                yield text


# ── 单例 ─────────────────────────────────────────────
_pipeline_instance: Optional[RAGPipeline] = None


def get_pipeline() -> RAGPipeline:
    """获取全局 RAG 流水线实例"""
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = RAGPipeline()
        _pipeline_instance.load_index()
    return _pipeline_instance

---

## 12. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| Embedding | "文本的数字指纹"：把句子变成固定长度的浮点向量，语义相近的句子向量也相近 | 全链路术语表 |
| FAISS Index | "向量图书馆的索引卡"：存了所有文档块的向量，查询时快速找到最相似的 Top-K | 全链路术语表 |
| Reranker (Cross-Encoder) | "双阅卷老师复核"：初检用向量相似度粗筛，重排序用更精确的 Cross-Encoder 对候选精排 | 全链路术语表 |
| BGE (BAAI General Embedding) | "中文语义理解国家队"：智源研究院出品的中文嵌入模型，C-MTEB 榜单 Top-3 | 全链路术语表 |
| OpenAI 兼容 API | "通用插座协议"：vLLM 和本 RAG 服务都暴露 OpenAI 格式的 /v1/chat/completions，Claude Code 可无缝接入 | 全链路术语表 |

---

## 13. 部署场景举例（性能实测数据）

### 13.1 完整启动命令

```bash
# 终端 1：启动嵌入服务（BGE-large-zh on GPU）
cd ~/lab02-rag-claude-code && source venv/bin/activate
python src/embedding_service.py
# 预期: 模型加载 1.2 GB 显存, 单条嵌入 ~10ms

# 终端 2：启动 RAG API 服务
cd ~/lab02-rag-claude-code && source venv/bin/activate
python src/api_server.py
# 预期: 端口 8000, /v1/chat/completions 就绪

# 终端 3：配置 Claude Code 使用本地端点
claude --api-base http://localhost:8000/v1

# 终端 4：快速验证
curl -s http://localhost:9001/health | python -m json.tool
curl -s http://localhost:8000/health | python -m json.tool
```

### 13.2 检索阶段耗时参考（A800, GPU 嵌入）

| 阶段 | 耗时 | 说明 |
|------|------|------|
| Query 嵌入 | 5-15 ms | BGE-large-zh on GPU |
| FAISS FlatIP 检索 (10000 向量) | <1 ms | 全内存索引 |
| Cross-Encoder 重排序 (Top-10→Top-5) | 10-30 ms | BGE-Reranker on GPU |
| 检索总耗时 | 15-45 ms | 远小于 LLM 生成时间 |

### 13.3 知识库规模建议

| 文档数 | Chunks 数 | 推荐索引类型 | 索引大小 |
|--------|----------|-------------|---------|
| <100   | <1000   | FlatIP      | ~4 MB   |
| 100-1000 | 1000-10000 | IVFFlat   | ~40 MB  |
| 1000+  | 10000+  | IVFPQ       | ~200 MB |

---

## 14. 上下游串联

```
Lab 02 在端到端推理链中的位置

┌──────────────────────────────────────────────────────────────────┐
│                RAG 增强推理的完整链路                               │
│                                                                   │
│  用户/Claude Code                                                  │
│    │  提问: "MCP 协议支持哪些传输方式？"                            │
│    ▼                                                              │
│  ┌─────────────────────────────────────────┐                      │
│  │ ★ Lab 02 RAG API                        │ ← 本文档核心          │
│  │                                          │                      │
│  │  1. Query Embedding ──→ Embedding 服务   │ (BGE-large-zh)      │
│  │  2. Vector Search    ──→ FAISS 索引     │ (Lab 02 构建)        │
│  │  3. Rerank           ──→ Cross-Encoder  │ (BGE-Reranker)       │
│  │  4. Context Build    ──→ Prompt Template │                      │
│  │  5. LLM Generate     ──→ vLLM/Anthropic │ (Lab 01 部署的模型)  │
│  └─────────────────────────────────────────┘                      │
│    │                                                              │
│    ▼                                                              │
│  返回: 带上下文引用的增强回答                                       │
│                                                                   │
│  依赖关系：                                                         │
│    Lab 01 (推理服务部署) → Lab 02 (在其上构建 RAG 管线)             │
│    Lab 02 (RAG)          → Claude Code 集成 → 日常工作可用          │
│    后续实验: Lab 03 (自定义 Kernel 加速 Embedding/Attention)        │
└──────────────────────────────────────────────────────────────────┘
```
