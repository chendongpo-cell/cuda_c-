# vLLM 模型加载机制深度剖析

> 本文档深入分析 vLLM 如何从 HuggingFace 格式的模型权重文件（safetensors / .bin / .pt）加载模型，包括模型注册表、配置解析、权重加载流水线、量化模型、LoRA 适配器、内存分析，以及自定义模型的完整步骤。
>
> 基于 vLLM 源码：`/data/chendongpo/agent_projects/vllm_src/vllm/`

---

## 目录

1. [总体架构概览](#1-总体架构概览)
2. [模型注册表：ModelRegistry](#2-模型注册表modelregistry)
3. [模型配置解析：config.json → ModelConfig](#3-模型配置解析configjson--modelconfig)
4. [权重加载流水线](#4-权重加载流水线)
5. [量化模型加载](#5-量化模型加载)
6. [LoRA 适配器加载](#6-lora-适配器加载)
7. [内存分析与 warmup](#7-内存分析与-warmup)
8. [添加自定义模型：完整实战指南](#8-添加自定义模型完整实战指南)
9. [常见加载问题及解决方案](#9-常见加载问题及解决方案)
10. [深入学习资源](#10-深入学习资源)

---

## 1. 总体架构概览

vLLM 的模型加载是一个多阶段的流水线，从接收用户命令行参数开始，到最终模型在 GPU 上 ready 运行，主要经历以下几个阶段：

```
                          vLLM 模型加载全流程
    ┌──────────────────────────────────────────────────────────────────────┐
    │                                                                      │
    │  ① CLI 参数解析                                                      │
    │     --model /path/to/model --dtype auto --tp 2 --quantization awq    │
    │     │                                                                │
    │     ▼                                                                │
    │  ② ModelConfig 构建                                                  │
    │     ├── 读取 config.json → PretrainedConfig                          │
    │     ├── 提取 architectures → 确定模型架构                             │
    │     ├── 验证 dtype / quantization / max_model_len                    │
    │     └── 构建 MultiModalConfig / LoRAConfig（如果启用）                │
    │     │                                                                │
    │     ▼                                                                │
    │  ③ 模型注册表查询                                                     │
    │     ModelRegistry.resolve_model_cls(architectures)                    │
    │     ├── 匹配 _VLLM_MODELS 字典                                       │
    │     ├── 懒加载 vllm.model_executor.models.{module}                   │
    │     └── 返回 (model_cls, arch_name)                                  │
    │     │                                                                │
    │     ▼                                                                │
    │  ④ 模型实例化                                                         │
    │     model_class(config=hf_config, cache_config=..., quant_config=...) │
    │     ├── 构建 nn.Module 结构（空权重）                                  │
    │     ├── 量化层用 PackedvLLMParameter 等特殊参数                        │
    │     └── LoRA 层预留插槽（如果 --enable-lora）                         │
    │     │                                                                │
    │     ▼                                                                │
    │  ⑤ 权重加载                                                           │
    │     DefaultModelLoader.load_model()                                   │
    │     ├── 下载 / 定位权重文件（safetensors / .bin / .pt）               │
    │     ├── safetensors_weights_iterator() 逐文件迭代                     │
    │     ├── model.load_weights(weights_iterator)                          │
    │     │   ├── 按 TP rank 分片 (row/column parallel)                    │
    │     │   ├── 量化层反量化 / 重打包                                      │
    │     │   └── default_weight_loader → param.data.copy_(loaded_weight)   │
    │     └── quant_method.process_weights_after_loading(module)            │
    │     │                                                                │
    │     ▼                                                                │
    │  ⑥ 内存分析与 warmup                                                  │
    │     worker.determine_num_available_blocks()                           │
    │     ├── profile_run() — 最大 batch 的 dummy 前向                      │
    │     ├── peak_memory = init_gpu_memory - free_gpu_memory               │
    │     ├── num_gpu_blocks = (total * gpu_memory_utilization - peak)      │
    │     │                    // cache_block_size                          │
    │     ├── 分配 KV cache blocks                                          │
    │     └── capture_model() — CUDA graph 录制                             │
    │     │                                                                │
    │     ▼                                                                │
    │  ⑦ 模型就绪，进入推理循环                                              │
    │                                                                      │
    └──────────────────────────────────────────────────────────────────────┘
```

核心调用链：

```python
# engine/llm_engine.py → worker/worker.py → model_runner.py → loader.py

# 第一步：LLMEngine 初始化触发
# vllm/engine/llm_engine.py
class LLMEngine:
    def __init__(self, ...):
        self.model_executor = executor_class(...)
        # executor 内部会调用 worker.load_model()

# 第二步：Worker 初始化 → load_model
# vllm/worker/worker.py 第 171-183 行
class Worker:
    def init_device(self):
        torch.cuda.empty_cache()
        # ★ 记录模型加载前的 GPU 空闲内存，用于后续内存分析
        self.init_gpu_memory = torch.cuda.mem_get_info()[0]

    def load_model(self):
        self.model_runner.load_model()

# 第三步：ModelRunner 调用 get_model
# vllm/worker/model_runner.py 第 1059-1072 行
class ModelRunner:
    def load_model(self) -> None:
        logger.info("Starting to load model %s...", self.model_config.model)
        with DeviceMemoryProfiler() as m:
            self.model = get_model(
                model_config=self.model_config,
                device_config=self.device_config,
                load_config=self.load_config,
                lora_config=self.lora_config,
                parallel_config=self.parallel_config,
                scheduler_config=self.scheduler_config,
                cache_config=self.cache_config,
            )
        self.model_memory_usage = m.consumed_memory
        logger.info("Loading model weights took %.4f GB",
                    self.model_memory_usage / float(2**30))
```

**关键文件清单**（所有路径相对于 vllm 源码根目录）：

| 文件 | 行数 | 作用 |
|---|---|---|
| `config.py` | ~1800+ | 所有配置类（ModelConfig, CacheConfig, LoRAConfig, ParallelConfig 等） |
| `model_executor/models/registry.py` | ~450 | 模型注册表、懒加载、架构自动检测 |
| `model_executor/model_loader/loader.py` | ~1260 | DefaultModelLoader 及所有加载器实现 |
| `model_executor/model_loader/weight_utils.py` | ~683 | 权重下载、safetensors/pt 迭代器、weight loader 函数 |
| `model_executor/model_loader/utils.py` | ~40 | get_model_architecture、set_default_torch_dtype |
| `model_executor/models/utils.py` | ~485 | AutoWeightsLoader、PPMissingLayer、make_layers |
| `model_executor/models/llama.py` | ~617 | LLaMA 完整实现（许多模型的基类） |
| `model_executor/models/interfaces.py` | ~68 | SupportsLoRA、SupportsPP、supports_multimodal 等接口 |
| `model_executor/layers/quantization/__init__.py` | ~67 | QUANTIZATION_METHODS 注册表 |
| `model_executor/layers/quantization/awq.py` | ~173 | AWQ INT4 量化配置及线性方法 |
| `model_executor/layers/quantization/gptq.py` | ~100+ | GPTQ 量化配置 |
| `model_executor/layers/quantization/fp8.py` | ~100+ | FP8 量化配置及方法 |
| `model_executor/layers/quantization/base_config.py` | ~100+ | QuantizationConfig 基类 |
| `lora/models.py` | ~600+ | LoRAModel、LoRAModelManager、LRU 缓存 |
| `lora/layers.py` | ~600+ | BaseLayerWithLoRA、各种 LoRA 线性层 |
| `lora/lora.py` | ~120+ | LoRALayerWeights、PackedLoRALayerWeights |
| `worker/model_runner.py` | ~1400+ | ModelRunner、profile_run、capture_model |
| `worker/worker.py` | ~500+ | Worker、determine_num_available_blocks |
| `model_executor/parameter.py` | ~200+ | PackedvLLMParameter、GroupQuantScaleParameter 等特殊参数类型 |
| `model_executor/layers/linear.py` | ~800+ | ColumnParallelLinear、RowParallelLinear、QKVParallelLinear 等 |

---

## 2. 模型注册表：ModelRegistry

### 2.1 核心数据结构

vLLM 通过一个全局注册表来管理所有支持的模型架构。核心代码在 `vllm/model_executor/models/registry.py`。

```
    _VLLM_MODELS 字典结构
    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                 │
    │  key: HuggingFace config.json 中 architectures 列表的值          │
    │       (例如 "LlamaForCausalLM", "Qwen2ForCausalLM")              │
    │                                                                 │
    │  value: ("子模块名", "类名") 的元组                                │
    │         子模块名 = vllm/model_executor/models/ 下的文件名         │
    │         类名 = 该文件中的模型类名                                  │
    │                                                                 │
    │  示例:                                                          │
    │  "LlamaForCausalLM"  → ("llama",   "LlamaForCausalLM")          │
    │  "Qwen2ForCausalLM"  → ("qwen2",   "Qwen2ForCausalLM")          │
    │  "MistralForCausalLM"→ ("llama",   "LlamaForCausalLM")  ← 复用  │
    │  "DeepseekV2ForCausalLM" → ("deepseek_v2", "DeepseekV2ForCausalLM")│
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘
```

真实源码（registry.py 第 24-131 行）：

```python
# yapf: disable
_TEXT_GENERATION_MODELS = {
    # [Decoder-only]
    "AquilaModel": ("llama", "LlamaForCausalLM"),
    "AquilaForCausalLM": ("llama", "LlamaForCausalLM"),  # AquilaChat2
    "ArcticForCausalLM": ("arctic", "ArcticForCausalLM"),
    "BaiChuanForCausalLM": ("baichuan", "BaiChuanForCausalLM"),
    "BloomForCausalLM": ("bloom", "BloomForCausalLM"),
    "CohereForCausalLM": ("commandr", "CohereForCausalLM"),
    "DeepseekForCausalLM": ("deepseek", "DeepseekForCausalLM"),
    "DeepseekV2ForCausalLM": ("deepseek_v2", "DeepseekV2ForCausalLM"),
    "FalconForCausalLM": ("falcon", "FalconForCausalLM"),
    "GemmaForCausalLM": ("gemma", "GemmaForCausalLM"),
    "Gemma2ForCausalLM": ("gemma2", "Gemma2ForCausalLM"),
    "GPT2LMHeadModel": ("gpt2", "GPT2LMHeadModel"),
    "GPTBigCodeForCausalLM": ("gpt_bigcode", "GPTBigCodeForCausalLM"),
    "GPTJForCausalLM": ("gpt_j", "GPTJForCausalLM"),
    "GPTNeoXForCausalLM": ("gpt_neox", "GPTNeoXForCausalLM"),
    "LlamaForCausalLM": ("llama", "LlamaForCausalLM"),
    "LLaMAForCausalLM": ("llama", "LlamaForCausalLM"),  # 老格式兼容
    "MistralForCausalLM": ("llama", "LlamaForCausalLM"),  # Mistral 复用 Llama
    "MixtralForCausalLM": ("mixtral", "MixtralForCausalLM"),
    "Qwen2ForCausalLM": ("qwen2", "Qwen2ForCausalLM"),
    "Qwen2MoeForCausalLM": ("qwen2_moe", "Qwen2MoeForCausalLM"),
    # ... 50+ 更多模型
}

_EMBEDDING_MODELS = {
    "MistralModel": ("llama_embedding", "LlamaEmbeddingModel"),
    "Qwen2ForRewardModel": ("qwen2_rm", "Qwen2ForRewardModel"),
    "Gemma2Model": ("gemma2_embedding", "Gemma2EmbeddingModel"),
}

_MULTIMODAL_MODELS = {
    "Blip2ForConditionalGeneration": ("blip2", "Blip2ForConditionalGeneration"),
    "ChatGLMModel": ("chatglm", "ChatGLMForCausalLM"),
    "InternVLChatModel": ("internvl", "InternVLChatModel"),
    "LlavaForConditionalGeneration": ("llava", "LlavaForConditionalGeneration"),
    "Qwen2VLForConditionalGeneration": ("qwen2_vl", "Qwen2VLForConditionalGeneration"),
    # ... 更多多模态模型
}

_SPECULATIVE_DECODING_MODELS = {
    "EAGLEModel": ("eagle", "EAGLE"),
    "MedusaModel": ("medusa", "Medusa"),
    "MLPSpeculatorPreTrainedModel": ("mlp_speculator", "MLPSpeculator"),
}

# 最终合并为一个全局字典
_VLLM_MODELS = {
    **_TEXT_GENERATION_MODELS,
    **_EMBEDDING_MODELS,
    **_MULTIMODAL_MODELS,
    **_SPECULATIVE_DECODING_MODELS,
}
```

### 2.2 自动检测：从 config.json 到模型类

当用户指定 `--model /path/to/model` 时，vLLM 如何知道该用哪个模型类？

```
    config.json → ModelConfig → ModelRegistry 查询流程
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  ① 读取 config.json                                            │
    │     {                                                          │
    │       "architectures": ["LlamaForCausalLM"],  ◄── 关键字段      │
    │       "hidden_size": 4096,                                     │
    │       "num_hidden_layers": 32,                                 │
    │       "num_attention_heads": 32,                               │
    │       "num_key_value_heads": 8,                                │
    │       ...                                                      │
    │     }                                                          │
    │     │                                                          │
    │     ▼                                                          │
    │  ② ModelConfig.__init__() 中调用                                │
    │     self.hf_config = get_config(model, trust_remote_code, ...)  │
    │     architectures = getattr(self.hf_config, "architectures", [])│
    │     │                                                          │
    │     ▼                                                          │
    │  ③ get_model_architecture(model_config)                        │
    │     文件: vllm/model_executor/model_loader/utils.py            │
    │     architectures = getattr(model_config.hf_config,             │
    │                             "architectures", [])                │
    │     return ModelRegistry.resolve_model_cls(architectures)       │
    │     │                                                          │
    │     ▼                                                          │
    │  ④ ModelRegistry.resolve_model_cls()                           │
    │     for arch in architectures:  # 遍历列表直到找到匹配            │
    │         model_cls = self._try_load_model_cls(arch)             │
    │         if model_cls is not None:                              │
    │             return (model_cls, arch)                           │
    │     │                                                          │
    │     ▼                                                          │
    │  ⑤ _LazyRegisteredModel.load_model_cls()                       │
    │     mod = importlib.import_module(                              │
    │         "vllm.model_executor.models.llama")                    │
    │     return getattr(mod, "LlamaForCausalLM")                    │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

真实源码（model_loader/utils.py 第 21-35 行）：

```python
def get_model_architecture(
        model_config: ModelConfig) -> Tuple[Type[nn.Module], str]:
    architectures = getattr(model_config.hf_config, "architectures", [])
    # 特殊处理：量化 Mixtral
    mixtral_supported = [
        "fp8", "compressed-tensors", "gptq_marlin", "awq_marlin"
    ]
    if (model_config.quantization is not None
            and model_config.quantization not in mixtral_supported
            and "MixtralForCausalLM" in architectures):
        architectures = ["QuantMixtralForCausalLM"]
    return ModelRegistry.resolve_model_cls(architectures)
```

### 2.3 懒加载机制

注意 registry.py 中使用 `_LazyRegisteredModel` 而非直接导入模型类：

```python
# registry.py 第 401-407 行
ModelRegistry = _ModelRegistry({
    model_arch: _LazyRegisteredModel(
        module_name=f"vllm.model_executor.models.{mod_relname}",
        class_name=cls_name,
    )
    for model_arch, (mod_relname, cls_name) in _VLLM_MODELS.items()
})

# _LazyRegisteredModel 的核心方法（registry.py 第 214-229 行）
@dataclass(frozen=True)
class _LazyRegisteredModel(_BaseRegisteredModel):
    module_name: str
    class_name: str

    def load_model_cls(self) -> Type[nn.Module]:
        mod = importlib.import_module(self.module_name)
        return getattr(mod, self.class_name)
```

**为什么需要懒加载？** 避免在主进程中初始化 CUDA 上下文，因为后续会 fork 子进程进行分布式推理，而 CUDA 不支持 fork。懒加载确保模型类只在真正需要时才被导入。

### 2.4 inspect 子进程机制

对于模型能力检测（如是否支持多模态、是否支持 pipeline parallel），registry 通过子进程来检查，避免影响主进程的 CUDA 状态：

```python
# registry.py 第 412-433 行
def _run_in_subprocess(fn: Callable[[], _T]) -> _T:
    with tempfile.NamedTemporaryFile() as output_file:
        input_bytes = cloudpickle.dumps((fn, output_file.name))
        returned = subprocess.run(
            [sys.executable, "-m", "vllm.model_executor.models.registry"],
            input=input_bytes,
            capture_output=True)
        try:
            returned.check_returncode()
        except Exception as e:
            raise RuntimeError(f"Error raised in subprocess:\n"
                             f"{returned.stderr.decode()}") from e
        with open(output_file.name, "rb") as f:
            return pickle.load(f)
```

### 2.5 register_model 方法：注册自定义模型

vLLM 提供了 `register_model` 方法让用户可以注册外部模型，支持两种方式：

```python
# 方式一：直接传入模型类（会在主进程立即导入）
from vllm.model_executor.models import ModelRegistry

class MyCustomModel(nn.Module):
    ...

# 注册
ModelRegistry.register_model("MyCustomForCausalLM", MyCustomModel)

# 方式二：字符串懒加载（推荐，避免 CUDA fork 问题）
ModelRegistry.register_model(
    "MyCustomForCausalLM",
    "my_package.my_module:MyCustomModel"  # 格式：<module>:<class>
)
```

源码中的注册方法（registry.py 第 277-309 行）：

```python
def register_model(
    self,
    model_arch: str,
    model_cls: Union[Type[nn.Module], str],
) -> None:
    if model_arch in self.models:
        logger.warning(
            "Model architecture %s is already registered, and will be "
            "overwritten by the new model class %s.", model_arch, model_cls)
    if isinstance(model_cls, str):
        split_str = model_cls.split(":")
        if len(split_str) != 2:
            msg = "Expected a string in the format `<module>:<class>`"
            raise ValueError(msg)
        model = _LazyRegisteredModel(*split_str)
    else:
        model = _RegisteredModel.from_model_cls(model_cls)
    self.models[model_arch] = model
```

### 2.6 模型接口检测

vLLM 通过 interface 判断模型的能力（registry.py 第 168-177 行）：

```python
@dataclass(frozen=True)
class _ModelInfo:
    is_text_generation_model: bool
    is_embedding_model: bool
    supports_multimodal: bool
    supports_pp: bool        # 是否支持 Pipeline Parallelism
    has_inner_state: bool    # 是否有内部状态（如 Mamba）
    is_attention_free: bool  # 是否无注意力机制

    @staticmethod
    def from_model_cls(model: Type[nn.Module]) -> "_ModelInfo":
        return _ModelInfo(
            is_text_generation_model=is_text_generation_model(model),
            is_embedding_model=is_embedding_model(model),
            supports_multimodal=supports_multimodal(model),
            supports_pp=supports_pp(model),
            has_inner_state=has_inner_state(model),
            is_attention_free=is_attention_free(model),
        )
```

接口判断通过检查类的继承关系实现。例如 `vllm/model_executor/models/interfaces.py`：

```python
class SupportsLoRA:
    supported_lora_modules: List[str] = []
    embedding_modules: Dict[str, str] = {}
    embedding_padding_modules: List[str] = []

class SupportsPP:
    """标记模型支持 Pipeline Parallelism"""
    pass
```

---

## 3. 模型配置解析：config.json → ModelConfig

### 3.1 ModelConfig 的核心字段

`ModelConfig` 是所有模型配置的容器，定义在 `vllm/config.py` 中：

```
    ModelConfig 的关键字段
    ┌──────────────────────────────────────────────────────────────────┐
    │                                                                  │
    │  用户指定参数:                                                    │
    │  ├── model: str             模型路径或 HuggingFace ID              │
    │  ├── tokenizer: str         tokenizer 路径                        │
    │  ├── dtype: str             "auto" / "float16" / "bfloat16"      │
    │  ├── quantization: str      "awq" / "gptq" / "fp8" / None       │
    │  ├── max_model_len: int     最大序列长度                           │
    │  ├── seed: int              随机种子                              │
    │  ├── revision: str          模型版本                              │
    │  ├── enforce_eager: bool    是否禁用 CUDA graph                   │
    │  └── trust_remote_code: bool 是否信任远程代码                      │
    │                                                                  │
    │  从 config.json 解析:                                             │
    │  ├── hf_config: PretrainedConfig  (transformers 配置对象)          │
    │  │   ├── architectures: ["LlamaForCausalLM"]                      │
    │  │   ├── hidden_size: 4096                                       │
    │  │   ├── num_hidden_layers: 32                                    │
    │  │   ├── num_attention_heads: 32                                  │
    │  │   ├── num_key_value_heads: 8  (GQA 时与 num_attention_heads 不同)│
    │  │   ├── intermediate_size: 11008                                │
    │  │   ├── vocab_size: 32000                                       │
    │  │   ├── head_dim: 128  (或 hidden_size // num_attention_heads)   │
    │  │   ├── rope_theta: 10000.0                                     │
    │  │   └── max_position_embeddings: 8192                            │
    │  │                                                               │
    │  └── hf_text_config: PretrainedConfig  (纯文本部分，多模态时分离)    │
    │                                                                  │
    │  推导出的字段:                                                     │
    │  ├── max_model_len: int     验证后的最大序列长度                    │
    │  ├── embedding_mode: bool   是否为 embedding 模型                  │
    │  ├── is_attention_free: bool 是否为无注意力模型（如 Mamba）         │
    │  ├── has_inner_state: bool  是否有内部状态                         │
    │  └── multimodal_config: MultiModalConfig  (多模态模型)             │
    │                                                                  │
    └──────────────────────────────────────────────────────────────────┘
```

真实源码（config.py 第 37-200 行）：

```python
class ModelConfig:
    def __init__(self, model, tokenizer, tokenizer_mode, trust_remote_code,
                 dtype, seed, revision=None, code_revision=None,
                 rope_scaling=None, rope_theta=None, tokenizer_revision=None,
                 max_model_len=None, quantization=None, enforce_eager=None,
                 max_seq_len_to_capture=None, ...):
        self.model = model
        self.quantization = quantization
        # 核心：从 HuggingFace 加载配置
        self.hf_config = get_config(self.model, trust_remote_code, revision,
                                    code_revision, rope_scaling, rope_theta,
                                    config_format)
        self.hf_text_config = get_hf_text_config(self.hf_config)
        self.dtype = _get_and_verify_dtype(self.hf_text_config, dtype)

        # 检测是否为多模态/embedding/attention-free 模型
        architectures = getattr(self.hf_config, "architectures", [])
        self.multimodal_config = self._init_multimodal_config(limit_mm_per_prompt)
        self.embedding_mode = ModelRegistry.is_embedding_model(architectures)
        self.is_attention_free = ModelRegistry.is_attention_free_model(architectures)
        self.has_inner_state = ModelRegistry.model_has_inner_state(architectures)
```

### 3.2 关键配置字段详解

```
    num_attention_heads (32)  vs  num_key_value_heads (8)
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  MHA (Multi-Head Attention):                                   │
    │    num_attention_heads = num_key_value_heads = 32              │
    │    Q × 32个, K × 32个, V × 32个                                │
    │                                                                │
    │  GQA (Grouped-Query Attention) — LLaMA 3 70B:                  │
    │    num_attention_heads = 64, num_key_value_heads = 8           │
    │    Q × 64个, K × 8个, V × 8个                                  │
    │    每 8 个 Q head 共享 1 个 KV head                            │
    │                                                                │
    │  MQA (Multi-Query Attention) — Falcon 部分版本:                 │
    │    num_key_value_heads = 1                                     │
    │    所有 Q head 共享同一个 K, V                                  │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

`hidden_size`、`head_dim`、`num_attention_heads` 之间的关系（config.py 第 451-466 行）：

```python
def get_head_size(self) -> int:
    if hasattr(self.hf_text_config, "model_type"
               ) and self.hf_text_config.model_type == 'deepseek_v2':
        # DeepSeek V2 的 head_dim 是 192，FlashAttention 只支持 32/64/128/256
        # 需要 padding 到 256
        return 256
    if hasattr(self.hf_text_config, "head_dim"):
        return self.hf_text_config.head_dim
    # 默认推导：hidden_size / num_attention_heads
    return (self.hf_text_config.hidden_size //
            self.hf_text_config.num_attention_heads)
```

### 3.3 常见架构的 config.json 对比

**LLaMA 3 8B (config.json)**:
```json
{
  "architectures": ["LlamaForCausalLM"],
  "hidden_size": 4096,
  "intermediate_size": 14336,
  "num_attention_heads": 32,
  "num_hidden_layers": 32,
  "num_key_value_heads": 8,
  "rms_norm_eps": 1e-05,
  "rope_theta": 500000.0,
  "tie_word_embeddings": false,
  "vocab_size": 128256,
  "max_position_embeddings": 8192
}
```

**Qwen2 7B (config.json)**:
```json
{
  "architectures": ["Qwen2ForCausalLM"],
  "hidden_size": 3584,
  "intermediate_size": 18944,
  "num_attention_heads": 28,
  "num_hidden_layers": 28,
  "num_key_value_heads": 4,
  "rms_norm_eps": 1e-06,
  "rope_theta": 1000000.0,
  "tie_word_embeddings": false,
  "vocab_size": 151936,
  "use_sliding_window": false,
  "max_position_embeddings": 32768
}
```

**DeepSeek V2 (config.json 关键字段)**:
```json
{
  "architectures": ["DeepseekV2ForCausalLM"],
  "hidden_size": 5120,
  "intermediate_size": 12288,
  "moe_intermediate_size": 1536,
  "num_attention_heads": 128,
  "num_hidden_layers": 60,
  "num_key_value_heads": 128,
  "n_routed_experts": 160,
  "n_shared_experts": 2,
  "num_experts_per_tok": 6,
  "q_lora_rank": 1536,
  "kv_lora_rank": 512,
  "qk_nope_head_dim": 128,
  "qk_rope_head_dim": 64,
  "v_head_dim": 128,
  "vocab_size": 102400
}
```

---

## 4. 权重加载流水线

### 4.1 加载器类型与 LoadFormat

vLLM 支持多种加载格式，通过 `LoadFormat` 枚举和 `get_model_loader()` 工厂函数分发：

```
    LoadFormat 与对应的 Loader
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  LoadFormat.AUTO           → DefaultModelLoader                │
    │    ├── 自动检测 safetensors, .bin, .pt                          │
    │    ├── 支持 sharded 权重 (model-00001-of-00003.safetensors)     │
    │    └── 支持 Mistral 合并格式 (consolidated.safetensors)         │
    │                                                                │
    │  LoadFormat.SAFETENSORS    → DefaultModelLoader                │
    │    └── 强制使用 safetensors 格式                                │
    │                                                                │
    │  LoadFormat.PT             → DefaultModelLoader                │
    │    └── 强制使用 PyTorch .pt 格式                                │
    │                                                                │
    │  LoadFormat.DUMMY          → DummyModelLoader                  │
    │    └── 随机初始化权重（用于性能基准测试）                          │
    │                                                                │
    │  LoadFormat.TENSORIZER     → TensorizerLoader                  │
    │    └── 使用 CoreWeave 的 tensorizer 库快速序列化/反序列化        │
    │                                                                │
    │  LoadFormat.SHARDED_STATE  → ShardedStateLoader                │
    │    └── 直接加载每个 TP rank 的分片权重                           │
    │                                                                │
    │  LoadFormat.BITSANDBYTES   → BitsAndBytesModelLoader           │
    │    └── 支持 bitsandbytes 4bit/8bit 量化                         │
    │                                                                │
    │  LoadFormat.GGUF           → GGUFModelLoader                   │
    │    └── 加载 GGUF 格式文件（llama.cpp 等使用）                    │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

loader.py 第 1238-1259 行：

```python
def get_model_loader(load_config: LoadConfig) -> BaseModelLoader:
    if isinstance(load_config.load_format, type):
        return load_config.load_format(load_config)
    if load_config.load_format == LoadFormat.DUMMY:
        return DummyModelLoader(load_config)
    if load_config.load_format == LoadFormat.TENSORIZER:
        return TensorizerLoader(load_config)
    if load_config.load_format == LoadFormat.SHARDED_STATE:
        return ShardedStateLoader(load_config)
    if load_config.load_format == LoadFormat.BITSANDBYTES:
        return BitsAndBytesModelLoader(load_config)
    if load_config.load_format == LoadFormat.GGUF:
        return GGUFModelLoader(load_config)
    return DefaultModelLoader(load_config)
```

### 4.2 DefaultModelLoader 完整流程

```
    DefaultModelLoader.load_model() 详细流程
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  load_model(model_config, device_config, lora_config, ...)     │
    │  │                                                             │
    │  ├── ① 设置默认 dtype                                           │
    │  │     with set_default_torch_dtype(model_config.dtype):       │
    │  │                                                             │
    │  ├── ② 模型实例化（空权重）                                       │
    │  │     model = _initialize_model(model_config, load_config,    │
    │  │                               lora_config, cache_config)    │
    │  │     │                                                       │
    │  │     └── _initialize_model() 内部:                           │
    │  │         model_class, _ = get_model_architecture(model_config)│
    │  │         model = build_model(model_class, hf_config, ...)     │
    │  │         │                                                   │
    │  │         └── build_model() 内部:                              │
    │  │             extra_kwargs = {}                                │
    │  │             if supports_lora(model_class):                  │
    │  │                 extra_kwargs["lora_config"] = lora_config    │
    │  │             return model_class(                             │
    │  │                 config=hf_config,                           │
    │  │                 cache_config=cache_config,                   │
    │  │                 quant_config=quant_config,                  │
    │  │                 **extra_kwargs)                             │
    │  │                                                             │
    │  ├── ③ 加载权重                                                  │
    │  │     model.load_weights(self._get_all_weights(model_config, model))│
    │  │     │                                                       │
    │  │     └── _get_all_weights() 内部:                             │
    │  │         ┌── primary_weights: 从 model_config.model 加载      │
    │  │         └── secondary_weights: 模型的次要权重（如有）          │
    │  │                                                             │
    │  ├── ④ 量化后处理                                                │
    │  │     for _, module in model.named_modules():                 │
    │  │         quant_method = getattr(module, "quant_method", None) │
    │  │         if quant_method is not None:                        │
    │  │             quant_method.process_weights_after_loading(module)│
    │  │                                                             │
    │  └── ⑤ 返回 model.eval()                                        │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

loader.py 第 389-414 行：

```python
def load_model(self, *, model_config: ModelConfig,
               device_config: DeviceConfig,
               lora_config: Optional[LoRAConfig],
               parallel_config: ParallelConfig,
               scheduler_config: SchedulerConfig,
               cache_config: CacheConfig) -> nn.Module:
    target_device = torch.device(device_config.device)
    with set_default_torch_dtype(model_config.dtype):
        with target_device:
            model = _initialize_model(model_config, self.load_config,
                                      lora_config, cache_config,
                                      scheduler_config)

        model.load_weights(self._get_all_weights(model_config, model))

        for _, module in model.named_modules():
            quant_method = getattr(module, "quant_method", None)
            if quant_method is not None:
                with device_loading_context(module, target_device):
                    quant_method.process_weights_after_loading(module)
    return model.eval()
```

### 4.3 权重文件定位

`_prepare_weights()` 方法负责找到权重文件（loader.py 第 258-330 行）：

```
    权重文件定位流程
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  输入: model_name_or_path = "meta-llama/Meta-Llama-3-8B"       │
    │                                                                │
    │  ├── 本地路径? → 直接使用                                        │
    │  │                                                             │
    │  └── HuggingFace Hub ID? → 下载                                 │
    │       │                                                        │
    │       ├── 1. _maybe_download_from_modelscope()                  │
    │       │     如果 VLLM_USE_MODELSCOPE=1，从 ModelScope 下载       │
    │       │                                                        │
    │       ├── 2. download_weights_from_hf()                        │
    │       │     根据 load_format 确定 allow_patterns:               │
    │       │     AUTO:       ["*.safetensors", "*.bin"]              │
    │       │     SAFETENSORS: ["*.safetensors"]                      │
    │       │     PT:          ["*.pt"]                                │
    │       │                                                        │
    │       ├── 3. 下载 model.safetensors.index.json                  │
    │       │     用于确定分片文件的映射关系                             │
    │       │                                                        │
    │       └── 4. filter_duplicate_safetensors_files()              │
    │            排除 index 中未列出的重复文件                          │
    │            (如 Mistral-7B-v0.3 同时有分片和合并文件)              │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

### 4.4 Safetensors 格式与 mmap 支持

Safetensors 是 vLLM 默认首选格式，支持 memory-mapped 零拷贝加载：

```python
# weight_utils.py 第 395-410 行
def safetensors_weights_iterator(
    hf_weights_files: List[str]
) -> Generator[Tuple[str, torch.Tensor], None, None]:
    """逐文件迭代 safetensors 权重。"""
    enable_tqdm = not torch.distributed.is_initialized(
    ) or torch.distributed.get_rank() == 0
    for st_file in tqdm(
            hf_weights_files,
            desc="Loading safetensors checkpoint shards",
            disable=not enable_tqdm,
            bar_format=_BAR_FORMAT,
    ):
        with safe_open(st_file, framework="pt") as f:
            for name in f.keys():
                param = f.get_tensor(name)
                yield name, param
```

`safe_open` 内部使用了 mmap 机制：
- 文件数据被映射到进程的虚拟地址空间，不需要完整读入内存
- 当实际访问特定张量时才触发页面加载（page fault）
- 对于 TP 场景，每个 rank 只访问自己需要的分片，大幅减少内存占用

### 4.5 分片模型加载：model.safetensors.index.json

大型模型（如 LLaMA 70B）通常分片存储：

```
    分片文件结构
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  model-00001-of-00015.safetensors                              │
    │  model-00002-of-00015.safetensors                              │
    │  ...                                                           │
    │  model-00015-of-00015.safetensors                              │
    │  model.safetensors.index.json  ← 索引文件                       │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

索引文件 `model.safetensors.index.json` 内容示例：

```json
{
  "metadata": {
    "total_size": 140765640192
  },
  "weight_map": {
    "model.embed_tokens.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.input_layernorm.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.self_attn.q_proj.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.self_attn.k_proj.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.self_attn.v_proj.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.self_attn.o_proj.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.mlp.gate_proj.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.mlp.up_proj.weight": "model-00001-of-00015.safetensors",
    "model.layers.0.mlp.down_proj.weight": "model-00002-of-00015.safetensors",
    "model.layers.1.self_attn.q_proj.weight": "model-00002-of-00015.safetensors",
    ...
  }
}
```

过滤重复文件的逻辑（weight_utils.py 第 298-319 行）：

```python
def filter_duplicate_safetensors_files(hf_weights_files, hf_folder, index_file):
    index_file_name = os.path.join(hf_folder, index_file)
    if not os.path.isfile(index_file_name):
        return hf_weights_files

    with open(index_file_name, "r") as f:
        weight_map = json.load(f)["weight_map"]
    weight_files_in_index = set()
    for weight_name in weight_map:
        weight_files_in_index.add(
            os.path.join(hf_folder, weight_map[weight_name]))
    hf_weights_files = [
        f for f in hf_weights_files if f in weight_files_in_index
    ]
    return hf_weights_files
```

### 4.6 Tensor Parallelism 权重分片

当使用多 GPU Tensor Parallelism 时（`--tensor-parallel-size N`），每个 rank 只加载自己需要的权重分片：

```
    TP=2 时的权重分片策略
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  Column Parallel (沿 dim 0 分片):                               │
    │    适用于: embed_tokens, lm_head                                │
    │    ┌──────────────────┐                                        │
    │    │   完整权重矩阵     │  [vocab_size, hidden_size]              │
    │    │  (32000 × 4096)  │                                        │
    │    └──────────────────┘                                        │
    │      rank 0: [0:16000, :]   上半部分                            │
    │      rank 1: [16000:32000, :] 下半部分                          │
    │                                                                │
    │  Row Parallel (沿 dim 1 分片):                                  │
    │    适用于: q_proj, k_proj, v_proj, gate_proj, up_proj           │
    │    ┌──────────────────────────┐                                │
    │    │      完整权重矩阵          │  [hidden_size, 4096]            │
    │    │     (4096 × 4096)        │                                │
    │    └──────────────────────────┘                                │
    │      rank 0: [:, 0:2048]   左半部分                             │
    │      rank 1: [:, 2048:4096] 右半部分                            │
    │                                                                │
    │  注意：down_proj, o_proj 的完整结果需要通过 all-reduce 求和       │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

权重加载器函数（weight_utils.py）：

```python
def default_weight_loader(param: torch.Tensor,
                          loaded_weight: torch.Tensor) -> None:
    """默认权重加载器。"""
    if param.numel() == 1 and loaded_weight.numel() == 1:
        param.data.fill_(loaded_weight.item())
    else:
        assert param.size() == loaded_weight.size()
        param.data.copy_(loaded_weight)

def row_parallel_weight_loader(param: torch.Tensor,
                               loaded_weight: torch.Tensor) -> None:
    """Row Parallel 权重加载器 — 沿 dim 0 分片。"""
    tp_rank = get_tensor_model_parallel_rank()
    shard_dim = 0 if param.dim() != 1 else None
    if shard_dim is not None:
        shard_size = param.data.shape[shard_dim]
        start_idx = tp_rank * shard_size
        loaded_weight = loaded_weight.narrow(shard_dim, start_idx, shard_size)
    return default_weight_loader(param, loaded_weight)

def sharded_weight_loader(shard_axis: int) -> LoaderFunction:
    """创建沿指定轴分片的权重加载器。"""
    def loader(param, loaded_weight):
        tp_rank = get_tensor_model_parallel_rank()
        shard_size = param.data.shape[shard_axis]
        start_idx = tp_rank * shard_size
        loaded_weight = loaded_weight.narrow(shard_axis, start_idx, shard_size)
        return default_weight_loader(param, loaded_weight)
    return loader
```

### 4.7 AutoWeightsLoader：智能权重分发

`AutoWeightsLoader` 是 vLLM 中大多数新模型的权重加载机制，通过树形分组自动将权重分发到对应的子模块和参数：

```python
# models/utils.py 第 64-192 行
class AutoWeightsLoader:
    """
    自动将权重加载到 nn.Module 中。
    只需迭代一次权重就能自动检测子模块和参数。
    """

    def __init__(self, module, *, skip_prefixes=None,
                 ignore_unexpected_prefixes=None):
        self.module = module
        self.skip_prefixes = skip_prefixes or []

    def _groupby_prefix(self, weights):
        """按第一级前缀分组。"""
        weights_by_parts = ((weight_name.split(".", 1), weight_data)
                           for weight_name, weight_data in weights)
        for prefix, group in itertools.groupby(weights_by_parts,
                                              key=lambda x: x[0][0]):
            yield (prefix, (("" if len(parts) == 1 else parts[1], data)
                           for parts, data in group))

    def _load_module(self, base_prefix, module, weights):
        """递归加载模块权重。"""
        if isinstance(module, PPMissingLayer):
            return
        # 如果模块有自己的 load_weights 方法，调用它
        if module != self.module:
            module_load_weights = getattr(module, "load_weights", None)
            if callable(module_load_weights):
                module_load_weights(weights)
                return

        child_modules = dict(module.named_children())
        child_params = dict(module.named_parameters(recurse=False))

        for child_prefix, child_weights in self._groupby_prefix(weights):
            prefix = self._get_qualname(base_prefix, child_prefix)
            if self._can_skip(prefix):
                continue
            if child_prefix in child_modules:
                self._load_module(prefix, child_modules[child_prefix],
                                 child_weights)
            elif child_prefix in child_params:
                self._load_param(prefix, child_params[child_prefix],
                                child_weights)
            else:
                if not self._can_ignore_unexpected(prefix):
                    raise ValueError(f"No module or param named '{prefix}'")

    def load_weights(self, weights, *, mapper=None):
        if mapper is not None:
            weights = mapper.apply(weights)
        self._load_module("", self.module, weights)
```

### 4.8 LLaMA 模型的具体 load_weights 实现

LLaMA 模型（很多模型复用它）有两层 `load_weights`：模块级和模型级。

**模块级**（llama.py 第 358-416 行）：处理 stacked parameters（如 qkv_proj 是由 q_proj、k_proj、v_proj 合并的）：

```python
# LlamaModel.load_weights
def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
    stacked_params_mapping = [
        (".qkv_proj", ".q_proj", "q"),
        (".qkv_proj", ".k_proj", "k"),
        (".qkv_proj", ".v_proj", "v"),
        (".gate_up_proj", ".gate_proj", 0),
        (".gate_up_proj", ".up_proj", 1),
    ]
    params_dict = dict(self.named_parameters())
    for name, loaded_weight in weights:
        if "rotary_emb.inv_freq" in name:
            continue
        # 处理 stacked parameters
        for param_name, weight_name, shard_id in stacked_params_mapping:
            if weight_name not in name:
                continue
            name = name.replace(weight_name, param_name)
            if name.endswith(".bias") and name not in params_dict:
                continue
            if is_pp_missing_parameter(name, self):
                continue
            param = params_dict[name]
            weight_loader = param.weight_loader
            weight_loader(param, loaded_weight, shard_id)
            break
        else:
            # 非 stacked 参数直接加载
            name = maybe_remap_kv_scale_name(name, params_dict)
            if name is None:
                continue
            if is_pp_missing_parameter(name, self):
                continue
            param = params_dict[name]
            weight_loader = getattr(param, "weight_loader",
                                   default_weight_loader)
            weight_loader(param, loaded_weight)
```

**模型级**（llama.py 第 574-582 行）：使用 AutoWeightsLoader 进行更清晰的加载：

```python
# LlamaForCausalLM.load_weights
def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
    loader = AutoWeightsLoader(
        self,
        skip_prefixes=(["lm_head."]
                       if self.config.tie_word_embeddings else None),
    )
    loader.load_weights(
        self.maybe_remap_mistral(name, loaded_weight)
        for name, loaded_weight in weights)
```

### 4.9 列并行 + 行并行的组合（一个完整 Transformer 层）

```
    ┌──────────────────────────────────────────────────────────────┐
    │           Transformer Layer with TP=2                        │
    │                                                              │
    │   Input X [seq, hidden]  ← 已通过 all-reduce 同步            │
    │       │                                                     │
    │       ├──────> Attention Block ──────┐                       │
    │       │                              │                       │
    │       │  ┌─────────────────────────┐ │                       │
    │       │  │ 列并行: Q/K/V 投影      │ │                      │
    │       │  │ W_q [h, h/tp]  (本地)  │ │                      │
    │       │  │ W_k [h, h/tp]  (本地)  │ │                      │
    │       │  │ W_v [h, h/tp]  (本地)  │ │                      │
    │       │  └──────────┬──────────────┘ │                      │
    │       │             │               │                       │
    │       │             ▼               │                       │
    │       │  ┌─────────────────────────┐ │                       │
    │       │  │ Flash Attention (本地)  │ │                      │
    │       │  │ 每个 GPU 计算自己的 head│ │                      │
    │       │  └──────────┬──────────────┘ │                      │
    │       │             │               │                       │
    │       │             ▼               │                       │
    │       │  ┌─────────────────────────┐ │                       │
    │       │  │ 行并行: O 投影          │ │                      │
    │       │  │ W_o [h/tp, h] (本地)   │ │                      │
    │       │  └──────────┬──────────────┘ │                      │
    │       │             │               │                       │
    │       │             ▼               │                       │
    │       │  ┌─────────────────────────┐ │                       │
    │       │  │ All-Reduce (求和)       │ │                      │
    │       │  │ Y = Y_0 + Y_1          │ │                      │
    │       │  └──────────┬──────────────┘ │                      │
    │       │             │               │                       │
    │       ├──────> MLP Block ───────────┘                       │
    │       │                                                     │
    │       │  ┌─────────────────────────┐                        │
    │       │  │ 列并行: gate/up 投影    │                        │
    │       │  │ W_gate [h, 8h/3/tp]     │                        │
    │       │  │ W_up   [h, 8h/3/tp]     │                        │
    │       │  └──────────┬──────────────┘                        │
    │       │             │                                       │
    │       │             ▼                                       │
    │       │  ┌─────────────────────────┐                        │
    │       │  │ SiLU(gate) * up (本地) │                        │
    │       │  └──────────┬──────────────┘                        │
    │       │             │                                       │
    │       │             ▼                                       │
    │       │  ┌─────────────────────────┐                        │
    │       │  │ 行并行: down 投影       │                        │
    │       │  │ W_down [8h/3/tp, h]     │                        │
    │       │  └──────────┬──────────────┘                        │
    │       │             │                                       │
    │       │             ▼                                       │
    │       │  ┌─────────────────────────┐                        │
    │       │  │ All-Reduce (求和)       │                        │
    │       │  └──────────┬──────────────┘                        │
    │       │             │                                       │
    │       ▼             ▼                                       │
    │   Output Y [seq, hidden]                                     │
    └──────────────────────────────────────────────────────────────┘
```

**同步模式总结：**

| 操作 | 方向 | 通信模式 | 通信量 |
|---|---|---|---|
| QKV 投影 | 列并行 | Identity | 0 (无需通信) |
| O 投影 | 行并行 | All-Reduce | 2*(tp-1)/tp * (size/tp) |
| Gate/Up | 列并行 | Identity | 0 |
| Down | 行并行 | All-Reduce | 2*(tp-1)/tp * (size/tp) |

---

## 5. 量化模型加载

### 5.1 量化方法注册表

vLLM 通过 `QUANTIZATION_METHODS` 字典统一管理所有量化方法（`quantization/__init__.py` 第 32-54 行）：

```python
QUANTIZATION_METHODS: Dict[str, Type[QuantizationConfig]] = {
    "aqlm": AQLMConfig,
    "awq": AWQConfig,
    "deepspeedfp": DeepSpeedFPConfig,
    "tpu_int8": Int8TpuConfig,
    "fp8": Fp8Config,
    "fbgemm_fp8": FBGEMMFp8Config,
    "modelopt": ModelOptFp8Config,
    "marlin": MarlinConfig,
    "gguf": GGUFConfig,
    "gptq_marlin_24": GPTQMarlin24Config,
    "gptq_marlin": GPTQMarlinConfig,
    "awq_marlin": AWQMarlinConfig,
    "gptq": GPTQConfig,
    "compressed-tensors": CompressedTensorsConfig,
    "bitsandbytes": BitsAndBytesConfig,
    "qqq": QQQConfig,
    "experts_int8": ExpertsInt8Config,
    "neuron_quant": NeuronQuantConfig,
    "ipex": IPEXConfig,
}
```

量化配置的自动检测（config.py 第 249-289 行）：

```python
def _verify_quantization(self) -> None:
    quant_cfg = self._parse_quant_hf_config()
    if quant_cfg is not None:
        quant_method = quant_cfg.get("quant_method", "").lower()
        # 遍历所有量化方法，看哪个能匹配
        for _, method in QUANTIZATION_METHODS.items():
            quantization_override = method.override_quantization_method(
                quant_cfg, self.quantization)
            if quantization_override:
                quant_method = quantization_override
                self.quantization = quantization_override
                break
        if self.quantization is None:
            self.quantization = quant_method
        elif self.quantization != quant_method:
            raise ValueError(...)
```

### 5.2 AWQ: INT4 量化详解

AWQ (Activation-aware Weight Quantization) 使用 INT4 存储权重，FP16 存储 scales：

```
    AWQ 权重的内存布局 (group_size=128)
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  原始 FP16 权重: [input_size, output_size]                      │
    │     = [4096, 4096] = 4096 × 4096 × 2 bytes = 32 MB            │
    │                                                                │
    │  AWQ INT4 量化后:                                               │
    │                                                                │
    │  qweight: [input_size, output_size // 8]  (INT32 packed, 8×4bit)│
    │     = [4096, 512] × 4 bytes = 8 MB                             │
    │                                                                │
    │  qzeros:  [input_size // group_size, output_size // 8]         │
    │     = [32, 512] × 4 bytes = 64 KB  (group_size=128)            │
    │                                                                │
    │  scales:  [input_size // group_size, output_size]  (FP16)       │
    │     = [32, 4096] × 2 bytes = 256 KB                            │
    │                                                                │
    │  总大小: ~8.3 MB  (压缩比 ~3.8x)                                 │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

AWQ 量化配置源码（`quantization/awq.py`）：

```python
class AWQConfig(QuantizationConfig):
    def __init__(self, weight_bits: int, group_size: int, zero_point: bool):
        self.weight_bits = weight_bits       # 4
        self.group_size = group_size          # 128 (常见值)
        self.zero_point = zero_point           # True
        self.pack_factor = 32 // self.weight_bits  # 8

    @classmethod
    def from_config(cls, config: Dict[str, Any]) -> "AWQConfig":
        weight_bits = cls.get_from_keys(config, ["w_bit", "bits"])
        group_size = cls.get_from_keys(config, ["q_group_size", "group_size"])
        zero_point = cls.get_from_keys(config, ["zero_point"])
        return cls(weight_bits, group_size, zero_point)

    def get_quant_method(self, layer, prefix) -> Optional["AWQLinearMethod"]:
        if isinstance(layer, LinearBase):
            return AWQLinearMethod(self)
        return None

    def get_min_capability(cls) -> int:
        return 75  # Turing 及以上
```

`AWQLinearMethod.create_weights()` — 创建量化权重参数（awq.py 第 86-141 行）：

```python
def create_weights(self, layer, input_size_per_partition,
                   output_partition_sizes, input_size, output_size,
                   params_dtype, **extra_weight_attrs):
    weight_loader = extra_weight_attrs.get("weight_loader")
    pack_factor = self.quant_config.pack_factor  # 8

    qweight = PackedvLLMParameter(data=torch.empty(
        input_size_per_partition,
        output_size_per_partition // pack_factor,
        dtype=torch.int32,
    ), input_dim=0, output_dim=1, packed_dim=1,
       packed_factor=pack_factor, weight_loader=weight_loader)
    layer.register_parameter("qweight", qweight)

    qzeros = PackedvLLMParameter(data=torch.empty(
        input_size_per_partition // self.quant_config.group_size,
        output_size_per_partition // pack_factor,
        dtype=torch.int32,
    ), input_dim=0, output_dim=1, packed_dim=1,
       packed_factor=pack_factor, weight_loader=weight_loader)
    layer.register_parameter("qzeros", qzeros)

    scales = GroupQuantScaleParameter(data=torch.empty(
        input_size_per_partition // self.quant_config.group_size,
        output_size_per_partition,
        dtype=params_dtype,
    ), input_dim=0, output_dim=1, weight_loader=weight_loader)
    layer.register_parameter("scales", scales)
```

AWQ 推理时的反量化（awq.py 第 150-172 行）：

```python
def apply(self, layer, x, bias=None) -> torch.Tensor:
    qweight = layer.qweight
    scales = layer.scales
    qzeros = layer.qzeros
    pack_factor = self.quant_config.pack_factor
    out_shape = (x.shape[:-1] + (qweight.shape[-1] * pack_factor, ))
    reshaped_x = x.reshape(-1, x.shape[-1])

    FP16_MATMUL_HEURISTIC_CONDITION = x.shape[:-1].numel() >= 256

    if FP16_MATMUL_HEURISTIC_CONDITION:
        # 大批量：先反量化到 FP16，再做 matmul
        out = ops.awq_dequantize(qweight, scales, qzeros, 0, 0, 0)
        out = torch.matmul(reshaped_x, out)
    else:
        # 小批量：直接使用 INT4 gemm kernel（更快）
        out = ops.awq_gemm(reshaped_x, qweight, scales, qzeros, pack_factor)
    if bias is not None:
        out.add_(bias)
    return out.reshape(out_shape)
```

**Marlin Kernel 加速**：`awq_marlin` 是 AWQ 的优化变体，使用专门的 Marlin CUDA kernel 实现更快的 INT4 矩阵乘法。它会在 `process_weights_after_loading` 阶段将 weight 重新打包为 Marlin 格式。

### 5.3 GPTQ: 量化详解

GPTQ 支持 2/3/4/8 位量化，与 AWQ 最大的区别是它支持 `desc_act`（descending activation order）：

```python
# quantization/gptq.py 第 21-74 行
class GPTQConfig(QuantizationConfig):
    def __init__(self, weight_bits: int, group_size: int,
                 desc_act: bool, lm_head_quantized: bool):
        self.weight_bits = weight_bits          # 4
        self.group_size = group_size             # 128
        self.desc_act = desc_act                 # True/False
        self.lm_head_quantized = lm_head_quantized  # True/False
        self.pack_factor = Fraction(32, self.weight_bits)

    @classmethod
    def from_config(cls, config):
        weight_bits = cls.get_from_keys(config, ["bits"])
        group_size = cls.get_from_keys(config, ["group_size"])
        desc_act = cls.get_from_keys(config, ["desc_act"])
        lm_head_quantized = cls.get_from_keys_or(config, ["lm_head"], default=False)
        return cls(weight_bits, group_size, desc_act, lm_head_quantized)
```

GPTQ 配置文件 `quantize_config.json` 示例：

```json
{
  "bits": 4,
  "group_size": 128,
  "desc_act": false,
  "damp_percent": 0.01,
  "sym": true,
  "true_sequential": true,
  "model_file_base_name": "model",
  "quant_method": "gptq"
}
```

### 5.4 FP8: Hopper 原生量化

FP8 是 NVIDIA Hopper (SM90) 架构的原生数据类型，无需复杂的反量化 kernel：

```python
# quantization/fp8.py 第 36-93 行
class Fp8Config(QuantizationConfig):
    def __init__(self, is_checkpoint_fp8_serialized=False,
                 activation_scheme="dynamic", ignored_layers=None):
        self.is_checkpoint_fp8_serialized = is_checkpoint_fp8_serialized
        self.activation_scheme = activation_scheme  # "dynamic" 或 "static"
        self.ignored_layers = ignored_layers or []

    @classmethod
    def get_min_capability(cls) -> int:
        return 80  # Ampere 及以上

    def get_quant_method(self, layer, prefix):
        from vllm.attention.layer import Attention
        if isinstance(layer, LinearBase):
            if is_layer_skipped(prefix, self.ignored_layers):
                return UnquantizedLinearMethod()
            return Fp8LinearMethod(self)
        elif isinstance(layer, FusedMoE):
            return Fp8MoEMethod(self)
        elif isinstance(layer, Attention):
            return Fp8KVCacheMethod(self)
        return None
```

FP8 使用时的命令行参数：

```bash
# 直接加载 FP8 量化 checkpoint
vllm serve neuralmagic/Meta-Llama-3.1-8B-Instruct-FP8

# 运行时 FP8 量化（动态）
vllm serve meta-llama/Meta-Llama-3-8B --quantization fp8
```

### 5.5 量化后处理：process_weights_after_loading

这是量化的关键步骤。加载完原始权重后，量化方法需要对权重进行重打包或转置等操作（loader.py 第 404-413 行）：

```python
for _, module in model.named_modules():
    quant_method = getattr(module, "quant_method", None)
    if quant_method is not None:
        with device_loading_context(module, target_device):
            quant_method.process_weights_after_loading(module)
```

### 5.6 量化格式对比

```
    ┌──────────────────────────────────────────────────────────────────────┐
    │                      QUANTIZATION FORMATS IN vLLM                    │
    ├──────────────┬───────────────┬──────────────┬────────────┬───────────┤
    │ 格式          │ 权重精度       │ 激活精度      │ 内存 vs FP16│ GPU 要求   │
    ├──────────────┼───────────────┼──────────────┼────────────┼───────────┤
    │ FP16 (基线)  │ FP16 (16-bit) │ FP16         │ 1.0×       │ 所有 GPU   │
    │ BF16         │ BF16 (16-bit) │ BF16         │ 1.0×       │ A100+     │
    │ AWQ-INT4     │ INT4 (4-bit)  │ FP16         │ ~0.25×     │ SM 75+    │
    │ GPTQ-INT4    │ INT4 (4-bit)  │ FP16         │ ~0.25×     │ SM 60+    │
    │ FP8 (NV)     │ FP8 (8-bit)   │ FP8          │ ~0.5×      │ H100      │
    │ AWQ_Marlin   │ INT4 (4-bit)  │ FP16         │ ~0.25×     │ SM 80+    │
    │ GPTQ_Marlin  │ INT4 (4-bit)  │ FP16         │ ~0.25×     │ SM 80+    │
    └──────────────┴───────────────┴──────────────┴────────────┴───────────┘
```

---

## 6. LoRA 适配器加载

### 6.1 LoRA 配置

`LoRAConfig` 定义在 `config.py` 第 1526-1575 行：

```python
class LoRAConfig:
    max_lora_rank: int            # 最大 LoRA rank (8, 16, 32, 64, 128, 256)
    max_loras: int                # 最多同时加载的 LoRA 适配器数
    fully_sharded_loras: bool = False  # 是否分片存储 LoRA
    max_cpu_loras: Optional[int] = None  # CPU 上缓存的 LoRA 数量
    lora_dtype: Optional[torch.dtype] = None
    lora_extra_vocab_size: int = 256    # LoRA 额外词汇表大小
    lora_vocab_padding_size: ClassVar[int] = 256
    long_lora_scaling_factors: Optional[Tuple[float]] = None

    def __post_init__(self):
        possible_max_ranks = (8, 16, 32, 64, 128, 256)
        if self.max_lora_rank not in possible_max_ranks:
            raise ValueError(...)
        if self.max_cpu_loras is None:
            self.max_cpu_loras = self.max_loras

    def verify_with_model_config(self, model_config):
        if self.lora_dtype in (None, "auto"):
            self.lora_dtype = model_config.dtype
        if model_config.quantization and model_config.quantization not in ["awq", "gptq"]:
            logger.warning("%s quantization is not tested with LoRA yet.",
                           model_config.quantization)
```

启动命令：

```bash
# 启用 LoRA + 加载指定适配器
vllm serve meta-llama/Meta-Llama-3-8B \
    --enable-lora \
    --lora-modules my-adapter=/path/to/lora/adapter \
    --max-lora-rank 16 \
    --max-loras 4
```

### 6.2 LoRA 与基础权重的共存机制

```
    LoRA 层与基础层的共存架构
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  # 基础层 (pretrained, frozen)                                  │
    │  base_weight: [hidden_size, output_size]   (4096, 4096)        │
    │                                                                │
    │  # LoRA 层 (trainable, rank r)                                  │
    │  lora_A: [hidden_size, r]     (4096, 16)   ← 低秩分解 A        │
    │  lora_B: [r, output_size]     (16, 4096)   ← 低秩分解 B        │
    │                                                                │
    │  # 推理时的输出                                                   │
    │  output = x @ base_weight^T + (x @ lora_A @ lora_B) * scaling  │
    │           \________________/   \_____________________________/  │
    │            冻结的基础权重             可切换的 LoRA 增量          │
    │                                                                │
    │  GPU 内存布局:                                                   │
    │  ┌──────────────────┐                                          │
    │  │   基础模型权重     │  ~15 GB (LLaMA-3-8B)                     │
    │  ├──────────────────┤                                          │
    │  │   LoRA 槽位 0     │  预分配，即使未使用也占用显存                │
    │  │   LoRA 槽位 1     │  每个 rank=16 的 LoRA 约 50MB             │
    │  │   LoRA 槽位 2     │                                          │
    │  │   LoRA 槽位 3     │                                          │
    │  ├──────────────────┤                                          │
    │  │   KV Cache       │  动态增长                                 │
    │  └──────────────────┘                                          │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

### 6.3 LoRA 适配器的加载流程

```
    LoRA 适配器加载流程
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  ① 请求到达: POST /v1/completions                              │
    │     body.model = "my-adapter"  ← 指定使用哪个 LoRA              │
    │     │                                                          │
    │     ▼                                                          │
    │  ② engine 解析请求: 从 model 字段提取 lora_name                  │
    │     lora_request = LoRARequest(lora_name="my-adapter", ...)    │
    │     │                                                          │
    │     ▼                                                          │
    │  ③ 查找适配器:                                                  │
    │     lora_manager.add_adapter(lora_request)                     │
    │     ├── 如果已在 GPU 缓存中 → 直接使用                            │
    │     ├── 如果在 CPU 缓存中 → 迁移到 GPU                           │
    │     └── 如果不在缓存中 → 从磁盘加载                               │
    │         │                                                      │
    │         └── LoRAModel.from_lora_tensors(...)                   │
    │             ├── 读取 adapter_model.safetensors                 │
    │             ├── 读入所有 lora_A, lora_B 张量                    │
    │             ├── 放入 AdapterLRUCache                            │
    │             └── 如果缓存满了 → LRU 淘汰                            │
    │     │                                                          │
    │     ▼                                                          │
    │  ④ 设置活跃适配器: set_active_loras({lora_request})              │
    │     └── 在下一轮推理时，Punica kernel 使用对应的 lora_A/B        │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

### 6.4 LoRA 的 per-request 选择

在 API 层面，用户通过 `model` 字段选择使用哪个 LoRA：

```bash
# 使用默认模型（无 LoRA）
curl http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "meta-llama/Meta-Llama-3-8B",
    "prompt": "Hello, world!",
    "max_tokens": 50
  }'

# 使用指定 LoRA 适配器
curl http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "my-adapter",
    "prompt": "Hello, world!",
    "max_tokens": 50
  }'
```

### 6.5 LoRALayerWeights 数据结构

```python
# lora/lora.py 第 10-58 行
class LoRALayerWeights:
    """单个 LoRA 层的权重，包含两个低秩矩阵。"""

    def __init__(self, module_name, rank, lora_alpha,
                 lora_a, lora_b, embeddings_tensor=None, scaling=None):
        self.module_name = module_name
        self.rank = rank
        self.lora_alpha = lora_alpha
        self.lora_a = lora_a              # [input_dim, rank]
        self.lora_b = lora_b              # [rank, output_dim]
        self.embeddings_tensor = embeddings_tensor

        if scaling is None:
            self.scaling = self.lora_alpha / self.rank
        else:
            self.scaling = scaling

    def optimize(self) -> "LoRALayerWeights":
        """将 scaling 合并到 lora_b 中，避免推理时的乘法。"""
        if self.scaling == 1:
            return self
        self.lora_b *= self.scaling
        self.scaling = 1
        return self
```

### 6.6 LoRA 内存估算

```
    LoRA 内存 = Σ(target_modules) × num_layers × (d × r + r × k) × 2 bytes

    示例: LLaMA-7B, r=8, target=[q_proj, v_proj]

    q_proj: d=4096, k=4096
            A: 4096 × 8 = 32,768 参数
            B: 8 × 4096 = 32,768 参数
            每层: 65,536 × 参数 × 2 bytes = 131 KB

    v_proj: 同上, ~131 KB

    总计: 2 × 32 layers × 131 KB ≈ 8.4 MB per adapter

    如果有 100 个 LoRA adapter:
    总计: 100 × 8.4 MB = 840 MB  ← 远小于完整模型 (14 GB)
```

---

## 7. 内存分析与 warmup

### 7.1 内存分析流程

vLLM 通过 dummy 前向传播来精确测量模型的内存占用：

```
    determine_num_available_blocks() 内存分析流程
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  ① 记录初始空闲内存                                               │
    │     torch.cuda.empty_cache()                                   │
    │     init_gpu_memory = torch.cuda.mem_get_info()[0]             │
    │     # 例如: 80 GB 的 A100, init_gpu_memory = 79.3 GB           │
    │     │                                                          │
    │     ▼                                                          │
    │  ② 执行 dummy 前向传播                                           │
    │     profile_run()                                              │
    │     ├── 构建最大 batch 的 dummy 输入                             │
    │     │   max_num_seqs × max_num_batched_tokens                  │
    │     ├── 如有 LoRA: 创建 max_loras 个 dummy lora                 │
    │     ├── 如有 MultiModal: 包含最大数量的 dummy 图像 token          │
    │     └── self.execute_model(model_input, kv_caches, ...)         │
    │     │                                                          │
    │     ▼                                                          │
    │  ③ 计算峰值内存                                                   │
    │     torch.cuda.synchronize()                                   │
    │     free_gpu_memory, total_gpu_memory = torch.cuda.mem_get_info()│
    │     peak_memory = init_gpu_memory - free_gpu_memory             │
    │     # 例如: 79.3 - 63.5 = 15.8 GB (模型权重 + 激活值等)         │
    │     │                                                          │
    │     ▼                                                          │
    │  ④ 计算可分配 KV cache blocks                                    │
    │     num_gpu_blocks = int(                                       │
    │         (total_gpu_memory * gpu_memory_utilization              │
    │          - peak_memory) // cache_block_size                     │
    │     )                                                          │
    │     # 例如: (80 * 0.9 - 15.8) GB / block_size                  │
    │     #      = (72 - 15.8) / block_size                          │
    │     #      ≈ 56.2 GB 给 KV cache                               │
    │     │                                                          │
    │     ▼                                                          │
    │  ⑤ 分配 KV cache                                               │
    │     _init_cache_engine()                                       │
    │     └── CacheEngine 分配 num_gpu_blocks 个 GPU 内存块            │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

核心源码（worker.py 第 204-253 行）：

```python
@torch.inference_mode()
def determine_num_available_blocks(self) -> Tuple[int, int]:
    torch.cuda.empty_cache()

    # 用 dummy input 执行一次前向传播来分析内存占用
    self.model_runner.profile_run()

    # 基于 profiled 峰值内存计算可分配的 KV cache block 数量
    torch.cuda.synchronize()
    free_gpu_memory, total_gpu_memory = torch.cuda.mem_get_info()
    peak_memory = self.init_gpu_memory - free_gpu_memory
    assert peak_memory > 0

    cache_block_size = self.get_cache_block_size_bytes()
    if cache_block_size == 0:
        num_gpu_blocks = 0
        num_cpu_blocks = 0
    else:
        num_gpu_blocks = int(
            (total_gpu_memory * self.cache_config.gpu_memory_utilization -
             peak_memory) // cache_block_size)
        num_cpu_blocks = int(self.cache_config.swap_space_bytes //
                            cache_block_size)
    num_gpu_blocks = max(num_gpu_blocks, 0)
    gc.collect()
    torch.cuda.empty_cache()
    return num_gpu_blocks, num_cpu_blocks
```

### 7.2 profile_run() 详细实现

```python
# model_runner.py 第 1202-1311 行
@torch.inference_mode()
def profile_run(self) -> None:
    sampling_params = SamplingParams(top_p=0.99, top_k=self.vocab_size - 1)
    max_num_batched_tokens = self.scheduler_config.max_num_batched_tokens
    max_num_seqs = self.scheduler_config.max_num_seqs

    # 创建 dummy LoRA 请求以占用最大 LoRA 内存
    dummy_lora_requests = []
    if self.lora_config:
        with self.lora_manager.dummy_lora_cache():
            for idx in range(self.lora_config.max_loras):
                lora_id = idx + 1
                dummy_lora_request = LoRARequest(
                    lora_name=f"warmup_{lora_id}",
                    lora_int_id=lora_id,
                    lora_path="/not/a/real/path",
                )
                self.lora_manager.add_dummy_lora(dummy_lora_request,
                                                 rank=LORA_WARMUP_RANK)
                dummy_lora_requests.append(dummy_lora_request)

    # 构建 max_num_seqs 个序列，总共 max_num_batched_tokens 个 token
    seqs = []
    batch_size = 0
    for group_id in range(max_num_seqs):
        seq_len = (max_num_batched_tokens // max_num_seqs +
                   (group_id < max_num_batched_tokens % max_num_seqs))
        batch_size += seq_len
        seq_data, dummy_multi_modal_data = \
            self.input_registry.dummy_data_for_profiling(
                self.model_config, seq_len, self.mm_registry)
        seq = SequenceGroupMetadata(
            request_id=str(group_id),
            is_prompt=True,
            seq_data={group_id: seq_data},
            sampling_params=sampling_params,
            block_tables=None,
        )
        seqs.append(seq)

    # 执行模型
    model_input = self.prepare_model_input(
        seqs, finished_requests_ids=[seq.request_id for seq in seqs])
    self.execute_model(model_input, kv_caches, intermediate_tensors)
    torch.cuda.synchronize()
```

### 7.3 内存分解

```
    GPU 显存总览 (以 80GB A100 + LLaMA-3-8B 为例)
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  ┌──────────────────────────┐  ← total_gpu_memory = 80 GB     │
    │  │                          │                                  │
    │  │   ┌──────────────────┐   │                                  │
    │  │   │  模型权重          │   │  ≈ 15 GB (FP16) / ≈ 4 GB (AWQ INT4)│
    │  │   │  (weights)        │   │                                  │
    │  │   ├──────────────────┤   │                                  │
    │  │   │  激活值/workspace  │   │  ≈ 1-2 GB (profile_run 测得)     │
    │  │   │  (activations)    │   │                                  │
    │  │   ├──────────────────┤   │                                  │
    │  │   │  KV Cache         │   │  ≈ (total * 0.9 - peak) 剩余全部  │
    │  │   │  (可分配 blocks)   │   │  ≈ 55-56 GB                      │
    │  │   ├──────────────────┤   │                                  │
    │  │   │  CUDA Graphs      │   │  ≈ 1-2 GB                        │
    │  │   │  (如果启用)        │   │  录制不同 batch size 的图          │
    │  │   ├──────────────────┤   │                                  │
    │  │   │  CUDA Context     │   │  ≈ 500 MB - 1 GB                │
    │  │   │  + Overhead       │   │  cuBLAS/cuDNN 内部缓冲区          │
    │  │   ├──────────────────┤   │                                  │
    │  │   │  其他              │   │  LoRA 槽位 / 临时缓冲区等         │
    │  │   ├──────────────────┤   │                                  │
    │  │   │  保留 (10%)       │   │  gpu_memory_utilization=0.9 时    │
    │  │   │                  │   │  保留 8 GB 用于突发内存需求         │
    │  │   └──────────────────┘   │                                  │
    │  └──────────────────────────┘                                  │
    │                                                                │
    │  关键公式:                                                      │
    │  KV_cache_bytes = total * gpu_memory_utilization - peak_memory  │
    │  num_blocks = KV_cache_bytes / cache_block_size                │
    │                                                                │
    │  cache_block_size = num_layers × 2 × num_kv_heads × head_size  │
    │                     × block_size × dtype_bytes                  │
    │                   = 32 × 2 × 8 × 128 × 16 × 2                  │
    │                   = 2,097,152 bytes ≈ 2 MB (per block)          │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

### 7.4 CUDA Graph 录制

warmup 的最后一步是 CUDA graph 录制（worker.py 第 285-290 行）：

```python
def _warm_up_model(self) -> None:
    if not self.model_config.enforce_eager:
        self.model_runner.capture_model(self.gpu_cache)
    set_random_seed(self.model_config.seed)
```

`capture_model` 会针对不同 batch size（1, 2, 4, 8, 16, 24, 32, ... 直到 max_batchsize_to_capture）录制 CUDA graph。之后推理时，如果 batch size 匹配某个录制的大小，就直接重放 graph，避免 kernel launch overhead。

---

## 8. 添加自定义模型：完整实战指南

### 8.1 步骤概览

```
    添加自定义模型的步骤
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  Step 1: 创建模型文件                                           │
    │    vllm/model_executor/models/my_custom_model.py               │
    │                                                                │
    │  Step 2: 实现模型类                                             │
    │    class MyCustomForCausalLM(nn.Module, SupportsLoRA):         │
    │        - __init__(): 构建模型结构                               │
    │        - forward(): 前向传播                                    │
    │        - load_weights(): 加载权重                               │
    │                                                                │
    │  Step 3: 注册模型                                               │
    │    在 registry.py 中添加到 _TEXT_GENERATION_MODELS             │
    │    或通过插件系统动态注册                                         │
    │                                                                │
    │  Step 4: 测试                                                   │
    │    vllm serve /path/to/model --trust-remote-code               │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

### 8.2 实战：创建一个自定义 CausalLM 模型

**Step 1: 创建文件 `vllm/model_executor/models/my_custom_model.py`**

```python
"""Inference-only MyCustom model compatible with HuggingFace weights."""
from typing import Iterable, List, Optional, Tuple

import torch
from torch import nn
from transformers import PretrainedConfig

from vllm.attention import Attention, AttentionMetadata
from vllm.config import CacheConfig, LoRAConfig
from vllm.model_executor.layers.activation import SiluAndMul
from vllm.model_executor.layers.layernorm import RMSNorm
from vllm.model_executor.layers.linear import (MergedColumnParallelLinear,
                                                QKVParallelLinear,
                                                RowParallelLinear)
from vllm.model_executor.layers.logits_processor import LogitsProcessor
from vllm.model_executor.layers.quantization import QuantizationConfig
from vllm.model_executor.layers.rotary_embedding import get_rope
from vllm.model_executor.layers.sampler import Sampler, SamplerOutput
from vllm.model_executor.layers.vocab_parallel_embedding import (
    DEFAULT_VOCAB_PADDING_SIZE, ParallelLMHead, VocabParallelEmbedding)
from vllm.model_executor.model_loader.weight_utils import (
    default_weight_loader)
from vllm.model_executor.sampling_metadata import SamplingMetadata

from .interfaces import SupportsLoRA
from .utils import AutoWeightsLoader, make_layers


class MyCustomMLP(nn.Module):
    """MLP 模块 (Gate-Up + Down projection)."""

    def __init__(self, hidden_size: int, intermediate_size: int,
                 quant_config: Optional[QuantizationConfig] = None,
                 prefix: str = "") -> None:
        super().__init__()
        self.gate_up_proj = MergedColumnParallelLinear(
            input_size=hidden_size,
            output_sizes=[intermediate_size] * 2,
            bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.gate_up_proj",
        )
        self.down_proj = RowParallelLinear(
            input_size=intermediate_size,
            output_size=hidden_size,
            bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.down_proj",
        )
        self.act_fn = SiluAndMul()

    def forward(self, x):
        gate_up, _ = self.gate_up_proj(x)
        x = self.act_fn(gate_up)
        x, _ = self.down_proj(x)
        return x


class MyCustomAttention(nn.Module):
    """Attention 模块."""

    def __init__(self, hidden_size: int, num_heads: int, num_kv_heads: int,
                 max_position: int = 4096 * 32, rope_theta: float = 10000.0,
                 quant_config=None, prefix: str = "") -> None:
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = hidden_size // num_heads
        self.scaling = self.head_dim ** -0.5

        self.qkv_proj = QKVParallelLinear(
            hidden_size=hidden_size, head_size=self.head_dim,
            total_num_heads=num_heads, total_num_kv_heads=num_kv_heads,
            bias=False, quant_config=quant_config,
            prefix=f"{prefix}.qkv_proj",
        )
        self.o_proj = RowParallelLinear(
            input_size=hidden_size, output_size=hidden_size,
            bias=False, quant_config=quant_config,
            prefix=f"{prefix}.o_proj",
        )
        self.rotary_emb = get_rope(
            head_size=self.head_dim, rotary_dim=self.head_dim,
            max_position=max_position, base=rope_theta,
        )
        self.attn = Attention(num_heads=num_heads, head_size=self.head_dim,
                              scale=self.scaling, num_kv_heads=num_kv_heads)

    def forward(self, positions, hidden_states, kv_cache, attn_metadata):
        qkv, _ = self.qkv_proj(hidden_states)
        q, k, v = qkv.split(
            [self.num_heads * self.head_dim,
             self.num_kv_heads * self.head_dim,
             self.num_kv_heads * self.head_dim], dim=-1)
        q, k = self.rotary_emb(positions, q, k)
        attn_output = self.attn(q, k, v, kv_cache, attn_metadata)
        output, _ = self.o_proj(attn_output)
        return output


class MyCustomDecoderLayer(nn.Module):
    """单个 Decoder Layer."""

    def __init__(self, config: PretrainedConfig,
                 quant_config=None, prefix: str = "") -> None:
        super().__init__()
        self.self_attn = MyCustomAttention(
            hidden_size=config.hidden_size,
            num_heads=config.num_attention_heads,
            num_kv_heads=config.num_key_value_heads,
            max_position=config.max_position_embeddings,
            rope_theta=config.rope_theta,
            quant_config=quant_config,
            prefix=f"{prefix}.self_attn",
        )
        self.mlp = MyCustomMLP(
            hidden_size=config.hidden_size,
            intermediate_size=config.intermediate_size,
            quant_config=quant_config,
            prefix=f"{prefix}.mlp",
        )
        self.input_layernorm = RMSNorm(config.hidden_size,
                                        eps=config.rms_norm_eps)
        self.post_attention_layernorm = RMSNorm(config.hidden_size,
                                                 eps=config.rms_norm_eps)

    def forward(self, positions, hidden_states, kv_cache, attn_metadata,
                residual=None):
        if residual is None:
            residual = hidden_states
            hidden_states = self.input_layernorm(hidden_states)
        else:
            hidden_states, residual = self.input_layernorm(hidden_states, residual)
        hidden_states = self.self_attn(
            positions=positions, hidden_states=hidden_states,
            kv_cache=kv_cache, attn_metadata=attn_metadata)
        hidden_states, residual = self.post_attention_layernorm(
            hidden_states, residual)
        hidden_states = self.mlp(hidden_states)
        return hidden_states, residual


class MyCustomModel(nn.Module):
    """完整的 Transformer 模型体."""

    def __init__(self, config: PretrainedConfig,
                 quant_config=None, prefix: str = "") -> None:
        super().__init__()
        self.config = config
        self.embed_tokens = VocabParallelEmbedding(
            config.vocab_size, config.hidden_size)
        self.start_layer, self.end_layer, self.layers = make_layers(
            num_hidden_layers=config.num_hidden_layers,
            layer_fn=lambda p: MyCustomDecoderLayer(
                config=config, quant_config=quant_config, prefix=p),
            prefix=f"{prefix}.layers",
        )
        self.norm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)

    def forward(self, input_ids, positions, kv_caches, attn_metadata):
        hidden_states = self.embed_tokens(input_ids)
        residual = None
        for i in range(self.start_layer, self.end_layer):
            layer = self.layers[i]
            hidden_states, residual = layer(
                positions, hidden_states, kv_caches[i], attn_metadata, residual)
        hidden_states, _ = self.norm(hidden_states, residual)
        return hidden_states


class MyCustomForCausalLM(nn.Module, SupportsLoRA):
    """完整的 Causal LM 模型."""

    packed_modules_mapping = {
        "qkv_proj": ["q_proj", "k_proj", "v_proj"],
        "gate_up_proj": ["gate_proj", "up_proj"]
    }
    supported_lora_modules = [
        "qkv_proj", "o_proj", "gate_up_proj", "down_proj",
        "embed_tokens", "lm_head"
    ]
    embedding_modules = {
        "embed_tokens": "input_embeddings",
        "lm_head": "output_embeddings"
    }
    embedding_padding_modules = ["lm_head"]

    def __init__(self, config: PretrainedConfig,
                 cache_config: Optional[CacheConfig] = None,
                 quant_config: Optional[QuantizationConfig] = None,
                 lora_config: Optional[LoRAConfig] = None) -> None:
        super().__init__()
        self.config = config
        self.lora_config = lora_config
        self.model = MyCustomModel(config=config, quant_config=quant_config,
                                    prefix="model")
        self.unpadded_vocab_size = config.vocab_size
        if lora_config:
            self.unpadded_vocab_size += lora_config.lora_extra_vocab_size
        self.lm_head = ParallelLMHead(
            self.unpadded_vocab_size, config.hidden_size,
            org_num_embeddings=config.vocab_size,
            padding_size=DEFAULT_VOCAB_PADDING_SIZE,
            quant_config=quant_config)
        self.logits_processor = LogitsProcessor(
            self.unpadded_vocab_size, config.vocab_size)
        self.sampler = Sampler()

    def forward(self, input_ids, positions, kv_caches, attn_metadata):
        return self.model(input_ids, positions, kv_caches, attn_metadata)

    def compute_logits(self, hidden_states, sampling_metadata):
        return self.logits_processor(self.lm_head, hidden_states, sampling_metadata)

    def sample(self, logits, sampling_metadata):
        return self.sampler(logits, sampling_metadata)

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]):
        loader = AutoWeightsLoader(self)
        loader.load_weights(weights)
```

**Step 2: 注册模型**

方式 A — 在 registry.py 中添加（适用于提 PR）：

```python
# 在 registry.py 的 _TEXT_GENERATION_MODELS 中添加：
"MyCustomForCausalLM": ("my_custom_model", "MyCustomForCausalLM"),
```

方式 B — 通过插件系统注册（适用于外部模型，不修改 vLLM 源码）：

```python
# my_plugin.py
from vllm.model_executor.models import ModelRegistry

ModelRegistry.register_model(
    "MyCustomForCausalLM",
    "vllm.model_executor.models.my_custom_model:MyCustomForCausalLM"
)
```

然后设置环境变量：

```bash
export VLLM_PLUGINS=my_plugin
vllm serve /path/to/my-custom-model --trust-remote-code
```

**Step 3: 确保 config.json 正确**

```json
{
  "architectures": ["MyCustomForCausalLM"],
  "model_type": "my_custom",
  "hidden_size": 2560,
  "intermediate_size": 10240,
  "num_attention_heads": 32,
  "num_hidden_layers": 32,
  "num_key_value_heads": 32,
  "rms_norm_eps": 1e-06,
  "rope_theta": 10000.0,
  "vocab_size": 51200,
  "max_position_embeddings": 2048
}
```

**Step 4: 测试**

```bash
vllm serve /path/to/my-custom-model --trust-remote-code --port 8000

# 测试推理
curl http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "/path/to/my-custom-model",
    "prompt": "Hello, world!",
    "max_tokens": 50
  }'
```

### 8.3 关键注意事项

1. **packed_modules_mapping**: 如果模型使用了合并的 QKV 或 Gate-Up 投影，必须在 `packed_modules_mapping` 中声明映射关系。

2. **LoRA 支持**: 需要实现 `SupportsLoRA` 接口，定义 `supported_lora_modules`、`embedding_modules`、`embedding_padding_modules`。

3. **Tensor Parallelism**: 使用 vLLM 提供的并行线性层（`ColumnParallelLinear`、`RowParallelLinear`、`QKVParallelLinear` 等），它们自动处理分片。

4. **权重加载器**: 每个量化参数都有自己的 `weight_loader` 方法。`AutoWeightsLoader` 会自动调用它们。

5. **Pipeline Parallelism**: 使用 `make_layers()` 函数构建层列表，它会自动处理 PP 的层分配。

---

## 9. 常见加载问题及解决方案

### 9.1 Out of Memory (OOM)

```
    问题诊断流程
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │ 症状:                                                           │
    │   torch.cuda.OutOfMemoryError: CUDA out of memory              │
    │                                                                │
    │ 原因诊断:                                                        │
    │   ① 模型太大 + batch size 太大 → 降低 max_num_batched_tokens      │
    │   ② gpu_memory_utilization 太高 → 降低到 0.85 或 0.80           │
    │   ③ 多模型/多进程占用同一 GPU → 检查 nvidia-smi                   │
    │   ④ LoRA 槽位太多 → 降低 max_loras                              │
    │   ⑤ CUDA graph 内存太大 → 设置 enforce_eager=True 禁用           │
    │                                                                │
    │ 解决命令:                                                        │
    │   vllm serve model \                                          │
    │     --gpu-memory-utilization 0.85 \                            │
    │     --max-model-len 4096 \                                     │
    │     --max-num-batched-tokens 4096 \                            │
    │     --enforce-eager  # 禁用 CUDA graph 可以节省显存               │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

### 9.2 架构不支持

```bash
# 错误信息：
# ValueError: Model architectures ['UnknownForCausalLM'] are not supported.
# Supported architectures: [...]
```

解决方案：
- 检查 config.json 中的 `architectures` 字段
- 如果模型与某个支持的架构兼容，可以修改 config.json 中的 `architectures`
- 或者按第 8 节的步骤添加自定义模型支持

### 9.3 量化配置不匹配

```bash
# 错误信息：
# ValueError: Quantization method specified in the model config (gptq)
# does not match the quantization method specified in the
# `quantization` argument (awq).
```

解决方案：
- 检查 `quantize_config.json` 或 `quant_config.json` 中的 `quant_method` 字段
- 确保 `--quantization` 参数与 checkpoint 的实际量化方法一致
- 对于 Marlin 优化，使用 `--quantization awq_marlin` 或 `--quantization gptq_marlin`

### 9.4 GPU 算力不支持

```bash
# 错误信息：
# The quantization method awq is not supported for the current GPU.
# Minimum capability: 75. Current capability: 70.
```

解决方案：
- AWQ 需要 SM 75+ (Turing 及以上)
- FP8 需要 SM 80+ (Ampere 及以上，推荐 Hopper SM 89+)
- Marlin kernel 需要 SM 80+
- 检查 GPU: `nvidia-smi --query-gpu=compute_cap --format=csv`

### 9.5 Attention Heads 不能整除 TP Size

```bash
# 错误信息：
# ValueError: Total number of attention heads (28) must be divisible
# by tensor parallel size (8)
```

这是 Qwen2-7B 使用 TP=8 时的典型问题（28 个 attention heads 不能被 8 整除）。TP size 必须是 `num_attention_heads` 和 `num_key_value_heads` 的公因数。

### 9.6 权重文件缺失

```bash
# 错误信息：
# RuntimeError: Cannot find any model weights with
# `meta-llama/Meta-Llama-3-8B`
```

常见原因：
- HuggingFace token 未认证（gated model）：`huggingface-cli login`
- 网络问题：设置 `HF_ENDPOINT=https://hf-mirror.com` 使用镜像
- 磁盘空间不足：检查 `HF_HOME` 或 `--download-dir` 的磁盘空间

### 9.7 Tie Word Embeddings 导致的形状问题

```bash
# 错误信息：
# RuntimeError: The expanded size of the tensor (128256) must match
# the existing size (128512) at non-singleton dimension 0.
```

当模型使用 `tie_word_embeddings=True` 时，vLLM 会复用 `embed_tokens` 的权重，不单独加载 `lm_head.weight`。`AutoWeightsLoader` 使用 `skip_prefixes=["lm_head."]` 参数跳过 lm_head 权重。

---

## 11. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| ModelRegistry | "模型家族的户口本"：通过 config.json 中的 architectures 字段查表找到对应的模型实现类 | 第四章术语表 |
| Safetensors | "权重文件的保险箱"：安全的张量序列化格式，支持 mmap 零拷贝加载，比 .bin 快 | 第四章术语表 |
| AutoWeightsLoader | "智能快递分拣员"：按命名前缀递归匹配，自动将权重分发到对应子模块和参数 | 第四章术语表 |
| QuantizationConfig | "量化方案的说明书"：AWQ/GPTQ/FP8 等量化方法各自定义如何压缩和反量化权重 | 第四章术语表 |
| Tensor Parallel Sharding | "切蛋糕分工"：ColumnParallel（按列切）和 RowParallel（按行切+AllReduce），每个 GPU 只加载自己的切片 | 第四章术语表 |

---

## 12. A800 部署场景举例

### 12.1 AWQ 量化加载（Qwen-33B on 2×A800）

```bash
# 2×A800 + AWQ，每卡约 8.5 GB 权重
vllm serve /data/models/Qwen2.5-32B-Instruct-AWQ \
    --tensor-parallel-size 2 \
    --quantization awq \
    --dtype auto \
    --max-model-len 32768 \
    --gpu-memory-utilization 0.92
```

**启动日志中验证加载**：
```
INFO: Loading model weights took 8.52 GB GPU memory (per GPU)
INFO: Available KV cache memory: 62.31 GiB
```
- 权重 8.5 GB × 2 ≈ 17 GB（远小于 BF16 的 65 GB）
- 每卡剩余约 62 GB 用于 KV Cache，单卡可支持约 31000 个 block × 16 tokens

### 12.2 LoRA 适配器动态加载场景

```bash
# 启动时注册多个 LoRA 适配器，运行时按请求切换
vllm serve /data/models/Qwen2.5-32B-Instruct-AWQ \
    --tensor-parallel-size 2 \
    --quantization awq \
    --enable-lora \
    --max-lora-rank 16 \
    --max-loras 4 \
    --max-cpu-loras 16 \
    --lora-modules math-adapter=/data/lora/math \
                  code-adapter=/data/lora/code
```

**调用时通过 model 字段选择适配器**：
```bash
curl http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{"model": "math-adapter", "prompt": "求解: x^2 + 3x + 2 = 0", "max_tokens": 100}'
```

---

## 13. 上下游串联

```
模型加载在 vLLM 推理链中的位置

┌──────────────────────────────────────────────────────────────────┐
│                    推理服务的生命周期                                │
│                                                                   │
│  ┌─────────────────────┐                                          │
│  │ 01-启动入口          │  CLI → VllmConfig → AsyncLLM             │
│  └────────┬────────────┘                                          │
│           │                                                       │
│           ▼                                                       │
│  ┌─────────────────────┐                                          │
│  │ ★ 04-模型加载       │  注册表查架构 → 构建空模型 → 加载权重      │
│  │                     │  → 应用量化 → LoRA 适配 → profile_run     │
│  └────────┬────────────┘                                          │
│           │                                                       │
│           ▼                                                       │
│  ┌─────────────────────┐     ┌─────────────────────┐              │
│  │ 02-调度器            │ ←→  │ 03-BlockManager     │              │
│  │ 分配计算资源         │     │ 管理 KV Cache 块    │              │
│  └────────┬────────────┘     └─────────────────────┘              │
│           │                                                       │
│           ▼                                                       │
│  ┌─────────────────────┐                                          │
│  │ 05-Worker/ModelRunner│  执行模型前向传播和采样                    │
│  └─────────────────────┘                                          │
│                                                                   │
│  本文档覆盖：模型从磁盘到 GPU 显存的完整加载链路                       │
│  前置阅读：01-启动入口（了解 Config 体系如何触发模型加载）             │
│  后续阅读：05-Worker执行（了解加载后的模型如何被调用执行）             │
└──────────────────────────────────────────────────────────────────┘
```

---

## 10. 深入学习资源

### 10.1 关键源文件阅读顺序

```
    从零到精通 vLLM 模型加载的阅读路径
    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  Level 1: 理解整体流程                                           │
    │    ① config.py  → ModelConfig 类（理解配置是如何解析的）           │
    │    ② model_loader/__init__.py → get_model() 函数                │
    │    ③ model_loader/loader.py → DefaultModelLoader.load_model()   │
    │                                                                │
    │  Level 2: 理解注册与检测                                         │
    │    ④ models/registry.py → ModelRegistry（架构名到模型类的映射）    │
    │    ⑤ models/interfaces.py → 模型能力接口                         │
    │                                                                │
    │  Level 3: 理解权重加载                                           │
    │    ⑥ model_loader/weight_utils.py → 权重迭代器与 loader 函数      │
    │    ⑦ models/llama.py → LlamaModel.load_weights()               │
    │    ⑧ models/utils.py → AutoWeightsLoader                       │
    │                                                                │
    │  Level 4: 理解量化                                               │
    │    ⑨ layers/quantization/base_config.py → QuantizationConfig    │
    │    ⑩ layers/quantization/awq.py → AWQ 完整实现                  │
    │    ⑪ layers/quantization/gptq.py → GPTQ 完整实现                │
    │    ⑫ layers/quantization/fp8.py → FP8 完整实现                  │
    │                                                                │
    │  Level 5: 理解 LoRA                                             │
    │    ⑬ lora/lora.py → LoRALayerWeights                           │
    │    ⑭ lora/layers.py → BaseLayerWithLoRA                        │
    │    ⑮ lora/models.py → LoRAModelManager（LRU 缓存管理）           │
    │                                                                │
    │  Level 6: 理解内存与性能                                         │
    │    ⑯ worker/worker.py → determine_num_available_blocks()       │
    │    ⑰ worker/model_runner.py → profile_run() / capture_model()   │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘
```

### 10.2 调试技巧

```bash
# 启用详细日志查看加载过程
export VLLM_LOGGING_LEVEL=DEBUG
vllm serve /path/to/model

# 查看模型注册表支持的所有架构
python -c "
from vllm.model_executor.models import ModelRegistry
for arch in sorted(ModelRegistry.get_supported_archs()):
    print(arch)
"

# 查看量化配置
python -c "
from vllm.model_executor.layers.quantization import QUANTIZATION_METHODS
for name, cls in QUANTIZATION_METHODS.items():
    print(f'{name}: min_capability={cls.get_min_capability()}')
"

# 测试特定模型的注册表匹配
python -c "
from vllm.model_executor.models import ModelRegistry
archs = ['LlamaForCausalLM']
cls, arch = ModelRegistry.resolve_model_cls(archs)
print(f'Matched: {arch} → {cls.__module__}.{cls.__name__}')
"

# 使用 tensorizer 加速加载（适用于频繁重启的场景）
python examples/tensorize_vllm_model.py \
    --model meta-llama/Meta-Llama-3-8B \
    --output /path/to/tensorized/model \
    --dtype float16

vllm serve /path/to/tensorized/model \
    --load-format tensorizer
```

### 10.3 关键调试代码

以下是一段独立脚本，用于测试自定义模型的注册表匹配和基本加载流程：

```python
"""测试自定义模型注册 — 独立调试脚本"""
import torch
from vllm.config import ModelConfig, CacheConfig, LoadConfig
from vllm.model_executor.models import ModelRegistry
from vllm.model_executor.model_loader import get_model

# 1. 列出所有支持的架构
print("=== 支持的模型架构 ===")
for arch in sorted(ModelRegistry.get_supported_archs()):
    print(f"  {arch}")

# 2. 模拟注册表查询
architectures = ["LlamaForCausalLM"]
model_cls, arch = ModelRegistry.resolve_model_cls(architectures)
print(f"\n=== 注册表匹配结果 ===")
print(f"  input: {architectures}")
print(f"  matched arch: {arch}")
print(f"  model class: {model_cls.__module__}.{model_cls.__name__}")

# 3. 检查模型能力
info = ModelRegistry.inspect_model_cls(architectures)
print(f"\n=== 模型能力 ===")
print(f"  is_text_generation: {info.is_text_generation_model}")
print(f"  is_embedding: {info.is_embedding_model}")
print(f"  supports_multimodal: {info.supports_multimodal}")
print(f"  supports_pp: {info.supports_pp}")
print(f"  has_inner_state: {info.has_inner_state}")
print(f"  is_attention_free: {info.is_attention_free}")

# 4. 检查量化方法
from vllm.model_executor.layers.quantization import QUANTIZATION_METHODS
print(f"\n=== 支持的量化方法 ===")
for name, cls in sorted(QUANTIZATION_METHODS.items()):
    try:
        min_cap = cls.get_min_capability()
    except:
        min_cap = "N/A"
    print(f"  {name:25s}  min_sm={min_cap}")
```

### 10.4 相关论文与参考资料

| 资源 | 说明 |
|---|---|
| [vLLM 官方文档](https://docs.vllm.ai/) | 完整的用户和开发者文档 |
| [vLLM GitHub](https://github.com/vllm-project/vllm) | 源码仓库 |
| [AWQ 论文](https://arxiv.org/abs/2306.00978) | Activation-aware Weight Quantization |
| [GPTQ 论文](https://arxiv.org/abs/2210.17323) | Accurate Post-Training Quantization |
| [Safetensors 文档](https://huggingface.co/docs/safetensors/) | 安全的张量序列化格式 |
| [LoRA 论文](https://arxiv.org/abs/2106.09685) | Low-Rank Adaptation of LLMs |
| [Punica 论文](https://arxiv.org/abs/2310.18547) | Multi-Tenant LoRA Serving |
| [Marlin Kernel](https://github.com/IST-DASLab/marlin) | 快速 INT4 矩阵乘法 kernel |
| [Tensorizer](https://github.com/coreweave/tensorizer) | CoreWeave 的模型序列化工具 |
| [GGUF 格式规范](https://github.com/ggerganov/ggml/blob/master/docs/gguf.md) | GGUF 张量命名标准 |

---

> 本文档基于 vLLM 源码（`/data/chendongpo/agent_projects/vllm_src/vllm/`）编写，涵盖了模型加载的完整流程。建议配合源码阅读，在每个关键函数处设置断点，使用 `vllm serve` 或 `LLM()` API 实际运行来加深理解。
