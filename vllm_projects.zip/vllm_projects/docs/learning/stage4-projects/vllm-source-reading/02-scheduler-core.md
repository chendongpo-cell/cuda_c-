# 02 - vLLM 调度器核心深度剖析

> "调度器是 vLLM 的大脑——它决定了谁先进、谁先出、谁被挤出、谁被换出。"

---

## 目录

1. [架构全景：调度器在 vLLM 中的位置](#1-架构全景)
2. [Scheduler.__init__()：初始化三大队列和块管理器](#2-初始化)
3. [关键数据结构：Sequence、SequenceGroup、SequenceStatus](#3-关键数据结构)
4. [SchedulingBudget：令牌预算的精算师](#4-schedulingbudget)
5. [schedule() 方法全流程详解](#5-schedule-方法全流程详解)
6. [_schedule_default() vs _schedule_chunked_prefill()](#6-两种调度策略)
7. [Chunked Prefill：分块预填充深度剖析](#7-chunked-prefill)
8. [Preemption 抢占逻辑：Swap vs Recompute](#8-preemption-抢占)
9. [请求状态机：WAITING → RUNNING → SWAPPED → FINISHED](#9-请求状态机)
10. [调度器与 BlockManager 的交互](#10-调度器与-blockmanager)
11. [调度器输出：SchedulerOutputs 的完整结构](#11-调度器输出)
12. [真实调度时间线追踪](#12-调度时间线)
13. [Prefix Caching 与调度器的协作](#13-prefix-caching)
14. [LoRA 感知调度](#14-lora-感知调度)
15. [Priority 优先级调度](#15-priority-优先级调度)
16. [监控与调试](#16-监控与调试)
17. [调度器配置参数全解](#17-配置参数全解)
18. [深入学习资源](#18-深入学习资源)

---

## 1. 架构全景

### 1.1 调度器在 vLLM 引擎中的位置

vLLM 的 `LLMEngine` 是一个经典的事件循环。每一步迭代都从调度器开始——调度器决定本轮要处理哪些请求，然后模型执行器根据调度结果运行模型。

```
                     LLMEngine 主循环 (step())
                              |
                              v
              +-------------------------------+
              |         Scheduler             |
              |   vllm/core/scheduler.py      |
              |                               |
              |  +-------------------------+  |
              |  | self.waiting (Deque)    |  |  <-- 新到的请求
              |  | self.running (Deque)    |  |  <-- 正在生成的请求
              |  | self.swapped (Deque)    |  |  <-- 被换出到CPU的请求
              |  +-------------------------+  |
              |                               |
              |  schedule() -> SchedulerOutputs
              +-------------------------------+
                              |
                              v
                   SchedulerOutputs (调度决策)
                              |
                              v
              +-------------------------------+
              |       ModelRunner             |
              |   (执行模型前向传播)            |
              +-------------------------------+
                              |
                              v
              +-------------------------------+
              |       Scheduler               |
              |   free_finished_seq_groups()  |
              |   (释放完成的请求, 更新队列)    |
              +-------------------------------+
                              |
                              v
                 返回生成结果, 进入下一次迭代
```

### 1.2 调度器的核心职责

```
  调度器 = 资源分配器 + 队列管理器 + 抢占决策者

  每一轮调度回答三个问题:

  1. 哪些 waiting 请求可以开始 prefill?  （预算检查 + 块分配）
  2. 哪些 running 请求可以继续 decode?   （逐token追加slot）
  3. 如果资源不够, 谁应该被抢占?         （swap 或 recompute）
```

### 1.3 文件结构速览

```
vllm/core/scheduler.py (~1841 lines)
├── class PreemptionMode(Enum)      # SWAP / RECOMPUTE
├── class SchedulingBudget          # 令牌和序列预算管理
├── class ScheduledSequenceGroup    # 被调度的序列组 + token_chunk_size
├── class SchedulerOutputs          # 最终调度输出
├── class SchedulerRunningOutputs   # running队列的调度结果
├── class SchedulerSwappedInOutputs # swapped队列的调度结果
├── class SchedulerPrefillOutputs   # waiting队列的调度结果
└── class Scheduler                 # 主调度器类
    ├── __init__()                  # 初始化队列和块管理器
    ├── add_seq_group()             # 添加请求到waiting队列
    ├── abort_seq_group()           # 中止请求
    ├── schedule()                  # 对外主入口
    │   ├── _schedule()             # 内部调度入口（选择策略）
    │   │   ├── _schedule_default()        # 默认策略（prefill优先）
    │   │   └── _schedule_chunked_prefill()# 分块预填充策略（decode优先）
    │   ├── _schedule_prefills()    # 调度waiting队列
    │   ├── _schedule_running()     # 调度running队列
    │   ├── _schedule_swapped()     # 调度swapped队列
    │   └── _schedule_priority_preemption() # 优先级抢占
    ├── _preempt() / _preempt_by_recompute() / _preempt_by_swap()
    ├── _can_append_slots() / _append_slots()
    ├── _allocate_and_set_running()
    ├── _passed_delay()             # 延迟调度逻辑
    ├── free_finished_seq_groups()  # 释放已完成请求
    └── _chunk_new_tokens_to_schedule()  # 分块计算
```

---

## 2. 初始化

### 2.1 Scheduler.__init__() 源码剖析

```python
# vllm/core/scheduler.py:324-423 (核心部分)

class Scheduler:

    def __init__(
        self,
        scheduler_config: SchedulerConfig,
        cache_config: CacheConfig,
        lora_config: Optional[LoRAConfig],
        pipeline_parallel_size: int = 1,
        output_proc_callback: Optional[Callable] = None,
    ) -> None:
        self.scheduler_config = scheduler_config
        self.cache_config = cache_config
        self.lora_config = lora_config

        # ---- 1. 选择 BlockSpaceManager 实现版本 ----
        version = "selfattn"
        if (self.scheduler_config.runner_type == "pooling"
                or self.cache_config.is_attention_free):
            version = "placeholder"

        BlockSpaceManagerImpl = BlockSpaceManager.get_block_space_manager_class(
            version)

        # ---- 2. 计算 GPU/CPU block 数量（流水线并行要均分）----
        num_gpu_blocks = cache_config.num_gpu_blocks
        if num_gpu_blocks:
            num_gpu_blocks //= pipeline_parallel_size

        num_cpu_blocks = cache_config.num_cpu_blocks
        if num_cpu_blocks:
            num_cpu_blocks //= pipeline_parallel_size

        # ---- 3. 创建块空间管理器 ----
        self.block_manager = BlockSpaceManagerImpl(
            block_size=self.cache_config.block_size,
            num_gpu_blocks=num_gpu_blocks,
            num_cpu_blocks=num_cpu_blocks,
            sliding_window=self.cache_config.sliding_window,
            enable_caching=self.cache_config.enable_prefix_caching)

        # ---- 4. 三大核心队列 ----
        self.waiting: Deque[SequenceGroup] = deque()   # WAITING状态
        self.running: Deque[SequenceGroup] = deque()   # RUNNING状态
        self.swapped: Deque[SequenceGroup] = deque()   # SWAPPED状态
```

### 2.2 三大队列详解

```
  vLLM 调度器的请求只存在于三个队列之一（加上已完成/中止的）

  +------------------+     +------------------+     +------------------+
  |    WAITING       |     |    RUNNING       |     |    SWAPPED       |
  |    (waiting)     |     |    (running)     |     |    (swapped)     |
  |    deque()       |     |    deque()       |     |    deque()       |
  +------------------+     +------------------+     +------------------+
         |                        |                        |
         |  新请求到达时           |  正在计算中            |  被换出到CPU内存
         |  被抢占(RECOMPUTE)      |  可能包含:             |  等待swap-in
         |  的请求也回到这里       |  - 正在decode的请求    |
         |                        |  - chunked prefill中   |
         |                        |    尚未完成的请求      |
         v                        v                        v
    等待被调度               每个iteration               等待GPU内存
    进行prefill              追加1个token                恢复后继续
```

### 2.3 队列操作全景

```
  请求生命周期与队列转移:

  add_seq_group(seq_group)
      |
      v
  +----------+   _schedule_prefills()    +----------+
  | WAITING  | ------------------------> | RUNNING  |
  +----------+   _allocate_and_set_      +----------+
      ^            running()                  |
      |                                       | prefill完成, 进入decode
      |  _preempt_by_recompute()              |
      |  (释放KV block, 重置状态)              | 每次iteration:
      |                                       |   _append_slots(): 追加1个slot
      |                                       |   token_budget -= 1
      |                                       |
      |                               +-------+-------+
      |                               |               |
      |                        正常生成结束      资源不足时
      |                               |        _preempt_by_swap()
      |                               |               |
      |                               v               v
      |                        free_finished_    +----------+
      |                        seq_groups()      | SWAPPED  |
      |                        释放block,        +----------+
      |                        从running移除          |
      |                                               | GPU有空闲时
      |                                               | _schedule_swapped()
      |                                               | _swap_in()
      |                                               |
      +-----------------------------------------------+
            恢复到running, 继续decode
```

### 2.4 SchedulerConfig 关键参数

```python
# vllm/config.py:1441-1500

@dataclass
class SchedulerConfig:
    # 单次迭代最多处理的token总数 (prefill tokens + decode tokens)
    max_num_batched_tokens: int = None  # 默认: max(max_model_len, 2048)

    # 单次迭代最多处理的序列数
    max_num_seqs: int = 128

    # 序列最大长度 (prompt + generated)
    max_model_len: int = 8192

    # speculative decoding 前瞻槽位数
    num_lookahead_slots: int = 0

    # prefill 延迟因子 (让 waiting 队列积攒更多请求再批量调度)
    delay_factor: float = 0.0

    # 是否启用 chunked prefill
    enable_chunked_prefill: bool = False

    # 抢占模式: "swap" | None (None表示自动选择)
    preemption_mode: Optional[str] = None

    # 多步调度步数 (用于 multi-step scheduling)
    num_scheduler_steps: int = 1

    # 调度策略: "fcfs" (先到先服务) | "priority" (优先级)
    policy: str = "fcfs"
```

#### max_num_batched_tokens 的默认值计算

```python
# vllm/config.py:1522-1551

def __post_init__(self) -> None:
    if self.max_num_batched_tokens is None:
        if self.enable_chunked_prefill:
            if self.num_scheduler_steps > 1:
                # Multi-step Chunked-Prefill 下不分块
                self.max_num_batched_tokens = max(self.max_model_len, 2048)
            else:
                # 默认 2048, 平衡 ITL (inter-token latency) 和 TTFT
                self.max_num_batched_tokens = 2048
        else:
            # 非分块模式: 至少等于 max_model_len
            self.max_num_batched_tokens = max(self.max_model_len, 2048)
```

#### 配置验证

```python
# vllm/config.py:1564-1570

def _verify_args(self) -> None:
    if (self.max_num_batched_tokens < self.max_model_len
            and not self.chunked_prefill_enabled):
        raise ValueError(
            f"max_num_batched_tokens ({self.max_num_batched_tokens}) is "
            f"smaller than max_model_len ({self.max_model_len}). "
            "This effectively limits the maximum sequence length to "
            "max_num_batched_tokens. Enable chunked prefill to fix.")
```

关键约束：如果不启用 chunked prefill，`max_num_batched_tokens` 必须 >= `max_model_len`，否则长 prompt 根本无法被调度。

---

## 3. 关键数据结构

### 3.1 SequenceStatus — 序列状态枚举

```python
# vllm/sequence.py:58-89

class SequenceStatus(enum.IntEnum):
    """Status of a sequence."""
    WAITING = 0              # 等待被调度
    RUNNING = 1               # 正在运行
    SWAPPED = 2               # 被换出到CPU
    # --- 以下都是终止状态 (status > SWAPPED) ---
    FINISHED_STOPPED = 3      # 正常停止 (遇到EOS)
    FINISHED_LENGTH_CAPPED = 4 # 达到最大长度
    FINISHED_ABORTED = 5      # 被中止
    FINISHED_IGNORED = 6      # 被忽略 (prompt太长等原因)

    @staticmethod
    def is_finished(status: "SequenceStatus") -> bool:
        return status > SequenceStatus.SWAPPED
```

```
  序列状态转换图 (状态机):

                  +-----------+
                  |  WAITING  |  <-- 新请求到达 / RECOMPUTE preemption
                  +-----------+
                        |
          _allocate_and_set_running()
                        |
                        v
                  +-----------+      _swap_out()       +----------+
                  |  RUNNING  | ----------------------> | SWAPPED  |
                  +-----------+     <------------------ +----------+
                        |              _swap_in()
                        |
          +-------+----+----------+
          |       |               |
          v       v               v
     FINISHED  FINISHED_     FINISHED_
     _STOPPED  LENGTH_CAPPED ABORTED/IGNORED
     (EOS)     (max_len)     (abort/too long)
```

### 3.2 Sequence — 单个序列

```python
# vllm/sequence.py:387-435 (核心字段)

class Sequence:
    """单个序列的数据、状态和块信息."""

    def __init__(self, seq_id, inputs, block_size,
                 eos_token_id=None, lora_request=None,
                 prompt_adapter_request=None):
        self.seq_id = seq_id              # 序列唯一ID
        self.inputs = inputs              # prompt tokens 等输入
        self.block_size = block_size      # KV cache block 大小
        self.data = SequenceData.from_seqs(self.prompt_token_ids) # token数据
        self.status = SequenceStatus.WAITING  # 初始状态
        self.stop_reason = None

    # -- 关键属性 --
    @property
    def n_blocks(self) -> int:
        """该序列需要的 block 数量"""
        return (self.get_len() + self.block_size - 1) // self.block_size

    def get_len(self) -> int:
        """总 token 数 = prompt + generated"""
        return self.data.get_len()

    def get_prompt_len(self) -> int:
        return self.data.get_prompt_len()

    def get_output_len(self) -> int:
        return self.data.get_output_len()

    def is_finished(self) -> bool:
        return SequenceStatus.is_finished(self.status)

    def reset_state_for_recompute(self):
        """被 recompute 抢占时重置状态"""
        self.data.reset_state_for_recompute()
```

### 3.3 SequenceGroup — 序列组

```python
# vllm/sequence.py:625-680 (核心字段)

class SequenceGroup:
    """一组来自同一 prompt 的序列 (例如 beam search 有多个序列)."""

    def __init__(self, request_id, seqs, arrival_time,
                 sampling_params=None, lora_request=None,
                 pooling_params=None, priority=0):
        self.request_id = request_id       # 请求唯一ID
        self.seqs = seqs                   # List[Sequence]
        self.first_seq = seqs[0]           # 第一个序列(大多数场景只有1个)
        self.arrival_time = arrival_time   # 到达时间(FCFS排序依据)
        self.sampling_params = sampling_params
        self.lora_request = lora_request
        self.priority = priority           # 用户指定优先级

        # 性能指标
        self.metrics = RequestMetrics(
            arrival_time=arrival_time,
            last_token_time=arrival_time,
            first_scheduled_time=None,
            first_token_time=None,
            time_in_queue=None)

    # -- 关键方法 --
    def get_max_num_running_seqs(self) -> int:
        """正在运行的序列数(剩余未完成的数量)"""
        if self.is_single_seq:
            return 0 if self.first_seq.is_finished() else 1
        return self.num_seqs() - self.num_finished_seqs()

    def is_prefill(self) -> bool:
        """是否处于 prefill 阶段"""
        # prefill (WAITING状态) 或 chunked prefill 的中间状态
        ...
```

**Sequence vs SequenceGroup 的关系：**

```
  SequenceGroup (一个请求)
  ├── request_id: "abc-123"
  ├── arrival_time: 1700000000.0
  ├── sampling_params: {temperature: 0.7, max_tokens: 512}
  ├── metrics: RequestMetrics(...)
  └── seqs: List[Sequence]
       └── Sequence (seq_id=0)        <-- 大多数情况只有1个
            ├── status: RUNNING
            ├── data: SequenceData
            │    ├── prompt_token_ids: [1,2,3,...,1000]
            │    └── output_token_ids: [1001,1002,...]
            └── block_size: 16

  特殊情况: beam search (n > 1)
  SequenceGroup (一个请求, beam_size=4)
  └── seqs: List[Sequence]
       ├── Sequence (seq_id=0, beam 1)
       ├── Sequence (seq_id=1, beam 2)
       ├── Sequence (seq_id=2, beam 3)
       └── Sequence (seq_id=3, beam 4)
```

---

## 4. SchedulingBudget

### 4.1 预算管理的设计

`SchedulingBudget` 是调度过程中的核心计数器，在整个 `schedule()` 调用中保持和更新。

```python
# vllm/core/scheduler.py:46-120 (完整代码)

@dataclass
class SchedulingBudget:
    token_budget: int          # 总token预算 (max_num_batched_tokens)
    max_num_seqs: int          # 最大序列数

    _request_ids_num_batched_tokens: Set[str]  # 已计入token的请求ID
    _request_ids_num_curr_seqs: Set[str]       # 已计入seq数的请求ID
    _num_cached_tokens: int = 0                # 缓存的token数(prefix hit)
    _num_batched_tokens: int = 0               # 实际需要计算的token数
    _num_curr_seqs: int = 0                    # 当前序列数

    def can_schedule(self, *, num_new_tokens: int, num_new_seqs: int):
        assert num_new_tokens >= 0
        assert num_new_seqs != 0
        return (self.num_batched_tokens + num_new_tokens <= self.token_budget
                and self.num_curr_seqs + num_new_seqs <= self.max_num_seqs)

    def remaining_token_budget(self):
        return self.token_budget - self.num_batched_tokens

    def add_num_batched_tokens(self, req_id, num_batched_tokens,
                                num_cached_tokens=0):
        if req_id in self._request_ids_num_batched_tokens:
            return  # 防重复: 同一请求不重复计入
        self._request_ids_num_batched_tokens.add(req_id)
        self._num_batched_tokens += num_batched_tokens
        self._num_cached_tokens += num_cached_tokens
```

### 4.2 预算使用的关键设计

```
  为什么需要 _request_ids 去重?

  场景: chunked prefill 模式下, running 队列中的请求
  可能在 _schedule_running() 之前已经计入了 num_seqs,
  而 _schedule_running() 中可能再次被计入。

  去重机制: 每个请求的 req_id 只计入一次,
  subtract 时也只减去一次。

  预算消耗示意:

  初始 budget:
    token_budget = 2048
    max_num_seqs = 128

  prefill 请求A (1000 tokens):
    + add_num_batched_tokens("A", 1000)
    + add_num_seqs("A", 1)
    => _num_batched_tokens = 1000
    => _num_curr_seqs = 1

  decode 请求B (1 token):
    + add_num_batched_tokens("B", 1)
    + add_num_seqs("B", 1)
    => _num_batched_tokens = 1001
    => _num_curr_seqs = 2

  剩余:
    remaining_token_budget = 2048 - 1001 = 1047
    remaining_seqs = 128 - 2 = 126
```

---

## 5. schedule() 方法全流程详解

### 5.1 主入口 schedule()

```python
# vllm/core/scheduler.py:1289-1444

def schedule(
        self
) -> Tuple[List[SequenceGroupMetadata], SchedulerOutputs, bool]:
    """
    每轮迭代的核心调度入口。

    Returns:
        seq_group_metadata_list: 发送给 worker 的元数据列表
        scheduler_outputs: 调度输出 (含 block 交换信息)
        allow_async_output_proc: 是否允许异步输出处理
    """
    scheduler_start_time = time.perf_counter()

    # ============ 第1步: 执行调度决策 ============
    scheduler_outputs: SchedulerOutputs = self._schedule()
    now = time.time()

    # ============ 第2步: 构建发送给 worker 的元数据 ============
    seq_group_metadata_list: List[SequenceGroupMetadata] = []
    for i, scheduled_seq_group in enumerate(
            scheduler_outputs.scheduled_seq_groups):
        seq_group = scheduled_seq_group.seq_group
        token_chunk_size = scheduled_seq_group.token_chunk_size

        # 记录首次调度时间 (用于计算 TTFT)
        seq_group.maybe_set_first_scheduled_time(now)

        # 收集每个序列的 seq_data 和 block_tables
        seq_data: Dict[int, SequenceData] = {}
        block_tables: Dict[int, List[int]] = {}

        for seq in seq_group.get_seqs(status=SequenceStatus.RUNNING):
            seq_id = seq.seq_id
            seq_data[seq_id] = seq.data
            block_tables[seq_id] = self.block_manager.get_block_table(seq)
            self.block_manager.access_all_blocks_in_seq(seq, now)

        # ... 构建 SequenceGroupMetadata ...

    # ============ 第3步: 标记 blocks 为已计算 ============
    for scheduled_seq_group in scheduler_outputs.scheduled_seq_groups:
        self.block_manager.mark_blocks_as_computed(
            scheduled_seq_group.seq_group,
            scheduled_seq_group.token_chunk_size)

    # ============ 第4步: 累计调度耗时到各 running 请求 ============
    scheduler_time = time.perf_counter() - scheduler_start_time
    for seq_group in self.running:
        if seq_group.metrics is not None:
            if seq_group.metrics.scheduler_time is not None:
                seq_group.metrics.scheduler_time += scheduler_time
            else:
                seq_group.metrics.scheduler_time = scheduler_time

    return (seq_group_metadata_list, scheduler_outputs,
            allow_async_output_proc)
```

### 5.2 内部调度入口 _schedule()

```python
# vllm/core/scheduler.py:1251-1256

def _schedule(self) -> SchedulerOutputs:
    """Schedule queued requests."""
    if self.scheduler_config.chunked_prefill_enabled:
        return self._schedule_chunked_prefill()
    else:
        return self._schedule_default()
```

---

## 6. 两种调度策略

### 6.1 _schedule_default() — 默认策略（prefill 优先）

```python
# vllm/core/scheduler.py:1051-1154

def _schedule_default(self) -> SchedulerOutputs:
    """
    默认策略: prefill 优先 + decode 其次 + swapped 最后

    流程:
    1. 优先调度 WAITING 中的新请求 (prefill)
    2. 如果没有 prefill, 调度 RUNNING 中的 decode
    3. 如果没有 preempt, 尝试 swap-in
    """
    # ---- 初始化 ----
    budget = SchedulingBudget(
        token_budget=self.scheduler_config.max_num_batched_tokens,
        max_num_seqs=self.scheduler_config.max_num_seqs,
    )

    # 将 running 请求的 seq 数预先计入预算
    for seq_group in self.running:
        budget.add_num_seqs(seq_group.request_id,
                           seq_group.get_max_num_running_seqs())
    curr_loras = set(
        seq_group.lora_int_id for seq_group in self.running
        if seq_group.lora_int_id > 0) if self.lora_enabled else None

    # ---- Phase 1: 调度 WAITING 请求 (prefill) ----
    if not self.swapped:  # swapped 非空时跳过 prefill, 优先 swap-in
        prefills = self._schedule_prefills(budget, curr_loras,
                                           enable_chunking=False)

    # ---- Phase 1.5: Priority preemption (仅 priority 策略) ----
    if len(prefills.seq_groups) == 0 and self.scheduler_config.policy == "priority":
        self._schedule_priority_preemption(budget)

    # ---- Phase 2: 调度 RUNNING 请求 (decode) ----
    if len(prefills.seq_groups) == 0:  # 只有无 prefill 时才调度 decode
        running_scheduled = self._schedule_running(budget, curr_loras,
                                                    enable_chunking=False)

        # ---- Phase 3: 调度 SWAPPED 请求 (swap-in) ----
        if len(running_scheduled.preempted) + len(
                running_scheduled.swapped_out) == 0:
            swapped_in = self._schedule_swapped(budget, curr_loras)

    # ---- 更新队列状态 ----
    self.waiting.extendleft(running_scheduled.preempted)  # 被抢占的回到 waiting
    if len(prefills.seq_groups) > 0:
        self.running.extend([s.seq_group for s in prefills.seq_groups])
    self.running.extend(running_scheduled.decode_seq_groups_list)
    if len(swapped_in.decode_seq_groups) > 0:
        self.running.extend([s.seq_group for s in swapped_in.decode_seq_groups])
    self.swapped.extend(running_scheduled.swapped_out)

    # ---- 合并输出 ----
    return SchedulerOutputs(
        scheduled_seq_groups=scheduled_seq_groups,
        num_prefill_groups=len(prefills.seq_groups),
        num_batched_tokens=budget.num_batched_tokens + budget.num_cached_tokens,
        blocks_to_swap_in=swapped_in.blocks_to_swap_in,
        blocks_to_swap_out=running_scheduled.blocks_to_swap_out,
        blocks_to_copy=...,
        ignored_seq_groups=...,
        num_lookahead_slots=running_scheduled.num_lookahead_slots,
        running_queue_size=len(self.running),
        preempted=preempted,
    )
```

```
  _schedule_default() 决策流程图:

  ┌──────────────────────────────────────┐
  │  初始化 budget (token + seq 预算)      │
  │  预扣除 running 请求的 seq 配额        │
  └──────────────────┬───────────────────┘
                     │
                     v
            ┌────────────────┐
            │ self.swapped   │
            │ is empty?      │
            └───┬────────┬───┘
                │YES     │NO (swapped优先, 跳过prefill)
                v        v
   ┌────────────────────┐  ┌──────────────────┐
   │ _schedule_prefills │  │ 直接进入Phase 2  │
   │ (enable_chunking   │  │ (不调度新prefill) │
   │  =False)           │  └──────────────────┘
   └─────────┬──────────┘
             │
             v
    ┌──────────────────────┐
    │ prefills.seq_groups  │
    │ is empty?            │
    ├──────┬───────────────┤
    │ YES  │ NO            │
    │      │               │
    │      v               v
    │  _schedule_running   │  有prefill → 跳过decode
    │      │               │  (非chunked模式prefill独占batch)
    │      │               │
    │      v               │
    │  (如有preempt?)      │
    │  _schedule_swapped   │
    │      │               │
    └──────┴───────────────┘
           │
           v
    合并结果, 更新队列
    ↓
    SchedulerOutputs
```

### 6.2 _schedule_chunked_prefill() — 分块预填充策略（decode 优先）

```python
# vllm/core/scheduler.py:1156-1249

def _schedule_chunked_prefill(self) -> SchedulerOutputs:
    """
    Chunked prefill 策略:

    与默认策略的核心区别:
    - 默认策略: prefill 优先, prefill和decode不能共存于同一batch
    - Chunked策略: decode 优先, prefill可被分块, prefill和decode可共存

    流程:
    1. 先调度 RUNNING 中的 decode 和未完成的 chunked prefill
    2. 调度 SWAPPED 请求
    3. 最后调度 WAITING 中的新 prefill (会被chunking)
    """
    budget = SchedulingBudget(
        token_budget=self.scheduler_config.max_num_batched_tokens,
        max_num_seqs=self.scheduler_config.max_num_seqs,
    )

    # ---- Phase 1: 先调度 RUNNING (decode + 未完成的chunked prefill) ----
    running_scheduled = self._schedule_running(budget, curr_loras,
                                                enable_chunking=True)

    # ---- Phase 2: 调度 SWAPPED ----
    if len(running_scheduled.preempted) + len(
            running_scheduled.swapped_out) == 0:
        swapped_in = self._schedule_swapped(budget, curr_loras)

    # ---- Phase 3: 调度 WAITING (新的chunked prefill) ----
    prefills = self._schedule_prefills(budget, curr_loras,
                                        enable_chunking=True)

    # ---- 更新队列 (decode优先, prefill放后面) ----
    self.running.extend(
        [s.seq_group for s in swapped_in.decode_seq_groups])
    self.running.extend(
        [s.seq_group for s in swapped_in.prefill_seq_groups])
    self.running.extend(
        [s.seq_group for s in running_scheduled.decode_seq_groups])
    self.running.extend(
        [s.seq_group for s in running_scheduled.prefill_seq_groups])
    self.running.extend([s.seq_group for s in prefills.seq_groups])

    # ---- 合并输出: prefill 排前面 (attention backend 要求) ----
    scheduled_seq_groups = (prefills.seq_groups +
                            running_scheduled.prefill_seq_groups +
                            swapped_in.prefill_seq_groups +
                            running_scheduled.decode_seq_groups +
                            swapped_in.decode_seq_groups)
```

```
  _schedule_chunked_prefill() 决策流程对比:

  _schedule_default():                  _schedule_chunked_prefill():

  ┌──────────────┐                      ┌──────────────┐
  │ 1. PREFILLS  │ (独占batch)          │ 1. DECODES   │ (先保障decode)
  └──────────────┘                      └──────────────┘
         │                                      │
         v                                      v
  ┌──────────────┐                      ┌──────────────┐
  │ 2. DECODES   │ (只在无prefill时)     │ 2. SWAPPED   │
  └──────────────┘                      └──────────────┘
         │                                      │
         v                                      v
  ┌──────────────┐                      ┌──────────────┐
  │ 3. SWAPPED   │                      │ 3. PREFILLS  │ (可分块)
  └──────────────┘                      └──────────────┘

  关键差异:
  - 默认: 有prefill就不能有decode, TTFT好但吞吐可能低
  - Chunked: decode和prefill共存, ITL好, throughput高
```

---

## 7. Chunked Prefill

### 7.1 为什么需要 Chunked Prefill

```
  问题: 长prompt的prefill耗时很长, 阻塞所有decode请求

  无Chunked Prefill:
  ┌──────────────────────────────────────────────────────┐
  │ Batch 1: 1个长prefill (8000 tokens), 耗时 200ms     │
  │ (所有 decode 请求等待 200ms, ITL 暴涨)               │
  ├──────────────────────────────────────────────────────┤
  │ Batch 2: 10个decode (各1 token), 耗时 20ms           │
  └──────────────────────────────────────────────────────┘

  有Chunked Prefill:
  ┌──────────────────────────────────────────────────────┐
  │ Batch 1: 1个chunked prefill (2048/8000 tokens)       │
  │        + 10个decode (各1 token)                       │
  ├──────────────────────────────────────────────────────┤
  │ Batch 2: 1个chunked prefill (2048/8000, 继续)        │
  │        + 10个decode                                   │
  ├──────────────────────────────────────────────────────┤
  │ Batch 3: 1个chunked prefill (2048/8000, 继续)        │
  │        + 10个decode                                   │
  ├──────────────────────────────────────────────────────┤
  │ Batch 4: 1个chunked prefill (1856/8000, 最后一次)    │
  │        + 10个decode                                   │
  └──────────────────────────────────────────────────────┘

  效果: decode 请求不再需要等整个长 prefill 完成!
```

### 7.2 _chunk_new_tokens_to_schedule() — 分块核心

```python
# vllm/core/scheduler.py:1776-1840

@staticmethod
def _chunk_new_tokens_to_schedule(
    scheduler_config: SchedulerConfig,
    cache_config: CacheConfig,
    budget: SchedulingBudget,
    prompt_limit: int,
    num_new_tokens: int,
) -> int:
    """
    根据预算将 prefill token 数进行分块。

    Args:
        num_new_tokens: 该请求还需要处理的 token 数
    Returns:
        本轮实际要处理的 token 数 (<= num_new_tokens)
    """
    remaining_token_budget = budget.remaining_token_budget()

    if scheduler_config.is_multi_step:
        # Multi-step + chunked prefill: 实际上不分块
        # 如果 num_new_tokens > budget, 返回0 (本轮不调度)
        if num_new_tokens > prompt_limit:
            return num_new_tokens  # 超限, 返回原始值让调用方处理
        return (0 if num_new_tokens > remaining_token_budget else
                num_new_tokens)

    if cache_config.enable_prefix_caching:
        # prefix caching 模式下, chunk size 必须是 block_size 的倍数
        block_size = cache_config.block_size
        remainder = budget.token_budget % block_size
        if remainder != 0:
            raise ValueError(
                "When enabling chunked prefill and prefix caching, "
                "max_num_batched_tokens must be divisible by block_size")
        remaining_token_budget = (remaining_token_budget // block_size *
                                  block_size)

    # 取剩余预算和需要的新token数的较小值
    num_new_tokens = min(num_new_tokens, remaining_token_budget)

    return num_new_tokens
```

```
  Chunked Prefill 的分块过程:

  假设: max_num_batched_tokens = 2048, block_size = 16
        请求A有 3000 个 prompt tokens

  ┌──────────────────────────────────────────────────────────┐
  │ Iteration 1:                                             │
  │   请求A在 waiting 队列                                   │
  │   num_new_tokens = 3000                                  │
  │   remaining_budget = 2048 (刚初始化)                      │
  │   chunked: min(3000, 2048) = 2048                        │
  │   调度 2048 个 token, 请求进入 running, 标记为 prefill   │
  ├──────────────────────────────────────────────────────────┤
  │ Iteration 2:                                             │
  │   请求A在 running 队列, is_prefill() = True              │
  │   已计算: 2048/3000 tokens                               │
  │   num_new_tokens = 3000 - 2048 = 952                     │
  │   remaining_budget = 取决于当前batch (假设1500)           │
  │   chunked: min(952, 1500) = 952                          │
  │   调度全部 952 个 token                                  │
  │   请求完成 prefill, 转为 decode 状态                     │
  ├──────────────────────────────────────────────────────────┤
  │ Iteration 3+:                                            │
  │   请求A在 running 队列, is_prefill() = False (decode)   │
  │   每次 iteration 追加 1 个 token                         │
  └──────────────────────────────────────────────────────────┘
```

### 7.3 启用 Chunked Prefill

```bash
# 启动 vLLM 服务时启用 chunked prefill
vllm serve meta-llama/Llama-2-7b-hf \
    --max-num-batched-tokens 2048 \
    --max-num-seqs 128 \
    --enable-chunked-prefill
    # 可选: --max-model-len 8192

# 对应的 Python API
from vllm import LLM
llm = LLM(
    model="meta-llama/Llama-2-7b-hf",
    max_num_batched_tokens=2048,
    max_num_seqs=128,
    enable_chunked_prefill=True,
)
```

---

## 8. Preemption 抢占

### 8.1 抢占触发条件

```
  何时发生抢占?

  场景: _schedule_running() 中, 某个 running 请求的 KV cache 无法继续扩展

  while not self._can_append_slots(seq_group):
      # 无法为 seq_group 追加新的 slot(s)
      # 原因: GPU KV cache 不足

      # 选择 victim:
      if running_queue:
          victim = running_queue.pop()   # 抢占队列中优先级最低的
      else:
          victim = seq_group              # 抢占自己 (最坏情况)

      # 执行抢占
      preempted_mode = self._preempt(victim, blocks_to_swap_out)
```

### 8.2 _preempt() — 抢占决策

```python
# vllm/core/scheduler.py:1535-1575

def _preempt(
    self,
    seq_group: SequenceGroup,
    blocks_to_swap_out: List[Tuple[int, int]]
) -> PreemptionMode:
    """
    抢占决策逻辑:

    1. 如果用户指定了 preemption_mode → 使用用户指定
    2. 默认 (None):
       - 单序列请求 (绝大多数场景) → RECOMPUTE (开销更低)
       - 多序列请求 (beam search) → SWAP (recompute不支持多序列)
    """
    if self.user_specified_preemption_mode is None:
        if seq_group.get_max_num_running_seqs() == 1:
            preemption_mode = PreemptionMode.RECOMPUTE
        else:
            preemption_mode = PreemptionMode.SWAP
    elif self.user_specified_preemption_mode == "swap":
        preemption_mode = PreemptionMode.SWAP
    else:
        preemption_mode = PreemptionMode.RECOMPUTE

    # 每50次抢占打印一次警告
    if self.num_cumulative_preemption % 50 == 0:
        logger.warning(
            "Sequence group %s is preempted by %s mode... "
            "Increase gpu_memory_utilization or tensor_parallel_size...",
            seq_group.request_id, preemption_mode,
            self.num_cumulative_preemption + 1)
    self.num_cumulative_preemption += 1

    if preemption_mode == PreemptionMode.RECOMPUTE:
        self._preempt_by_recompute(seq_group)
    elif preemption_mode == PreemptionMode.SWAP:
        self._preempt_by_swap(seq_group, blocks_to_swap_out)
    return preemption_mode
```

### 8.3 RECOMPUTE vs SWAP 对比

```
  RECOMPUTE:                                SWAP:
  ┌──────────────────────────┐             ┌──────────────────────────┐
  │ 1. 释放 GPU 上的 KV blocks │            │ 1. 将 KV blocks 从 GPU   │
  │ 2. 状态置为 WAITING       │            │    拷贝到 CPU             │
  │ 3. 回到 waiting 队列      │            │ 2. 状态置为 SWAPPED       │
  │    (从头重新 prefill)     │            │ 3. 回到 swapped 队列      │
  │                           │            │    (GPU有空时 swap-in)    │
  │ 优点: 不需要CPU内存       │            │                           │
  │      (交换空间)            │            │ 优点: 保留计算进度         │
  │                           │            │      (不需要重算)           │
  │ 缺点: 之前计算的 token     │            │                           │
  │      需要重新计算          │            │ 缺点: 需要 CPU 内存         │
  └──────────────────────────┘             │      (swap空间)           │
                                           └──────────────────────────┘
```

### 8.4 _preempt_by_recompute() — 重算抢占

```python
# vllm/core/scheduler.py:1577-1587

def _preempt_by_recompute(self, seq_group: SequenceGroup) -> None:
    """通过重算进行抢占: 释放KV cache, 重置状态, 回到waiting队列."""
    seqs = seq_group.get_seqs(status=SequenceStatus.RUNNING)
    assert len(seqs) == 1  # 只支持单序列
    for seq in seqs:
        seq.status = SequenceStatus.WAITING
        self.free_seq(seq)              # 释放GPU KV blocks
        seq.reset_state_for_recompute() # 重置data状态
    self._free_seq_group_cross_attn_blocks(seq_group)
```

### 8.5 _preempt_by_swap() — 交换抢占

```python
# vllm/core/scheduler.py:1589-1620

def _preempt_by_swap(
    self,
    seq_group: SequenceGroup,
    blocks_to_swap_out: List[Tuple[int, int]],
) -> None:
    self._swap_out(seq_group, blocks_to_swap_out)

def _swap_out(
    self,
    seq_group: SequenceGroup,
    blocks_to_swap_out: List[Tuple[int, int]],
) -> None:
    if not self.block_manager.can_swap_out(seq_group):
        raise RuntimeError(
            "Aborted due to the lack of CPU swap space. "
            "Please increase the swap space to avoid this error.")
    mapping = self.block_manager.swap_out(seq_group)
    blocks_to_swap_out.extend(mapping)
    for seq in seq_group.get_seqs(status=SequenceStatus.RUNNING):
        seq.status = SequenceStatus.SWAPPED

def _swap_in(
    self,
    seq_group: SequenceGroup,
    blocks_to_swap_in: List[Tuple[int, int]],
) -> None:
    mapping = self.block_manager.swap_in(seq_group)
    blocks_to_swap_in.extend(mapping)
    for seq in seq_group.get_seqs(status=SequenceStatus.SWAPPED):
        seq.status = SequenceStatus.RUNNING
```

### 8.6 抢占的完整时间线

```
  抢占完整流程示例:

  GPU KV Cache: [████████████████████░░░░]  80% 满

  ┌─────────────────────────────────────────────────────────────┐
  │ Step N: 正常运行                                            │
  │   running: [A(decoding), B(decoding), C(decoding)]          │
  │   waiting: [D(prompt, 3000 tokens)]                         │
  ├─────────────────────────────────────────────────────────────┤
  │ Step N+1: D 的 prefill 需要大量 blocks                       │
  │   _schedule_prefills(D):                                    │
  │     can_allocate(D) → OK? 假设 OK                           │
  │     allocate(D) → GPU blocks 满了                           │
  │   D 进入 running                                            │
  │   running: [A, B, C, D(prefill)]                            │
  ├─────────────────────────────────────────────────────────────┤
  │ Step N+2: A, B, C 需要追加 decode slot                      │
  │   _schedule_running():                                      │
  │     for A: _can_append_slots(A) → False! (GPU满了)          │
  │     → preempt C (running队列最后一个, 最低优先级)            │
  │     C 状态变为 WAITING (recompute) 或 SWAPPED (swap)        │
  │                                                                │
  │   running: [A, B, D(prefill)]                               │
  │   waiting: [C] 或 swapped: [C]                              │
  └─────────────────────────────────────────────────────────────┘
```

---

## 9. 请求状态机

### 9.1 完整状态转换图

```
                      add_seq_group()
                           |
                           v
                      +---------+
                 +--->| WAITING |<------------------+
                 |    +---------+                    |
                 |         |                         |
                 |         | _allocate_and_set_      |
                 |         | running()               |
                 |         | (分配KV blocks,         |
                 |         |  状态→RUNNING)          |
                 |         v                         |
                 |    +---------+                    |
                 |    | RUNNING |                    |
                 |    +---------+                    |
                 |      |     |        |             |
                 |      |     |        | _preempt_   |
                 |      |     |        | by_swap()   |
                 |      |     |        v             |
                 |      |     |   +---------+        |
                 |      |     |   | SWAPPED |--------+
                 |      |     |   +---------+  _swap_in()
                 |      |     |        |      后状态→RUNNING
                 |      |     |        |
                 |      |     |   free_finished_seq_groups()
                 |      |     |   或 _schedule_running() 中检测完成
                 |      |     |
                 v      v     v
              +-----------------------------+
              | FINISHED_STOPPED            |  (EOS token)
              | FINISHED_LENGTH_CAPPED      |  (达到 max_tokens)
              | FINISHED_ABORTED            |  (用户中止)
              | FINISHED_IGNORED            |  (prompt 太长等)
              +-----------------------------+
```

### 9.2 各状态的含义和转移条件

| 状态 | 含义 | 进入条件 | 离开条件 |
|------|------|----------|----------|
| WAITING (0) | 等待被调度 | 新请求到达 / recompute抢占 | block分配成功, 进入RUNNING |
| RUNNING (1) | 正在计算 | prefill调度 / swap-in / chunked prefill继续 | 完成/decode结束 / 被抢占 |
| SWAPPED (2) | 被换出到CPU | swap抢占 (GPU内存不足) | swap-in成功, 进入RUNNING |
| FINISHED_STOPPED (3) | 正常完成 | 生成EOS token | (终态) |
| FINISHED_LENGTH_CAPPED (4) | 达到长度上限 | output_len >= max_tokens | (终态) |
| FINISHED_ABORTED (5) | 被中止 | abort_seq_group() | (终态) |
| FINISHED_IGNORED (6) | 被忽略 | prompt太长无法分配 | (终态) |

### 9.3 状态检查的核心代码

```python
# vllm/sequence.py:70-72

@staticmethod
def is_finished(status: "SequenceStatus") -> bool:
    return status > SequenceStatus.SWAPPED
    # status 0,1,2 → 未完成; status 3,4,5,6 → 已完成

# vllm/core/scheduler.py:502-504
def has_unfinished_seqs(self) -> bool:
    return len(self.waiting) != 0 or len(self.running) != 0 or len(
        self.swapped) != 0
```

---

## 10. 调度器与 BlockManager

### 10.1 交互全景

```
  Scheduler                          BlockSpaceManager
  ─────────                          ─────────────────
      │                                      │
      │  can_allocate(seq_group)              │
      │─────────────────────────────────────>│  检查 GPU 是否有足够
      │<─────────────────────────────────────│  free blocks
      │  AllocStatus.OK / LATER / NEVER      │
      │                                      │
      │  allocate(seq_group)                 │
      │─────────────────────────────────────>│  为 seq_group 分配
      │                                      │  KV cache blocks
      │                                      │
      │  can_append_slots(seq_group)         │
      │─────────────────────────────────────>│  检查能否为已存在的
      │<─────────────────────────────────────│  序列追加新的 slot
      │  True / False                        │
      │                                      │
      │  append_slots(seq, num_slots)        │
      │─────────────────────────────────────>│  为 seq 追加新 slot
      │<─────────────────────────────────────│  (decode时追加1个token)
      │  List[(src_block, dst_block)]        │  (返回COW列表)
      │                                      │
      │  can_swap_out(seq_group)             │
      │─────────────────────────────────────>│  检查CPU swap空间
      │                                      │
      │  swap_out(seq_group)                 │
      │─────────────────────────────────────>│  将blocks从GPU拷到CPU
      │                                      │
      │  can_swap_in(seq_group)              │
      │─────────────────────────────────────>│  检查GPU是否有空间
      │                                      │
      │  swap_in(seq_group)                  │
      │─────────────────────────────────────>│  将blocks从CPU拷回GPU
      │                                      │
      │  free(seq)                           │
      │─────────────────────────────────────>│  释放seq的KV blocks
      │                                      │
      │  get_block_table(seq)                │
      │─────────────────────────────────────>│  获取seq的block映射表
      │<─────────────────────────────────────│
      │  List[int] (physical block IDs)      │
      │                                      │
      │  get_common_computed_block_ids()     │
      │─────────────────────────────────────>│  prefix caching: 获取
      │<─────────────────────────────────────│  已计算的公共block
      │  List[int]                           │
      │                                      │
      │  access_all_blocks_in_seq(seq, now)  │
      │─────────────────────────────────────>│  更新block访问时间
      │                                      │  (用于LRU eviction)
      │  mark_blocks_as_computed(seq_group)  │
      │─────────────────────────────────────>│  标记blocks已计算
      │                                      │  (prefix caching用)
```

### 10.2 BlockManager 版本选择

```python
# vllm/core/scheduler.py:341-362

version = "selfattn"
if (self.scheduler_config.runner_type == "pooling"
        or self.cache_config.is_attention_free):
    version = "placeholder"

BlockSpaceManagerImpl = BlockSpaceManager.get_block_space_manager_class(
    version)

# 对于普通 attention 模型: version = "selfattn"
#   → CachedBlockSpaceManager (带 prefix caching)
#   或 UncachedBlockSpaceManager (不带 prefix caching)

# 对于 pooling 模型或 attention-free 模型: version = "placeholder"
#   → 不需要真正的 KV cache, 使用占位管理器
```

### 10.3 alloc 结果的三态

```python
# vllm/core/interfaces.py

class AllocStatus(enum.Enum):
    OK = 0       # 可以分配, 有足够 free blocks
    LATER = 1    # 暂时不能分配, 但以后可能可以
                  # (等待其他请求完成释放 blocks)
    NEVER = 2    # 永远不能分配
                  # (prompt 太长, 即使所有 blocks 给它也不够)
```

```
  can_allocate() 的三种返回:

  请求 prompt 长度: 500 tokens, block_size=16
  → 需要约 32 blocks

  ┌───────────────────────────────────────────────┐
  │ GPU 总 blocks: 1000                          │
  │ 已用: 950 blocks                             │
  │ 空闲: 50 blocks                              │
  │                                              │
  │ 请求需要: 32 blocks                          │
  │ can_allocate() → OK (50 >= 32)              │
  ├───────────────────────────────────────────────┤
  │ 已用: 980 blocks                             │
  │ 空闲: 20 blocks                              │
  │                                              │
  │ can_allocate() → LATER (20 < 32, 但理论上    │
  │   等 running 请求完成后可以释放更多)          │
  ├───────────────────────────────────────────────┤
  │ 总 blocks: 1000, 请求需要: 1200 blocks        │
  │                                              │
  │ can_allocate() → NEVER (即使全空也不够)       │
  │   请求状态 → FINISHED_IGNORED                 │
  └───────────────────────────────────────────────┘
```

### 10.4 Copy-on-Write (COW) 机制

```
  当 append_slots() 遇到共享的 block 时需要 COW:

  初始状态 (prefix caching hit, block 5 被两个序列共享):
  Seq A: [block 1] [block 2] [block 5(shared)]
  Seq B: [block 1] [block 2] [block 5(shared)]

  Seq A 追加 slot (decode 新 token):
  1. 需要修改 block 5 的内容
  2. block 5 被共享 → 不能直接修改
  3. COW: 分配新 block 10, 复制 block 5 → block 10
  4. 返回 blocks_to_copy: [(5, 10)]

  结果:
  Seq A: [block 1] [block 2] [block 10(copy of 5, now writable)]
  Seq B: [block 1] [block 2] [block 5(shared, unchanged)]

  SchedulerOutputs.blocks_to_copy 被传递给 worker,
  worker 在执行模型前完成 block copy 操作.
```

---

## 11. 调度器输出

### 11.1 SchedulerOutputs 完整结构

```python
# vllm/core/scheduler.py:132-198

@dataclass
class SchedulerOutputs:
    """The scheduling decision made from a scheduler."""

    # 被调度的序列组列表 (prefill在前, decode在后)
    scheduled_seq_groups: GenericSequence[ScheduledSequenceGroup]

    # prefill 组的数量 (用于 attention backend 排序)
    num_prefill_groups: int

    # 总批处理 token 数
    num_batched_tokens: int

    # 需要从CPU→GPU换入的 blocks: List[(cpu_block, gpu_block)]
    blocks_to_swap_in: List[Tuple[int, int]]

    # 需要从GPU→CPU换出的 blocks: List[(gpu_block, cpu_block)]
    blocks_to_swap_out: List[Tuple[int, int]]

    # 需要复制的 blocks (COW): List[(src_block, dst_block)]
    blocks_to_copy: List[Tuple[int, int]]

    # 被忽略的序列组 (prompt 太长等)
    ignored_seq_groups: List[SequenceGroup]

    # speculative decoding 前瞻槽位数
    num_lookahead_slots: int

    # running 队列大小
    running_queue_size: int

    # 本轮被抢占的请求数
    preempted: int

    def __post_init__(self):
        # swap_in 和 swap_out 不能同时发生
        assert not (self.blocks_to_swap_in and self.blocks_to_swap_out)
```

### 11.2 ScheduledSequenceGroup

```python
# vllm/core/scheduler.py:122-130

@dataclass
class ScheduledSequenceGroup:
    seq_group: SequenceGroup
    # token_chunk_size:
    #   - decode: 1
    #   - prefill (完整): 全部 prompt token 数
    #   - chunked prefill: 本轮要处理的 token 数 (<= prompt 总数)
    token_chunk_size: int
```

### 11.3 三级中间输出结构

```
  SchedulerPrefillOutputs (waiting → prefill):
  ├── seq_groups: List[ScheduledSequenceGroup]   # 被调度的 prefill
  ├── ignored_seq_groups: List[SequenceGroup]    # 被忽略的
  └── num_lookahead_slots: int

  SchedulerRunningOutputs (running → decode/chunked prefill):
  ├── decode_seq_groups: List[ScheduledSequenceGroup]
  ├── prefill_seq_groups: List[ScheduledSequenceGroup] # chunked prefill
  ├── preempted: List[SequenceGroup]              # 被 recompute 抢占
  ├── swapped_out: List[SequenceGroup]            # 被 swap 抢占
  ├── blocks_to_swap_out: List[(int, int)]
  ├── blocks_to_copy: List[(int, int)]
  └── num_lookahead_slots: int

  SchedulerSwappedInOutputs (swapped → running):
  ├── decode_seq_groups: List[ScheduledSequenceGroup]
  ├── prefill_seq_groups: List[ScheduledSequenceGroup]
  ├── blocks_to_swap_in: List[(int, int)]
  ├── blocks_to_copy: List[(int, int)]
  ├── num_lookahead_slots: int
  └── infeasible_seq_groups: List[SequenceGroup]  # swap-in后也无法运行的
```

---

## 12. 调度时间线

### 12.1 不启用 Chunked Prefill 的典型调度时间线

```
  配置: max_num_seqs=3, max_num_batched_tokens=2048
  请求A: 500 tokens prompt, 到达 T=0ms
  请求B: 800 tokens prompt, 到达 T=5ms
  请求C: 2000 tokens prompt, 到达 T=10ms

  ═══════════════════════════════════════════════════════════════
  Iteration 1 (T≈15ms):
  ┌─────────────────────────────────────────────────────────────┐
  │ _schedule_prefills():                                      │
  │   A (500 tokens): can_allocate → OK, budget: 2048-500=1548 │
  │   B (800 tokens): can_allocate → OK, budget: 1548-800=748  │
  │   C (2000 tokens): 748 < 2000 → break                      │
  │                                                            │
  │ _schedule_running(): 跳过 (有prefill)                      │
  │                                                            │
  │ Result: Batch [A(prefill,500), B(prefill,800)]             │
  │ running: [A, B]                                            │
  │ waiting: [C]                                               │
  └─────────────────────────────────────────────────────────────┘
  ═══════════════════════════════════════════════════════════════
  Iteration 2 (T≈50ms, A和B的prefill完成):
  ┌─────────────────────────────────────────────────────────────┐
  │ _schedule_prefills():                                      │
  │   C (2000 tokens): can_allocate → OK, budget: 1548?        │
  │     检查: max_num_seqs=3, running 已有 A,B(2个)            │
  │     2000 <= 2048 → 可以                                    │
  │                                                            │
  │ Result: Batch [C(prefill,2000)]                            │
  │ running: [A, B, C(prefill)]                                │
  │ waiting: []                                                │
  └─────────────────────────────────────────────────────────────┘
  ═══════════════════════════════════════════════════════════════
  Iteration 3 (T≈120ms, C的prefill完成):
  ┌─────────────────────────────────────────────────────────────┐
  │ prefills → empty (waiting为空)                              │
  │ _schedule_running():                                       │
  │   A (decode): budget token 1, num_seqs 1/3                 │
  │   B (decode): budget token 1, num_seqs 2/3                 │
  │   C (decode): budget token 1, num_seqs 3/3                 │
  │                                                            │
  │ Result: Batch [A(decode), B(decode), C(decode)]            │
  │ running: [A, B, C]                                         │
  └─────────────────────────────────────────────────────────────┘
```

### 12.2 启用 Chunked Prefill 的调度时间线

```
  配置: max_num_seqs=4, max_num_batched_tokens=2048,
        enable_chunked_prefill=True
  请求D: 5000 tokens prompt, 到达 T=0ms
  请求E: 100 tokens prompt, 到达 T=1ms  (已完成prefill, decode中)
  请求F: 50 tokens prompt, 到达 T=2ms   (已完成prefill, decode中)

  ═══════════════════════════════════════════════════════════════
  Iteration 1:
  ┌─────────────────────────────────────────────────────────────┐
  │ _schedule_running() (先调度!):                             │
  │   E (decode): 1 token, OK                                  │
  │   F (decode): 1 token, OK                                  │
  │                                                            │
  │ _schedule_prefills():                                      │
  │   D (5000 tokens): remaining_budget = 2048-2 = 2046        │
  │     chunked: min(5000, 2046) = 2046                        │
  │                                                            │
  │ Result: Batch [D(chunked_prefill:2046/5000), E(decode),    │
  │                F(decode)]                                  │
  │ running: [E, F, D(prefill)]                                │
  └─────────────────────────────────────────────────────────────┘
  ═══════════════════════════════════════════════════════════════
  Iteration 2:
  ┌─────────────────────────────────────────────────────────────┐
  │ _schedule_running():                                       │
  │   D (chunked prefill继续): 5000-2046=2954 remaining        │
  │     remaining_budget → chunk min(2954, 2046) = 2046        │
  │   E (decode): 1 token                                      │
  │                                                            │
  │ Result: Batch [D(chunked_prefill:2046/5000), E(decode)]    │
  │ running: [E, F, D(prefill)]                                │
  └─────────────────────────────────────────────────────────────┘
  ═══════════════════════════════════════════════════════════════
  Iteration 3:
  ┌─────────────────────────────────────────────────────────────┐
  │ _schedule_running():                                       │
  │   D (chunked prefill继续): 2954-2046=908 remaining         │
  │     chunk: min(908, 2046) = 908                            │
  │   E (decode): 1 token                                      │
  │   F (decode): 1 token                                      │
  │                                                            │
  │ Result: Batch [D(chunked_prefill:908/5000), E(decode),     │
  │                F(decode)]                                  │
  │ D prefill 完成! 下次迭代转为 decode                        │
  └─────────────────────────────────────────────────────────────┘
```

---

## 13. Prefix Caching

### 13.1 Prefix Caching 与调度器的协作

```python
# vllm/core/scheduler.py:1299-1344 (schedule() 中的 prefix caching 逻辑)

if not self.cache_config.enable_prefix_caching:
    common_computed_block_nums = []

# ... 对每个 scheduled_seq_group ...

if self.cache_config.enable_prefix_caching:
    common_computed_block_nums = (
        self.block_manager.get_common_computed_block_ids(
            seq_group.get_seqs(status=SequenceStatus.RUNNING)))

# 这些已计算的 block IDs 被传递给 worker,
# worker 在 attention 计算中可以跳过这些 blocks
seq_group_metadata = SequenceGroupMetadata(
    ...
    computed_block_nums=common_computed_block_nums,
    ...
)
```

### 13.2 Cached Tokens 在预算中的处理

```python
# vllm/core/scheduler.py:1702-1774

def _get_num_new_uncached_and_cached_tokens(
    self, seq_group, status, enable_chunking, budget
) -> Tuple[int, int]:
    """
    返回 (uncached_tokens, cached_tokens)

    uncached_tokens: 需要实际计算的 token 数 (消耗预算)
    cached_tokens:   已缓存的 token 数 (不消耗计算预算,
                      但 block 已经分配, 不重复消耗)
    """
    for seq in seqs:
        if not seq.is_prefill():
            num_uncached_new_tokens += 1  # decode 永远是 1
            continue

        num_computed_tokens_seq = seq.get_num_computed_tokens()
        all_num_new_tokens_seq = seq.get_len() - num_computed_tokens_seq

        if not self.cache_config.enable_prefix_caching:
            num_uncached_new_tokens += all_num_new_tokens_seq
            continue

        # prefix caching 启用: 查询缓存
        num_cached_tokens_seq = self.block_manager.get_num_cached_tokens(seq)
        # ... 计算 uncached vs cached ...
```

```
  Prefix Caching 场景:

  两个请求共享相同的 system prompt:

  请求X: system_prompt(200 tokens) + user_msg(100 tokens) = 300 tokens
  请求Y: system_prompt(200 tokens) + user_msg(50 tokens)  = 250 tokens

  ┌──────────────────────────────────────────────────────────┐
  │ 请求X 被调度 (第一次):                                    │
  │   block_manager: system prompt 的 blocks → 计算并缓存    │
  │   uncached: 300 tokens → 消耗预算 300                    │
  │   cached: 0                                              │
  ├──────────────────────────────────────────────────────────┤
  │ 请求Y 被调度 (prefix hit!):                               │
  │   block_manager.get_num_cached_tokens(seq) → 200 tokens  │
  │   uncached: 50 tokens (只有 user_msg 剩余部分)            │
  │   cached: 200 tokens (system prompt, 免费!)              │
  │                                                          │
  │   预算消耗: 只消耗 50 (uncached)                          │
  │   → 可以同时调度更多请求!                                 │
  └──────────────────────────────────────────────────────────┘
```

---

## 14. LoRA 感知调度

### 14.1 LoRA 调度的基本逻辑

```python
# 在 _schedule_prefills 中:
lora_int_id = 0
if self.lora_enabled:
    lora_int_id = seq_group.lora_int_id
    if (lora_int_id > 0
            and lora_int_id not in curr_loras
            and len(curr_loras) >= self.lora_config.max_loras):
        # 当前 batch 已经达到 max_loras 上限
        # 该请求暂不调度
        leftover_waiting_sequences.appendleft(seq_group)
        waiting_queue.popleft()
        continue

# 调度成功后:
if curr_loras is not None and lora_int_id > 0:
    curr_loras.add(lora_int_id)
```

### 14.2 LoRA 批处理约束

```
  max_loras = 2 (一次 batch 最多 2 个不同的 LoRA adapter)

  waiting 队列:
  [请求A(LoRA α), 请求B(LoRA α), 请求C(LoRA β), 请求D(LoRA γ)]

  ┌──────────────────────────────────────────────────────────┐
  │ Iteration N:                                            │
  │   curr_loras = {}                                       │
  │   A (LoRA α): OK, curr_loras = {α}                      │
  │   B (LoRA α): OK, curr_loras = {α} (α已存在,不增加)     │
  │   C (LoRA β): OK, curr_loras = {α, β}                   │
  │   D (LoRA γ): len(curr_loras)=2 >= max_loras=2 → skip  │
  │                                                         │
  │   Batch: [A, B, C] (同一个batch包含2个LoRA)             │
  └──────────────────────────────────────────────────────────┘
```

### 14.3 LoRA ID 排序

```python
# vllm/core/scheduler.py:170-182

def _sort_by_lora_ids(self):
    """按 LoRA ID 排序, 使相同 LoRA 的请求相邻."""
    def key_fn(group: ScheduledSequenceGroup):
        key = (group.seq_group.lora_int_id, group.seq_group.request_id)
        if 0 < self.num_prefill_groups < len(self.scheduled_seq_groups):
            # chunked prefill 要求所有 prefill 在 decode 之前
            return (not group.seq_group.is_prefill(), *key)
        return key

    self.scheduled_seq_groups = sorted(self.scheduled_seq_groups,
                                       key=key_fn)
```

---

## 15. Priority 优先级调度

### 15.1 Priority Preemption 机制

```python
# vllm/core/scheduler.py:830-893

def _schedule_priority_preemption(self, budget: SchedulingBudget) -> int:
    """
    优先级抢占:
    - 对 waiting 和 running 按优先级排序
    - 如果 waiting 中有高优先级请求, 但 GPU 内存不足,
      则抢占 running 中优先级最低的请求
    """
    waiting_queue = self.waiting
    running_queue = deque(sorted(self.running, key=self._get_priority))

    force_preemption_count = 0

    if waiting_queue:
        seq_group = waiting_queue.popleft()
        # 检查是否需要抢占低优先级 running 请求
        while running_queue and self._get_priority(
                running_queue[-1]) > self._get_priority(seq_group):
            # running队列末尾优先级更低 → 可能需要抢占
            # ... 检查资源是否足够 ...
            # 如果不够 → 抢占
            vseq_group = running_queue.pop()
            self._preempt(vseq_group, blocks_to_swap_out)
            waiting_queue.appendleft(vseq_group)
            force_preemption_count += 1
```

### 15.2 优先级排序

```python
# vllm/core/scheduler.py:819-828

def _get_priority(self, seq_group) -> Tuple[Optional[int], float]:
    """获取优先级: 用户指定优先级 > arrival_time"""
    return seq_group.priority, seq_group.arrival_time

# 使用负数优先级可以实现 "高优在前":
# priority = -1 → 比 priority = 0 更优先
# priority = 1  → 比 priority = 0 更靠后
```

---

## 16. 监控与调试

### 16.1 关键 Metrics

```python
# vllm/sequence.py:97-123

@dataclass
class RequestMetrics:
    arrival_time: float              # 请求到达时间
    last_token_time: float           # 上一个 token 生成时间
    first_scheduled_time: float      # 首次被调度时间
    first_token_time: float          # 首 token 生成时间
    time_in_queue: float             # 排队时间 (TTFT的一部分)
    finished_time: float             # 完成时间
    scheduler_time: float            # 调度器累计耗时
    model_forward_time: float        # 模型前向传播累计耗时
    model_execute_time: float        # 模型执行总耗时
```

```
  从 RequestMetrics 可以计算出:

  TTFT (Time To First Token):
    = first_token_time - arrival_time

  TPOT (Time Per Output Token):
    = (finished_time - first_token_time) / num_output_tokens

  ITL (Inter-Token Latency):
    = last_token_latency (每个token之间的间隔)

  Queue Time:
    = time_in_queue (在waiting队列中等待的时间)

  Scheduler Overhead:
    = scheduler_time (调度器本身的时间开销)
```

### 16.2 查看调度器状态

```bash
# 启动时开启 debug 日志查看调度细节
VLLM_LOGGING_LEVEL=DEBUG vllm serve meta-llama/Llama-2-7b-hf \
    --max-num-batched-tokens 2048 \
    --max-num-seqs 128 \
    2>&1 | grep -E "scheduler|preempt|chunked|num_batched_tokens"
```

```python
# 编程方式获取调度器状态
from vllm import LLM

llm = LLM(model="meta-llama/Llama-2-7b-hf")

# 获取 engine 和 scheduler (内部API, 可能变化)
engine = llm.llm_engine
scheduler = engine.scheduler[0]  # 取第一个scheduler

# 查看队列状态
print(f"Waiting: {len(scheduler.waiting)}")
print(f"Running: {len(scheduler.running)}")
print(f"Swapped: {len(scheduler.swapped)}")

# 查看抢占计数
print(f"Cumulative preemptions: {scheduler.num_cumulative_preemption}")

# 查看 prefix cache 命中率
print(f"GPU cache hit rate: {scheduler.get_prefix_cache_hit_rate('gpu')}")
```

### 16.3 调度器相关的 Prometheus Metrics (如果启用)

```
  vllm:num_requests_waiting           # waiting 队列大小
  vllm:num_requests_running           # running 队列大小
  vllm:num_requests_swapped           # swapped 队列大小
  vllm:num_preemptions_total          # 抢占总次数 (counter)
  vllm:gpu_cache_usage_perc           # GPU KV cache 使用率
  vllm:cpu_cache_usage_perc           # CPU swap cache 使用率
  vllm:prefix_cache_hit_rate          # prefix cache 命中率
  vllm:time_to_first_token_seconds    # TTFT
  vllm:time_per_output_token_seconds  # TPOT
  vllm:request_prompt_tokens          # 请求 prompt token 数分布
  vllm:request_generation_tokens      # 请求生成 token 数分布
```

### 16.4 常见问题排查

```bash
# 问题1: 频繁抢占 (大量 "is preempted by" 日志)
# 原因: GPU KV cache 不足
# 解决方案: 增加 gpu_memory_utilization 或减少 max_num_seqs
vllm serve model \
    --gpu-memory-utilization 0.95 \
    --max-num-seqs 64

# 问题2: 长 prompt 请求被忽略 (FINISHED_IGNORED)
# 原因: prompt 超过 max_model_len 或 block 容量
# 解决方案: 启用 chunked prefill 或增加 max_model_len
vllm serve model \
    --enable-chunked-prefill \
    --max-model-len 16384

# 问题3: TTFT 过长
# 原因: 大 prefill batch 或 delay_factor 设置
# 解决方案: 减小 max_num_batched_tokens 或设 delay_factor=0
vllm serve model \
    --max-num-batched-tokens 1024 \
    --scheduler-delay-factor 0.0

# 问题4: CPU swap 空间不足
# 原因: swapped 请求过多
# 解决方案: 增加 swap space 或改用 recompute
vllm serve model \
    --swap-space 16 \          # 默认4GB, 增加到16GB
    --preemption-mode recompute # 或强制 recompute
```

---

## 17. 配置参数全解

### 17.1 SchedulerConfig 参数速查

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `max_num_batched_tokens` | None (自动) | 单次迭代最大批处理 token 数 |
| `max_num_seqs` | 128 | 单次迭代最大序列数 |
| `max_model_len` | 8192 | 序列最大长度 |
| `num_lookahead_slots` | 0 | Speculative Decoding 前瞻槽位 |
| `delay_factor` | 0.0 | Prefill 延迟因子 |
| `enable_chunked_prefill` | False | 是否启用分块预填充 |
| `preemption_mode` | None | 抢占模式: "swap"/None(自动) |
| `num_scheduler_steps` | 1 | Multi-Step 调度步数 |
| `policy` | "fcfs" | 调度策略: "fcfs"/"priority" |

### 17.2 常用启动命令参考

```bash
# 高吞吐场景 (大批量, 允许较长 TTFT)
vllm serve model \
    --max-num-batched-tokens 8192 \
    --max-num-seqs 256 \
    --max-model-len 8192 \
    --enable-chunked-prefill

# 低延迟场景 (小批量, 快速响应)
vllm serve model \
    --max-num-batched-tokens 512 \
    --max-num-seqs 32 \
    --max-model-len 4096 \
    --scheduler-delay-factor 0.0

# 长文本场景
vllm serve model \
    --max-model-len 32768 \
    --enable-chunked-prefill \
    --max-num-batched-tokens 4096 \
    --max-num-seqs 64

# Multi-Step Scheduling (降低调度开销)
# 仅适用于 vLLM V1 架构
VLLM_USE_V1=1 vllm serve model \
    --num-scheduler-steps 8 \
    --enable-chunked-prefill

# Priority 调度
vllm serve model \
    --scheduling-policy priority
```

### 17.3 调度器相关完整 vLLM 启动参数

```bash
# 查看所有 scheduler 相关参数
vllm serve --help | grep -A1 -E "scheduler|prefill|preemption|budget|priority"
```

典型输出（vLLM 0.6.x+）：
```
  --max-num-batched-tokens MAX_NUM_BATCHED_TOKENS
                        maximum number of batched tokens per iteration
  --max-num-seqs MAX_NUM_SEQS
                        maximum number of sequences per iteration
  --max-model-len MAX_MODEL_LEN
                        maximum length of a sequence
  --enable-chunked-prefill / --no-enable-chunked-prefill
                        enable chunked prefill
  --scheduler-delay-factor SCHEDULER_DELAY_FACTOR
  --preemption-mode {swap,recompute}
  --num-scheduler-steps NUM_SCHEDULER_STEPS
  --scheduling-policy {fcfs,priority}
```

---

---

## 19. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| Continuous Batching | "公交车随上随下"：每次迭代动态增减 batch 中的请求，不停车等人 | 第二章术语表 |
| Chunked Prefill | "长任务的切片面包"：把长 prompt 的 prefill 切小块，不让它独占 GPU | 第二章术语表 |
| Preemption | "VIP 插队机制"：资源不足时把低优先级请求暂停（swap）或重置（recompute） | 第二章术语表 |
| SchedulingBudget | "每轮的零花钱"：token_budget 和 max_seqs 控制每轮最多调度多少计算量 | 第二章术语表 |
| Prefix Caching | "抄作业"：共享 system prompt 的 KV Cache 只算一次，后续请求直接用 | 第三章术语表 |

---

## 20. A800 部署场景举例

### 20.1 高吞吐场景（Qwen-33B on 2×A800）

```bash
# 允许长 TTFT，追求最大 tokens/s
vllm serve Qwen/Qwen2.5-32B-Instruct-AWQ \
    --tensor-parallel-size 2 \
    --max-num-batched-tokens 16384 \
    --max-num-seqs 128 \
    --max-model-len 32768 \
    --enable-chunked-prefill \
    --scheduler-delay-factor 0.0
```

### 20.2 低延迟场景（在线对话，TTFT 敏感）

```bash
# 优先保证 TTFT P95 < 2s
vllm serve Qwen/Qwen2.5-32B-Instruct-AWQ \
    --tensor-parallel-size 2 \
    --max-num-batched-tokens 4096 \
    --max-num-seqs 32 \
    --max-model-len 8192 \
    --enable-chunked-prefill \
    --scheduler-delay-factor 0.0 \
    --enable-prefix-caching
```

**调度器参数速记**：
- `--max-num-batched-tokens` 越大 → 每批次 prefill 越多 → 吞吐越高但 TTFT 越差
- `--max-num-seqs` 越大 → 并发 decode 越多 → GPU 利用率越高但 TPOT 越差
- `--enable-chunked-prefill` → 必开，尤其是混合负载场景

---

## 21. 上下游串联

```
调度器在 vLLM 推理链中的位置

┌──────────────────────────────────────────────────────────────────┐
│                     vLLM 引擎主循环                        │
│                                                                   │
│  EngineCore.step()                                                │
│    │                                                              │
│    ├── Scheduler.schedule()  ← ★ 本文档                          │
│    │     ├── _schedule_prefills()   (waiting → running)           │
│    │     ├── _schedule_running()    (追加 decode slot)            │
│    │     └── _schedule_swapped()    (swap-in)                    │
│    │                                                              │
│    ├── ModelRunner.execute_model()  ── 05-Worker执行              │
│    │                                                              │
│    └── Scheduler.free_finished_seq_groups()                       │
│                                                                   │
│  输入来源：                                                         │
│    - 新请求 → AsyncLLM.add_request() ── 01-启动入口                │
│    - KV Cache 状态 → BlockManager ── 03-BlockManager               │
│                                                                   │
│  输出去向：                                                         │
│    - SchedulerOutput → Worker.execute_model() ── 05-Worker执行     │
│                                                                   │
│  前置阅读：01-启动入口（理解请求如何进入系统）                         │
│  后续阅读：03-BlockManager（理解调度器的块分配依赖）                   │
└──────────────────────────────────────────────────────────────────┘
```

## 18. 深入学习资源

### 18.1 源码文件清单

| 文件 | 说明 | 行数 |
|------|------|------|
| `vllm/core/scheduler.py` | 调度器主文件 | ~1841 |
| `vllm/core/block_manager.py` | 块空间管理器 | ~650 |
| `vllm/core/interfaces.py` | BlockSpaceManager 接口定义 | ~300 |
| `vllm/sequence.py` | Sequence/SequenceGroup 数据结构 | ~1400 |
| `vllm/config.py` | SchedulerConfig/CacheConfig 配置 | ~2500 |
| `vllm/engine/llm_engine.py` | 引擎主循环 (调用 scheduler) | ~1800 |
| `vllm/core/block/cpu_gpu_block_allocator.py` | CPU/GPU 块分配器 | ~350 |
| `vllm/core/block/prefix_caching_block.py` | Prefix Caching 块管理 | ~700 |

### 18.2 推荐阅读顺序

```
  第1步: vllm/sequence.py (SequenceStatus, Sequence, SequenceGroup)
          → 理解基础数据结构

  第2步: vllm/core/scheduler.py:
          - SchedulingBudget (L46-120)
          - SchedulerOutputs (L132-198)
          - Scheduler.__init__() (L324-423)
          - _schedule_default() (L1051-1154)
          - _schedule_chunked_prefill() (L1156-1249)
          - schedule() 主入口 (L1289-1444)

  第3步: vllm/core/scheduler.py:
          - _schedule_prefills() (L895-1049)
          - _schedule_running() (L521-683)
          - _preempt() / _preempt_by_recompute() / _preempt_by_swap() (L1535-1620)

  第4步: vllm/core/block/prefix_caching_block.py
          → 理解 prefix caching 的块共享和 COW

  第5步: vllm/engine/llm_engine.py
          → 理解 schedule() 如何被调用, 输出如何被使用
```

### 18.3 调试实验

```python
"""
实验 1: 观察调度器的队列变化

在调用 schedule() 前后打印队列状态,
理解每次 iteration 中请求如何在不同队列间流转.
"""

# schedule_test.py
import time
from vllm import LLM, SamplingParams

llm = LLM(
    model="meta-llama/Llama-2-7b-hf",
    max_num_seqs=4,
    max_num_batched_tokens=1024,
    enable_chunked_prefill=False,  # 先不用chunked, 方便观察
)

engine = llm.llm_engine
scheduler = engine.scheduler[0]

# 添加监控钩子
original_schedule = scheduler._schedule
def monitored_schedule():
    print(f"[BEFORE] waiting={len(scheduler.waiting)}, "
          f"running={len(scheduler.running)}, "
          f"swapped={len(scheduler.swapped)}")
    result = original_schedule()
    print(f"[AFTER]  waiting={len(scheduler.waiting)}, "
          f"running={len(scheduler.running)}, "
          f"swapped={len(scheduler.swapped)}, "
          f"preempted={result.preempted}, "
          f"num_batched_tokens={result.num_batched_tokens}")
    return result
scheduler._schedule = monitored_schedule

# 发送请求
prompts = ["Hello, " * 100, "Tell me about " * 50, "What is " * 10]
sampling_params = SamplingParams(max_tokens=100)
outputs = llm.generate(prompts, sampling_params)
```

```python
"""
实验 2: 触发并观察抢占

发送大量请求, 使 GPU 内存不足, 观察抢占行为.
"""

llm = LLM(
    model="meta-llama/Llama-2-7b-hf",
    max_num_seqs=2,                     # 故意设小
    max_num_batched_tokens=512,         # 故意设小
    gpu_memory_utilization=0.3,         # 故意设小, 容易触发抢占
    enable_chunked_prefill=False,
)

scheduler = llm.llm_engine.scheduler[0]

# 设置钩子观察抢占
original_preempt = scheduler._preempt
def monitored_preempt(seq_group, blocks_to_swap_out):
    mode = original_preempt(seq_group, blocks_to_swap_out)
    print(f"[PREEMPT] request={seq_group.request_id}, mode={mode}, "
          f"cumulative={scheduler.num_cumulative_preemption}")
    return mode
scheduler._preempt = monitored_preempt

# 发送多个长 prompt 触发抢占
long_prompts = ["Hello world! " * 500 for _ in range(10)]
sampling_params = SamplingParams(max_tokens=200)
outputs = llm.generate(long_prompts, sampling_params)
```

```python
"""
实验 3: 对比 chunked prefill 的 TTFT

分别在不启用和启用 chunked prefill 的情况下,
测量长 prompt + 短 prompt 混合场景的 TTFT.
"""

import time

def measure_ttft(llm, prompts):
    start = time.time()
    # 使用异步生成来精确测量
    # ... 自行实现 ...

# 不启用 chunked prefill
llm_no_chunked = LLM(model="...", enable_chunked_prefill=False)
ttft_no_chunked = measure_ttft(llm_no_chunked, prompts)

# 启用 chunked prefill
llm_chunked = LLM(model="...", enable_chunked_prefill=True)
ttft_chunked = measure_ttft(llm_chunked, prompts)

print(f"TTFT without chunked: {ttft_no_chunked}")
print(f"TTFT with chunked:    {ttft_chunked}")
```

### 18.4 关键论文和资源

1. **vLLM 论文 (SOSP'23)**: "Efficient Memory Management for Large Language Model Serving with PagedAttention"
   - 提出了 PagedAttention 和 vLLM 的整体架构
   - 解释了 block 管理和抢占机制
   - https://arxiv.org/abs/2309.06180

2. **Splitwise (MLSys'24)**: "Splitwise: Efficient Generative LLM Inference Using Phase Splitting"
   - 提出了 prefill 和 decode 分离的思想
   - 启发了 chunked prefill 设计
   - https://arxiv.org/abs/2311.18677

3. **Sarathi-Serve (OSDI'24)**: "Sarathi-Serve: Efficient LLM Inference with Stalled-free Scheduling"
   - 提出了 chunked prefill (stall-free scheduling) 的完整方案
   - https://arxiv.org/abs/2403.02310

4. **vLLM GitHub Discussions**: 搜索 "scheduler", "chunked prefill", "preemption"
   - https://github.com/vllm-project/vllm/discussions

5. **vLLM 官方文档 - Scheduling**:
   - https://docs.vllm.ai/en/latest/design/arch_overview.html

### 18.5 实验练习清单

| 编号 | 练习 | 目标 |
|------|------|------|
| 1 | 用 `pdb` 在 `_schedule_default()` 设置断点, 跟踪一次完整的 schedule 调用 | 理解调度流程 |
| 2 | 修改 `delay_factor`, 观察 waiting 队列的积攒行为 | 理解延迟调度 |
| 3 | 设置 `max_num_seqs=1`, 发送3个请求, 观察 FCFS 调度顺序 | 理解队列排序 |
| 4 | 启用 chunked prefill, 观察一个长 prompt 被分成几次处理 | 理解分块 |
| 5 | 设置较小的 `gpu_memory_utilization`, 触发抢占, 观察 recompute 行为 | 理解抢占 |
| 6 | 使用 beam search (best_of=4), 观察多序列请求的 swap 抢占 | 理解 SWAP |
| 7 | 启用 prefix caching, 发送共享 system prompt 的请求, 打印 cache hit rate | 理解 prefix caching |
| 8 | 修改 scheduler 代码, 增加自定义日志, 打印每轮的 budget 消耗详情 | 理解预算管理 |
| 9 | 阅读 `_schedule_prefills()` 和 `_schedule_running()` 的完整实现, 用纸笔画出流程图 | 深入理解 |
| 10 | 跟踪一个被 recompute 抢占的请求: 从 WAITING→RUNNING→WAITING→RUNNING→FINISHED | 理解状态机 |

---

## 附录: 关键行号速查

```
vllm/core/scheduler.py 关键行号索引:

  L33-43    PreemptionMode 枚举定义
  L46-120   SchedulingBudget 类
  L122-130  ScheduledSequenceGroup 数据类
  L132-198  SchedulerOutputs 数据类
  L201-240  SchedulerRunningOutputs 数据类
  L243-273  SchedulerSwappedInOutputs 数据类
  L276-295  SchedulerPrefillOutputs 数据类
  L324-423  Scheduler.__init__()
  L437-439  add_seq_group() — 添加请求
  L451-488  abort_seq_group() — 中止请求
  L502-504  has_unfinished_seqs()
  L521-683  _schedule_running() — 调度 running 队列
  L685-801  _schedule_swapped() — 调度 swapped 队列
  L819-828  _get_priority() — 优先级计算
  L830-893  _schedule_priority_preemption() — 优先级抢占
  L895-1049 _schedule_prefills() — 调度 waiting 队列
  L1051-1154 _schedule_default() — 默认调度策略
  L1156-1249 _schedule_chunked_prefill() — 分块预填充策略
  L1251-1256 _schedule() — 内部调度入口
  L1289-1444 schedule() — 对外主入口
  L1446-1451 fork_seq() / free_seq()
  L1472-1491 free_finished_seq_groups() — 释放完成请求
  L1493-1496 _allocate_and_set_running() — 分配 block 并设为 RUNNING
  L1498-1533 _append_slots() — 追加 slot
  L1535-1575 _preempt() — 抢占决策
  L1577-1587 _preempt_by_recompute() — 重算抢占
  L1589-1594 _preempt_by_swap() — 交换抢占
  L1596-1604 _swap_in() — 换入
  L1606-1620 _swap_out() — 换出
  L1622-1635 _passed_delay() — 延迟调度检查
  L1637-1664 _get_num_lookahead_slots() — 前瞻槽位计算
  L1666-1774 _get_num_new_uncached_and_cached_tokens() — token 计数
  L1776-1840 _chunk_new_tokens_to_schedule() — 分块计算
```

---

> "调度器的精髓不在于多复杂，而在于三个队列、两个预算、一个抢占——在这七件事之间做出的每个取舍，都直接影响着延迟和吞吐的天平。"
