# 第五章：Worker 与 ModelRunner 深度剖析

> **vLLM 源码阅读系列**
>
> 本章深入分析 vLLM 推理引擎的 **执行层**：Worker（GPU 工作线程）和 ModelRunner（模型执行器）。
> 理解这一层，你就掌握了 vLLM 如何将调度器的决策转化为实际的 GPU 计算。

---

## 目录

1. [整体架构概览](#1-整体架构概览)
2. [Worker：每 GPU 一个执行单元](#2-worker每-gpu-一个执行单元)
3. [execute_model：一次推理迭代的完整路径](#3-execute_model一次推理迭代的完整路径)
4. [ModelRunner 详解](#4-modelrunner-详解)
5. [Attention 后端选择与实现](#5-attention-后端选择与实现)
6. [FlashAttention 后端的 Attention Metadata](#6-flashattention-后端的-attention-metadata)
7. [CUDA Graph 深度解析](#7-cuda-graph-深度解析)
8. [多 GPU-Tensor-Parallel-TP-执行](#8-多-gputensor-parallel-tp执行)
9. [Sampler：采样器详解](#9-sampler采样器详解)
10. [性能剖析与实践](#10-性能剖析与实践)
11. [深入学习资源](#11-深入学习资源)

---

## 1. 整体架构概览

### 1.1 Worker 在 vLLM 中的位置

```
                              vLLM 推理引擎架构
                              ===================

+------------------------------------------------------------------+
|                          AsyncLLMEngine                          |
|  +----------+    +----------+    +----------------+              |
|  | Request  |--->| Scheduler|--->|  Executor      |              |
|  | Queue    |    | (调度器) |    |  (执行器)       |              |
|  +----------+    +----------+    +-------+--------+              |
|                                          |                        |
+------------------------------------------+------------------------+
                                           |
                    +----------------------+----------------------+
                    |                      |                      |
            +-------v------+      +-------v------+      +-------v------+
            |   Worker 0   |      |   Worker 1   |      |   Worker N   |
            |   (GPU 0)    |      |   (GPU 1)    |      |   (GPU N)    |
            |              |      |              |      |              |
            | +----------+ |      | +----------+ |      | +----------+ |
            | |Model     | |      | |Model     | |      | |Model     | |
            | |Runner    | |      | |Runner    | |      | |Runner    | |
            | +----------+ |      | +----------+ |      | +----------+ |
            | +----------+ |      | +----------+ |      | +----------+ |
            | |KV Cache  | |      | |KV Cache  | |      | |KV Cache  | |
            | +----------+ |      | +----------+ |      | +----------+ |
            +--------------+      +--------------+      +--------------+
```

- **Scheduler**（调度器）：决定每轮推理处理哪些序列（prefill/decode），分配 KV cache 块
- **Worker**（工作线程）：每个 GPU 一个 Worker，负责管理该 GPU 上的 KV cache 和模型
- **ModelRunner**（模型执行器）：Worker 内部的核心组件，负责构建输入张量、执行模型前向传播、处理输出

### 1.2 单步推理的数据流

```
一次完整的推理迭代（iteration）数据流
====================================

SchedulerOutput ------> Worker.execute_model() ------> SamplerOutput
(调度器输出)              (Worker 执行模型)               (采样器输出)

详细数据流：

SchedulerOutput                     Worker                        输出
+------------------+         +-----------------+          +--------------+
| seq_group_meta   |         |                 |          | next_tokens  |
| data_list        |         | prepare_input() |          | logprobs     |
|                  |-------->|   |             |          | hidden_states|
| block_tables     |         |   |             |          |              |
| blocks_to_swap   |         |   v             |          +--------------+
| blocks_to_copy   |         | ModelRunner     |
+------------------+         |   .forward()    |
                             |   |             |
                             |   v             |
                             | model(**inputs) |
                             |   |             |
                             |   v             |
                             | compute_logits  |
                             |   |             |
                             |   v             |
                             | sampler()       |
                             +-----------------+
```

---

## 2. Worker：每 GPU 一个执行单元

### 2.1 Worker 类层次结构

```
继承关系：
=========

WorkerBase (ABC)                           # 抽象接口，定义 execute_model 等
+-- LoraNotSupportedWorkerBase             # 不支持 LoRA 的 Worker（辅助类）
+-- LocalOrDistributedWorkerBase           # 支持单机/分布式的默认实现
    +-- Worker                             # GPU Worker 完整实现
```

源码位置：`vllm/worker/worker_base.py` 和 `vllm/worker/worker.py`

### 2.2 Worker 类定义与核心字段

```python
# vllm/worker/worker.py (实际源码)

class Worker(LocalOrDistributedWorkerBase):
    """A worker class that executes (a partition of) the model on a GPU.

    Each worker is associated with a single GPU. The worker is responsible
    for maintaining the KV cache and executing the model on the GPU. In case
    of distributed inference, each worker is assigned a partition of the model.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        parallel_config: ParallelConfig,
        scheduler_config: SchedulerConfig,
        device_config: DeviceConfig,
        cache_config: CacheConfig,
        load_config: LoadConfig,
        local_rank: int,         # 本地 GPU 编号 (0, 1, 2, ...)
        rank: int,               # 全局 rank 编号
        distributed_init_method: str,
        lora_config: Optional[LoRAConfig] = None,
        speculative_config: Optional[SpeculativeConfig] = None,
        prompt_adapter_config: Optional[PromptAdapterConfig] = None,
        is_driver_worker: bool = False,  # 是否为 driver worker（rank 0）
        model_runner_cls: Optional[Type[GPUModelRunnerBase]] = None,
        observability_config: Optional[ObservabilityConfig] = None,
    ) -> None:
```

核心字段：

| 字段 | 类型 | 说明 |
|------|------|------|
| `model_runner` | `GPUModelRunnerBase` | 模型执行器，负责张量构建和前向传播 |
| `cache_engine` | `List[CacheEngine]` | KV cache 引擎，管理 GPU/CPU 缓存块 |
| `gpu_cache` | `List[List[torch.Tensor]]` | GPU KV cache，供模型推理时使用 |
| `is_driver_worker` | `bool` | 是否为 driver worker（Tensor Parallel 中的 rank 0） |
| `rank` | `int` | 当前 Worker 的全局 rank |
| `local_rank` | `int` | 当前 GPU 的本地编号 |

### 2.3 Worker 初始化与 Cache 分配流程

```
Worker 初始化生命周期
====================

1. __init__()
   +-- 保存所有 Config 对象
   +-- 创建 ModelRunner（根据模型类型选择）
   |   +-- 普通模型 -> ModelRunner
   |   +-- Embedding 模型 -> EmbeddingModelRunner
   |   +-- Encoder-Decoder -> EncoderDecoderModelRunner
   +-- 初始化 profiler（可选）

2. init_device()
   +-- 设置 CUDA 设备：torch.cuda.set_device(local_rank)
   +-- 初始化分布式环境：init_distributed_environment()
   +-- 确保模型并行初始化：ensure_model_parallel_initialized()
   +-- 设置随机种子

3. load_model()
   +-- 委托给 model_runner.load_model()
       +-- 加载模型权重
       +-- 初始化 LoRA/PromptAdapter（如配置）
       +-- torch.compile()（如启用）

4. determine_num_available_blocks()
   +-- model_runner.profile_run()  -> 空跑一次推断，测量峰值内存
   +-- 计算剩余可用显存
   +-- 计算可分配的 GPU block 数量
   +-- 返回 (num_gpu_blocks, num_cpu_blocks)

5. initialize_cache(num_gpu_blocks, num_cpu_blocks)
   +-- _init_cache_engine()
   |   +-- 为每个 pipeline stage 创建 CacheEngine
   +-- _warm_up_model()
   |   +-- 如未启用 --enforce-eager
   |   |   +-- model_runner.capture_model()  -> 捕获 CUDA Graph
   |   +-- 重置随机种子
   +-- Worker 就绪，可执行推理
```

### 2.4 WorkerInput：Worker 执行输入

```python
# vllm/worker/worker_base.py

@dataclasses.dataclass(frozen=True)
class WorkerInput:
    """Local inputs to each worker. May contain device-specific data."""

    num_seq_groups: Optional[int] = None       # 当前批次中的序列组数量
    blocks_to_swap_in: Optional[torch.Tensor] = None   # 需要从 CPU 加载到 GPU 的块
    blocks_to_swap_out: Optional[torch.Tensor] = None  # 需要从 GPU 卸载到 CPU 的块
    blocks_to_copy: Optional[torch.Tensor] = None      # 需要复制的块（Copy-on-Write）
    virtual_engine: int = 0                    # Pipeline Parallel 的虚拟引擎编号
    num_steps: int = 1                        # 多步调度时的步数
```

**block swap/copy 的物理含义：**

```
KV Cache Block 管理操作
=======================

GPU KV Cache:                          CPU Swap Space:
+---+---+---+---+---+                  +---+---+---+---+---+
| 0 | 1 | 2 | 3 | 4 |                  | 0 | 1 | 2 | 3 | 4 |
+---+---+---+---+---+                  +---+---+---+---+---+
                     |                                      |
   swap_in: GPU <-- CPU (被抢占的序列恢复)                    |
   swap_out: GPU --> CPU (保存被抢占的序列)                   |
   copy:     块A --> 块B (Copy-on-Write 写时复制)             |
```

---

## 3. execute_model：一次推理迭代的完整路径

### 3.1 顶层调用链

`execute_model()` 是 `LocalOrDistributedWorkerBase` 中定义的模板方法，它协调了分布式 Worker 之间的元数据广播和模型执行。

```python
# vllm/worker/worker_base.py - 核心执行路径

def execute_model(
    self,
    execute_model_req: Optional[ExecuteModelRequest] = None,
) -> Optional[List[SamplerOutput]]:
    """Executes at least one model step on the given sequences."""
    start_time = time.perf_counter()

    # 步骤 1: 准备输入（包含分布式广播）
    inputs = self.prepare_input(execute_model_req)
    if inputs is None:
        return None

    model_input, worker_input, kwargs = inputs
    num_steps = worker_input.num_steps

    # 步骤 2: 执行 Worker 级别的操作（KV cache swap/copy）
    self.execute_worker(worker_input)

    # 步骤 3: 如果无序列组，直接返回空列表
    if worker_input.num_seq_groups == 0:
        return []

    # 步骤 4: Pipeline Parallel - 非首 stage 接收中间张量
    intermediate_tensors = None
    if not get_pp_group().is_first_rank:
        intermediate_tensors = IntermediateTensors(
            get_pp_group().recv_tensor_dict(all_gather_group=get_tp_group()))

    # 步骤 5: 执行模型前向传播
    output = self.model_runner.execute_model(
        model_input=model_input,
        kv_caches=self.kv_cache[worker_input.virtual_engine],
        intermediate_tensors=intermediate_tensors,
        num_steps=num_steps,
        **kwargs,
    )

    # 步骤 6: Pipeline Parallel - 非末 stage 发送中间张量
    if not get_pp_group().is_last_rank:
        get_pp_group().send_tensor_dict(output.tensors,
                                        all_gather_group=get_tp_group())
        return [None]

    # 步骤 7: 返回采样结果
    return output
```

### 3.2 prepare_input：分布式输入准备

```
prepare_input() 流程（Driver Worker vs. 非 Driver Worker）
==========================================================

Driver Worker (rank 0):                     非 Driver Worker:
+-----------------------------+            +--------------------------+
| 1. prepare_worker_input()  |            | 1. broadcast_tensor_dict  |
|    构建 WorkerInput        |            |    从 rank 0 接收广播     |
|                            |            |                          |
| 2. model_runner            |  broadcast | 2. 反序列化 WorkerInput  |
|    .prepare_model_input()  | =========> |    & ModelInput          |
|    构建 ModelInput         |            |                          |
|                            |            |                          |
| 3. if do_metadata_broadcast|            |                          |
|      广播给所有 TP ranks   |            |                          |
+-----------------------------+            +--------------------------+
```

**Driver Worker 负责**：
1. 从 `ExecuteModelRequest` 中提取 `seq_group_metadata_list`
2. 调用 `model_runner.prepare_model_input()` 构建 GPU 输入张量
3. 将计算结果广播给同 TP 组内的其他 Worker

### 3.3 execute_worker：KV Cache 操作

```python
# vllm/worker/worker.py

@torch.inference_mode()
def execute_worker(self, worker_input: WorkerInput) -> None:
    virtual_engine = worker_input.virtual_engine

    # Swap-in：从 CPU 加载被抢占序列的 KV cache 到 GPU
    if (worker_input.blocks_to_swap_in is not None
            and worker_input.blocks_to_swap_in.numel() > 0):
        self.cache_engine[virtual_engine].swap_in(
            worker_input.blocks_to_swap_in)

    # Swap-out：将需要挂起的序列 KV cache 从 GPU 卸载到 CPU
    if (worker_input.blocks_to_swap_out is not None
            and worker_input.blocks_to_swap_out.numel() > 0):
        self.cache_engine[virtual_engine].swap_out(
            worker_input.blocks_to_swap_out)

    # Copy：CoW (Copy-on-Write) 块复制
    if (worker_input.blocks_to_copy is not None
            and worker_input.blocks_to_copy.numel() > 0):
        self.cache_engine[virtual_engine].copy(worker_input.blocks_to_copy)
```

### 3.4 完整执行流程图

```
execute_model() 完整时序图
==========================

Driver Worker (rank 0)                       Worker 1, 2, ..., N
---------------------                       --------------------
        |                                           |
        | SchedulerOutput                           |
        | (seq_group_metadata_list,                  |
        |  blocks_to_swap/copy)                      |
        |                                           |
        v                                           |
  prepare_input()                                    |
   +-- prepare_worker_input()                        |
   +-- model_runner.prepare_model_input()             |
   |    +-- _prepare_model_input_tensors()            |
   |    |    +-- builder.build()                     |
   |    +-- SamplingMetadata.prepare()                |
   |                                                 |
   +-- broadcast_tensor_dict ----------------------> |
   |                                                 v
   |                                        接收 ModelInput + WorkerInput
   |                                                 |
        |                                           |
        v                                           v
  execute_worker()                           execute_worker()
   +-- swap_in()                               +-- swap_in()
   +-- swap_out()                              +-- swap_out()
   +-- copy()                                  +-- copy()
        |                                           |
        v                                           v
  model_runner.execute_model()              model_runner.execute_model()
   +-- 判断是否使用 CUDA Graph                    +-- 同样执行
   +-- model_executable(                       +-- model_executable(
   |     input_ids,                            |     input_ids,
   |     positions,                            |     positions,
   |     kv_caches,                            |     kv_caches,
   |     attn_metadata)                        |     attn_metadata)
   |                                           |
   +-- [TP: all-reduce 在 attention 和          +-- [TP: all-reduce 在各层]
   |    MLP 层自动发生]                         |
   |                                           |
   +-- compute_logits()  [仅 last pp stage]     +-- compute_logits()  [仅 last pp]
   +-- model.sample()    [仅 driver worker]     +-- return []
        |
        v
  SamplerOutput
  (sampled_tokens, logprobs, ...)
```

---

## 4. ModelRunner 详解

### 4.1 ModelRunner 类层次结构

```
ModelRunner 继承关系
====================

ModelRunnerBase (ABC)                          # 抽象基类
+-- GPUModelRunnerBase[TModelInputForGPU]      # GPU 通用实现
    +-- ModelRunner                            # 标准模型 + 采样
    +-- EmbeddingModelRunner                   # Embedding 模型
    +-- EncoderDecoderModelRunner              # Encoder-Decoder 模型
    +-- CPUModelRunner                         # CPU 推理
    +-- TPUModelRunner                         # TPU 推理
    +-- NeuronModelRunner                      # AWS Neuron 推理
    +-- OpenVINOModelRunner                    # OpenVINO 推理
```

源码位置：`vllm/worker/model_runner.py`

### 4.2 ModelInputForGPU：模型输入数据结构

```python
# vllm/worker/model_runner.py

@dataclass(frozen=True)
class ModelInputForGPU(ModelRunnerInputBase):
    """Base class for model forward pass metadata."""

    input_tokens: Optional[torch.Tensor] = None       # [num_tokens] 输入 token IDs
    input_positions: Optional[torch.Tensor] = None     # [num_tokens] 每个 token 的位置
    seq_lens: Optional[List[int]] = None               # 每个序列的总长度
    query_lens: Optional[List[int]] = None              # 每个序列的查询长度
    lora_mapping: Optional["LoRAMapping"] = None        # LoRA 索引映射
    lora_requests: Optional[Set[LoRARequest]] = None    # LoRA 请求集合
    attn_metadata: Optional["AttentionMetadata"] = None # Attention 元数据
    prompt_adapter_mapping: Optional[PromptAdapterMapping] = None
    prompt_adapter_requests: Optional[Set[PromptAdapterRequest]] = None
    multi_modal_kwargs: Optional[BatchedTensorInputs] = None
    request_ids_to_seq_ids: Optional[Dict[str, List[int]]] = None
    finished_requests_ids: Optional[List[str]] = None
    virtual_engine: int = 0
    async_callback: Optional[Callable] = None
    seq_group_metadata_list: Optional[List[SequenceGroupMetadata]] = None
    scheduler_outputs: Optional[SchedulerOutputs] = None


@dataclass(frozen=True)
class ModelInputForGPUWithSamplingMetadata(ModelInputForGPU):
    """Extended by ModelRunner for sampling."""

    sampling_metadata: Optional["SamplingMetadata"] = None
    is_prompt: Optional[bool] = None
```

### 4.3 ModelInputForGPUBuilder：构建器详解

Builder 负责将 `SequenceGroupMetadata`（调度器输出）转换为 GPU 上的张量。

```
Builder 工作流程
================

seq_group_metadata_list (来自 Scheduler)
        |
        |  遍历每个 seq_group
        v
+-------------------------------------------+
| add_seq_group(seq_group_metadata)          |
|                                            |
| 对于 prefill 序列（is_prompt=True）:        |
|   +-- 整个 prompt token 序列作为输入        |
|   +-- query_len = prompt_len               |
|   +-- 不分配 block_table                   |
|                                            |
| 对于 decode 序列（is_prompt=False）:        |
|   +-- 仅 1 个新 token 作为输入              |
|   +-- query_len = 1                        |
|   +-- 使用 block_table 指向 KV cache       |
+-------------------------------------------+
        |
        v
+-------------------------------------------+
| build() - 构造 GPU 张量                    |
|                                            |
| 1. input_tokens: 拼接所有 token IDs        |
|    [prefill_0, ..., prefill_N,             |
|     decode_0, ..., decode_M]               |
|                                            |
| 2. input_positions: 每个 token 的位置       |
|    对于 decode: position = seq_len - 1     |
|                                            |
| 3. seq_lens: 每个序列的当前总长度           |
|                                            |
| 4. query_lens: 每个序列的查询长度            |
|    prefill: prompt_len                     |
|    decode: 1                               |
|                                            |
| 5. attn_metadata (由 Attention Backend 构建)|
|    +-- builder.build(seq_lens, query_lens)  |
|                                            |
| 6. CUDA Graph padding (如果需要)            |
|    +-- _get_cuda_graph_pad_size()          |
+-------------------------------------------+
```

### 4.4 Prefill 与 Decode 的输入构造对比

```
Prefill 阶段输入构造
====================

序列: "Hello, how are you?"
(假设 tokenized 为 [H, e, l, l, o, ,,  , h, o, w, ...])

input_tokens:  [H, e, l, l, o, ,,  , h, o, w,  , a, r, e,  , y, o, u, ?]
                |<---------- 完整 prompt ------------------------------>|
input_positions: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, ...]
query_len:       len(prompt_tokens) = 20
seq_len:         20  (增加后)
context_len:     0   (之前没有任何已计算的 token)

slot_mapping: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, ...]
               |<-- 每个 token 写入对应 KV cache slot ---------------->|

block_tables: 未使用（prefill 时 block_tables 为 None）


Decode 阶段输入构造
====================

序列已处理到第 20 个 token，当前生成第 21 个 token:

input_tokens:   [next_token_id]                     # 仅 1 个 token
input_positions: [20]                                # seq_len - 1 = 20
query_len:       1
seq_len:          21  (20 + 1)
context_len:      20

slot_mapping: [K]                                    # 写入 KV cache 的位置 K
                                                     # K = block_table[20 // block_size]
                                                     #     * block_size + (20 % block_size)

block_tables: [[2, 5, 7, ...]]                      # 映射到物理 KV cache 块
               |<-- seq 0 使用的物理 block 编号 -->|
```

### 4.5 prepare_model_input() 源码

```python
# vllm/worker/model_runner.py

class ModelRunner(GPUModelRunnerBase[ModelInputForGPUWithSamplingMetadata]):
    """GPU model runner with sampling step."""

    def prepare_model_input(
        self,
        seq_group_metadata_list: List[SequenceGroupMetadata],
        virtual_engine: int = 0,
        finished_requests_ids: Optional[List[str]] = None,
    ) -> ModelInputForGPUWithSamplingMetadata:
        """Prepare the model input based on a given sequence group.

        The API assumes seq_group_metadata_list is sorted by prefill -> decode.
        - input_tokens[:num_prefill_tokens] contains prefill tokens.
        - input_tokens[num_prefill_tokens:] contains decode tokens.
        """
        # 步骤 1: 构建基础张量输入
        model_input = self._prepare_model_input_tensors(
            seq_group_metadata_list, finished_requests_ids)

        # 步骤 2: 仅在最后一个 PP stage 准备采样元数据
        if get_pp_group().is_last_rank:
            generators = self.get_generators(finished_requests_ids)
            sampling_metadata = SamplingMetadata.prepare(
                seq_group_metadata_list, model_input.seq_lens,
                model_input.query_lens, self.device, self.pin_memory,
                generators, self.sampling_metadata_cache)
        else:
            sampling_metadata = None

        is_prompt = (seq_group_metadata_list[0].is_prompt
                     if seq_group_metadata_list else None)

        return dataclasses.replace(model_input,
                                   sampling_metadata=sampling_metadata,
                                   is_prompt=is_prompt,
                                   virtual_engine=virtual_engine)
```

### 4.6 execute_model() 源码

```python
# vllm/worker/model_runner.py

@torch.inference_mode()
@dump_input_when_exception(exclude_args=[0], exclude_kwargs=["self"])
def execute_model(
    self,
    model_input: ModelInputForGPUWithSamplingMetadata,
    kv_caches: List[torch.Tensor],
    intermediate_tensors: Optional[IntermediateTensors] = None,
    num_steps: int = 1,
) -> Optional[Union[List[SamplerOutput], IntermediateTensors]]:
    """Execute the model forward pass and sampling."""

    # 1. 设置活跃 LoRA 适配器
    if self.lora_config:
        self.set_active_loras(model_input.lora_requests,
                              model_input.lora_mapping)

    # 2. 设置活跃 PromptAdapter
    if self.prompt_adapter_config:
        self.set_active_prompt_adapters(
            model_input.prompt_adapter_requests,
            model_input.prompt_adapter_mapping)

    # 3. 开始 attention state 前向传播
    self.attn_state.begin_forward(model_input)

    # 4. 判断是否使用 CUDA Graph
    prefill_meta = model_input.attn_metadata.prefill_metadata
    decode_meta = model_input.attn_metadata.decode_metadata
    virtual_engine = model_input.virtual_engine

    if prefill_meta is None and decode_meta.use_cuda_graph:
        # 纯 decode batch，使用 CUDA Graph
        graph_batch_size = model_input.input_tokens.shape[0]
        model_executable = self.graph_runners[virtual_engine][graph_batch_size]
    else:
        # prefill 或混合 batch，使用 eager 模式
        model_executable = self.model

    # 5. 执行模型前向传播（核心调用）
    with set_forward_context(model_input.attn_metadata):
        hidden_or_intermediate_states = model_executable(
            input_ids=model_input.input_tokens,
            positions=model_input.input_positions,
            kv_caches=kv_caches,
            attn_metadata=model_input.attn_metadata,
            intermediate_tensors=intermediate_tensors,
            **MultiModalInputs.as_kwargs(multi_modal_kwargs, device=self.device),
        )

    # 6. 如果不是最后一个 PP stage，返回中间张量
    if not get_pp_group().is_last_rank:
        return hidden_or_intermediate_states

    # 7. 计算 logits（从 hidden states 到 vocab_size）
    logits = self.model.compute_logits(hidden_or_intermediate_states,
                                       model_input.sampling_metadata)

    # 8. 非 driver worker 不执行采样
    if not self.is_driver_worker:
        return []

    # 9. 采样下一个 token
    output: SamplerOutput = self.model.sample(
        logits=logits,
        sampling_metadata=model_input.sampling_metadata,
    )

    return [output]
```

### 4.7 前向传播的核心：model_executable(**inputs)

```
model_executable(**inputs) 内部流程
===================================

inputs:
+-- input_ids: [num_tokens]  token IDs 张量
+-- positions: [num_tokens] 位置编码张量
+-- kv_caches: List[Tensor] KV cache 列表 (每层一个)
+-- attn_metadata: AttentionMetadata (block_tables, context_lens, ...)
+-- intermediate_tensors: Optional[IntermediateTensors]

模型前向计算 (以 LLaMA 为例，TP=2):
----------------------------------
For each Transformer Layer:
|
+-- RMSNorm(input)                          # 归一化
|
+-- QKV Projection (ColumnParallelLinear)   # TP: 列切分
|   +-- [rank 0]: QKV[:, :hidden/2]
|   +-- [rank 1]: QKV[:, hidden/2:]
|
+-- RoPE (Rotary Position Embedding)        # 旋转位置编码
|
+-- FlashAttention (with KV Cache)          # 注意力计算
|   +-- [rank 0]: 处理 num_heads/2 个头
|   +-- [rank 1]: 处理 num_heads/2 个头
|
+-- O Projection (RowParallelLinear)        # TP: 行切分 + all-reduce
|   +-- tensor_model_parallel_all_reduce()  # TP 通信
|
+-- Residual Connection
|
+-- RMSNorm
|
+-- Gate/Up Projection (ColumnParallelLinear)
|   +-- SiLU(gate) * up
|
+-- Down Projection (RowParallelLinear)
|   +-- tensor_model_parallel_all_reduce()  # TP 通信
|
+-- Residual Connection

最后:
+-- RMSNorm (final)
+-- LM Head (ColumnParallelLinear)
    +-- 输出 logits: [num_tokens, vocab_size]
```

**TP All-Reduce 发生的位置**：每个 Transformer 层中 **2 次**（Attention Output 和 MLP Output）。

---

## 5. Attention 后端选择与实现

### 5.1 后端总览

```
vLLM Attention 后端
===================

  +--------------------------------------------------------------+
  |                    Attention Backend 选择器                    |
  |                    (vllm/attention/selector.py)                |
  +--------------------------------------------------------------+
                              |
          +-------------------+-------------------+
          |                   |                   |
    +-----v-----+      +-----v-----+      +-----v-----+
    |FlashAttn  |      |FlashInfer |      | XFormers  |
    |(默认推荐) |      |(最优 FP8) |      | (回退)    |
    +-----+-----+      +-----+-----+      +-----+-----+
          |                   |                   |
    +-----v-----+      +-----v-----+      +-----v-----+
    | ROCm      |      | Torch     |      | Pallas    |
    | FlashAttn |      | SDPA      |      | (TPU)     |
    | (AMD)     |      | (CPU)     |      |           |
    +-----------+      +-----------+      +-----------+
```

### 5.2 后端选择逻辑（关键源码）

```python
# vllm/attention/selector.py

def which_attn_to_use(
    head_size: int,
    sliding_window: Optional[int],
    dtype: torch.dtype,
    kv_cache_dtype: Optional[str],
    block_size: int,
    is_attention_free: bool,
) -> _Backend:
    """Returns which flash attention backend to use."""

    # 默认选择 FlashAttention
    selected_backend = _Backend.FLASH_ATTN

    # 1. 无 attention 层（如 Mamba）-> NO_ATTENTION
    if is_attention_free:
        return _Backend.NO_ATTENTION

    # 2. 检查全局强制设置
    backend_by_global_setting = get_global_forced_attn_backend()
    if backend_by_global_setting is not None:
        selected_backend = backend_by_global_setting
    else:
        backend_by_env_var = envs.VLLM_ATTENTION_BACKEND
        if backend_by_env_var is not None:
            selected_backend = backend_name_to_enum(backend_by_env_var)

    # 3. 平台特定选择
    if is_cpu():
        return _Backend.TORCH_SDPA
    if is_hip():  # AMD GPU
        return _Backend.ROCM_FLASH

    # 4. NVIDIA GPU 上的 FlashAttention 兼容性检查
    if selected_backend == _Backend.FLASH_ATTN:
        if not current_platform.has_device_capability(80):
            selected_backend = _Backend.XFORMERS       # 不支持 Volta/Turing
        elif dtype not in (torch.float16, torch.bfloat16):
            selected_backend = _Backend.XFORMERS       # 不支持其他 dtype
        elif kv_cache_dtype is not None and kv_cache_dtype.startswith("fp8"):
            selected_backend = _Backend.XFORMERS       # 不支持 FP8 KV cache
        elif block_size % 16 != 0:
            selected_backend = _Backend.XFORMERS       # 不支持非 16 倍数
        elif sliding_window is not None:
            selected_backend = _Backend.XFORMERS       # 不支持 sliding window

    # 5. 检查 FlashAttention 包是否安装 + head_size 支持
    if selected_backend == _Backend.FLASH_ATTN:
        try:
            import vllm.vllm_flash_attn
            supported_sizes = FlashAttentionBackend.get_supported_head_sizes()
            if head_size not in supported_sizes:
                selected_backend = _Backend.XFORMERS
        except ImportError:
            selected_backend = _Backend.XFORMERS

    return selected_backend
```

### 5.3 各后端对比

| 特性 | FlashAttention | FlashInfer | XFormers | Torch SDPA |
|------|---------------|------------|----------|------------|
| **适用场景** | 默认，通用最佳 | 高级优化，FP8 | 回退方案 | CPU 推理 |
| **硬件要求** | SM80+ (A100+) | SM80+ (A100+) | 任何 NVIDIA GPU | CPU |
| **FP8 KV Cache** | 不支持 | 支持 | 支持 | 不支持 |
| **Block Size** | 必须 16 的倍数 | 无限制 | 无限制 | 无限制 |
| **Sliding Window** | 不支持 | 支持 | 支持 | 支持 |
| **Head Size** | 32,64,96,128,160,192,224,256 | 更多 | 无限制 | 无限制 |
| **性能** | 最优 | 最优 (部分场景) | 较慢 | 最慢 |

### 5.4 如何指定 Attention 后端

```bash
# 方法 1: 环境变量
export VLLM_ATTENTION_BACKEND=FLASHINFER  # 使用 FlashInfer
export VLLM_ATTENTION_BACKEND=XFORMERS    # 使用 xFormers
export VLLM_ATTENTION_BACKEND=FLASH_ATTN  # 使用 FlashAttention

# 方法 2: 代码中全局强制
from vllm.attention.selector import global_force_attn_backend, _Backend
global_force_attn_backend(_Backend.FLASHINFER)

# 方法 3: 上下文管理器
from vllm.attention.selector import global_force_attn_backend_context_manager
with global_force_attn_backend_context_manager(_Backend.XFORMERS):
    # 此代码块内使用 XFormers
    pass
```

### 5.5 FlashAttention 后端：KV Cache 形状

```python
# vllm/attention/backends/flash_attn.py

class FlashAttentionBackend(AttentionBackend):

    @staticmethod
    def get_kv_cache_shape(
        num_blocks: int,
        block_size: int,
        num_kv_heads: int,
        head_size: int,
    ) -> Tuple[int, ...]:
        if block_size % 16 != 0:
            raise ValueError("Block size must be a multiple of 16.")
        # KV cache: [2, num_blocks, block_size, num_kv_heads, head_size]
        # 其中 2 代表 [key_cache, value_cache]
        return (2, num_blocks, block_size, num_kv_heads, head_size)
```

```
KV Cache 张量布局（FlashAttention 后端）
========================================

kv_cache.shape = [2, num_blocks, block_size, num_kv_heads, head_size]

  索引 0 -> Key Cache   +-------------------------------------+
                        | [num_blocks, block_size, kv_heads,  |
                        |  head_size]                         |
                        +-------------------------------------+
  索引 1 -> Value Cache +-------------------------------------+
                        | [num_blocks, block_size, kv_heads,  |
                        |  head_size]                         |
                        +-------------------------------------+

物理块布局（block_size=16, num_kv_heads=8, head_size=128）:
+------------------------------------------------------------+
| Block 0                             Block 1                |
| +-------------------------+  +-------------------------+  |
| | Token 0..15 x 8 heads   |  | Token 16..31 x 8 heads  |  |
| | 每个 token 128 维        |  |                          |  |
| +-------------------------+  +-------------------------+  |
| Block 2                             Block 3                |
| ...                                                        |
+------------------------------------------------------------+
```

---

## 6. FlashAttention 后端的 Attention Metadata

### 6.1 FlashAttentionMetadata 字段

```python
# vllm/attention/backends/flash_attn.py

@dataclass
class FlashAttentionMetadata(AttentionMetadata):
    """Metadata for FlashAttentionBackend."""

    # === 批次维度 ===
    seq_lens: Optional[List[int]]              # 每个序列的总长度
    seq_lens_tensor: Optional[torch.Tensor]    # [batch_size] int32 张量

    # === Context/Query/Seq 的关系 ===
    # |---------- context_len ----------|
    # |-------------------- seq_len --------------------|
    #                                   |-- query_len ---|
    max_query_len: Optional[int]               # 批次中最大 query 长度
    max_decode_query_len: Optional[int]        # decode 批次最大 query 长度
    max_prefill_seq_len: int                   # prefill 最大序列长度
    max_decode_seq_len: int                    # decode 最大序列长度

    # === 索引结构 ===
    query_start_loc: Optional[torch.Tensor]    # [batch+1] query 累积起始位置
    seq_start_loc: Optional[torch.Tensor]      # [batch+1] seq 累积起始位置
    context_lens_tensor: Optional[torch.Tensor]# [batch] 每个序列的 context 长度

    # === KV Cache 寻址 ===
    block_tables: Optional[torch.Tensor]        # [batch, max_blocks] 块地址表
    slot_mapping: Optional[torch.Tensor]        # [num_tokens] 每个 token 写入位置

    # === CUDA Graph ===
    use_cuda_graph: bool                        # 是否使用 CUDA Graph

    # === Prefill/Decode 分离 ===
    num_prefills: int                           # prefill 序列数
    num_prefill_tokens: int                     # prefill token 总数
    num_decode_tokens: int                      # decode token 总数
```

### 6.2 关键 Metadata 的构建过程

```
Attention Metadata 构建过程
============================

Builder 遍历每个 seq_group，累积：

1. context_lens:  每个序列已计算的 token 数
   prefill 序列:  context_len = 0 (从零开始)
   decode 序列:   context_len = seq_len - 1

2. block_tables:  每个序列的物理块映射
   block_tables[seq_id] = [block_0, block_1, ..., block_n]
   例如: [2, 5, 7, 11] 表示该序列的 token 存储在物理块 2, 5, 7, 11 中

3. slot_mapping:  每个新 token 应写入 KV cache 的哪个 slot
   slot = block_number * block_size + block_offset

   例如，block_size=16:
   第 20 个 token -> block_index = 20 // 16 = 1
                   -> block_number = block_tables[1] = 5
                   -> offset = 20 % 16 = 4
                   -> slot = 5 * 16 + 4 = 84

4. query_start_loc / seq_start_loc:  累积索引（用于 varlen attention）
   例如，query_lens = [4, 6, 2]:
   query_start_loc = [0, 4, 10, 12]
```

### 6.3 slot_mapping 详解

```
slot_mapping 的构造
====================

假设:
  block_size = 16
  序列 seq_0 的 block_tables = [2, 5, 7]  (3 blocks, 可容纳 48 tokens)
  序列 seq_0 的 context_len = 20  (已计算 20 个 token)
  序列 seq_0 的 query_len = 1   (decode 阶段, 1 个新 token)

新 token 是第 21 个 token (0-indexed = 20)

计算 slot:
  block_index = 20 // 16 = 1   -> 使用 block_tables[1] = 5
  block_offset = 20 % 16 = 4  -> 在块内的偏移
  slot = 5 * 16 + 4 = 84

slot_mapping 示意:
+----------------------------------------------------------+
|  物理 KV Cache                  |                        |
|  +-------+-------+-------+-----+                        |
|  |Block 0|Block 1|Block 2| ... |                        |
|  +-------+-------+-------+-----+                        |
|  | Block | Block | Block | ... |  slot 84 指向          |
|  |   2   |   5   |   7   |     |  Block 5, offset 4     |
|  |       |  *<-- |       |     |                        |
|  +-------+-------+-------+-----+                        |
|                                  |                       |
|  slot_mapping = [84]             |                       |
+----------------------------------------------------------+

对于 prefill（整个 prompt token 序列）:
  slot_mapping = [slot_for_token_0, slot_for_token_1, ..., slot_for_token_N]
```

### 6.4 compute_slot_mapping 源码

```python
# vllm/attention/backends/utils.py

def compute_slot_mapping(
    is_profile_run: bool,
    slot_mapping: List[int],
    seq_id: int,
    seq_len: int,
    context_len: int,
    start_idx: int,
    block_size: int,
    block_tables: Dict[int, List[int]],
):
    """Compute slot mapping for each token in the sequence."""
    if is_profile_run:
        # Memory profiling: block tables not initialized yet
        slot_mapping.extend([PAD_SLOT_ID] * seq_len)
        return

    block_table = block_tables[seq_id]
    for i in range(start_idx, seq_len):
        block_number = block_table[i // block_size]
        block_offset = i % block_size
        slot = block_number * block_size + block_offset
        slot_mapping.append(slot)
```

### 6.5 Prefill 和 Decode Metadata 的分离

```python
# flash_attn.py 中通过属性分离 prefill 和 decode metadata

@property
def prefill_metadata(self) -> Optional["FlashAttentionMetadata"]:
    if self.num_prefills == 0:
        return None
    return FlashAttentionMetadata(
        slot_mapping=self.slot_mapping[:self.num_prefill_tokens],
        seq_lens=self.seq_lens[:self.num_prefills],
        block_tables=self.block_tables[:self.num_prefills],
        use_cuda_graph=False,  # Prefill 不使用 CUDA Graph
        ...
    )

@property
def decode_metadata(self) -> Optional["FlashAttentionMetadata"]:
    if self.num_decode_tokens == 0:
        return None
    return FlashAttentionMetadata(
        slot_mapping=self.slot_mapping[self.num_prefill_tokens:],
        seq_lens_tensor=self.seq_lens_tensor[self.num_prefills:],
        block_tables=self.block_tables[self.num_prefills:],
        use_cuda_graph=self.use_cuda_graph,
        ...
    )
```

### 6.6 FlashAttention 前向计算核心

```python
# unified_flash_attention 的核心逻辑
# vllm/attention/backends/flash_attn.py

# 1. 将 KV 写入 cache
if kv_cache.numel() > 0:
    torch.ops._C_cache_ops.reshape_and_cache_flash(
        key, value, key_cache, value_cache,
        attn_metadata.slot_mapping,   # <-- 关键：通过 slot_mapping 索引
        kv_cache_dtype,
    )

# 2. Prefill: 使用 flash_attn_varlen_func（支持 block_tables）
if prefill_meta := attn_metadata.prefill_metadata:
    prefill_output = flash_attn_varlen_func(
        q=query[:num_prefill_tokens],
        k=key_cache,                          # 从 KV cache 读取
        v=value_cache,
        cu_seqlens_q=prefill_meta.query_start_loc,
        block_table=prefill_meta.block_tables, # paged attention!
        causal=True,
    )

# 3. Decode: 使用 flash_attn_with_kvcache
if decode_meta := attn_metadata.decode_metadata:
    decode_output = flash_attn_with_kvcache(
        q=decode_query.unsqueeze(1),           # [batch, 1, num_heads, head_size]
        k_cache=key_cache,
        v_cache=value_cache,
        block_table=decode_meta.block_tables,
        cache_seqlens=decode_meta.seq_lens_tensor,
        causal=True,
    )
```

---

## 7. CUDA Graph 深度解析

### 7.1 什么是 CUDA Graph

CUDA Graph 将一系列 CUDA kernel launch 预先记录下来，形成一个"图"，之后只需一次调用即可重放整个操作序列，大幅减少 CPU 端的 kernel launch overhead。

```
CUDA Graph 原理
================

  Eager 模式 (每次迭代):              CUDA Graph 模式:
  +----------+                        +--------------+
  | CPU:     |                        | 捕获阶段:    |
  | launch k1|--> GPU: k1             |  记录所有    |
  | launch k2|--> GPU: k2             |  kernel 调用 |
  | launch k3|--> GPU: k3             |  到一张图中  |
  | ...      |                        +------+-------+
  | launch kN|--> GPU: kN                    |
  +----------+                        +------v-------+
   每次都要 CPU launch              | 重放阶段:    |
   Overhead ~5-10us/kernel          | graph.replay()|--> GPU: k1,k2,...,kN
                                      | 一次性提交    |     所有 kernel
                                      +--------------+
```

### 7.2 vLLM 中 CUDA Graph 的适用范围

vLLM **仅对 decode 阶段**使用 CUDA Graph，原因：

1. **Decode 的输入形状固定**：每个序列只输入 1 个 token，batch_size 固定
2. **Prefill 的输入形状可变**：不同 prompt 长度不同
3. **性能收益边界**：当 token 数 > 200 时，CUDA Graph 收益可忽略不计

### 7.3 CUDA Graph 捕获流程（关键源码）

```python
# vllm/worker/model_runner.py

@torch.inference_mode()
def capture_model(self, kv_caches: List[List[torch.Tensor]]) -> None:
    """Cuda graph capture a model.

    Note that CUDA graph's performance gain is negligible if number
    of batched tokens are larger than 200. And since CUDA graph
    requires fixed sized tensors, supporting large/variable batch
    size requires high GPU memory overhead. Thus, vLLM only captures
    decoding requests. Mixed batch (chunked prefill + decoding) or
    prefill requests are not captured.

    Since it is used for decoding-only, it assumes there's only 1 token
    per sequence in the batch.
    """
    logger.info("CUDA graphs can take additional 1~3 GiB memory per GPU.")

    max_batch_size = self.max_batchsize_to_capture
    input_tokens = torch.zeros(max_batch_size, dtype=torch.long).cuda()
    input_positions = torch.zeros(max_batch_size, dtype=torch.long).cuda()

    # 可捕获的 batch size 列表：
    # _BATCH_SIZES_TO_CAPTURE = [1, 2, 4, 8, 16, 24, 32, 40, ..., 8192]
    batch_size_capture_list = [
        bs for bs in _BATCH_SIZES_TO_CAPTURE
        if bs <= self.max_batchsize_to_capture
    ]

    with graph_capture() as graph_capture_context:
        for virtual_engine in range(pipeline_parallel_size):
            # 从大到小捕获（先用大 batch_size 捕获以减少显存碎片）
            for batch_size in reversed(batch_size_capture_list):
                attn_metadata = (
                    self.attn_state.graph_capture_get_metadata_for_batch(
                        batch_size))

                graph_runner = CUDAGraphRunner(
                    self.model, self.attn_backend.get_name(),
                    self.attn_state.graph_clone(batch_size),
                    self.model_config.is_encoder_decoder_model)

                capture_inputs = {
                    "input_ids": input_tokens[:batch_size],
                    "positions": input_positions[..., :batch_size],
                    "kv_caches": kv_caches[virtual_engine],
                    "attn_metadata": attn_metadata,
                    "memory_pool": self.graph_memory_pool,
                    "stream": graph_capture_context.stream,
                }

                with set_forward_context(attn_metadata):
                    graph_runner.capture(**capture_inputs)
                self.graph_memory_pool = graph_runner.graph.pool()
                self.graph_runners[virtual_engine][batch_size] = graph_runner

    logger.info("Graph capturing finished in %.0f secs.", elapsed_time)
```

### 7.4 CUDAGraphRunner 源码

```python
# vllm/worker/model_runner.py

class CUDAGraphRunner:

    def __init__(self, model, backend_name, attn_state, is_encoder_decoder_model):
        self.model = model
        self.input_buffers: Dict[str, torch.Tensor] = {}    # 输入缓冲区
        self.output_buffers: Dict[str, torch.Tensor] = {}   # 输出缓冲区
        self._graph: Optional[torch.cuda.CUDAGraph] = None

    def capture(self, input_ids, positions, hidden_or_intermediate_states,
                intermediate_inputs, kv_caches, attn_metadata,
                memory_pool, stream, **kwargs):
        """捕获模型前向传播为 CUDA Graph"""

        # 先预热几次（让 Triton autotune 等初始开销完成）
        for _ in range(_NUM_WARMUP_ITERS):  # _NUM_WARMUP_ITERS = 2
            self.model(
                input_ids=input_ids, positions=positions,
                kv_caches=kv_caches, attn_metadata=attn_metadata, **kwargs,
            )
        torch.cuda.synchronize()

        # 创建 CUDA Graph 并捕获
        self._graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self._graph, pool=memory_pool, stream=stream):
            output = self.model(
                input_ids=input_ids, positions=positions,
                kv_caches=kv_caches, attn_metadata=attn_metadata, **kwargs,
            )
            if hidden_or_intermediate_states is not None:
                hidden_or_intermediate_states.copy_(output)
            else:
                hidden_or_intermediate_states = output

        torch.cuda.synchronize()

        # 保存输入缓冲区引用（replay 时需要拷贝新数据进去）
        self.input_buffers = {
            "input_ids": input_ids,
            "positions": positions,
            "kv_caches": kv_caches,
        }
        self.output_buffers = {"hidden_states": hidden_or_intermediate_states}

    def forward(self, input_ids, positions, kv_caches,
                attn_metadata, intermediate_tensors, **kwargs):
        """重放 CUDA Graph（仅拷贝变化的输入）"""

        # 将新输入拷贝到固定的输入缓冲区（必须 in-place 更新）
        self.input_buffers["input_ids"].copy_(input_ids, non_blocking=True)
        self.input_buffers["positions"].copy_(positions, non_blocking=True)
        self.input_buffers["slot_mapping"].copy_(
            attn_metadata.slot_mapping, non_blocking=True)

        # 更新 attention state 的 graph 输入缓冲区
        self.attn_state.prepare_graph_input_buffers(
            self.input_buffers, attn_metadata, ...)

        # 一次调用，重放整个前向传播
        self.graph.replay()

        # 从输出缓冲区读取结果
        return self.output_buffers["hidden_states"]
```

### 7.5 CUDA Graph 的显存开销

```
CUDA Graph 显存分析
====================

每个捕获的 batch_size 对应一个 CUDAGraphRunner，每个都需要：

1. 输入缓冲区：input_ids [batch_size], positions [batch_size],
   slot_mapping [batch_size], block_tables [batch_size, max_blocks], ...

2. 输出缓冲区：hidden_states [batch_size, hidden_size]

3. CUDA Graph 执行池：~200-500 MB（取决于模型大小和 batch_size）

4. 中间激活：与 eager 模式相同

总开销估算（以 LLaMA-7B, max_num_seqs=256 为例）:
  需要捕获的 batch_sizes: ~34 个
  每个 runner 的内存池: ~200 MB
  总开销: 34 x 200 MB ~= 6.8 GB

这就是 vLLM 日志中 "CUDA graphs can take additional 1~3 GiB"
的来源 -> 可以通过减小 max_num_seqs 来减少开销

优化策略:
  - --enforce-eager: 完全禁用 CUDA Graph（调试用）
  - 减小 --max-num-seqs: 减少需要捕获的 batch_size 数量
  - 减小 --gpu-memory-utilization: 为 CUDA Graph 留出显存
```

### 7.6 批量图捕获的 batch_size 策略

```python
# _BATCH_SIZES_TO_CAPTURE 和 _get_graph_batch_size

_BATCH_SIZE_ALIGNMENT = 8
_BATCH_SIZES_TO_CAPTURE = [1, 2, 4] + [
    _BATCH_SIZE_ALIGNMENT * i for i in range(1, 1025)
]
# 即: [1, 2, 4, 8, 16, 24, 32, 40, 48, ..., 8192]

def _get_graph_batch_size(batch_size: int) -> int:
    """Returns the padded batch size given actual batch size."""
    if batch_size <= 2:
        return batch_size
    elif batch_size <= 4:
        return 4
    else:
        return ((batch_size + _BATCH_SIZE_ALIGNMENT - 1) //
                _BATCH_SIZE_ALIGNMENT * _BATCH_SIZE_ALIGNMENT)
```

### 7.7 CUDA Graph Replay 执行路径

```
execute_model() 中的路径选择:
------------------------------

if prefill_meta is None and decode_meta.use_cuda_graph:
    # 纯 decode + CUDA graph 可用
    graph_batch_size = model_input.input_tokens.shape[0]
    model_executable = self.graph_runners[virtual_engine][graph_batch_size]
else:
    # prefill 或混合批次
    model_executable = self.model

output = model_executable(
    input_ids=..., positions=..., kv_caches=..., attn_metadata=...
)

        +------------------+------------------+
        |  CUDA Graph 路径 |   Eager 路径      |
        +------------------+------------------+
        | graph.forward()  | model.forward()  |
        |   |              |   |              |
        |   +-- copy 输入   |   +-- 正常       |
        |   |   到 buffer   |   |   PyTorch    |
        |   |              |   |   前向传播    |
        |   +-- graph       |   |              |
        |   |   .replay()   |   |              |
        |   |              |   |              |
        |   +-- 返回输出    |   +-- 返回输出    |
        +------------------+------------------+
```

### 7.8 何时禁用 CUDA Graph

```bash
# 场景 1: 调试时（确保 eager 执行，方便定位问题）
vllm serve /path/to/model --enforce-eager

# 场景 2: 显存不足（CUDA Graph 额外占用 1-3 GB/GPU）
vllm serve /path/to/model --enforce-eager

# 场景 3: 模型结构动态变化
vllm serve /path/to/model --enforce-eager

# 场景 4: 需要 torch.compile() 的动态图优化
vllm serve /path/to/model --enforce-eager
```

---

## 8. 多 GPU（Tensor Parallel TP）执行

### 8.1 TP 架构概述

```
Tensor Parallelism (TP) 架构
=============================

                    +--------------+
                    |  Scheduler   |  (运行在 rank 0 / driver worker)
                    +------+-------+
                           |
              broadcast seq_group_metadata
         +-----------------+-----------------+
         |                 |                 |
   +-----v-----+     +-----v-----+     +-----v-----+
   | Worker 0  |     | Worker 1  |     | Worker N  |
   | (rank 0)  |     | (rank 1)  |     | (rank N)  |
   |  Driver   |     |           |     |           |
   |           |     |           |     |           |
   | +-------+ |     | +-------+ |     | +-------+ |
   | |Model  | |     | |Model  | |     | |Model  | |
   | |Shard 0| |<===>| |Shard 1| |<===>| |Shard N| |
   | +-------+ |     | +-------+ |     | +-------+ |
   +-----------+     +-----------+     +-----------+
        ^                 ^                 ^
        +-----------------+-----------------+
              all-reduce (在 Attention Output / MLP Output)
```

### 8.2 Driver Worker 与 Non-Driver Worker

```
角色分工
========

Driver Worker (rank 0):
  +-- 接收 SchedulerOutput
  +-- prepare_input(): 构建 ModelInput + WorkerInput
  +-- broadcast: 广播给所有 TP ranks
  +-- execute_worker(): KV cache 操作
  +-- model_runner.execute_model(): 模型前向传播
  +-- compute_logits(): 计算 logits
  +-- model.sample(): 执行采样 [只有 driver 执行]
  +-- 返回 SamplerOutput

Non-Driver Workers (rank 1, 2, ..., N):
  +-- 接收 broadcast 的 ModelInput + WorkerInput
  +-- execute_worker(): KV cache 操作
  +-- model_runner.execute_model(): 模型前向传播
  |   +-- TP 自动 all-reduce 在各层进行
  +-- return []  (不执行采样)
```

### 8.3 TP 通信模式

```
TP 中每次 Transformer 层的通信
===============================

  +----------------------------------------------------------+
  |                    Attention Block                        |
  |                                                          |
  |  RMSNorm                                                 |
  |     |                                                    |
  |  +--v--------------------------+                        |
  |  | QKV Projection              |  ColumnParallelLinear   |
  |  | (每个 rank 持有一部分列)       |  无需通信               |
  |  +--+--------------------------+                        |
  |     |                                                    |
  |  +--v--------------------------+                        |
  |  | FlashAttention              |  分头计算               |
  |  | (每个 rank 持有 num_heads/N) |  无需通信               |
  |  +--+--------------------------+                        |
  |     |                                                    |
  |  +--v--------------------------+                        |
  |  | O Projection                |  RowParallelLinear      |
  |  | (每个 rank 持有一部分行)       |                        |
  |  +--+--------------------------+                        |
  |     |                                                    |
  |  +--v--------------------------+                        |
  |  | All-Reduce <==============> |  <- 第 1 次 TP 通信     |
  |  | (聚合所有 rank 的输出)        |                        |
  |  +--+--------------------------+                        |
  |     |                                                    |
  |     +-- Residual Add --+                                |
  |     |                  |                                |
  |     v                  |                                |
  |  RMSNorm               |                                |
  |     |                  |                                |
  |  +--v------------------+                                |
  |  | Gate/Up Projection  |  ColumnParallelLinear          |
  |  +--+------------------+                                |
  |     |                                                    |
  |  +--v------------------+                                |
  |  | Down Projection     |  RowParallelLinear             |
  |  +--+------------------+                                |
  |     |                                                    |
  |  +--v------------------+                                |
  |  | All-Reduce <======> |  <- 第 2 次 TP 通信             |
  |  +--+------------------+                                |
  |     |                                                    |
  |     +-- Residual Add --+                                |
  +----------------------------------------------------------+

每层 Transformer 2 次 all-reduce:
  1. Attention Output 后
  2. MLP Output 后

对于 LLaMA-7B (32 层), TP=4:
  总共 64 次 all-reduce 操作
```

### 8.4 All-Reduce 的实现

```python
# vllm/distributed/parallel_state.py

class GroupCoordinator:
    def all_reduce(self, input_: torch.Tensor) -> torch.Tensor:
        # 优先使用 custom all-reduce (基于 NVLink 或 PCIe P2P)
        if self.ca_comm is not None and self.ca_comm.should_custom_ar(input_):
            return torch.ops.vllm.outplace_all_reduce(
                input_, group_name=self.unique_name)
        # 否则使用 PyTorch 原生 all-reduce (基于 NCCL)
        else:
            torch.ops.vllm.inplace_all_reduce(input_,
                group_name=self.unique_name)
            return input_

# RowParallelLinear 中调用 all-reduce:
# vllm/model_executor/layers/linear.py
output = tensor_model_parallel_all_reduce(output_parallel)
```

---

## 9. Sampler：采样器详解

### 9.1 Sampler 的职责

```python
# vllm/model_executor/layers/sampler.py

class Sampler(nn.Module):
    """Samples the next tokens from the model's outputs.

    This layer does the following:
    1. Discard hidden states not used for sampling
    2. Compute logits for next tokens
    3. Apply presence, frequency, and repetition penalties
    4. Apply temperature scaling
    5. Apply top-p and top-k truncation
    6. Apply min-p truncation
    7. Sample the next tokens

    Each sequence group can have different sampling parameters.
    """
```

### 9.2 Sampler.forward() 完整流程

```python
def forward(
    self,
    logits: torch.Tensor,              # [num_tokens, vocab_size]
    sampling_metadata: SamplingMetadata,
) -> Optional[SamplerOutput]:
    """Single-step GPU-side sampling."""

    # 1. 初始化采样张量（温度、top_p、top_k、惩罚系数等）
    if not sampling_metadata.reuse_sampling_tensors:
        self._init_sampling_tensors(logits, sampling_metadata)

    # 2. 应用 min_tokens 惩罚（将 stop token 设为 -inf）
    logits = _apply_min_tokens_penalty(logits, sampling_metadata)

    # 3. 应用出现/频率/重复惩罚
    if do_penalties:
        logits = _apply_penalties(
            logits, prompt_tokens, output_tokens,
            presence_penalties, frequency_penalties, repetition_penalties)

    # 4. 应用温度缩放（temperature scaling）
    logits = logits.to(torch.float)
    logits.div_(sampling_tensors.temperatures.unsqueeze(dim=1))

    # 5. 应用 top-k / top-p 过滤
    if do_top_p_top_k:
        logits = _apply_top_k_top_p(logits, top_ps, top_ks)

    # 6. 应用 min-p 过滤
    if do_min_p:
        logits = _apply_min_p(logits, min_ps)

    # 7. 计算概率分布
    probs = torch.softmax(logits, dim=-1, dtype=torch.float)
    logprobs = torch.log_softmax(logits, dim=-1, dtype=torch.float)

    # 8. 采样下一个 token
    maybe_deferred_sample_results, maybe_sampled_tokens_tensor = _sample(
        probs, logprobs, sampling_metadata, sampling_tensors)

    # 9. 提取 logprobs
    prompt_logprobs, sample_logprobs = get_logprobs(
        logprobs, sampling_metadata, maybe_deferred_sample_results)

    # 10. 构建 SamplerOutput
    return _build_sampler_output(...)
```

### 9.3 各采样策略详解

```
采样策略完整流程
================

logits: [num_seqs, vocab_size]  (每个序列一行)
       |
       v
+------------------------------+
| 1. 惩罚 (Penalties)          |
|                              |
| Presence Penalty:            |
|   logits[t] -= alpha_p       |
|   如果 token t 已经在序列中   |
|                              |
| Frequency Penalty:           |
|   logits[t] -= alpha_f x     |
|   count(t)                   |
|                              |
| Repetition Penalty:          |
|   logits[t] = logits[t] < 0  |
|     ? logits[t] * alpha_r    |
|     : logits[t] / alpha_r    |
+--------------+---------------+
               v
+------------------------------+
| 2. 温度 (Temperature)        |
| logits = logits / T          |
| T=1.0: 不变                  |
| T<1.0: 更尖锐 (确定性增强)    |
| T>1.0: 更平滑 (随机性增强)    |
+--------------+---------------+
               v
+--------------------------------------+
| 3. Top-K 过滤                        |
| 保留 logits 最大的 K 个值，其余 -inf   |
+------------------+-------------------+
                   v
+--------------------------------------+
| 4. Top-P (Nucleus) 过滤               |
| 保留最小集合，使得累积概率 >= p         |
+------------------+-------------------+
                   v
+------------------------------------------+
| 5. Min-P 过滤                             |
| 保留 prob >= min_p x max_prob 的 token    |
+------------------+-----------------------+
                   v
+--------------------------------------+
| 6. Softmax + 采样                     |
|                                      |
| probs = softmax(logits)              |
| Greedy: argmax(probs)                |
| Random: multinomial(probs)           |
| Beam Search: top-n logprobs          |
+--------------------------------------+
```

### 9.4 Top-K / Top-P / Min-P 实现

```python
def _apply_top_k_top_p(
    logits: torch.Tensor,
    p: torch.Tensor,     # [batch] top_p 值
    k: torch.Tensor,     # [batch] top_k 值
) -> torch.Tensor:
    """Apply top-k and top-p filtering to logits."""
    logits_sort, logits_idx = logits.sort(dim=-1, descending=False)

    # Apply top-k
    top_k_mask = logits_sort.size(1) - k.to(torch.long)
    top_k_mask = logits_sort.gather(1, top_k_mask.unsqueeze(dim=1))
    top_k_mask = logits_sort < top_k_mask
    logits_sort.masked_fill_(top_k_mask, -float("inf"))

    # Apply top-p
    probs_sort = logits_sort.softmax(dim=-1)
    probs_sum = probs_sort.cumsum(dim=-1)
    top_p_mask = probs_sum <= 1 - p.unsqueeze(dim=1)
    top_p_mask[:, -1] = False  # 至少保留一个 token
    logits_sort.masked_fill_(top_p_mask, -float("inf"))

    # 恢复原始排序
    logits = torch.empty_like(logits_sort).scatter_(
        dim=-1, index=logits_idx, src=logits_sort)
    return logits


def _apply_min_p(
    logits: torch.Tensor,
    min_p: torch.Tensor,   # [batch] min_p 值
) -> torch.Tensor:
    """Apply min-p filtering."""
    probs = torch.softmax(logits, dim=-1)
    top_probs, _ = probs.max(dim=-1, keepdim=True)
    scaled_min_p = min_p.unsqueeze_(dim=1) * top_probs
    tokens_to_remove = probs < scaled_min_p
    logits = logits.masked_fill_(tokens_to_remove, -float("inf"))
    return logits
```

### 9.5 SamplerOutput 结构

```python
class SamplerOutput(msgspec.Struct):
    """For each sequence group, generate a list of SequenceOutput."""

    outputs: List[CompletionSequenceGroupOutput]  # 每个 seq_group 的输出

    sampled_token_probs: Optional[torch.Tensor] = None   # 采样概率
    logprobs: Optional[torch.Tensor] = None              # log 概率
    sampled_token_ids: Optional[torch.Tensor] = None      # 采样 token IDs
    sampled_token_ids_cpu: Optional[torch.Tensor] = None  # CPU 上的 token IDs

    hidden_states: Optional[torch.Tensor] = None          # 最后 hidden states
    prefill_hidden_states: Optional[torch.Tensor] = None  # prefill hidden states

    model_forward_time: Optional[float] = None            # 前向传播耗时
    model_execute_time: Optional[float] = None            # 总执行耗时
```

### 9.6 常用采样命令行参数

```bash
vllm serve /path/to/model \
    --temperature 0.7 \           # 温度（默认 1.0）
    --top-p 0.9 \                 # Top-p (nucleus) 采样
    --top-k 50 \                  # Top-k 采样
    --min-p 0.05 \                # Min-p 采样
    --repetition-penalty 1.1 \    # 重复惩罚
    --frequency-penalty 0.5 \     # 频率惩罚
    --presence-penalty 0.5 \      # 出现惩罚
    --seed 42                     # 随机种子
```

---

## 10. 性能剖析与实践

### 10.1 推理耗时分布

```
一次推理迭代的时间分布（典型场景）
===================================

以 LLaMA-7B, A100-40GB, batch_size=32, decode-only 为例：

+-------------------------------------------------------------+
| 阶段                          | 耗时 (ms)  | 占比          |
+-------------------------------------------------------------+
| prepare_input()               | ~0.05      | <0.5%         |
|   +-- builder.build() (CPU)   |            |               |
|   +-- 张量 H2D 拷贝            |            |               |
+-------------------------------------------------------------+
| execute_worker()              | ~0.01      | <0.1%         |
|   +-- KV cache swap/copy      |            |               |
+-------------------------------------------------------------+
| model_executable() 前向传播    | ~8-12      | ~85%          |
|   +-- Attention (FlashAttn)   | ~3-5       |               |
|   +-- MLP (GEMM)              | ~4-6       |               |
|   +-- All-Reduce (TP 通信)     | ~1-2       |               |
+-------------------------------------------------------------+
| compute_logits()              | ~0.5       | ~5%           |
+-------------------------------------------------------------+
| model.sample()                | ~0.3       | ~3%           |
|   +-- penalties + temperature |            |               |
|   +-- top-k/top-p + softmax   |            |               |
|   +-- multinomial/argmax      |            |               |
+-------------------------------------------------------------+
| 总计                          | ~10-13     | 100%          |
+-------------------------------------------------------------+

Prefill 阶段（prompt_len=1024, batch_size=1）:
  模型前向传播: ~15-25 ms（与 prompt 长度正相关）
```

### 10.2 关键优化目标

```
优化矩阵
========

瓶颈                        | 优化方向
----------------------------+----------------------------------
模型前向传播 (占 85%+)       | 1. CUDA Graph (减少 kernel launch)
                             | 2. FlashInfer 后端 (FP8 KV cache)
                             | 3. 量化 (AWQ, GPTQ, FP8)
                             | 4. torch.compile() 图优化
                             | 5. 算子融合 (fused RMSNorm, fused RoPE)
----------------------------+----------------------------------
Attention 计算              | 1. PagedAttention (高效 KV cache 管理)
                             | 2. Prefix caching (跳过重复 prompt)
                             | 3. FlashAttention (fused kernel)
                             | 4. 增大 block_size (减少查表开销)
----------------------------+----------------------------------
TP 通信                     | 1. NVLink/NVSwitch (高带宽)
                             | 2. Custom all-reduce (绕过 NCCL)
                             | 3. 减少 TP 度数
----------------------------+----------------------------------
采样                        | 1. GPU 端采样 (避免 CPU-GPU 同步)
                             | 2. FlashInfer sampling kernel
                             | 3. Pinned memory (减少拷贝开销)
----------------------------+----------------------------------
调度                        | 1. Continuous batching (动态批次)
                             | 2. Chunked prefill (避免 prefill 阻塞)
                             | 3. Prefix caching (跳过计算)
```

### 10.3 使用 Nsight Systems 进行 Timeline 分析

```bash
# 方法 1: 使用 vLLM 内置 profiler
export VLLM_TORCH_PROFILER_DIR=/tmp/vllm_profile
vllm serve /path/to/model --max-num-seqs 32

# 方法 2: 使用 Nsight Systems
nsys profile --trace=cuda,nvtx,osrt,cublas \
    --output=/tmp/vllm_nsys \
    python -m vllm.entrypoints.openai.api_server \
        --model /path/to/model \
        --enforce-eager

# 方法 3: 使用 PyTorch Profiler (在代码中)
with torch.profiler.profile(
    activities=[
        torch.profiler.ProfilerActivity.CPU,
        torch.profiler.ProfilerActivity.CUDA,
    ],
    record_shapes=True,
    with_stack=True,
) as prof:
    output = model_runner.execute_model(model_input, kv_caches)
prof.export_chrome_trace("trace.json")
```

### 10.4 Worker 端的 Profiler 代码

```python
# vllm/worker/worker.py 中内置的 Profiler

class Worker(LocalOrDistributedWorkerBase):
    def __init__(self, ...):
        # Torch profiler. Enabled and configured through env vars:
        # VLLM_TORCH_PROFILER_DIR=/path/to/save/trace
        if envs.VLLM_TORCH_PROFILER_DIR:
            self.profiler = torch.profiler.profile(
                activities=[
                    torch.profiler.ProfilerActivity.CPU,
                    torch.profiler.ProfilerActivity.CUDA,
                ],
                with_stack=True,
                on_trace_ready=torch.profiler.tensorboard_trace_handler(
                    torch_profiler_trace_dir, use_gzip=True))
```

### 10.5 关键性能指标

```bash
# 查看 vLLM 服务运行时的性能指标
curl http://localhost:8000/metrics | grep -E "vllm"

# 关键指标：
# vllm:time_to_first_token_seconds       # TTFT - 首 token 延迟
# vllm:time_per_output_token_seconds     # TPOT - 每输出 token 延迟
# vllm:request_success_total             # 成功请求数
# vllm:num_requests_running              # 当前运行中的请求数
# vllm:num_requests_waiting              # 等待中的请求数
# vllm:gpu_cache_usage_perc              # GPU KV cache 使用率
# vllm:prompt_tokens_total               # 处理的 prompt token 总数
# vllm:generation_tokens_total           # 生成的 token 总数
```

### 10.6 常见性能问题排查

```
问题诊断清单
============

1. 首 token 延迟高 (TTFT 高)
   +-- prompt 长度是否过长
   +-- prefix caching 是否启用
   +-- 是否有 block swap 操作
   +-- prefill batch 是否过大导致排队

2. 每 token 延迟高 (TPOT 高)
   +-- batch_size 是否过大 -> GEMM 计算密集
   +-- CUDA Graph 是否启用
   +-- attention backend 选择
   +-- KV cache 是否有碎片

3. 吞吐量低
   +-- GPU 利用率 (nvidia-smi)
   +-- continuous batching 是否生效
   +-- max_num_seqs 是否太小
   +-- max_num_batched_tokens 是否太小
   +-- TP 通信是否成为瓶颈

4. 显存不足 (OOM)
   +-- 减小 max_num_seqs
   +-- 减小 gpu_memory_utilization
   +-- 启用 --enforce-eager (禁用 CUDA Graph)
   +-- 减小 max_model_len
   +-- 使用量化模型
```

### 10.7 实践命令

```bash
# === 基础推理测试 ===
vllm serve meta-llama/Llama-2-7b-hf \
    --host 0.0.0.0 --port 8000 \
    --max-num-seqs 64 --max-model-len 4096 \
    --gpu-memory-utilization 0.9

# 发送请求
curl http://localhost:8000/v1/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "meta-llama/Llama-2-7b-hf",
        "prompt": "Explain the architecture of vLLM",
        "max_tokens": 100,
        "temperature": 0.7
    }'

# === 使用不同 Attention 后端 ===
export VLLM_ATTENTION_BACKEND=FLASHINFER
vllm serve /path/to/model

# === 禁用 CUDA Graph（调试模式）===
vllm serve /path/to/model --enforce-eager

# === 性能测试 ===
# 使用 benchmark_throughput 脚本
python benchmarks/benchmark_throughput.py \
    --model /path/to/model \
    --dataset ShareGPT_V3_unfiltered_cleaned_split.json \
    --num-prompts 1000

# === Profiling ===
VLLM_TORCH_PROFILER_DIR=/tmp/profile vllm serve /path/to/model
# 查看 trace
tensorboard --logdir=/tmp/profile
```

### 10.8 实验建议

```
动手实验路线
============

实验 1: 追踪一次完整的推理迭代
  1. 在 Worker.execute_model() 入口设置断点
  2. 观察 execute_model_req 的结构
  3. 跟踪 prepare_input() -> model_runner.execute_model() -> sample()
  4. 记录每步的输入输出形状

实验 2: 对比不同 Attention 后端
  1. VLLM_ATTENTION_BACKEND=FLASH_ATTN 运行 benchmark
  2. VLLM_ATTENTION_BACKEND=FLASHINFER 运行 benchmark
  3. 对比延迟和吞吐量

实验 3: CUDA Graph 对比
  1. 默认配置运行 benchmark
  2. --enforce-eager 运行 benchmark
  3. 对比 decode 阶段的延迟差异

实验 4: TP 扩展实验
  1. --tensor-parallel-size 1 运行 benchmark
  2. --tensor-parallel-size 2 运行 benchmark
  3. --tensor-parallel-size 4 运行 benchmark
  4. 分析扩展效率

实验 5: Profiling 分析
  1. VLLM_TORCH_PROFILER_DIR=/tmp/prof 启动服务
  2. 发送一批请求
  3. 用 tensorboard 或 chrome://tracing 打开 trace
  4. 找出最耗时的 kernel 和通信操作
```

---

## 12. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| ModelRunner | "GPU 上的指挥家"：负责构建输入张量、调度 attention 后端、执行前向传播、驱动采样 | 第五章术语表 |
| slot_mapping | "KV Cache 的门牌号"：把每个 token 映射到物理 KV Cache block 中的具体位置 | 第五章术语表 |
| CUDAGraphRunner | "预录的广播体操"：启动时录制不同 batch_size 的前向传播图，推理时一键重放 | 第五章术语表 |
| Attention Backend | "注意力的方言翻译官"：FlashAttention/FlashInfer/XFormers，统一接口不同实现 | 第五章术语表 |
| Sampler | "彩票摇号机"：接收 logits，施加温度/top-k/top-p 过滤，最终采样出下一个 token | 第五章术语表 |

---

## 13. A800 部署场景举例

### 13.1 Attention 后端选择（2×A800）

```bash
# 推荐：FlashInfer 后端（FP8 KV Cache + 更低延迟）
export VLLM_ATTENTION_BACKEND=FLASHINFER
vllm serve Qwen/Qwen2.5-32B-Instruct-AWQ \
    --tensor-parallel-size 2 \
    --max-num-seqs 64 \
    --enforce-eager  # A800 上 eager decode 亦可接受
```

### 13.2 CUDA Graph 策略

```bash
# 方案 A：完全禁用 CUDA Graph（启动快，节省显存 2-4 GB）
vllm serve Qwen/Qwen2.5-32B-Instruct-AWQ \
    --tensor-parallel-size 2 \
    --enforce-eager

# 方案 B：仅捕获小 batch_size 的 CUDA Graph
vllm serve Qwen/Qwen2.5-32B-Instruct-AWQ \
    --tensor-parallel-size 2 \
    --compilation-config '{"cudagraph_capture_sizes": [1,2,4,8,16]}'
```

### 13.3 查看 GPU 执行效率

```bash
# 观察 GPU 利用率和显存使用
watch -n 1 nvidia-smi

# 查看 vLLM 指标端点
curl -s http://localhost:8000/metrics | grep -E "vllm:(time_to_first_token|time_per_output_token|num_requests)"
```

---

## 14. 上下游串联

```
Worker/ModelRunner 在 vLLM 推理链中的位置

┌──────────────────────────────────────────────────────────────────┐
│                 一次推理迭代的完整数据流                              │
│                                                                   │
│  Scheduler.schedule() ── 02-调度器                                │
│    │ 输出: seq_group_metadata_list                                │
│    ▼                                                              │
│  Worker.prepare_input()                                           │
│    │ 分布式广播 metadata                                           │
│    ▼                                                              │
│  ModelRunner.prepare_model_input()  ← ★ 本文档核心                 │
│    │ 构建: input_tokens, positions, slot_mapping, block_tables    │
│    │ 来源: 序列数据 = 02-调度器; block_tables = 03-BlockManager     │
│    ▼                                                              │
│  Worker.execute_worker()                                          │
│    │ KV Cache swap_in/swap_out/copy                                │
│    ▼                                                              │
│  ModelRunner.execute_model()                                      │
│    │ 选 CUDA Graph 或 eager 模式                                   │
│    ├── model.forward(input_ids, positions, kv_caches, metadata)   │
│    │   ├── Attention (FlashAttention/FlashInfer) ── 读写 KV Cache │
│    │   ├── MLP (GEMM via Tensor Core)                             │
│    │   └── TP All-Reduce (每层 2 次)                               │
│    ├── model.compute_logits()                                     │
│    └── model.sample() ──→ SamplerOutput                           │
│         │                                                          │
│         ▼                                                          │
│  AsyncLLM.process_output() ──→ 流式返回给客户端                      │
│                                                                   │
│  前置阅读：01-启动入口 → 02-调度器 → 03-BlockManager                 │
│  本文档是 vLLM 源码阅读五部曲的收官之章                                │
└──────────────────────────────────────────────────────────────────┘
```

---

## 11. 深入学习资源

### 11.1 关键源码文件清单

| 文件 | 行数 | 关键内容 |
|------|------|----------|
| `vllm/worker/worker.py` | ~498 | Worker 类：初始化、内存分析、cache 管理 |
| `vllm/worker/worker_base.py` | ~486 | WorkerBase, LocalOrDistributedWorkerBase, execute_model() |
| `vllm/worker/model_runner.py` | ~1933 | GPUModelRunnerBase, ModelRunner, CUDAGraphRunner, builder |
| `vllm/worker/model_runner_base.py` | ~242 | ModelRunnerBase, ModelRunnerInputBase |
| `vllm/worker/cache_engine.py` | ~ | CacheEngine: KV cache 块分配与管理 |
| `vllm/attention/selector.py` | ~305 | 注意力后端自动选择逻辑 |
| `vllm/attention/backends/flash_attn.py` | ~781 | FlashAttention 完整实现（metadata + kernel） |
| `vllm/attention/backends/utils.py` | ~ | slot_mapping, block_tables 构建工具 |
| `vllm/model_executor/layers/sampler.py` | ~ | Sampler: 完整采样流程 |
| `vllm/distributed/parallel_state.py` | ~ | TP 通信：all-reduce, broadcast |
| `vllm/model_executor/layers/linear.py` | ~ | ColumnParallelLinear, RowParallelLinear |
| `vllm/model_executor/sampling_metadata.py` | ~ | SamplingMetadata 准备与缓存 |

### 11.2 推荐阅读顺序

```
第一轮：理解整体流程
  1. vllm/worker/worker_base.py  -> execute_model() 模板方法
  2. vllm/worker/worker.py       -> Worker 实现
  3. vllm/worker/model_runner.py -> ModelRunner.execute_model()

第二轮：理解输入构造
  4. vllm/worker/model_runner.py -> ModelInputForGPUBuilder
  5. vllm/attention/backends/utils.py -> compute_slot_mapping()

第三轮：理解 Attention
  6. vllm/attention/selector.py         -> 后端选择逻辑
  7. vllm/attention/backends/flash_attn.py -> FlashAttention 完整流程

第四轮：理解 CUDA Graph
  8. vllm/worker/model_runner.py -> capture_model()
  9. vllm/worker/model_runner.py -> CUDAGraphRunner

第五轮：理解采样与分布式
  10. vllm/model_executor/layers/sampler.py -> Sampler.forward()
  11. vllm/distributed/parallel_state.py     -> all_reduce, broadcast
  12. vllm/model_executor/layers/linear.py   -> RowParallelLinear
```

### 11.3 论文与参考资料

| 资源 | 说明 |
|------|------|
| [vLLM Paper](https://arxiv.org/abs/2309.06180) | PagedAttention 原始论文 |
| [FlashAttention Paper](https://arxiv.org/abs/2205.14135) | FlashAttention 算法原理 |
| [FlashAttention-2 Paper](https://arxiv.org/abs/2307.08691) | FlashAttention-2 改进 |
| [FlashInfer](https://github.com/flashinfer-ai/flashinfer) | FlashInfer 内核库 |
| [CUDA Graphs Guide](https://developer.nvidia.com/blog/cuda-graphs/) | NVIDIA CUDA Graph 官方指南 |
| [Megatron-LM](https://arxiv.org/abs/1909.08053) | Tensor Parallelism 原始论文 |
| [NCCL](https://github.com/NVIDIA/nccl) | NVIDIA 集合通信库 |
| [vLLM GitHub](https://github.com/vllm-project/vllm) | vLLM 主仓库 |

### 11.4 关键概念速查

| 概念 | 一句话解释 |
|------|-----------|
| **Worker** | 每个 GPU 上一个，负责管理 KV cache 和执行模型 |
| **ModelRunner** | Worker 内的核心，构建输入张量、执行前向传播、处理输出 |
| **SchedulerOutput** | 调度器的输出，决定本轮处理哪些序列 |
| **SequenceGroupMetadata** | 每个序列组的元数据（token IDs, block_tables, sampling_params） |
| **ModelInputForGPU** | 打包了所有 GPU 模型前向传播需要的输入 |
| **AttentionMetadata** | 包含了 attention 所需的所有元数据（block_tables, slot_mapping, context_lens） |
| **slot_mapping** | 将每个 token 映射到 KV cache 的物理位置 |
| **block_tables** | 每个序列的逻辑块到物理块的映射表 |
| **CUDA Graph** | 将一系列 kernel launch 录制成图，之后一次调用即可重放 |
| **CUDAGraphRunner** | 封装了 CUDA Graph 的捕获与重放 |
| **Tensor Parallelism (TP)** | 将模型参数切分到多个 GPU，每层有 2 次 all-reduce |
| **All-Reduce** | 多 GPU 上求和 + 广播，TP 中的核心通信操作 |
| **Driver Worker** | TP 组中 rank 0 的 Worker，负责调度和采样 |
| **Sampler** | 将 logits 转换为下一 token，支持各种采样策略 |
| **SamplerOutput** | 包含采样结果、概率和 hidden states |

### 11.5 调试技巧

```python
# 技巧 1: 打印模型输入
# 在 model_runner.py build() 返回前添加：
logger.info(f"input_tokens shape: {input_tokens_tensor.shape}")
logger.info(f"seq_lens: {seq_lens}")
logger.info(f"query_lens: {query_lens}")
logger.info(f"slot_mapping[:20]: {slot_mapping_tensor[:20]}")
logger.info(f"num_prefills: {attn_metadata.num_prefills}")
logger.info(f"num_decode_tokens: {attn_metadata.num_decode_tokens}")

# 技巧 2: 检查 CUDA Graph 是否生效
if prefill_meta is None and decode_meta.use_cuda_graph:
    logger.info(f"Using CUDA Graph, batch_size={graph_batch_size}")
else:
    logger.info(f"Using Eager mode")

# 技巧 3: 检查 TP 通信
import torch.distributed as dist
logger.info(f"TP rank: {dist.get_rank()}, TP size: {dist.get_world_size()}")
```

---

## 附录 A：Worker 初始化的完整命令序列

```bash
# 完整启动参数示例
vllm serve meta-llama/Llama-2-7b-hf \
    # === Worker 相关 ===
    --tensor-parallel-size 2 \              # TP 度数
    --pipeline-parallel-size 1 \            # PP 度数
    --worker-use-ray \                      # 使用 Ray 管理 Worker 进程
    --max-parallel-loading-workers 8 \      # 并行加载模型权重的 Worker 数

    # === GPU & Memory ===
    --gpu-memory-utilization 0.9 \          # GPU 显存使用率
    --cpu-offload-gb 0 \                    # CPU offload 大小
    --max-num-seqs 256 \                    # 最大并发序列数
    --max-num-batched-tokens 8192 \         # 每批次最大 token 数
    --max-model-len 4096 \                  # 最大序列长度

    # === CUDA Graph ===
    --max-seq-len-to-capture 8192 \         # CUDA Graph 捕获的最大 seq_len
    # --enforce-eager \                     # 禁用 CUDA Graph

    # === KV Cache ===
    --block-size 16 \                       # KV cache 块大小
    --swap-space 4 \                        # CPU swap 空间 (GB)
```

## 附录 B：完整 execute_model() 调用链时序图

```
execute_model() 完整时序
========================

时间 ---------------------------------------------------------->

Driver (rank 0):            Rank 1:               Rank N:
|                           |                     |
| SchedulerOutput           |                     |
|                           |                     |
+- prepare_input()          |                     |
|  +- prepare_worker_input()|                     |
|  +- prepare_model_input() |                     |
|     +- builder.add_seq()  |                     |
|     |  +- per seq:        |                     |
|     |     +- _compute_lens|                     |
|     |     +- _compute_    |                     |
|     |        slot_mapping |                     |
|     +- builder.build()    |                     |
|     +- SamplingMetadata   |                     |
|         .prepare()        |                     |
|                           |                     |
| broadcast ----------------+-------------------->|
|                           +- recv broadcast ----+
|                           |                     |
+- execute_worker()         +- execute_worker() -+
|  +- swap_in()             |  +- swap_in()       |
|  +- copy()                |  +- copy()          |
|                           |                     |
+- model_runner             +- model_runner       |
|  .execute_model()         |  .execute_model()   |
|                           |                     |
|  +- 选 CUDA Graph/Eager   |  +- 选 CUDA Graph   |
|                           |                     |
|  +- model_executable(     |  +- model_executable|
|  |   input_ids,          |  |                   |
|  |   positions,          |  |                   |
|  |   kv_caches,          |  |                   |
|  |   attn_metadata)      |  |                   |
|  |                       |  |                   |
|  |  [TP all-reduce 自动] |  |  [TP all-reduce]  |
|  |                       |  |                   |
|  +- compute_logits()     |  +- compute_logits() |
|  |                       |  |                   |
|  +- model.sample()       |  +- return []        |
|  |  +- penalties         |                     |
|  |  +- temperature       |                     |
|  |  +- top-k/top-p       |                     |
|  |  +- softmax           |                     |
|  |  +- multinomial/argmax|                     |
|  |                       |                     |
|  +- return [SamplerOutput]|                     |
|                           |                     |
+- 返回给 Scheduler --------+---------------------+
```

---

> **下一章预告**: 第六章将深入 `Cache Engine 与 KV Cache 管理`，包括 PagedAttention 的块分配策略、块管理器、前缀缓存、Copy-on-Write 机制、以及 Swap In/Out 的实现细节。
