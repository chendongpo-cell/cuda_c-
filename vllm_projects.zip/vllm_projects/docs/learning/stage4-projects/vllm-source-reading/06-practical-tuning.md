# 06 - vLLM 实战调优完全指南

> "没有测量就没有优化。一次只改一个参数，每次都要测。"

---

## 白话引入：改车先上马力机的故事

改装车圈有一条铁律：**先上马力机，再动手。**

你把一台原厂思域开到改装店，说"我要加 50 匹马力"。一个靠谱的技师不会直接给你装个大涡轮。他先把车上马力机（测功机 / Dyno）拉一条基线曲线——当前马力、扭矩、空燃比、涡轮压力全部记录。然后他换一个进气，再上马力机拉一次——看进气改装到底加了 3 匹还是 5 匹。再调 ECU，再拉一次。每次都只改一个变量，每次都测量，每次记录。

现在想象一个"野路子"改装：进排气、涡轮、中冷、ECU 一起上。马力确实涨了 80 匹——但到底是哪个改装件贡献最大？如果出了爆震，是 ECU 调太激进还是涡轮压力过高？你永远不知道。而且这种改法大概率在第一个弯道就拉缸——因为你没有基线，没有对比，没有渐进验证。

**vLLM 调优就是大模型的"马力机调校"。**

你有一个 7B 或者 32B 的模型要部署到线上，默认参数跑起来吞吐只有 800 tokens/s，你觉得不够。这时候如果你把量化、batch size、prefix caching、CUDA Graphs、chunked prefill 全打开，跑出来 2000 tokens/s——你确实进步了，但如果有问题（比如 TPOT 突然飙到 200ms），你根本不知道是谁引起的。

调优三定律不是口号，是血的教训：

1. **没有基线，就没有调优**——每次改动前后都要 benchmark，记录 TTFT / TPOT / Throughput / GPU Util。没有基线数据，你只是在"随机扭旋钮"。
2. **一次只改一个参数**——改了 max_num_seqs 又改 quantization，你永远不知道吞吐提升是谁的功劳、延迟恶化是谁的锅。
3. **瓶颈决定优化方向**——compute-bound 才去增大 batch、考虑 TP；memory-bound 增大 batch 反而让延迟更差；scheduling-bound 调 CUDA Graphs 和 chunked prefill 才有效。

本文提供一套完整的、可复现的 vLLM 调优方法论——从建立基线到逐项扫描到最终配置锁定，每个步骤都有真实的命令和可预期的数值范围。

---

## 术语预检

| 术语 | 英文 | 一句话解释 |
|------|------|-----------|
| **TTFT** | Time To First Token | 从发送请求到收到第一个 token 的延迟，受 Prefill 速度影响最大 |
| **TPOT** | Time Per Output Token | 第一个 token 之后每个后续 token 的平均生成间隔，受 decode 阶段 GPU 显存带宽影响 |
| **Throughput** | Throughput | 单位时间内产生的总 token 数（tokens/s），衡量系统整体产出能力 |
| **GPU Utilization** | GPU-Util | nvidia-smi 显示的 GPU 计算核心使用率。注意：Decode 阶段 20-40% 属于正常（受限于显存带宽而非算力） |
| **Compute-Bound / Memory-Bound** | 计算瓶颈 / 访存瓶颈 | Prefill 通常是 Compute-Bound（GPU 算力是瓶颈）；Decode 通常是 Memory-Bound（显存带宽是瓶颈）。选错优化方向 = 白费力气 |
| **Baseline (基线)** | Baseline | 调优前的默认配置基准数据。所有后续实验都必须和基线对比。没有基线 = 没有调优 |

---

## 目录

1. [核心心法](#1-核心心法)
2. [建立基线：基准测试与记录](#2-建立基线)
3. [瓶颈识别方法论](#3-瓶颈识别方法论)
4. [调优清单：一次一个，逐个击破](#4-调优清单)
5. [生产配置示例（7B~70B）](#5-生产配置示例)
6. [调优日志模板](#6-调优日志模板)
7. [常见错误与修复](#7-常见错误与修复)
8. [附录：快速参考卡片](#8-附录)

---

## 1. 核心心法

### 1.1 调优金律

```
┌─────────────────────────────────────────────────────────────────┐
│                     vLLM 调优三定律                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  定律一：没有基线，就没有调优                                      │
│    每次改动前后必须 benchmark，记录 TTFT / TPOT / Throughput      │
│                                                                 │
│  定律二：一次只改一个参数                                          │
│    改了 max_num_seqs 又改 quantization，你不知道是谁起作用         │
│                                                                 │
│  定律三：瓶颈决定优化方向                                          │
│    compute-bound → batch/并行/量化 才有用                          │
│    memory-bound  → 增加 batch 反而让延迟变差                       │
│    scheduling    → 调 chunked prefill / prefix cache              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 调优决策流程图

```
                            ┌──────────────┐
                            │  部署基线版本  │
                            │  (默认参数)    │
                            └──────┬───────┘
                                   │
                                   ▼
                        ┌────────────────────┐
                        │  跑基准 benchmark   │
                        │  记录 TTFT/TPOT/   │
                        │  Throughput/GPU Util│
                        └────────┬───────────┘
                                 │
                                 ▼
                        ┌────────────────────┐
                        │  GPU 利用率 > 80%?  │
                        └────────┬───────────┘
                                 │
                    ┌────────────┼────────────┐
                    │ YES        │            │ NO
                    ▼            │            ▼
          ┌──────────────┐      │    ┌──────────────┐
          │ compute-bound │      │    │ 利用率低, 但  │
          │ → 量化        │      │    │ nvidia-smi   │
          │ → 增大 batch  │      │    │ 显示高吞吐?   │
          │ → TP/DP       │      │    └──────┬───────┘
          └──────────────┘      │            │
                                │   ┌────────┼────────┐
                                │   │ YES    │        │ NO
                                │   ▼        │        ▼
                                │ ┌──────┐   │  ┌──────────┐
                                │ │memory-│   │  │overhead/ │
                                │ │bound  │   │  │scheduling│
                                │ │→正常  │   │  │→CUDA Grph│
                                │ │→减ctx │   │  │→调调度器 │
                                │ └──────┘   │  └──────────┘
                                │            │
                                ▼            ▼
                    ┌────────────────────────────┐
                    │ 逐项调优 (一次一个)           │
                    │ 每项改完后: 重跑 benchmark    │
                    │ 记录 → 对比 → 决定保留/回退   │
                    └────────────┬───────────────┘
                                 │
                                 ▼
                        ┌────────────────┐
                        │ 稳定 30 分钟后  │
                        │ 封版上线        │
                        └────────────────┘
```

### 1.3 核心指标速查

| 指标 | 英文 | 含义 | 优化方向 |
|------|------|------|---------|
| 首 token 延迟 | TTFT | 用户发送请求到收到第一个 token | 越小越好，受 Prefill 影响 |
| 每 token 生成时间 | TPOT | 第一个 token 之后每个 token 的间隔 | 越小越好，受 Decode 影响 |
| 吞吐 | Throughput | 每秒产出的 token 总数 | 越大越好 |
| 并发 | QPS | 每秒完成的请求数 | 越大越好 |
| GPU 利用率 | GPU-Util | nvidia-smi 显示的百分比 | Decode 阶段 20-40% 正常 |

---

## 2. 建立基线

### 2.1 部署基线服务

选择一组默认参数作为基线。基线必须稳定、可复现。

```bash
# ============================================
# 步骤一：启动基线 vLLM 服务
# ============================================

# 以 Qwen2.5-7B-Instruct 为例，FP16 精度，单卡 A800
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 \
    --port 8000 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 8192 \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    --disable-log-requests \
    2>&1 | tee baseline_server.log &

# 等待服务就绪
until curl -s http://localhost:8000/health > /dev/null; do
    echo "等待服务启动..."
    sleep 2
done
echo "服务已就绪"

# 记录启动时的关键信息
echo "===== 基线配置 =====" > baseline_config.txt
echo "模型: Qwen2.5-7B-Instruct, FP16" >> baseline_config.txt
echo "GPU: 1x A800 80GB" >> baseline_config.txt
echo "max-model-len: 4096" >> baseline_config.txt
echo "max-num-seqs: 64" >> baseline_config.txt
echo "max-num-batched-tokens: 8192" >> baseline_config.txt
echo "gpu-memory-utilization: 0.90" >> baseline_config.txt
echo "enforce-eager: true (CUDA graphs 关闭)" >> baseline_config.txt
echo "启动时间: $(date)" >> baseline_config.txt
```

### 2.2 使用官方 benchmark_serving.py 压测

vLLM 源码自带 `benchmarks/benchmark_serving.py`，是官方推荐的压测工具。

```bash
# ============================================
# 步骤二：用官方脚本跑基线 benchmark
# ============================================

# 1. 同步请求（测单请求延迟）
python3 -m vllm.benchmarks.benchmark_serving \
    --backend vllm \
    --model Qwen2.5-7B-Instruct \
    --dataset-name sharegpt \
    --dataset-path /data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json \
    --num-prompts 200 \
    --request-rate 1.0 \
    --save-result \
    --result-dir ./baseline_results \
    --result-filename baseline_sync.json \
    2>&1 | tee baseline_bench.log

# 2. 逐步加压（找到吞吐上界）
for rate in 1 2 4 8 16 32 inf; do
    echo "=== 测试 request-rate=$rate ==="
    python3 -m vllm.benchmarks.benchmark_serving \
        --backend vllm \
        --model Qwen2.5-7B-Instruct \
        --dataset-name sharegpt \
        --dataset-path /data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json \
        --num-prompts 200 \
        --request-rate $rate \
        --save-result \
        --result-dir ./baseline_results \
        --result-filename "baseline_rate_${rate}.json" \
        2>&1 | tee -a baseline_bench.log
done
```

### 2.3 使用官方 benchmark_throughput.py 测吞吐上限

```bash
# ============================================
# 步骤三：离线吞吐测试（不通过 API，直接测引擎上限）
# ============================================

# 测最理想情况：无限 prompt，无限 batch
python3 -m vllm.benchmarks.benchmark_throughput \
    --model /models/Qwen2.5-7B-Instruct \
    --input-len 1024 \
    --output-len 128 \
    --num-prompts 1000 \
    --enforce-eager \
    --max-num-batched-tokens 8192 \
    2>&1 | tee baseline_throughput.log

# 测不同输入长度下的吞吐变化
for input_len in 256 512 1024 2048 4096; do
    echo "=== input_len=$input_len ==="
    python3 -m vllm.benchmarks.benchmark_throughput \
        --model /models/Qwen2.5-7B-Instruct \
        --input-len $input_len \
        --output-len 128 \
        --num-prompts 500 \
        --enforce-eager \
        2>&1 | tee -a baseline_throughput.log
done
```

### 2.4 用自定义 benchmark 脚本测端到端

```bash
# ============================================
# 步骤四：自定义脚本（更接近真实场景）
# ============================================

# 单轮对话压测
bash /data/chendongpo/agent_projects/vllm_projects/scripts/benchmark.sh localhost 8000 Qwen2.5-7B-Instruct 100 4

# 不同并发下的行为
for concurrency in 1 2 4 8 16 32 64; do
    echo "=== Concurrency: $concurrency ==="
    bash /data/chendongpo/agent_projects/vllm_projects/scripts/benchmark.sh localhost 8000 Qwen2.5-7B-Instruct 100 $concurrency \
        2>&1 | tee -a baseline_concurrency.log
done
```

### 2.5 记录基线结果

每次基线测试完成后，立即填写基线结果表。这是后续所有对比的基础。

```bash
# 从 benchmark 日志中提取关键数值
echo "========== 基线结果汇总 =========="
echo "模型: Qwen2.5-7B-Instruct (FP16)"
echo "硬件: 1x A800 80GB"
echo ""
echo "--- 离线吞吐 ---"
grep -E "Throughput|tokens/s" baseline_throughput.log
echo ""
echo "--- 在线服务 (rate=inf) ---"
grep -A 20 "request-rate=inf" baseline_bench.log | grep -E "Throughput|P50|P95|P99"
echo ""
echo "--- GPU 状态 ---"
nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv
```

基线条目格式：

```
| 实验ID | 日期       | 变更          | TTFT P50 | TTFT P95 | TPOT P50 | TPOT P95 | Throughput | GPU Util | 备注     |
|--------|-----------|---------------|----------|----------|----------|----------|------------|----------|---------|
| B00    | 2026-07-20| 基线(默认参数) | 156ms    | 298ms    | 12ms     | 21ms     | 1250 tok/s | 60%      | CPU-GPU gap 大 |
```

---

## 3. 瓶颈识别方法论

### 3.1 三种瓶颈的判断矩阵

```
                    观察指标: nvidia-smi 看到什么？
                              │
          ┌───────────────────┼───────────────────┐
          │ GPU-Util 高        │ GPU-Util 中低      │ GPU-Util 低
          │ (>80%)            │ (30-60%)          │ (<20%)
          ▼                   ▼                   ▼
      ┌─────────┐       ┌─────────┐         ┌─────────┐
      │Compute  │       │Memory   │         │Scheduling│
      │Bound    │       │Bound    │         │Bound     │
      └────┬────┘       └────┬────┘         └────┬────┘
           │                 │                    │
    特征:   │           特征: │              特征: │
    ·SM 接近满载  │       ·显存带宽接近上限  │  ·kernel launch gap 大
    ·Tensor Core忙│       ·DRAM throughput >80% │  ·CPU 端处理慢
    ·batch 增大   │       ·batch 增大后延迟变差  │  ·nsys 看到大量空隙
    后吞吐线性增长│       ·nvidia-smi dmon 看     │  ·decode kernel 间隔长
           │      │    到大量 mem read/write    │
           ▼      │              │               │
    优化方向:      │        优化方向: │         优化方向:
    ·量化(用低bit) │       ·量化KV Cache          │  ·CUDA Graph
    ·增大batch    │       ·减小 max-model-len    │  ·torch.compile
    ·TP/DP        │       ·prefix caching        │  ·chunked prefill
    ·FlashInfer   │       ·减小并发               │  ·减少CPU端处理
```

### 3.2 Compute-Bound 诊断

Compute-bound 意味着 GPU 计算核心在满负荷运转，性能受限于算力。

```bash
# ============================================
# Compute-Bound 诊断命令集
# ============================================

# 1. nvidia-smi 持续监控
nvidia-smi dmon -s pucv -d 1 -c 60
# 输出示例 (compute-bound):
#   gpu   pwr  gtemp  mtemp    sm   mem   enc   dec
#    0    285     62     38    95    65     0     0
#                                    ^^
#                                   SM 利用率 95%
# → Compute-Bound! GPU 满负荷

# 2. 查看 SM 时钟频率 (是否跑满)
nvidia-smi -q -d CLOCK | grep -A5 "SM"
# 期望: SM clock 接近额定最大值 (A800 ≈ 1410 MHz)

# 3. Nsight Compute 确认 compute vs memory 占比
ncu --metrics \
    sm__throughput.avg.pct_of_peak_sustained_elapsed,\
    dram__throughput.avg.pct_of_peak_sustained_elapsed \
    --kernel-name regex:.*gemm.* \
    python3 -c "
import torch
a = torch.randn(4096, 4096, dtype=torch.float16, device='cuda')
b = torch.randn(4096, 4096, dtype=torch.float16, device='cuda')
for _ in range(100):
    torch.mm(a, b)
torch.cuda.synchronize()
"
# 看 sm__throughput: 如果 > 80% → compute-bound
# 看 dram__throughput: 如果 > 80% → memory-bound

# 4. 压力测试确认
# 增大 batch 后吞吐成比例增长 → compute-bound
# 增大 batch 后吞吐几乎不变 → memory-bound
```

Compute-Bound 的典型日志特征：

```
# vLLM 日志中：
INFO:     GPU blocks: 12345, CPU blocks: 0
# blocks 充足，说明显存不是瓶颈

# benchmark 中：
Throughput: 2450.3 tokens/s  ← 已经比较高
TTFT P50: 45ms               ← Prefill 快 (compute 够)
TPOT P50: 8ms                ← Decode 快
```

### 3.3 Memory-Bound 诊断

Memory-bound 意味着 GPU 时间花在等待 HBM 数据上。这在 Decode 阶段是正常的。

```bash
# ============================================
# Memory-Bound 诊断命令集
# ============================================

# 1. 显存带宽利用率
nvidia-smi dmon -s pucv -d 1 -c 60
# 典型 memory-bound 输出:
#   gpu   pwr  gtemp  mtemp    sm   mem   enc   dec
#    0    210     58     35    35    89     0     0
#                              ^^    ^^
#                           SM 低  显存带宽高
# → Memory-Bound! GPU 在等显存数据

# 2. 显存使用详细分解
echo "=== 显存使用分解 ==="
nvidia-smi --query-gpu=memory.total,memory.used,memory.free --format=csv

# 3. 显存分配分解 (手动计算)
python3 -c "
model_params = 7e9       # Qwen2.5-7B
bytes_per_param = 2      # FP16
model_mem_gb = model_params * bytes_per_param / 1e9
print(f'模型参数: {model_mem_gb:.1f} GB')

# KV Cache 大约占 (粗略)
# 对于 Qwen2.5-7B: 每 token 约 0.5 MB KV Cache
kv_per_token_mb = 0.5
kv_cache_gb = 730848 * kv_per_token_mb / 1024  # 假设 730848 tokens
print(f'KV Cache: {kv_cache_gb:.1f} GB')

# 框架开销
total_used = 65  # 从 nvidia-smi
other_gb = total_used - model_mem_gb - kv_cache_gb
print(f'框架开销+激活: {other_gb:.1f} GB')
print(f'总计: {total_used:.1f} GB / 80 GB')
"

# 4. nsys 时间线分析
nsys profile --trace=cuda --output=mem_bound_profile \
    python3 my_vllm_bench.py 2>/dev/null
# 在 Nsight Systems GUI 中:
# → 如果 decode kernel 很短 (5-20μs) 且连续
# → kernel 之间没有大的 gap
# → GPU 利用率低但 kernel 不闲置
# = Memory-bound (正常!)

# 5. 检查是否有 swap (显存不够用，被换出)
grep -i "swap" vllm_server.log
# 如果看到:
#   WARNING: Swapped X blocks
# → KV Cache 不够用了，请求被 swap 到 CPU
# → 延迟会暴增 (CPU RAM 比 HBM 慢 10-30x)
```

### 3.4 Scheduling-Bound 诊断

Scheduling-bound 意味着 GPU 有空闲，但不是因为 memory-bound，而是因为 CPU 端来不及提交 kernel。

```bash
# ============================================
# Scheduling-Bound 诊断命令集
# ============================================

# 1. nsys profile 看 kernel launch gap
nsys profile \
    --trace=cuda,osrt \
    --output=sched_profile \
    python3 my_vllm_inference_loop.py 2>/dev/null

# 在时间线中观察:
#   正常: [═══Kernel═══] [═══Kernel═══] [═══Kernel═══]
#   异常: [═══Kernel═══]  [gap 20μs]  [═══Kernel═══]  [gap 15μs]
#                            ^^^^               ^^^^
#                         这是 launch overhead → Scheduling-Bound

# 2. 日志特征
grep -i "prefill\|decode" vllm_server.log | tail -20
# 如果看到:
#   Prefill batch: 1 seqs, 2048 tokens   ← batch 很小
#   Decode batch: 3 seqs                  ← 并发很低
# → 可能是请求量不够，或者调度器没能攒够 batch

# 3. benchmark 时监控 waiting queue
# 在 vLLM 的 Prometheus metrics 中查看:
curl -s http://localhost:8000/metrics | grep -E "vllm:num_requests"
#   vllm:num_requests_running{model_name="..."} 4.0
#   vllm:num_requests_waiting{model_name="..."} 15.0
#   vllm:num_requests_swapped{model_name="..."} 0.0
# → waiting 远大于 running → 调度器是瓶颈
```

### 3.5 显存使用全面分析

```bash
# ============================================
# 显存使用分析命令集
# ============================================

# 1. 查看 vLLM 分配的 KV Cache blocks
curl -s http://localhost:8000/metrics | grep -E "vllm:gpu_cache"

# 典型输出:
# vllm:gpu_cache_usage_perc{model_name="..."} 0.72
# → KV Cache 用了 72%

# 2. 计算 KV Cache 总容量
echo "KV Cache blocks 总数:"
curl -s http://localhost:8000/metrics | grep "vllm:num_gpu_blocks_total"
# vllm:num_gpu_blocks_total{model_name="..."} 45678.0

# 每个 block = block_size 个 token 的 KV Cache
# 默认 block_size = 16
# KV Cache 可容纳: 45678 * 16 = 730,848 tokens (所有并发序列之和)

# 3. 检查 block 利用率
curl -s http://localhost:8000/metrics | grep "vllm:num_gpu_blocks"
# 如果 used / total 比例 < 50% 但已经报 OOM
# → 碎片化严重 → 减小 block_size 或增大 gpu_memory_utilization
```

### 3.6 显存碎片诊断

```bash
# ============================================
# 检查显存碎片化
# ============================================

# 在 vLLM 日志中找:
grep -E "block|fragment" vllm_server.log

# 不好的信号:
#   "Cannot allocate X blocks for prefill"  ← block 分配失败
#   "gpu_cache_usage_perc = 0.60" 但 OOM   ← 碎片化严重
#   block_size 太大导致无法利用剩余显存
```

---

## 4. 调优清单

以下每一项都遵循铁律：**改参数 → benchmark → 记录 → 对比基线 → 决定保留/回退**。

在开始之前，先准备调优工作区：

```bash
# 创建调优工作目录
mkdir -p tuning_results
echo "实验ID,日期,变更参数,原值,新值,TTFT_P50_ms,TTFT_P95_ms,TPOT_P50_ms,TPOT_P95_ms,Throughput_tokens_s,QPS,GPU_Util_percent,备注" \
    > tuning_results/tuning_log.csv

# 快速 GPU 状态检查函数
check_gpu() {
    nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total,temperature.gpu \
        --format=csv,noheader
}
```

---

### 4a. 量化 (Quantization): FP16 → AWQ / GPTQ / FP8

**原理**：模型参数用低精度存储，加载时反量化或用专用 kernel 直接计算。

```
显存压缩比:
  FP16 (基线):  ████████████████████████████ 100% (14 GB for 7B)
  FP8:          ██████████████ 50% (7 GB)
  INT4 AWQ/GPTQ: ███████ 25% (3.5 GB)
```

**命令**：

```bash
# ============================================
# 4a.1 AWQ 量化模型部署
# ============================================
# 首先要确保有 AWQ 量化好的模型，如果没有需要先下载
# huggingface-cli download Qwen/Qwen2.5-7B-Instruct-AWQ --local-dir /models/Qwen2.5-7B-AWQ

vllm serve /models/Qwen2.5-7B-AWQ \
    --host 0.0.0.0 \
    --port 8000 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --quantization awq \
    --gpu-memory-utilization 0.90 \
    2>&1 | tee tuning_results/awq_server.log &

# 压测
python3 -m vllm.benchmarks.benchmark_serving \
    --backend vllm \
    --model Qwen2.5-7B-AWQ \
    --dataset-name sharegpt \
    --dataset-path /data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json \
    --num-prompts 200 \
    --request-rate inf \
    --save-result \
    --result-dir ./tuning_results \
    --result-filename awq_result.json \
    2>&1 | tee tuning_results/awq_bench.log

# ============================================
# 4a.2 GPTQ (Marlin kernel) 量化模型部署
# ============================================
# Marlin 是专门针对 INT4 GPTQ 优化过的 kernel，比普通 GPTQ 快 30-50%

vllm serve /models/Qwen2.5-7B-GPTQ-Int4 \
    --host 0.0.0.0 \
    --port 8001 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --quantization gptq_marlin \
    --gpu-memory-utilization 0.90 \
    2>&1 | tee tuning_results/gptq_server.log &

# 压测
python3 -m vllm.benchmarks.benchmark_serving \
    --backend vllm \
    --model Qwen2.5-7B-GPTQ-Int4 \
    --port 8001 \
    --dataset-name sharegpt \
    --dataset-path /data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json \
    --num-prompts 200 \
    --request-rate inf \
    --save-result \
    --result-dir ./tuning_results \
    --result-filename gptq_result.json \
    2>&1 | tee tuning_results/gptq_bench.log

# ============================================
# 4a.3 FP8 量化部署（需要 H100/H200 或 Ada 架构 GPU）
# ============================================
vllm serve /models/Qwen2.5-7B-FP8 \
    --host 0.0.0.0 \
    --port 8002 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --quantization fp8 \
    --gpu-memory-utilization 0.90 \
    2>&1 | tee tuning_results/fp8_server.log &

# 压测同上...
```

**量化方法对比总结**：

```
               精度损失    显存节省    速度提升    硬件要求       适用场景
               ────────    ────────    ────────    ────────       ────────
FP8 (W8A8)    <0.1%       50%         +60-100%    H100/Ada      延迟敏感，显存够
AWQ INT4      <1%         75%         +30-50%     所有GPU        通用，推荐
GPTQ INT4     <1%         75%         +30-50%     所有GPU        通用
GPTQ Marlin   <1%         75%         +50-80%     Ampere+       追求速度首选 (本机在用)
```

**预期改进**：

| 模型 | FP16 显存 | INT4 显存 | 典型吞吐提升 | 精度风险 |
|------|----------|----------|-------------|---------|
| 7B | 14 GB | 3.5 GB | 1.2-1.5x | 数学推理可能 1-2% 下降 |
| 13B | 26 GB | 6.5 GB | 1.3-1.5x | 同上 |
| 70B | 140 GB | 35 GB | 可单卡运行 | 长上下文可能退化 |

**风险与检查**：

```bash
# 量化后的精度检查
python3 -c "
from openai import OpenAI
client = OpenAI(base_url='http://localhost:8000/v1', api_key='dummy')

# 测试简单的数学推理
resp = client.chat.completions.create(
    model='Qwen2.5-7B-AWQ',
    messages=[{'role': 'user', 'content': '23 * 47 = ?'}]
)
print(resp.choices[0].message.content)
# 期望: 1081 (如果不正确说明精度有问题)

# 对比 FP16 基线的输出质量
# 用同一组 prompt 让 FP16 和 INT4 都跑一遍，人工对比
"
```

---

### 4b. Batch Size (max_num_seqs) 扫描

**原理**：更大的 batch 让 GPU 同时处理更多序列，提高利用率，但超过一定程度后延迟收益递减。

```bash
# ============================================
# 4b: max_num_seqs 扫描
# ============================================

for max_seqs in 8 16 32 64 128 256; do
    echo "=========================================="
    echo "测试 max_num_seqs = $max_seqs"
    echo "=========================================="

    # 1. 杀掉旧服务
    pkill -f "vllm serve" 2>/dev/null || true
    sleep 3

    # 2. 启动新配置
    vllm serve /models/Qwen2.5-7B-Instruct \
        --host 0.0.0.0 \
        --port 8000 \
        --max-model-len 4096 \
        --max-num-seqs $max_seqs \
        --max-num-batched-tokens 8192 \
        --gpu-memory-utilization 0.90 \
        --enforce-eager \
        2>&1 | tee "tuning_results/seqs_${max_seqs}_server.log" &

    # 3. 等待就绪
    until curl -s http://localhost:8000/health > /dev/null; do sleep 2; done

    # 4. 压测
    python3 -m vllm.benchmarks.benchmark_serving \
        --backend vllm \
        --model Qwen2.5-7B-Instruct \
        --dataset-name sharegpt \
        --dataset-path /data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json \
        --num-prompts 200 \
        --request-rate inf \
        --save-result \
        --result-dir ./tuning_results \
        --result-filename "seqs_${max_seqs}_result.json" \
        2>&1 | tee "tuning_results/seqs_${max_seqs}_bench.log"

    # 5. 记录 GPU 状态
    check_gpu >> "tuning_results/seqs_${max_seqs}_gpu.log"
done

echo "扫描完成！查看结果:"
echo "tuning_results/seqs_*_bench.log"
```

**理想的结果曲线**：

```
Throughput
(tokens/s)  │
            │
  2400 ─    │                              ╭─────── 平台期
            │                          ╭───╯
  2000 ─    │                     ╭────╯
            │                ╭───╯
  1600 ─    │          ╭────╯
            │     ╭───╯
  1200 ─    │╭──╯
            │╯
   800 ─    │
            │
            └────┬────┬────┬────┬────┬────┬────
                 8    16   32   64   96   128  256   max_num_seqs
                                         ^
                                     sweet spot:
                                 最大吞吐且延迟可接受
```

**观察要点**：

```
max_num_seqs=8:
  TTFT 很低, TPOT 很低 → 用户体验好
  Throughput 低 → GPU 吃不饱
  GPU Util ≈ 20% → 资源浪费

max_num_seqs=64:
  TTFT 中, TPOT 中
  Throughput 接近峰值
  GPU Util ≈ 60-70%

max_num_seqs=256:
  Throughput 可能更高或持平
  TTFT 显著增加 → 用户等待时间长
  TPOT 显著增加 → 生成速度变慢
  → 如果在线服务，这个值太大了
```

**决策规则**：

```
在线服务 (延迟敏感): 选 Throughput 达到峰值 80% 的最小 max_num_seqs
离线批处理 (吞吐优先): 选 Throughput 最大的 max_num_seqs
折中方案: 选 TTFT P95 < 500ms 能支持的最大 max_num_seqs
```

---

### 4c. Token Budget (max_num_batched_tokens) 扫描

**原理**：控制每次 iteration 处理的 token 数量上限。影响 Prefill 的吞吐和单个请求的延迟。

```
max_num_batched_tokens 的作用:
  每次 GPU forward 最多处理这么多 token
  Prefill tokens + Decode tokens ≤ max_num_batched_tokens

大值:
  一次能处理更多 Prefill token → 长 prompt TTFT 更低
  一次能处理更多 Decode 序列 → 并发更高
  → 但峰值显存占用更大

小值:
  Prefill 被切分更细 → 长 prompt TTFT 变高
  但对已有 Decode 序列的干扰小 → TPOT 更稳定
  → 适合需要稳定 TPOT 的场景
```

**扫描命令**：

```bash
# ============================================
# 4c: max_num_batched_tokens 扫描
# ============================================

for batched_tokens in 2048 4096 8192 16384 32768; do
    echo "=== max_num_batched_tokens = $batched_tokens ==="

    pkill -f "vllm serve" 2>/dev/null || true
    sleep 3

    vllm serve /models/Qwen2.5-7B-Instruct \
        --host 0.0.0.0 \
        --port 8000 \
        --max-model-len 4096 \
        --max-num-seqs 128 \
        --max-num-batched-tokens $batched_tokens \
        --gpu-memory-utilization 0.90 \
        --enforce-eager \
        2>&1 | tee "tuning_results/tokens_${batched_tokens}_server.log" &

    until curl -s http://localhost:8000/health > /dev/null; do sleep 2; done

    python3 -m vllm.benchmarks.benchmark_serving \
        --backend vllm \
        --model Qwen2.5-7B-Instruct \
        --dataset-name sharegpt \
        --dataset-path /data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json \
        --num-prompts 200 \
        --request-rate inf \
        --save-result \
        --result-dir ./tuning_results \
        --result-filename "tokens_${batched_tokens}_result.json" \
        2>&1 | tee "tuning_results/tokens_${batched_tokens}_bench.log"
done
```

**经验公式**：

```
max_num_batched_tokens ≥ max_num_seqs × 2
# 为什么 ×2? 保证有至少一个 Prefill 请求的空间
# 如果都是 Decode: max_num_seqs 个 token (每个序列 1 token)
# 如果混有 Prefill: 需要更多空间

推荐:
  短 prompt (<512 tokens):
    max_num_batched_tokens = 4096 或 8192

  中等 prompt (512-2048):
    max_num_batched_tokens = 8192 或 16384

  长 prompt (>2048):
    max_num_batched_tokens = 16384 或更高
    但要同时开启 chunked prefill
```

---

### 4d. Context Length (max_model_len) 精确设置

**原理**：`max_model_len` 决定了 KV Cache 预分配的最大序列长度。设得比实际需要大就是浪费显存。

```bash
# ============================================
# 4d: 计算显存浪费
# ============================================

python3 -c "
# 显存浪费计算器
model = 'Qwen2.5-7B'
num_layers = 28
num_kv_heads = 4
head_dim = 128
bytes_per_elem = 2  # FP16
gpu_memory_utilization = 0.90
total_gpu_mem_gb = 80

def kv_cache_per_seq(seq_len):
    # 每层 Key + Value
    per_layer = 2 * num_kv_heads * head_dim * seq_len * bytes_per_elem
    return per_layer * num_layers / 1e9  # GB

print('max_model_len 对 KV Cache 的影响:')
print('-' * 55)
print(f'{\"max_model_len\":<20} {\"每序列 KV Cache\":<18} {\"256 序列总计\":<15}')
print('-' * 55)
for seq_len in [1024, 2048, 4096, 8192, 16384, 32768]:
    per_seq = kv_cache_per_seq(seq_len)
    total_256 = per_seq * 256
    print(f'{seq_len:<20} {per_seq:<16.2f} GB {total_256:<13.1f} GB')

print()
print('如果你的实际 prompt 最长 = 4096 token:')
print(f'  设为 max_model_len=4096: 每序列 {kv_cache_per_seq(4096):.2f} GB')
print(f'  设为 max_model_len=32768: 每序列 {kv_cache_per_seq(32768):.2f} GB')
print(f'  浪费: {(kv_cache_per_seq(32768) - kv_cache_per_seq(4096)):.2f} GB / 序列')
print(f'  256 序列总计浪费: {(kv_cache_per_seq(32768) - kv_cache_per_seq(4096)) * 256:.1f} GB')
print(f'  这可能导致少跑 {int((kv_cache_per_seq(32768) - kv_cache_per_seq(4096)) * 256 / kv_cache_per_seq(4096))} 个并发序列')
"
```

**如何确定实际需要的 max_model_len**：

```bash
# ============================================
# 分析你的数据集的真实 context 长度
# ============================================

# 如果你用 ShareGPT 格式的数据:
python3 -c "
import json
import numpy as np

with open('/data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json') as f:
    data = json.load(f)

# 用 tokenizer 统计实际 token 数 (这里用近似: 1 token ≈ 0.75 中文字符)
lengths = []
for item in data[:1000]:  # 采样 1000 条
    turns = item.get('conversations', [])
    total_chars = sum(len(t.get('value', '')) for t in turns)
    lengths.append(total_chars * 0.75)  # 粗略估计 token 数

lengths = np.array(lengths)
print(f'样本数: {len(lengths)}')
print(f'平均长度: {lengths.mean():.0f} tokens')
print(f'P50: {np.percentile(lengths, 50):.0f} tokens')
print(f'P90: {np.percentile(lengths, 90):.0f} tokens')
print(f'P95: {np.percentile(lengths, 95):.0f} tokens')
print(f'P99: {np.percentile(lengths, 99):.0f} tokens')
print(f'最大值: {lengths.max():.0f} tokens')
print()
print(f'建议 max_model_len: {int(np.percentile(lengths, 99) * 1.2)} (P99 * 1.2 留余量)')
"
```

**规则**：

```
max_model_len = P99实际长度 × 1.2 (留 20% 余量)
不要留默认的 32768！除非你真的需要长上下文。

如果业务有极少超长请求 (P99.9):
  单独处理 → 用更长的超时、专门的实例
  不要让 99% 的请求为 1% 的极端情况买单
```

---

### 4e. Tensor Parallelism (TP)

**原理**：把模型权重切分到多张 GPU，每张 GPU 只计算一部分，通过集合通信同步结果。

```
TP=1 (单卡):
┌───────────────┐
│    GPU 0      │
│  完整模型权重   │
│  ┌───────────┐│
│  │Layer 0-27 ││   → 全部在 GPU0 上计算
│  │Attention  ││
│  │MLP        ││
│  └───────────┘│
└───────────────┘

TP=2 (双卡):
┌───────────────┐     ┌───────────────┐
│    GPU 0      │     │    GPU 1      │
│  权重的一半     │◄───►│  权重的一半     │
│  ┌───────────┐│     │┌───────────┐  │
│  │列切分 MLP  ││     ││列切分 MLP  │  │
│  │行切分 Attn ││     ││行切分 Attn │  │
│  └───────────┘│     │└───────────┘  │
└───────────────┘     └───────────────┘
   AllReduce 每个 Transformer 层后同步一次
```

**什么时候 TP 有帮助**：

```bash
# ============================================
# 4e: TP 对比测试
# ============================================

# 测试 TP=1 (基线)
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8000 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --tensor-parallel-size 1 \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    2>&1 | tee tuning_results/tp1_server.log &

# 测试 TP=2
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8001 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --tensor-parallel-size 2 \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    2>&1 | tee tuning_results/tp2_server.log &
```

**TP 适用性判断表**：

```
模型大小    TP=1      TP=2            结论
─────────────────────────────────────────────
7B         1250 t/s  800 t/s          TP 有害！通信开销 > 计算收益
13B        720 t/s   1100 t/s         TP 有益 (单卡快满了)
33B        装不下     850 t/s         TP 必要 (单卡装不下)
70B        装不下     550 t/s (TP=2)  TP 必要
70B        装不下     900 t/s (TP=4)  4卡：考虑量化单卡跑

TP 何时带来正收益:
  ✓ 单卡显存放不下模型参数 → 必须 TP
  ✓ 模型 > 30B, 单卡虽然装得下但 KV Cache 很紧张 → TP=2 值得
  ✓ 需要极低延迟 → TP 降低单卡计算量

TP 何时有害:
  ✗ 小模型 (≤13B)，单卡完全够用 → 通信开销白白浪费
  ✗ GPU 间 NVLink 带宽不足 (如用 PCIe 而不是 NVLink)
  ✗ 推理 batch 很小 → 通信延迟占比大
```

**TP 延迟权衡**：

```
TP=1:  TTFT 较低 (没有通信开销)
       TPOT 较低

TP=2:  TTFT 可能更低 (每卡计算量减半)
       TPOT 可能更低
       但每个 Transformer 层后都有 AllReduce 通信
       → 如果模型小，通信时间 > 节省的计算时间 → 负优化
```

---

### 4f. Prefix Caching

**原理**：vLLM 自动检测多个请求的公共前缀，第一个请求计算后缓存 KV，后续请求直接复用。

```
无 Prefix Caching:
  请求 1: [System Prompt: 2000 tokens] [User: 100 tokens] → 计算全部 2100 token 的 KV
  请求 2: [System Prompt: 2000 tokens] [User: 80 tokens]  → 重新计算全部 2080 token 的 KV
  请求 3: [System Prompt: 2000 tokens] [User: 120 tokens] → 重新计算全部 2120 token 的 KV
  → System Prompt 的 2000 token KV 被重复算了 3 次！

有 Prefix Caching:
  请求 1: [System Prompt: 2000 tokens] → 计算并缓存 KV ╮
             [User: 100 tokens] → 只算这 100 token         │
  请求 2: [System Prompt: 2000 tokens] → 命中缓存, 跳过! ←─╯
             [User: 80 tokens] → 只算这 80 token
  请求 3: [System Prompt: 2000 tokens] → 命中缓存, 跳过!
             [User: 120 tokens] → 只算这 120 token
  → System Prompt 只算了 1 次！
```

**命令**：

```bash
# ============================================
# 4f: Prefix Caching 对比
# ============================================

# 对比组 A: 不开启 prefix caching
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8000 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    2>&1 | tee tuning_results/no_prefix_server.log &

# 等就绪后 benchmark (用有公共前缀的数据集)

# 对比组 B: 开启 prefix caching
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8001 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --enable-prefix-caching \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    2>&1 | tee tuning_results/prefix_enabled_server.log &

# 等就绪后 benchmark (同样的数据集)
```

**监控 Prefix Cache 命中率**：

```bash
# ============================================
# Prefix Cache 命中率监控
# ============================================

# vLLM 的 Prometheus metrics
curl -s http://localhost:8000/metrics | grep -E "prefix_cache"

# 典型输出:
# vllm:prefix_cache_queries_total{model_name="..."} 15234.0
# vllm:prefix_cache_hits_total{model_name="..."}   11200.0
# → 命中率 = 11200 / 15234 ≈ 73.5%

# 实时监控命中率:
watch -n 2 "curl -s http://localhost:8000/metrics | grep prefix_cache"
```

**适用场景判断**：

```
适合 Prefix Caching:
  ✓ 系统提示词固定且较长 (>200 tokens)
  ✓ Few-shot 示例每次都一样
  ✓ 多轮对话，每轮都带历史
  ✓ RAG 场景中固定的 prompt 模板

不适合 Prefix Caching:
  ✗ 每次 prompt 都完全不一样 (如翻译任务)
  ✗ 系统提示词很短 (<50 tokens)
  ✗ 显存极度紧张 (prefix cache 额外占显存)
```

---

### 4g. Chunked Prefill

**原理**：把长 prompt 的 Prefill 拆成多个 chunk，穿插在 Decode 之间执行，避免一个长 prompt 阻塞所有请求。

```
未开启 Chunked Prefill (长 prompt 阻塞问题):
  Iter 1: [████████████████ Prefill: 8192 tokens ████████████████]  ← 耗时 50ms
            其他 Decode 请求全部排队等待 50ms → TTFT 暴增
  Iter 2: [Decode batch: 64 seqs]

开启 Chunked Prefill:
  Iter 1: [████ Prefill chunk 0: 2048 tokens ████] [Decode: 60 seqs]
  Iter 2: [████ Prefill chunk 1: 2048 tokens ████] [Decode: 62 seqs]
  Iter 3: [████ Prefill chunk 2: 2048 tokens ████] [Decode: 63 seqs]
  Iter 4: [████ Prefill chunk 3: 2048 tokens ████] [Decode: 64 seqs]
  → 每次只阻塞 12.5ms，Decode 依然在跑
```

**命令**：

```bash
# ============================================
# 4g: Chunked Prefill 对比
# ============================================

# 对比组 A: 不开启 chunked prefill (只能靠 max-num-batched-tokens 限制)
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8000 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 8192 \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    2>&1 | tee tuning_results/no_chunked_server.log &

# 对比组 B: 开启 chunked prefill
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8001 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 8192 \
    --enable-chunked-prefill \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    2>&1 | tee tuning_results/chunked_server.log &
```

**Chunked Prefill 效果分析**：

```
                    不开 Chunked           开 Chunked
                    ─────────────          ──────────
TTFT P50 (短prompt):  150ms                150ms (无变化)
TTFT P95 (短prompt):  220ms                225ms (略高, 正常)
TTFT P95 (长prompt):  1200ms               450ms (大幅改善!)
TPOT P50:             8ms                  9ms (略有影响)
Throughput:           1250 t/s             1220 t/s (几乎不变)

结论: Chunked Prefill 主要改善 P95/P99 延迟，对平均吞吐影响很小。
      适合有混合长短 prompt 的场景。
```

**与 max_num_batched_tokens 的关系**：

```
Chunked Prefill 的 chunk_size = max_num_batched_tokens - running_seqs
                               ─────────────────────────────────
                                每次 Iteration 留给 Prefill 的 token 预算

如果 max_num_batched_tokens = 8192, running_seqs = 60:
  Prefill 每次最多处理 8192 - 60 = 8132 token

如果 max_num_batched_tokens 太小 (如 2048):
  即使开了 Chunked Prefill, 每个 chunk 也太小
  → 拆分太细, overhead 变大
```

---

### 4h. CUDA Graphs

**原理**：CUDA Graphs 把一组 GPU kernel 调用预先录制为 graph，后续重放时 CPU 只需一次调用，消除 kernel launch overhead。

```
enforce_eager (无 CUDA Graph):
  CPU: [launch][launch][launch][launch][launch][launch]...
        每个 kernel launch 需要 5-10μs CPU 时间
  GPU: [══Kernel══] [gap] [══Kernel══] [gap] [══Kernel══]...
        50% 时间在等 CPU launch → 浪费!

CUDA Graph 开启:
  CPU: [Capture Graph once] → [Replay Graph] → [Replay] → [Replay]
        只有 1 次 launch!
  GPU: [══Kernel 1══][══Kernel 2══][══Kernel 3══][══Kernel 4══]...
        没有 gap, 连续执行
```

**命令**：

```bash
# ============================================
# 4h: CUDA Graphs 对比
# ============================================

# 对比组 A: enforce_eager (CUDA Graphs 关闭)
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8000 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --gpu-memory-utilization 0.90 \
    --enforce-eager \
    2>&1 | tee tuning_results/eager_server.log &

# 对比组 B: CUDA Graphs 开启 (vLLM 默认, 不需要额外参数)
# 但需要 warmup; vLLM 启动时会自动做
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 --port 8001 \
    --max-model-len 4096 \
    --max-num-seqs 64 \
    --gpu-memory-utilization 0.90 \
    2>&1 | tee tuning_results/cudagraph_server.log &

# 观察 vLLM 启动日志中的 Graph 捕获过程:
# 期望看到:
#   "Graph capturing (batch_size=1)..."
#   "Graph capturing (batch_size=2)..."
#   ...
#   捕获多个 batch size 的 graph, 运行时根据实际 batch 选择
```

**CUDA Graph 限制**：

```
优点:
  + Decode 阶段 TPOT 降低 20-40%
  + GPU 利用率更平滑
  + 对高并发场景改善显著

限制:
  - Graph capture 需要额外显存 (通常 1-2 GB)
  - 首次启动需要 warmup 时间 (几秒钟)
  - batch size 变化时需要不同 graph → 占用更多显存
  - 如果 workload 极其多变 (batch size 频繁变化) → graph 命中率低
  - 某些自定义模型可能不兼容

在以下场景 enforce_eager 可能更好:
  - 显存极度紧张，需要省下 graph 占用的 1-2GB
  - 调试阶段，需要清晰的报错信息
  - 模型计算图极不规则 (如 MoE 动态路由)
```

---

## 5. 生产配置示例

以下是经过实战验证的配置。所有数值为**在线服务**场景下的推荐值。

### 5.1 Qwen2.5-7B 系列

```
┌─────────────────────────────────────────────────────────────┐
│                 Qwen2.5-7B-Instruct                          │
├─────────────────────────────────────────────────────────────┤
│  硬件: 1x A800 80GB                                         │
│  场景: 通用对话, 短 prompt (<2048 tokens)                     │
│  延迟目标: TTFT P95 < 500ms                                  │
└─────────────────────────────────────────────────────────────┘
```

**FP16 配置**：

```bash
vllm serve /models/Qwen2.5-7B-Instruct \
    --host 0.0.0.0 \
    --port 8000 \
    --max-model-len 4096 \
    --max-num-seqs 128 \
    --max-num-batched-tokens 8192 \
    --gpu-memory-utilization 0.92 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_7b_fp16.log
# 预期 Throughput: 1200-1500 tokens/s (FP16)
# 预期 TTFT P50: ~100ms
# 预期 TPOT P50: ~10ms
```

**INT4 (GPTQ Marlin) 配置**：

```bash
vllm serve /models/Qwen2.5-7B-Instruct-GPTQ-Int4 \
    --host 0.0.0.0 \
    --port 8000 \
    --quantization gptq_marlin \
    --max-model-len 4096 \
    --max-num-seqs 128 \
    --max-num-batched-tokens 8192 \
    --gpu-memory-utilization 0.92 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_7b_int4.log
# 预期 Throughput: 1800-2400 tokens/s (Marlin kernel 加速)
# 预期 TTFT P50: ~80ms
# 预期 TPOT P50: ~7ms
# 单卡剩余显存: 约 55-60 GB 可用于更大的 KV Cache 或更多并发
```

### 5.2 Qwen2.5-14B 系列

```
┌─────────────────────────────────────────────────────────────┐
│                 Qwen2.5-14B-Instruct                         │
├─────────────────────────────────────────────────────────────┤
│  硬件选项:                                                    │
│    A: 1x A800 80GB + INT4 量化                               │
│    B: 2x A800 80GB + FP16 (TP=2)                             │
│  场景: 中等复杂度任务, prompt <4096 tokens                     │
└─────────────────────────────────────────────────────────────┘
```

**方案 A: 单卡 INT4**：

```bash
vllm serve /models/Qwen2.5-14B-Instruct-GPTQ-Int4 \
    --host 0.0.0.0 \
    --port 8000 \
    --quantization gptq_marlin \
    --max-model-len 4096 \
    --max-num-seqs 96 \
    --max-num-batched-tokens 8192 \
    --gpu-memory-utilization 0.90 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_14b_int4.log
# 预期 Throughput: 900-1200 tokens/s
# 显存使用: ~30 GB (模型) + ~20 GB (KV Cache) + 开销 ≈ 55 GB
```

**方案 B: 双卡 FP16 TP=2**：

```bash
vllm serve /models/Qwen2.5-14B-Instruct \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 2 \
    --max-model-len 4096 \
    --max-num-seqs 128 \
    --max-num-batched-tokens 8192 \
    --gpu-memory-utilization 0.90 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_14b_tp2.log
# 预期 Throughput: 1100-1400 tokens/s
# 精度无损 (FP16)
# 成本: 2 张卡 vs 方案 A 的 1 张卡
```

### 5.3 Qwen2.5-32B / 33B 系列

```
┌─────────────────────────────────────────────────────────────┐
│                 Qwen2.5-32B-Instruct                         │
├─────────────────────────────────────────────────────────────┤
│  硬件: 1x A800 80GB + INT4 量化 或 2x A800 FP16              │
│  场景: 复杂推理, 代码生成, prompt <8192 tokens                │
└─────────────────────────────────────────────────────────────┘
```

**方案 A: 单卡 INT4 (推荐)**：

```bash
vllm serve /models/Qwen2.5-32B-Instruct-GPTQ-Int4 \
    --host 0.0.0.0 \
    --port 8000 \
    --quantization gptq_marlin \
    --max-model-len 8192 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.90 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_32b_int4.log
# 预期 Throughput: 600-900 tokens/s
# 显存使用: ~16 GB (模型) + ~25 GB (KV Cache@8k, 64 seqs) + 开销 ≈ 48 GB
```

**方案 B: 双卡 FP16 TP=2**：

```bash
vllm serve /models/Qwen2.5-32B-Instruct \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 2 \
    --max-model-len 8192 \
    --max-num-seqs 80 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.90 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_32b_tp2.log
# 预期 Throughput: 750-1000 tokens/s
# 精度最优 (FP16)
# 每张卡 ~32 GB (模型) + ~25 GB (KV Cache) ≈ 57 GB
```

### 5.4 Qwen2.5-72B / 70B 系列

```
┌─────────────────────────────────────────────────────────────┐
│                 Qwen2.5-72B-Instruct                         │
├─────────────────────────────────────────────────────────────┤
│  硬件选项:                                                    │
│    A: 2x A800 80GB + INT4 量化 + TP=2                        │
│    B: 4x A800 80GB + FP16 + TP=4                             │
│  场景: 最强模型, 复杂推理, 长上下文                             │
└─────────────────────────────────────────────────────────────┘
```

**方案 A: 双卡 INT4 TP=2 (推荐，性价比最高)**：

```bash
vllm serve /models/Qwen2.5-72B-Instruct-GPTQ-Int4 \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 2 \
    --quantization gptq_marlin \
    --max-model-len 8192 \
    --max-num-seqs 48 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.90 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_72b_int4_tp2.log
# 预期 Throughput: 300-500 tokens/s
# 每张卡: ~18 GB (模型) + ~30 GB (KV Cache) ≈ 48 GB
# 两张 A800 即可跑 72B 模型, 性价比极高
```

**方案 B: 四卡 FP16 TP=4 (精度优先)**：

```bash
vllm serve /models/Qwen2.5-72B-Instruct \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 4 \
    --max-model-len 8192 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.90 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee production_72b_fp16_tp4.log
# 预期 Throughput: 400-650 tokens/s
# 预期 TTFT P50: ~250ms
# 每张卡: ~35 GB (模型) + ~20 GB (KV Cache) ≈ 55 GB
```

### 5.5 生产配置速查表

```
┌─────────────┬──────────┬──────────┬──────────┬────────────┬───────────────┐
│   模型       │  硬件     │  量化     │  TP      │ max_num_   │ 预期吞吐       │
│             │          │          │          │ seqs       │ (tokens/s)    │
├─────────────┼──────────┼──────────┼──────────┼────────────┼───────────────┤
│ 7B          │ 1x A800  │ FP16     │ 1        │ 128        │ 1200-1500     │
│ 7B          │ 1x A800  │ GPTQ Int4│ 1        │ 128        │ 1800-2400     │
│ 14B         │ 1x A800  │ GPTQ Int4│ 1        │ 96         │ 900-1200      │
│ 14B         │ 2x A800  │ FP16     │ 2        │ 128        │ 1100-1400     │
│ 32B         │ 1x A800  │ GPTQ Int4│ 1        │ 64         │ 600-900       │
│ 32B         │ 2x A800  │ FP16     │ 2        │ 80         │ 750-1000      │
│ 72B         │ 2x A800  │ GPTQ Int4│ 2        │ 48         │ 300-500       │
│ 72B         │ 4x A800  │ FP16     │ 4        │ 64         │ 400-650       │
│ 72B         │ 8x A800  │ FP16     │ 8        │ 128        │ 600-900       │
└─────────────┴──────────┴──────────┴──────────┴────────────┴───────────────┘

注: 所有配置均假设 max-model-len=4096/8192, 启用 prefix caching 和 chunked prefill
```

---

## 6. 调优日志模板

### 6.1 单次实验日志模板

每次参数变更后，填写以下表格：

```markdown
## 实验 #N: [变更简述]

| 字段 | 值 |
|------|-----|
| 实验ID | TUN-006 |
| 日期 | 2026-07-20 14:30 |
| 模型 | Qwen2.5-7B-Instruct-GPTQ-Int4 |
| 硬件 | 1x A800 80GB (GPU 0) |
| 变更类型 | Batch Size 扫描 |
| 变更参数 | max_num_seqs: 64 → 128 |
| 其他参数 | max-model-len=4096, max-num-batched-tokens=8192, quantization=gptq_marlin |

### 服务启动日志 (关键行)

```
INFO: Using Marlin kernel for GPTQ
INFO: # GPU blocks: 50234, # CPU blocks: 4096
INFO: Chunked prefill is enabled
INFO: Prefix caching is enabled
```

### Benchmark 结果

| 指标 | 变更前 (TUN-005) | 变更后 (TUN-006) | 变化 |
|------|-----------------|-----------------|------|
| TTFT P50 | 156ms | 178ms | +14% |
| TTFT P95 | 298ms | 420ms | +41% |
| TTFT P99 | 450ms | 680ms | +51% |
| TPOT P50 | 12ms | 16ms | +33% |
| TPOT P95 | 21ms | 34ms | +62% |
| Throughput | 1250 t/s | 1620 t/s | +30% |
| QPS | 4.2 req/s | 5.8 req/s | +38% |
| GPU Util | 45% | 72% | +27pp |

### 显存状态

| 指标 | 值 |
|------|-----|
| GPU Memory Used | 42.3 GB / 80 GB |
| GPU Cache Usage | 68% |
| GPU Blocks Total | 50234 |
| GPU Blocks Used (avg) | 34159 |

### 结论

- [ ] 保留此变更
- [ ] 回退此变更
- [ ] 需要更多测试

通过: TTFT P95 仍在 500ms 以内，Throughput 提升 30%。保留。
```

### 6.2 完整调优记录表 (CSV 格式)

```csv
实验ID,日期,变更参数,原值,新值,TTFT_P50_ms,TTFT_P95_ms,TTFT_P99_ms,TPOT_P50_ms,TPOT_P95_ms,Throughput_tokens_s,QPS,GPU_Util_pct,GPU_Mem_GB,决策,备注
B00,2026-07-20,基线,默认,默认,156,298,450,12,21,1250,4.2,45,38.5,基线,enforce_eager
T01,2026-07-20,量化,FP16,GPTQ_Int4,132,245,380,9,16,1850,6.5,60,35.2,保留,精度检查通过
T02,2026-07-20,max_num_seqs,64,128,178,420,680,16,34,1620,5.8,72,42.3,保留,TTFT_P95仍在500ms内
T03,2026-07-20,max_num_seqs,128,256,320,890,1500,28,65,1580,5.5,78,56.1,回退,TTFT_P95超标
T04,2026-07-21,prefix_caching,关闭,启用,145,260,400,12,21,1380,5.1,52,40.0,保留,命中率73%提升明显
T05,2026-07-21,chunked_prefill,关闭,启用,148,280,420,13,22,1220,4.9,55,39.8,保留,长prompt P95大幅改善
T06,2026-07-21,CUDA_graphs,enforce_eager,默认,140,255,390,8,14,1320,5.0,58,40.5,保留,TPOT降低33%
T07,2026-07-21,max_model_len,32768,4096,135,248,375,9,15,1380,5.2,54,35.0,保留,释放了大量KV Cache
```

### 6.3 调优总结模板

```markdown
## 调优总结: [项目名/模型名]

### 调优前后对比

| 指标 | 基线 | 最终 | 提升 |
|------|------|------|------|
| Throughput | 1250 t/s | 2350 t/s | +88% |
| TTFT P95 | 298ms | 268ms | -10% |
| TPOT P50 | 12ms | 7ms | -42% |
| 显存使用 | 38.5 GB | 58.2 GB | - |

### 最终配置

\`\`\`bash
vllm serve /models/Qwen2.5-7B-Instruct-GPTQ-Int4 \
    --host 0.0.0.0 --port 8000 \
    --quantization gptq_marlin \
    --max-model-len 4096 \
    --max-num-seqs 128 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.92 \
    --enable-chunked-prefill \
    --enable-prefix-caching
\`\`\`

### 调优路径

B00 (基线 FP16) → T01 (GPTQ Int4, +48%吞吐) → T02 (max_num_seqs=128, +30%吞吐)
→ T04 (prefix caching, 命中率 73%) → T05 (chunked prefill, P95 改善)
→ T06 (CUDA graphs, TPOT -33%) → T07 (max_model_len 精确设置, 显存释放)

### 关键教训

1. GPTQ Int4 在本场景精度无损失, 是最有性价比的优化
2. max_num_seqs 超过 128 后 TTFT P95 超标, 128 是最优点
3. CUDA Graphs 对小 batch TPOT 改善显著
4. max_model_len 从默认的 32768 改成 4096 释放了 ~12GB 显存
```

---

## 7. 常见错误与修复

### 错误 1: max_model_len 设置过大

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: max_model_len=32768, 但实际业务最长 prompt 只有 4096       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    显存使用高, 但 KV Cache 利用率低                               │
│    nvidia-smi memory.used = 65 GB / 80 GB                       │
│    gpu_cache_usage_perc = 0.25 → KV Cache 才用 25%!             │
│    能支持的并发数远低于预期                                        │
│                                                                 │
│  根因:                                                           │
│    max_model_len 决定了每个 sequence 预分配的 KV Cache 上限        │
│    32768 / 4096 = 8x → 同样显存只能支持 1/8 的并发                │
│                                                                 │
│  修复:                                                           │
│    分析业务 prompt 的 P99 长度                                    │
│    max_model_len = P99 × 1.2                                    │
│    例如 P99 = 3500 → max_model_len = 4200                       │
│                                                                 │
│  验证:                                                           │
│    nvidia-smi: memory.used 降低                                  │
│    gpu_cache_usage_perc 提升到 50-70%                            │
│    相同并发下 swap 次数减少                                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 错误 2: 小模型用 TP=2

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: Qwen2.5-7B 用 --tensor-parallel-size 2                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    TTFT、TPOT 反而比单卡差                                       │
│    GPU-Util 两张卡都只有 30-40%                                  │
│    nvlink 带宽占用高但计算利用率低                                 │
│                                                                 │
│  根因:                                                           │
│    7B 模型单卡完全够, TP=2 增加的 AllReduce 通信开销 >            │
│    降低的计算量, 得不偿失                                          │
│    每个 Transformer Layer 后都需要 AllReduce                     │
│    对于 7B 模型, AllReduce(28层 × 2次) 的延迟 > 并行节省的时间     │
│                                                                 │
│  修复:                                                           │
│    --tensor-parallel-size 1  ← 改回单卡                          │
│                                                                 │
│  规则:                                                           │
│    模型 ≤ 13B: 单卡                                             │
│    模型 14B-34B: 单卡 INT4 或 双卡 FP16 TP=2                    │
│    模型 ≥ 70B: 多卡 TP (TP=2 用 INT4, TP=4 用 FP16)            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 错误 3: 忘了开启 Prefix Caching

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: 系统提示词 2000 token, 每个请求都一样, 但没开 prefix cache  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    TTFT 高且稳定, 不受请求量影响                                   │
│    每次 benchmark TTFT P50 都在 300ms+                           │
│    prefix_cache_* 指标全部为 0 或不存在                           │
│                                                                 │
│  根因:                                                           │
│    忘记加 --enable-prefix-caching 参数                            │
│    或者加了但 prefix cache 因为其他原因不生效                       │
│                                                                 │
│  修复:                                                           │
│    vllm serve ... --enable-prefix-caching                        │
│                                                                 │
│  验证:                                                           │
│    curl http://localhost:8000/metrics | grep prefix_cache         │
│    # 应该看到:                                                    │
│    # vllm:prefix_cache_queries_total{...} 5000.0                 │
│    # vllm:prefix_cache_hits_total{...} 3800.0                    │
│    # → 命中率 = 3800/5000 = 76% ✅                               │
│                                                                 │
│    或用日志验证:                                                  │
│    grep -i "prefix cache hit" server.log | wc -l                 │
│    # > 0 说明有命中                                               │
│                                                                 │
│  容易漏掉的检查:                                                  │
│    1. 自动前缀缓存需要 block_size ≥ 16 (默认满足)                  │
│    2. 如果用了 APCs (Automatic Prefix Caching),                   │
│       hash 计算的 block 必须是 16-token 对齐的                     │
│    3. 采样参数不同 (temperature, top_p) 不影响 prefix 匹配         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 错误 4: block_size 设置过大

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: --block-size 256                                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    显存还有空间 (gpu_memory_used < total)                        │
│    但 vLLM 报 "Cannot allocate blocks"                          │
│    gpu_cache_usage_perc 只有 50% 却 OOM                          │
│                                                                 │
│  根因 (内部碎片):                                                 │
│    block_size = 256 token                                       │
│    每个请求实际使用 300 token (2 个 block = 512, 浪费 212)        │
│    ┌──────────┬──────────┐                                      │
│    │  使用300  │ 浪费212  │ ← 第二个 block 被分配但只用了一部分     │
│    │  (256)   │  (44+168)│                                      │
│    └──────────┴──────────┘                                      │
│    碎片率 = 212/512 = 41.4%!                                     │
│                                                                 │
│  修复:                                                           │
│    --block-size 16 (vLLM 默认)                                   │
│    或者 --block-size 8  (极致减少碎片但增加管理 overhead)          │
│                                                                 │
│  计算公式:                                                       │
│    碎片率 ≈ (block_size - 1) / (2 × avg_seq_len_per_req)        │
│    平均请求长度 500 token, block_size=16:                        │
│      碎片率 ≈ 15 / 1000 = 1.5%                                  │
│    平均请求长度 500 token, block_size=256:                       │
│      碎片率 ≈ 255 / 1000 = 25.5%                                │
│                                                                 │
│  规则:                                                           │
│    短对话 (<500 token): block_size = 8 或 16                     │
│    中等长度 (500-2000): block_size = 16 (默认)                    │
│    长上下文 (>2000): block_size = 16 或 32                       │
│    几乎不需要设置 > 32                                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 错误 5: 未预热就 benchmark

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: vLLM 刚启动就立刻压测                                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    第一次 benchmark 的结果明显比后续差                              │
│    TTFT P50 第一次 220ms, 第二次 150ms (同样的请求)                │
│    尤其是开启 CUDA Graph 时, 第一次运行几乎无 Graph 命中            │
│                                                                 │
│  根因:                                                           │
│    CUDA Graph capture 在 batch size 变化时需要重新捕获             │
│    GPU cache 冷启动: L2 cache / TLB 都是空的                     │
│    CUDA kernel just-in-time (JIT) 编译有 overhead                │
│                                                                 │
│  修复:                                                           │
│    # 方法 1: 手工预热                                              │
│    for i in {1..20}; do                                          │
│        curl -s http://localhost:8000/v1/chat/completions \       │
│            -H "Content-Type: application/json" \                 │
│            -d '{"model":"...","messages":[{"role":"user",        │
│            "content":"hello"}],"max_tokens":10}' > /dev/null     │
│    done                                                          │
│    echo "预热完成"                                                │
│                                                                 │
│    # 方法 2: 等 CUDA Graph 捕获完成                               │
│    grep "Graph capturing" server.log                             │
│    # 等看到所有 batch size 的 graph 都 captured 后再 benchmark     │
│                                                                 │
│    # 方法 3: 用 benchmark_serving.py 预热                         │
│    python3 -m vllm.benchmarks.benchmark_serving \                │
│        ... --num-prompts 50 \   ← 先用 50 个请求预热              │
│        && \                                                      │
│    python3 -m vllm.benchmarks.benchmark_serving \                │
│        ... --num-prompts 200   ← 正式 benchmark                  │
│                                                                 │
│  验证:                                                           │
│    连续跑 3 次 benchmark, 结果应该在 ±5% 以内                      │
│    如果差距 > 10%, 说明系统还没稳定                                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 错误 6: KV Cache 数据类型浪费

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: KV Cache 用 FP16, 但 FP8 精度完全够                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    KV Cache 占显存比例过高 (>60%)                                 │
│    能支撑的并发数受限                                              │
│                                                                 │
│  修复:                                                           │
│    --kv-cache-dtype fp8 \                                        │
│    → KV Cache 显存减半, 同样显存支持 2x 并发                       │
│                                                                 │
│  注意:                                                           │
│    FP8 KV Cache 只在 H100/Ada Lovelace+ 上支持                   │
│    A800/A100 是 Ampere, 不支持 FP8 KV Cache!                     │
│    → A 系列卡用 --kv-cache-dtype auto (默认是 FP16)               │
│                                                                 │
│  验证:                                                           │
│    nvidia-smi --query-gpu=name --format=csv                      │
│    如果是 "NVIDIA H100" → 可以用 fp8 kv cache                    │
│    如果是 "NVIDIA A800" → 不支持 fp8 kv cache                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 错误 7: gpu_memory_utilization 设得过高 OOM

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: --gpu-memory-utilization 0.98                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    启动成功, 跑一会儿后 OOM                                       │
│    尤其是并发上来之后                                              │
│    CUDA out of memory error                                      │
│                                                                 │
│  根因:                                                           │
│    0.98 太激进了                                                  │
│    中间激活 (activations) 是动态分配的                             │
│    CUDA context + PyTorch 缓存可能需要额外的 ~2-3 GB               │
│    峰值显存 = 模型 + KV Cache + 中间激活 + 开销                    │
│                                                                 │
│  修复:                                                           │
│    --gpu-memory-utilization 0.85 ~ 0.92                          │
│    A800 80GB:                                                   │
│      0.90 → 留 8 GB 缓冲区 (安全)                                 │
│      0.85 → 留 12 GB 缓冲区 (更安全)                              │
│      0.92 → 留 6.4 GB 缓冲区 (还行, 高峰期可能 OOM)               │
│                                                                 │
│  规则:                                                           │
│    7B:   0.90-0.92 (模型小, 波动小)                               │
│    14B:  0.88-0.90                                                │
│    30B+: 0.85-0.88 (模型大, 中间激活也大)                          │
│    如果启用 CUDA Graphs: 再降 0.02 (graph 需要额外显存)            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 错误 8: benchmark 只测 inf 不测实际负载

```
┌─────────────────────────────────────────────────────────────────┐
│  错误: 只用 --request-rate inf 跑 benchmark                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  症状:                                                           │
│    benchmark 显示 Throughput 2000 t/s, TTFT P50 120ms            │
│    上线后用户抱怨延迟高, TTFT 经常 2s+                              │
│                                                                 │
│  根因:                                                           │
│    --request-rate inf 是无排队场景 → TTFT ≈ 纯计算时间             │
│    实际有排队时: TTFT = 排队时间 + 计算时间                         │
│    用 inf 测不出队列堆积的影响                                     │
│                                                                 │
│  修复:                                                           │
│    for rate in 1 2 4 8 16 32 64 inf; do                          │
│        python3 -m vllm.benchmarks.benchmark_serving \            │
│            ... --request-rate $rate                              │
│    done                                                          │
│                                                                 │
│    找到:                                                          │
│    1. 延迟墙 (TTFT P95 开始飙升的点)                               │
│    2. 吞吐上限 (increase rate but throughput stops increasing)   │
│    3. 最佳工作点 (throughput 达到上限 80% 时延迟还能接受)           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 8. 附录

### 8.1 显存分配分解 (ASCII Pie Chart)

```
  典型 A800 80GB 部署 Qwen2.5-7B (FP16, max_model_len=4096, max_num_seqs=128):

  ┌────────────────────────────────────────────────────────────────┐
  │                    80 GB GPU Memory                            │
  │  ┌─────────────────────────────────────────────────────────┐   │
  │  │████████████████         模型参数: ~14 GB  (17.5%)       │   │
  │  │██████████████████████████                              │   │
  │  ├─────────────────────────────────────────────────────────┤   │
  │  │████████████████████████  KV Cache:  ~20 GB  (25.0%)    │   │
  │  │██████████████████████                                  │   │
  │  ├─────────────────────────────────────────────────────────┤   │
  │  │███████████████          CUDA Graph: ~2 GB   (2.5%)     │   │
  │  ├─────────────────────────────────────────────────────────┤   │
  │  │██████████               激活+开销:  ~4 GB   (5.0%)      │   │
  │  ├═════════════════════════════════════════════════════════┤   │
  │  │░░░░░░░░░░░░░░░░░░░░░░  缓冲区:    ~8 GB   (10.0%)      │   │
  │  │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░                   │   │
  │  ├─────────────────────────────────────────────────────────┤   │
  │  │                         空闲:     ~32 GB  (40.0%)      │   │
  │  │                                                        │   │
  │  └─────────────────────────────────────────────────────────┘   │
  └────────────────────────────────────────────────────────────────┘

  INT4 量化后同样的场景:
  ┌────────────────────────────────────────────────────────────────┐
  │                    80 GB GPU Memory                            │
  │  ├─────────────────────────────────────────────────────────┤   │
  │  │████████          模型参数: ~3.5 GB (4.4%)               │   │
  │  ├─────────────────────────────────────────────────────────┤   │
  │  │████████████████████████  KV Cache:  ~20 GB  (25.0%)    │   │
  │  │██████████████████████                                  │   │
  │  ├─────────────────────────────────────────────────────────┤   │
  │  │███████████          其他:     ~6 GB   (7.5%)           │   │
  │  ├═════════════════════════════════════════════════════════┤   │
  │  │                         空闲: ~50.5 GB (63.1%) →       │   │
  │  │                         可以增大 max_num_seqs 到 300+! │   │
  │  └─────────────────────────────────────────────────────────┘   │
  └────────────────────────────────────────────────────────────────┘
```

### 8.2 常用监控一行命令

```bash
# ============================================
# 监控速查
# ============================================

# GPU 实时状态
watch -n 1 "nvidia-smi --query-gpu=index,utilization.gpu,memory.used,temperature.gpu --format=csv"

# vLLM 关键指标
watch -n 2 "curl -s http://localhost:8000/metrics | grep -E 'vllm:(num_requests|gpu_cache|prefix_cache)'"

# 服务健康检查
while true; do
    echo "$(date): $(curl -s -o /dev/null -w '%{http_code}' http://localhost:8000/health)"
    sleep 5
done

# 日志错误实时监控
tail -f vllm_server.log | grep -E "ERROR|WARNING|OOM|swap"

# benchmark 过程可视化 (在另一个终端 watch progress)
```

### 8.3 一键调优脚本框架

```bash
#!/bin/bash
# auto_tune.sh — 自动化调优流程框架
# 使用方法: bash auto_tune.sh /models/Qwen2.5-7B-Instruct

MODEL="$1"
BASE_PORT=8000
DATASET="/data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json"
RESULTS_DIR="./auto_tune_results"

mkdir -p "$RESULTS_DIR"

echo "=== 自动调优开始: $MODEL ==="
echo "结果目录: $RESULTS_DIR"
echo ""

# 1. 基线
echo "[1/8] 基线测试..."
# (启动服务、benchmark、记录结果的代码)
echo "完成"

# 2. 量化
echo "[2/8] 量化测试..."
# ...
echo ""

# 3. max_num_seqs 扫描
echo "[3/8] max_num_seqs 扫描..."
for seqs in 16 32 64 128 256; do
    echo "  测试 max_num_seqs=$seqs..."
    # ...
done
echo ""

# 4. max_num_batched_tokens 扫描
# 5. max_model_len 精确设置
# 6. prefix caching
# 7. chunked prefill
# 8. CUDA graphs

echo "=== 调优完成 ==="
echo "结果: $RESULTS_DIR/"
echo "最佳配置: cat $RESULTS_DIR/best_config.txt"
```

### 8.4 快速决策卡片

```
┌─────────────────────────────────────────────────────────────────┐
│                    vLLM 调优快速决策卡                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Q: TTFT 太高怎么办?                                             │
│  A: ① 开 prefix caching (如有公共前缀)                           │
│      ② 开 chunked prefill (如有长 prompt)                       │
│      ③ 增大 max-num-batched-tokens                              │
│      ④ 检查是否需要 TP                                           │
│                                                                 │
│  Q: TPOT 太高怎么办?                                             │
│  A: ① 开 CUDA Graphs                                           │
│      ② 减少 max_num_seqs (降低 KV Cache 竞争)                    │
│      ③ 量化模型 (降低显存带宽压力)                                 │
│      ④ 检查是否有 swap                                           │
│                                                                 │
│  Q: Throughput 太低怎么办?                                       │
│  A: ① 增大 max_num_seqs (GPU 吃不饱)                             │
│      ② 增大 max-num-batched-tokens                               │
│      ③ 量化模型 (减少显存带宽瓶颈)                                 │
│      ④ 检查是否 memory-bound → 增加 batch 没用                  │
│                                                                 │
│  Q: 频繁 OOM 怎么办?                                             │
│  A: ① 降低 gpu-memory-utilization (0.90 → 0.85)                 │
│      ② 降低 max_model_len (设成 P99 值的 1.2 倍)                  │
│      ③ 降低 max_num_seqs                                         │
│      ④ 量化模型 (释放大量显存)                                    │
│      ⑤ 量化 KV Cache (--kv-cache-dtype fp8, 仅 H100)            │
│                                                                 │
│  Q: 显存够但并发上不去?                                           │
│  A: ① 降低 max_model_len (释放更多 KV Cache 空间)                 │
│      ② 降低 block_size (减少内部碎片)                             │
│      ③ 检查 gpu_cache_usage 是否接近 100%                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 8.5 参数优先级排序

在实际调优中，按照投入产出比从高到低排序：

```
优先级  参数                  预期收益        风险         调优难度
─────────────────────────────────────────────────────────────────
  ★★★   max_model_len 精确化   显存节省 30-50%  无           低
  ★★★   量化 (FP16→INT4)       吞吐 +30-80%    精度风险 1%   低
  ★★☆   max_num_seqs 调优      吞吐 +20-50%    延迟增加      中
  ★★☆   prefix caching 开启     TTFT -30-60%    无            低
  ★★☆   CUDA Graphs 开启        TPOT -20-40%    显存 +1-2GB   低
  ★★☆   max_num_batched_tokens  长prompt TTFT改善 无           低
  ★☆☆   chunked prefill        延迟稳定性      TPOT略增      低
  ★☆☆   TP 调优                吞吐 +X%        延迟、成本    中
  ★☆☆   block_size 调优        减少碎片        overhead      低
  ☆☆☆   KV Cache dtype FP8     2x KV Cache    仅 H100       低
```

---

## 9. 易混淆技术辨析

### 9.1 Throughput 优化 vs Latency 优化

这是调优中最容易走错方向的分叉口：

```
┌──────────────────────┬─────────────────────────┬──────────────────────────┐
│  维度                 │  吞吐优先 (Throughput)   │  延迟优先 (Latency)       │
├──────────────────────┼─────────────────────────┼──────────────────────────┤
│  目标                 │  每秒产出最多 token       │  每个请求尽快返回         │
│  典型场景             │  离线批处理、数据标注      │  在线对话、代码补全       │
│  核心指标             │  tokens/s, QPS           │  TTFT P95, TPOT P95      │
│  优化方向             │  增大 batch, 量化, TP     │  减小 batch, CUDA Graphs │
│  max_num_seqs         │  尽量大（128-256+）       │  适中（16-64）            │
│  chunked prefill      │  可以不开启               │  强烈建议开启             │
│  GPU 利用率目标        │  >80%                    │  40-60% 也正常            │
└──────────────────────┴─────────────────────────┴──────────────────────────┘

关键认知：这两个目标很多时候是矛盾的。
  - 增大 max_num_seqs → 吞吐上升，但 TTFT/TPOT 也上升（排队和竞争加剧）
  - 减小 max_num_seqs → 延迟下降，但吞吐也下降（GPU 吃不饱）

实战选择：
  - 在线服务选"延迟墙"：找到 P95 TTFT 开始指数飙升的点，把 max_num_seqs 设在该点之前
  - 批处理选"吞吐平台"：找到吞吐不再增长的 max_num_seqs，那就是最优点
```

### 9.2 Memory-Bound vs Compute-Bound 的判断

```
这不是理论概念——它直接决定你的调优方向是否正确。

快速判断方法（1 分钟）：
  nvidia-smi dmon -s pucv -d 1 -c 10

  观察输出:
  ┌─────────────────────────────────────────────────────────┐
  │  sm=85%  mem=40%  → Compute-Bound                      │
  │    → 增大 batch 有用，量化对 Prefill 有帮助             │
  │    → 增大 max_num_batched_tokens, 考虑 TP               │
  │                                                         │
  │  sm=30%  mem=85%  → Memory-Bound                        │
  │    → 增大 batch 可能让延迟恶化                          │
  │    → 量化权重（减少读取量），不要增大 batch              │
  │    → prefix caching（减少不必要的 Prefill）              │
  │                                                         │
  │  sm=15%  mem=35%  → Scheduling-Bound                    │
  │    → CUDA Graphs, chunked prefill, torch.compile        │
  │    → CPU 端处理跟不上，GPU 在空等                        │
  └─────────────────────────────────────────────────────────┘

一个常见错误：Memory-Bound 场景下盲目增大 max_num_seqs。
  Decode 阶段，每增加一个并发序列，都要多读一份 KV Cache。
  如果显存带宽已经 85%+，再加并发只会让每个序列的 TPOT 等比例恶化。
  正确的做法是减少每个序列的内存需求（量化 KV Cache、降低 max_model_len）。
```

### 9.3 TP vs PP for Inference

```
Tensor Parallelism (TP) 和 Pipeline Parallelism (PP) 在推理中的适用性完全不同：

TP (Tensor Parallelism):
  原理: 每层的权重矩阵按列/行切分到多张 GPU，每层计算后 AllReduce 同步。
  推理适用: ★★★ 标准方案
  优点: 每张卡显存压力均分，延迟几乎不增加（AllReduce 很快）
  缺点: 需要高速 GPU 间互联（NVLink），小模型通信开销可能 > 计算收益
  适用: 单卡放不下模型参数时

PP (Pipeline Parallelism):
  原理: 模型按层切分，GPU0 管 Layer 0-13，GPU1 管 Layer 14-27。
  推理适用: ★☆☆ 几乎不用于推理
  优点: 通信量小（只在层边界传激活值）
  缺点: 
    - Pipeline bubble：GPU 间有等待空档，一批请求中 GPU0 可能在等 GPU1 完成上一批
    - Micro-batch 调度复杂，推理延迟成倍增加
    - 不适合 decode 阶段（每次只生成 1 个 token，pipeline bubble 占比极大）
  适用: 训练场景多，推理场景极少使用

为什么推理只用 TP 不用 PP:
  推理是逐 token 生成的（decode），每个 step 的序列长度很短。
  PP 需要把 batch 切分成 micro-batch 来填充 pipeline bubble。
  但在 decode 阶段 batch 本来就小（几十个序列），micro-batch 更小（可能 1-2 个），
  pipeline bubble 会占据 50% 以上的时间。

如果你看到某个推理方案用了 PP，大概率是：
  - 模型极大（>175B），拆得不够细，PP 作为 TP 的补充
  - 或者是训练/Pre-Training 场景，不是在线推理
```

---

## 10. AI Infra 专家视角

### 10.1 性能瓶颈排查流程

```
第一层：是哪种瓶颈？（30 秒判断）
├── nvidia-smi dmon -s pucv -d 1 -c 5
│   ├── sm > 80%, mem < 50% → Compute-Bound → 跳至第二层 A
│   ├── sm < 40%, mem > 70% → Memory-Bound → 跳至第二层 B
│   └── sm < 20%, mem < 40% → Scheduling-Bound → 跳至第二层 C
│
├── 第二层 A: Compute-Bound 排查
│   ├── 用 ncu 查看具体 kernel 的 sm__throughput
│   │   ncu --metrics sm__throughput.avg.pct_of_peak_sustained_elapsed \
│   │       --kernel-name regex:.*gemm.* python3 my_bench.py
│   ├── sm__throughput < 60% → 优化空间大
│   │   ├── 量化 (FP16 → INT4): 权重减半 → Compute 效率翻倍
│   │   ├── 增大 max_num_batched_tokens (给 Prefill 更多并行度)
│   │   ├── 增大 max_num_seqs (让 GPU 吃更饱)
│   │   └── 考虑 TP=2（如果单卡算力不够）
│   └── sm__throughput > 80% → 已接近硬件极限，考虑换更强 GPU
│
├── 第二层 B: Memory-Bound 排查
│   ├── nvidia-smi --query-gpu=utilization.memory --format=csv
│   ├── memory util > 85% → 带宽已饱和
│   │   ├── 量化模型权重 (INT4): 读取量减半 → 等效带宽翻倍
│   │   ├── 减小 max_num_seqs (减少 KV Cache 读取竞争)
│   │   ├── 降低 max_model_len (减少每个序列的 KV Cache 大小)
│   │   └── 开启 prefix caching (消除重复 Prefill 的内存流量)
│   └── memory util < 50% → 带宽不是瓶颈，回到第一层重新判断
│
└── 第二层 C: Scheduling-Bound 排查
    ├── nsys profile --trace=cuda,osrt python3 my_bench.py
    │   在 Nsight Systems GUI 中查看 kernel 间是否有 >20μs 的 gap
    ├── 如果有明显 gap:
    │   ├── 开启 CUDA Graphs (消除 launch overhead)
    │   ├── 确保 enforce_eager 已关闭 (vLLM 默认关闭)
    │   ├── 检查 vLLM 日志中 "Graph captured" 是否成功
    │   └── 升级 PyTorch/CUDA 版本（某些版本有已知 launch 性能问题）
    └── 如果 gap 很小但 GPU 仍空闲:
        ├── 请求量不够（发更多请求）
        ├── 增大 max_num_seqs（让 scheduler 有更多请求可选）
        └── 增大 request-rate（benchmark 加压）
```

### 10.2 A800 部署实操：Qwen2.5-32B-Instruct on 2×A800

**场景设定**：两台 A800 80GB，部署 32B 模型，服务内部 Agent 工作流。目标是 7×24 稳定服务，TTFT P95 < 500ms。

#### 方案对比

```bash
# ============================================
# 方案 A: 双卡 FP16 TP=2（无损精度，推荐作为基线）
# ============================================
vllm serve /data/models/Qwen2.5-32B-Instruct \
    --host 0.0.0.0 --port 8000 \
    --tensor-parallel-size 2 \
    --max-model-len 8192 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.88 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee tuning_logs/32b_fp16_tp2.log

# ============================================
# 方案 B: 单卡 INT4 GPTQ Marlin（成本最优）
# ============================================
vllm serve /data/models/Qwen2.5-32B-Instruct-GPTQ-Int4 \
    --host 0.0.0.0 --port 8001 \
    --quantization gptq_marlin \
    --max-model-len 8192 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.90 \
    --enable-chunked-prefill \
    --enable-prefix-caching \
    2>&1 | tee tuning_logs/32b_int4_marlin.log
```

#### 调优迭代记录（真实流程）

```
迭代 0: 基线 (方案 A, 默认参数)
  配置: max_num_seqs=256 (vLLM 默认), max_num_batched_tokens=2048 (默认)
  Throughput: 420 tokens/s, TTFT P50: 350ms, TTFT P95: 2100ms
  GPU Util: GPU0=45%, GPU1=45%
  结论: TTFT P95 太差 (2100ms)，默认 max_num_batched_tokens 太小导致长 prompt 被切太碎

迭代 1: 增大 token budget
  配置: max_num_batched_tokens 2048 → 16384
  Throughput: 680 tokens/s (+62%), TTFT P50: 180ms, TTFT P95: 480ms
  GPU Util: GPU0=72%, GPU1=72%
  结论: 显著改善。TTFT P95 从 2100ms 降到 480ms，token budget 是关键参数

迭代 2: 调优 max_num_seqs
  配置: max_num_seqs 256 → 128
  Throughput: 650 tokens/s (-4%), TTFT P95: 420ms (-12%)
  结论: 稍降吞吐但延迟更好，128 是更好的平衡点

迭代 3: 再调 max_num_seqs
  配置: max_num_seqs 128 → 64
  Throughput: 580 tokens/s (-11%), TTFT P95: 360ms (-14%)
  GPU Util: GPU0=58%, GPU1=58%
  结论: 延迟更好了但 GPU 利用率下降。选择 64 还是 128 取决于 SLA 要求

迭代 4: 开启 prefix caching
  配置: --enable-prefix-caching (之前未开启)
  prefix_cache_hit_rate: 68% (system prompt 长 500 token)
  Throughput: 720 tokens/s (+24%), TTFT P50: 120ms (-33%)
  结论: 前缀缓存对本场景（固定 system prompt）效果显著

迭代 5: 对比方案 B (单卡 INT4)
  配置: 方案 B 全部参数
  Throughput: 750 tokens/s, TTFT P50: 160ms, TTFT P95: 390ms
  GPU Util: 70%
  显存: 模型 16.5GB + KV Cache 22GB + 开销 5GB ≈ 43.5GB / 80GB
  结论: 单卡 INT4 达到了双卡 FP16 的吞吐！而且省一张卡。精度检查通过。

最终选定: 方案 B (单卡 INT4)
  理由: 
    1. 节省一张 A800 (可用于其他服务或投机解码 draft model)
    2. 吞吐略优于方案 A 双卡
    3. TTFT P95 390ms < 500ms SLA
    4. 剩余 36GB 显存可应对流量峰值
```

#### 部署后的持续监控

```bash
# 每 30 秒检查核心指标
watch -n 30 "curl -s http://localhost:8000/metrics | grep -E \
  'vllm:(num_requests_waiting|num_requests_running|gpu_cache_usage_perc|prefix_cache_hits_total|prefix_cache_queries_total)'"

# 告警规则（Prometheus）:
# - gpu_cache_usage_perc > 0.90 → 警告：KV Cache 即将耗尽
# - num_requests_waiting > 20 → 警告：排队严重
# - prefix_cache_hit_rate < 0.30 → 提示：前缀缓存效率低，检查 system prompt 是否一致
# - num_requests_swapped > 0 → 严重：有请求被 swap 到 CPU，性能大幅下降
```

---

## 参考资料

- vLLM 官方文档: https://docs.vllm.ai/en/latest/
- vLLM Serving Benchmark: https://github.com/vllm-project/vllm/tree/main/benchmarks
- NVIDIA Nsight Systems: https://developer.nvidia.com/nsight-systems
- NVIDIA Nsight Compute: https://developer.nvidia.com/nsight-compute
- 本系列上一篇: 05-worker-execution.md
- 本系列下一篇: (待定)
