# vLLM 启动全流程：从命令行到 Ready

> 本文档详细追踪 vLLM 从命令行启动到服务就绪的完整链路，逐层深入源码，适合慢速深度研读。
> 
> 基于 vLLM 0.11+ 版本（V1 引擎架构），本文档涵盖 `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/` 下的真实代码。

---

## 目录

1. [整体架构概览](#1-整体架构概览)
2. [阶段一：入口点与参数解析](#2-阶段一入口点与参数解析)
3. [阶段二：AsyncEngineArgs.create_engine_config()](#3-阶段二asyncengineargscreate_engine_config)
4. [阶段三：AsyncLLM 初始化](#4-阶段三asyncllm-初始化)
5. [阶段四：EngineCore 初始化](#5-阶段四enginecore-初始化)
6. [阶段五：Worker.init_device() - 设备初始化](#6-阶段五workerinit_device---设备初始化)
7. [阶段六：Worker.load_model() - 模型加载](#7-阶段六workerload_model---模型加载)
8. [阶段七：Memory Profiling - KV Cache 显存计算](#8-阶段七memory-profiling---kv-cache-显存计算)
9. [阶段八：CUDA Graph Capture](#9-阶段八cuda-graph-capture)
10. [阶段九：服务就绪](#10-阶段九服务就绪)
11. [启动日志逐行解读](#11-启动日志逐行解读)
12. [常见失败与修复](#12-常见失败与修复)
13. [各阶段耗时分析](#13-各阶段耗时分析)
14. [深入学习资源](#14-深入学习资源)

---

## 1. 整体架构概览

### 1.1 启动流程全景图

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                        vLLM Startup Pipeline Overview (V1 Architecture)           │
├──────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  CLI: python -m vllm.entrypoints.openai.api_server --model meta-llama/Llama-3.1 │
│                                                                                  │
│  ┌──────────────────────────────────────────────────────────────────────────┐    │
│  │ Phase 1: Argument Parsing (~0.1s)                                        │    │
│  │                                                                          │    │
│  │  make_arg_parser() ──> parser.parse_args() ──> Namespace args            │    │
│  │       │                                                                  │    │
│  │       ▼                                                                  │    │
│  │  AsyncEngineArgs.from_cli_args(args)                                     │    │
│  │       │                                                                  │    │
│  └───────┼──────────────────────────────────────────────────────────────────┘    │
│          │                                                                       │
│  ┌───────▼──────────────────────────────────────────────────────────────────┐    │
│  │ Phase 2: Config Construction (~0.5-2s)                                   │    │
│  │                                                                          │    │
│  │  engine_args.create_engine_config()                                      │    │
│  │       │                                                                  │    │
│  │       ├──> ModelConfig      (HuggingFace config.json 加载)               │    │
│  │       ├──> LoadConfig       (权重格式、下载策略)                         │    │
│  │       ├──> CacheConfig      (KV Cache 配置)                              │    │
│  │       ├──> ParallelConfig   (TP/PP/DP 配置)                              │    │
│  │       ├──> SchedulerConfig  (调度器配置)                                 │    │
│  │       ├──> DeviceConfig     (设备配置)                                   │    │
│  │       └──> VllmConfig       (聚合所有子配置)                             │    │
│  │                                                                          │    │
│  └───────┼──────────────────────────────────────────────────────────────────┘    │
│          │                                                                       │
│  ┌───────▼──────────────────────────────────────────────────────────────────┐    │
│  │ Phase 3: AsyncLLM.__init__() (~0.1s)                                     │    │
│  │                                                                          │    │
│  │  ├──> Renderer 创建          (模板渲染器)                                │    │
│  │  ├──> InputProcessor 创建    (请求预处理)                                │    │
│  │  ├──> OutputProcessor 创建   (输出后处理)                                │    │
│  │  └──> EngineCoreClient 创建  (后台进程 IPC 通信)                         │    │
│  │       │                                                                  │    │
│  └───────┼──────────────────────────────────────────────────────────────────┘    │
│          │                                                                       │
│  ┌───────▼──────────────────────────────────────────────────────────────────┐    │
│  │ Phase 4: EngineCore.__init__() [后台进程] (~5-60s, 取决于模型大小)       │    │
│  │                                                                          │    │
│  │  ┌─────────────────── Sub-phases ───────────────────────────────┐        │    │
│  │  │                                                              │        │    │
│  │  │  4a. Executor 创建                                           │        │    │
│  │  │      每个 GPU 一个 Worker 进程                               │        │    │
│  │  │                                                              │        │    │
│  │  │  4b. Worker.init_device()           (~1-3s)                  │        │    │
│  │  │      ├── CUDA 设备设置                                        │        │    │
│  │  │      ├── NCCL 分布式初始化                                    │        │    │
│  │  │      ├── 显存快照 (MemorySnapshot)                            │        │    │
│  │  │      └── ModelRunner 创建                                     │        │    │
│  │  │                                                              │        │    │
│  │  │  4c. Worker.load_model()            (~5-50s)                  │        │    │
│  │  │      ├── HuggingFace config.json 下载                          │        │    │
│  │  │      ├── 权重下载（如果需要）                                   │        │    │
│  │  │      ├── 模型架构实例化                                       │        │    │
│  │  │      └── 量化工具加载 (AWQ/GPTQ/FP8...)                       │        │    │
│  │  │                                                              │        │    │
│  │  │  4d. KV Cache 初始化                (~1-2s)                   │        │    │
│  │  │      ├── profile_run() 前向传播分析                            │        │    │
│  │  │      ├── 计算 num_gpu_blocks                                    │        │    │
│  │  │      └── 分配 KV Cache pages                                   │        │    │
│  │  │                                                              │        │    │
│  │  │  4e. CUDA Graph Capture              (~10-60s)                │        │    │
│  │  │      ├── 遍历 batch size: 1,2,4,8,...,max_num_seqs            │        │    │
│  │  │      ├── 每个大小: capture decode forward pass                 │        │    │
│  │  │      └── 保存 graph 到 CUDA Graph Pool                        │        │    │
│  │  │                                                              │        │    │
│  │  │  4f. Scheduler 创建                                           │        │    │
│  │  │                                                              │        │    │
│  │  └──────────────────────────────────────────────────────────────┘        │    │
│  │                                                                          │    │
│  │  EngineCore sends: EngineCoreReadyResponse                               │    │
│  └───────┼──────────────────────────────────────────────────────────────────┘    │
│          │                                                                       │
│  ┌───────▼──────────────────────────────────────────────────────────────────┐    │
│  │ Phase 5: Server Ready (~0.1s)                                            │    │
│  │                                                                          │    │
│  │  ├──> FastAPI app 构建                                                   │    │
│  │  ├──> 注册路由 (/v1/chat/completions, /v1/completions, /health ...)     │    │
│  │  ├──> 绑定端口                                                          │    │
│  │  └──> uvicorn 启动                                                      │    │
│  │                                                                          │    │
│  └──────────────────────────────────────────────────────────────────────────┘    │
│                                                                                  │
└──────────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 V0 与 V1 架构对比

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          vLLM V0 vs V1 Architecture                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  V0 (旧版，v0.6.x 及之前):                                                    │
│  ┌───────────────────────────────────────────────────────────────┐          │
│  │  API Server (asyncio)                                          │          │
│  │       │                                                        │          │
│  │       ▼                                                        │          │
│  │  AsyncLLMEngine (asyncio)         <-- 单进程                    │          │
│  │       │                                                        │          │
│  │       ▼                                                        │          │
│  │  LLMEngine                                                      │          │
│  │       │                                                        │          │
│  │       ▼                                                        │          │
│  │  GPU Workers (Ray / Multiprocessing)  <-- 多 GPU 才多进程      │          │
│  └───────────────────────────────────────────────────────────────┘          │
│                                                                             │
│  V1 (新版，v0.7+):                                                           │
│  ┌───────────────────────────────────────────────────────────────┐          │
│  │  API Server (asyncio)       ┐                                   │          │
│  │       │                     │  进程间: ZMQ IPC                  │          │
│  │       ▼                     │                                   │          │
│  │  AsyncLLM                   │  前 台 进 程                      │          │
│  │       │                     │  (asyncio event loop)             │          │
│  │       ▼                     │                                   │          │
│  │  EngineCoreClient           │                                   │          │
│  │  (ZMQ/msgpack 通信)         ┘                                   │          │
│  │       │                                                        │          │
│  ════════╪══ 进程边界 ═══════════════════════════════════════════ │          │
│  │       ▼                                                        │          │
│  │  EngineCore (独立进程)                                          │          │
│  │       │                                                        │          │
│  │       ├── Scheduler (调度层)                                    │          │
│  │       │                                                        │          │
│  │       └── Executor (执行层)                                     │          │
│  │            │                                                   │          │
│  │            ├── GPU Worker 0  (独立进程)                         │          │
│  │            ├── GPU Worker 1  (独立进程)                         │          │
│  │            └── ...  (每个 GPU 一个 Worker)                      │          │
│  │                                                                 │          │
│  │        后 台 进 程 组                                           │          │
│  └───────────────────────────────────────────────────────────────┘          │
│                                                                             │
│  关键改进:                                                                   │
│  1. API Server 和 Engine 分离为不同进程 (通过 ZMQ 通信)                      │
│  2. EngineCore 统一管理调度和执行，避免 GIL 竞争                              │
│  3. 每个 GPU Worker 独立进程，通过 torch.distributed 同步                    │
│  4. 更好的容错：一个 worker 崩溃不会直接拖垮 API server                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.3 进程树

```
启动命令:
  python -m vllm.entrypoints.openai.api_server --model meta-llama/Llama-3.1-8B-Instruct \
    --tensor-parallel-size 2

产生的进程树:
  ┌───────────────────────────────────────────────────┐
  │  Main Process (API Server)                        │
  │  PID: 1000                                        │
  │  Role: FastAPI + AsyncLLM + EngineCoreClient      │
  │  GPU: 使用 cuda:0 for NCCL init only              │
  │                                                   │
  │  ├── EngineCore Process (后台)                     │
  │  │   PID: 1001                                    │
  │  │   Role: EngineCore (scheduler + coordinator)   │
  │  │   GPU: 无                                      │
  │  │                                               │
  │  │   ├── Worker Process (GPU 0)                   │
  │  │   │   PID: 1002                               │
  │  │   │   Role: GPUWorker                          │
  │  │   │   GPU: cuda:0                             │
  │  │   │   TP Rank: 0                              │
  │  │   │                                           │
  │  │   └── Worker Process (GPU 1)                   │
  │  │       PID: 1003                               │
  │  │       Role: GPUWorker                          │
  │  │       GPU: cuda:1                             │
  │  │       TP Rank: 1                              │
  │  │                                               │
  │  └── StatLogger Thread (后台)                     │
  │      Role: 定期输出吞吐量/token统计               │
  │                                                   │
  └───────────────────────────────────────────────────┘
```

---

## 2. 阶段一：入口点与参数解析

### 2.1 入口点：`__main__` 块

文件：`vllm/entrypoints/openai/api_server.py`

```python
# vllm/entrypoints/openai/api_server.py:691-703
if __name__ == "__main__":
    # NOTE(simon):
    # This section should be in sync with vllm/entrypoints/cli/main.py for CLI
    # entrypoints.
    cli_env_setup()
    parser = FlexibleArgumentParser(
        description="vLLM OpenAI-Compatible RESTful API server."
    )
    parser = make_arg_parser(parser)
    args = parser.parse_args()
    validate_parsed_serve_args(args)

    uvloop.run(run_server(args))
```

**关键点：**
- 使用 `uvloop` 替代标准库 asyncio（性能更好）
- `FlexibleArgumentParser` 继承自 `argparse.ArgumentParser`，支持更多类型
- `make_arg_parser()` 通过反射 dataclass 字段生成所有参数

### 2.2 `run_server()` 函数调用链

```python
# vllm/entrypoints/openai/api_server.py:650-663
async def run_server(args, **uvicorn_kwargs) -> None:
    """Run a single-worker API server."""
    decorate_logs("APIServer", skip_if_decorated=True)
    
    # 注册 SIGTERM 信号处理器 —— 在 uvicorn 接管前生效
    def _interrupt_init(*_) -> None:
        raise KeyboardInterrupt("terminated")
    signal.signal(signal.SIGTERM, _interrupt_init)
    
    listen_address, sock = setup_server(args)  # (1) 提前绑定端口
    await run_server_worker(listen_address, sock, args, **uvicorn_kwargs)  # (2)
```

**流程：**

```
run_server(args)
    │
    ├─ setup_server(args)                 # 验证参数 + 绑定端口
    │    ├─ log_version_and_model()        # 打印 vLLM 版本和模型名
    │    ├─ log_non_default_args()         # 打印非默认参数
    │    ├─ validate_api_server_args()     # 验证 tool_parser/reasoning_parser
    │    ├─ create_server_socket()         # 提前绑定端口 (防止 Ray 竞争)
    │    └─ set_ulimit()                   # 提高文件描述符限制
    │
    └─ run_server_worker(listen_address, sock, args)
         │
         ├─ build_async_engine_client(args)    # 构建引擎客户端 (context manager)
         │    │
         │    ├─ AsyncEngineArgs.from_cli_args(args) # 从解析结果创建 EngineArgs
         │    ├─ engine_args.create_engine_config()  # 构建 VllmConfig
         │    └─ AsyncLLM.from_vllm_config(config)   # 创建异步引擎 (触发后台启动)
         │
         ├─ build_and_serve(engine_client, ...)  # 构建 FastAPI app 并启动服务
         │    ├─ build_app(args)                 # 创建 FastAPI 实例
         │    ├─ init_app_state(...)             # 初始化 app state
         │    └─ serve_http(app, sock, ...)      # 启动 uvicorn
         │
         └─ shutdown_task                       # 等待服务关闭
```

### 2.3 参数解析：`AsyncEngineArgs`

文件：`vllm/engine/arg_utils.py`

`EngineArgs` 是一个庞大的 `@dataclass`，字段按类别从各 Config 类的字段默认值初始化。`AsyncEngineArgs` 继承自 `EngineArgs`，只增加了一个 `enable_log_requests` 字段。

```
@dataclass
class EngineArgs:                              # 所有 LLM 引擎的参数
    # ── Model (来自 ModelConfig) ──
    model: str                                 # HuggingFace 模型名或路径
    tokenizer: str | None                      # 分词器名（默认等于 model）
    tokenizer_mode: TokenizerMode              # auto/hf/slow/mistral/deepseek_v32
    trust_remote_code: bool                    # 是否信任远程代码
    dtype: ModelDType                          # auto/half/float16/bfloat16/float32
    seed: int                                  # 随机种子
    max_model_len: int                         # 最大上下文长度
    quantization: QuantizationMethods | None   # 量化方法
    enforce_eager: bool                        # 禁用 CUDA Graph
    skip_tokenizer_init: bool                  # 跳过 tokenizer 初始化
    # ... 还有 served_model_name, revision, hf_token 等
    
    # ── Load (来自 LoadConfig) ──
    load_format: str | LoadFormats             # auto/safetensors/pt/npcache
    download_dir: str | None                   # 模型下载目录
    
    # ── Parallel (来自 ParallelConfig) ──
    tensor_parallel_size: int                  # TP 并行度 (默认 1)
    pipeline_parallel_size: int                # PP 并行度 (默认 1)
    data_parallel_size: int                    # DP 并行度 (默认 1)
    distributed_executor_backend: str          # mp/ray/external_launcher
    
    # ── KV Cache (来自 CacheConfig) ──
    block_size: int                            # KV Cache 块大小 (默认 16)
    gpu_memory_utilization: float              # GPU 显存利用率 (默认 0.92)
    kv_cache_dtype: CacheDType                 # KV Cache 数据类型
    enable_prefix_caching: bool                # 前缀缓存
    
    # ── Scheduler (来自 SchedulerConfig) ──
    max_num_batched_tokens: int                # 每批次最大 token 数
    max_num_seqs: int                          # 最大并发序列数
    enable_chunked_prefill: bool               # 分块预填充
    
    # ── Compilation (来自 CompilationConfig) ──
    cudagraph_capture_sizes: list[int] | None  # CUDA Graph 捕获的 batch size
    
    # ── Other ──
    enable_lora: bool                          # 启用 LoRA
    # ... 还有 speculative, multimodal, observability 等


@dataclass
class AsyncEngineArgs(EngineArgs):             # 只比 EngineArgs 多一个字段
    enable_log_requests: bool = False          # 是否记录请求日志
```

### 2.4 `add_cli_args()` —— 动态生成 CLI 参数

```python
# vllm/engine/arg_utils.py:784-1576
@staticmethod
def add_cli_args(parser: FlexibleArgumentParser) -> FlexibleArgumentParser:
    """通过反射 dataclass 字段自动生成 argparse 参数"""
    
    # Model 参数组
    model_kwargs = get_kwargs(ModelConfig)  # 返回 {field_name: argparse_kwargs}
    model_group = parser.add_argument_group("ModelConfig", description=ModelConfig.__doc__)
    model_group.add_argument("--model", **model_kwargs["model"])
    model_group.add_argument("--dtype", **model_kwargs["dtype"])
    # ... 30+ 个模型参数 ...
    
    # Parallel 参数组
    parallel_kwargs = get_kwargs(ParallelConfig)
    parallel_group = parser.add_argument_group("ParallelConfig", ...)
    parallel_group.add_argument("--tensor-parallel-size", "-tp", **parallel_kwargs["tensor_parallel_size"])
    # ... 20+ 个并行参数 ...
    
    # Cache 参数组
    # Scheduler 参数组
    # Compilation 参数组
    # LoRA 参数组
    # ... 等共 10+ 个参数组
```

**参数组分类一览：**

```
python -m vllm.entrypoints.openai.api_server --help
  ModelConfig:            --model, --dtype, --max-model-len, --quantization, ...
  LoadConfig:             --load-format, --download-dir, ...
  AttentionConfig:        --attention-backend
  ParallelConfig:         -tp, -pp, -dp, --nnodes, --node-rank, ...
  CacheConfig:            --block-size, --gpu-memory-utilization, --kv-cache-dtype, ...
  SchedulerConfig:        --max-num-batched-tokens, --max-num-seqs, ...
  CompilationConfig:      --cudagraph-capture-sizes, ...
  LoRAConfig:             --enable-lora, --max-loras, --max-lora-rank, ...
  MultiModalConfig:       --limit-mm-per-prompt, ...
  ObservabilityConfig:    --otlp-traces-endpoint, ...
  OffloadConfig:          --cpu-offload-gb, ...
  VllmConfig:             --speculative-config, --compilation-config, ...
```

### 2.5 关键参数的默认值与语义

```python
# 默认值在对应的 Config 类中定义

# CacheConfig
gpu_memory_utilization: float = 0.92     # 使用 92% 的 GPU 显存
block_size: int = 16                     # 每个 KV cache block 16 个 token

# SchedulerConfig  
DEFAULT_MAX_NUM_BATCHED_TOKENS = 2048    # 每批次最多处理 2048 tokens
DEFAULT_MAX_NUM_SEQS = 128               # 最多同时处理 128 个序列

# 根据硬件自动调整 (arg_utils.py:2374-2456):
# H100/H200 (显存 >= 70GiB):
#   OPENAI_API_SERVER: max_num_batched_tokens=8192, max_num_seqs=1024
# A100 及其他:
#   OPENAI_API_SERVER: max_num_batched_tokens=2048, max_num_seqs=256
```

---

## 3. 阶段二：AsyncEngineArgs.create_engine_config()

文件：`vllm/engine/arg_utils.py`，`create_engine_config()` 方法，这是整个启动流程的核心配置构建方法。

### 3.1 流程图

```
create_engine_config(usage_context)
│
├─ (1) current_platform.pre_register_and_update()
│      确定当前平台: CUDA/ROCm/CPU/TPU/XPU
│
├─ (2) DeviceConfig(device=current_platform.device_type)
│      创建设备配置: "cuda" / "cpu" / "tpu" ...
│
├─ (3) 验证环境变量
│      envs.validate_environ()
│
├─ (4) maybe_override_with_speculators()
│      检测是否为 speculative decoding 的 draft model
│
├─ (5) self.create_model_config()  ─────────────────────────────────────┐
│      │                                                                 │
│      ├── ModelConfig(model=self.model, tokenizer=..., dtype=...,       │
│      │              max_model_len=..., quantization=..., ...)          │
│      │                                                                 │
│      ├── 内部流程:                                                      │
│      │   ├─ 解析 HuggingFace config.json                               │
│      │   ├─ 确定模型架构 (registry lookup)                              │
│      │   ├─ 确定 tokenizer 类型                                        │
│      │   ├─ 确定 max_model_len                                         │
│      │   ├─ 确定 attention 类型 (decoder/encoder/hybrid/...)           │
│      │   └─ 确定是否为 pooling model                                   │
│      │                                                                 │
│      └── 返回 ModelConfig 对象                                         │
│                                                                        │
├─ (6) self._set_default_chunked_prefill_and_prefix_caching_args()       │
│      设置默认的分块预填充和前缀缓存行为                                  │
│                                                                        │
├─ (7) self.create_load_config()                                         │
│      │                                                                 │
│      └── LoadConfig(load_format=..., download_dir=..., ...)           │
│                                                                        │
├─ (8) CacheConfig(...)                                                  │
│      │                                                                 │
│      ├── block_size (16 by default)                                    │
│      ├── gpu_memory_utilization (0.92 by default)                      │
│      ├── cache_dtype (从 model config 推导)                            │
│      ├── enable_prefix_caching                                         │
│      └── sliding_window (从 model config 读取)                         │
│                                                                        │
├─ (9) ParallelConfig(...)                                               │
│      │                                                                 │
│      ├── tensor_parallel_size / pipeline_parallel_size                 │
│      ├── data_parallel_size / data_parallel_rank                       │
│      ├── master_addr / master_port (多节点通信)                         │
│      └── distributed_executor_backend (mp/ray/external_launcher)       │
│                                                                        │
├─ (10) SchedulerConfig(...)                                             │
│      │                                                                 │
│      ├── max_num_batched_tokens                                        │
│      ├── max_num_seqs                                                  │
│      ├── enable_chunked_prefill                                        │
│      └── policy (fcfs/priority)                                        │
│                                                                        │
├─ (11) 其他子配置:                                                       │
│      ├── LoRAConfig (if enable_lora)                                   │
│      ├── SpeculativeConfig (if --speculative-config)                   │
│      ├── ObservabilityConfig                                           │
│      ├── CompilationConfig                                             │
│      └── StructuredOutputsConfig                                       │
│                                                                        │
└─ (12) VllmConfig(打包所有子配置) ───────────────────────────────────────┘
```

### 3.2 `create_model_config()` 详解

```python
# arg_utils.py:1588-1660
def create_model_config(self) -> ModelConfig:
    return ModelConfig(
        model=self.model,
        tokenizer=self.tokenizer,
        tokenizer_mode=self.tokenizer_mode,
        trust_remote_code=self.trust_remote_code,
        dtype=self.dtype,
        seed=self.seed,
        revision=self.revision,
        code_revision=self.code_revision,
        hf_token=self.hf_token,
        tokenizer_revision=self.tokenizer_revision,
        max_model_len=self.max_model_len,
        quantization=self.quantization,
        quantization_config=self.quantization_config,
        enforce_eager=self.enforce_eager,
        # ... 40+ 个参数 ...
    )
```

**ModelConfig 构造函数内部做了什么（精简版）：**

```
ModelConfig.__init__()
│
├── (1) 加载 HuggingFace config.json
│      使用 transformers.AutoConfig.from_pretrained(model_name)
│      或从本地路径读取 config.json
│      → self.hf_config: PretrainedConfig
│
├── (2) 解析模型架构名
│      hf_config.architectures[0]  →  e.g. "LlamaForCausalLM"
│      → self.hf_text_config (Text 模型配置)
│
├── (3) 确定模型架构枚举
│      通过 MODEL_ARCH_CONFIG_CONVERTORS 查找匹配
│      → self.architecture: ModelArchitectureConfig
│
├── (4) 计算 max_model_len
│      如果用户未指定:
│        → 从 hf_config 读取 (max_position_embeddings, rope_scaling 等)
│        → 考虑 sliding_window
│
├── (5) 确定 model_impl
│      auto → 尝试 vllm 实现 → 回退到 transformers
│
├── (6) 确定 dtype
│      auto → 从 hf_config.torch_dtype → bfloat16/float16
│
├── (7) 加载 generation_config.json
│      用于 eos_token_id, pad_token_id 等
│
├── (8) 注册 multimodal 配置 (如果是多模态模型)
│      → 加载 image_processor, feature_extractor 等
│
└── (9) 解析 runner_type
       "generate" / "pooling" / "draft"
       取决于模型类型: ForCausalLM → generate, ForSequenceClassification → pooling
```

### 3.3 `CacheConfig` 配置

```python
# config/cache.py
@config
class CacheConfig:
    block_size: int = 16                    # KV cache 块大小 (token 数)
    gpu_memory_utilization: float = 0.92    # 显存利用率
    cache_dtype: CacheDType = "auto"        # KV cache 数据类型
    enable_prefix_caching: bool = False     # 是否启用前缀缓存
    prefix_caching_hash_algo = "sha256"     # 哈希算法
    calculate_kv_scales: bool = False       # KV cache 量化缩放因子
    sliding_window: int | None = None       # 滑动窗口大小
    # Mamba 相关
    mamba_cache_dtype: MambaDType = "auto"
    mamba_block_size: int | None = None
    mamba_cache_mode: MambaCacheMode = "all"
```

### 3.4 `ParallelConfig` 配置

```python
# config/parallel.py (关键字段)
@config
class ParallelConfig:
    tensor_parallel_size: int = 1              # TP 大小
    pipeline_parallel_size: int = 1            # PP 大小
    prefill_context_parallel_size: int = 1     # Context Parallelism (预填充)
    decode_context_parallel_size: int = 1      # Context Parallelism (解码)
    data_parallel_size: int = 1                # DP 大小
    data_parallel_rank: int = 0                # DP rank
    data_parallel_backend: str = "mp"          # mp/ray
    distributed_executor_backend: str = None   # mp/ray/external_launcher
    master_addr: str = "127.0.0.1"            # 分布式主节点地址
    master_port: int = 29500                   # 分布式通信端口
    nnodes: int = 1                            # 节点数
    node_rank: int = 0                         # 节点 rank
    disable_custom_all_reduce: bool = False    # 禁用自定义 AllReduce
    enable_expert_parallel: bool = False       # 专家并行 (MoE)
    max_parallel_loading_workers: int = None   # 并行加载权重线程数
```

### 3.5 `SchedulerConfig` 配置

```python
# config/scheduler.py
@config
class SchedulerConfig:
    DEFAULT_MAX_NUM_BATCHED_TOKENS = 2048
    DEFAULT_MAX_NUM_SEQS = 128
    
    runner_type: RunnerType = "generate"       # generate/pooling/draft
    max_num_batched_tokens: int = 2048          # 每批次最大 token 数
    max_num_seqs: int = 128                     # 最大并发序列数
    enable_chunked_prefill: bool = True         # 分块预填充
    policy: SchedulerPolicy = "fcfs"            # fcfs/priority
    max_num_partial_prefills: int = 1           # 并发部分预填充数
    long_prefill_token_threshold: int = 0       # 长预填充阈值
    scheduler_reserve_full_isl: bool = False    # 预留完整输入长度
    watermark: float = 0.0                      # KV cache watermark
    async_scheduling: bool = False              # 异步调度
    stream_interval: int = 1                    # 流输出间隔
```

### 3.6 VllmConfig 聚合

```python
# arg_utils.py:2316-2343
config = VllmConfig(
    model_config=model_config,
    cache_config=cache_config,
    parallel_config=parallel_config,
    scheduler_config=scheduler_config,
    device_config=device_config,
    load_config=load_config,
    offload_config=offload_config,
    attention_config=attention_config,
    mamba_config=mamba_config,
    kernel_config=kernel_config,
    lora_config=lora_config,
    speculative_config=speculative_config,
    compilation_config=compilation_config,
    observability_config=observability_config,
    # ... 更多子配置 ...
)
```

---

## 4. 阶段三：AsyncLLM 初始化

文件：`vllm/v1/engine/async_llm.py`

### 4.1 `AsyncLLM.__init__()` 全貌

```python
# vllm/v1/engine/async_llm.py:73-200
class AsyncLLM(EngineClient):
    def __init__(
        self,
        vllm_config: VllmConfig,
        executor_class: type[Executor],
        log_stats: bool,
        usage_context: UsageContext = UsageContext.ENGINE_CONTEXT,
        ...
    ) -> None:
        # (1) 注册自定义 config 序列化
        maybe_register_config_serialize_by_value()
        
        self.vllm_config = vllm_config
        self.model_config = vllm_config.model_config
        self.observability_config = vllm_config.observability_config
        
        # (2) 初始化 OTLP trace (如果配置了)
        tracing_endpoint = self.observability_config.otlp_traces_endpoint
        if tracing_endpoint is not None:
            init_tracer("vllm.llm_engine", tracing_endpoint)
        
        # (3) 创建 Renderer (模板渲染器)
        self.renderer = renderer = renderer_from_config(self.vllm_config)
        
        # (4) 创建 InputProcessor (请求预处理)
        self.input_processor = InputProcessor(self.vllm_config, renderer)
        
        # (5) 创建 OutputProcessor (输出后处理)
        self.output_processor = OutputProcessor(
            renderer.tokenizer,
            log_stats=self.log_stats,
            stream_interval=self.vllm_config.scheduler_config.stream_interval,
        )
        
        # (6) 创建 EngineCoreClient (IPC 层，触发后台引擎启动!)  
        self.engine_core = EngineCoreClient.make_async_mp_client(
            vllm_config=vllm_config,
            executor_class=executor_class,
            log_stats=self.log_stats,
        )
        
        # (7) 创建 StatLoggerManager (统计日志)
        if self.log_stats:
            self.logger_manager = StatLoggerManager(
                vllm_config=vllm_config,
                engine_idxs=self.engine_core.engine_ranks_managed,
                ...
            )
            self.logger_manager.log_engine_initialized()
        
        # (8) 启动 output handler 后台任务 (如果已有 event loop)
        self.output_handler: asyncio.Task | None = None
        try:
            asyncio.get_running_loop()
            self._run_output_handler()
        except RuntimeError:
            pass  # 没有 event loop，稍后在 add_request 时启动
```

### 4.2 `AsyncLLM.from_vllm_config()` 工厂方法

```python
# async_llm.py:202-229
@classmethod
def from_vllm_config(
    cls,
    vllm_config: VllmConfig,
    enable_log_requests: bool = False,
    disable_log_stats: bool = False,
    ...
) -> "AsyncLLM":
    return cls(
        vllm_config=vllm_config,
        executor_class=Executor.get_class(vllm_config),  # 根据配置选择 Executor 类
        log_requests=enable_log_requests,
        log_stats=not disable_log_stats,
        ...
    )
```

### 4.3 `EngineCoreClient.make_async_mp_client()` —— 启动后台进程

这是真正触发 EngineCore 启动的地方。

```
EngineCoreClient.make_async_mp_client()
│
├── 创建 ZMQ socket pair (用于 IPC)
│     ┌──────────────────────────────────┐
│     │  Frontend Process                │
│     │  ├── EngineCoreClient (ZMQ)      │
│     │  │   ├── input_socket (PUSH)     │──── reqs, aborts, etc ──>│
│     │  │   └── output_socket (PULL)    │<── outputs, stats ───────│
│     │  └── AsyncLLM                    │                           │
│     └──────────────────────────────────┘                           │
│                                                                    │
│     ┌──────────────────────────────────┐                           │
│     │  EngineCore Process              │                           │
│     │  ├── EngineCore                  │                           │
│     │  │   ├── Scheduler               │                           │
│     │  │   └── Executor                │                           │
│     │  └── ZMQ input/output sockets    │                           │
│     └──────────────────────────────────┘                           │
│                                                                    │
├── spawn EngineCore 进程
│     通过 multiprocessing.Process 启动
│     目标函数: run_engine_core
│
└── 等待 EngineCoreReadyResponse (握手完成信号)
      timeout: HANDSHAKE_TIMEOUT_MINS = 5 分钟
      收到后即表示引擎启动完成
```

---

## 5. 阶段四：EngineCore 初始化

文件：`vllm/v1/engine/core.py`

### 5.1 `EngineCore.__init__()` 全流程

```python
# vllm/v1/engine/core.py:99-200+
class EngineCore:
    def __init__(
        self,
        vllm_config: VllmConfig,
        executor_class: type[Executor],
        log_stats: bool,
        ...
    ):
        # (1) 加载插件
        from vllm.plugins import load_general_plugins
        load_general_plugins()
        
        self.vllm_config = vllm_config
        if not vllm_config.parallel_config.data_parallel_rank_local:
            logger.info(
                "Initializing a V1 LLM engine (v%s) with config: %s",
                VLLM_VERSION, vllm_config
            )
        
        self.log_stats = log_stats
        
        # ════════════════════════════════════════════════════════════════
        # (2) 创建 Executor — 这一步 spawn Worker 进程!
        # ════════════════════════════════════════════════════════════════
        self.model_executor = executor_class(vllm_config)
        
        # ════════════════════════════════════════════════════════════════
        # (3) 初始化 KV Cache — 触发 profile_run + 分配缓存
        # ════════════════════════════════════════════════════════════════
        kv_cache_config = self._initialize_kv_caches(vllm_config)
        
        # (4) 创建 StructuredOutputManager
        self.structured_output_manager = StructuredOutputManager(vllm_config)
        
        # ════════════════════════════════════════════════════════════════
        # (5) 创建 Scheduler
        # ════════════════════════════════════════════════════════════════
        Scheduler = vllm_config.scheduler_config.get_scheduler_cls()
        self.scheduler = Scheduler(
            vllm_config=vllm_config,
            kv_cache_config=kv_cache_config,
            structured_output_manager=self.structured_output_manager,
            ...
        )
```

### 5.2 Executor 创建 (MultiprocExecutor)

```
MultiprocExecutor.__init__(vllm_config)
│
├── 确定 world_size = TP * PP * DP
│
├── 为每个 GPU Worker 创建进程
│     │
│     ├── Worker Process 0 (GPU 0, TP rank 0)
│     │   ├── Worker.__init__()
│     │   ├── Worker.init_device()       ← 阶段五
│     │   ├── Worker.load_model()        ← 阶段六
│     │   ├── Worker.determine_available_memory()  ← 阶段七
│     │   └── Worker.compile_or_warm_up_model()    ← 阶段八
│     │
│     ├── Worker Process 1 (GPU 1, TP rank 1)
│     │   └── ... (同上，并行执行)
│     │
│     └── ... (每个 GPU 一个 Worker 进程)
│
└── 等待所有 Worker 初始化完成
```

### 5.3 `_initialize_kv_caches()` 流程

```
_initialize_kv_caches(vllm_config)
│
├── (1) 收集每个 Worker 的 KV Cache Spec
│      self.model_executor.get_kv_cache_spec()
│      → 返回每种 layer 需要的 KV cache 配置
│      → e.g. FullAttentionSpec, SlidingWindowSpec, MambaSpec ...
│
├── (2) 确定 KV Cache block 大小
│      resolve_kv_cache_block_sizes(kv_cache_config)
│
├── (3) 调用 Worker.determine_available_memory()
│      返回可用于 KV cache 的显存字节数
│
├── (4) 计算 num_blocks
│      num_blocks = available_memory / (block_size * kv_cache_size_per_token)
│
├── (5) 更新 CacheConfig
│      cache_config.num_gpu_blocks = num_blocks
│
├── (6) 分配 KV Cache
│      Worker.initialize_from_config(kv_cache_config)
│
└── (7) 编译/预热模型
       Worker.compile_or_warm_up_model()
       → 包含 CUDA Graph capture!
```

---

## 6. 阶段五：Worker.init_device() - 设备初始化

文件：`vllm/v1/worker/gpu_worker.py`

### 6.1 完整流程图

```
Worker.init_device()
│
├── (1) 设置 CUDA 设备
│     │
│     ├── 清除 NCCL_ASYNC_ERROR_HANDLING (Ray 环境下会导致问题)
│     │
│     ├── 计算 local_rank (考虑 DP_LOCAL_RANK 偏移)
│     │    self.local_rank += dp_local_rank * tp_pp_world_size
│     │
│     ├── 解析 physical GPU IDs
│     │    如果设置了 assigned_physical_gpu_ids:
│     │      先将逻辑 rank 映射到物理 GPU
│     │    否则:
│     │      使用 CUDA_VISIBLE_DEVICES 或默认顺序
│     │
│     └── 设置 torch 当前设备
│          self.device = torch.device(f"cuda:{visible_device_index}")
│          torch.accelerator.set_device_index(self.device)
│
├── (2) 检查 dtype 支持
│     current_platform.check_if_supports_dtype(self.model_config.dtype)
│     → 检查 GPU 是否支持 bfloat16/fp8 等
│
├── (3) 初始化分布式环境 (NCCL)
│     │
│     ├── init_distributed_environment()
│     │    ├── world_size = TP * PP * DP
│     │    ├── rank = tp_rank + pp_rank * tp_size + dp_rank * tp_size * pp_size
│     │    ├── init_method = distributed_init_method (默认 "env://")
│     │    └── backend = "nccl"
│     │
│     ├── ensure_model_parallel_initialized()
│     │    创建 TP/PP/CP 通信组
│     │
│     └── 设置 custom_all_reduce (如果启用)
│
├── (4) 设置随机种子
│     set_random_seed(self.model_config.seed)
│
├── (5) 显存快照
│     │
│     ├── gc.collect()
│     ├── torch.accelerator.empty_cache()
│     ├── self.init_snapshot = MemorySnapshot(device=self.device)
│     │    记录:
│     │      ├── free_memory: 可用显存
│     │      ├── total_memory: 总显存
│     │      └── torch_peak: PyTorch 峰值分配
│     │
│     └── self.requested_memory = request_memory(init_snapshot, cache_config)
│          计算公式:
│            requested = init_snapshot.free_memory * gpu_memory_utilization
│                      + init_snapshot.torch_peak (已经分配的 PyTorch 内存)
│
├── (6) 创建 ModelRunner
│     │
│     ├── 根据 use_v2_model_runner 选择:
│     │   V1: vllm.v1.worker.gpu_model_runner.GPUModelRunner
│     │   V2: vllm.v1.worker.gpu.model_runner.GPUModelRunner
│     │
│     └── self.model_runner = GPUModelRunner(vllm_config, device)
│
└── (7) 上报使用统计 (仅 rank 0)
      report_usage_stats(self.vllm_config)
```

### 6.2 `init_device()` 源码

```python
# gpu_worker.py:249-373
@instrument(span_name="Init device")
def init_device(self):
    if self.device_config.device_type == "cuda":
        os.environ.pop("NCCL_ASYNC_ERROR_HANDLING", None)
        parallel_config = self.parallel_config
        
        # Adjust local_rank for DP
        if parallel_config.distributed_executor_backend not in ("ray", "external_launcher") \
           and parallel_config.data_parallel_backend != "ray" \
           and parallel_config.nnodes_within_dp == 1:
            dp_local_rank = self.parallel_config.data_parallel_rank_local
            if dp_local_rank is None:
                dp_local_rank = self.parallel_config.data_parallel_index
            tp_pp_world_size = (
                self.parallel_config.pipeline_parallel_size
                * self.parallel_config.tensor_parallel_size
            )
            self.local_rank += dp_local_rank * tp_pp_world_size
        
        # Set CUDA device
        visible_device_index = (
            current_platform.logical_device_id_to_visible_device_id(self.local_rank)
        )
        self.device = torch.device(f"cuda:{visible_device_index}")
        torch.accelerator.set_device_index(self.device)
        
        # Check dtype support
        current_platform.check_if_supports_dtype(self.model_config.dtype)
        
        # Initialize NCCL
        init_worker_distributed_environment(
            self.vllm_config, self.rank,
            self.distributed_init_method, self.local_rank,
            current_platform.dist_backend,
        )
        
        # Set random seed
        set_random_seed(self.model_config.seed)
        
        # Memory snapshot
        gc.collect()
        torch.accelerator.empty_cache()
        self.init_snapshot = MemorySnapshot(device=self.device)
        self.requested_memory = request_memory(self.init_snapshot, self.cache_config)
```

### 6.3 `init_worker_distributed_environment()` —— NCCL 初始化

```python
# gpu_worker.py:1192-1234
def init_worker_distributed_environment(
    vllm_config: VllmConfig,
    rank: int,
    distributed_init_method: str | None = None,
    local_rank: int = -1,
    backend: str = "nccl",
) -> None:
    parallel_config = vllm_config.parallel_config
    
    # 批量不变性优化
    init_batch_invariance()
    
    # EPLB (Expert Parallel Load Balancing) 环境变量覆盖
    override_envs_for_eplb(parallel_config, ...)
    
    # 设置 custom all-reduce
    set_custom_all_reduce(not parallel_config.disable_custom_all_reduce)
    
    init_method = distributed_init_method or "env://"
    
    # 超时设置
    timeout = None
    if parallel_config.distributed_timeout_seconds is not None:
        timeout = timedelta(seconds=parallel_config.distributed_timeout_seconds)
    
    # 核心：初始化 torch.distributed
    init_distributed_environment(
        parallel_config.world_size,
        rank,
        init_method,
        local_rank,
        backend,        # "nccl"
        timeout,
    )
    
    # 创建 TP/PP/CP 子组
    ensure_model_parallel_initialized(
        parallel_config.tensor_parallel_size,
        parallel_config.pipeline_parallel_size,
        parallel_config.prefill_context_parallel_size,
        parallel_config.decode_context_parallel_size,
    )
```

---

## 7. 阶段六：Worker.load_model() - 模型加载

文件：`vllm/v1/worker/gpu_worker.py`

### 7.1 加载流程

```
Worker.load_model()
│
├── (1) 进入 Memory Pool Context
│     self._maybe_get_memory_pool_context(tag="weights")
│     → 如果启用了 CuMem allocator，在这期间的所有 GPU 分配会被标记为 "weights"
│     → 便于后续 sleep/wake up 时管理
│
├── (2) 降低 PyTorch allocator 分片大小
│     self._scoped_allocator_max_split(max_split_size_mb=20)
│     → 目的：减少显存碎片化
│
├── (3) self.model_runner.load_model()
│     │
│     ├── (3a) 下载模型 (如果本地没有)
│     │    │
│     │    ├── huggingface_hub.snapshot_download(model_name)
│     │    │   下载:
│     │    │     ├── config.json          (~几 KB)
│     │    │     ├── tokenizer.json       (~几 MB)
│     │    │     ├── tokenizer_config.json
│     │    │     ├── *.safetensors        (~几 GB, 模型权重)
│     │    │     └── generation_config.json
│     │    │
│     │    └── 或从本地缓存加载: ~/.cache/huggingface/hub/
│     │
│     ├── (3b) 模型架构解析
│     │    │
│     │    ├── 从 hf_config.architectures 获取架构名
│     │    │   例如: "LlamaForCausalLM", "Qwen2ForCausalLM"
│     │    │
│     │    ├── 通过模型注册表查找实现类
│     │    │   vllm 自带 70+ 模型实现:
│     │    │     vllm/model_executor/models/
│     │    │       ├── llama.py
│     │    │       ├── qwen2.py
│     │    │       ├── deepseek_v2.py
│     │    │       ├── mixtral.py
│     │    │       ├── gemma2.py
│     │    │       └── ...
│     │    │
│     │    └── 如果找不到专属实现 → 回退到通用 transformers 实现
│     │
│     ├── (3c) 实例化模型
│     │    │
│     │    ├── 创建模型对象 (空壳)
│     │    │   model = LlamaForCausalLM(config, ...)
│     │    │
│     │    ├── 应用量化
│     │    │   │
│     │    │   ├── FP8: 替换 linear → fp8 linear
│     │    │   ├── AWQ: 加载 awq 权重 + 替换算子
│     │    │   ├── GPTQ: 加载 gptq 权重 + 替换算子
│     │    │   ├── BitsAndBytes: 使用 4-bit 量化
│     │    │   └── 其他: squeezellm, marlin, ...
│     │    │
│     │    └── 加载权重
│     │         │
│     │         ├── safetensors 格式:
│     │         │   使用 safe_open() 读取 .safetensors 文件
│     │         │   通过 load_weights() 映射到模型参数
│     │         │
│     │         ├── PyTorch 格式:
│     │         │   使用 torch.load() 读取 .bin 文件
│     │         │
│     │         └── 可选: tensorizer 格式 (零拷贝加载)
│     │
│     └── 返回模型对象
│
├── (4) 退出 Memory Pool Context
│
└── (5) 可选: 初始化 WeightTransferEngine
      (用于 RL 训练中的权重更新)
```

### 7.2 模型注册表

```
模型架构 → 实现类的查找路径:

1. vllm/model_executor/models/registry.py (或 __init__.py):
   
   _MODELS = {
       "LlamaForCausalLM": ("llama", "LlamaForCausalLM"),
       "Qwen2ForCausalLM": ("qwen2", "Qwen2ForCausalLM"),
       "MistralForCausalLM": ("mistral", "MistralForCausalLM"),
       "DeepseekV2ForCausalLM": ("deepseek_v2", "DeepseekV2ForCausalLM"),
       "Gemma2ForCausalLM": ("gemma2", "Gemma2ForCausalLM"),
       "Phi3ForCausalLM": ("phi3", "Phi3ForCausalLM"),
       ... (70+ entries)
   }

2. 查找流程:
   config.json → architectures: ["LlamaForCausalLM"]
                          ↓
   _MODELS["LlamaForCausalLM"] → ("llama", "LlamaForCausalLM")
                          ↓
   import vllm.model_executor.models.llama.LlamaForCausalLM
```

### 7.3 Tokenizer 加载

Tokenizer 的加载发生在 Renderer 创建时（比模型加载早）。

```
Renderer.__init__()
│
├── 从 HuggingFace 加载 tokenizer
│     AutoTokenizer.from_pretrained(model_name)
│
├── 加载的关键文件:
│     tokenizer.json           # 词汇表和 merge rules
│     tokenizer_config.json    # tokenizer 配置
│     special_tokens_map.json  # 特殊 token 映射
│
├── 支持的特殊 tokenizer mode:
│     ├── "auto":       自动选择 (默认)
│     ├── "hf":         强制 HuggingFace tokenizer
│     ├── "slow":       强制慢速 tokenizer
│     ├── "mistral":    使用 Mistral 专用 tokenizer
│     ├── "deepseek_v32": DeepSeek V3.2 专用
│     └── "deepseek_v4":  DeepSeek V4 专用
│
└── 加载 chat_template (从 tokenizer_config.json)
```

---

## 8. 阶段七：Memory Profiling - KV Cache 显存计算

文件：`vllm/v1/worker/gpu_worker.py`，`determine_available_memory()`

### 8.1 显存预算全景图

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                            GPU Memory Budget Breakdown                        │
│                                                                              │
│  假设: Tesla H100 80GB, gpu_memory_utilization=0.92                          │
│                                                                              │
│  Total GPU Memory: 80 GB                                                     │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │██████████████████████████████████████████████████████████████████████│    │
│  │                                                                      │    │
│  │ ←────────────── requested_memory = 0.92 × 80 = 73.6 GB ────────────→│    │
│  │                                                                      │    │
│  │ ┌─────────────┬───────────┬─────────────┬──────────────────────────┐ │    │
│  │ │  CUDA       │  Model    │ Activation  │  KV Cache                │ │    │
│  │ │  Context    │  Weights  │ (peak)      │  (计算得出)              │ │    │
│  │ │  & NCCL     │  ~10-15GB │  ~1-5GB     │  ~50-60 GB               │ │    │
│  │ │  buffers    │           │             │                          │ │    │
│  │ │  ~1-2 GB    │           │             │                          │ │    │
│  │ └─────────────┴───────────┴─────────────┴──────────────────────────┘ │    │
│  │                                                                      │    │
│  │ ← 8% unused (默认) ─→│                                              │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  KV Cache 分配:                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  num_blocks = available_kv_cache_memory / block_bytes_per_block       │    │
│  │                                                                      │    │
│  │  block_bytes_per_block = block_size × num_layers × num_kv_heads      │    │
│  │                          × head_size × 2 (K+V) × dtype_bytes         │    │
│  │                                                                      │    │
│  │  例如 Llama-3.1-8B (FP16 KV Cache):                                   │    │
│  │    block_size = 16                                                    │    │
│  │    num_layers = 32                                                    │    │
│  │    num_kv_heads = 8                                                   │    │
│  │    head_size = 128                                                    │    │
│  │    dtype_bytes = 2 (float16)                                          │    │
│  │                                                                      │    │
│  │    per_block = 16 × 32 × 8 × 128 × 2 × 2 (K+V) = 2,097,152 bytes   │    │
│  │             ≈ 2 MB / block                                            │    │
│  │                                                                      │    │
│  │    num_blocks = 50 GB / 2 MB ≈ 25,000 blocks                         │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 8.2 `determine_available_memory()` 源码

```python
# gpu_worker.py:399-552
@torch.inference_mode()
def determine_available_memory(self) -> int:
    # 情况 1: 用户显式指定了 KV cache 内存大小
    if kv_cache_memory_bytes := self.cache_config.kv_cache_memory_bytes:
        self.model_runner.profile_run()  # 仍然需要一次 profile 来编译模型
        logger.info(
            "Initial free memory %s GiB, reserved %s GiB memory for KV Cache "
            "as specified by kv_cache_memory_bytes config ..."
        )
        return kv_cache_memory_bytes
    
    # 情况 2: 自动计算 (默认路径)
    # 执行一次前向传播来 profile 内存使用
    with memory_profiling(
        self.init_snapshot,
        weights_memory=int(self.model_runner.model_memory_usage),
    ) as profile_result:
        self.model_runner.profile_run()  # dummy forward pass
        
        profile_torch_peak = torch.accelerator.memory_stats(self.device).get(
            "allocated_bytes.all.peak", 0
        )
        
        # 估算 CUDA graph 内存
        cudagraph_memory_estimate = 0
        if current_platform.is_cuda() \
           and self.vllm_config.compilation_config.cudagraph_mode != CUDAGraphMode.NONE:
            cudagraph_memory_estimate = self.model_runner.profile_cudagraph_memory()
    
    # 计算各部分内存
    profile_result.torch_peak_increase = (
        profile_torch_peak - profile_result.before_profile.torch_peak
    )
    profile_result.non_kv_cache_memory = (
        profile_result.non_torch_increase       # CUDA context, driver 开销
        + profile_result.torch_peak_increase    # 峰值激活
        + profile_result.weights_memory         # 模型权重
    )
    
    # 最终可用 KV cache 内存
    self.available_kv_cache_memory_bytes = (
        self.requested_memory                    # 我们希望使用的内存
        - profile_result.non_kv_cache_memory     # 减去非 KV cache 开销
        - cudagraph_memory_estimate              # 减去 CUDA graph 内存
    )
    
    return int(self.available_kv_cache_memory_bytes)
```

### 8.3 `memory_profiling` Context Manager 工作原理

```
memory_profiling(init_snapshot, weights_memory)
│
├── before_profile:
│     ├── torch.accelerator.synchronize()
│     ├── gc.collect()
│     ├── 记录 before.torch_peak (PyTorch 已分配峰值)
│     └── 记录 before.free_memory, before.total_memory
│
├── [用户代码: self.model_runner.profile_run()]
│     执行一次包含 max_num_batched_tokens 个 token 的前向传播
│     这会触发 CUDA kernel 编译 (JIT) + 内存分配峰值
│
├── after_profile:
│     ├── torch.accelerator.synchronize()
│     ├── 记录 after.free_memory, after.total_memory
│     └── 记录 after.torch_peak
│
└── 计算:
      non_torch_increase = before.free_memory - after.free_memory
                           - (after.torch_peak - before.torch_peak)
```

---

## 9. 阶段八：CUDA Graph Capture

文件：`vllm/v1/worker/gpu_worker.py`，`compile_or_warm_up_model()`

### 9.1 流程概览

```
compile_or_warm_up_model()
│
├── (1) 编译预热 (VLLM_COMPILE mode)
│     warmup_sizes = compile_sizes - cudagraph_capture_sizes
│     for each size: _dummy_run(size)
│
├── (2) Kernel 预热
│     kernel_warmup(self)
│     → 对 FlashAttention, GEMM, MoE 等 kernel 进行预热
│
├── (3) CUDA Graph Capture (如果 enforce_eager=False)
│     │
│     │  cuda_graph_memory_bytes = self.model_runner.capture_model()
│     │
│     │  ┌─────────────────────────────────────────────────────────┐
│     │  │                CUDA Graph Capture 过程                    │
│     │  │                                                         │
│     │  │  默认 capture sizes: [1, 2, 4, 8, 16, 24, 32, ...,     │
│     │  │                        max_cudagraph_capture_size]      │
│     │  │                                                         │
│     │  │  for batch_size in capture_sizes:                       │
│     │  │      │                                                 │
│     │  │      ├── (a) 创建 dummy input：                         │
│     │  │      │        token IDs, positions, attention mask      │
│     │  │      │                                                 │
│     │  │      ├── (b) 第一次 warmup run (触发 CUDA JIT 编译):    │
│     │  │      │        model.forward(tokens, positions, ...)     │
│     │  │      │                                                 │
│     │  │      ├── (c) torch.cuda.graph() 上下文:                │
│     │  │      │        │                                        │
│     │  │      │        │  CUDA Graph 捕获阶段：                  │
│     │  │      │        │  所有 CUDA kernel 调用被记录而非执行    │
│     │  │      │        │                                        │
│     │  │      │        │  for each layer:                        │
│     │  │      │        │    ├── QKV projection (GEMM)            │
│     │  │      │        │    ├── Rotary Position Embedding        │
│     │  │      │        │    ├── FlashAttention (fused kernel)    │
│     │  │      │        │    ├── O projection (GEMM)              │
│     │  │      │        │    └── FFN (2 × GEMM + activation)      │
│     │  │      │        │                                        │
│     │  │      │        └── → CUDAGraphWrapper 实例              │
│     │  │      │                                                 │
│     │  │      └── (d) 保存 graph, 释放中间内存                  │
│     │  │                                                         │
│     │  └─────────────────────────────────────────────────────────┘    │
│
├── (4) 对比实际与估算的 CUDA graph 内存
│
├── (5) Sampler 预热 (V1)
│     _dummy_sampler_run(hidden_states)
│
├── (6) 重新设置随机种子
│     set_random_seed(self.model_config.seed)
│
├── (7) 激活 JIT 监控
│     activate_triton_jit_monitor()
│
├── (8) 冻结 GC heap
│     freeze_gc_heap()
│
└── (9) 返回 CompilationTimes
```

### 9.2 CUDA Graph 捕获大小序列

```
默认 cudagraph_capture_sizes 通过以下方式确定:

1. max_cudagraph_capture_size (默认值):
   │
   ├── 如果用户指定: 使用用户值
   │
   └── 未指定时的默认规则:
       先从 max_num_seqs 开始，逐步减半直到找到可以捕获的最大大小:
       
       candidate_sizes = []
       size = max_num_seqs
       while size >= 1:
           try:
               capture(size)  # 尝试捕获
               candidate_sizes.append(size)
           except (out of memory, other errors):
               size = size // 2  # 减半重试
       
       典型结果:
          max_num_seqs=256 → cg_sizes = [1, 2, 4, 8, 16, 24, 32, 40, 48, 56, 64]
                                     → max_cudagraph_capture_size = 64

2. 用户可以通过 --cudagraph-capture-sizes 显式指定:
      --cudagraph-capture-sizes "1,2,4,8,16,32"
      或通过编译配置:
      --compilation-config '{"cudagraph_capture_sizes": [1,2,4,8,16,32]}'
```

### 9.3 CUDA Graph 优化原理

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                      Why CUDA Graphs Matter for LLM Inference                 │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  无 CUDA Graph (enforce_eager=True):                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  for each decode step:                                               │     │
│  │    CPU: launch kernel_A()  ──────┐  overhead: ~5-20μs per launch     │     │
│  │    CPU: launch kernel_B()  ──┐   │                                     │     │
│  │    CPU: launch kernel_C()  ┐ │   │                                     │     │
│  │    ... (几十个 kernel)     │ │   │                                     │     │
│  │                            ▼ ▼   ▼                                     │     │
│  │    GPU: execute kernel_A → kernel_B → kernel_C → ...                  │     │
│  │                                                                       │     │
│  │    Total: 很多 CPU→GPU 调度开销，每个 step 消耗 ~100-200μs on CPU   │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│  有 CUDA Graph:                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  for each decode step:                                               │     │
│  │    CPU: launch cuda_graph_replay()   ← 只有一次 CPU→GPU 通信！     │     │
│  │         overhead: ~5-10μs                                            │     │
│  │                            │                                          │     │
│  │    GPU: execute entire graph (所有 kernel)                           │     │
│  │                                                                       │     │
│  │    关键: decode 阶段的 batch size 固定，                                       │     │
│  │    输入输出 tensor 地址固定 → CUDA Graph 完美适用                    │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│  性能收益:                                                                    │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  对于 decode (小 batch)，CUDA Graph 可以将 latency 降低 10-30%       │    │
│  │                                                                      │    │
│  │  例如 Llama-3.1-8B on H100:                                          │    │
│  │     eager mode: ~25ms/token (batch=1)                                │    │
│  │     cuda graph:  ~18ms/token (batch=1)  ← 28% 提升                   │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ⚠️ CUDA Graph 限制:                                                         │
│  - 需要额外的显存 (~1-5GB 取决于模型大小)                                    │
│  - 不能处理动态 shape → 只适用于 decode 阶段                                 │
│  - prefill 阶段 (batch size 变化) 仍使用 eager mode                          │
│  - 捕获时间较长 (每增加一倍的 batch size 都增加开销)                          │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 10. 阶段九：服务就绪

### 10.1 返回主进程后的流程

```
EngineCore 后台进程启动完毕 → EngineCoreReadyResponse
│
├── AsyncLLM.__init__() 返回
│
├── run_server_worker() 继续
│     │
│     ├── build_and_serve(engine_client, listen_address, sock, args)
│     │     │
│     │     ├── build_app(args, supported_tasks, model_config)
│     │     │     │
│     │     │     ├── 创建 FastAPI 实例
│     │     │     ├── 注册路由:
│     │     │     │     ├── /v1/chat/completions
│     │     │     │     ├── /v1/completions
│     │     │     │     ├── /v1/models
│     │     │     │     ├── /v1/embeddings
│     │     │     │     ├── /health
│     │     │     │     ├── /version
│     │     │     │     └── /v1/tokenize
│     │     │     ├── 添加中间件:
│     │     │     │     ├── CORS (跨域)
│     │     │     │     ├── Authentication (API key)
│     │     │     │     ├── X-Request-ID
│     │     │     │     └── Scaling (弹性扩缩容)
│     │     │     └── 注册异常处理器
│     │     │
│     │     ├── init_app_state(engine_client, app.state, args)
│     │     │     │
│     │     │     ├── 设置 served_model_names
│     │     │     ├── 创建 OpenAIServingModels
│     │     │     ├── 创建 OpenAIServingRender
│     │     │     └── 创建 ServingTokenization
│     │     │
│     │     └── serve_http(app, sock=..., ...)
│     │           │
│     │           └── 启动 uvicorn server
│     │                 ├── host: 0.0.0.0 (默认) or --host
│     │                 ├── port: 8000 (默认) or --port
│     │                 └── log_level: info (默认)
│     │
│     └── shutdown_task (await until server stops)
│
└── Server Ready!
```

### 10.2 Health Endpoint

```
GET /health

处理流程:
  AsyncLLM.check_health()
    → engine_core.resources.engine_dead? → 是否还在运行
    → output_handler.done()?              → output handler 是否挂了

返回:
  200 OK        → engine is healthy
  500 Error     → engine is dead/errored
```

---

## 11. 启动日志逐行解读

以下是在启动 `Llama-3.1-8B-Instruct` on 1xH100 时的典型日志，逐行解释。

### 11.1 标准启动日志

```
# 1. 版本和模型信息
INFO: vLLM API server version 0.11.0
INFO: model: meta-llama/Llama-3.1-8B-Instruct

  → api_server.py:522-523 log_version_and_model()
  → 打印 vLLM 版本和模型名，确认命令行参数被正确接收


# 2. 非默认参数日志
INFO: Non-default args: {'max_model_len': 32768, 'gpu_memory_utilization': 0.92, ...}

  → api_server.py:524 log_non_default_args()
  → 只打印和默认值不同的参数，方便调试


# 3. 模型配置加载
INFO: Using model implementation: vllm

  → ModelConfig 确定使用 vLLM 原生实现（而非 transformers 回退）


# 4. Tokenizer 加载
INFO: Loading tokenizer from meta-llama/Llama-3.1-8B-Instruct
INFO: Tokenizer loaded successfully. Vocab size: 128256

  → renderer_from_config() → AutoTokenizer.from_pretrained()


# 5. 引擎开始初始化 (EngineCore 进程)
INFO: Initializing a V1 LLM engine (v0.11.0) with config: VllmConfig(...)

  → EngineCore.__init__() 入口，打印完整配置


# 6. 分布式初始化
INFO: Initializing distributed environment with backend=nccl, world_size=1, ...

  → init_worker_distributed_environment()
  → world_size=1 表示单 GPU 单机 (无 TP/PP)


# 7. 设备初始化
DEBUG: worker init memory snapshot: MemorySnapshot(free_memory=..., total_memory=...)
DEBUG: worker requested memory: 73.60GiB

  → Worker.init_device() 中的 MemorySnapshot
  → 80GB × 0.92 ≈ 73.6 GB 请求内存


# 8. 模型加载
INFO: Loading model from meta-llama/Llama-3.1-8B-Instruct
INFO: Model loading took 8.45 seconds

  → Worker.load_model()
  → 权重加载耗时，取决于磁盘和网络速度


# 9. 模型加载详情 (V1/V2 model runner)
INFO: Model weights loaded. Memory usage: 14.96 GiB

  → model_runner.model_memory_usage 记录权重大小
  → Llama-3.1-8B 在 FP16 下约 15GB


# 10. 内存 profiling
INFO: Available KV cache memory: 52.34 GiB

  → Worker.determine_available_memory() 的结果
  → 73.6 - 14.96 (weights) - 2.5 (activations) - 1.5 (CUDA context) - 2.3 (cudagraph estimate) ≈ 52.3


# 11. KV Cache 分配
INFO: KV Cache blocks: 25600, block_size: 16
INFO: KV Cache memory: 52.34 GiB, 25600 blocks

  → _initialize_kv_caches() 计算出的 num_blocks
  → 每个 block 约 2MB


# 12. CUDA Graph 捕获
INFO: Capturing CUDA graphs for batch sizes: [1, 2, 4, 8, 16, 24, 32, 40, 48, 56, 64]
INFO: CUDA graph capture took 35.21 seconds

  → compile_or_warm_up_model() → capture_model()
  → 每个 batch size 耗时约 3 秒


# 13. CUDA Graph 内存
INFO: CUDA graph pool memory: 2.15 GiB (actual), 2.30 GiB (estimated), difference: 0.15 GiB (6.5%).

  → 实际和估算的 CUDA graph 内存对比


# 14. 调度器就绪
INFO: Scheduler initialized. max_num_seqs=256, max_num_batched_tokens=2048

  → EngineCore 中 Scheduler 创建完成


# 15. 引擎就绪
INFO: EngineCore initialization complete.

  → EngineCore 发送 EngineCoreReadyResponse


# 16. 服务就绪
INFO: Supported tasks: ('generate',)
INFO: Starting vLLM server on http://0.0.0.0:8000

  → build_and_serve() → serve_http()
  → 此时 /health 返回 200 OK


# 17. Uvicorn 日志
INFO: Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)

  → uvicorn 接管 HTTP 请求处理


# 18. 首次请求时的 JIT 监控 (如果启用)
INFO: Triton JIT monitor activated

  → 后续推理中如果有新的 JIT 编译，会打印警告
```

### 11.2 多 GPU 时的额外日志 (TP=2)

```
# 每个 GPU 一个 Worker 进程，所以日志会翻倍
INFO: Initializing worker process 1 (rank=1, local_rank=1)
INFO: Initializing worker process 0 (rank=0, local_rank=0)
INFO: Worker 0: Model weights loaded. Memory usage: 7.48 GiB
INFO: Worker 1: Model weights loaded. Memory usage: 7.48 GiB
  → TP=2 时每个 GPU 只持有一半的权重


# NCCL 通信检测
INFO: NCCL version: 2.21.5
INFO: AllReduce test: bandwidth=324.5 GB/s
  → custom_all_reduce 初始化完成


# CUDA Graph 在每个 Worker 上独立捕获
INFO: Worker 0: Capturing CUDA graphs... (took 35.21s)
INFO: Worker 1: Capturing CUDA graphs... (took 35.18s)
  → 各 GPU 独立捕获，耗时相近
```

---

## 12. 常见失败与修复

### 12.1 OOM (Out of Memory)

```
错误样本:
  torch.cuda.OutOfMemoryError: CUDA out of memory. 
  Tried to allocate 256.00 MiB (GPU 0; 80.00 GiB total capacity; 
  78.50 GiB already allocated; ...)

根因分析:
  显存不足，通常是以下原因之一:
  1. gpu_memory_utilization 设置太高
  2. max_model_len 设置太大 → KV cache 占用过多
  3. 模型本身太大（权重 + KV cache 超出显存）
  4. 其他进程占用了显存（nvidia-smi 检查）
  5. CUDA graph 占用了预期外的显存

修复方案 (按优先级):
  1. 降低 gpu_memory_utilization:
     --gpu-memory-utilization 0.85  (默认 0.92)
     
  2. 降低 max_model_len:
     --max-model-len 8192  (默认从 config.json 读取)
     
  3. 使用量化减少权重显存:
     --quantization fp8  (需要 FP8 权重)
     --quantization awq   (需要 AWQ 量化权重)
     --dtype half  (默认，比 bfloat16 略小)
     
  4. 禁用 CUDA Graph (减少 CUDA graph 显存):
     --enforce-eager
     或: --compilation-config '{"cudagraph_mode": "none"}'
     
  5. 启用 prefix caching 可略微减少 KV cache 使用:
     --enable-prefix-caching
     
  6. 减小 block_size (更细粒度的 KV cache 管理):
     --block-size 8  (默认 16，减半可减少碎片)
     
  7. 检查是否有其他进程占用 GPU:
     nvidia-smi  # 查看显存使用
     fuser -v /dev/nvidia*  # 查看占用 GPU 的进程
     
  8. 终极方案: 扩充 GPU 或使用 TP (多 GPU 分片):
     --tensor-parallel-size 2  (2 GPU 分片)

调试技巧:
  export VLLM_LOGGING_LEVEL=DEBUG  # 打印详细的显存分配日志
  # 查看显存快照:
  # 日志中搜索: "worker init memory snapshot"
```

### 12.2 NCCL 超时/通信失败

```
错误样本:
  RuntimeError: NCCL error in: ../torch/csrc/distributed/c10d/ProcessGroupNCCL.cpp
  unhandled system error (run with NCCL_DEBUG=INFO for details)
  
  RuntimeError: [Rank 1] Watchdog caught collective operation timeout
  Work sequence: 42
  Last enqueued work: allreduce

根因分析:
  1. 网络配置问题（多节点部署）
  2. NCCL 版本不兼容
  3. GPU 拓扑问题（NVLink 断连）
  4. CUDA 驱动/NCCL 版本不匹配
  5. InfiniBand 配置错误（多节点）

修复方案:
  1. 增加 NCCL 超时:
     --distributed-timeout-seconds 600  (默认 300 秒，增加超时)
     
  2. 检查 NCCL 版本和 CUDA 版本兼容:
     python -c "import torch; print(torch.cuda.nccl.version())"
     nvidia-smi  # 查看 CUDA 驱动版本
     
  3. 调试 NCCL:
     export NCCL_DEBUG=INFO
     export NCCL_DEBUG_SUBSYS=ALL
     
  4. 单节点多 GPU 环境:
     确保 NVLink/NVSwitch 工作正常:
     nvidia-smi topo -m  # 查看 GPU 拓扑
     
  5. 多节点环境:
     检查网络接口:
     ifconfig  # 确认 NIC 配置
     # NCCL 默认使用第一个网络接口，可通过环境变量指定:
     export NCCL_SOCKET_IFNAME=eth0
     
  6. 单 GPU 运行 (避免 NCCL):
     确保 --tensor-parallel-size 1 (默认)
     
  7. 禁用 custom all-reduce:
     --disable-custom-all-reduce
```

### 12.3 模型不受支持

```
错误样本:
  ValueError: Model architecture 'UnknownForCausalLM' is not supported by vLLM.
  
  RuntimeError: Failed to load model: <model_name>
  Model architecture XxxForCausalLM not found in vLLM model registry.

根因分析:
  1. 模型架构未在 vLLM 的 _MODELS 注册表中
  2. 自定义模型需要 trust_remote_code=True
  3. vLLM 版本太低，不支持该架构

修复方案:
  1. 检查 vLLM 支持的模型列表:
     https://docs.vllm.ai/en/latest/models/supported_models/
     
  2. 升级 vLLM:
     pip install --upgrade vllm
     
  3. 尝试 trust_remote_code:
     --trust-remote-code
     注意: 允许执行远程代码，仅在信任模型来源时使用
     
  4. 对于新模型，可能需要添加 --model-impl 参数:
     --model-impl transformers  (强制使用 transformers 实现)
     
  5. 如果模型使用自定义 architecture:
     # 检查 config.json 中的 architectures 字段:
     cat ~/.cache/huggingface/hub/models--xxx/config.json | jq '.architectures'
     # 如果架构名不在支持列表中，可能需要等待 vLLM 更新
```

### 12.4 启动慢

```
现象:
  启动需要 2-10 分钟
  
原因分析:
  ┌───────────────────────────────────────────────────────────────┐
  │  Phase                     │  典型耗时        │  说明          │
  ├───────────────────────────────────────────────────────────────┤
  │  权重下载(首次)             │  1-30 min        │  取决于网速    │
  │  HuggingFace config 加载   │  1-5 sec         │  HTTP 请求     │
  │  Tokenizer 加载            │  1-3 sec         │  读取 json     │
  │  模型权重加载               │  5-60 sec        │  safetensors   │
  │  NCCL 初始化 (多GPU)       │  5-30 sec        │  allreduce 测试│
  │  内存 profiling             │  2-10 sec        │  首次 forward  │
  │  CUDA Graph capture        │  10-120 sec      │  每个大小 3-5s │
  └───────────────────────────────────────────────────────────────┘
  
加速方案:
  1. 预先下载模型:
     huggingface-cli download meta-llama/Llama-3.1-8B-Instruct
     
  2. 使用 --download-dir 指定已下载目录:
     --download-dir /data/models/
     
  3. 禁用 CUDA Graph (跳过最慢的阶段):
     --enforce-eager
     或: --compilation-config '{"cudagraph_capture_sizes": []}'
     
  4. 减少 CUDA Graph 捕获大小:
     --cudagraph-capture-sizes "1,2,4,8"
     或: --max-cudagraph-capture-size 8
     
  5. 单 GPU 无需 NCCL，跳过 NCCL 初始化 (自动)
  
  6. 使用 tensorizer 预序列化权重 (极速加载):
     pip install tensorizer
     # 需要先 tensorize 模型
```

### 12.5 Transformers 版本不兼容

```
错误样本:
  ImportError: cannot import name 'LlamaForCausalLM' from 'transformers'
  AttributeError: 'LlamaConfig' object has no attribute 'rope_scaling'

修复方案:
  pip install transformers --upgrade  # 确保最新版本
  # 或安装 vLLM 推荐的版本:
  pip install vllm[transformers]
```

---

## 13. 各阶段耗时分析

### 13.1 典型耗时分解 (Llama-3.1-8B on H100, SSD 存储)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                     vLLM Startup Time Breakdown (Llama-3.1-8B, 1xH100)        │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Total startup: ~55 seconds                                                   │
│                                                                              │
│  Argument Parsing     ▏ 0.1s  ( 0.2%)                                        │
│  Config Construction  ▎ 0.5s  ( 0.9%)                                        │
│  Tokenizer Loading    ▎ 1.0s  ( 1.8%)                                        │
│  Weight Loading       ██████ 8.5s  (15.5%)  ← 磁盘 I/O 密集                  │
│  Device Init+NCCL     ▎ 1.5s  ( 2.7%)                                        │
│  Memory Profiling     ██ 3.0s  ( 5.5%)   ← 首次 CUDA kernel 编译             │
│  KV Cache Alloc       ▌ 0.5s  ( 0.9%)                                        │
│  CUDA Graph Capture   ████████████████████████ 35.0s  (63.6%)  ← JIT 密集    │
│  Scheduler Init       ▏ 0.2s  ( 0.4%)                                        │
│  Server Setup         ▌ 0.5s  ( 0.9%)                                        │
│  Other                ██ 4.2s  ( 7.6%)   ← 日志、中间件等                     │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  ▏▎▌███                                                                 │    │
│  │  0               10        20        30        40        50   55s     │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  关键优化点:                                                                  │
│  1. CUDA Graph Capture 占比 63% — 使用更少的 capture sizes 可大幅降低启动时间 │
│  2. Weight Loading 占比 16% — 使用 NVMe SSD 或 tensorizer 加速               │
│  3. Memory Profiling 占比 5% — 涉及 CUDA JIT，首次启动不可避免               │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 13.2 TP=2 时的耗时变化

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                  vLLM Startup with TP=2 (2xH100, Llama-3.1-8B)               │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Workers 并行执行大部分操作，但由于:                                          │
│    - NCCL 同步点 (allreduce)          +5s                                    │
│    - 两个 worker 需要协调              +2s                                    │
│    - 每个 worker 权重减半              -2s (更快加载)                         │
│    - NCCL allreduce benchmark test     +5s                                    │
│                                                                              │
│  Total ~60s (略慢于单 GPU，但支持更大模型)                                     │
│                                                                              │
│  显存使用 (每个 GPU):                                                         │
│    单 GPU:   权重 15GB + KV Cache 52GB = 67GB (80GB 的 84%)                  │
│    TP=2:    权重 7.5GB + KV Cache 55GB = 62.5GB (每个 GPU)                   │
│             → TP 让每个 GPU 的权重减半，KV cache 空间更大                     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 13.3 大模型启动优化 (70B 级别)

```
以 Llama-3.1-70B 为例 (8xH100, TP=8):

  Total ~180s (3 分钟)
  
  各阶段:
    权重下载(如需要):  0-600s  (取决于网络，可预先下载)
    权重加载:         30s     (8 个 worker 并行加载，每个约 9GB)
    NCCL 初始化:      20s     (8 GPU allreduce 测试)
    Memory Profiling: 15s     (更大的模型 → 更多 CUDA kernel 编译)
    CUDA Graph:       90s     (更多层 → 每个 size 捕获更慢)
    
  优化建议:
    --max-cudagraph-capture-size 16    (减少到 5 个 capture sizes)
    --block-size 32                     (增大 block 减少管理开销)
    --max-num-seqs 64                   (降低并发)
```

### 13.4 量化模型启动 (FP8/AWQ)

```
AWQ Llama-3.1-8B on 1xH100:

  权重加载:        4s     (FP16: 8.5s → AWQ: 权重文件更小)
  Memory Profiling: 2s     (量化 kernel 不同)
  CUDA Graph:       30s    (稍快，因为计算更少)
  Total: ~42s               (比 FP16 快 ~25%)

FP8 Llama-3.1-8B on 1xH100 (需要 FP8 权重):

  权重加载:        6s     (FP8 文件大小 ~ FP16 的 50%)
  Memory Profiling: 3s     
  CUDA Graph:       32s    
  Total: ~47s
```

---

---

## 15. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| AsyncLLM | 前台的"大厅接待员"：收请求、调后台、送回结果 | 第一章术语表 |
| EngineCore | 后台的"总工程师"：独立进程，统一管理调度和执行 | 第一章术语表 |
| Config 对象簇 | 启动参数的"身份证全家桶"：ModelConfig、CacheConfig、ParallelConfig 等 | 第四章术语表 |
| VllmConfig | 把所有子配置打包成一个大包裹，一键传递给各个组件 | 第四章术语表 |
| CUDA Graph Capture | 启动时的"演习"：把不同 batch size 前向传播录制成图，推理时直接重放 | 第五章术语表 |

---

## 16. A800 部署场景举例

### 16.1 场景：Qwen2.5-32B-Instruct-AWQ on 2×A800 80GB

```bash
# 2×A800 + AWQ 量化，TP=2 部署命令
vllm serve /data/models/Qwen2.5-32B-Instruct-AWQ \
    --host 0.0.0.0 --port 8000 \
    --dtype auto \
    --quantization awq \
    --tensor-parallel-size 2 \
    --max-model-len 32768 \
    --gpu-memory-utilization 0.92 \
    --max-num-seqs 64 \
    --enforce-eager \
    --disable-log-requests
```

**为什么这样配？**
- `--tensor-parallel-size 2`：2×A800 通过 NVLink 桥接，每卡约持 8.5 GB 权重，剩余显存全部分给 KV Cache
- `--enforce-eager`：跳过 CUDA Graph capture 可节省启动时间约 35 秒，A800 上 eager decode 延迟仍然可接受
- `--gpu-memory-utilization 0.92`：AWQ 后显存充裕，92% 全部分给 KV Cache

### 16.2 场景：Qwen2.5-72B-Instruct-GPTQ-Int4 on 4×A800

```bash
# 4×A800 + GPTQ，TP=4 部署命令
vllm serve /data/models/Qwen2.5-72B-Instruct-GPTQ-Int4 \
    --host 0.0.0.0 --port 8000 \
    --dtype auto \
    --quantization gptq \
    --tensor-parallel-size 4 \
    --max-model-len 32768 \
    --gpu-memory-utilization 0.90 \
    --max-num-seqs 32 \
    --enable-chunked-prefill \
    --disable-log-requests
```

**启动日志关键行解读（两种配置通用）**：
- `Model weights loaded. Memory usage: X.XX GiB` → 确认权重加载成功
- `Available KV cache memory: XX.XX GiB` → KV Cache 可用空间
- `KV Cache blocks: XXXXX, block_size: 16` → block 数量和粒度
- `CUDA graph capture took XX.XX seconds` → 若未用 `--enforce-eager`，这是耗时大头

---

## 17. 上下游串联

```
vLLM 启动流程在完整推理链中的位置

┌──────────────────────────────────────────────────────────────────┐
│                     端到端推理请求链路                              │
│                                                                   │
│  用户请求                                                          │
│    │                                                              │
│    ▼                                                              │
│  FastAPI 路由 (/v1/chat/completions)   ← 本阶段产物：服务已就绪      │
│    │                                                              │
│    ▼                                                              │
│  AsyncLLM.process_request()                                       │
│    │                                                              │
│    ▼                                                              │
│  EngineCore.step() ─── Scheduler.schedule() ─── 02-调度器核心      │
│    │                                                              │
│    ▼                                                              │
│  ModelRunner.execute_model() ─── 05-Worker执行                    │
│    │                                                              │
│    ▼                                                              │
│  KV Cache read/write ─── 03-BlockManager                          │
│    │                                                              │
│    ▼                                                              │
│  模型前向传播 ─── 04-模型加载（本阶段产物：模型已加载到GPU）          │
│    │                                                              │
│    ▼                                                              │
│  Sampler.sample() ──→ 返回 token                                  │
│                                                                   │
│  本文档覆盖：从命令行参数到服务 Ready 的全过程                        │
│  前置依赖：无（本文档是整个系列的起点）                               │
│  后续阅读：02-调度器核心（理解请求到来后如何被调度执行）               │
└──────────────────────────────────────────────────────────────────┘
```

## 14. 深入学习资源

### 14.1 官方资源

| 资源 | 链接 | 说明 |
|------|------|------|
| vLLM 官方文档 | https://docs.vllm.ai/ | 完整的用户指南和 API 参考 |
| vLLM GitHub | https://github.com/vllm-project/vllm | 源码仓库 |
| vLLM 论文 (SOSP 2023) | https://arxiv.org/abs/2309.06180 | PagedAttention 原始论文 |
| vLLM 支持的模型 | https://docs.vllm.ai/en/latest/models/supported_models/ | 模型兼容性列表 |
| vLLM 设计文档 | https://docs.vllm.ai/en/latest/design/overview/ | 架构设计概述 |

### 14.2 关键技术论文

| 论文 | 主题 | 关键提出 |
|------|------|----------|
| PagedAttention (vLLM paper) | KV Cache 管理 | 虚拟内存分页管理 KV Cache |
| FlashAttention (Dao et al.) | 注意力优化 | 融合注意力 kernel，减少显存 |
| FlashAttention-2 | 注意力优化 | 更好的并行化策略 |
| FlashAttention-3 | 注意力优化 | H100 专门优化 |
| Continuous Batching (Orca) | 调度优化 | 迭代级调度，提高 GPU 利用率 |
| Splitwise | 分离架构 | Prefill/Decode 分离 |
| Sarathi-Serve | Chunked Prefill | 分块预填充，减少 tail latency |

### 14.3 源码阅读路径 (推荐顺序)

```
vLLM 源码阅读推荐路径 (由浅入深):

  入门级:
  1. vllm/sampling_params.py          # 采样参数，约 200 行
  2. vllm/sequence.py                 # 序列数据结构定义
  3. vllm/config/model.py             # ModelConfig，理解模型的参数
  
  中级:
  4. vllm/engine/arg_utils.py         # 参数解析，所有 CLI 参数一目了然
  5. vllm/entrypoints/openai/api_server.py  # API Server 入口
  6. vllm/v1/engine/async_llm.py      # AsyncLLM，引擎的异步封装
  7. vllm/v1/engine/core.py           # EngineCore，核心循环
  
  深入:
  8. vllm/v1/worker/gpu_worker.py     # GPU Worker, 最核心的 1000+ 行
  9. vllm/v1/worker/gpu_model_runner.py  # ModelRunner, 模型执行 (~5000+ 行)
  10. vllm/v1/core/sched/             # 调度器实现
  11. vllm/v1/attention/backends/     # 各种注意力后端实现
  
  进阶:
  12. vllm/model_executor/models/     # 具体模型实现
  13. vllm/model_executor/layers/     # 自定义算子层
  14. vllm/compilation/               # CUDA Graph 和编译优化
  15. vllm/distributed/               # 分布式通信实现
```

### 14.4 调试技巧

```bash
# 1. 启用详细日志
export VLLM_LOGGING_LEVEL=DEBUG

# 2. 启用 NCCL 调试
export NCCL_DEBUG=INFO
export NCCL_DEBUG_SUBSYS=ALL

# 3. 启用 PyTorch CUDA 内存调试
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTORCH_NO_CUDA_MEMORY_CACHING=1

# 4. Profiling 启动过程
python -m cProfile -o startup.prof \
  -m vllm.entrypoints.openai.api_server --model <model> &
# 等待启动完成后 kill
snakeviz startup.prof  # 可视化 profile 结果

# 5. 使用 PyTorch profiler 追踪启动过程
# 在启动脚本中或环境变量中启用:
export VLLM_TORCH_PROFILER_DIR=/tmp/vllm_trace
# 然后查看 trace:
# tensorboard --logdir /tmp/vllm_trace

# 6. 查看各阶段耗时
export VLLM_LOGGING_LEVEL=INFO
# 搜索关键日志:
# "Model loading took"
# "CUDA graph capture took"
# "available KV cache memory"

# 7. 检查 GPU 拓扑
nvidia-smi topo -m
# 确认 GPU 间的 NVLink/P2P 连接状态

# 8. 检查模型文件完整性
ls -la ~/.cache/huggingface/hub/models--meta-llama--Llama-3.1-8B-Instruct/snapshots/*/
# 确认所有 .safetensors 文件都存在且大小正确
```

### 14.5 进一步实验

```
学习建议:

1. 修改并观察:
   - 修改 gpu_memory_utilization=0.5 → 观察 num_blocks 变化
   - 修改 max_model_len → 观察 KV cache 大小变化
   - 修改 block_size → 观察 block 数量和碎片
   - 启用 enforce_eager → 跳过 CUDA graph，看性能差异
   - 使用 --max-cudagraph-capture-size 4 → 观察启动时间和推理性能

2. 添加自定义日志:
   在 Worker.init_device() 中插入:
     logger.info("MY_DEBUG: init_snapshot = %s", self.init_snapshot)
   在 determine_available_memory() 后插入:
     logger.info("MY_DEBUG: available_kv_cache_memory = %d", ...)

3. 用小型模型做实验 (更快的迭代):
   --model Qwen/Qwen2-0.5B-Instruct  # 只有 0.5GB 权重，启动极快
   --model TinyLlama/TinyLlama-1.1B-Chat-v1.0

4. 阅读 vLLM 测试代码:
   tests/v1/engine/test_engine_core.py
   tests/v1/worker/test_gpu_worker.py
   → 了解各组件如何被单独测试
```

---

> **总结**: vLLM 的启动流程是一个精密的编排过程：从命令行参数的反射式解析，到 HuggingFace 配置的加载，再到多进程 Worker 的创建和分布式环境的初始化。核心的内存管理通过 profiling 前向传播来精确计算 KV cache 可用空间，CUDA graph capture 则在启动时通过遍历多种 batch size 来消除推理时的 CPU kernel launch 开销。理解这个过程对于优化部署配置和排查启动问题至关重要。
>
> **关键文件路径:**
> - 入口: `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/entrypoints/openai/api_server.py`
> - 参数: `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/engine/arg_utils.py`
> - 异步引擎: `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/v1/engine/async_llm.py`
> - EngineCore: `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/v1/engine/core.py`
> - GPU Worker: `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/v1/worker/gpu_worker.py`
> - Model Runner: `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/v1/worker/gpu_model_runner.py`
> - 配置: `/data/yueyameng/deepseek/lib/python3.10/site-packages/vllm/config/`

---

*文档版本: 基于 vLLM 0.11.x (2026-07), V1 引擎架构*  
*写作风格: 中文技术文档，适合深度学习与源码阅读*
