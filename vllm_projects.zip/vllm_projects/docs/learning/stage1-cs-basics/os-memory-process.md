# OS、内存与进程：AI Infra 工程师的底层基石

> 本文面向 vLLM/CUDA/GPU 推理方向的 AI Infra 工程师，深入讲解操作系统内存管理与进程调度的核心概念，
> 并阐明它们与 GPU 推理性能之间的直接关联。每一个概念都会落到"这对 vLLM 意味着什么"。

---

## 目录

1. [虚拟内存深度解析](#1-虚拟内存深度解析)
2. [PagedAttention 为何有效：OS 虚拟内存的类比](#2-pagedattention-为何 By效-os-虚拟内存的类比)
3. [进程与线程](#3-进程与线程)
4. [内存层次结构](#4-内存层次结构)
5. [NUMA 架构](#5-numa-架构)
6. [CPU-GPU 数据传输](#6-cpu-gpu-数据传输)
7. [大页 (Huge Pages)](#7-大页-huge-pages)
8. [内存分配器内部实现](#8-内存分配器内部实现)
9. [CUDA 内存管理](#9-cuda-内存管理)
10. [进程调度](#10-进程调度)
11. [信号处理](#11-信号处理)
12. [文件 I/O 与模型加载](#12-文件io-与模型加载)
13. [进程间通信 (IPC)](#13-进程间通信-ipc)
14. [实战场景：vLLM OOM 时发生了什么](#14-实战场景vllm-oom-时发生了什么)
15. [与 AI Infra 的关联](#与-ai-infra-的关联)
16. [深入学习资源](#深入学习资源)

---

## 1. 虚拟内存深度解析

### 1.1 为什么需要虚拟内存

物理内存是有限的、碎片化的。虚拟内存提供三个核心能力：

1. **隔离 (Isolation)**：每个进程拥有独立的地址空间，进程 A 无法直接访问进程 B 的内存。
2. **抽象 (Abstraction)**：进程看到的是连续的地址空间，而物理内存可以是零散分布的。
3. **超卖 (Overcommit)**：进程可以分配超过物理内存大小的虚拟地址空间，OS 按需分配物理页。

```
  进程 A 的虚拟地址空间           物理内存 (Physical RAM)
+------------------------+      +------------------------+
| 0x0000_0000_0000       |      |                        |
|        ...             |      |  Frame 0: [进程B数据]   |
| 0x0000_7f00_0000 (heap)|      |  Frame 1: [进程A代码]   |
| 0x0000_7f80_0000 (mmap)| ---> |  Frame 2: [进程A堆]    |
| 0x0000_7fff_0000 (libc)|      |  Frame 3: [空闲]       |
| 0x0000_7fff_ffff (stack)|     |  Frame 4: [进程A栈]    |
|        ...             |      |  Frame 5: [进程B堆]    |
| 0xffff_ffff_ffff       |      |        ...             |
+------------------------+      +------------------------+
     虚拟地址 (Virtual)              物理帧 (Physical Frame)
         |                                ^
         |    页表映射 (Page Table)        |
         +--------------------------------+
```

### 1.2 多级页表：解决页表过大的问题

在 64 位系统上，地址空间达 2^64 字节。如果使用单级页表，以 4KB 页大小计算，
页表条目数 = 2^64 / 2^12 = 2^52 条，每条 8 字节，需要 32PB —— 不可行。

**解决方案**：多级页表。只在虚拟地址实际被使用时才分配中间页表。

以 x86-64 的 4 级页表为例（Linux 内核配置为 4 级或 5 级）：

```
虚拟地址 (48-bit effective, bits 63:48 are sign-extended)
+-----+-----+-----+-----+-----+------------+
| 47:39 | 38:30 | 29:21 | 20:12 |   11:0    |
| PML4  | PDPT  |  PD   |  PT   |  Offset   |
|  9b   |  9b   |  9b   |  9b   |   12b     |
+-----+-----+-----+-----+-----+------------+
  |      |       |       |         |
  |      |       |       |         +---> 页内偏移 (4KB = 2^12)
  |      |       |       +---> 页表 (PT) 索引, 512 项, 每个指向 4KB 页
  |      |       +---> 页目录 (PD) 索引, 512 项
  |      +---> 页目录指针表 (PDPT) 索引, 512 项
  +---> PML4 (Page Map Level 4) 索引, 512 项

CR3 寄存器
    |
    v
  PML4[0..511]
    |                PDPT[0..511]
    +---> PML4E[i] --------------> PDPTE[j]
                                       |
                                       +---> PDE[k] ---------> PTE[m]
                                                                   |
                                                                   +---> 4KB 物理页
                                                                         |
                                                                   [实际数据]
```

**一次完整的页表遍历 (Page Table Walk)**：

```
1. CPU 发出虚拟地址 0x0000_7f8a_1234_5abc
2. MMU 取 CR3 → 找到 PML4 基地址
3. MMU 用 bits[47:39] 索引 PML4，读取 PML4 Entry
   - 检查 Present 位：如果为 0 → Page Fault!
   - 检查权限位：如果写只读页 → Page Fault!
4. MMU 从 PML4E 中提取 PDPT 基地址
5. MMU 用 bits[38:30] 索引 PDPT，读取 PDPT Entry
6. MMU 从 PDPTE 中提取 PD 基地址
7. MMU 用 bits[29:21] 索引 PD，读取 PD Entry
8. MMU 从 PDE 中提取 PT 基地址
   - 如果 PDE 的 PS (Page Size) 位为 1 → 这是 2MB 大页，直接得到物理地址
9. MMU 用 bits[20:12] 索引 PT，读取 PT Entry
10. MMU 从 PTE 中提取 4KB 物理页帧号
11. 物理地址 = (物理帧号 << 12) | bits[11:0]
```

**关键观察**：一次完整的 4 级页表遍历需要 **4 次内存访问**（只为了翻译一个地址）。
这就是为什么 TLB 如此重要。

### 1.3 TLB (Translation Lookaside Buffer)

TLB 是 MMU 内部的硬件缓存，缓存最近使用的虚拟页号 → 物理帧号的映射。

```
         CPU 核
    +---------------+
    |  Load/Store   |
    |  虚拟地址 VA   |
    +-------+-------+
            |
            v
    +-------+-------+     命中 (Hit)     +-----------+
    |    TLB 查找    | ----------------> | 直接得到   |
    |  (硬件并行匹配) |                   | 物理地址   |
    +-------+-------+                   +-----------+
            |
            | 未命中 (Miss)
            v
    +-------+-------+                   +-----------+
    |  Page Table   |                   | 更新 TLB  |
    |     Walk      | ----------------> |           |
    | (4 次内存访问)  |                   +-----------+
    +---------------+
```

**TLB 的关键指标**（典型 Intel Xeon / AMD EPYC）：

| 指标 | L1 TLB (数据) | L2 TLB |
|------|--------------|--------|
| 条目数 | 64-128 | 1536-2048 |
| 覆盖范围 (4KB 页) | 256KB-512KB | 6MB-8MB |
| 延迟 | 1 cycle | 5-8 cycles |
| 关联度 | 4-way / 8-way | 12-way |

**关键洞察**：如果工作集超过 TLB 覆盖范围，就会频繁发生 TLB miss，
每次 miss 需要额外的 4 次内存访问（page table walk）。对于 LLM 推理，
KV cache 很容易达到 GB 级别，这就是大页 (Huge Pages) 至关重要的原因。

### 1.4 Page Fault（缺页异常）

当 CPU 访问一个虚拟地址，但页表条目中 Present 位为 0 时，触发 Page Fault。

```
Minor Page Fault (软缺页):
   进程访问已分配但未映射的页
   → OS 找到空闲物理帧
   → 更新页表
   → 延迟: ~1-10 微秒
   典型场景: malloc 后首次访问 (惰性分配)

Major Page Fault (硬缺页):
   进程访问已被换出到磁盘的页
   → OS 从磁盘读取数据到物理帧
   → 更新页表
   → 延迟: ~1-10 毫秒 (涉及磁盘 I/O!)
   典型场景: 访问被 swap 出去的内存
```

**查看进程的 page fault 统计**：

```bash
# 实时查看 page fault
pidstat -r -p <PID> 1

# 某进程的累计统计
cat /proc/<PID>/stat | awk '{print "min_flt:"$10" maj_flt:"$12}'

# 系统级统计
cat /proc/vmstat | grep pgfault
```

### 1.5 mmap 系统调用

`mmap` 是 vLLM 中最关键的系统调用之一。它将文件映射到进程的虚拟地址空间，
实现按需加载 (demand paging)。

```c
#include <sys/mman.h>

// mmap 签名
void *mmap(void *addr, size_t length, int prot, int flags,
           int fd, off_t offset);

// 典型用法：映射模型权重文件
int fd = open("model.safetensors", O_RDONLY);
size_t file_size = lseek(fd, 0, SEEK_END);

// 将整个文件映射到虚拟地址空间（不立即读取！）
float *weights = mmap(NULL, file_size, PROT_READ,
                      MAP_PRIVATE,  // 或 MAP_SHARED
                      fd, 0);

// 此时文件内容尚未加载到物理内存
// 只有在实际访问时才会触发 page fault 并加载
float first_value = weights[0];  // ---> 触发 major page fault
```

**mmap 的优点**（对模型加载至关重要）：
1. **延迟加载 (Lazy Loading)**：不需要在启动时将所有权重读入内存
2. **零拷贝 (Zero-Copy)**：数据从 page cache 直接映射到进程空间，无需内核→用户态拷贝
3. **多进程共享**：多个进程可以用 MAP_SHARED 映射同一文件，共享物理内存
4. **自动回收**：内存压力下，干净的文件映射页可以简单丢弃（因为磁盘上还有副本）

---

## 2. PagedAttention 为何有效：OS 虚拟内存的类比

> **这是本文最重要的一个洞察。** PagedAttention 的设计灵感直接来源于操作系统
> 的虚拟内存管理。理解这个类比，你就理解了 vLLM 架构的核心。

### 2.1 问题：传统 KV Cache 管理的困境

在 Transformer 自回归解码中，每个 token 的 attention 计算需要所有之前 token
的 Key 和 Value。传统实现为每个序列预分配一块连续的 KV cache 内存：

```
传统方式：每个序列预分配连续内存
+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
| Seq 0, token 0 | Seq 0, token 1 | ... (预留 2048 tokens)  |未使用|
+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
|<----------- 预分配连续内存 (2048 * KV_size) -------------------->|

问题：
1. 内部碎片：序列提前结束，预留空间浪费
2. 外部碎片：序列长度不一，分配器无法复用
3. 无法共享：不同序列的相同 prompt prefix 无法共享 KV cache
```

### 2.2 核心类比：虚拟内存 = PagedAttention

```
    操作系统虚拟内存                              vLLM PagedAttention
+---------------------------+           +---------------------------+
| 虚拟地址空间 (Virtual)     |           | 逻辑 KV 块索引 (Logical)  |
|                           |           |                           |
| 进程看到连续的地址          |           | Attention 看到连续的位置   |
|                           |           | Block 0, 1, 2, 3, ...     |
+-----------+---------------+           +-----------+---------------+
            |                                       |
            | 页表 (Page Table)                      | 块表 (Block Table)
            v                                       v
+-----------+---------------+           +-----------+---------------+
| 物理内存 (Physical)       |           | GPU 显存 (Physical Blocks) |
|                           |           |                           |
| 实际分散在 RAM 各处        |           | 实际分散在 HBM 各处         |
| Frame 0x3a, 0x7f, 0x12... |           | Block 0x1a, 0x2f, 0x08...|
+---------------------------+           +---------------------------+
```

### 2.3 逐项类比详解

```
+------------------+--------------------------+-------------------------------+
|     概念          |     操作系统 (OS)         |     vLLM PagedAttention        |
+------------------+--------------------------+-------------------------------+
| 地址空间          | 虚拟地址空间 (每个进程)     | 逻辑块序列 (每个序列/请求)        |
| 基本单位          | 页 (Page), 4KB            | 块 (Block), 通常 16 tokens      |
| 映射结构          | 页表 (Page Table)          | 块表 (Block Table)              |
| 物理存储          | 物理帧 (Physical Frame)    | 物理块 (Physical Block, 在HBM上)|
| 分配策略          | 惰性分配 (Demand Paging)    | 惰性分配 (On-demand Allocation)  |
| 缺页 -> 分配       | Page Fault -> 分配物理帧    | Block Fault -> 分配新物理块       |
| 共享机制          | 共享内存 (shmget/mmap)     | 块共享 (Prefix Caching)          |
| 回收策略          | 页面回收 (Page Reclaim)     | 块回收 (Block Eviction/Free)     |
| 碎片问题          | 外部碎片                    | 消除碎片 (非连续分配)             |
+------------------+--------------------------+-------------------------------+
```

### 2.4 vLLM 块表映射的实际流程

```
序列 A 的 4 个 token 被分配到物理块 7, 3, 12:

块表 (Block Table) for Sequence A:
+----+-----+-----+-----+
| 索引|  0  |  1  |  2  |
+----+-----+-----+-----+
| 物理|  7  |  3  | 12  |
+----+-----+-----+-----+

GPU HBM 上的物理块存储:
+--------+--------+--------+--------+--------+
| Block 3| Block 7| Block12| Block 1|  ...   |
| [K][V] | [K][V] | [K][V] | [K][V] |        |
+--------+--------+--------+--------+--------+
    ^        ^        ^
    |        |        |
    +--------+--------+---- 块表指向分散的物理块

Attention 计算时:
  for i in range(num_blocks):
      physical_block_id = block_table[i]     # 等价于 OS 的页表查询
      k_cache = kv_cache[physical_block_id]  # 等价于通过物理帧号访问内存
      # compute attention...
```

### 2.5 Prefix Caching：OS 共享内存的翻版

```
两个序列共享相同的 System Prompt "You are a helpful assistant..."

序列 1: "You are a helpful assistant. What is the weather?"
序列 2: "You are a helpful assistant. Tell me a joke."
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            共享的 prefix 部分

vLLM 的块表:
序列 1 块表: [Block A] -> [Block B] -> [Block C] -> [Block D] -> [Block E]
序列 2 块表: [Block A] -> [Block B] -> [Block C] -> [Block X] -> [Block Y]
              ^^^^^^^^^^^^^^^^^^^^^^^^
              共享相同物理块 (引用计数 > 1)

OS 的共享内存:
进程 1 页表: [Frame 10] -> [Frame 11] -> [Frame 12]
进程 2 页表: [Frame 10] -> [Frame 11] -> [Frame 12]
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
              共享相同物理帧 (libc.so 的代码段)
```

**这就是 PagedAttention 的真正威力**：它把 OS 花了 40 年打磨的虚拟内存思想搬到了 GPU 显存管理上。

---

## 3. 进程与线程

### 3.1 进程和线程的本质区别

```
+----------------------------------------------------------+
|                        进程 (Process)                      |
|  +------------------------------------------------------+ |
|  | 虚拟地址空间 (Virtual Address Space)                    | |
|  | +--------+ +-------+ +--------+ +---------+           | |
|  | |  Text  | | Data  | |  Heap  | |  Stack  |           | |
|  | | (代码)  | | (数据) | | (堆)   | |  (栈)   |           | |
|  | +--------+ +-------+ +--------+ +---------+           | |
|  +------------------------------------------------------+ |
|  | 文件描述符表 (File Descriptor Table)                    | |
|  | 信号处理表 (Signal Handlers)                            | |
|  | 进程 ID (PID)                                          | |
|  +------------------------------------------------------+ |
|  +------------------------------------------------------+ |
|  | 线程 1          线程 2           线程 3                 | |
|  | +---------+    +---------+     +---------+            | |
|  | | 寄存器   |    | 寄存器   |     | 寄存器   |            | |
|  | | PC, SP  |    | PC, SP  |     | PC, SP  |            | |
|  | | 独立栈   |    | 独立栈   |     | 独立栈   |            | |
|  | +---------+    +---------+     +---------+            | |
|  |  (共享地址空间、共享文件描述符、共享信号处理)              | |
|  +------------------------------------------------------+ |
+----------------------------------------------------------+
```

**关键差异表**：

| 维度 | 进程 (Process) | 线程 (Thread) |
|------|---------------|--------------|
| 地址空间 | 独立 | 共享 |
| 创建开销 | 高 (fork + exec) | 低 (clone 仅栈) |
| 上下文切换 | 完整切换 (页表+TLB) | 轻量切换 (仅寄存器) |
| 通信方式 | IPC (管道/共享内存/消息队列) | 直接读写共享变量 |
| 隔离性 | 强 (一个崩溃不影响其他) | 弱 (一个崩溃可能导致全部挂掉) |
| 典型创建耗时 | ~1-10 ms | ~10-100 us |

### 3.2 上下文切换成本详解

```
进程上下文切换 (Process Context Switch):
+---------------------------+        +---------------------------+
| 进程 A 运行中              |   ->   | 进程 B 运行中              |
+---------------------------+        +---------------------------+
开销项:
  1. 保存 A 的寄存器 (~50-100 条指令)
  2. 保存 A 的 FPU/SSE/AVX 状态 (fxsave/xsave, ~数百字节)
  3. 切换 CR3 寄存器 → 加载 B 的页表基地址
  4. TLB 全部失效! (INVLPG 或隐式刷新，取决于 CPU 是否支持 PCID)
  5. 恢复 B 的寄存器
  6. 恢复 B 的 FPU 状态

总成本: ~1-5 微秒 (不含 cache 预热)
加上 cache miss 惩罚: 可达 ~10-50 微秒

线程上下文切换 (Thread Context Switch):
+---------------------------+        +---------------------------+
| 线程 A 运行中              |   ->   | 线程 B 运行中              |
+---------------------------+        +---------------------------+
开销项:
  1. 保存 A 的寄存器
  2. 保存 A 的 FPU 状态
  3. CR3 不变!  (同一进程，同一页表)
  4. TLB 大部分保留 (仅非全局条目可能失效)
  5. 恢复 B 的寄存器
  6. 恢复 B 的 FPU 状态

总成本: ~0.1-1 微秒
```

### 3.3 为什么 vLLM 使用线程而不是进程

```python
# vLLM 的 Tensor Parallelism 架构：多线程共享同一个 CUDA context
#
# Process 0 (唯一的 Python 进程)
#   ├── Thread 0: Worker (GPU 0) ← 持有 GPU 0 的 CUDA context
#   ├── Thread 1: Worker (GPU 1)
#   ├── Thread 2: Worker (GPU 2)
#   └── Thread 3: Worker (GPU 3)
#
# 为什么不用多进程？
# 1. CUDA Context 切换开销巨大 (~10-100ms)，线程共享同一个 context
# 2. 多进程间 IPC 通信延迟远高于线程间共享内存
# 3. 模型权重本身已在共享内存中，多进程反而需要额外的 IPC 来同步
# 4. NCCL 的 all-reduce 在多线程模式下更高效
#
# 例外：当需要进程隔离（如生产环境多个独立模型）时，会使用多进程
```

---

## 4. 内存层次结构

### 4.1 完整的内存金字塔（A800 80GB 服务器数据）

```
                                       大小         延迟              带宽
                                  +------------+-------------+----------------+
   寄存器 (Registers)             |  ~KB        |  ~0 cycles  |  ~TB/s         |
  /‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾  +------------+-------------+----------------+
  | L1 Cache (L1 缓存)            |  64KB/core  |  ~4 cycles  |  ~2 TB/s        |
  |‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾  +------------+-------------+----------------+
  | | L2 Cache (L2 缓存)          |  1MB/core   |  ~12 cycles |  ~1 TB/s        |
  | |‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ +------------+-------------+----------------+
  | | | L3 Cache (L3 缓存/LLC)    |  ~50-100MB  |  ~40 cycles |  ~500 GB/s      |
  | | |‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾+------------+-------------+----------------+
  | | | | DRAM (主内存, DDR5)      |  512GB-2TB  |  ~100 ns    |  ~50-100 GB/s   |
  | | | |‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾+------------+-------------+----------------+
  | | | | | GPU HBM (显存, A800)   |  80GB/GPU   |  ~200 ns    |  ~2 TB/s (HBM2e)|
  | | | | |‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾+------------+-------------+----------------+
  | | | | | | NVMe SSD (本地盘)     |  4-8TB      |  ~10 us     |  ~7 GB/s (PCIe4)|
  | | | | | |‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾+------------+-------------+----------------+
  | | | | | | | 网络存储 (RDMA)     |  PB 级      |  ~10-100 us |  ~100-200 Gbps  |
  +-+-+-+-+-+-+-------------------+-------------+----------------+

关键比例关系:
  L1 延迟 : L3 延迟 : DRAM 延迟 : NVMe 延迟 ≈ 1 : 10 : 25 : 2500
  L1 带宽 : DRAM 带宽 : NVMe 带宽 ≈ 40 : 1 : 0.14

每次往下一层，延迟增加约一个数量级。
```

### 4.2 Cache Line 与 False Sharing

```
Cache Line = 64 字节 (x86-64 / ARM 通用)

+-- Cache Line (64 bytes) ---------------------------------------+
| int a | int b | int c | int d | int e | int f | ... | padding  |
+----------------------------------------------------------------+
    ^               ^
    |               |
  Core 0 写 a     Core 1 写 c
  (使整个        (使整个
   cache line     cache line
   失效!)         失效!)

结果: Core 0 和 Core 1 不断使对方的 cache line 失效
     即使它们操作的是不同变量!  → False Sharing

解决方案: 对齐到 cache line 边界
struct alignas(64) AlignedData {
    int data;
    char padding[60];  // 填充到 64 字节
};
```

### 4.3 为什么这些数字对 GPU 推理很重要

```
一个典型的 LLM 推理步骤的时间分解 (prefill 阶段):

Token embedding lookup:          ~10 us  (L3 Cache 命中, 几百 KB)
Attention QKV projection:        ~100 us (矩阵乘法, 从 HBM 读取权重)
Attention score computation:     ~50 us  (从 HBM 读取 KV Cache)
FFN 第一层:                      ~200 us (矩阵乘法, 从 HBM 读取权重)
FFN 第二层:                      ~200 us (矩阵乘法, 从 HBM 读取权重)

总计: ~500-600 us per token (prefill)

瓶颈: 带宽。矩阵乘法的计算时间远小于数据传输时间。
     权重从 HBM 加载到 SM (流多处理器) 的时间占主导。
```

---

## 5. NUMA 架构

### 5.1 8-GPU 服务器的典型 NUMA 拓扑

```
        A800 8-GPU 服务器 NUMA 拓扑 (典型 2-socket 配置)
        ==================================================

    Socket 0 (CPU 0)                          Socket 1 (CPU 1)
+---------------------------+              +---------------------------+
| NUMA Node 0               |   UPI/QPI    | NUMA Node 1               |
|  +---------------------+  |<===========>|  +---------------------+  |
|  | CPU 0 内核集群       |  |  跨 Socket  |  | CPU 1 内核集群       |  |
|  |                     |  |  互联        |  |                     |  |
|  | DDR5 内存 Bank 0-3  |  |             |  | DDR5 内存 Bank 4-7  |  |
|  | (本地 DRAM)         |  |             |  | (本地 DRAM)         |  |
|  +---------------------+  |             |  +---------------------+  |
|         |    |    |    |  |             |         |    |    |    |   |
|         v    v    v    v  |             |         v    v    v    v   |
|  +------++------++------++------+   +------++------++------++------+|
|  | GPU0 || GPU1 || GPU2 || GPU3 |   | GPU4 || GPU5 || GPU6 || GPU7 ||
|  |A800  ||A800  ||A800  ||A800 |   |A800  ||A800  ||A800  ||A800 ||
|  |80GB  ||80GB  ||80GB  ||80GB |   |80GB  ||80GB  ||80GB  ||80GB ||
|  +------++------++------++------+   +------++------++------++------+
|         |    |    |    |                 |    |    |    |    |
|  PCIe Switch  |    |    |           PCIe Switch  |    |    |
|  (PLX)   +----+    |    |          (PLX)   +----+    |    |
|  +-------+         |    |           +-------+         |    |
|  +-----------------+    |           +-----------------+    |
|  +----------------------+           +----------------------+
+---------------------------+              +---------------------------+

关键连接:
  GPU 0-3 通过 PCIe Switch 连接到 CPU 0 (NUMA Node 0)
  GPU 4-7 通过 PCIe Switch 连接到 CPU 1 (NUMA Node 1)
  CPU 0 <-> CPU 1 通过 UPI (Ultra Path Interconnect) 互联

NUMA 延迟 (典型值):
  NUMA Node 0 访问本地 DRAM:          ~100 ns
  NUMA Node 0 访问远端 DRAM (Node 1): ~180 ns  (跨 NUMA 惩罚 ~1.8x)
```

### 5.2 NUMA 感知的必要性

```bash
# 查看 NUMA 拓扑
numactl --hardware

# 典型输出:
# available: 2 nodes (0-1)
# node 0 cpus: 0-31,64-95
# node 0 size: 515872 MB
# node 0 free: 412345 MB
# node 1 cpus: 32-63,96-127
# node 1 size: 516096 MB
# node 1 free: 398765 MB
# node distances:
# node   0   1
#   0:  10  21   ← 21/10 = 2.1x 跨 NUMA 延迟惩罚
#   1:  21  10

# 查看 GPU 的 NUMA 亲和性
nvidia-smi topo -m

# 典型输出 (截取):
#         GPU0    GPU1    GPU2    GPU3    GPU4    GPU5    GPU6    GPU7
# GPU0     X      NV12    NV12    NV12    SYS     SYS     SYS     SYS
# GPU1    NV12     X      NV12    NV12    SYS     SYS     SYS     SYS
# ...
# 含义:
#   NV12 = NVLink 12 (GPU 间直连, 高带宽)
#   SYS  = 需要通过 PCIe 和 QPI/UPI (跨 NUMA, 慢!)
```

### 5.3 正确的 NUMA 绑定策略

```bash
# 启动 vLLM 时绑定到正确的 NUMA 节点

# 方案 1: 如果只使用 GPU 0-3 (都在 NUMA Node 0)
numactl --cpunodebind=0 --membind=0 \
    vllm serve meta-llama/Llama-3.1-70B \
    --tensor-parallel-size 4

# 方案 2: 使用 8 卡时，需要处理跨 NUMA 通信
# vLLM 内部使用 NCCL 进行 all-reduce, NCCL 会自动处理拓扑感知
# 但 CPU 端的 worker 线程仍应绑定到对应 NUMA 节点

# 方案 3: 检查当前进程的 NUMA 内存分布
numastat -p <vllm_pid>

# Per-node process memory usage (in MBs) for PID 12345
#                            Node 0          Node 1           Total
#                            --------------- --------------- ---------------
# Huge                         20480.00         10240.00        30720.00
# Heap                         1024.00             0.00         1024.00
# Stack                           8.00             0.00            8.00
# Private                      512.00             0.00          512.00
# -------                      --------------- --------------- ---------------
# Total                       22024.00         10240.00        32264.00
# ↑ 如果 GPU 4-7 对应的内存大量分配在 Node 0，说明没有正确绑定!
```

---

## 6. CPU-GPU 数据传输

### 6.1 Pinned Memory (页锁定内存)

```
普通可分页内存 (Pageable Memory):
+----------+      DMA (需要额外 bounce buffer)
| 用户缓冲区 | ----+
+----------+      |    +------------------+      +----------+
                  +--> | DMA Bounce Buffer | ---> | GPU HBM  |
                       +------------------+      +----------+
问题:
  - OS 可能随时将用户缓冲区的物理页换出
  - DMA 引擎需要先将数据拷贝到内核空间的不换出缓冲区 (bounce buffer)
  - 多一次拷贝！浪费 PCIe 带宽

页锁定内存 (Pinned / Page-Locked Memory):
+----------+      DMA (直接传输)
| 用户缓冲区 | --------------------------------> +----------+
| (pinned)  |                                   | GPU HBM  |
+----------+                                   +----------+
优点:
  - OS 保证物理页不会被换出
  - DMA 引擎可以直接从用户缓冲区读取 (零拷贝)
  - 带宽可达 PCIe 理论极限的 90%+
代价:
  - 锁定的页不能被 OS 用于其他目的
  - 分配太多 pinned memory 会导致系统可用内存急剧下降
```

```c
// CUDA 中的 pinned memory 分配
#include <cuda_runtime.h>

// 普通 (pageable) 分配 — 慢
float *h_data;
cudaMallocHost(&h_data, size);  // 分配 pinned memory

// 对比: 普通 malloc — DMA 需要 bounce buffer
float *h_data_pageable = (float*)malloc(size);

// H2D 拷贝: pinned memory 更快
cudaMemcpy(d_data, h_data, size, cudaMemcpyHostToDevice);        // 快
cudaMemcpy(d_data, h_data_pageable, size, cudaMemcpyHostToDevice); // 慢

cudaFreeHost(h_data);  // 释放 pinned memory
free(h_data_pageable);
```

### 6.2 DMA 引擎与异步拷贝

```
CPU-GPU 数据传输的完整流程:

时间线:
------
CPU Thread:     [准备数据] [发起 DMA] [做其他事...               ] [等待完成]
                      |          |                                |
DMA Engine:           |    [DMA Copy: Host DRAM → GPU HBM    ]   |
                      |     ↑                                  |
                      |     |  PCIe 总线                        |
                      |     v                                  |
GPU:                  |          [CUDA Kernel 等待数据...] [Kernel执行]

关键机制:
1. cudaMemcpyAsync: 发起 DMA 后立即返回，不阻塞 CPU
2. CUDA Stream: 将操作串行化在同一个 stream 内
3. 多 Stream 并行: 不同 stream 的拷贝和 kernel 执行可以重叠

典型的多 Stream 流水线模式:
Stream 0: [H2D chunk0] [Kernel chunk0] [D2H chunk0]
Stream 1:    [H2D chunk1] [Kernel chunk1] [D2H chunk1]
Stream 2:       [H2D chunk2] [Kernel chunk2] [D2H chunk2]
            ↑           ↑           ↑           ↑
            时间重叠 → 充分利用 PCIe 和 GPU 计算资源
```

```python
# PyTorch/CUDA 中的异步拷贝模式
import torch

# 创建多个 CUDA stream
streams = [torch.cuda.Stream() for _ in range(4)]

# 将数据分片，每个 stream 处理一块
chunks = torch.chunk(input_data, 4, dim=0)
results = []

for i, (chunk, stream) in enumerate(zip(chunks, streams)):
    with torch.cuda.stream(stream):
        # H2D 拷贝 (异步)
        gpu_chunk = chunk.to('cuda', non_blocking=True)
        # Kernel 执行
        output_chunk = model(gpu_chunk)
        results.append(output_chunk)

# 等待所有 stream 完成
torch.cuda.synchronize()
final_result = torch.cat(results)
```

### 6.3 PCIe 带宽的实际限制

```
A800 服务器 PCIe 拓扑 (典型):

GPU 0-3 共享连接 CPU 0 的 PCIe Switch:
  PCIe Gen4 x16 = ~32 GB/s (理论)
  实际有效带宽: ~25-28 GB/s (协议开销)
  但这是 4 个 GPU 共享! → 每个 GPU 实际可用 ~6-8 GB/s

NVLink (GPU 间直连):
  A800: NVLink 3.0, 600 GB/s (双向, 每条链路 50 GB/s x 12)
  实际 all-reduce 带宽: ~300-400 GB/s (取决于数据大小和算法)

结论:
  CPU ↔ GPU 数据传输是瓶颈 (>10x 慢于 GPU ↔ GPU)
  应最小化 CPU ↔ GPU 的数据传输
  KV Cache 应完全驻留在 GPU HBM 中
```

---

## 7. 大页 (Huge Pages)

### 7.1 为什么 ML 工作负载需要大页

```
4KB 页的 TLB 覆盖问题:

假设 L2 TLB 有 1536 个条目，都是 4KB 页:
  最大覆盖: 1536 × 4KB = 6MB

vLLM 的工作集:
  模型权重:  70B 参数 × 2 bytes (FP16) = 140 GB
  KV Cache:  假设 batch_size=32, max_tokens=4096, 8 层 attention
             ≈ 数十 GB

6MB vs 140GB → TLB 覆盖不足 0.004%!
每次内存访问都可能触发 TLB miss → Page Table Walk → 4 次额外内存访问

使用 2MB 大页:
  最大覆盖: 1536 × 2MB = 3GB → 仍然不够，但好了 500 倍
  使用 1GB 大页:
  最大覆盖: 1536 × 1GB = 1.5TB → 完全覆盖!

ML 推理的 TLB miss 率对比:
  4KB 页:  ~5-15%  (严重!)
  2MB 页:  ~0.1-1% (可接受)
  1GB 页:  ~0.01%  (几乎消除)
```

### 7.2 配置大页

```bash
# === 透明大页 (Transparent Huge Pages, THP) ===

# 查看当前状态
cat /sys/kernel/mm/transparent_hugepage/enabled
# always [madvise] never

# 设置为 always (系统自动尝试使用 2MB 大页)
echo always > /sys/kernel/mm/transparent_hugepage/enabled

# 查看 THP 使用情况
cat /proc/meminfo | grep -i huge
# AnonHugePages:    24576000 kB
# ShmemHugePages:          0 kB

# === 显式大页 (Explicit Huge Pages) ===

# 预留 40GB 的 2MB 大页
echo 20480 > /proc/sys/vm/nr_hugepages
# 20480 × 2MB = 40GB

# 或者在启动时配置 (GRUB)
# hugepages=20480

# 查看预留
cat /proc/meminfo | grep Huge
# HugePages_Total:   20480
# HugePages_Free:    20480
# Hugepagesize:       2048 kB

# === 1GB 大页 (需要 CPU 支持 pdpe1gb) ===

# GRUB 配置
# default_hugepagesz=1G hugepagesz=1G hugepages=40

# 检查 CPU 是否支持
grep pdpe1gb /proc/cpuinfo  # 有输出则支持
```

```python
# 在 Python 中使用大页分配内存 (通过 mmap)
import mmap
import os

# 使用 MAP_HUGETLB 标志分配大页内存
HUGE_SIZE = 2 * 1024 * 1024  # 2MB

# 方法 1: 匿名大页映射
addr = mmap.mmap(
    -1,
    HUGE_SIZE,
    flags=mmap.MAP_HUGETLB | mmap.MAP_ANONYMOUS | mmap.MAP_PRIVATE,
    prot=mmap.PROT_READ | mmap.PROT_WRITE
)

# 方法 2: PyTorch 中使用大页 (通过环境变量)
# export PYTORCH_CUDA_ALLOC_CONF=use_hugetlb:true
```

### 7.3 THP 的陷阱

```
THP 不总是好的:

问题 1: 分配延迟
  当 THP 尝试分配 2MB 连续物理内存时，
  如果内存碎片化严重，可能需要 compact memory (内存压缩)，
  导致短时间的延迟尖刺 (~几毫秒到几十毫秒)

问题 2: 内存浪费
  分配 100KB 但 THP 给了一个 2MB 的页
  → 浪费 1.9MB (内部碎片)

问题 3: 交换开销
  将 2MB 页换出到磁盘比 4KB 页慢得多
  (但 ML 服务器通常禁用 swap)

最佳实践:
  - ML 推理服务器: 使用显式 1GB 或 2MB 大页
  - 对延迟敏感的在线服务: madvise 模式 + 关键缓冲区手动分配大页
  - 不要只依赖 THP always 模式
```

---

## 8. 内存分配器内部实现

### 8.1 malloc/free 的内部结构

```
ptmalloc (glibc 默认分配器) 的内部结构:

+--- Arena (分配竞技场) ---------------+
| +--- Heap -----------------------+ |
| |                                | |
| | +--- Chunk (已分配) -------+   | |
| | | prev_size | size | data  |   | |
| | +--------------------------+   | |
| |                                | |
| | +--- Chunk (空闲) ---------+   | |
| | | prev_size | size | fd|bk |   | |
| | +--------------------------+   | |
| |                                | |
| +--------------------------------+ |
+------------------------------------+

arena: 一个分配区域，多线程下有多个 arena 减少锁竞争
chunk: 内存块的基本单位
  已分配 chunk:
    [prev_size (8B)] [size (8B)] [user data ...]
                                  ^
                                  malloc 返回的指针指向这里
  
  空闲 chunk (free list):
    [prev_size (8B)] [size (8B)] [fd (8B)] [bk (8B)] [...]
                                  ↑       ↑
                              forward   backward
                              pointer   pointer (双向链表)

空闲链表 (Free List / Bins):
  Fast bins:  大小 16-80 字节的 chunk, LIFO, 单链表, 不合并
  Small bins: 大小 < 512 字节, FIFO, 双向链表, 精确匹配
  Large bins: 大小 >= 512 字节, 双向链表, 最佳匹配
  Unsorted bin: 刚释放的 chunk 暂存区
  Top chunk:    heap 顶部的大块空闲内存
```

### 8.2 内存碎片

```
外部碎片 (External Fragmentation):

+-----+   +--+  +------+   +--+  +--------+
| 32KB |   |8K|  | 16KB |   |8K|  |  空闲   |  ← 总空闲: 40KB
| 已用 |   |空|  | 已用 |   |空|  |  (40KB) |
+-----+   +--+  +------+   +--+  +--------+
                ↑
          需要分配 20KB → 失败!
          因为最大的连续空闲块只有 8KB (虽然总空闲有 48KB)

内部碎片 (Internal Fragmentation):
+----------------------------------+
| 分配了 32KB 块, 实际只用 24KB     |
| [////24KB 使用////|--8KB 浪费--]  |
+----------------------------------+

ML 工作负载中的碎片:
  模型权重 (GB 级连续分配) → 外部碎片风险高
  KV Cache 动态分配 → PagedAttention 通过非连续分配消除外部碎片
```

### 8.3 分配器对比

```
+-----------+----------+--------------------+---------------------+
| 分配器     | 设计目标  | 多线程性能           | ML 工作负载表现       |
+-----------+----------+--------------------+---------------------+
| ptmalloc   | 通用      | arena 间竞争        | 差: 大块分配碎片多     |
| (glibc)   |          | 需要较多锁          |                     |
+-----------+----------+--------------------+---------------------+
| tcmalloc   | 多线程    | 线程本地缓存 (TLS)   | 好: 大块分配表现好     |
| (Google)  | 高性能    | 减少锁竞争           | 适合内存密集应用       |
+-----------+----------+--------------------+---------------------+
| jemalloc   | 多线程    | arena 分区 + TLS    | 好: 碎片控制优秀       |
| (Facebook) | 低碎片    | 细粒度锁            | PyTorch 推荐          |
+-----------+----------+--------------------+---------------------+
| mimalloc   | 极低延迟  | 自由链表分片         | 极好: 分配/释放极快    |
| (Microsoft)| 低碎片    | 无锁设计            | 新兴 ML 系统的选择     |
+-----------+----------+--------------------+---------------------+

设置方法:
  # 使用 jemalloc
  LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libjemalloc.so.2 python -m vllm.entrypoints.openai.api_server ...

  # 使用 tcmalloc
  LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4 python ...

  # 使用 mimalloc
  LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libmimalloc.so python ...
```

### 8.4 Arena 和 Slab 分配器模式

```
Arena Allocator (区域分配器):
  一次性分配大块内存，内部自行管理子分配
  适合: 请求级别的临时分配 (每个推理请求需要临时缓冲区)

+--- Arena ---------------------------+
| [已分配 chunk1] [chunk2] [chunk3]...|
|                          ^          |
|                     bump pointer    |
|  (只增不减, 释放时整个 arena 一起释放)|
+-------------------------------------+
优点: 分配 O(1), 无碎片, 释放 O(1) (整块释放)
缺点: 无法单独释放某个 chunk

vLLM 中的应用: Block Table 使用 arena 分配器管理物理块

Slab Allocator (Slab 分配器):
  为每种大小的对象预分配 slab 缓存
  适合: 固定大小的频繁分配/释放

+--- Slab (for 256B objects) --------+
| [obj] [obj] [obj] [free] [obj] ... |
+------------------------------------+
+--- Slab (for 512B objects) --------+
| [obj] [free] [obj] [obj] [obj] ... |
+------------------------------------+

CUDA 的 cudaMallocAsync 内存池就是 slab 模式。
```

---

## 9. CUDA 内存管理

### 9.1 CUDA 内存类型全景

```
+------------------------------------------------------------------+
|                        CUDA 内存类型                              |
+---------------------------+----------+---------+------------------+
| 类型                       | 位置     | 延迟     | 用途              |
+---------------------------+----------+---------+------------------+
| 寄存器 (Registers)         | SM 内    | ~0      | 自动变量           |
| 共享内存 (Shared Memory)   | SM 内    | ~1-32   | 线程块内共享       |
| L1/Texture Cache           | SM 内    | ~28     | 只读/纹理          |
| L2 Cache                   | GPU 芯片 | ~200    | 全局缓存           |
| 全局内存 (Global/HBM)      | HBM     | ~200-800| 主要数据存储       |
| 本地内存 (Local Memory)    | HBM     | ~200-800| 寄存器溢出         |
| 常量内存 (Constant Memory) | HBM     | ~200    | 只读常量(有缓存)    |
| 纹理内存 (Texture Memory)  | HBM     | ~200    | 2D 空间局部性       |
| Pinned Memory (Host端)     | DRAM    | ~PCIe   | DMA 零拷贝         |
| 统一内存 (Unified Memory)  | HBM+DRAM| 动态     | 自动迁移           |
+---------------------------+----------+---------+------------------+
```

### 9.2 cudaMalloc vs cudaMallocHost vs cudaMallocManaged

```c
// === 1. cudaMalloc: GPU 显存分配 ===
float *d_data;
cudaMalloc(&d_data, 1024 * 1024 * 1024); // 1GB on GPU HBM
// 只能在 GPU kernel 中访问
// 需要显式的 cudaMemcpy 和 CPU 侧交换数据

// === 2. cudaMallocHost: Pinned (Page-Locked) Host Memory ===
float *h_pinned;
cudaMallocHost(&h_pinned, 1024 * 1024 * 1024); // 1GB pinned on host DRAM
// CPU 可以快速访问，GPU 可以 DMA 直接读取
// 不会被 OS 换出到 swap
// 典型用途: 模型输入/输出缓冲区

// === 3. cudaMallocManaged: Unified Memory ===
float *um_data;
cudaMallocManaged(&um_data, 1024 * 1024 * 1024); // 1GB unified
// CPU 和 GPU 都能访问同一个指针
// GPU 访问时自动 page-migrate 到 HBM
// CPU 访问时自动 migrate 回 DRAM
// 便捷但有性能开销 (page fault + migration latency)

// === 访问速度对比 (A800) ===
// cudaMalloc 的 GPU 端访问:       ~2 TB/s (HBM2e 内部)
// cudaMallocHost 的 GPU 端访问:    ~25 GB/s (PCIe Gen4 x16)
// cudaMallocManaged 的 GPU 端访问: 第一次 ~25 GB/s + page fault overhead
//                                   后续 ~2 TB/s (已迁移到 HBM)
```

### 9.3 CUDA Memory Pool (cudaMallocAsync)

```c
// CUDA 11.2+ 的 stream-ordered memory pool

// 创建内存池
cudaMemPool_t memPool;
cudaMemPoolCreate(&memPool, &poolProps);

// 设置内存池的释放阈值 (延迟释放，减少 cudaFree 开销)
uint64_t threshold = UINT64_MAX;
cudaMemPoolSetAttribute(memPool,
    cudaMemPoolAttrReleaseThreshold, &threshold);

// 在 stream 上的异步分配
float *d_data;
cudaMallocAsync(&d_data, size, stream);  // 异步分配
cudaFreeAsync(d_data, stream);           // 异步释放

// 优势:
// 1. 分配/释放操作在 stream 上排序，避免同步开销
// 2. 内存复用：释放的内存不会立即还给 OS，而是留在池中
// 3. 减少 cudaMalloc/cudaFree 调用次数 (这两个调用本身有 ~10-100us 开销)
```

### 9.4 vLLM 中的 CUDA 内存管理策略

```python
# vLLM 的内存层次管理:
#
# 1. 模型权重: cudaMalloc 一次性分配，常驻 GPU HBM
#    - 通过 mmap 从磁盘加载到 CPU 内存
#    - 再用 cudaMemcpy 传输到 GPU
#    - 分配后不再释放，直到进程退出
#
# 2. KV Cache: PagedAttention 的块分配
#    - 预分配一个大的 GPU 内存池 (Block Pool)
#    - 每个请求按需从池中获取块
#    - 请求结束时释放块回池
#    - 核心: 块大小 = 16 tokens × num_heads × head_dim × 2 (K+V) × 2 bytes (FP16)
#
# 3. 临时缓冲区 (Activations):
#    - 每个推理步骤的中间激活值
#    - CUDA Graph 捕获后可复用固定的内存布局
#    - 使用 CUDA Memory Pool 减少分配开销

# 块大小计算示例 (Llama-3 8B):
# hidden_size = 4096
# num_kv_heads = 8
# head_dim = 128
# block_size = 16 tokens
#
# block_size_bytes = 16 × 8 × 128 × 2 (K+V) × 2 (FP16) = 65536 bytes = 64KB
# 1GB = 16384 个 block → 可支持很多并发请求
```

---

## 10. 进程调度

### 10.1 CFS (Completely Fair Scheduler)

```
CFS 核心概念: vruntime (虚拟运行时间)

每个调度实体 (task_struct) 维护一个 vruntime:
  vruntime += 实际运行时间 × (1024 / weight)
  
  weight 由 nice 值决定:
  nice=-20 → weight=88761  (权重最高，vruntime 增长最慢)
  nice=0   → weight=1024   (默认)
  nice=19  → weight=15     (权重最低，vruntime 增长最快)

红黑树 (Red-Black Tree) 组织所有可运行任务:
       (key = vruntime)
              [C]
             /   \
           [B]   [E]
          /   \
        [A]   [D]
        
  最左侧节点 (vruntime 最小) 获得 CPU → 保证公平性

CFS 调度时间线:
Time: 0ms      10ms     20ms     30ms     40ms     50ms
      |---------|--------|--------|--------|--------|
CPU0: [  TaskA ][ TaskB ][  TaskA ][  TaskC ][  TaskB ]
      (vruntime 小)                               (vruntime 趋同)

每个任务的运行时间片 (time_slice):
  time_slice ≈ sched_period × (weight / total_weight)
  sched_period: 调度周期, 通常 ~6-20ms (取决于 CPU 上运行的任务数)
```

### 10.2 CPU 亲和性

```bash
# 查看当前进程的 CPU 亲和性
taskset -p <PID>
# pid 12345's current affinity mask: ffffffff
# (所有 CPU 核都可以用)

# 将进程绑定到 CPU 0-15
taskset -cp 0-15 <PID>

# 启动时就绑定 (用于推理服务)
taskset -c 0-31,64-95 numactl --membind=0 \
    vllm serve meta-llama/Llama-3.1-8B

# 为什么需要绑定?
# 1. 避免进程在不同 NUMA 节点的 CPU 之间迁移
#    (迁移后访问原来的 NUMA 本地内存变成远程访问 → 延迟翻倍)
# 2. GPU 推理的 CPU 端工作主要是:
#    - 调度和分发请求
#    - tokenizer 处理 (CPU 密集型)
#    - NCCL 控制逻辑
#    绑定到一个 NUMA 节点足够处理这些工作
# 3. 避免干扰系统其他关键进程 (如网络中断处理)
```

```python
# Python 中设置 CPU 亲和性
import os

# 绑定当前进程到特定 CPU 核
os.sched_setaffinity(0, {0, 1, 2, 3, 64, 65, 66, 67})
# 注意: {64,65,66,67} 通常是超线程对应的逻辑核
# 对于推理工作负载，通常绑定到物理核更合适

# 查看当前亲和性
print(os.sched_getaffinity(0))
```

### 10.3 为什么要固定推理进程

```
不绑定的问题:

    CPU 调度器
+------------------+
|                  |
| vLLM Worker 在   | ---迁移---> vLLM Worker 在
| CPU 0 (Node 0)   |             CPU 32 (Node 1)
|                  |
| 内存分配在       |             但内存仍在 Node 0!
| NUMA Node 0      |             → 所有内存访问都变成
|                  |               跨 NUMA 远程访问!
+------------------+             → 延迟从 100ns 变成 180ns
                                 → 吞吐量下降 10-30%

绑定的效果:
+------------------+
| vLLM Worker 始终 |  CPU 0-15 (Node 0)
| 运行在 Node 0    |
| 内存也锁定在     |  所有内存访问 → 本地, ~100ns
| Node 0           |
+------------------+
  预测性: 延迟稳定，无毛刺
  性能: 最大化，避免跨 NUMA 惩罚
```

---

## 11. 信号处理

### 11.1 SIGTERM vs SIGKILL

```
信号处理流程:

SIGTERM (15) - 优雅终止 (Graceful Shutdown):
+--------+     +--------+     +------------------+
| 发送   | --> | 进程   | --> | 信号处理函数      |
| SIGTERM|     | 捕获   |     | 1. 停止接收新请求  |
+--------+     +--------+     | 2. 排空现有请求    |
                              | 3. 释放 GPU 显存    |
                              | 4. 关闭文件描述符   |
                              | 5. exit(0)         |
                              +------------------+
  可以阻塞 (进程可以选择忽略或延迟处理)
  
SIGKILL (9) - 强制终止:
+--------+     +--------+     +------------------+
| 发送   | --> | 内核   | --> | 进程立即终止      |
| SIGKILL|     | 强制   |     | 无清理机会         |
+--------+     +--------+     +------------------+
  不可捕获、不可阻塞、不可忽略
  GPU 显存需要等 CUDA driver 超时后才能回收!
```

```python
# vLLM 中的优雅关闭信号处理 (简化版)

import signal
import sys

class GracefulShutdown:
    def __init__(self, server):
        self.server = server
        self.shutting_down = False
        # 注册信号处理
        signal.signal(signal.SIGTERM, self._handle_sigterm)
        signal.signal(signal.SIGINT, self._handle_sigterm)

    def _handle_sigterm(self, signum, frame):
        if self.shutting_down:
            # 第二次收到信号 → 强制退出
            sys.exit(1)
        
        self.shutting_down = True
        print("Received SIGTERM, starting graceful shutdown...")
        
        # 1. 停止接受新请求
        self.server.stop_accepting_requests()
        
        # 2. 等待现有请求完成 (带超时)
        self.server.drain_requests(timeout=30)
        
        # 3. 释放 GPU 资源
        self.server.free_gpu_memory()
        
        # 4. 清理
        self.server.cleanup()
        
        sys.exit(0)
```

### 11.2 推理服务的关键信号

```
+----------+----------+-----------------------------------------------+
| 信号      | 编号     | 推理服务应该如何处理                             |
+----------+----------+-----------------------------------------------+
| SIGTERM  | 15       | 优雅关闭：排空请求→释放显存→退出                  |
| SIGINT   | 2        | 同 SIGTERM (Ctrl+C 触发)                        |
| SIGUSR1  | 10       | 自定义：重新加载模型配置 / 切换模型版本            |
| SIGUSR2  | 12       | 自定义：dump 当前 KV Cache 状态到文件 (调试用)     |
| SIGHUP   | 1        | 重新加载配置文件 (传统 UNIX 语义)                 |
| SIGSEGV  | 11       | 段错误! 捕获后尝试 dump core 并打印堆栈后退出      |
| SIGBUS   | 7        | 总线错误 (常发生于 mmap 文件被截断)               |
|          |          | 模型文件损坏时可能触发 → 需要校验文件完整性         |
+----------+----------+-----------------------------------------------+
```

---

## 12. 文件 I/O 与模型加载

### 12.1 mmap 模型加载：safetensors 的工作方式

```
safetensors + mmap 的加载流程:

step 1. 打开文件
  fd = open("model.safetensors", O_RDONLY)

step 2. mmap 映射 (不读取数据!)
  header = mmap(NULL, header_size, ..., fd, 0)
  → OS 只在页表中创建 VMA (Virtual Memory Area)
  → 不分配物理内存，不读取磁盘

step 3. 解析 JSON header
  json_header_str = header[0:header_size]  ← 首次访问!
  → Major Page Fault → OS 从磁盘读取 header 部分
  
  header_json = json.loads(json_header_str)
  # {
  #   "model.layers.0.self_attn.q_proj.weight": {
  #     "dtype": "F16",
  #     "shape": [4096, 4096],
  #     "data_offsets": [1024, 33555456]
  #   },
  #   ...
  # }

step 4. 映射张量数据 (延迟加载)
  for tensor_name, tensor_info in header_json.items():
      offset, length = tensor_info["data_offsets"][0], ...
      # 使用 MAP_SHARED 映射文件的数据段
      data_ptr = mmap(NULL, length, PROT_READ, MAP_SHARED,
                      fd, header_size + offset)
      tensor = torch.from_numpy(
          np.frombuffer(data_ptr, dtype=dtype)
      ).reshape(shape).clone()  # .clone() 时才真正读取到 CPU 内存
                                  # 或者直接用 cudaMemcpy 拷贝到 GPU

step 5. 如果不再需要 CPU 端副本，可以 munmap
  munmap(data_ptr, length)
```

### 12.2 Page Cache 的作用

```
Page Cache 与模型加载:

第一次加载模型:
  磁盘 ---read()---> Page Cache ---用户态拷贝---> 用户缓冲区
  (实际: mmap 方式下，Page Cache 页直接被映射到用户空间，零拷贝)

第二次加载模型 (热启动):
  Page Cache (已缓存) ---零拷贝映射---> 用户空间
  (不需要读磁盘!)

Page Cache 的大小和回收:
  cat /proc/meminfo | grep -E "^Cached|^Buffers"
  # Cached:          52428800 kB  (50GB page cache)
  
  当需要更多内存时，OS 会回收 Page Cache:
  1. 优先回收干净页 (clean pages, 磁盘上有副本)
  2. 脏页 (dirty pages) 需要先写回磁盘

  如果模型文件在 Page Cache 中 → 加载几乎瞬时完成
  如果 Page Cache 被回收 → 需要重新读磁盘

优化:
  # 预热 page cache
  vmtouch -t model.safetensors  # 将整个文件加载到 page cache
  vmtouch model.safetensors     # 查看有多少在 cache 中
```

### 12.3 Direct I/O vs Buffered I/O

```
Buffered I/O (默认):
  数据路径: 磁盘 → Page Cache → 用户缓冲区
  优点: 缓存加速重复读取、预读 (readahead) 优化顺序读
  缺点: 占用 Page Cache、额外的内存拷贝

Direct I/O (O_DIRECT):
  数据路径: 磁盘 → 用户缓冲区 (绕过 Page Cache)
  优点: 不污染 Page Cache、减少拷贝、适合一次性大文件读取
  缺点: 需要对齐的缓冲区 (通常是 512 字节对齐)、无预读
  场景: 模型权重文件通常只读一次 → 适合 Direct I/O

选择:
  safetensors 使用 mmap → 必然走 Page Cache
  PyTorch 的 torch.load 默认使用 Buffered I/O
  
  对于大规模模型加载:
  - 如果内存充足: mmap + Page Cache (最佳)
  - 如果内存紧张: Direct I/O + 直接拷贝到 GPU (避免浪费 Page Cache)
```

---

## 13. 进程间通信 (IPC)

### 13.1 共享内存 (System V shm)

```c
// === System V 共享内存: vLLM 多进程 Tensor Parallelism 的基础 ===

// 进程 1 (创建共享内存):
#include <sys/shm.h>
#include <sys/ipc.h>

key_t key = ftok("/tmp/vllm_shm", 'V');
int shmid = shmget(key, 1024 * 1024 * 1024,  // 1GB
                   IPC_CREAT | 0666);
void *shm_addr = shmat(shmid, NULL, 0);

// 将模型权重写入共享内存
memcpy(shm_addr, model_weights, size);

// 进程 2 (Python 多进程 worker, 如 TP=4 时的 rank 1):
key_t key = ftok("/tmp/vllm_shm", 'V');
int shmid = shmget(key, 1024 * 1024 * 1024, 0666);
void *shm_addr = shmat(shmid, NULL, 0);

// 直接访问! 零拷贝
float *weights = (float*)shm_addr;
// 使用 weights 进行 GPU 推理...
```

### 13.2 vLLM 的多进程 Tensor Parallelism 架构

```
vLLM TP=4 的进程/内存架构:

+------------------------------------------------------------------+
|                       共享内存区域                                 |
|  +------------------------------------------------------------+ |
|  | 模型权重 (140GB, 在 CPU 内存中以 shared memory 共享)         | |
|  +------------------------------------------------------------+ |
|  | NCCL 通信缓冲区                                             | |
|  +------------------------------------------------------------+ |
+------------------------------------------------------------------+
        |           |           |           |
   shmat|      shmat|      shmat|      shmat|
        v           v           v           v
+---------+  +---------+  +---------+  +---------+
| Worker 0|  | Worker 1|  | Worker 2|  | Worker 3|
| (rank 0)|  | (rank 1)|  | (rank 2)|  | (rank 3)|
| GPU 0   |  | GPU 1   |  | GPU 2   |  | GPU 3   |
+---------+  +---------+  +---------+  +---------+

数据流 (以 all-reduce 为例):
  Worker 0: [partial_result_0] → NCCL AllReduce → [full_result]
  Worker 1: [partial_result_1] → (GPU 间 NVLink/PCIe) → [full_result]
  Worker 2: [partial_result_2] → (可能跨 NUMA) → [full_result]
  Worker 3: [partial_result_3] → [full_result]

共享内存的作用:
  - 模型权重只读共享 (multiprocessing 的 fork 天然共享)
  - NCCL 的 IPC 通信 (GPU Direct RDMA 的前置步骤)
  - 进程间同步 (通过共享标志位)
```

### 13.3 IPC 性能对比

```
+----------------+----------+--------------+---------------------+
| IPC 方式        | 延迟      | 带宽          | 适用场景              |
+----------------+----------+--------------+---------------------+
| 管道 (Pipe)    | ~5-10 us | ~100 MB/s    | 小数据量、流式传输     |
| Unix Socket    | ~10-20 us| ~500 MB/s    | 本地 C/S 通信         |
| 共享内存 (shm)  | ~0.1 us  | ~50-100 GB/s | 大块数据、零拷贝       |
| 消息队列 (mq)  | ~5-10 us | ~100 MB/s    | 结构化小消息           |
| mmap 文件       | ~0.1 us  | ~磁盘/内存带宽| 持久化 + 共享         |
| TCP Socket     | ~50 us   | ~10 Gbps     | 跨机器               |
| RDMA           | ~1-5 us  | ~100-200 Gbps| 跨机器、零拷贝        |
+----------------+----------+--------------+---------------------+

结论: 对于进程间的大块数据传输 (如模型权重), 共享内存是最优选择。
     vLLM 的多进程模式正是基于这个原因选择共享内存。
```

---

## 14. 实战场景：vLLM OOM 时发生了什么

### 14.1 逐步分解

```
场景: 用户向 vLLM 发送大批量请求，GPU 显存 OOM

时间线:

T0: 正常运行，GPU 显存使用率 85%
    nvidia-smi:
    | 0  A800  80GB  | 00000000:18:00.0  Off  |                    0 |
    | N/A   42C    P0  320W / 300W |  68000MiB / 81920MiB |     95%   |

T1: 新请求到达，需要分配更多 KV Cache 块
    vLLM Block Manager:
      allocate_block() → 没有空闲块!
      所有块都被占用，等待中的请求队列开始堆积

T2: vLLM 尝试回收 (Block Eviction)
    - 检查是否有已完成但未释放的块的请求
    - 如果有 swap 空间配置: 将不活跃请求的 KV Cache 换出到 CPU 内存
    - 如果还不够: 请求进入等待队列

T3: 最坏情况 — 无块可回收，但当前请求仍在进行中
    T3.1: 如果 GPU 显存耗尽发生在 CUDA kernel 执行期间:
      CUDA 报告: "out of memory"
      PyTorch 抛出: torch.cuda.OutOfMemoryError
      
    T3.2: OS 层面同时发生什么?
      
      方案 A: 如果是在 CPU 端分配 (cudaMallocHost / mmap 映射):
        malloc 返回 NULL?
        → 取决于 vm.overcommit_memory 设置
        
        /proc/sys/vm/overcommit_memory:
          0 (启发式): OS 估计是否有足够内存，不足时拒绝
          1 (总是允许): 总是返回成功 (即使物理内存不足)
          2 (不允许): 严格限制 (CommitLimit 以内)
        
        ML 服务器通常设置为 0 或 2 (避免 OOM Killer 误杀)

      方案 B: OOM Killer 可能被触发:
        
        OS 内存回收顺序:
        1. 缩减 Page Cache (丢弃干净页)
        2. 缩减内核 Slab 缓存
        3. 压缩内存 (memory compaction)
        4. 如果仍不够 → 触发 OOM Killer

T4: OOM Killer 评估进程 (打分系统):
    oom_score = (内存使用比例) × (oom_score_adj + 1000) / 1000
    
    查看进程的 oom_score:
      cat /proc/<vllm_pid>/oom_score
      # 数值越高 → 越可能被 kill
    
    调整 oom_score_adj (降低被 kill 概率):
      echo -500 > /proc/<vllm_pid>/oom_score_adj  # 降低 50%
      echo -1000 > /proc/<vllm_pid>/oom_score_adj # 完全豁免

T5: 如果使用了 cgroup 内存限制:
    /sys/fs/cgroup/memory/vllm.slice/memory.limit_in_bytes
    
    达到限制时:
    - 不会触发全局 OOM Killer
    - 只影响该 cgroup 内的进程
    - 更可控、更可预测

T6: GPU 端 OOM (与 CPU 分开):
    GPU 有独立的 OOM 机制:
    - CUDA driver 会拒绝 cudaMalloc 请求
    - PyTorch CUDA allocator 会尝试释放缓存的显存
    - 如果仍失败 → torch.cuda.OutOfMemoryError
    - 不会直接导致进程被 kill (除非异常未被捕获)
```

### 14.2 预防和监控

```bash
# === GPU 显存监控 ===
# 持续监控 GPU 显存使用
watch -n 1 nvidia-smi

# 查看显存使用的详细信息
nvidia-smi --query-gpu=memory.used,memory.free,memory.total --format=csv

# === 系统内存监控 ===
# 查看内存压力
cat /proc/pressure/memory
# some avg10=0.00 avg60=0.00 avg300=0.00 total=0
# full avg10=0.00 avg60=0.00 avg300=0.00 total=0
# full > 0 表示有进程在等待内存分配 → 内存压力!

# === Docker/cgroup 限制 ===
# 为 vLLM 容器设置内存限制
docker run --memory=256g --memory-swap=256g \
    --shm-size=8g \
    --gpus '"device=0,1,2,3"' \
    vllm/vllm-openai:latest \
    --model meta-llama/Llama-3.1-70B \
    --tensor-parallel-size 4 \
    --gpu-memory-utilization 0.90  # 最多使用 90% 显存
```

### 14.3 进程内存布局全图

```
进程的内存布局 (x86-64, 48-bit 虚拟地址空间):

0x0000_0000_0000 +------------------------+
                 |  NULL / 不可访问         |  (防止 NULL 指针解引用)
0x0000_7fff_ffff +------------------------+
                 |  Text (代码段)           |  (可执行指令, 只读)
                 +------------------------+
                 |  Data (已初始化数据)      |  (全局变量)
                 +------------------------+
                 |  BSS (未初始化数据)       |  (初始化为 0 的全局变量)
                 +------------------------+
                 |                        |
                 |  Heap (堆)              |  (malloc/free, 向上增长)
                 |       ↓                |
                 |   ...  ...             |
                 +------------------------+
                 |   ...  ...             |
                 |       ↑                |
                 |  mmap 区域              |  (共享库、文件映射、匿名映射)
                 |       ↓                |
                 |   libc.so              |
                 |   libpthread.so        |
                 |   libcuda.so           |
                 |   model.safetensors    |  ← mmap 映射的模型权重!
                 |   libnccl.so           |
                 +------------------------+
                 |   ...  ...             |
                 |       ↓                |
                 +------------------------+
                 |  Stack (栈, 主线程)      |  (局部变量, 向下增长)
0x0000_7fff_ffff +------------------------+
                 |                        |
                 |  [非规范地址间隙]       |
                 |                        |
0xffff_8000_0000 +------------------------+
                 |  Kernel Space           |  (内核代码和数据)
0xffff_ffff_ffff +------------------------+

查看进程内存布局:
  cat /proc/<pid>/maps
  pmap -x <pid>
```

---

## 与 AI Infra 的关联

本文涵盖的每一个 OS 概念都与 AI Infra 工程师的日常工作直接相关：

| OS 概念 | 在 vLLM / GPU 推理中的应用 |
|---------|--------------------------|
| **虚拟内存 / 页表 / TLB** | PagedAttention 的块表设计直接借鉴页表机制；TLB miss 的概念对应 PagedAttention 的块表查询开销 |
| **Page Fault** | mmap 延迟加载模型权重；PagedAttention 按需分配 KV Cache 块（Block Fault） |
| **mmap** | safetensors 模型加载的零拷贝机制；多进程共享模型权重 |
| **进程 vs 线程** | vLLM 使用多线程而非多进程的原因：共享 CUDA context，避免 IPC 开销 |
| **内存层次结构** | 优化访问模式使热数据留在 L2/L3；权重布局优化以减少 HBM 访问次数 |
| **NUMA** | GPU 与 CPU 的亲和性绑定；跨 NUMA 的 NCCL all-reduce 优化 |
| **Pinned Memory** | cudaMallocHost 分配 DMA 缓冲区，避免 bounce buffer |
| **DMA / 异步拷贝** | cudaMemcpyAsync + 多 stream 流水线，隐藏 PCIe 传输延迟 |
| **大页** | 减少 TLB miss，对于 KV Cache 等 GB 级工作集至关重要 |
| **内存分配器** | 使用 jemalloc/tcmalloc 替代 glibc malloc，减少内存碎片 |
| **CUDA 内存池** | cudaMallocAsync 减少分配开销；PagedAttention 的块池管理 |
| **CFS 调度** | 推理服务需要固定的 CPU 亲和性，避免跨 NUMA 迁移 |
| **信号** | SIGTERM 优雅关闭 → 排空请求 → 释放 GPU 显存 |
| **文件 I/O** | mmap 加载 safetensors；page cache 预热加速重启 |
| **共享内存** | 多进程 Tensor Parallelism 中进程间共享权重的基石 |

**核心思维模型**：OS 花了数十年解决"多进程如何高效安全地共享物理内存"的问题。
vLLM 面对的是同样的问题，只不过"内存"变成了"GPU 显存"，"进程"变成了"推理请求"。
理解 OS 的设计原理，就等于掌握了 vLLM 的设计蓝图。

---

## 16. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| mmap | 像"把文件直接挂到内存地址上"一样，访问内存即读写文件 | 本文第12节 |
| TLB | 像"地址翻译快查本"一样，缓存虚拟地址到物理地址的映射关系 | 本文第1节 |
| NUMA | 像"双拼别墅"一样，每个 CPU 有自己的本地内存，跨 CPU 访问更慢 | 本文第5节 |
| Huge Pages | 像"用大号便签纸代替小纸条"一样，用 2MB/1GB 页覆盖更多地址空间 | 本文第7节 |
| Pinned Memory | 像"被钉在墙上的地图"一样，物理页不会被 OS 换出，DMA 可直接访问 | 本文第6节 |

## 17. A800 部署场景举例

**场景1：A800 上部署 Qwen-33B 时的 NUMA 绑定与 Huge Pages 配置**

在 2×A800 服务器上通过 TP=2 部署 Qwen-33B：

```bash
# 1. 预留 1GB 大页（模型权重 62GB + KV Cache 10GB ≈ 需要约 80 个 1GB 大页）
echo 80 > /sys/kernel/mm/hugepages/hugepages-1048576kB/nr_hugepages

# 2. 查看 NUMA 拓扑，确认 GPU 0-1 属于 NUMA Node 0
nvidia-smi topo -m
# GPU0    GPU1    ...    NUMA Affinity
#  X      NV12    ...    N0
# NV12     X      ...    N0

# 3. 绑定 vLLM 进程到 NUMA Node 0，避免跨 NUMA 内存访问
numactl --cpunodebind=0 --membind=0 \
    vllm serve /models/Qwen2.5-32B-Instruct \
    --tensor-parallel-size 2 \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.90

# 4. 验证: 进程的 Huge 页应全部在 Node 0
numastat -p $(pgrep -f vllm)
# 预期: Node 0 Huge 远大于 Node 1
```

参考本文第5节（NUMA）和第7节（Huge Pages），跨 NUMA 访问延迟约 1.8x，绑定后可以避免 10-30% 的性能损失。

**场景2：通过 mmap 加速 DeepSeek-67B 模型加载**

```python
# DeepSeek-67B 约 134GB (FP16)，首次加载需要 ~30 秒
# 利用 mmap + page cache 预热，热重启可降到 ~2 秒
import os
import torch

# 预加载模型文件到 page cache
os.system("vmtouch -t /models/DeepSeek-V2-Chat/model-*.safetensors")
# 输出: Files: 1, Directories: 0, Resident Pages: 34304/34304 134G/134G

# 后续加载时，safetensors 的 mmap 直接从 page cache 读取，无需磁盘 I/O
model = LLM(model="/models/DeepSeek-V2-Chat", dtype="float16")
```

## 18. 上下游串联

```
上游 ← 本文档 → 下游

上游：模型文件存储与加载（磁盘 I/O 层）
      本文档教的 mmap、page cache、Direct I/O 决定模型权重如何
      从磁盘进入内存，直接影响冷启动延迟（第12节）。

下游：vLLM PagedAttention GPU 显存管理
      PagedAttention 的块表机制直接借鉴了本文档教的页表/虚拟内存设计，
      包括按需分配、非连续映射、共享/写时复制等（第2节）。

完整链路参考：end-to-end-inference-trace.md
  磁盘(safetensors) → mmap → CPU DRAM → cudaMemcpy → GPU HBM(权重) →
  请求到达 → PagedAttention Block Table(类似页表) → GPU Kernel → 采样输出
```

---
---
## 深入学习资源

### 书籍

1. **《Operating Systems: Three Easy Pieces》(OSTEP)** — Remzi H. Arpaci-Dusseau
   - 免费在线阅读: https://pages.cs.wisc.edu/~remzi/OSTEP/
   - 重点章节: Virtualization (虚拟化), Concurrency (并发), Persistence (持久化)
   - 适合: 系统性地学习 OS 核心概念

2. **《Computer Systems: A Programmer's Perspective》(CSAPP)** — Bryant & O'Hallaron
   - 重点章节: Chapter 6 (Memory Hierarchy), Chapter 9 (Virtual Memory)
   - 适合: 从程序员视角理解硬件和 OS 的交互

3. **《Understanding the Linux Kernel》** — Bovet & Cesati
   - 重点章节: Chapter 2 (Memory Addressing), Chapter 3 (Processes), Chapter 8 (Memory Management)
   - 适合: 深入 Linux 内核实现细节

4. **《Linux Kernel Development》** — Robert Love
   - 重点章节: Chapter 4 (Process Scheduling), Chapter 12 (Memory Management)
   - 适合: 理解 Linux 内核的设计决策

5. **《Programming Massively Parallel Processors》** — Kirk & Hwu
   - 重点章节: Chapter 4 (Memory and Data Locality), Chapter 5 (CUDA Memory)
   - 适合: 深入 GPU 内存层次和 CUDA 编程模型

### 论文

6. **"Efficient Memory Management for Large Language Model Serving with PagedAttention"** — Kwon et al., SOSP 2023
   - vLLM 的核心论文，理解 PagedAttention 的实现细节
   - https://arxiv.org/abs/2309.06180

7. **"What Every Programmer Should Know About Memory"** — Ulrich Drepper, 2007
   - 经典之作，覆盖 DRAM、Cache、NUMA、TLB 等方方面面
   - https://people.freebsd.org/~lstewart/articles/cpumemory.pdf

8. **"CUDA C++ Programming Guide" — Memory Hierarchy** — NVIDIA
   - https://docs.nvidia.com/cuda/cuda-c-programming-guide/index.html
   - 重点阅读: Chapter 5 (Performance Guidelines), Chapter 3 (Programming Interface → Memory Management)

### 在线资源

9. **NVIDIA Developer Blog — CUDA Memory Management**
   - https://developer.nvidia.com/blog/tag/cuda-memory-management/
   - 涵盖: Unified Memory, cudaMallocAsync, CUDA Graphs

10. **Linux Kernel Documentation — Memory Management**
    - https://www.kernel.org/doc/html/latest/admin-guide/mm/index.html
    - 涵盖: Huge Pages, NUMA, Memory Overcommit, OOM Killer

11. **vLLM 源码 — Worker / Model Runner / Block Manager**
    - https://github.com/vllm-project/vllm
    - 关键文件:
      - `vllm/worker/worker.py` — 推理 worker 的线程模型
      - `vllm/core/block_manager.py` — PagedAttention 的块管理
      - `vllm/worker/model_runner.py` — 模型执行的调度

### 工具

12. **`perf`** — Linux 性能分析工具
    ```bash
    # TLB miss 分析
    perf stat -e dTLB-load-misses,dTLB-store-misses -p <pid>
    # cache miss 分析
    perf stat -e cache-misses,cache-references -p <pid>
    # NUMA 分析
    perf stat -e node-loads,node-load-misses -p <pid>
    ```

13. **`numactl` / `numastat`** — NUMA 拓扑和内存分布分析
14. **`nvidia-smi topo -m`** — GPU 拓扑和 NVLink 连接分析
15. **`bpftrace`** — 动态追踪工具，可追踪 mmap/page fault/内存分配等系统调用
16. **`heaptrack`** — 堆内存分析，找出内存泄漏和碎片来源

---

> **学习建议**：建议按照本文的章节顺序学习，每个概念先在 Linux 上用 `perf`/`strace`/`bpftrace`
> 实际操作验证，然后对照 vLLM 源码找到对应的实现。OS 和 GPU 推理之间的联系不是抽象的——
> 每一行 vLLM 的块管理代码，都是 OS 页表管理思想的直接应用。
