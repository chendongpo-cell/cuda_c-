# Python 深度精要 —— AI Infra 工程师视角

> 读者：需要深度 Python 知识以构建、调试、优化 vLLM / FastAPI / PyTorch 推理服务的 AI Infra 工程师。
> 本文非入门教程，从推理服务生产实践出发逐层拆解 Python 核心机制。

---

## 1. Python 内存模型

### 1.1 引用计数 + 分代 GC

CPython 用**引用计数**（即时回收）配合**分代标记-清除**（解决循环引用）。

```
+-------------------+          +----------------------------+
|   PyObject        |          |     GC 三代 (generational)  |
|  ob_refcnt = 3    |          |  Gen0 阈值700  → 频繁扫描   |
|  ob_type ---------+--->      |  Gen1 阈值10   → 较少扫描   |
+-------------------+          |  Gen2          → 极少扫描   |
                               +----------------------------+
引用计数 = 确定性回收 (del obj → 立即释放)，对 GPU 显存管理至关重要
分代 GC  = 解决 A↔B 循环引用——两者 refcnt>0 但不可达
```

### 1.2 PyTorch Tensor 为何不经过 GC

```python
import gc; t = torch.randn(1000, 1000)
print(gc.is_tracked(t))  # False — Tensor 不参与 Python GC
```

Tensor 是 **C++ 对象 + Python 薄封装**，真正数据由 `c10::TensorImpl` 通过 `intrusive_ptr` 管理：

```
Python 侧                          C++ 侧 (libtorch)
┌─────────────────┐              ┌──────────────────────┐
│ THPVariable     │   ptr  ───>  │  c10::TensorImpl     │
│  (无 GC head)    │              │  StorageImpl*        │
└─────────────────┘              └──────────┬───────────┘
                                            │ CUDA Allocator → 显存
```

### 1.3 `__slots__` 内存优化

vLLM 每个推理请求创建 `SamplingParams`。无 `__slots__` 时每实例约 168 字节（PyObject头 + dict），开 `__slots__` 后约 40 字节——每秒数千 QPS 下累计节省显著。

```python
class SamplingParams:
    __slots__ = ('temperature', 'top_p', 'max_tokens')
    def __init__(self, temperature=1.0, top_p=1.0, max_tokens=100):
        self.temperature = temperature; self.top_p = top_p
        self.max_tokens = max_tokens
```

### 1.4 weakref 与缓存

```python
import weakref

class KVBlockCache:
    def __init__(self):
        self._cache = weakref.WeakValueDictionary()
    def put(self, block_id, block):
        self._cache[block_id] = block  # 无强引用时自动移除
```

### 1.5 长期运行内存碎片

推理服务器常运行数天。pymalloc 将释放的内存保留在池中不归还 OS，RSS 持续增长。缓解：`malloc_trim(0)` 在低谷期触发、使用 jemalloc/mimalloc、`PYTHONMALLOC=malloc`。

---

## 2. 装饰器深度剖析

装饰器 = `func = decorator(func)` 的语法糖，在**定义时**执行。

### 2.1 常用内置装饰器

```python
class SamplingParams:
    @classmethod
    def from_config(cls, config) -> "SamplingParams":  # vLLM 工厂方法
        return cls(temperature=config.temperature, top_p=config.top_p)

    @property
    def is_greedy(self) -> bool:
        return self.temperature == 0.0
```

### 2.2 FastAPI 路由装饰器

```python
@app.post("/v1/completions")  # FastAPI 启动时注册路由 + 记录 OpenAPI schema
async def completions(request: CompletionRequest): ...
```

### 2.3 生产级装饰器模板

```python
import time, functools
from typing import Callable, TypeVar

F = TypeVar('F', bound=Callable)

def latency_tracker(metric_name: str):
    """参数化装饰器：记录推理延迟。@functools.wraps 是必须的。"""
    def decorator(func: F) -> F:
        @functools.wraps(func)  # 保留 func.__name__ 等元信息
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            try:
                return func(*args, **kwargs)
            finally:
                elapsed_ms = (time.perf_counter() - start) * 1000
                print(f"[{metric_name}] {func.__name__}: {elapsed_ms:.2f}ms")
        return wrapper
    return decorator

@latency_tracker("forward")
@torch.no_grad()
def model_forward(hidden_states, attention_mask): ...
```

---

## 3. 上下文管理器

### 3.1 `__enter__` / `__exit__`

```python
class GPUMemoryTracker:
    def __enter__(self):
        torch.cuda.synchronize()
        self.start = torch.cuda.memory_allocated()
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        torch.cuda.synchronize()
        delta = (torch.cuda.memory_allocated() - self.start) / 1024**2
        return False  # 不吞异常
```

### 3.2 contextlib.contextmanager

```python
from contextlib import contextmanager

@contextmanager
def cuda_device(device_id: int):
    original = torch.cuda.current_device()
    try:
        torch.cuda.set_device(device_id)
        yield
    finally:
        torch.cuda.set_device(original)
```

### 3.3 vLLM Block Manager 模式

vLLM 显存管理用 acquire/release，即上下文管理器：

```
@contextmanager
def allocated_blocks(cache_engine, num_blocks):
    blocks = cache_engine.allocate(num_blocks)
    try: yield blocks
    finally: cache_engine.free(blocks)  # 自动归还 KV cache 块
```

同理：CUDA stream 切换也适用 `@contextmanager def cuda_stream(stream): ...`

---

## 4. 生成器与 yield

### 4.1 生成器函数 = 可暂停的函数

```python
def token_generator(logits_processor, max_tokens: int):
    token_ids = [BOS_ID]
    for _ in range(max_tokens):
        next_token = sample(logits_processor(token_ids))
        token_ids.append(next_token)
        yield next_token         # ← 暂停，返回给调用者
        if next_token == EOS_ID: break

gen = token_generator(proc, 100)
tok1 = next(gen)  # 运行到 yield，暂停
tok2 = next(gen)  # 从 yield 后继续
```

### 4.2 yield from

```python
def decode_layer(hs):
    yield from self_attention(hs)  # 透明传递子生成器的值
    yield from feed_forward(hs)
```

### 4.3 FastAPI SSE Streaming

```python
from fastapi.responses import StreamingResponse

@app.post("/v1/completions")
async def completions(request: CompletionRequest):
    async def event_stream():
        async for token in engine.generate_stream(request.prompt):
            yield f"data: {json.dumps({'token': token.text})}\n\n"
        yield "data: [DONE]\n\n"
    return StreamingResponse(event_stream(), media_type="text/event-stream")
```

### 4.4 内存效率

`for line in open("10GB.txt"): process(line)` ——生成器惰性迭代，任意时刻仅一行在内存。对比 `lines = [l for l in open("10GB.txt")]` 会 OOM。

### 4.5 异步生成器

```python
async def async_stream(model, prompts):
    for prompt in prompts:
        result = await model.generate_async(prompt)  # yield 间可 await
        yield result
```

---

## 5. Async/Await 深度剖析

### 5.1 Event Loop 内部：epoll

```
┌──────────────────────────────────────────────────────────┐
│                      Event Loop                          │
│  while True:                                             │
│      events = epoll.wait()    ← 内核中阻塞，不消耗 CPU    │
│      for fd, event in events:                             │
│          task = fd_to_task[fd]                            │
│          task.send(result)     ← 恢复协程执行              │
│                                                          │
│  ┌──fd3──┐ ┌──fd7──┐ ┌─Timer─┐ ┌─Signal─┐               │
│  │ 文件IO │ │Socket │ │ 5ms  │ │ SIGINT │               │
│  └───────┘ └───────┘ └───────┘ └────────┘               │
└──────────────────────────────────────────────────────────┘
```

### 5.2 Coroutine / Task / Future

```
Future   ─── 未来会有值的占位对象
  ▲
Task     ─── 包装协程提交给 event loop，继承 Future
  │ 包含
Coroutine ─── 可暂停/恢复的函数 (编译为 YIELD_FROM 字节码)
```

### 5.3 async/await 编译结果

`await` 编译为 `YIELD_FROM` 字节码——协程本质是生成器。`__code__.co_flags |= CO_COROUTINE` 标记区分普通生成器和协程。

### 5.4 vLLM AsyncLLMEngine 架构

```
FastAPI Server ──POST──> AsyncLLMEngine
                              │
                    add_request() → RequestTracker (队列)
                    step_async()  ← Event loop 驱动
                         │
                    ┌────┴─────┐
                    │ Scheduler │  选择 batch
                    └────┬─────┘
                    ┌────┴──────────┐
                    │ ModelRunner   │  GPU 推理 (释放 GIL)
                    └───────────────┘
```

### 5.5 常见陷阱

```python
# 1. 同步阻塞阻塞 event loop → 修复: await loop.run_in_executor(None, blocking_func)
# 2. asyncio.sleep(1) 忘记 await → 返回 coroutine 对象不执行
# 3. 多次 asyncio.run() → 每次创建新 event loop，性能差
```

---

## 6. 类型标注

### 6.1 基础 + 进阶

```python
from typing import Optional, Union, List, Dict, TypeVar, Generic, Protocol
from dataclasses import dataclass

# 基础类型——FastAPI/Basemodel 常用
class CompletionRequest(BaseModel):
    prompt: str
    temperature: float = 1.0
    max_tokens: Optional[int] = None
    stop: Union[str, List[str], None] = None

# TypeVar + Generic
T = TypeVar('T')
class Result(Generic[T]):
    data: T; error: Optional[str] = None

# Protocol——结构化子类型，无需继承
class TokenizerLike(Protocol):
    def encode(self, text: str) -> List[int]: ...
    def decode(self, token_ids: List[int]) -> str: ...

# dataclass——vLLM SamplingParams
@dataclass
class SamplingParams:
    temperature: float = 1.0; top_p: float = 1.0
    max_tokens: int = 16; stop: Optional[List[str]] = None
    @property
    def is_greedy(self) -> bool: return self.temperature == 0.0
```

### 6.2 TypedDict / @overload / mypy

```python
from typing import TypedDict, overload

class TokenResponse(TypedDict):
    id: int; text: str; logprob: float

@overload
def sample(logits: torch.Tensor, num: int) -> torch.Tensor: ...
@overload
def sample(logits: torch.Tensor, num: None = None) -> int: ...
```

CI 中强制类型检查：`mypy vllm/ --ignore-missing-imports --strict`

---

## 7. 导入系统

### 7.1 import 内部流程

```
import torch.nn.functional as F

1. sys.modules 查缓存 → 命中直接返回
2. 未命中: 遍历 sys.meta_path finders:
   BuiltinImporter → FrozenImporter → PathFinder(sys.path 中找 .py/.so)
3. FileFinder 找到 → SourceFileLoader.exec_module() → 编译+执行
4. sys.modules[name] = module  ← 缓存
```

### 7.2 绝对导入 vs 循环导入

```python
# 推荐：绝对导入
from vllm.engine.llm_engine import LLMEngine

# 避免：相对导入（重构易断）
from .llm_engine import LLMEngine

# 循环导入解决方案
from __future__ import annotations
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from vllm.engine.llm_engine import LLMEngine  # 仅类型检查时导入
# 或延迟导入：在函数内部 import
```

---

## 8. GIL（全局解释器锁）

### 8.1 GIL 保护什么

```
           GIL (互斥锁，任意时刻仅一个线程持有)
         ┌────┼────┐
         v    v    v
      Thread1 Thread2 Thread3

保护: CPython 引用计数 + 内部数据结构 (list/dict)
不保护: 应用层数据 → 需 threading.Lock
```

### 8.2 C 扩展释放 GIL

```c
// PyTorch CUDA 操作
Py_BEGIN_ALLOW_THREADS   // 释放 GIL
cuda_kernel<<<g,b>>>(a,b,c); cudaDeviceSynchronize();
Py_END_ALLOW_THREADS     // 重新获取 GIL
```

```
时间 ──>
Thread1(Python): [GIL]  [等待GIL]  [GIL]
Thread2(CUDA):          [──kernel──]   ← 不持 GIL，GPU 代码完全不受 GIL 限制
```

### 8.3 GIL vs asyncio

GIL 解决多线程下的 CPython 内部安全；asyncio 解决单线程下大量 I/O 的高效调度。两者解决不同层面的问题。

### 8.4 Python 3.13 free-threaded (`--disable-gil`)

当前（2025）实验性。PyTorch 等 C 扩展正适配中。稳定后 vLLM 可从 `asyncio+run_in_executor` 简化为真正的多线程并行，降低调度开销。

---

## 9. 多进程 vs 多线程

### 9.1 决策框架

- I/O 密集 (网络/磁盘) → 多线程 (ThreadPoolExecutor)
- CPU 密集 (计算) → 多进程 (ProcessPoolExecutor)
- GPU 推理 → 多进程 (CUDA 上下文隔离)
- API 服务 → asyncio + 线程池 (FastAPI)

### 9.2 fork vs spawn —— CUDA 必须用 spawn

```python
mp.set_start_method('spawn', force=True)
```
fork 继承父进程 CUDA 上下文 → OOM/死锁。spawn 全新启动，干净隔离。

### 9.3 vLLM Tensor Parallelism

```python
def run_worker(rank, world_size, model_config):
    torch.cuda.set_device(rank)
    model = load_model(model_config, rank, world_size).to(f'cuda:{rank}')
    # NCCL 通信在进程间进行
```

### 9.4 共享内存

```python
from multiprocessing.shared_memory import SharedMemory
shm = SharedMemory(name="kv_cache", create=True, size=100*1024*1024)
arr = np.ndarray((n,), dtype=np.float32, buffer=shm.buf)
```
多 GPU 间共享 KV cache 块，比 pickle 序列化快数个数量级。

---

## 10. 性能分析

### 10.1 四层分析栈

| 层次 | 工具 | 用途 |
|------|------|------|
| Python 函数级 | cProfile | `python -m cProfile -o out.stats` → `pstats` 分析 |
| Python 行级 | line_profiler | `@profile` + `kernprof -l -v` |
| CUDA kernel 级 | torch.profiler | `ProfilerActivity.CUDA` + `export_chrome_trace` |
| 生产无侵入 | py-spy | `py-spy record -o flame.svg --pid PID` |

### 10.2 torch.profiler

```python
with torch.profiler.profile(activities=[ProfilerActivity.CUDA]) as prof:
    with torch.no_grad(): output = model(input_ids)
print(prof.key_averages().table(sort_by="cuda_time_total"))
prof.export_chrome_trace("trace.json")  # → chrome://tracing
```

### 10.3 火焰图解读

```
     ┌──────────────────────────────────────┐
     │              main()                  │ ← 底部=调用者，顶部=被调者
     │  ┌──────────┐  ┌───────────────────┐ │   宽度=CPU 时间占比
     │  │ generate │  │  process_result   │ │   高度=调用栈深度
     │  │ ┌──────┐ │  │  ┌──────┐ ┌────┐  │ │
     │  │ │sample│ │  │  │decode│ │json│  │ │
     │  │ └──────┘ │  │  └──────┘ └────┘  │ │
     │  └──────────┘  └───────────────────┘ │
     └──────────────────────────────────────┘
宽块 = 热点，优先优化。
```

### 10.4 memory_profiler

```bash
python -m memory_profiler script.py  # 逐行内存增长
```

---

## 11. Python-C/C++ 互操作

### 11.1 ctypes / cffi

```python
import ctypes
lib = ctypes.CDLL("libcublas.so")
lib.cublasSgemm_v2.argtypes = [c_void_p, c_int, ...]
```
```python
from cffi import FFI; ffi = FFI()
ffi.cdef("int get_device_count();")
lib = ffi.dlopen("libcuda.so"); count = lib.get_device_count()
```

### 11.2 pybind11 —— vLLM 核心互操作

```
Python               C++ (pybind11)               CUDA
┌─────────┐  ┌─────────────────────────┐  ┌──────────┐
│model()  │─>│ forward(py::args)       │─>│ kernel   │
│         │  │   py::gil_scoped_release│  │ <<<>>>   │
│零拷贝   │  │   launch_kernel()       │  └──────────┘
└─────────┘  └─────────────────────────┘
   PyTorch Tensor ←→ torch::Tensor (自动转换，零拷贝)
```

### 11.3 完整最小示例：Python → pybind11 → CUDA

```cpp
// cuda_kernel.cu
#include <torch/extension.h>
__global__ void silu_kernel(const float* in, float* out, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) { float x = in[i]; out[i] = x / (1.0f + expf(-x)); }
}
torch::Tensor silu_forward(torch::Tensor input) {
    auto out = torch::empty_like(input);
    silu_kernel<<<(n+255)/256, 256>>>(input.data_ptr<float>(), out.data_ptr<float>(), n);
    return out;
}
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("silu_forward", &silu_forward, "SiLU (CUDA)");
}
```

```python
from torch.utils.cpp_extension import load
mod = load(name="cuda_ops", sources=["cuda_kernel.cu"])
result = mod.silu_forward(tensor)
```

`torch.utils.cpp_extension.load_inline` 支持在 Python 中直接嵌入 CUDA C++ 并用 JIT 编译——适合原型，但推理服务应使用预编译 wheel。

---

## 12. 打包与分发

### 12.1 pyproject.toml

```toml
[build-system]
requires = ["setuptools>=61", "wheel"]
build-backend = "setuptools.backends._legacy:_Backend"

[project]
name = "vllm"; version = "0.5.0"
requires-python = ">=3.9"
dependencies = ["torch>=2.0.0", "transformers", "fastapi", "uvicorn"]

[project.scripts]
vllm-serve = "vllm.entrypoints.openai.api_server:main"
```

### 12.2 Wheel 与依赖锁定

CUDA wheel 命名：`vllm-0.5.0+cu121-cp310-cp310-manylinux1_x86_64.whl`。

推理部署必须完全锁定依赖：`requirements.in → pip-compile → requirements.txt (带 hash)`。一个 transformer 版本回退可能导致 tokenizer 行为不一致，引发静默错误。

---

## 13. 性能陷阱

| 陷阱 | 反模式 | 正确做法 |
|------|--------|---------|
| 列表构造 | `for x in L: out.append(f(x))` | `[f(x) for x in L]` (C 级 LIST_APPEND) |
| 字符串拼接 | `s += t` 循环中 | `"".join(tokens)` 一次性分配 |
| Dict key | 自定义 `__hash__` 类 | 直接用 tuple (C 级 hashable) |
| View vs Copy | 高频 `clone()` | 用 `view()` / 就地操作 |
| 函数调用 | 热路径上多个小函数 | 内联 + `mul_().add_()` 减少 dispatch |
| 属性查找 | `for _ in range(N): obj.attr` | 先用 `attr = obj.attr` 提升到局部变量 |

---

## 14. 生产级日志

```python
import structlog
logger = structlog.get_logger()

logger.info("request_completed", request_id="req-abc123",
    prompt_tokens=512, completion_tokens=128, latency_ms=234.5,
    tokens_per_second=545.8, model="llama-3-8b")
```
输出 JSON → ELK / Loki / Grafana。日志级别：开发 DEBUG、staging/prod INFO/WARNING、ERROR 始终告警。

### Request ID 传播（contextvars = asyncio 版 threading.local）

```python
import contextvars
request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar('request_id')

@app.middleware("http")
async def add_request_id(request, call_next):
    rid = request.headers.get('X-Request-ID', str(uuid.uuid4()))
    token = request_id_var.set(rid)
    try:
        resp = await call_next(request)
        resp.headers['X-Request-ID'] = rid
        return resp
    finally:
        request_id_var.reset(token)
# 任意深度调用栈中: logger.info(msg, request_id=request_id_var.get("unknown"))
```

---

## 15. 测试

### 15.1 pytest Fixture + 参数化 + 异步

```python
@pytest.fixture
def dummy_model():
    model = SimpleModel(hidden_size=128).cuda()
    yield model
    del model; torch.cuda.empty_cache()

@pytest.mark.parametrize("model,batch,max_tokens", [
    ("llama-7b", 1, 128), ("llama-7b", 8, 256), ("mistral-7b", 4, 100),
])
def test_generation(model, batch, max_tokens):
    out = LLM(model=model).generate(["Hi"] * batch, SamplingParams(max_tokens=max_tokens))
    assert all(len(o.outputs[0].token_ids) <= max_tokens for o in out)

@pytest.mark.asyncio
async def test_async_generate(async_engine):
    results = [tok async for tok in async_engine.generate("Hi", request_id="t1")]
    assert len(results) > 0
```

### 15.2 Mock GPU + Hypothesis 属性测试

```python
def test_gpu_mock(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)

from hypothesis import given, strategies as st

@given(
    temperature=st.floats(0.0, 2.0),
    top_p=st.floats(0.0, 1.0),
    max_tokens=st.integers(1, 4096),
)
def test_sampling_invariants(temperature, top_p, max_tokens):
    p = SamplingParams(temperature=temperature, top_p=top_p, max_tokens=max_tokens)
    if p.is_greedy: assert temperature == 0.0
    assert p.max_tokens > 0 and 0.0 <= p.top_p <= 1.0
```
Hypothesis 自动探索边缘值（0, 1, 最大值, NaN），覆盖手工测试盲区。

---

## 与 AI Infra 的关联

| 层面       | Python 角色                                    | 关键知识点                  |
|-----------|-----------------------------------------------|---------------------------|
| API 服务   | FastAPI 路由、请求校验、SSE streaming           | async/await、装饰器、生成器 |
| 调度引擎   | vLLM AsyncLLMEngine、请求队列、block 管理       | 协程、上下文管理器、GIL     |
| 模型执行   | torch.no_grad()、Tensor 操作                   | 内存模型、性能陷阱           |
| C++/CUDA  | pybind11、torch.utils.cpp_extension            | C/C++ 互操作               |
| 生产运维   | structlog、py-spy、memory_profiler             | 性能分析、打包分发           |
| CI/CD     | mypy 类型检查、pytest、Docker 构建              | 类型标注、测试               |

核心洞察：

1. **GIL 不限制 GPU**：CUDA kernel 释放 GIL 后异步执行。多路请求的并行瓶颈在 GPU 算力和显存带宽。
2. **async/await 是推理服务骨架**：vLLM 本质是事件循环驱动的调度器——理解协程才能理解请求排队、batch 组装、流式返回。
3. **内存管理是核心挑战**：KV cache 分配/释放、显存碎片、长期 RSS 增长——从 Python 内存模型到 PyTorch C++ 分配器，全链路都要理解。
4. **Python-C++ 边界是优化关键路径**：Tensor 操作从 Python dispatch 到 C++/CUDA——`torch.no_grad()`、`inference_mode()`、view 操作都是优化手段。

---

## 16. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| async/await | 像"餐厅里点完菜去忙别的事，叫号了再回来"一样，不阻塞地等待 I/O | 本文第5节 |
| Generator/SSE | 像"流水线传送带"一样，产出一点就送出去一点，不用等全部完成 | 本文第4节 |
| contextmanager | 像"签到签退"一样，进入时分配资源，退出时自动释放 | 本文第3节 |
| GIL | 像"单通道收费站"一样，同一时刻只有一个 Python 线程能执行字节码 | 本文第8节 |
| decorator | 像"函数的外套"一样，在不修改原函数代码的前提下增强其功能 | 本文第2节 |

## 17. A800 部署场景举例

**场景1：A800 上部署 FastAPI SSE 流式推理服务**

```bash
# 启动 vLLM API Server（内置 FastAPI + SSE）
vllm serve /models/Qwen2.5-32B-Instruct \
    --tensor-parallel-size 2 \
    --host 0.0.0.0 --port 8000

# 流式请求验证
curl -N http://localhost:8000/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "/models/Qwen2.5-32B-Instruct",
        "messages": [{"role": "user", "content": "用 Python 写一个二分查找"}],
        "stream": true,
        "max_tokens": 256
    }'
# 预期: 逐 token 返回 SSE data 行，而非等所有 token 生成完毕
```

该服务底层使用 async generator（本文第4.3节），每个 token 通过 `yield` 立即推送给客户端。在 A800 上，Qwen-33B 的 decode 延迟约 15ms/token，SSE 流式使得用户感知延迟为 15ms 而非 15ms×256=3.8s。

**场景2：用 `__slots__` 优化高并发下的内存占用**

在 A800 推理服务中，每秒处理数千个请求，每个请求创建一个 `SamplingParams` 对象。启用 `__slots__`（本文第1.3节）：

```python
class SamplingParams:
    __slots__ = ('temperature', 'top_p', 'max_tokens', 'stop')
    # 每个实例约 40 字节 vs 默认 168 字节
    # 10000 QPS × 128 字节节省 = 1.28 MB/s 分配节省
```

参考本文第1.3节和第1.5节，长期高负载下可配合 `PYTHONMALLOC=malloc` 和 jemalloc 控制 RSS 增长。

## 18. 上下游串联

```
上游 ← 本文档 → 下游

上游：API 接入与请求路由（HTTP 入站层）
      FastAPI 路由装饰器 + Pydantic 模型校验负责接收和验证外部请求，
      再通过 asyncio event loop 将请求分发给推理引擎。

下游：vLLM AsyncLLMEngine 推理调度
      本文档教的 async/await 是 AsyncLLMEngine 的核心运转方式，
      协程驱动 scheduler.step() → worker.execute_model() 的循环，
      生成器（yield）实现逐 token 流式返回。

完整链路参考：end-to-end-inference-trace.md
  HTTP Request → FastAPI Router → Pydantic validate → AsyncLLMEngine.add_request() →
  Scheduler (asyncio loop) → Worker (pybind11 → CUDA) → SSE yield token →
  HTTP Response
```

---
---
## 深入学习资源

### 必读

| 资源 | 说明 |
|------|------|
| 《Fluent Python》第二版，Luciano Ramalho | Python 深度机制最佳书籍 |
| 《CPython Internals》Anthony Shaw | 源码级理解解释器 |
| 《High Performance Python》第二版，Gorelick & Ozsvald | Python 性能优化实践 |
| [Python Developer's Guide](https://devguide.python.org/) | 内存管理、GC 内部机制 |
| [Real Python: Async IO](https://realpython.com/async-io-python/) | 异步编程社区最佳教程 |

### vLLM 源码导航

| 路径 | 学习目标 |
|------|---------|
| `vllm/engine/async_llm_engine.py` | 异步调度核心架构 |
| `vllm/worker/model_runner.py` | GPU 执行路径 |
| `vllm/core/block_manager.py` | KV cache 管理（上下文管理器模式） |
| `vllm/sampling_params.py` | dataclass 实际用法 |
| `vllm/entrypoints/openai/api_server.py` | FastAPI 集成 |
| `csrc/` | C++/CUDA 扩展入口 |

### 工具链速查

| 工具 | 用途 | 命令 |
|------|------|------|
| py-spy | 生产 CPU 采样 | `py-spy top --pid PID` |
| memray | 内存分配火焰图 | `memray run --native script.py` |
| scalene | CPU+内存+GPU 综合 | `scalene --gpu script.py` |
| viztracer | 协程/线程并发可视化 | `viztracer -o trace.json script.py` |
| snakeviz | cProfile 火焰图 | `snakeviz profile.stats` |

### 进阶阅读

- [PEP 703 – Making the GIL Optional](https://peps.python.org/pep-0703/) — free-threaded 设计文档
- [PyTorch Dispatcher 内部机制](https://pytorch.org/docs/stable/torch.compiler_dynamo_deepdive.html) — Python→C++ dispatch 完整链路
- [vLLM 论文](https://arxiv.org/abs/2309.06180) — PagedAttention 核心架构
- [Numba CUDA 编程](https://numba.pydata.org/numba-doc/latest/cuda/index.html) — 无需 C++ 的 GPU kernel 开发
- [Python `dis` 模块文档](https://docs.python.org/3/library/dis.html) — 字节码分析，热路径优化基础
