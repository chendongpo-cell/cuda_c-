# C++ 源码阅读指南：面向 AI Infra 工程师

> **目标读者**：需要阅读 vLLM / CUDA / PyTorch C++ 源码的 AI Infra 工程师
> **定位**：源码阅读能力，**不是**算法面试。不追求手写红黑树，追求能看懂推理引擎在做什么。
> **策略**：边读源码边查，不需要"学完再开始"。

---

## 1. 类与继承 -- vLLM 的多态模式

### 1.1 对象内存布局

```
+----------------------------------------------------+
|  CpuGpuBlockAllocator 对象内存布局                   |
+----------------------------------------------------+
|  [vptr]  --------->  vtable (虚函数表)                |
|                      +----------------------------+  |
|                      | &CpuGpuBlockAllocator::alloc | (覆盖基类虚函数)
|                      | &CpuGpuBlockAllocator::free  |
|                      | &CpuGpuBlockAllocator::~dtor |
|                      +----------------------------+  |
|  [cpu_allocator_]  (BlockAllocator, 内嵌值对象)       |
|  [gpu_allocator_]  (BlockAllocator, 内嵌值对象)       |
+----------------------------------------------------+
```

### 1.2 实战：BlockAllocator 的虚函数多态

```cpp
// === 基类：定义接口契约 ===
class BlockAllocator {
public:
    virtual ~BlockAllocator() = default;
    virtual bool allocate(size_t num_blocks, std::vector<int>& out_ids) = 0;
    virtual void free(const std::vector<int>& block_ids) = 0;
    virtual size_t num_free_blocks() const = 0;
};

// === 派生类：组合 CPU/GPU 两种分配器 ===
class CpuGpuBlockAllocator : public BlockAllocator {
public:
    CpuGpuBlockAllocator(size_t num_cpu, size_t num_gpu)
        : cpu_alloc_(num_cpu), gpu_alloc_(num_gpu) {}

    bool allocate(size_t n, std::vector<int>& out) override {
        if (gpu_alloc_.num_free_blocks() >= n)
            return gpu_alloc_.allocate(n, out);
        return cpu_alloc_.allocate(n, out);  // fallback: swap 到 CPU
    }
    void free(const std::vector<int>& ids) override { /* ... */ }
    size_t num_free_blocks() const override {
        return gpu_alloc_.num_free_blocks() + cpu_alloc_.num_free_blocks();
    }
private:
    BlockAllocator cpu_alloc_;
    BlockAllocator gpu_alloc_;
};
```

**阅读要点**：`= 0` 是纯虚函数，子类必须实现；`override` 让编译器校验签名；析构函数加 `virtual` 确保多态 delete 安全。

### 1.3 模板：类型参数化与 CUDA Kernel

模板在 ML 推理引擎中无孔不入：Tensor dtype、kernel block size。

```cpp
// === 函数模板：同一个 kernel 支持 half/float/bfloat16 ===
template <typename scalar_t>
void rms_norm_kernel(
    scalar_t* __restrict__ out,          // __restrict__ = 无别名提示
    const scalar_t* __restrict__ input,
    float eps, int num_tokens, int hidden_size
) {
    for (int i = 0; i < num_tokens; i++) {
        float var = 0.0f;
        for (int j = 0; j < hidden_size; j++) {
            float v = static_cast<float>(input[i * hidden_size + j]);
            var += v * v;
        }
        var /= hidden_size;
        float rms = 1.0f / sqrtf(var + eps);
        for (int j = 0; j < hidden_size; j++)
            out[i * hidden_size + j] = static_cast<scalar_t>(
                static_cast<float>(input[i * hidden_size + j]) * rms);
    }
}
// 调用: rms_norm_kernel<half>(out, input, 1e-5, N, D);
```

**关键**：模板代码必须在头文件定义，编译器需完整定义才能实例化。

---

## 2. RAII 与智能指针 -- 不会泄漏的 CUDA 内存

### 2.1 RAII 生命周期图

```
  构造                          析构
   |                             |
   v                             v
+--+=============================+--+
|  获取资源：                    释放资源：
|  new / cudaMalloc              delete / cudaFree
|  fopen                         fclose
|  lock(mutex)                   unlock
+--+=============================+--+
   |<------- 对象生命周期 -------->|
   异常安全：即使抛异常，析构函数也会被调用，资源不会泄漏
```

### 2.2 CUDA 显存的 RAII 封装

```cpp
class CudaBuffer {
public:
    CudaBuffer(size_t size) : size_(size), ptr_(nullptr) {
        cudaMalloc(&ptr_, size);              // 构造 = 申请 GPU 显存
    }
    ~CudaBuffer() { if (ptr_) cudaFree(ptr_); }  // 析构 = 释放

    // 禁止拷贝（GPU 显存的拷贝代价极高）
    CudaBuffer(const CudaBuffer&) = delete;
    CudaBuffer& operator=(const CudaBuffer&) = delete;

    // 允许移动
    CudaBuffer(CudaBuffer&& other) noexcept
        : size_(other.size_), ptr_(other.ptr_) {
        other.ptr_ = nullptr; other.size_ = 0;  // 转移所有权，源对象置空
    }

    void* data() { return ptr_; }
    size_t size() const { return size_; }
private:
    size_t size_;
    void* ptr_;
};

// 使用：函数退出时自动释放，异常也安全
void process_on_gpu() {
    CudaBuffer input(1 << 20), output(1 << 20);  // 自动申请
    launch_kernel(input.data(), output.data());
}  // input/output 析构，自动 cudaFree，即使 launch_kernel 抛异常
```

### 2.3 智能指针三句话

```cpp
// 1. unique_ptr — 独占所有权，零开销。vLLM Worker 持有唯一 GPU 缓存。
class Worker {
    std::unique_ptr<CudaBuffer> kv_cache_;
public:
    Worker(size_t sz) : kv_cache_(std::make_unique<CudaBuffer>(sz)) {}
    CudaBuffer* get_cache() { return kv_cache_.get(); }
};

// 2. shared_ptr — 共享所有权，有引用计数开销。多个请求共享 tokenizer。
std::shared_ptr<Tokenizer> tok = std::make_shared<Tokenizer>();
auto proc1 = RequestProcessor(tok);  // use_count() == 2
auto proc2 = RequestProcessor(tok);  // use_count() == 3

// 3. weak_ptr — 不增加引用计数，打破循环引用。观察缓存淘汰。
std::weak_ptr<BlockManager> obs;
if (auto mgr = obs.lock()) { mgr->evict_blocks(10); }
// 规则：默认 unique_ptr，多 owner 才用 shared_ptr，循环引用用 weak_ptr
```

---

## 3. 移动语义 -- Tensor 在 Layer 间零拷贝传递

### 3.1 移动前后的内存对比

```
【移动前】
  tensor_a              tensor_b
  +--------+            +--------+
  | ptr ──────> [显存A]  | ptr ──────> [显存B]
  | size=8 |            | size=8 |
  +--------+            +--------+

  tensor_c = std::move(tensor_a);  // 转移所有权

【移动后】
  tensor_a    tensor_c              tensor_b
  +--------+  +--------+            +--------+
  | ptr=null | | ptr ──────> [显存A] | ptr ──────> [显存B]
  | size=0  | | size=8 |            | size=8 |
  +--------+  +--------+            +--------+

  tensor_a 处于"有效但未指定"状态，可以安全析构或赋新值。
  显存A 没有发生拷贝！只有指针被转移。
```

### 3.2 Tensor 移动实战

```cpp
class Tensor {
public:
    // 移动构造 — 只转移指针，不拷贝数据
    Tensor(Tensor&& other) noexcept
        : data_(other.data_), size_(other.size_), device_(other.device_) {
        other.data_ = nullptr; other.size_ = 0;
    }
    // 移动赋值
    Tensor& operator=(Tensor&& other) noexcept {
        if (this != &other) {
            delete[] data_;        // 释放自己的旧数据
            data_ = other.data_;   // 接管对方
            size_ = other.size_;
            other.data_ = nullptr; other.size_ = 0;
        }
        return *this;
    }
    // 拷贝构造 — 深拷贝，昂贵
    Tensor(const Tensor& other) : size_(other.size_), device_(other.device_) {
        data_ = new float[size_]; memcpy(data_, other.data_, size_ * sizeof(float));
    }
private:
    float* data_;  size_t size_;  int device_;
};

// === 实战模式 ===
std::vector<Tensor> layers;  layers.reserve(32);
for (int i = 0; i < 32; i++)
    layers.push_back(create_layer(i));  // RVO / 移动，零拷贝
    // 等价于 layers.emplace_back(create_layer(i));
```

### 3.3 std::forward 与完美转发

```cpp
template <typename T, typename... Args>
std::unique_ptr<T> make_block(Args&&... args) {
    return std::make_unique<T>(std::forward<Args>(args)...);
    // forward 保持参数的值类别：左值拷贝，右值移动
}
```

---

## 4. STL 容器在 ML Infra 中的实战

```cpp
// === vector：动态数组，做 Block Table ===
std::vector<int> token_ids;
token_ids.reserve(max_seq_len);  // 预分配，避免反复 realloc
// 传给 CUDA: cudaMemcpy(dst, token_ids.data(), N*sizeof(int), cudaMemcpyHostToDevice);

// === unordered_map：哈希表，做 block 反向映射 ===
class BlockManager {
    std::unordered_map<int, RequestId> block_to_request_;  // block_id -> 请求
    std::unordered_set<int> free_blocks_;                   // 空闲 block 集合
    std::unordered_map<RequestId, std::vector<int>> block_tables_;  // 请求 -> block 表
public:
    bool allocate(RequestId r, size_t n) {
        if (free_blocks_.size() < n) return false;
        auto& tbl = block_tables_[r]; tbl.reserve(n);
        auto it = free_blocks_.begin();
        for (size_t i = 0; i < n; i++) {
            int blk = *it; tbl.push_back(blk);
            block_to_request_[blk] = r;
            it = free_blocks_.erase(it);  // O(1)
        }
        return true;
    }
};

// === deque：双端队列，调度器的 waiting queue ===
std::deque<std::shared_ptr<Sequence>> waiting_queue_;
waiting_queue_.push_back(seq);  // 尾部加
auto s = waiting_queue_.front(); waiting_queue_.pop_front();  // 头部取

// === optional：可能没有值的返回值（prefix caching）===
std::optional<std::vector<int>> lookup(const std::vector<int>& tokens, size_t n) {
    auto it = cache_.find(hash(tokens, n));
    if (it != cache_.end()) return it->second;
    return std::nullopt;
}
auto cached = lookup(tokens, 128);
if (cached) reuse_kv_blocks(*cached);
```

---

## 5. Lambda 与 std::function -- CUDA Stream 回调

```cpp
// === 四种捕获模式 ===
int N = 128; float* out = buf.data();
auto l1 = [=]() { launch(out, N); };    // [=] 按值捕获所有
auto l2 = [&]() { launch(out, N); };    // [&] 按引用捕获所有 (小心生命周期!)
auto l3 = [=, &stream]() {              // 混合：N 按值，stream 按引用
    cudaStreamSynchronize(stream); };   // (CUDA stream 不能拷贝)
auto l4 = [count](int x) mutable { count += x; return count; };  // mutable

// === 实战：CUDA stream 回调 ===
auto done = std::make_shared<std::atomic<bool>>(false);
cudaLaunchHostFunc(compute_stream,
    [done](cudaStream_t, cudaError_t) { done->store(true); }, nullptr);
while (!done->load()) prepare_next_batch();  // 主线程等 kernel 完成
```

---

## 6. 阅读大型 C++ 项目的通用技巧

### 6.1 目录结构与职责划分

```
vllm/
├── csrc/                    <-- C++ 核心代码
│   ├── cache_kernels.cu     <-- CUDA kernel (GPU 上运行的代码)
│   ├── attention/           <-- PagedAttention 实现
│   ├── quantization/        <-- 量化 kernel
│   └── pybind/              <-- pybind11 绑定 (C++ ↔ Python 边界)
├── include/vllm/            <-- 头文件 (类声明、函数签名)
└── vllm/                    <-- Python 代码
```

### 6.2 阅读策略

```bash
# 找某个类的定义
grep -rn "class BlockManager" --include="*.h"
# 找某个函数的实现
grep -rn "void Scheduler::schedule" --include="*.cpp"
# 找 pybind11 绑定（Python 调用入口）
grep -rn "PYBIND11_MODULE\|\.def(" --include="*.cpp"
```

### 6.3 宏模式速查

```cpp
#define CUDA_CHECK(call) do {                        \
    cudaError_t err = call;                          \
    if (err != cudaSuccess) {                        \
        fprintf(stderr, "CUDA error %s:%d: %s\n",   \
            __FILE__, __LINE__, cudaGetErrorString(err)); \
        abort();                                     \
    }                                                \
} while (0)

#ifdef USE_CUDA
    launch_gpu_kernel(data);
#else
    compute_cpu_fallback(data);
#endif
```

**原则**：先看 `.h` 头文件理解接口，再看 `.cpp` 理解实现，从 `pybind/` 找到 Python 入口。

---

## 7. vLLM 源码中的三个典型模式

### 7.1 调度器循环（简化）

```cpp
class Scheduler {
public:
    std::vector<ScheduleDecision> schedule() {
        std::vector<ScheduleDecision> decisions;
        // 阶段 1：从 waiting 队列调度新请求
        while (!waiting_queue_.empty() && has_capacity()) {
            auto seq = std::move(waiting_queue_.front());
            waiting_queue_.pop_front();
            if (!allocate_for(seq)) { waiting_queue_.push_front(std::move(seq)); break; }
            seq->set_status(RUNNING);
            running_.push_back(seq);
            decisions.push_back({ADD, seq});
        }
        // 阶段 2：检查抢占 (preemption)
        for (auto& seq : running_)
            if (!seq->has_new_tokens())
                decisions.push_back({PREEMPT, seq});
        // 阶段 3：swap 管理 (GPU <-> CPU)
        while (!swap_queue_.empty()) {
            decisions.push_back({SWAP, swap_queue_.front()});
            swap_queue_.pop();
        }
        return decisions;
    }
private:
    std::deque<std::shared_ptr<Sequence>> waiting_queue_;
    std::vector<std::shared_ptr<Sequence>> running_;
    std::queue<std::shared_ptr<Sequence>> swap_queue_;
};
```

### 7.2 Block Manager -- PagedAttention 核心

```cpp
// 每个 block 存 BLOCK_SIZE 个 token 的 KV Cache
constexpr int BLOCK_SIZE = 16;

class NaiveBlockManager {
public:
    // seq_id -> {block_id_0, block_id_1, ...}
    // Token  0~15  -> block_id_0
    // Token 16~31  -> block_id_1
    using BlockTable = std::vector<int>;

    bool allocate(SeqId sid, size_t n) {
        if (free_blocks_.size() < n) return false;
        for (size_t i = 0; i < n; i++) {
            int blk = free_blocks_.front(); free_blocks_.pop();
            block_tables_[sid].push_back(blk);
        }
        return true;
    }

    void free(SeqId sid) {
        auto it = block_tables_.find(sid);
        if (it == block_tables_.end()) return;
        for (int blk : it->second) free_blocks_.push(blk);
        block_tables_.erase(it);
    }

    const BlockTable& get_block_table(SeqId sid) const {
        return block_tables_.at(sid);
    }
private:
    std::unordered_map<SeqId, BlockTable> block_tables_;
    std::queue<int> free_blocks_;
};
```

### 7.3 Model Runner 执行流程

```cpp
class ModelRunner {
public:
    ModelOutput execute_model(
        const std::vector<SequenceGroup>& scheduled_seqs,
        const std::vector<int>& block_tables  // 展平的 block table
    ) {
        prepare_input(scheduled_seqs, block_tables);  // 构造 GPU tensor
        auto hidden_states = forward();                // 模型前向
        auto tokens = sample(hidden_states);           // 采样
        return {hidden_states, tokens};
    }
};
```

---

## 8. pybind11：C++ 与 Python 的桥梁

### 8.1 调用流程

```
+-------------------+          +-------------------+          +-------------------+
|                   |  调用    |                   |  调用    |                   |
|   Python 代码      | -------> |   pybind11 层     | -------> |   C++ 核心         |
|                   |          |                   |          |                   |
| scheduler.py      |          | bindings.cpp      |          | scheduler.cpp     |
| s = Scheduler()   |          | PYBIND11_MODULE   |          | class Scheduler { |
| s.schedule(...)   |          |   m.def("schedule"|          |   void schedule();|
|                   |          |   , &schedule_fn);|          | };                |
+-------------------+          +-------------------+          +-------------------+
       ^                                                             |
       |                    Python list <-- vector<int>              |
       +-------------------------------------------------------------+
```

### 8.2 完整示例

```cpp
// ===== csrc/my_ops.cpp =====
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>       // vector <-> list 自动转换
namespace py = pybind11;

class TokenSampler {
    float temperature_; int top_k_;
public:
    TokenSampler(float temp, int k) : temperature_(temp), top_k_(k) {}
    int sample(const std::vector<float>& logits) {
        std::vector<std::pair<float, int>> idx;
        for (size_t i = 0; i < logits.size(); i++)
            idx.emplace_back(logits[i], i);
        std::partial_sort(idx.begin(), idx.begin() + top_k_, idx.end(),
                          std::greater<>());
        return idx[0].second;  // 简化
    }
    void set_temperature(float t) { temperature_ = t; }
};

PYBIND11_MODULE(my_ops, m) {
    m.doc() = "My inference engine ops";
    py::class_<TokenSampler>(m, "TokenSampler")
        .def(py::init<float, int>(), py::arg("temperature") = 1.0,
             py::arg("top_k") = 50)
        .def("sample", &TokenSampler::sample, py::arg("logits"))
        .def("set_temperature", &TokenSampler::set_temperature);
}
```

```python
# Python 侧调用
import my_ops
s = my_ops.TokenSampler(temperature=0.8, top_k=50)
token_id = s.sample([0.1, 0.5, 0.2, 2.1, -0.3, 1.1])  # list 自动转 vector
```

### 8.3 vLLM 中的常见 pybind 模式

```cpp
// vLLM 张量接口 — 零拷贝 GPU 操作
m.def("reshape_and_cache", &reshape_and_cache,
    "Reshape key/value and cache into paged KV cache");
m.def("paged_attention_v1", &paged_attention_v1,
    py::arg("out"), py::arg("query"), py::arg("key_cache"), py::arg("value_cache"));
```

---

## 9. 调试

### 9.1 阅读 Segfault 堆栈

```
==12345==ERROR: AddressSanitizer: SEGV on unknown address 0x000000000000
    #0 vllm::BlockManager::get_block_table(...) block_manager.cpp:42
    #1 vllm::ModelRunner::prepare_input(...) model_runner.cpp:156
    #2 vllm::ModelRunner::execute_model(...) model_runner.cpp:89
    #3 pybind11::cpp_function::dispatcher(...)
解读：空指针解引用。block_manager.cpp:42 中 this 指针或返回引用为空。
```

### 9.2 GDB 基础命令

```bash
gdb --args python my_script.py
(gdb) run                    # 运行
(gdb) bt                     # 调用栈
(gdb) bt full                # 调用栈 + 局部变量
(gdb) frame 3                # 切换到第 3 帧
(gdb) info locals            # 当前帧局部变量
(gdb) print block_tables_.size()
(gdb) print *this            # 打印 this 指向的对象
(gdb) break block_manager.cpp:42
(gdb) continue / step / next
(gdb) thread apply all bt    # 所有线程的调用栈
```

### 9.3 AddressSanitizer 和 CUDA 检查

```bash
# CPU 侧
g++ -fsanitize=address -g -O1 my_code.cpp -o my_program
./my_program  # 检测：heap-buffer-overflow, use-after-free, double-free, leak

# GPU 侧
compute-sanitizer --tool memcheck python run_vllm.py
```

---

## 10. 线程安全 -- vLLM 的多线程调度

```cpp
#include <mutex>
#include <shared_mutex>
#include <atomic>

class ThreadSafeBlockManager {
    mutable std::mutex mutex_;
    std::queue<int> free_blocks_;
    std::unordered_map<SeqId, std::vector<int>> block_tables_;

public:
    bool allocate(SeqId sid, size_t n) {
        std::lock_guard<std::mutex> lock(mutex_);  // RAII 锁，析构自动解锁
        if (free_blocks_.size() < n) return false;  // return 也会触发解锁
        for (size_t i = 0; i < n; i++) {
            block_tables_[sid].push_back(free_blocks_.front());
            free_blocks_.pop();
        }
        return true;
    }
};

// === 同时锁多个 mutex，避免死锁 ===
class RequestQueue {
    std::mutex in_, out_;
public:
    void transfer() {
        std::scoped_lock lock(in_, out_);  // C++17，同时锁两个
        move_all(incoming_, outgoing_);
    }
};

// === Atomic：无锁全局 ID 生成 ===
std::atomic<uint64_t> counter_{0};
uint64_t next_id() { return counter_.fetch_add(1, std::memory_order_relaxed); }

// === 请求取消标志 ===
class Request {
    std::atomic<bool> cancelled_{false};
public:
    void cancel() { cancelled_.store(true, std::memory_order_release); }
    bool is_cancelled() const { return cancelled_.load(std::memory_order_acquire); }
};
```

---

## 11. 内存布局 -- 面向数据的设计

### 11.1 栈 vs 堆

```
+---------------------------+ 高地址
|         栈 (Stack)         |  局部变量，8MB，自动管理，极快
|           ↓               |  超限 → stack overflow
|           ↑               |
+---------------------------+  
|         堆 (Heap)          |  new/malloc，GB 级，手动管理，较慢
|   静态数据 (.bss/.data)    |  全局变量
|   代码段 (.text)           |  程序指令
+---------------------------+ 低地址
规则：大对象/不确定生命周期 → 堆；小对象/确定作用域 → 栈
```

### 11.2 SoA vs AoS -- GPU 友好的数据布局

```
【AoS: Array of Structures — 对 GPU 不友好】
struct Token { int id; float logit; float attn; };
Token tokens[4];
布局: [id0|logit0|attn0|id1|logit1|attn1|id2|logit2|attn2|id3|logit3|attn3]
      交错排列。GPU warp 读 id 时，相邻线程读到的地址不连续 → 多次内存事务

【SoA: Structure of Arrays — 对 GPU 友好】
struct TokenBatch { int* ids; float* logits; float* attn_scores; };
布局: [id0|id1|id2|id3]              ← 连续，一次 warp 读取 = 一次内存事务
      [logit0|logit1|logit2|logit3]  ← 连续，合并访问 (coalesced)
      [attn0|attn1|attn2|attn3]      ← 连续，无 bank conflict
```

### 11.3 Cache Line 与 False Sharing

```
Cache line = 64 bytes
+--------------------------------------------------+
|              一个 Cache Line (64B)                 |
| [thread_0_counter] [thread_1_counter] [padding...] |
+--------------------------------------------------+
         ^                    ^
    Core 0 写入           Core 1 写入
    → invalidate 整行    → invalidate 整行
    → Core 1 重加载      → Core 0 重加载
这就是 False Sharing：不同变量在同一 cache line，互相使缓存失效。

解决：
struct alignas(64) PaddedCounter { std::atomic<size_t> counter{0}; };
// 每个变量独占一个 cache line，vLLM 的 WorkerStats 常用此模式
```

---

## 12. 推理引擎代码实战精选

### 12.1 PagedAttention Kernel 骨架

```cpp
// vLLM csrc/attention/ 中的真实 kernel 骨架
template <typename scalar_t, int HEAD_SIZE, int BLOCK_SIZE>
__global__ void paged_attention_kernel(
    scalar_t* __restrict__ out,              // [num_seqs, num_heads, head_size]
    const scalar_t* __restrict__ query,
    const scalar_t* __restrict__ key_cache,  // [num_blocks, num_heads, head_size, block_size]
    const scalar_t* __restrict__ value_cache,
    const int* __restrict__ block_tables,    // [num_seqs, max_blocks]
    const int* __restrict__ context_lens,
    float scale
) {
    const int seq_idx = blockIdx.x, head_idx = blockIdx.y;
    const int ctx_len = context_lens[seq_idx];
    const int num_blocks = (ctx_len + BLOCK_SIZE - 1) / BLOCK_SIZE;

    for (int b = 0; b < num_blocks; b++) {
        int phys_blk = block_tables[seq_idx * max_blocks + b];  // 逻辑→物理映射
        // key_cache[phys_blk][head_idx][:][:]  — 从分页 KV cache 读取
        // 计算 attention score，做 online softmax
    }
}
```

### 12.2 PyTorch 的 FlashAttention 类型分发

```cpp
// PyTorch extension 中的 kernel 分发模式
at::Tensor flash_attention_forward(const at::Tensor& q, const at::Tensor& k,
                                    const at::Tensor& v, float scale) {
    AT_DISPATCH_FLOATING_TYPES_AND_HALF(q.scalar_type(), "flash_attn", [&] {
        flash_attention_kernel<scalar_t>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
            v.data_ptr<scalar_t>(),
            q.size(0), q.size(1), q.size(2), q.size(3), scale);
    });
    // AT_DISPATCH_FLOATING_TYPES_AND_HALF 展开后为 float/double/half/bfloat16 各实例化一份
    return output;
}
```

### 12.3 异步双缓冲流水线

```cpp
template <typename T>
class DoubleBufferPipeline {
public:
    void swap_and_launch(cudaStream_t stream) {
        std::swap(front_, back_);            // 交换
        launch_kernel(back_->data(), stream); // back 异步计算
        cpu_process(front_->data());          // front 同时被 CPU 读写
    }
private:
    std::unique_ptr<CudaBuffer> front_, back_;
};
```

---

## 与 AI Infra 的关联

| 知识点 | AI Infra 中的实际应用 |
|--------|----------------------|
| 类/继承/虚函数 | vLLM `BlockAllocator` 基类，不同策略的子类 |
| RAII / 智能指针 | CUDA 资源管理、`unique_ptr<ModelRunner>`、模型权重生命周期 |
| 移动语义 | Tensor 在 layer 间零拷贝传递、`std::move` 传输 `SamplerOutput` |
| STL 容器 | `vector<int>` 做 Block Table、`deque<Sequence>` 做调度队列 |
| Lambda | CUDA stream 回调、`std::function` 存回调 |
| 头文件/命名空间/宏 | 读懂 `csrc/` 目录结构，`CUDA_CHECK`、`DISPATCH` 等宏 |
| pybind11 | Python 调用 C++ core 的入口，`PYBIND11_MODULE` |
| 线程安全 | 调度器多线程、采样并发、KV cache 线程安全 |
| 数据布局 | SoA 设计 GPU kernel 输入、避免 false sharing |
| GDB/ASAN | 排查 segfault、use-after-free、CUDA 越界 |

**核心认知**：在 AI Infra 领域，C++ 不是用来刷题的。你要的是：看到一个 C++ 类能快速理解其职责和生命周期；看到一个 kernel 能看懂数据流和并行策略；看到一个 pybind 绑定能追踪调用链。以上每一个代码示例都是推理引擎中的真实模式。

---

## 13. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| RAII | 像"门禁卡借还制"一样，获取资源时拿卡，离开时自动归还 | 本文第2节 |
| 移动语义 | 像"搬家"一样，只转移所有权指针，不搬运家具（数据） | 本文第3节 |
| pybind11 | 像"翻译官"一样，在 Python 和 C++ 之间传递调用和返回值 | 本文第8节 |
| 虚函数/多态 | 像"统一遥控器"一样，同一个接口操作不同的设备（子类） | 本文第1节 |
| STL 容器 | 像"工具箱"一样，vector 是收纳盒（顺序），map 是标签本（按键查找） | 本文第4节 |

## 14. A800 部署场景举例

**场景1：调试 vLLM PagedAttention Kernel 内存越界**

在 A800 上运行 Qwen-33B 推理服务时，偶发 segfault 崩溃。通过 GDB 定位到 `paged_attention_v2.cu` 中的 block table 索引越界：

```bash
# 挂载 GDB 到运行中的 vLLM 进程
gdb --args python -m vllm.entrypoints.openai.api_server \
    --model /models/Qwen2.5-32B-Instruct \
    --tensor-parallel-size 2

(gdb) break paged_attention_v2.cu:186
(gdb) print physical_block_id   # 发现为 -1，说明 block table 查询返回了无效值
(gdb) bt                        # 回溯调用链：Worker → ModelRunner → PagedAttention Kernel
```

结合本文第2节（RAII 封装 `CudaBuffer`）和第6节（源码阅读）的知识，你可以追踪到是 `block_tables_` 的 `unordered_map` 存在并发访问问题，修复后再用 `compute-sanitizer` 验证。

**场景2：用 pybind11 为自定义量化算子暴露 Python 接口**

在 A800 上部署 DeepSeek-67B，需要集成一个自研的 INT4 CUDA 量化 kernel：

```python
# Python 端调用
import torch
import custom_quant_ops  # 由 pybind11 编译的 .so
weight_fp16 = torch.randn(4096, 4096, dtype=torch.float16, device='cuda')
weight_int4, scale = custom_quant_ops.quantize_int4(weight_fp16)
# 预期: weight_int4.shape == (4096, 1024)  # INT4 打包后大小减半
```

参考本文第8节（pybind11）的模式，将 CUDA kernel 封装为 `PYBIND11_MODULE`，在 Python 侧直接调用，避免了 70% 以上的序列化开销。

## 15. 上下游串联

```
上游 ← 本文档 → 下游

上游：Python 推理服务层（FastAPI / vLLM Engine）
      Python 通过 pybind11 调用 C++ 核心逻辑，C++ 源码阅读能力帮助你
      理解从 Python entrypoint 到 C++ 执行的调用链。

下游：CUDA Kernel 执行层
      本文档教的 RAII、移动语义、模板等是阅读 CUDA kernel 封装代码
      （如 csrc/cache_kernels.cu）的前提，理解 C++ 封装后才能看懂
      kernel launch 的参数准备和错误处理。

完整链路参考：end-to-end-inference-trace.md
  HTTP Request → FastAPI → vLLM AsyncLLMEngine → Scheduler →
  ModelRunner → C++ Worker (pybind11) → CUDA Kernel → GPU HBM
```

---
---
## 深入学习资源

### 书籍
1. **《C++ Primer (第5版)》** -- 重点看 Part III（类设计）、IV（泛型编程）、V（高级主题）
2. **《Effective Modern C++》Scott Meyers** -- 第 4 章（智能指针）和第 5 章（移动语义）必读
3. **《CUDA C++ Programming Guide》NVIDIA 官方** -- 不须通读，遇到 `__global__`/`__shared__`/`threadIdx` 时查即可

### 在线资源
4. **cppreference.com** -- STL 容器的官方参考，遇到不认识的直接查
5. **pybind11 官方文档** -- 看 "First steps" 和 "Classes" 两章就够
6. **vLLM 源码的 `csrc/` 目录** -- 最好的教材就是你要读的代码本身

### 动手路径
7. 用 pybind11 写一个简单的 C++ extension 暴露给 Python（30 分钟）
8. 读 vLLM `csrc/cache_kernels.cu` -- 理解 `reshape_and_cache` kernel（1 小时）
9. 读 vLLM `csrc/attention/` -- 理解 PagedAttention kernel（2 小时）
10. 读 PyTorch `ATen/native/cuda/` 中一个简单的 kernel 实现（1 小时）
11. 用 GDB attach 运行中的 vLLM，打断点在 `Scheduler::schedule`，step 进去（尝试性学习）

### 特别提醒
- **不要"学完再开始读源码"** -- 边读边查效率最高
- **遇到不认识的语法，直接查 cppreference 或问 AI** -- 不需要记住所有细节
- **关注数据流而非语法糖** -- 理解"数据从哪来、到哪去"比某个模板技巧重要 10 倍
- **先看头文件，再看实现** -- 头文件定义接口契约，是理解架构的最佳入口
