# 网络基础：AI Infra 工程师的必修课
> 面向 AI Infra 工程师，聚焦 GPU 集群推理与分布式训练所需的网络知识。从 TCP 协议栈到 NCCL 通信，从 REST API 到 NVLink 拓扑，覆盖全栈网络体系。
---
## 1. TCP/IP 协议深度解析
### 1.1 为什么需要深入 TCP

推理服务中 gRPC 基于 TCP，SSE 依赖 TCP 字节流语义。常见问题根源：
- **延迟抖动**：TCP 重传或拥塞控制
- **tail latency 高**：P99 是 P50 的 10 倍 --- TCP 慢启动
- **吞吐上不去**：滑动窗口太小或丢包

### 1.2 三次握手

```
Client                              Server
  |------- SYN (seq=x) ------------>|  LISTEN → SYN_RCVD (1 RTT)
  |<------ SYN+ACK (seq=y, ack=x+1)-|  SYN_RCVD
  |------- ACK (ack=y+1)----------->|  ESTABLISHED
```

- 同机房 RTT ~0.05-0.1ms，`tcp_syn_retries` 默认 6 (超时约 127s)
- 短连接额外付出 1 RTT，首 token 延迟敏感场景必须使用连接池

### 1.3 TCP 状态机

```
                          +---------+
                          |  CLOSED |
                          +---------+
                              | ^
        被动打开              | |  主动关闭
        ┌─────────────────────┘ └──────────┐
        V                                   |
     +---------+        +---------+        |
     |  LISTEN  |        |SYN_SENT |        |
     +---------+        +---------+        |
        |                   |              |
     SYN|rcv            SYN+ACK            |
        V                   V              |
     +---------+        +---------+        |
     |SYN_RCVD |        |ESTABLISH|        |
     +---------+        +---------+        |
        |                   |              |
     ACK|                   |              |
        V                   |              |
     +---------+            |              |
 +-->|ESTABLISH|<-----------/              |
 |   +---------+                           |
 |     |     \____ std:_____               |
 |     |                    \              |
 |  FIN_WAIT_1 <--FIN---- CLOSE_WAIT       |
 |     |                     |             |
 |  ACK|                  FIN|             |
 |     V                     V             |
 |  FIN_WAIT_2           LAST_ACK          |
 |     |                     |             |
 |  FIN|                  ACK|             |
 |     V                     V             |
 |  TIME_WAIT (2MSL=60s)-->CLOSED          |
 |     |                                   |
 +--- CLOSED <-----------------------------+
```

**TIME_WAIT**：持续 2MSL=60s。SSE 服务中客户端主动断开时堆积大量 TIME_WAIT：
```bash
sysctl -w net.ipv4.tcp_tw_reuse=1
```

### 1.4 滑动窗口与流量控制

```
发送方                                   接收方
+---+---+---+---+---+---+---+---+
| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |     buffer: [ ][ ][ ][ ] → win=4
+---+---+---+---+---+---+---+---+
  ^确认  ^待确认  ^可发送     ^不可发送
  <----- 滑动窗口(win=4) ----->
```

带宽延迟积 BDP = 带宽 × RTT。25Gb/s RTT=1ms → BDP=3.125MB，窗口不够大则打不满带宽：
```bash
sysctl -w net.core.rmem_max=134217728
```

### 1.5 拥塞控制

```
cwnd ^
 |                                    ...
 |                              ..-""|
 |                        ..-""      |
 |                  ..-""            |
 |             ..-""                 | 拥塞避免：线性增长
 |        ..-""                      |
 |   ..-""                           |
 |..""                               |
 +-----------------------------------> RTT
  慢启动：cwnd 每 RTT 翻倍，直到 ssthresh
```

**四大算法**：

| 算法       | 触发条件          | 行为                                  |
|------------|-------------------|---------------------------------------|
| 慢启动     | 连接建立/RTO超时   | cwnd 从 1 MSS 起，每 ACK 加 1 MSS      |
| 拥塞避免   | cwnd ≥ ssthresh   | cwnd 每 RTT 增加 1 MSS                 |
| 快速重传   | 收到 3 个重复 ACK  | 立即重传，不等 RTO                      |
| 快速恢复   | 快速重传后         | ssthresh=cwnd/2, cwnd=ssthresh+3      |

```bash
# GPU 集群推荐 BBR（基于带宽和 RTT 建模，非基于丢包）
sysctl -w net.ipv4.tcp_congestion_control=bbr
```

对 NCCL 的影响：跨节点 TCP 中 Cubic 在交换机缓冲小时吞吐坍塌。RDMA 绕过内核，避免拥塞控制不确定性。

---

## 2. Socket 编程与 I/O 模型

### 2.1 BSD Socket API 流程

```
Server Process                       Client Process
socket() → bind() → listen()           socket()
     |                               |
accept() ← 监听队列(backlog)    connect() → TCP 三次握手
     |                               |
已连接 fd                          已连接 fd
     |                               |
  recv()/send() <====== 数据交换 =====> send()/recv()
     |                               |
  close()                           close()
```

### 2.2 C10K 问题与 epoll

| 方案         | 原理                  | 并发能力 |
|--------------|----------------------|----------|
| fork/thread  | 每连接一个进程/线程     | ~100-1000|
| select/poll  | 轮询所有 fd, O(N)     | ~数千    |
| epoll(Linux) | 事件通知, O(1)         | 百万级   |
| io_uring     | 零系统调用环形缓冲区    | 千万级   |

**epoll 原理**：

```
应用程序                    内核
epoll_create1() ---------> 创建 epoll 实例 (红黑树 + 就绪链表)
epoll_ctl(ADD, fd) ------> 注册 fd 到红黑树，挂载回调
                       ... 数据到达 NIC ...
epoll_wait() <------------ 从就绪链表拷贝事件到用户空间
  处理就绪 fd:
recv/send (非阻塞模式)
```

LT：可读/可写即通知（默认）；ET：仅状态变化时通知一次，需循环读到 EAGAIN。

### 2.3 Python asyncio 与 epoll

```python
import asyncio

async def handle_stream(reader, writer):
"""SSE 流式响应的本质：await = 交出控制权给 epoll"""
prompt = await reader.read(4096)   # epoll_wait → sock.recv()
for token in generate(prompt):
    writer.write(f"data: {token}\n\n".encode())
    await writer.drain()           # 缓冲区满时等待 EPOLLOUT

async def main():
server = await asyncio.start_server(handle_stream, '0.0.0.0', 8000)
# 底层: socket()→bind()→listen()→非阻塞→epoll_ctl(ADD)→epoll_wait 循环
async with server:
    await server.serve_forever()
```

---

## 3. HTTP 协议族

### 3.1 HTTP/1.1 关键特性

**Keep-Alive**：默认持久连接，避免 TCP 握手开销。**管线化**：受 HOL Blocking 影响，实际极少使用。

```
HTTP/1.1 管线化 HOL 阻塞：
请求1(大文件) → |----慢传输----| 响应1
请求2(小JSON) → |              | 响应2 ← 被请求1阻塞！
请求3(小JSON) → |              | 响应3 ← 被阻塞！

浏览器用 6 个并行连接规避 → 对推理服务：每个连接独立
```

### 3.2 HTTP/2：多路复用

核心创新：**二进制分帧层**，单 TCP 连接复用多 Stream：

```
HTTP/1.1:                          HTTP/2:
+-------+ +-------+ +-------+      +---------------------------+
| 请求1  | | 请求2  | | 请求3  |      | Stream1:[H][D1][D1]       |
| TCP1   | | TCP2   | | TCP3   |      | Stream2:[H][D2]          |
+-------+ +-------+ +-------+      | Stream3:[H][D3][D3][D3]   |
 |         |         |         +---------------------------+
 V         V         V                     |
   服务端(被动多连接)                    服务端(单TCP多Stream)
```

| 特性      | HTTP/1.1 | HTTP/2          |
|-----------|----------|-----------------|
| 传输格式   | 文本     | 二进制帧         |
| 多路复用   | 否       | 是 (Stream级)   |
| 头部压缩   | 无       | HPACK           |
| 流量控制   | 仅TCP    | Stream级+连接级 |

### 3.3 HTTP/3 与 QUIC

HTTP/3 基于 QUIC(UDP)，彻底解决 TCP HOL 阻塞：HTTP/2 丢失的 TCP 段仍阻塞所有 Stream；HTTP/3 每个 Stream 独立，丢失仅影响自身。

| 特性     | TCP+TLS 1.3 | QUIC          |
|----------|-------------|---------------|
| 握手 RTT | 2 RTT       | 0-RTT/1-RTT   |
| 传输层   | 内核态 TCP   | 用户态 QUIC   |
| 连接迁移 | 不支持       | 支持(CID)     |

### 3.4 推理服务协议选择

| 场景                      | 协议     | 原因                              |
|---------------------------|----------|-----------------------------------|
| 流式 Chat Completions(SSE)| HTTP/1.1 | SSE 依赖长连接和简单语义            |
| gRPC 推理服务              | HTTP/2   | 双向流和多路复用                    |
| 非流式 REST API            | HTTP/1.1 | 简单、广泛兼容                     |
| 服务器间 RPC               | gRPC     | 强类型、高性能、原生流式支持         |

**SSE 需要 HTTP/1.1**：基于长连接模型，HTTP/2 多路复用与 SSE 单向推送语义不匹配。
**gRPC 使用 HTTP/2**：需要四种流模式，只有 HTTP/2 多 Stream 模型能原生支持。

---

## 4. REST API 设计与 OpenAI 协议

### 4.1 Chat Completions API --- 事实标准

几乎 vLLM、TGI、TensorRT-LLM 都兼容此接口。

**请求**：
```json
POST /v1/chat/completions
{
  "model": "meta-llama/Llama-3-70b",
  "messages": [{"role": "user", "content": "Hello"}],
  "temperature": 0.7, "max_tokens": 512, "stream": true
}
```

**非流式响应**：
```json
{"id":"chatcmpl-abc","object":"chat.completion","choices":[{"index":0,
  "message":{"role":"assistant","content":"..."},"finish_reason":"stop"}],
  "usage":{"prompt_tokens":25,"completion_tokens":15,"total_tokens":40}}
```

**流式 SSE 响应**：
```
data: {"id":"...","choices":[{"delta":{"content":"Quantum"},"finish_reason":null}]}

data: {"id":"...","choices":[{"delta":{"content":" computing"},"finish_reason":null}]}

data: [DONE]
```

### 4.2 vLLM 流式实现要点

```python
async def stream_response(request):
# Content-Type: text/event-stream, Cache-Control: no-cache
# Connection: keep-alive, X-Accel-Buffering: no (禁用 Nginx 缓冲)
async for chunk in engine.generate(request.prompt, request.params):
    yield f"data: {json.dumps(format_chunk(chunk))}\n\n"
yield "data: [DONE]\n\n"
```

### 4.3 设计检查清单

- **认证与限流**：API Key/JWT；Token Bucket 按用户限流
- **健壮性**：请求超时；指数退避重试；断路器模式防雪崩
- **可观测性**：X-Request-ID 链路追踪；TTFT/TPOT/吞吐量指标；OpenTelemetry
- **兼容性**：OpenAI SDK 兼容 base_url；版本化 API (/v1/)；统一错误格式

---

## 5. gRPC 内部机制

### 5.1 Protobuf 定义

```protobuf
service InferenceService {
rpc Infer(ModelInferRequest) returns (ModelInferResponse);           // 一元
rpc StreamInfer(ModelInferRequest) returns (stream ModelInferResponse); // 服务端流
rpc ChatInfer(stream ChatMessage) returns (stream ChatMessage);     // 双向流
}

message ModelInferRequest {
string model_name = 1; string model_version = 2;
repeated InferInputTensor inputs = 3; bytes raw_input_contents = 5;
}
message InferInputTensor { string name = 1; string datatype = 2; repeated int64 shape = 3; }
```

### 5.2 gRPC 四种通信模式

```
一元 RPC:         Client ──req──> Server ──resp──> Client
服务端流:          Client ──req──> Server ──tok1──tok2──...──tokN──> Client
客户端流:          Client ──chk1──chk2──...──chkN──> Server ──resp──> Client
双向流:           Client ──msg1──> <──resp1── ──msg2──> <──resp2── ... > Server
```

### 5.3 Triton 选择 gRPC 的原因

| 维度     | HTTP/1.1+JSON | gRPC+Protobuf  |
|----------|---------------|----------------|
| 序列化    | JSON ~1-5ms   | Protobuf ~0.1-0.5ms |
| 连接复用  | 需连接池       | 原生多路复用    |
| P50/P99  | 5ms/15ms      | 1ms/3ms        |

(1) 二进制序列化减少 CPU 开销；(2) HTTP/2 多路复用承载数百并发请求；(3) 原生流式支持 token 级输出。

---

## 6. NCCL 通信与 GPU 互联

### 6.1 带宽层级（以 H100 为例）

```
带宽 ↑
(GB/s)
900  ████████████████████████████  NVLink 4.0 (900 GB/s 单向, 18 links × 50)
 ███
 ███  ███████████████████████  NVSwitch (3.2 TB/s 全双工)
 ███  ███
400  ███  ███  ██████████████████  InfiniBand NDR400 (50 GB/s)
 ███  ███  ███
100  ███  ███  ███  █████████████  IB HDR100 (12.5 GB/s)
 ███  ███  ███  ███
 64  ███  ███  ███  ███  ████████  PCIe 5.0 x16 (64 GB/s)
 ███  ███  ███  ███  ████
 25  ███  ███  ███  ███  ████      200GbE RoCE (25 GB/s)
 ███  ███  ███  ███  ████
  3  ███  ███  ███  ███  ████      25GbE (3 GB/s)
 ──────────────────────────────────────
  NVLink NVSwitch NDR400 HDR100 PCIe5 200G 25G
延迟:  ~1μs   ~1μs    ~1-2μs ~1-2μs ~1μs  ~5μs ~10μs
```

**关键洞察**：NVLink 900 GB/s vs 200GbE 25 GB/s，差距 **36 倍**。这是多节点 TP 几乎不可行的根本原因。

### 6.2 NVLink 与 NVSwitch 拓扑 (DGX H100)

```
GPU0 ←─NVLink 900GB/s─→ GPU1
 ↕                      ↕
GPU2 ←────────────────→ GPU3
 ↕                      ↕          NVSwitch 0,1,2,3
GPU4 ←────────────────→ GPU5       (全互联, 3.2 TB/s 全双工)
 ↕                      ↕
GPU6 ←────────────────→ GPU7
 |          ...          |
 +──── NVSwitch (4个) ───+

每个 GPU 通过 18 条 NVLink 链路连接所有 4 个 NVSwitch。
任意 GPU 对之间全带宽点对点通信。
```

### 6.3 PCIe vs InfiniBand vs RoCE v2

| 特性         | PCIe 5.0 x16   | IB NDR400       | RoCE v2 (200GbE) |
|-------------|----------------|-----------------|------------------|
| 单向带宽     | 64 GB/s        | 50 GB/s (400Gb/s) | 25 GB/s          |
| 延迟        | ~1 μs          | ~1-2 μs          | ~5 μs            |
| GPU Direct  | 是             | 是 (GDR)         | 是 (GDR)         |
| 交换机       | 不需要(树形)   | 需要 IB 交换机    | 标准以太网交换机   |
| 无损传输     | 是             | 是(内置)         | 需 PFC+ECN        |

---

## 7. All-Reduce 算法深度

### 7.1 Ring All-Reduce

```
输入 (N=4 GPUs):                    输出:
GPU0:[a0,b0,c0]                     所有GPU:[a_sum,b_sum,c_sum]
GPU1:[a1,b1,c1]                     其中 a_sum=a0+a1+a2+a3
GPU2:[a2,b2,c2]
GPU3:[a3,b3,c3]

过程 (数据分 N 块, 大小 D/N):
  Scatter-Reduce (N-1 步) —— 环形传递并累加:
  第1步: GPU0→GPU1, GPU1→GPU2, GPU2→GPU3, GPU3→GPU0
  第2步: 继续环形传递（GPUn持有自己块号的累加结果）
  第N-1步后: 每个GPU持有 1/N 的完整归约结果

  AllGather (N-1 步) —— 环形广播累加结果:
  每个GPU将自己持有的完整块传给邻居
  经N-1步后，所有GPU拥有全部归约结果

总步数: 2(N-1)
每GPU总发送量: 2×(N-1)/N×D ≈ 2D (大N时)
时间: T_ring = 2(N-1) × (α + D/(N×B))
(α=延迟启动开销~5-10μs, B=带宽)
```

### 7.2 Tree All-Reduce

```
N=8 GPU 的二叉树:
    Round 1 (Reduce自底向上):
    GPU0──┐        GPU4──┐
          ├→GPU1         ├→GPU5
    GPU2──┘        GPU6──┘
          ↓              ↓
    GPU1 ────────────────→ GPU3(root)
    GPU5 ────────────────→

    Round 2 (Broadcast自顶向下):
    GPU3→GPU1→GPU0    GPU3→GPU5→GPU4
          └→GPU2            └→GPU6

总步数: 2×log₂(N)     (N=8: 6步 vs Ring的14步; N=64: 12步 vs 126步)
时间: T_tree = 2×log₂(N) × (α + D/B)
```

### 7.3 CollNet (NVSwitch单步All-Reduce)

```
传统All-Reduce:                     CollNet (需NVSwitch):
GPU0:[a0]→                          GPU0:[a0]─┐
GPU1:[a1]→  多步→[a_sum]→所有GPU     GPU1:[a1]─┤
GPU2:[a2]→                          GPU2:[a2]─┼→NVSwitch→[a_sum]→所有GPU (1步!)
GPU3:[a3]→                          GPU3:[a3]─┘

硬件要求: DGX系列 + NVSwitch全互联 + NVLink全互联
```

### 7.4 算法选择

```
        数据量 D ->
GPU数量    1KB     1MB    1GB   100GB
N=2-8     Tree    Tree   Ring  Ring
N=8-64    Tree    Ring   Ring  Ring
N>64      Tree    Tree   Ring  Ring

有NVSwitch(N≤8): CollNet CollNet CollNet 不适用
选择依据: 延迟主导区(D小)→Tree; 带宽主导区(D大)→Ring
NCCL自动选择最优算法，但理解原理有助于性能诊断
```

---

## 8. RDMA 技术

### 8.1 内核旁路机制

```
传统 I/O:                     RDMA:
应用 ⇅ buffer(copy_from_user)  应用 ⇅ MR(直接访问,绕过内核)
内核 TCP/IP栈                   RNIC
NIC                            网络
网络

CPU: 是   延迟: ~10-50μs       CPU: 否   延迟: ~1-2μs
```

### 8.2 Verbs API 核心抽象

```
Protection Domain (PD): 安全域，所有 RDMA 资源容器
  │
  ├── Memory Region (MR): 注册的内存，RNIC 可直接访问
  │   (pin物理内存, lkey/rkey 访问密钥)
  │
  ├── Queue Pair (QP): 通信端点
  │   ├── Send Queue (SQ): 发送请求队列
  │   └── Receive Queue (RQ): 接收请求队列
  │
  └── Completion Queue (CQ): 完成通知队列
  每个 Work Completion 对应一个完成的 Work Request
```

**编程流程**：`ibv_open_device`→`alloc_pd`→`reg_mr`→`create_cq`→`create_qp`→`modify_qp(INIT→RTR→RTS)`→`post_send/recv`→`poll_cq`

### 8.3 单边 vs 双边操作

```
双边(Two-sided):                     单边(One-sided):
发送方          接收方               发起方          目标方(被动)
post_send ──→ post_recv              rdma_write ──→ 直接写入目标地址
 (数据)──→ (缓冲区)               (数据+地址)──→ CPU不受影响
poll_cq        poll_cq               poll_cq

应用: MPI, NCCL send/recv           应用: 分布式KV, GPU Direct RDMA写入
```

---

## 9. GPU 集群网络拓扑

### 9.1 Fat-Tree

```
     ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
Spine:   │Spine1│ │Spine2│ │Spine3│ │Spine4│  (越往上越粗)
     └──┬─┬──┘ └──┬─┬──┘ └──┬─┬──┘ └──┬─┬──┘
        │ │       │ │       │ │       │ │
     ┌──┴─┴───────┴─┴───────┴─┴───────┴─┴──┐
Leaf:    │Leaf1│Leaf2│Leaf3│Leaf4│Leaf5│Leaf6│
     └──┬──┘└──┬──┘└──┬──┘└──┬──┘└──┬──┘└──┬─┘
        │      │      │      │      │      │
Server:  [S1]   [S2]   [S3]   [S4]   [S5]   [S6]
```

收敛比 = 下行/上行。1:1 无阻塞；3:1 常见 GPU 集群；10:1 不适合训练。

### 9.2 Rail-Optimized (DGX SuperPOD)

```
GPU0 --- NIC0(Rail0) --- Leaf0 ---+
GPU1 --- NIC1(Rail1) --- Leaf1 ---+
...                               +-- Spine(全互联)
GPU7 --- NIC7(Rail7) --- Leaf7 ---+
```
每 GPU 专用 NIC(不共享 PCIe)；同编号 NIC 连同一 Leaf→形成"轨道"；同 Rail 直通无需跨交换机。DGX H100 SuperPOD: 8×CX7 NDR400 + 32×Quantum-2。

### 9.3 通信路径对比

```
Fat-Tree: GPU0→Leaf0→Spine→Leaf0→GPU0 (4跳,跨交换机争用)
Rail:     GPU0→Rail0→GPU0             (1跳,同交换机)
```

---

## 10. GPU Direct RDMA (GDR)

### 10.1 数据路径对比

```
无 GDR:
GPU0显存 →(cudaMemcpy D2H)→ CPU内存 →(RDMA Write)→ NIC → 网络
→ 对端NIC →(RDMA)→ CPU内存 →(cudaMemcpy H2D)→ GPU1显存
共 4 次数据拷贝！

有 GDR:
GPU0显存 →(PCIe, NIC直接读取)→ NIC → 网络
→ 对端NIC →(PCIe, NIC直接写入)→ GPU1显存
共 0 次 CPU 内存拷贝！延迟大幅降低。
```

### 10.2 启用配置

```bash
# 验证 GPU 与 NIC 在同一 PCIe 根复合体下
nvidia-smi topo -m
# 要求 PIX (PCIe Switch 连接) 或更近

# NCCL 环境变量
export NCCL_NET_GDR_LEVEL=5    # 0=禁用, 1-5=不同级别
export NCCL_NET_GDR_READ=1     # 启用 GDR read
# 日志中查看: "NET/Plugin: Using GDR"
```

---

## 11. NCCL 集合通信操作

### 11.1 操作全集与使用场景

```
操作            │ 输入→输出                    │ 通信量         │ 使用场景
────────────────┼──────────────────────────────┼────────────────┼─────────────
AllReduce      │ 各GPU本地数据→所有GPU得归约结果 │ 2(N-1)/N×D    │ DP梯度同步
ReduceScatter  │ 归约结果分散到各GPU            │ (N-1)/N×D     │ FSDP, SP
AllGather      │ 各GPU不同数据→所有GPU收集全部   │ (N-1)/N×D     │ TP, SP
Broadcast      │ 1个GPU发送→所有GPU接收         │ D             │ 参数分发
All-to-All     │ 各GPU发不同块到各GPU(个性化)    │ (N-1)/N×D    │ MoE专家路由
P2P (send/recv)│ GPU i → GPU j                │ D             │ PP激活传递
```

### 11.2 在模型并行中的使用

```
数据并行(DP) —— AllReduce(梯度) × 1次/N步 —— 通信量=2×参数量, 需高带宽
张量并行(TP) —— AllReduce × 每层2次/每token —— 延迟极高敏感, 必须NVLink
流水线并行(PP) —— P2P send/recv × 1次/N层 —— 通信频率低, 以太网足够
序列并行(SP) —— AllGather/ReduceScatter × 每层 —— 需较高带宽
专家并行(EP) —— All-to-All × 每层 —— 间歇性高通信量(MoE特有)
```

---

## 12. 多节点推理网络分析

### 12.1 延迟预算分解 (Llama-3-70B, TP=8, 2节点)

```
                高速网络(25GB/s)           低速网络(3GB/s)
组件                 时间(ms)   占比            时间(ms)   占比
────────────────────────────────────────────────────────────────
GPU 计算(所有层)       12.0     46%             12.0      22%
机内通信(NVLink)        8.0     31%              8.0      15%
跨节点通信(网络)         4.0     15%             32.0      58%  ← 成为瓶颈！
采样                    0.1     <1%              0.1      <1%
到用户的网络传输         1.0      4%              1.0       2%
其他开销                1.0      4%              1.0       2%
────────────────────────────────────────────────────────────────
总计                   26.1    100%             54.1     100%  (+107%)
```

### 12.2 各并行策略的网络需求

```
并行策略    单步通信量      延迟敏感度    带宽需求
DP         梯度(GB级)      低(异步DP)    高
TP         激活(MB级)      极高(每token) 极高(NVLink)
PP         激活(MB级)      中            低(以太网)
SP         激活(MB级)      高            高
EP         路由(MB-GB级)   中            中(取决于稀疏度)
```

**结论**：(1) 推理尽可能单机内完成；(2) 跨节点需高速网络(IB NDR400/400GbE)；(3) 多节点 TP 性价比低。

---

## 13. 关键的 Socket 选项

### 13.1 TCP_NODELAY --- 流式推理最关键选项

```
Nagle 开启(TCP_NODELAY=0, 默认):
  有新数据、前数据未确认且大小<MSS → 等待直到确认或满MSS
  结果: 每个 token 延迟 ~40ms (延迟ACK超时) → 体验极差

Nagle 关闭(TCP_NODELAY=1):
  每次 write() 立即发送，无论大小/确认状态
  结果: 每个 token 立即送达 → 流畅体验
  代价: 更多小包，但完全值得
```

```python
import socket
def configure_streaming_sock(sock):
sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)  # 禁用 Nagle
sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 4*1024*1024)  # 4MB发送缓冲
sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4*1024*1024)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)  # 检测死连接
sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 60)
sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 10)
sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 3)
```

### 13.2 其他关键选项与内核参数

```bash
# SO_REUSEADDR — 允许 TIME_WAIT 端口立即重用
# 推理服务频繁重启/滚动更新必备

# 内核参数
net.core.somaxconn = 4096           # accept() 积压队列
net.core.rmem_max = 134217728       # 最大接收缓冲
net.ipv4.tcp_rmem = 4096 131072 134217728
net.ipv4.tcp_tw_reuse = 1           # TIME_WAIT 端口重用
```

---

## 14. 推理服务负载均衡

### 14.1 L4 vs L7

```
             L4 (TCP/UDP层)              L7 (HTTP/gRPC层)
────────────────────────────────────────────────────────────
转发依据:         IP + Port                   URL, Header, Cookie
SSL Termination:  否                          是
延迟:             ~1μs                        ~100μs
工具:             HAProxy(tcp), Nginx(stream)  Nginx, Envoy, Traefik
────────────────────────────────────────────────────────────

推理服务两层架构：
  边缘层(L7): Nginx/Envoy — SSL终止 + 路由 + 限流
  ↓
  服务层(L4): HAProxy stream — 快速TCP负载均衡
  ↓
  推理引擎: vLLM / TGI / TensorRT-LLM
```

### 14.2 一致哈希 (流式SSE会话保持)

```
哈希环 (0 到 2^32-1):
  ┌───────────NodeA───────────NodeB───────────NodeC────────────┐
  │                    ↗hash(session_id)                       │
  │                  映射到 NodeA ← 同 session 始终路由到这里    │
  └────────────────────────────────────────────────────────────┘

优势: 节点增减时仅重映射 K/N 个 key；虚拟节点(150-200个/物理节点)改善分布
```

```nginx
upstream inference_backend {
hash $arg_session_id consistent;  # 按 session_id 一致哈希
server node1:8000; server node2:8000;
server node3:8000; server node4:8000;
keepalive 128; keepalive_timeout 120s;
}
server {
listen 443 ssl http2;
location /v1/chat/completions {
    proxy_pass http://inference_backend;
    proxy_http_version 1.1;
    proxy_buffering off;          # 禁用缓冲 ← SSE 关键！
    proxy_read_timeout 600s;      # 长流式响应超时
    proxy_set_header Connection "";  # 清除 close
}
}
```

### 14.3 健康检查

```
Liveness:  GET /health          → 200 if server running
Readiness: GET /health/ready     → 200 if model loaded and ready
Deep:      GET /health/generate  → 测试推理

Envoy 配置: timeout=3s, interval=10s, unhealthy_threshold=3, healthy_threshold=2
```

---

## 与 AI Infra 的关联

网络知识贯穿 AI Infra 工程师的推理与训练技术栈：

**推理场景**：
1. **流式响应优化**：TCP_NODELAY禁用Nagle，TIME_WAIT管理，拥塞控制调优
2. **负载均衡**：L4/L7分层，一致哈希SSE会话保持，健康检查
3. **多节点TP评估**：NVLink(900 GB/s) vs 网络差距36倍，正确判断可行性
4. **协议选择**：SSE需HTTP/1.1语义，gRPC需HTTP/2多路复用

**训练场景**：
5. **NCCL性能调优**：Ring vs Tree 延迟/带宽权衡
6. **网络拓扑设计**：Fat-Tree/Leaf-Spine/Rail-Optimized选型与收敛比评估
7. **RDMA与GPU Direct**：Verbs API(QP/CQ/WR)，内核旁路，GDR消除CPU中转
8. **集合通信与模型并行**：各操作在 DP/TP/PP/SP/EP 中的使用模式

**关键判断力**：
9. **带宽vs延迟瓶颈诊断**：大N延迟主导，大D带宽主导
10. **首token延迟分解**：拆解关键路径网络贡献，量化跨节点TP开销

---

## 15. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| TCP_NODELAY | 像"不攒够一车再发快递"一样，有数据就立即发送 | 本文第13节 |
| SSE | 像"广播电台"一样，服务器持续单向推送数据给客户端 | 本文第3/4节 |
| gRPC | 像"专线电话"一样，二进制协议+双向流，比 HTTP/JSON 更高效 | 本文第5节 |
| NCCL | 像"GPU之间的高速快递网络"一样，所有卡之间并行传输数据 | 本文第6/11节 |
| RDMA | 像"直接往邻居家冰箱放东西"一样，绕过对方 CPU，直写内存 | 本文第8节 |

## 16. A800 部署场景举例

**场景1：多节点部署 DeepSeek-67B 时的网络调优**

在 2 台 A800 服务器（每台 8 卡）上通过 TP=8+PP=2 部署 DeepSeek-67B：

```bash
# 1. 启用 BBR 拥塞控制（GPU 集群推荐）
sysctl -w net.ipv4.tcp_congestion_control=bbr

# 2. 增大 socket 缓冲区以利用 25GbE 全带宽
sysctl -w net.core.rmem_max=134217728
sysctl -w net.core.wmem_max=134217728

# 3. 启用 GPU Direct RDMA（消除 CPU 中转）
export NCCL_NET_GDR_LEVEL=5
export NCCL_NET_GDR_READ=1

# 4. 验证 RoCE v2 是否已启用 GDR
# 启动后检查 NCCL 日志: "NET/Plugin: Using GDR"
```

跨节点通信 3.2GB KV Cache 块时，GDR 使延迟从 ~15ms（经 CPU 中转）降到 ~4ms（NIC 直读 GPU HBM）。参考本文第10节。

**场景2：SSE 流式输出调优（禁用 Nagle + Nginx 缓冲配置）**

```nginx
# 代理层必须禁用缓冲，否则 SSE 流式体验差
location /v1/chat/completions {
    proxy_pass http://vllm_backend;
    proxy_buffering off;  ← 关键！禁用 Nginx 缓冲
    proxy_read_timeout 600s;
}

# vLLM 服务端确保 TCP_NODELAY=1（见本文第13节）
```

## 17. 上下游串联

```
上游 ← 本文档 → 下游

上游：客户端请求（HTTP/gRPC 入站）
      本文档覆盖了推理请求从客户端到达服务器的完整网络路径，
      包括协议选择（SSE→HTTP/1.1、gRPC→HTTP/2）、负载均衡策略。

下游：GPU 集群内部通信（NCCL/RDMA）
      当模型被切分到多卡/多节点时，本文档教的 NVLink/InfiniBand/RoCE
      拓扑、All-Reduce 算法选择、GPU Direct RDMA 是跨卡通信的基础。

完整链路参考：end-to-end-inference-trace.md
  客户端 → HTTP/gRPC → 负载均衡器(L4/L7) → vLLM API Server →
  推理引擎 → NCCL All-Reduce(跨卡) → GPU Kernel → 响应流式返回
```

---
---
## 深入学习资源

### 书籍

| 书名 | 作者 | 推荐理由 |
|------|------|---------|
| **TCP/IP Illustrated, Vol 1** (2nd) | Stevens/Fall | TCP协议栈圣经，重点关注12-16章(TCP) |
| **UNIX Network Programming, Vol 1** (3rd) | Stevens | Socket编程权威指南，第6章(I/O复用)、第26章(线程) |
| **High Performance Browser Networking** | Ilya Grigorik | HTTP/2、TLS、WebSocket实践，免费在线版 hpbn.co |
| **Computer Networking: A Top-Down Approach** (8th) | Kurose/Ross | 系统学习，第3章(传输层)扎实 |

### NVIDIA 官方文档

| 资源 | 链接 |
|------|------|
| NCCL 文档 | https://docs.nvidia.com/deeplearning/nccl/ |
| NVLink/NVSwitch 白皮书 | https://www.nvidia.com/en-us/data-center/nvlink/ |
| DGX H100 系统架构 | https://docs.nvidia.com/dgx/dgxh100-user-guide/ |
| GPU Direct RDMA | https://docs.nvidia.com/cuda/gpudirect-rdma/ |
| ConnectX/Spectrum 文档 | https://docs.nvidia.com/networking/ |

### 论文与博客

- "How NCCL Works" - Sylvain Jeaugey (NCCL作者) --- NCCL内部机制必读系列
- "Bringing HPC Techniques to Deep Learning" - Baidu (2017) --- Ring All-Reduce 开创性工作
- "A Tutorial on RDMA Programming" --- Mellanox/NVIDIA RDMA 编程教程
- "Massively Scale Your Deep Learning Training with NCCL 2.4" --- NCCL 环/树切换详解
- "Scaling Distributed ML with the Parameter Server" - OSDI 2014 --- 参数服务器架构

### 在线资源

1. **Beej's Guide to Network Programming** (https://beej.us/guide/bgnet/) -- Socket 编程最佳入门教程
2. **Cloudflare Blog - Networking** (https://blog.cloudflare.com/tag/networking/) -- HTTP/3、QUIC、TCP 调优前沿
3. **Linux Kernel Networking Docs** (https://www.kernel.org/doc/html/latest/networking/) -- TCP/IP 协议栈实现
4. **vLLM 源码** (https://github.com/vllm-project/vllm) -- `entrypoints/` 流式实现, `engine/` 推理调度
5. **NVIDIA Magnum IO** (https://developer.nvidia.com/magnum-io) -- GPU 集群 I/O 技术全景
