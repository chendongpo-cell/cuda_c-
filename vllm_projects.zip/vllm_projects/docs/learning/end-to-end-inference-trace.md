# 一次完整的 AI Infra 推理请求全链路追踪

> **场景**：用户部署 Qwen2.5-32B (dense, 33B parameters) 在 2×A800 上使用 vLLM，发送一个 Chat Completion 请求。
>
> **目标**：逐层追踪一个 `curl` 请求如何从网线进入、穿过 FastAPI、被调度器调度、在 GPU 上执行 Transformer 计算、通过 PagedAttention 读写 KV Cache、最终生成 500 个 token 并逐字流式返回给用户。
>
> **覆盖文档**：本文档串联了全部 41 篇学习文档，是整套学习材料的「总索引」和「全景图」。

---

## 目录

- [Part 1: 请求全景图 (Overview)](#part-1-请求全景图-overview)
- [Part 2: 逐层深度追踪 (Layer-by-Layer Trace)](#part-2-逐层深度追踪-layer-by-layer-trace)
  - [Layer 1: 网络层 (Network) -- ~1ms](#layer-1-网络层-network----1ms)
  - [Layer 2: API 层 (FastAPI/vLLM Entry) -- ~2ms](#layer-2-api-层-fastapivllm-entry----2ms)
  - [Layer 3: 调度层 (Scheduler) -- ~0.5ms](#layer-3-调度层-scheduler----05ms)
  - [Layer 4: 执行层 (ModelRunner/Worker) -- ~150ms prefill + ~12.5s decode](#layer-4-执行层-modelrunnerworker----150ms-prefill--125s-decode)
  - [Layer 5: Attention 子层 (PagedAttention Kernel) -- ~80ms prefill + ~8s decode](#layer-5-attention-子层-pagedattention-kernel----80ms-prefill--8s-decode)
  - [Layer 6: CUDA 执行层 (GPU Hardware) -- 内含在上层](#layer-6-cuda-执行层-gpu-hardware----内含在上层)
  - [Layer 7: 量化层 (AWQ/GPTQ) -- 如适用](#layer-7-量化层-awqgptq----如适用)
- [Part 3: 易混淆技术辨析 (Tech Differentiation)](#part-3-易混淆技术辨析-tech-differentiation)
- [Part 4: 性能瓶颈逐层排查 (Expert Troubleshooting Guide)](#part-4-性能瓶颈逐层排查-expert-troubleshooting-guide)
- [Part 5: 线上并发优化实操方案 (Production Optimization)](#part-5-线上并发优化实操方案-production-optimization)
- [附录 A: 全部 41 篇文档索引](#附录-a-全部-41-篇文档索引)
- [附录 B: 关键数字速查表](#附录-b-关键数字速查表)
- [附录 C: 核心源码文件速查](#附录-c-核心源码文件速查)

---

## Part 1: 请求全景图 (Overview)

### 1.1 一次推理请求的完整路径

```
时间轴 (ms)    0        1        2        3       4~5      6~155    155~12655
              |        |        |        |        |        |         |
              v        v        v        v        v        v         v
┌─────────────────────────────────────────────────────────────────────────────────────┐
│            Qwen2.5-32B 推理请求全链路追踪 (55 input tokens → 500 output tokens)        │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  Layer 1: 网络层 (~1ms)                                                               │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │ curl → TCP 三次握手 → HTTP POST /v1/chat/completions → FastAPI Uvicorn 接收     │  │
│  │ 文档: stage1-cs-basics/networking.md                                           │  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
│                                          │                                           │
│                                          ▼                                           │
│  Layer 2: API 层 (~2ms)                                                               │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │ JSON 解析 → Chat Template 应用 → Tokenize (55 tokens) → SamplingParams         │  │
│  │ → AsyncLLMEngine.add_request() → 创建 Sequence → 加入 WAITING 队列              │  │
│  │ 文档: stage1-cs-basics/python-essentials.md, direction-B/vllm-architecture.md   │  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
│                                          │                                           │
│                                          ▼                                           │
│  Layer 3: 调度层 (~0.5ms)                                                             │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │ Scheduler.schedule(): WAITING → can_allocate(OK) → 分配 KV Cache 块             │  │
│  │ → RUNNING → 构建 Attention Metadata (block_table, slot_mapping)                  │  │
│  │ 文档: direction-B/continuous-batching.md, vllm-source-reading/02-scheduler-core.md│  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
│                                          │                                           │
│                                          ▼                                           │
│  Layer 4: 执行层 — Prefill (~150ms)                                                  │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │ ModelRunner.execute_model(): prepare_input → model.forward() → sample          │  │
│  │   Embedding(55 tokens, 5120 dim)                                                │  │
│  │   → 64 × TransformerBlock(RMSNorm → QKV Proj → PagedAttention → O Proj        │  │
│  │      → All-Reduce → RMSNorm → SwiGLU MLP → All-Reduce → Residual)              │  │
│  │   → lm_head (5120 → 152064 vocab) → sample → first token                       │  │
│  │ 文档: stage2/pytorch-transformer.md, vllm-source-reading/05-worker-execution.md │  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
│                                          │                                           │
│                                          ▼                                           │
│  Layer 4/5: 执行层 — Decode × 500 (~12.5s, ~25ms/token)                             │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │ 每个 step: 输入 1 个新 token → 64 层 forward → lm_head → sample → next token   │  │
│  │ PagedAttention: 1 query × N key/value（通过 block_table 索引 KV Cache）         │  │
│  │ CUDA Graph 重放: 1 次 GPU launch 完成全部 64 层计算                              │  │
│  │ 文档: direction-B/paged-attention-deep.md, direction-B/kv-cache-optimization.md │  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
│                                          │                                           │
│                                          ▼                                           │
│  Layer 2 返回: SSE 流式输出 (~500 chunks)                                              │
│  ┌───────────────────────────────────────────────────────────────────────────────┐  │
│  │ OutputProcessor: token_id → text delta → SSE data: {"choices":[{"delta":...}]}  │  │
│  │ → async generator yield → StreamingResponse → TCP → curl 终端逐字显示           │  │
│  │ 文档: stage1-cs-basics/networking.md, stage1-cs-basics/python-essentials.md     │  │
│  └───────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 模型规格速览

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              Qwen2.5-32B 关键规格                                      │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  参数总量:        33B (330 亿)                                                        │
│  架构:            Dense Transformer (非 MoE)                                          │
│  层数 (L):        64 层                                                               │
│  隐藏维度 (d):    5120                                                                │
│  Q 头数:          40                                                                  │
│  KV 头数:         8 (GQA, group_size=5)                                              │
│  每头维度:        128                                                                 │
│  中间维度 (FFN):  13824 (≈ 2.7×d, SwiGLU)                                            │
│  词表大小:        152064                                                              │
│  最大上下文:      131072 tokens                                                       │
│  权重精度:        BF16 / FP16                                                         │
│  权重显存:        ~66 GB                                                              │
│  KV Cache (1 req, 8K ctx): ~8 GB                                                     │
│                                                                                     │
│  部署硬件:        2 × NVIDIA A800 80GB                                                │
│  并行策略:        TP=2 (每卡负责 32 层)                                               │
│  互联:            NVLink 3.0 (600 GB/s 双向)                                          │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 1.3 各层时间预算分解

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              端到端延迟预算 (55 input tokens, 生成 500 tokens)          │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  阶段                    │ 耗时         │ 占比       │ 瓶颈类型          │ 关键文档    │
│  ───────────────────────┼─────────────┼───────────┼──────────────────┼───────────   │
│  TCP 连接 + HTTP 解析    │ ~1ms        │ <0.01%     │ 网络 I/O          │ networking  │
│  Tokenize + API 处理     │ ~2ms        │ <0.02%     │ CPU 计算          │ python-ess  │
│  调度 + 块分配           │ ~0.5ms      │ <0.01%     │ CPU 逻辑          │ scheduler   │
│  Prefill (55 tokens)     │ ~150ms      │ 1.2%       │ Compute-Bound     │ pytorch-tr  │
│  Decode × 500            │ ~12500ms    │ 98.8%      │ Memory-Bound      │ paged-attn  │
│  ───────────────────────┼─────────────┼───────────┼──────────────────┼───────────   │
│  总计                    │ ~12653ms    │ 100%       │ —                 │ —           │
│                                                                                     │
│  关键指标:                                                                           │
│  TTFT (首 token 延迟):   ~155ms (网络+API+调度+Prefill)                              │
│  TPOT (每 token 延迟):   ~25ms (Decode 单步)                                        │
│  吞吐 (单请求):          ~40 tokens/s                                                │
│  KV Cache 增长:          0 → 8 GB (Prefill) → 8.04 GB (Decode 500 tokens)          │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 1.4 分层架构与文档映射

```
                         ┌──────────────────────────────────┐
                         │     用户请求 (curl / Client)      │
                         └───────────────┬──────────────────┘
                                         │
    ┌────────────────────────────────────┼────────────────────────────────────┐
    │  Layer 1: 网络层                    │                                     │
    │  ─────────────────                 ▼                                     │
    │  TCP/UDP → HTTP/SSE → Nginx        │  networking.md                      │
    │───────────────────────────────────────────────────────────────────────── │
    │  Layer 2: API/应用层                                                      │
    │  ─────────────────                                                       │
    │  FastAPI → Tokenizer → AsyncLLMEngine  │ python-essentials.md            │
    │                                       │ vllm-architecture.md             │
    │───────────────────────────────────────────────────────────────────────── │
    │  Layer 3: 调度层                                                          │
    │  ───────────────                                                         │
    │  Scheduler → BlockManager → Preemption│ continuous-batching.md           │
    │                                       │ 02-scheduler-core.md              │
    │                                       │ 03-block-manager.md               │
    │                                       │ scheduling-strategies.md          │
    │───────────────────────────────────────────────────────────────────────── │
    │  Layer 4: 执行层                                                          │
    │  ───────────────                                                         │
    │  Worker → ModelRunner → TP All-Reduce │ 05-worker-execution.md           │
    │  64× TransformerBlock 前向传播        │ pytorch-transformer.md           │
    │                                       │ megatron-lm-deep-dive.md          │
    │───────────────────────────────────────────────────────────────────────── │
    │  Layer 5: Attention 子层                                                   │
    │  ───────────────────────                                                  │
    │  PagedAttention Kernel               │ paged-attention-deep.md            │
    │  FlashAttention Tiling               │ kv-cache-optimization.md           │
    │  Block Table 间接寻址                 │ attention-kernel-optimize.md       │
    │───────────────────────────────────────────────────────────────────────── │
    │  Layer 6: CUDA/GPU 硬件层                                                   │
    │  ────────────────────────                                                 │
    │  Warp 调度 → Tensor Core → HBM         │ cuda-programming.md               │
    │  SIMT 执行模型                        │ simt-parallel-model.md            │
    │  Roofline 分析                        │ cuda-kernel-deep-dive.md          │
    │───────────────────────────────────────────────────────────────────────── │
    │  Layer 7: 量化层 (可选)                                                    │
    │  ───────────────────────                                                 │
    │  AWQ/GPTQ INT4 Dequant               │ quantization-inference.md          │
    │  Marlin Kernel                       │                                    │
    └─────────────────────────────────────────────────────────────────────────┘
```

### 1.5 文档阅读顺序建议

```
第 1 步 (建全景):  本文档 (end-to-end-inference-trace.md) ← 你在这里
                    ↓
第 2 步 (看架构):  stage3-direction-B-inference/vllm-architecture.md
                    ↓
第 3 步 (看源码):  stage4-projects/vllm-source-reading/
                    01-entrypoint-startup.md → 02-scheduler-core.md
                    → 03-block-manager.md → 04-model-loader.md
                    → 05-worker-execution.md → 06-practical-tuning.md
                    ↓
第 4 步 (深挖核心): stage3-direction-B-inference/
                     continuous-batching.md → paged-attention-deep.md
                     → kv-cache-optimization.md → quantization-inference.md
                    ↓
第 5 步 (理解硬件): stage2-ai-infra-foundations/
                     pytorch-transformer.md → cuda-programming.md
                     → simt-parallel-model.md
                    ↓
第 6 步 (动手实验): stage4-projects/hands-on-labs/
                     lab01 → lab02 → lab03
                    ↓
第 7 步 (扩展视野): stage3-direction-A-kernel/ (算子开发)
                    stage3-direction-C-training/ (分布式训练)
                    stage3-direction-D-mlops/ (集群运维)
```

---

## Part 2: 逐层深度追踪 (Layer-by-Layer Trace)

### Layer 1: 网络层 (Network) -- ~1ms

**参考文档**: `stage1-cs-basics/networking.md`

#### 1.1 TCP 连接建立

```
用户主机 (curl)                              服务器 (2×A800 节点)
    │                                              │
    │  curl -X POST http://localhost:8000/...       │
    │  ───────────────────────────────────────────▶ │
    │                                              │
    │  ① DNS 解析 (localhost → 127.0.0.1, 本地跳过)  │
    │                                              │
    │  ② TCP 三次握手 (同机回环, ~0.1ms)              │
    │     SYN (seq=x)                               │
    │  ───────────────────────────────────────────▶ │
    │                          SYN+ACK (seq=y, ack=x+1)
    │  ◀─────────────────────────────────────────── │
    │     ACK (ack=y+1)                             │
    │  ───────────────────────────────────────────▶ │
    │     状态: ESTABLISHED                         │
    │                                              │
    │  ③ HTTP 请求发送 (~0.2ms)                      │
    │     POST /v1/chat/completions HTTP/1.1         │
    │     Host: localhost:8000                       │
    │     Content-Type: application/json             │
    │     Content-Length: 256                        │
    │     Accept: text/event-stream                  │
    │     Connection: keep-alive                     │
    │     {                                          │
    │       "model": "qwen2.5-32b",                  │
    │       "messages": [{"role":"user",             │
    │         "content":"用Python写快速排序"}],       │
    │       "max_tokens": 500,                       │
    │       "stream": true                           │
    │     }                                          │
    │  ───────────────────────────────────────────▶ │
    │                                              │
```

#### 1.2 HTTP 请求如何到达 FastAPI

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                          从 TCP 字节流到 Python 协程                                    │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  网卡 (NIC)                                                                          │
│    │  DMA → 内核 Ring Buffer                                                         │
│    ▼                                                                                 │
│  内核 TCP/IP 栈                                                                      │
│    │  TCP 重组 → IP 分片 → 协议解析                                                    │
│    │  状态: TCP_NODELAY (关闭 Nagle, 每个小包立即发送, SSE 关键!)                       │
│    ▼                                                                                 │
│  Socket 接收缓冲区 (SO_RCVBUF, 默认 ~212KB)                                           │
│    │  epoll_wait() 返回 EPOLLIN 事件                                                   │
│    ▼                                                                                 │
│  Python asyncio Event Loop (uvloop)                                                  │
│    │  uvloop 基于 libuv, 使用 epoll 实现高性能事件循环                                 │
│    │  await reader.read() → 协程挂起 → epoll 通知 → 协程恢复                           │
│    ▼                                                                                 │
│  Uvicorn (ASGI Server)                                                               │
│    │  HTTP 协议解析: 请求行 → 请求头 → 请求体                                            │
│    │  ASGI scope = {type: "http", method: "POST", path: "/v1/chat/completions"}     │
│    ▼                                                                                 │
│  FastAPI Application                                                                │
│    │  URL 路由匹配 → openai/api_server.py::create_chat_completion()                   │
│    ▼                                                                                 │
│  Pydantic 请求验证                                                                    │
│    │  ChatCompletionRequest.model_validate(body_json)                                 │
│    │  验证: model 字段、messages 结构、max_tokens 范围                                  │
│    ▼                                                                                 │
│  Layer 2: API 层                                                                     │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 1.3 关键 Engineering Insight: 为什么 SSE 需要 proxy_buffering off

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                    Nginx 反向代理对 SSE 流式输出的影响                                   │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  场景: 生产环境通常在前面加一层 Nginx 做反向代理                                          │
│                                                                                     │
│  ❌ 默认行为 (proxy_buffering on):                                                    │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │  vLLM 后端:                                                                    │    │
│  │    token 1 "用" → SSE data: {delta:"用"}                                      │    │
│  │    token 2 "Python" → SSE data: {delta:"Python"}                              │    │
│  │    token 3 "写" → SSE data: {delta:"写"}                                      │    │
│  │                    │                                                           │    │
│  │                    ▼                                                           │    │
│  │  Nginx buffer:    [data1][data2][data3]... (攒够 4KB 或请求结束才发送!)         │    │
│  │                                                                               │    │
│  │  结果: 用户看到的是「卡了很久后一次性吐出全部内容」, 不是逐字输出!               │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                     │
│  ✅ 正确配置 (proxy_buffering off):                                                  │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │  location /v1/chat/completions {                                               │    │
│  │      proxy_pass http://vllm_backend:8000;                                      │    │
│  │      proxy_buffering off;           ← 核心! 关闭代理缓冲                        │    │
│  │      proxy_read_timeout 600s;       ← SSE 长连接, 超时设长                      │    │
│  │      proxy_set_header Connection "";  ← 清除 hop-by-hop 头                      │    │
│  │      chunked_transfer_encoding on;    ← 分块传输编码                             │    │
│  │      tcp_nodelay on;                 ← 关闭 TCP Nagle, 小包立即发               │    │
│  │  }                                                                             │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                     │
│  TCP_NODELAY 的极端重要性:                                                           │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │  没有 TCP_NODELAY (Nagle 算法):                                                │    │
│  │    token 1 → 写入 socket → 等待 ACK (40ms!) → 发送                             │    │
│  │    token 2 → 写入 socket → 等待 ACK (40ms!) → 发送                             │    │
│  │    每个 token 延迟 40ms → 500 tokens × 40ms = 20s 额外延迟!                    │    │
│  │                                                                               │    │
│  │  有 TCP_NODELAY:                                                               │    │
│  │    token 1 → 写入 socket → 立即发送 → 延迟 ~0.05ms                              │    │
│  │    token 2 → 写入 socket → 立即发送 → 延迟 ~0.05ms                              │    │
│  │    总延迟 < 25ms                                                               │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                     │
│  参考: networking.md 第 13.1 节 TCP_NODELAY, 第 14.2 节 Nginx 反向代理配置             │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 1.4 SSE 流式响应的网络层全景

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           SSE (Server-Sent Events) 流式响应                            │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  HTTP 响应头:                                                                        │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │  HTTP/1.1 200 OK                                                              │    │
│  │  Content-Type: text/event-stream       ← SSE MIME 类型                        │    │
│  │  Cache-Control: no-cache               ← 禁用浏览器缓存                        │    │
│  │  Connection: keep-alive                ← 保持长连接                            │    │
│  │  Transfer-Encoding: chunked            ← 分块传输编码                          │    │
│  │  X-Accel-Buffering: no                 ← 告诉 Nginx 不要缓冲                   │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                     │
│  SSE 数据格式 (逐 token 推送):                                                        │
│  ┌─────────────────────────────────────────────────────────────────────────────┐    │
│  │                                                                               │    │
│  │  data: {"id":"cmpl-xxx","object":"chat.completion.chunk",                     │    │
│  │         "created":1700000000,"model":"qwen2.5-32b",                           │    │
│  │         "choices":[{"index":0,"delta":{"content":"用"},"finish_reason":null}]} │    │
│  │  <空行>                                                                        │    │
│  │                                                                               │    │
│  │  data: {"id":"cmpl-xxx","object":"chat.completion.chunk",                     │    │
│  │         "choices":[{"index":0,"delta":{"content":"Python"},"finish_reason":null}]}│  │
│  │  <空行>                                                                        │    │
│  │                                                                               │    │
│  │  ... (逐 token) ...                                                            │    │
│  │                                                                               │    │
│  │  data: {"id":"cmpl-xxx","object":"chat.completion.chunk",                     │    │
│  │         "choices":[{"index":0,"delta":{"content":""},"finish_reason":"stop"}]} │    │
│  │  <空行>                                                                        │    │
│  │                                                                               │    │
│  │  data: [DONE]                                                                 │    │
│  │  <空行>                                                                        │    │
│  │                                                                               │    │
│  │  (连接关闭)                                                                     │    │
│  └─────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### Layer 2: API 层 (FastAPI/vLLM Entry) -- ~2ms

**参考文档**: `stage1-cs-basics/python-essentials.md`, `stage3-direction-B-inference/vllm-architecture.md`

#### 2.1 请求处理流水线

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                     FastAPI → AsyncLLMEngine 请求处理流水线                             │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  API Server (FastAPI / Uvicorn)                                                     │
│  文件: vllm/entrypoints/openai/api_server.py                                        │
│                                                                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  ① 路由匹配                                                                   │   │
│  │    @router.post("/v1/chat/completions")                                      │   │
│  │    async def create_chat_completion(request: ChatCompletionRequest):         │   │
│  │                                                                              │   │
│  │  ② Chat Template 应用                                                        │   │
│  │    ┌─────────────────────────────────────────────────────────────┐          │   │
│  │    │ 原始 messages:                                                │          │   │
│  │    │   [{"role": "user", "content": "用Python写快速排序"}]          │          │   │
│  │    │                                                               │          │   │
│  │    │ 经过 chat_template (Jinja2):                                  │          │   │
│  │    │   <|im_start|>system                                          │          │   │
│  │    │   You are Qwen, created by Alibaba Cloud.                     │          │   │
│  │    │   <|im_end|>                                                  │          │   │
│  │    │   <|im_start|>user                                            │          │   │
│  │    │   用Python写快速排序                                            │          │   │
│  │    │   <|im_end|>                                                  │          │   │
│  │    │   <|im_start|>assistant                                       │          │   │
│  │    │                                                               │          │   │
│  │    │  → 完整 prompt string                                         │          │   │
│  │    └─────────────────────────────────────────────────────────────┘          │   │
│  │                                                                              │   │
│  │  ③ Tokenize                                                                  │   │
│  │    ┌─────────────────────────────────────────────────────────────┐          │   │
│  │    │  tokenizer.encode(prompt)                                     │          │   │
│  │    │  → [151644, 8948, 198, 2610, 525, 264, 10950, ...]          │          │   │
│  │    │  共 55 个 token IDs (包括 system prompt + user message)       │          │   │
│  │    │  每个 token ID 是 [0, 152064) 范围内的整数                    │          │   │
│  │    └─────────────────────────────────────────────────────────────┘          │   │
│  │                                                                              │   │
│  │  ④ 采样参数构造                                                               │   │
│  │    SamplingParams(                                                           │   │
│  │        max_tokens=500,          # 最多生成 500 token                         │   │
│  │        temperature=0.7,        # 默认 (未指定时)                             │   │
│  │        top_p=0.9,              # nucleus sampling                            │   │
│  │        stop_token_ids=[151645], # <|im_end|>                                │   │
│  │        detokenize=True,        # 自动将 token ID 转回文本                    │   │
│  │    )                                                                         │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  AsyncLLMEngine                                                                     │
│  文件: vllm/engine/async_llm_engine.py                                              │
│                                                                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  ⑤ add_request()                                                              │   │
│  │                                                                              │   │
│  │  async def add_request(                                                       │   │
│  │      request_id: str,                    # 自动生成 UUID                       │   │
│  │      prompt: str | TokenSequence,                                             │   │
│  │      sampling_params: SamplingParams,                                         │   │
│  │  ) -> AsyncStream:                                                            │   │
│  │                                                                              │   │
│  │  # Step 1: 确保 prompt 已 tokenize                                            │   │
│  │  if isinstance(prompt, str):                                                  │   │
│  │      prompt_token_ids = tokenizer.encode(prompt)                              │   │
│  │                                                                              │   │
│  │  # Step 2: 创建 SequenceGroup                                                │   │
│  │  seq = Sequence(                                                              │   │
│  │      seq_id=next_seq_id,              # 全局递增序列 ID                        │   │
│  │      prompt_token_ids=prompt_token_ids,                                      │   │
│  │      block_size=16,                  # KV Cache 块大小                        │   │
│  │  )                                                                           │   │
│  │  seq_group = SequenceGroup(                                                   │   │
│  │      request_id="uuid-xxx",                                                  │   │
│  │      seqs=[seq],                     # 大多数请求只有 1 个序列                 │   │
│  │      sampling_params=sampling_params,                                        │   │
│  │      arrival_time=time.time(),        # 记录到达时间 (计算 TTFT)               │   │
│  │  )                                                                           │   │
│  │                                                                              │   │
│  │  # Step 3: 加入调度器等待队列                                                  │   │
│  │  scheduler.add_seq_group(seq_group)     # → self.waiting.append(seq_group)    │   │
│  │                                                                              │   │
│  │  # Step 4: 创建输出流, 返回给 API Server                                       │   │
│  │  output_stream = AsyncStream(request_id)                                     │   │
│  │  output_processor.add_request(request_id, output_stream)                     │   │
│  │  return output_stream                                                        │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 2.2 数据结构流转图

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                    原始文本 → Token IDs → Engine 请求 的数据流                           │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  raw text: "用Python写快速排序"                                                       │
│      │                                                                              │
│      │ chat_template.apply()                                                         │
│      ▼                                                                              │
│  formatted prompt: "<|im_start|>system\nYou are Qwen...\n<|im_end|>\n..."          │
│      │                                                                              │
│      │ tokenizer.encode()                                                            │
│      ▼                                                                              │
│  token IDs: [151644, 8948, 198, 2610, 525, 264, 10950, 17847, ...]  (55 tokens)    │
│      │                                                                              │
│      │ Sequence(prompt_token_ids=[...])                                              │
│      ▼                                                                              │
│  Sequence:                                                                           │
│    seq_id: 42                                                                        │
│    status: WAITING                                                                   │
│    data.prompt_token_ids: [151644, 8948, 198, ...]    # 55 个                       │
│    data.output_token_ids: []                          # 空, 等待生成                  │
│    logical_token_blocks: []                           # 未分配                       │
│      │                                                                              │
│      │ SequenceGroup(seqs=[seq])                                                     │
│      ▼                                                                              │
│  SequenceGroup:                                                                      │
│    request_id: "cmpl-uuid-xxx"                                                       │
│    arrival_time: 1700000000.123                                                      │
│    sampling_params: SamplingParams(max_tokens=500, temp=0.7, ...)                    │
│    metrics.first_token_time: None                  # 等待被调度                       │
│      │                                                                              │
│      │ scheduler.add_seq_group(seq_group)                                            │
│      ▼                                                                              │
│  进入 Layer 3: 调度器 waiting 队列                                                    │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### Layer 3: 调度层 (Scheduler) -- ~0.5ms

**参考文档**: `stage3-direction-B-inference/continuous-batching.md`, `stage4-projects/vllm-source-reading/02-scheduler-core.md`, `stage4-projects/vllm-source-reading/03-block-manager.md`, `stage3-direction-B-inference/scheduling-strategies.md`

#### 3.1 调度器在引擎循环中的位置

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           vLLM 引擎主循环 (step_async)                                  │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  AsyncLLMEngine._run_engine_loop():                                                  │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  while has_unfinished_requests():                                              │   │
│  │                                                                                │   │
│  │    ┌─────────────────────────────────────────────────────────────────────┐     │   │
│  │    │  【调度阶段】Scheduler.schedule()                                     │     │   │
│  │    │                                                                       │     │   │
│  │    │  输入:                                                                │     │   │
│  │    │    self.waiting:  [我们的请求, ...]  ← Deque[SequenceGroup]           │     │   │
│  │    │    self.running:  [请求X (decode中), 请求Y (decode中)]                │     │   │
│  │    │    self.swapped:  []                                                  │     │   │
│  │    │                                                                       │     │   │
│  │    │  输出: SchedulerOutputs                                               │     │   │
│  │    │    scheduled_seq_groups: [我们的请求 (prefill)]                        │     │   │
│  │    │    blocks_to_copy: []           ← 无 COW                              │     │   │
│  │    │    blocks_to_swap_in: []        ← 无 swap                             │     │   │
│  │    │    blocks_to_swap_out: []                                              │     │   │
│  │    │    num_prefill_groups: 1                                              │     │   │
│  │    │    num_batched_tokens: 55 (仅我们的请求, 假设无其他 prefill)           │     │   │
│  │    │                                                                       │     │   │
│  │    └─────────────────────────────────────────────────────────────────────┘     │   │
│  │                                    │                                            │   │
│  │                                    ▼                                            │   │
│  │    ┌─────────────────────────────────────────────────────────────────────┐     │   │
│  │    │  【执行阶段】ModelRunner.execute_model(scheduler_outputs)              │     │   │
│  │    │  (详见 Layer 4)                                                       │     │   │
│  │    └─────────────────────────────────────────────────────────────────────┘     │   │
│  │                                    │                                            │   │
│  │                                    ▼                                            │   │
│  │    ┌─────────────────────────────────────────────────────────────────────┐     │   │
│  │    │  【采样/后处理】Sample + Detokenize + SSE push                         │     │   │
│  │    └─────────────────────────────────────────────────────────────────────┘     │   │
│  │                                    │                                            │   │
│  │                                    ▼                                            │   │
│  │    【完成释放】 free_finished_seq_groups() (当请求完成时)                        │   │
│  │                                                                                │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 3.2 调度器决策: 我们的请求如何从 WAITING → RUNNING

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                        Scheduler._schedule_default() 决策流程                          │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  假设当前状态:                                                                        │
│    self.waiting = [我们的请求 (55 tokens)]                                            │
│    self.running = [请求X (decode, 128 tokens), 请求Y (decode, 256 tokens)]          │
│    self.swapped = []                                                                 │
│    max_num_seqs = 128                                                                │
│    max_num_batched_tokens = 2048                                                     │
│    gpu_memory_utilization = 0.90                                                     │
│                                                                                     │
│  Phase 1: Prefill 调度                                                               │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  for seq_group in self.waiting:                                                │   │
│  │                                                                               │   │
│  │    ① 检查序列数预算                                                             │   │
│  │      running 已有 2 个 (X, Y) + 我们的请求 = 3 <= 128 ✅                        │   │
│  │                                                                               │   │
│  │    ② 检查 Token 预算                                                            │   │
│  │      55 (我们的 prompt) ≤ 2048 ✅                                               │   │
│  │                                                                               │   │
│  │    ③ 检查 KV Cache 块是否足够 (核心!)                                            │   │
│  │      ┌──────────────────────────────────────────────────────────────┐        │   │
│  │      │  我们的请求需要多少 KV Cache 块?                                │        │   │
│  │      │                                                                │        │   │
│  │      │  计算: n_blocks = ceil(55 tokens / 16 block_size) = 4 块      │        │   │
│  │      │                                                                │        │   │
│  │      │  block_manager.can_allocate(seq_group)                         │        │   │
│  │      │    → 检查 GPU 空闲块池 ≥ 4                                      │        │   │
│  │      │    → 假设 GPU 有足够空闲块 → AllocStatus.OK ✅                  │        │   │
│  │      └──────────────────────────────────────────────────────────────┘        │   │
│  │                                                                               │   │
│  │    ④ 分配 KV Cache 块                                                          │   │
│  │      block_manager.allocate(seq_group)                                         │   │
│  │      ┌──────────────────────────────────────────────────────────────┐        │   │
│  │      │  物理块池:    [B0][B1][B2][B3][B4][B5][B6][B7][B8][B9]...    │        │   │
│  │      │                           ↑   ↑   ↑   ↑                       │        │   │
│  │      │  我们的块表:  logical[0]→B4, logical[1]→B5,                  │        │   │
│  │      │               logical[2]→B6, logical[3]→B7                   │        │   │
│  │      │                                                                │        │   │
│  │      │  B4 包含 tokens 0-15  的 KV Cache                              │        │   │
│  │      │  B5 包含 tokens 16-31 的 KV Cache                              │        │   │
│  │      │  B6 包含 tokens 32-47 的 KV Cache                              │        │   │
│  │      │  B7 包含 tokens 48-54 的 KV Cache (最后 7 个, 剩余槽位 0)     │        │   │
│  │      └──────────────────────────────────────────────────────────────┘        │   │
│  │                                                                               │   │
│  │    ⑤ 状态转换                                                                  │   │
│  │      seq.status: WAITING → RUNNING                                             │   │
│  │      seq_group 加入 scheduled_seq_groups                                       │   │
│  │                                                                               │   │
│  │  (我们的请求是唯一 waiting 的, 调度完成)                                         │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Phase 2: Decode 调度 (prefill 独占 batch, 跳过)                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  prefills.seq_groups 非空 → 有 prefill 时不调度 decode                         │   │
│  │  (非 Chunked Prefill 模式下, prefill 独占整个 batch)                           │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  结果:                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  self.waiting: []              (我们的请求已出队)                               │   │
│  │  self.running:  [请求X, 请求Y, 我们的请求]  (我们的请求加入 running 尾部)        │   │
│  │  scheduled_seq_groups: [我们的请求]                                            │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 3.3 Block Table 构造与 Attention Metadata 准备

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                    调度器输出 → Attention Metadata (交给 Worker)                       │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  调度器为每个 scheduled 序列准备元数据:                                                 │
│                                                                                     │
│  SequenceGroupMetadata (发送给 Worker 的数据结构):                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  seq_data: {                                                                  │   │
│  │      42: SequenceData(                                                        │   │
│  │          prompt_token_ids=[151644, 8948, 198, ...],  # 55 个                  │   │
│  │          output_token_ids=[],                        # 空                     │   │
│  │      )                                                                        │   │
│  │  }                                                                            │   │
│  │                                                                               │   │
│  │  block_tables: {                                                              │   │
│  │      42: [4, 5, 6, 7]   ← 逻辑块 → 物理块映射 (block_table)                   │   │
│  │  }                                                                            │   │
│  │                                                                               │   │
│  │  is_prompt: True             ← 这是 Prefill, 非 Decode                        │   │
│  │  query_lens: [55]            ← Prefill 需要查询全部 55 个 token               │   │
│  │  context_lens: [55]          ← 当前总长度                                      │   │
│  │  computed_block_nums: []     ← Prefix Caching 命中情况 (无命中)                │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Attention Metadata 关键字段 (构建于 ModelRunner.prepare_input()):                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  input_ids:    [151644, 8948, 198, ..., <last_prompt_token>]  (55 tokens)    │   │
│  │  positions:    [0, 1, 2, 3, ..., 54]              (每个 token 在序列中的位置)    │   │
│  │  block_tables: [[4, 5, 6, 7]]                     (GPU 上的 int32 张量)       │   │
│  │  context_lens: [55]                                (每个序列当前总长度)          │   │
│  │  slot_mapping: [B4_slot0, B4_slot1, ..., B7_slot6]  (每个 token 到 KV Cache  │   │
│  │                                                      物理槽位的映射)            │   │
│  │  query_lens: [55]                                                              │   │
│  │                                                                               │   │
│  │  slot_mapping 计算公式:                                                         │   │
│  │    logical_block_idx = position // 16                                          │   │
│  │    block_offset = position % 16                                                │   │
│  │    physical_block_id = block_table[logical_block_idx]                           │   │
│  │    slot = physical_block_id * 16 + block_offset                                 │   │
│  │                                                                               │   │
│  │  例如: position=18                                                             │   │
│  │    logical_block_idx = 18 // 16 = 1                                            │   │
│  │    block_offset = 18 % 16 = 2                                                  │   │
│  │    physical_block_id = block_table[1] = 5                                      │   │
│  │    slot = 5 * 16 + 2 = 82                                                      │   │
│  │    → token 18 的 KV Cache 写入物理块 5 的第 2 个 slot                           │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: 02-scheduler-core.md 第 10 节 (BlockManager 交互), 第 5.2 节                    │
│        03-block-manager.md 第 3 节 (BlockTable 映射)                                 │
│        vllm-architecture.md 第 4-5 节 (Scheduler + BlockManager)                    │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

### Layer 4: 执行层 (ModelRunner/Worker) -- ~150ms Prefill + ~12.5s Decode

**参考文档**: `stage4-projects/vllm-source-reading/05-worker-execution.md`, `stage2-ai-infra-foundations/pytorch-transformer.md`, `stage2-ai-infra-foundations/deep-learning-basics.md`

#### 4.1 Worker 多 GPU 执行架构 (TP=2)

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                         Worker 层 TP=2 多 GPU 执行架构                                 │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  主进程 (Driver Process)                                                             │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  EngineCore 协调器                                                             │   │
│  │    │                                                                          │   │
│  │    │ broadcast_inputs (通过 NCCL 广播或 Python IPC)                             │   │
│  │    ▼                                                                          │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  ┌──────────────────────┐              ┌──────────────────────┐                     │
│  │  GPU 0 (TP Rank 0)  │              │  GPU 1 (TP Rank 1)  │                     │
│  │  ┌────────────────┐  │              │  ┌────────────────┐  │                     │
│  │  │    Worker 0    │  │   NVLink     │  │    Worker 1    │  │                     │
│  │  │                │  │◄────────────►│  │                │  │                     │
│  │  │  ModelRunner 0 │  │  600 GB/s   │  │  ModelRunner 1 │  │                     │
│  │  │                │  │  双向        │  │                │  │                     │
│  │  │ 31GB模型参数   │  │              │  │ 31GB模型参数   │  │                     │
│  │  │ (层 0~31)      │  │              │  │ (层 32~63)     │  │                     │
│  │  │                │  │              │  │                │  │                     │
│  │  │ KV Cache (共享) │  │              │  │ KV Cache (共享) │  │                     │
│  │  │ 各层部分维度    │  │              │  │ 各层部分维度    │  │                     │
│  │  └────────────────┘  │              │  └────────────────┘  │                     │
│  └──────────────────────┘              └──────────────────────┘                     │
│                                                                                     │
│  TP=2 的工作方式:                                                                     │
│  - 权重: 每层参数按 head 维度或 hidden 维度对半切分到 2 个 GPU                          │
│  - 计算: 每个 GPU 各自做自己分片的前向计算                                             │
│  - 同步: 每层 2 次 All-Reduce (Attention 输出 + MLP 输出)                             │
│  - KV Cache: 按 head 维度分片, 各 GPU 存储自己负责的 heads 的 KV                       │
│  - 采样: 仅在 Rank 0 上执行 (收集 logits → 采样 → 广播结果)                            │
│                                                                                     │
│  参考: vllm-architecture.md 第 9 节 (多 GPU Tensor Parallelism)                       │
│        05-worker-execution.md 第 8 节 (TP Execution)                                 │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 4.2 ModelRunner.execute_model() 全流程

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                      execute_model() 的一次完整 Prefill 调用                            │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  ModelRunner.execute_model(seq_group_metadata_list, kv_caches):                      │
│                                                                                     │
│  ╔═══════════════════════════════════════════════════════════════════════════════╗   │
│  ║  Phase 1: prepare_input() — 构建 GPU 输入张量                        ~0.5ms    ║   │
│  ╠═══════════════════════════════════════════════════════════════════════════════╣   │
│  ║                                                                               ║   │
│  ║  ① 分离 Prefill 和 Decode 序列                                                  ║   │
│  ║    prefill_seqs = [我们的请求]  (metadata.is_prompt=True)                       ║   │
│  ║    decode_seqs = []               (本轮无 decode)                               ║   │
│  ║                                                                               ║   │
│  ║  ② 构造 input_ids 张量                                                          ║   │
│  ║    input_ids = [151644, 8948, 198, 2610, 525, ...]  # 55 个 token IDs         ║   │
│  ║    shape: [55]  dtype: int64  device: cuda:0                                   ║   │
│  ║                                                                               ║   │
│  ║  ③ 构造 position 张量                                                            ║   │
│  ║    positions = [0, 1, 2, 3, ..., 54]  # 每个 token 的位置索引                   ║   │
│  ║    shape: [55]  dtype: int64  device: cuda:0                                   ║   │
│  ║                                                                               ║   │
│  ║  ④ 构造 Attention Metadata                                                      ║   │
│  ║    block_tables = [[4, 5, 6, 7]]  shape: [1, max_blocks]                       ║   │
│  ║    slot_mapping = [64, 65, ..., 118]  # 物理槽位索引                            ║   │
│  ║    context_lens = [55]                                                          ║   │
│  ║    query_lens = [55]                                                            ║   │
│  ║                                                                               ║   │
│  ╚═══════════════════════════════════════════════════════════════════════════════╝   │
│                                    │                                                │
│                                    ▼                                                │
│  ╔═══════════════════════════════════════════════════════════════════════════════╗   │
│  ║  Phase 2: model.forward() — 模型前向传播                           ~149ms     ║   │
│  ╠═══════════════════════════════════════════════════════════════════════════════╣   │
│  ║                                                                               ║   │
│  ║  Step 0: Embedding (Token → Vector)                         ~0.1ms             ║   │
│  ║  ┌─────────────────────────────────────────────────────────────────┐         ║   │
│  ║  │  input_ids: [55]  int64                                          │         ║   │
│  ║  │      │  Embedding Lookup                                         │         ║   │
│  ║  │      ▼                                                            │         ║   │
│  ║  │  hidden_states: [55, 5120]  BF16  (~0.56 MB)                    │         ║   │
│  ║  │                                                                   │         ║   │
│  ║  │  权重: W_embed [152064, 5120]  (~1.56 GB BF16)                   │         ║   │
│  ║  │  操作: 查表, 无矩阵乘法 (memory-bound)                             │         ║   │
│  ║  └─────────────────────────────────────────────────────────────────┘         ║   │
│  ║                                                                               ║   │
│  ║  Step 1~64: Transformer Block × 64 循环                       ~148ms          ║   │
│  ║                                                                               ║   │
│  ║  每个 Block (~2.3ms):                                                          ║   │
│  ║  ┌───────────────────────────────────────────────────────────────────────┐   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ① RMSNorm (Pre-Attention Norm)                              ~0.1ms     │   ║   │
│  ║  │    hidden_states = hidden_states / sqrt(mean(x^2) + eps) * gamma       │   ║   │
│  ║  │    gamma: [5120]  learnable scale parameter                             │   ║   │
│  ║  │    特点: 无 bias, 无去均值 (比 LayerNorm 快 ~15%)                       │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ② QKV Projection (Linear)                                   ~0.5ms     │   ║   │
│  ║  │    输入: hidden_states [55, 5120]                                       │   ║   │
│  ║  │    W_Q: [5120, 40*128] → Q [55, 40, 128]                               │   ║   │
│  ║  │    W_K: [5120, 8*128]  → K [55, 8, 128]    ← GQA (8 KV heads)          │   ║   │
│  ║  │    W_V: [5120, 8*128]  → V [55, 8, 128]                                │   ║   │
│  ║  │    TP=2: W_Q/W_K/W_V 列切分, 每个 GPU 存一半 heads                       │   ║   │
│  ║  │    GPU0: Q 20 heads, K 4 heads, V 4 heads                               │   ║   │
│  ║  │    GPU1: Q 20 heads, K 4 heads, V 4 heads                               │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ③ RoPE (Rotary Position Embedding)                          ~0.05ms    │   ║   │
│  ║  │    Q = apply_rotary_pos_emb(Q, positions)                               │   ║   │
│  ║  │    K = apply_rotary_pos_emb(K, positions)                               │   ║   │
│  ║  │    每 2 维一组做 2D 旋转, 使注意力仅依赖于相对位置                          │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ④ PagedAttention ← 详见 Layer 5                          ~1.2ms     │   ║   │
│  ║  │    FlashAttention Tiling + PagedAttention Block Table                   │   ║   │
│  ║  │    O(55^2) attention, 通过 block_table 访问 KV Cache                    │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ⑤ O Projection (Linear)                                    ~0.3ms     │   ║   │
│  ║  │    输入: attention_output [55, 5120]                                     │   ║   │
│  ║  │    W_O: [5120, 5120] → output [55, 5120]                                │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ⑥ All-Reduce (Attention 输出同步)                           ~0.1ms     │   ║   │
│  ║  │    TP=2: 2 个 GPU 的结果求和恢复完整维度                                   │   ║   │
│  ║  │    通信量: 55 × 5120 × 2 bytes = 0.56 MB                                │   ║   │
│  ║  │    NVLink 传输: 0.56 MB / 600 GB/s ≈ 0.001ms (可忽略)                    │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ⑦ Residual Connection + RMSNorm (Pre-MLP Norm)             ~0.05ms    │   ║   │
│  ║  │    hidden_states = hidden_states + attention_output                      │   ║   │
│  ║  │    hidden_states = RMSNorm(hidden_states)                                │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ⑧ SwiGLU MLP                                               ~0.8ms     │   ║   │
│  ║  │    gate = x @ W_gate  [5120, 13824]  → gate [55, 13824]                │   ║   │
│  ║  │    up   = x @ W_up    [5120, 13824]  → up   [55, 13824]                │   ║   │
│  ║  │    mlp_out = gate * SiLU(up)           → [55, 13824]                    │   ║   │
│  ║  │    output = mlp_out @ W_down  [13824, 5120]  → [55, 5120]              │   ║   │
│  ║  │    特点: 3 个权重矩阵 (gate, up, down), SiLU 激活                         │   ║   │
│  ║  │    TP=2: W_gate/W_up 列切分, W_down 行切分                               │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ⑨ All-Reduce (MLP 输出同步)                                 ~0.1ms     │   ║   │
│  ║  │    通信量: 55 × 5120 × 2 bytes = 0.56 MB                                │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  ⑩ Residual Connection                                     ~0.01ms    │   ║   │
│  ║  │    hidden_states = hidden_states + mlp_output                           │   ║   │
│  ║  │    → 输出: [55, 5120] → 输入到下一层                                      │   ║   │
│  ║  │                                                                         │   ║   │
│  ║  │  每层总计: ~2.3ms (Prefill, 55 tokens)                                  │   ║   │
│  ║  │  64 层总计: 64 × 2.3ms ≈ 148ms                                          │   ║   │
│  ║  └───────────────────────────────────────────────────────────────────────┘   ║   │
│  ║                                                                               ║   │
│  ║  Step 65: Final RMSNorm + lm_head                            ~1ms             ║   │
│  ║  ┌─────────────────────────────────────────────────────────────────┐         ║   │
│  ║  │  hidden_states = RMSNorm(hidden_states)  → [55, 5120]            │         ║   │
│  ║  │                                                                   │         ║   │
│  ║  │  logits = hidden_states @ W_lm_head.T                             │         ║   │
│  ║  │  W_lm_head: [5120, 152064]  (~1.56 GB BF16)                      │         ║   │
│  ║  │  → logits [55, 152064]                                            │         ║   │
│  ║  │                                                                   │         ║   │
│  ║  │  我们只需要最后一个 token 的 logits:                                │         ║   │
│  ║  │  last_logits = logits[-1, :]  → [152064]  (~610 KB BF16)         │         ║   │
│  ║  │                                                                   │         ║   │
│  ║  │  (如果 lm_head 和 embedding 共享权重: 使用 tied weight)            │         ║   │
│  ║  └─────────────────────────────────────────────────────────────────┘         ║   │
│  ║                                                                               ║   │
│  ╚═══════════════════════════════════════════════════════════════════════════════╝   │
│                                    │                                                │
│                                    ▼                                                │
│  ╔═══════════════════════════════════════════════════════════════════════════════╗   │
│  ║  Phase 3: Sample — 采样                                    ~0.5ms             ║   │
│  ╠═══════════════════════════════════════════════════════════════════════════════╣   │
│  ║                                                                               ║   │
│  ║  logits [152064]  →  采样流水线 (全部在 GPU 上执行):                            ║   │
│  ║                                                                               ║   │
│  ║  ① Temperature Scaling                                                         ║   │
│  ║    logits = logits / temperature  (temp=0.7 → 放大差异)                        ║   │
│  ║                                                                               ║   │
│  ║  ② Top-K Filtering (如果设置)                                                    ║   │
│  ║    仅保留概率最高的 K 个 token, 其余 → -inf                                     ║   │
│  ║    (本例中未明确设置, 跳过)                                                     ║   │
│  ║                                                                               ║   │
│  ║  ③ Top-P (Nucleus) Filtering                                                   ║   │
│  ║    按概率从高到低排序, 累积概率 ≥ top_p=0.9 时截断                             ║   │
│  ║    其余 token → -inf                                                           ║   │
│  ║                                                                               ║   │
│  ║  ④ Softmax                                                                     ║   │
│  ║    probs = softmax(filtered_logits)  → [152064]                                ║   │
│  ║                                                                               ║   │
│  ║  ⑤ 采样                                                                         ║   │
│  ║    temperature > 0: 从多项式分布采样 (multinomial)                              ║   │
│  ║    temperature = 0: 贪心解码 (argmax)                                          ║   │
│  ║    → output_token_id = 105649  (例如: "用")                                    ║   │
│  ║                                                                               ║   │
│  ║  ⑥ 更新 Sequence                                                               ║   │
│  ║    seq.data.output_token_ids.append(105649)                                    ║   │
│  ║    seq.data.update_num_computed_tokens(55 + 1)                                 ║   │
│  ║    (此时 prefill 完成, 后续 decode 只追加 1 个 token)                           ║   │
│  ║                                                                               ║   │
│  ╚═══════════════════════════════════════════════════════════════════════════════╝   │
│                                                                                     │
│  参考: 05-worker-execution.md 第 3 节 (execute_model), 第 9 节 (Sampler)             │
│        pytorch-transformer.md 第 5 节 (Transformer 架构完整走读)                      │
│        deep-learning-basics.md 第 6 节 (激活函数), 第 3 节 (Softmax)                  │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 4.3 Decode 阶段: 500 次 step 循环

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              Decode 阶段: 逐 token 生成                                │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  Prefill 完成后, 请求进入 Decode 阶段。每个 step 生成 1 个 token:                       │
│                                                                                     │
│  Step 1 (生成 token 1):                                                              │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  输入: input_ids = [105649]      # 只有最新 1 个 token                          │   │
│  │        positions = [55]          # 第 55 个位置                                 │   │
│  │        KV Cache: 已有 55 个 token 的 KV (4 个 block)                           │   │
│  │                                                                               │   │
│  │  与 Prefill 的关键差异:                                                         │   │
│  │  ┌──────────────────────────────────────────────────────────────────────┐    │   │
│  │  │  项目           │  Prefill                     │  Decode               │    │   │
│  │  │  ─────────────┼─────────────────────────────┼────────────────────── │    │   │
│  │  │  输入 token 数  │  55                          │  1                    │    │   │
│  │  │  Attention 形状 │  [55×128] @ [128×55] = [55×55]│  [1×128] @ [128×56] = [1×56]│   │
│  │  │  FLOPs/层       │  ~1.5M attn + ~7M MLP        │  ~0.02M attn + ~0.2M MLP │   │
│  │  │  瓶颈类型        │  Compute-Bound (GPU 60-80%)  │  Memory-Bound (GPU 5-15%) │   │
│  │  │  HBM 读/层       │  ~5 MB (权重+KV)              │  ~5 MB (权重+KV)        │   │
│  │  │  每层耗时         │  ~2.3ms                     │  ~0.4ms                │   │
│  │  │  64 层总耗时      │  ~148ms                     │  ~25ms                 │   │
│  │  │  CUDA Graph      │  ❌ (动态形状)               │  ✅ (固定 batch size)    │   │
│  │  └──────────────────────────────────────────────────────────────────────┘    │   │
│  │                                                                               │   │
│  │  Decode 单步流程:                                                               │   │
│  │  ① Embedding (1 token → [5120]):             ~0.01ms                           │   │
│  │  ② 64 × Transformer Block (每层 ~0.38ms):    ~24.3ms (CUDA Graph 重放)        │   │
│  │  ③ lm_head + Sample:                         ~0.5ms                            │   │
│  │  ④ KV Cache 追加 1 slot:                     ~0.1ms                            │   │
│  │                                                                               │   │
│  │  总 Decode 时间: 500 × 25ms = 12.5s                                            │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  CUDA Graph 在 Decode 中的角色:                                                       │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  没有 CUDA Graph:                                                              │   │
│  │    每层 ~4-5 个 kernel launch × 64 层 = ~280 次 kernel launch                  │   │
│  │    每次 launch ~8us → 总 overhead ≈ 2.2ms/step                                 │   │
│  │    500 steps → 1.1s 额外开销                                                    │   │
│  │                                                                               │   │
│  │  有 CUDA Graph:                                                                 │   │
│  │    1 次 cudaGraphLaunch(graph) → ~10us overhead                                │   │
│  │    500 steps → 5ms 额外开销                                                     │   │
│  │    节省 ~1.1s (~8% 总 decode 时间)                                             │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: vllm-architecture.md 第 8 节 (CUDA Graphs)                                     │
│        05-worker-execution.md 第 7 节 (CUDA Graph 深度解析)                          │
│        cuda-programming.md 第 5 节 (CUDA Graphs)                                     │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 4.4 All-Reduce 通信在 TP=2 中的角色

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                     TP=2 All-Reduce: 每层 2 次, 每次 ~0.1ms                            │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  Transformer Block 中的两次 All-Reduce:                                                │
│                                                                                     │
│   输入 (各 GPU 独立)                                                                │
│     │                                                                               │
│     ▼                                                                               │
│   ┌─────── RMSNorm (各 GPU 独立, 输入相同) ───────┐                                   │
│     │                                                                               │
│     ▼                                                                               │
│   ┌─────── QKV Proj (列切分) ───────┐                                               │
│     │                                                                               │
│     ▼                                                                               │
│   ┌─────── PagedAttention (各 GPU 只计算自己的 heads) ───────┐                         │
│     │                                                                               │
│     ▼                                                                               │
│   ┌─────── O Proj (行切分, 部分输出) ───────┐                                          │
│     │                                                                               │
│     ▼                                                                               │
│   ★ All-Reduce #1: 将 GPU0 和 GPU1 的 O 投影输出求和                                  │
│     GPU0: [55, 2560] (前半 hidden dim)                                               │
│     GPU1: [55, 2560] (后半 hidden dim)                                               │
│     → 通信量: 55 × 2560 × 2 bytes × 2 = 0.56 MB                                     │
│     → NVLink 600 GB/s 下约 0.001ms (实际约 0.05ms, 包含 NCCL 启动开销)               │
│     │                                                                               │
│     ▼                                                                               │
│   ┌─────── Residual + RMSNorm (各 GPU 完整) ───────┐                                  │
│     │                                                                               │
│     ▼                                                                               │
│   ┌─────── SwiGLU MLP ───────┐                                                       │
│     │ gate/up: 列切分, down: 行切分                                                     │
│     ▼                                                                               │
│   ★ All-Reduce #2: 将 GPU0 和 GPU1 的 down 投影输出求和                               │
│     → 通信量: 同样 0.56 MB                                                           │
│     │                                                                               │
│     ▼                                                                               │
│   ┌─────── Residual ───────┐                                                          │
│     │                                                                               │
│     ▼                                                                               │
│   输出 (各 GPU 独立, 完整维度)                                                        │
│                                                                                     │
│  64 层 × 2 次 All-Reduce = 128 次 All-Reduce per forward pass                        │
│  总通信量 (Prefill): 128 × 0.56 MB = 71.7 MB                                         │
│  总通信延迟: 128 × 0.05ms ≈ 6.4ms (约 4.3% 的 Prefill 时间)                         │
│                                                                                     │
│  参考: vllm-architecture.md 第 9 节 (TP All-Reduce 在 Transformer Block 中的位置)      │
│        megatron-lm-deep-dive.md 第 3 节 (Tensor Parallelism 完整数学分析)              │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

### Layer 5: Attention 子层 (PagedAttention Kernel) -- ~80ms Prefill + ~8s Decode

**参考文档**: `stage3-direction-B-inference/paged-attention-deep.md`, `stage3-direction-B-inference/kv-cache-optimization.md`, `stage3-direction-B-inference/continuous-batching.md`, `stage3-direction-A-kernel/attention-kernel-optimize.md`

#### 5.1 PagedAttention 核心: Block Table 间接寻址

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                     PagedAttention: 一次 Attention 计算的内存轨迹                        │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  传统 Attention (连续 KV Cache):                                                       │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  Q[1, 128]  @  K^T[128, 56]  →  score[1, 56]                                │   │
│  │                                                                               │   │
│  │  K 的地址: K_base + 0, K_base + 128*2, K_base + 256*2, ...                   │   │
│  │  连续地址 → 一次性大块 load → 高效!                                             │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  PagedAttention (分页 KV Cache):                                                      │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  Q[1, 128]  @  K^T[128, 56]  →  score[1, 56]                                │   │
│  │                                                                               │   │
│  │  Step 1: 查 Block Table 获取物理块                                               │   │
│  │  ┌────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  position 0-15  → logical_block 0 → block_table[0] → physical B4   │      │   │
│  │  │  position 16-31 → logical_block 1 → block_table[1] → physical B5   │      │   │
│  │  │  position 32-47 → logical_block 2 → block_table[2] → physical B6   │      │   │
│  │  │  position 48-54 → logical_block 3 → block_table[3] → physical B7   │      │   │
│  │  └────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  Step 2: 按物理块地址遍历 K (不连续但可合并)                                      │   │
│  │  ┌────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  B4 内: K tokens 0-15, 地址连续 (16×128×2 = 4096 bytes)            │      │   │
│  │  │  加载 B4 → 计算 Q @ B4_K^T → partial_score[0:16]                   │      │   │
│  │  │  加载 B5 → 计算 Q @ B5_K^T → partial_score[16:32]                  │      │   │
│  │  │  加载 B6 → 计算 Q @ B6_K^T → partial_score[32:48]                  │      │   │
│  │  │  加载 B7 → 计算 Q @ B7_K^T → partial_score[48:55]                  │      │   │
│  │  └────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  Step 3: Online Softmax 合并 partial scores                                    │   │
│  │  ┌────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  (不将整个 [1, 56] score 写回 HBM, 在 SRAM 中完成 softmax)          │      │   │
│  │  │  m = -inf, l = 0                                                    │      │   │
│  │  │  for each block:                                                    │      │   │
│  │  │    s_i = Q @ block_i_K^T / sqrt(d)                                  │      │   │
│  │  │    m_new = max(m, max(s_i))                                         │      │   │
│  │  │    l = l * exp(m - m_new) + sum(exp(s_i - m_new))                   │      │   │
│  │  │    P_i = exp(s_i - m_new)                                           │      │   │
│  │  │    output += P_i @ block_i_V                                        │      │   │
│  │  │    m = m_new                                                        │      │   │
│  │  │  output = output / l                                                │      │   │
│  │  └────────────────────────────────────────────────────────────────────┘      │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  关键 Insight:                                                                       │
│  - 块内连续访问: 每个 block 16 个 token 的 KV 在物理上连续, 可做合并内存访问            │
│  - 跨块不连续: 但不影响性能, 因为每块 ~4KB (大于 L2 cache line) 已经足够大             │
│  - Block Table 缓存: 每个序列的 block_table 很小 (4 个 int), 放在 SMEM 中             │
│  - 总开销: PagedAttention 相比连续 KV Cache 仅有 ~3-5% 的额外开销                     │
│                                                                                     │
│  参考: paged-attention-deep.md 第 10 节 (PagedAttention CUDA Kernel)                  │
│        attention-kernel-optimize.md 第 3 节 (Online Softmax), 第 9 节 (PagedAttn)    │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 5.2 FlashAttention Tiling 技术 (Prefill 阶段)

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                    FlashAttention: 如何在 SRAM 中完成 O(N^2) Attention                  │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  Prefill 阶段的 Attention (Q [55, 40, 128], K [55, 8, 128], V [55, 8, 128]):        │
│                                                                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  标准 Attention 的问题:                                                         │   │
│  │  ┌──────────────────────────────────────────────────────────────────────┐    │   │
│  │  │  S = Q @ K^T        → [55, 55]  (写回 HBM)  ← 12 KB, 可接受           │    │   │
│  │  │  P = softmax(S)      → [55, 55]  (写回 HBM)                           │    │   │
│  │  │  O = P @ V          → [55, 128] (从 HBM 读 P)                         │    │   │
│  │  │                                                                        │    │   │
│  │  │  问题: 中间结果 S 和 P 各需 12 KB HBM 读写 (55 个 token 时还不严重)     │    │   │
│  │  │  但 8192 tokens 时: S [8192, 8192] = 256 MB! → HBM 瓶颈              │    │   │
│  │  └──────────────────────────────────────────────────────────────────────┘    │   │
│  │                                                                               │   │
│  │  FlashAttention 的解决方案 (Tiling):                                            │   │
│  │  ┌──────────────────────────────────────────────────────────────────────┐    │   │
│  │  │                                                                        │    │   │
│  │  │  K, V 分块 (块大小 B_r = 64, 沿序列维度):                               │    │   │
│  │  │                                                                        │    │   │
│  │  │  K 分块: K_1 [0:16], K_2 [16:32], K_3 [32:48], K_4 [48:55]           │    │   │
│  │  │  V 分块: V_1 [0:16], V_2 [16:32], V_3 [32:48], V_4 [48:55]           │    │   │
│  │  │                                                                        │    │   │
│  │  │  外循环 (遍历 K, V 分块):                                               │    │   │
│  │  │  ┌─────────────────────────────────────────────────────────────┐      │    │   │
│  │  │  │  for i in range(num_kv_blocks):  # 外循环遍历 K,V 块          │      │    │   │
│  │  │  │    K_i = load_K_block(i)    # 加载 K_i [B_r, d] 到 SRAM       │      │    │   │
│  │  │  │    V_i = load_V_block(i)    # 加载 V_i [B_r, d] 到 SRAM       │      │    │   │
│  │  │  │                                                               │      │    │   │
│  │  │  │    内循环 (遍历 Q 分块):                                        │      │    │   │
│  │  │  │    for j in range(num_q_blocks):                              │      │    │   │
│  │  │  │      Q_j = load_Q_block(j)  # 加载 Q_j [B_c, d] 到 SRAM       │      │    │   │
│  │  │  │      S_ij = Q_j @ K_i^T    # 全部在 SRAM 中计算 [B_c, B_r]    │      │    │   │
│  │  │  │      P_ij = online_softmax(S_ij, running_m, running_l)       │      │    │   │
│  │  │  │      O_j += P_ij @ V_i     # 累积输出                         │      │    │   │
│  │  │  │      store O_j  (最终 softmax 归一化后)                         │      │    │   │
│  │  │  └─────────────────────────────────────────────────────────────┘      │    │   │
│  │  │                                                                        │    │   │
│  │  │  关键: S_ij 和 P_ij 从不写回 HBM!                                       │    │   │
│  │  │  HBM 访问量: 仅 Q, K, V 各加载 1 次 + O 写出 1 次                       │    │   │
│  │  │  → 标准 Attention 的 O(N^2) HBM 访问 → O(N) HBM 访问                   │    │   │
│  │  └──────────────────────────────────────────────────────────────────────┘    │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  FlashAttention + PagedAttention 如何结合:                                             │
│  - FlashAttention 负责「如何高效计算」: Tiling + Online Softmax                        │
│  - PagedAttention 负责「KV Cache 存在哪里」: Block Table 间接寻址                      │
│  - 两者正交: FA 的 tiling 可以和 PA 的 block table 结合                               │
│  - 实现: 外循环遍历的不是均匀分块, 而是 block table 中的物理块                           │
│  参考: attention-kernel-optimize.md 第 2 节 (FlashAttention Tiling 策略)               │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 5.3 KV Cache 显存追踪

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                        KV Cache 显存增长追踪 (我们的请求)                                │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  Qwen2.5-32B KV Cache 参数:                                                           │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  num_layers = 64                                                              │   │
│  │  num_kv_heads = 8            (GQA: 40 Q heads shared over 8 KV heads)        │   │
│  │  head_dim = 128                                                                │   │
│  │  dtype = BF16 (2 bytes)                                                        │   │
│  │  block_size = 16 tokens                                                        │   │
│  │                                                                               │   │
│  │  每个 token 的 KV Cache 大小:                                                   │   │
│  │    单 token = 2(K+V) × num_kv_heads × head_dim × num_layers × dtype_bytes    │   │
│  │             = 2 × 8 × 128 × 64 × 2                                            │   │
│  │             = 262,144 bytes = 256 KB                                           │   │
│  │                                                                               │   │
│  │  每个 block (16 tokens):                                                        │   │
│  │    单 block = 16 × 256 KB = 4 MB                                               │   │
│  │                                                                               │   │
│  │  Prefill 后: 55 tokens 需要 ceil(55/16) = 4 个 block = 16 MB                  │   │
│  │  Decode 后: 555 tokens 需要 ceil(555/16) = 35 个 block = 140 MB              │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  显存使用全景 (2×A800, 共 160 GB):                                                    │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  权重:                        66 GB  (33B × 2 bytes BF16)                     │   │
│  │  CUDA Context + overhead:      ~3 GB                                          │   │
│  │  Peak Activations:             ~2 GB  (Prefill 时, Decode 时 < 0.1 GB)        │   │
│  │  KV Cache (0 requests):        0 GB                                           │   │
│  │  ─────────────────────────────────────────────────────────                   │   │
│  │  占用 (无请求):                ~71 GB / 160 GB = 44%                           │   │
│  │                                                                               │   │
│  │  我们的请求 KV Cache:           ~16 MB (prefill 后)                            │   │
│  │                               → ~140 MB (生成 500 token 后)                   │   │
│  │                                                                               │   │
│  │  可分配 KV Cache (gpu_memory_utilization=0.90):                                │   │
│  │    0.90 × 160 GB - 71 GB = 144 - 71 = 73 GB                                  │   │
│  │    可容纳 73 GB / 4 MB per block ≈ 18,688 个 block                            │   │
│  │    可同时服务 18,688 / (555/16) ≈ 539 个类似请求 (理论值)                      │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: kv-cache-optimization.md 第 2 节 (真实模型内存计算), 第 1 节 (KV Cache 基础)    │
│        paged-attention-deep.md 第 4 节 (内存效率分析)                                 │
│        03-block-manager.md 第 2 节 (物理块与显存布局)                                  │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### Layer 6: CUDA 执行层 (GPU Hardware) -- 内含在上述各层中

**参考文档**: `stage2-ai-infra-foundations/cuda-programming.md`, `stage2-ai-infra-foundations/simt-parallel-model.md`, `stage3-direction-A-kernel/cuda-kernel-deep-dive.md`

#### 6.1 一次矩阵乘法的 GPU 微观执行

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                    QKV Projection 的 GPU 微观执行 (以 Q Proj 为例)                       │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  操作: Q = X @ W_Q^T                                                                 │
│        X: [55, 5120] BF16                                                            │
│        W_Q: [5120, 5120] BF16  (TP=2 下每 GPU  [5120, 2560])                        │
│        Q: [55, 2560] BF16                                                            │
│                                                                                     │
│  ╔═══════════════════════════════════════════════════════════════════════════════╗   │
│  ║  Step 1: CPU 发起 Kernel Launch                                            ║   │
│  ╠═══════════════════════════════════════════════════════════════════════════════╣   │
│  ║                                                                               ║   │
│  ║  cuBLAS SGEMM (通过 CUDA Graph 重放):                                          ║   │
│  ║    grid: (55/128, 2560/128, 1) = (1, 20, 1) blocks                           ║   │
│  ║    每个 block: 256 threads (8 warps × 32 threads)                              ║   │
│  ║    shared memory per block: ~48 KB (存放 X tile 和 W_Q tile)                   ║   │
│  ║                                                                               ║   │
│  ║  CPU → GPU: 一次 cudaGraphLaunch() 调用                                       ║   │
│  ║    延迟: ~10 us (Graph 模式) vs ~8 us × 1 = 8 us (单 kernel)                  ║   │
│  ║                                                                               ║   │
│  ╚═══════════════════════════════════════════════════════════════════════════════╝   │
│                                    │                                                │
│                                    ▼                                                │
│  ╔═══════════════════════════════════════════════════════════════════════════════╗   │
│  ║  Step 2: SM 上的 Warp 调度                                                ║   │
│  ╠═══════════════════════════════════════════════════════════════════════════════╣   │
│  ║                                                                               ║   │
│  ║  每个 SM (共 108 个 SM):                                                        ║   │
│  ║  ┌─────────────────────────────────────────────────────────────────────┐      ║   │
│  ║  │                                                                       │      ║   │
│  ║  │  Warp Scheduler 0 ──► Warp 0 (32 threads) ──► Tensor Core ──► ...   │      ║   │
│  ║  │  Warp Scheduler 1 ──► Warp 1 (32 threads) ──► Tensor Core ──► ...   │      ║   │
│  ║  │  Warp Scheduler 2 ──► Warp 2 (发不出, 等待 HBM 数据)                  │      ║   │
│  ║  │  Warp Scheduler 3 ──► Warp 3 (正在从 SMEM 加载数据)                    │      ║   │
│  ║  │                                                                       │      ║   │
│  ║  │  关键: 当 Warp 2 因等待 HBM 数据而 stall 时,                            │      ║   │
│  ║  │       Warp Scheduler 立即切换到 Warp 0 (数据已在 SMEM 中)               │      ║   │
│  ║  │       → 零开销 Warp 切换 → 延迟隐藏!                                    │      ║   │
│  ║  │                                                                       │      ║   │
│  ║  │  Occupancy: 每个 SM 最多 64 warps                                      │      ║   │
│  ║  │  GEMM kernel: 注册器压力大, 通常 50% occupancy (32 warps/SM)           │      ║   │
│  ║  │  足够做延迟隐藏 (HBM 800 cycles / 32 warps, 每 warp 平均 25 cycles)   │      ║   │
│  ║  │                                                                       │      ║   │
│  ║  └─────────────────────────────────────────────────────────────────────┘      ║   │
│  ║                                                                               ║   │
│  ╚═══════════════════════════════════════════════════════════════════════════════╝   │
│                                    │                                                │
│                                    ▼                                                │
│  ╔═══════════════════════════════════════════════════════════════════════════════╗   │
│  ║  Step 3: Tensor Core 矩阵乘累加                                           ║   │
│  ╠═══════════════════════════════════════════════════════════════════════════════╣   │
│  ║                                                                               ║   │
│  ║  A800 第 3 代 Tensor Core (BF16 模式):                                         ║   │
│  ║  ┌─────────────────────────────────────────────────────────────────────┐      ║   │
│  ║  │                                                                       │      ║   │
│  ║  │  mma.sync.aligned.m16n8k16.row.col.f16.f16.f16.f16                   │      ║   │
│  ║  │  {d0, d1, d2, d3}, {a0, a1, a2, a3}, {b0, b1}, {c0, c1, c2, c3}   │      ║   │
│  ║  │                                                                       │      ║   │
│  ║  │  一个 warp 每周期完成:                                                  │      ║   │
│  ║  │    D[M16 × N8] += A[M16 × K16] × B[K16 × N8]                        │      ║   │
│  ║  │    = 16 × 8 × 16 × 2 = 4096 FMA operations                          │      ║   │
│  ║  │                                                                       │      ║   │
│  ║  │  峰值吞吐: 312 TFLOPS (每 SM 约 2.9 TFLOPS)                           │      ║   │
│  ║  │  实际利用率: ~80% (GEMM 优化良好) → ~250 TFLOPS                      │      ║   │
│  ║  │                                                                       │      ║   │
│  ║  │  数据流动:                                                             │      ║   │
│  ║  │  HBM → L2 → SMEM (异步 pipeline: cp.async)                            │      ║   │
│  ║  │  SMEM → Register File → Tensor Core → Register File                   │      ║   │
│  ║  │  结果: Register → SMEM → L2 → HBM                                     │      ║   │
│  ║  │                                                                       │      ║   │
│  ║  └─────────────────────────────────────────────────────────────────────┘      ║   │
│  ║                                                                               ║   │
│  ╚═══════════════════════════════════════════════════════════════════════════════╝   │
│                                                                                     │
│  参考: cuda-programming.md 第 3 节 (Tensor Core), 第 6 节 (GEMM 优化 Step by Step)   │
│        cuda-kernel-deep-dive.md Tensor Core 编程章节                                   │
│        simt-parallel-model.md 第 2 节 (Warp 执行模型), 第 3 节 (延迟隐藏)             │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

#### 6.2 Roofline 分析: Prefill vs Decode

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           Roofline 模型: Prefill vs Decode 瓶颈分析                      │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  A800 Roofline (BF16 Tensor Core):                                                   │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  TFLOPS                                                                        │   │
│  │  312 ┤────────────────────────────────────────────────● Peak BF16 TC          │   │
│  │      │                                              ╱                         │   │
│  │      │                                          ╱                             │   │
│  │      │  Memory-Bound         Compute-Bound    ╱                               │   │
│  │      │  (Decode)             (Prefill)     ╱                                   │   │
│  │      │                                  ╱                                      │   │
│  │      │    ● Decode Attention           ╱                                       │   │
│  │      │    (AI≈0.3, 8 TFLOPS)        ╱                                         │   │
│  │      │                            ╱                                            │   │
│  │      │                          ╱                                              │   │
│  │      │                        ╱ ● Prefill GEMM                                 │   │
│  │      │                      ╱   (AI≈50, 200 TFLOPS)                           │   │
│  │      │                    ╱                                                    │   │
│  │      │                  ╱                                                      │   │
│  │      │                ╱                                                        │   │
│  │      │              ╱                                                          │   │
│  │      │            ╱                                                            │   │
│  │      │          ╱                                                              │   │
│  │    0 └────────●──────────────────────────────────────────────────►             │   │
│  │      0       0.3   Ridge Point (~153)                  Arithmetic Intensity    │   │
│  │               (FLOP/Byte)                                                        │   │
│  │                                                                               │   │
│  │  Ridge Point = Peak_FLOPS / Peak_Bandwidth = 312 TFLOPS / 2039 GB/s           │   │
│  │               ≈ 153 FLOP/Byte                                                   │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Prefill 阶段 (Compute-Bound):                                                        │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  操作          │ AI (FLOP/Byte) │ 实际 TFLOPS │ 利用率 │ 瓶颈                 │   │
│  │  ─────────────┼───────────────┼────────────┼───────┼──────────────────── │   │
│  │  QKV Projection│ ~50           │ ~200        │ 64%    │ Tensor Core + HBM   │   │
│  │  Attention     │ ~32           │ ~100        │ 32%    │ 部分 Memory-Bound   │   │
│  │  SwiGLU MLP    │ ~80           │ ~250        │ 80%    │ Tensor Core         │   │
│  │  lm_head       │ ~1            │ ~30         │ 10%    │ Memory-Bound        │   │
│  │  ─────────────┼───────────────┼────────────┼───────┼──────────────────── │   │
│  │  整体           │ ~60           │ ~180        │ 58%    │ Mixed              │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Decode 阶段 (Memory-Bound):                                                          │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  操作          │ AI (FLOP/Byte) │ 实际 TFLOPS │ 利用率 │ 瓶颈                 │   │
│  │  ─────────────┼───────────────┼────────────┼───────┼──────────────────── │   │
│  │  QKV Projection│ ~0.25         │ ~8          │ 2.6%   │ 权重加载 (HBM BW)   │   │
│  │  Attention     │ ~0.3          │ ~10         │ 3.2%   │ KV Cache 加载       │   │
│  │  SwiGLU MLP    │ ~0.4          │ ~15         │ 4.8%   │ 权重加载 (HBM BW)   │   │
│  │  lm_head       │ ~0.02         │ ~1          │ 0.3%   │ 权重加载 (HBM BW)   │   │
│  │  ─────────────┼───────────────┼────────────┼───────┼──────────────────── │   │
│  │  整体           │ ~0.3          │ ~10         │ 3.2%   │ Heavily Memory-Bound│   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  核心洞察:                                                                           │
│  - Decode 的 GPU 利用率仅 ~3-5%, 不是 GPU 算力不够, 而是 HBM 带宽喂不饱 Tensor Core   │
│  - 这解释了为什么 Continuous Batching 如此重要: 多个 Decode 请求合并, 权重加载复用     │
│  - 也解释了为什么量化 (INT4) 对 Decode 吞吐提升巨大: 减少 HBM 带宽需求 4 倍              │
│                                                                                     │
│  参考: simt-parallel-model.md 第 5 节 (Roofline 模型)                                  │
│        continuous-batching.md 第 3 节 (Prefill 与 Decode 的协同调度)                   │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### Layer 7: 量化层 (AWQ/GPTQ) -- 如适用

**参考文档**: `stage3-direction-B-inference/quantization-inference.md`

#### 7.1 AWQ INT4 量化: Dequant 在 Forward Pass 中的位置

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                       AWQ INT4 量化: Dequant 发生在何时何地?                              │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  如果不使用量化 (FP16):                                                                │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  hidden_states [55, 5120] FP16                                               │   │
│  │      │                                                                        │   │
│  │      │ 加载 W_Q [5120, 5120] FP16 从 HBM (26 MB)                              │   │
│  │      ▼                                                                        │   │
│  │  = torch.matmul(hidden_states, W_Q)                                          │   │
│  │  → Q [55, 5120] FP16                                                          │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  使用 AWQ INT4 量化后:                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  hidden_states [55, 5120] FP16                                               │   │
│  │      │                                                                        │   │
│  │      │ ① 加载 qweight (INT4 packed, ~6.5 MB) + scales (FP16, ~0.5 MB) 从 HBM │   │
│  │      │    总加载: ~7 MB (vs FP16 的 26 MB, 节省 73% HBM 带宽)                  │   │
│  │      ▼                                                                        │   │
│  │  ② Dequant: int4_weight = qweight.dequantize()                               │   │
│  │     int4_weight = qweight * scales + zeros                                   │   │
│  │     → FP16 weight [5120, 5120]  (在寄存器/SMEM 中完成, 不写回 HBM)             │   │
│  │      │                                                                        │   │
│  │      ▼                                                                        │   │
│  │  ③ MatMul: output = hidden_states @ FP16_weight                              │   │
│  │     → 使用 Marlin Kernel (专用 INT4 Tensor Core 指令)                          │   │
│  │       A800 INT4 TC 峰值: 1248 TOPS (vs FP16 的 312 TFLOPS, 4× 峰值)           │   │
│  │     → 实际性能: 比 FP16 快 0.6-1.5× (取决于 batch size)                       │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Marlin Kernel 的核心优势:                                                             │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  朴素 INT4 MatMul (先 dequant 再计算):                                          │   │
│  │    ① 加载 qweight (INT4) 到 SMEM                                               │   │
│  │    ② Dequant 到 FP16 → SMEM (写入+读取中间数据: 双倍 SMEM 流量)                  │   │
│  │    ③ Tensor Core FP16 MatMul                                                  │   │
│  │    → 第②步浪费了 SMEM 带宽和容量                                                 │   │
│  │                                                                               │   │
│  │  Marlin INT4 MatMul (dequant 融入 Tensor Core):                                 │   │
│  │    ① 加载 qweight (INT4) 到 SMEM                                               │   │
│  │    ② 加载 scales (FP16) 到寄存器                                                │   │
│  │    ③ Tensor Core INT4 MatMul (mma.sync + 内联 dequant)                         │   │
│  │    → dequant 在 Tensor Core 内部完成, 无额外 SMEM 流量                           │   │
│  │    → A800 INT4 Tensor Core: 每周期 4096 ops (4× FP16)                         │   │
│  │                                                                               │   │
│  │  综合效果:                                                                      │   │
│  │    - HBM 加载减少 73%                                                           │   │
│  │    - SMEM 节省 50% (无需存储中间 FP16 结果)                                      │   │
│  │    - Decode 速度提升 1.5-2× (Memory-Bound 场景受益最大)                          │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  量化对本次请求的影响:                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  FP16 (未量化):                                                                 │   │
│  │    权重显存: 66 GB → 需要 2×A800 (每卡 33 GB)                                   │   │
│  │    Decode TPOT: ~25ms/token                                                    │   │
│  │    Decode 吞吐: ~40 tok/s (单请求)                                              │   │
│  │    KV Cache 可用: ~73 GB (可支持更多并发)                                        │   │
│  │                                                                               │   │
│  │  AWQ INT4 (量化):                                                                │   │
│  │    权重显存: ~17 GB → 单卡 A800 即可! (17 + 8 KV + 3 overhead ≈ 28 GB)         │   │
│  │    Decode TPOT: ~16ms/token (Marlin 加速)                                       │   │
│  │    Decode 吞吐: ~62 tok/s (单请求, 比 FP16 快 55%)                              │   │
│  │    KV Cache 可用: ~60 GB (单卡, 因权重少了可分配更多 KV)                          │   │
│  │    批量吞吐提升: 2-3× (Memory-Bound 场景受益 + 更多并发)                         │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: quantization-inference.md 第 3.1 节 (GPTQ), 第 3.2 节 (AWQ),                    │
│        第 5 节 (Marlin Kernel), 第 9 节 (33B 模型部署实操方案)                         │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Part 3: 易混淆技术辨析 (Tech Differentiation)

### 3.1 Continuous Batching vs Static Batching

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                     Continuous Batching vs Static Batching                            │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  场景: 3 个请求同时到达, 使用我们的模型                                                  │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  请求A: "用Python写快速排序" (55 tokens → 500 output tokens)                  │   │
│  │  请求B: "什么是机器学习"    (40 tokens → 200 output tokens)                  │   │
│  │  请求C: "翻译: hello world" (20 tokens → 3 output tokens)                     │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Static Batching (静态批处理, HF Transformers 风格):                                   │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  ───────────────────────────────────────────────────────────────────────► t   │   │
│  │                                                                               │   │
│  │  Batch 1: [A(55 tokens prefill)][B(40 tokens prefill)][C(20 tokens prefill)] │   │
│  │  ┌────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  Prefill 同一 batch (ok, 计算密集)                                   │      │   │
│  │  │  → 约 180ms (含 3 个请求的 prefill)                                 │      │   │
│  │  └────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  Decode: [A decode][B decode][C decode] (3 个请求同时 decode)                  │   │
│  │  ┌────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  请求C 在 3 个 token 后完成 → GPU 空转等待 A 和 B 完成!              │      │   │
│  │  │  ┌──┐                                                               │      │   │
│  │  │  │ C│ 完成 → ░░░░░░░░░░░░░ (GPU 浪费)                              │      │   │
│  │  │  └──┘                                                               │      │   │
│  │  │  请求B 在 200 个 token 后完成                                         │      │   │
│  │  │  ┌─────────────────┐                                                │      │   │
│  │  │  │  B              │ 完成 → ░░░░░░░░░ (GPU 浪费)                    │      │   │
│  │  │  └─────────────────┘                                                │      │   │
│  │  │  请求A 在 500 个 token 后完成                                         │      │   │
│  │  │  ┌──────────────────────────────────────────┐                       │      │   │
│  │  │  │  A                                       │                       │      │   │
│  │  │  └──────────────────────────────────────────┘                       │      │   │
│  │  │                                                                      │      │   │
│  │  │  总时间: 180ms + 500×25ms = 12.68s                                   │      │   │
│  │  │  GPU 利用率: 约 40-55%                                              │      │   │
│  │  └────────────────────────────────────────────────────────────────────┘      │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Continuous Batching (连续批处理, vLLM 风格):                                         │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  ───────────────────────────────────────────────────────────────────────► t   │   │
│  │                                                                               │   │
│  │  Step 1: Batch = [A(prefill) + B(prefill) + C(prefill)]  → 180ms              │   │
│  │  Step 2: Batch = [A(decode) + B(decode) + C(decode)]  → 25ms                  │   │
│  │  Step 3: Batch = [A(decode) + B(decode) + C(decode)]  → 25ms                  │   │
│  │  Step 4: 请求C 完成! → Batch = [A(decode) + B(decode)]  → 25ms               │   │
│  │          ↑                                                                     │   │
│  │          C 的 KV Cache 块释放 → 其他请求可立即使用                                │   │
│  │                                                                               │   │
│  │  Step 5~200: Batch = [A(decode) + B(decode)] 每步 25ms                         │   │
│  │  Step 201: 请求B 完成! → Batch = [A(decode)]  → 25ms                          │   │
│  │          此时新请求 D 加入 → Batch = [A(decode) + D(prefill)]  (如果在用 Chunked) │   │
│  │                                                                               │   │
│  │  Step 202~500: Batch = [A(decode)] 每步 25ms                                    │   │
│  │                                                                               │   │
│  │  总时间: 180ms + 500×25ms ≈ 12.68s (单个时间相近)                               │   │
│  │  但全程 GPU 利用率 > 80% (因为 C 和 B 的 slot 可被其他请求复用)                   │   │
│  │  共存请求数更多 → 总吞吐提高 2-5×                                                 │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  核心区别:                                                                            │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  维度           │  Static Batching          │  Continuous Batching             │   │
│  │  ──────────────┼──────────────────────────┼─────────────────────────────── │   │
│  │  Batch 生命周期  │  整个请求周期固定           │  每个 step 动态重组              │   │
│  │  提前完成的请求   │  空占位置, GPU 浪费        │  立即释放, slot 复用于新请求     │   │
│  │  新请求加入       │  必须等整个 batch 完成     │  任何 step 都可加入              │   │
│  │  KV Cache 管理   │  连续预分配, 浪费 50%+     │  PagedAttention 按需分页        │   │
│  │  GPU 利用率      │  40-55%                   │  80-96%                         │   │
│  │  吞吐            │  1x (基线)                │  2-24× (论文实测)               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: continuous-batching.md 第 1 节 (静态批处理为什么不够用), 第 2 节 (Continuous Batching)│
│        vllm-architecture.md 第 1 节 (设计哲学)                                         │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 FlashAttention vs PagedAttention

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                        FlashAttention vs PagedAttention                                │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  这两个技术经常被混为一谈, 但它们解决的是完全不同的问题:                                  │
│                                                                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  FlashAttention 解决: HOW to compute Attention efficiently                     │   │
│  │  (如何高效计算 Attention)                                                       │   │
│  │                                                                               │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │                                                                       │      │   │
│  │  │  问题: 标准 Attention 产生 O(N^2) 的中间矩阵 (S 和 P),               │      │   │
│  │  │       必须往返 HBM → HBM 带宽成为瓶颈                                │      │   │
│  │  │                                                                       │      │   │
│  │  │  方法: Tiling + Online Softmax                                       │      │   │
│  │  │   - 将 Q, K, V 分块, 块内计算 S_ij, 不写回完整 S 矩阵到 HBM         │      │   │
│  │  │   - Online Softmax: 分块计算 softmax, 保持 running statistics       │      │   │
│  │  │   - 最终只将 O 写回 HBM                                              │      │   │
│  │  │                                                                       │      │   │
│  │  │  效果: HBM 访问从 O(N^2) 降至 O(N)                                  │      │   │
│  │  │        加速比: 5-7× (实际), 12× (理论)                             │      │   │
│  │  │                                                                       │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  PagedAttention 解决: WHERE to store KV Cache                                   │   │
│  │  (KV Cache 存在哪里, 如何管理)                                                   │   │
│  │                                                                               │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │                                                                       │      │   │
│  │  │  问题: 传统 KV Cache 需要连续预分配 (每请求预留 max_length 的空间)     │      │   │
│  │  │        → 内存碎片严重, 利用率仅 ~6%                                   │      │   │
│  │  │                                                                       │      │   │
│  │  │  方法: 模仿 OS 虚拟内存分页                                              │      │   │
│  │  │   - KV Cache 分成固定大小的 Block (默认 16 tokens)                    │      │   │
│  │  │   - Block Table: 逻辑块 → 物理块 映射                                 │      │   │
│  │  │   - 按需分配, 释放后复用 (内存利用率 > 90%)                            │      │   │
│  │  │                                                                       │      │   │
│  │  │  效果: 内存浪费从 ~50% 降至 < 4%                                     │      │   │
│  │  │        相同显存下 batch size 提升 2-4×                               │      │   │
│  │  │                                                                       │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  它们如何协同工作:                                                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  vLLM 的 PagedAttention Kernel 是同时实现了两者:                                 │   │
│  │                                                                               │   │
│  │  ① FlashAttention 的 Tiling:                                                  │   │
│  │      外循环遍历 K, V 的 block (沿序列维度分块)                                   │   │
│  │      内循环遍历 Q 的 block                                                      │   │
│  │      → 保证 O(N) HBM 访问                                                      │   │
│  │                                                                               │   │
│  │  ② PagedAttention 的 Block Table:                                              │   │
│  │      外循环的 K, V 块索引不是均匀的 i×B_r,                                       │   │
│  │      而是通过 block_table 间接查找物理块                                        │   │
│  │      → 支持非连续物理内存布局                                                   │   │
│  │                                                                               │   │
│  │  融合后的伪代码:                                                                 │   │
│  │  ┌──────────────────────────────────────────────────────────────────────┐     │   │
│  │  │  for logical_block_idx in range(num_blocks):                         │     │   │
│  │  │      physical_block = block_table[logical_block_idx]  ← PA            │     │   │
│  │  │      K_tile = load_K_block(physical_block)             ← FA: tiling   │     │   │
│  │  │      V_tile = load_V_block(physical_block)             ← FA: tiling   │     │   │
│  │  │                                                                       │     │   │
│  │  │      for q_block_idx in range(num_q_blocks):                          │     │   │
│  │  │          Q_tile = load_Q_block(q_block_idx)                           │     │   │
│  │  │          S = Q_tile @ K_tile^T                     ← 全部在 SRAM 中   │     │   │
│  │  │          P = online_softmax(S)                     ← Online Softmax   │     │   │
│  │  │          O += P @ V_tile                                              │     │   │
│  │  └──────────────────────────────────────────────────────────────────────┘     │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  记忆口诀:                                                                            │
│    FlashAttention = HOW (计算方式: Tiling + SRAM)                                    │
│    PagedAttention = WHERE (存储方式: Block Table + 分页)                              │
│    它们 work TOGETHER, 不是互斥替代关系                                                │
│                                                                                     │
│  参考: paged-attention-deep.md, attention-kernel-optimize.md 第 2 节, 第 9 节         │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Tensor Parallelism vs Pipeline Parallelism

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                     Tensor Parallelism (TP) vs Pipeline Parallelism (PP)               │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  我们的场景 (2×A800, 单节点, NVLink): 使用 TP=2                                         │
│                                                                                     │
│  Tensor Parallelism (TP=2):                                                          │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  策略: 将每层的权重矩阵切分到 2 个 GPU, 层间 All-Reduce 同步                      │   │
│  │                                                                               │   │
│  │  GPU 0:                             GPU 1:                                     │   │
│  │  ┌─────────────────┐               ┌─────────────────┐                        │   │
│  │  │ Layer 0 (Q0..Q19)│               │ Layer 0 (Q20..Q39)│                       │   │
│  │  │   Attention      │←─All-Reduce─→│   Attention      │                        │   │
│  │  │   MLP (前半)     │               │   MLP (后半)     │                        │   │
│  │  ├─────────────────┤               ├─────────────────┤                        │   │
│  │  │ Layer 1          │←─All-Reduce─→│ Layer 1          │                        │   │
│  │  │   ...            │               │   ...            │                        │   │
│  │  │                  │               │                  │                        │   │
│  │  │ Layer 63         │←─All-Reduce─→│ Layer 63         │                        │   │
│  │  └─────────────────┘               └─────────────────┘                        │   │
│  │                                                                               │   │
│  │  特点:                                                                          │   │
│  │  - 每层都参与 All-Reduce (128 次/forward pass)                                  │   │
│  │  - 通信量: 与层数成正比 (每层 ~1 MB)                                            │   │
│  │  - 要求: 低延迟高带宽互联 (NVLink ≥ 300 GB/s)                                  │   │
│  │  - GPU 利用率: 高 (所有 GPU 同时工作)                                          │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Pipeline Parallelism (PP=2, 假设 8×A800 跨 2 节点):                                 │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  策略: 将模型按层切分, GPU0 负责前半层, GPU1 负责后半层                           │   │
│  │                                                                               │   │
│  │  时间轴 →                                                                       │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │                                                                       │      │   │
│  │  │  GPU 0: [Layer 0-31]{microbatch1} ░░░░░ [Layer 0-31]{mb2} ░░░░░      │      │   │
│  │  │                                        │                              │      │   │
│  │  │  GPU 1: ░░░░░ [Layer 32-63]{mb1} ░░░░░ [Layer 32-63]{mb2}             │      │   │
│  │  │                                        │                              │      │   │
│  │  │                                        ▼                              │      │   │
│  │  │                                     Bubble!                          │      │   │
│  │  │                                     (GPU 空闲等待)                    │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  特点:                                                                          │   │
│  │  - 只有相邻 GPU 之间存在 P2P 通信 (不在层边界不通信)                              │   │
│  │  - 通信量: 与层数无关 (只在 PP 边界传输, 每 microbatch ~0.5 MB)                 │   │
│  │  - 问题: Pipeline Bubble (GPU 空闲等待), PP 越大 bubble 越严重                  │   │
│  │  - 适合: 跨节点部署 (网络带宽低时, PP 比 TP 更省通信)                            │   │
│  │  - 推理场景: 一般不用于推理 (bubble 浪费 GPU)                                   │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  选型决策树:                                                                          │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  模型能放进单卡?                                                               │   │
│  │    ├─ YES → 无需并行 (TP=PP=1)                                                 │   │
│  │    └─ NO → 需要多卡                                                             │   │
│  │           │                                                                     │   │
│  │           ├─ 所有 GPU 在同一节点 (有 NVLink)?                                   │   │
│  │           │   └─ YES → 用 TP (我们的场景: 2×A800, TP=2)                        │   │
│  │           │                                                                     │   │
│  │           └─ GPU 跨节点 (无 NVLink, 只有 InfiniBand)?                           │   │
│  │               └─ YES → 用 PP (仅在层边界通信, 通信量小)                          │   │
│  │                        或者 TP 跨节点 (需要 200Gb+ InfiniBand)                   │   │
│  │                                                                               │   │
│  │  我们的 Qwen2.5-32B: 33B × 2 bytes = 66 GB > 80 GB 单卡                         │   │
│  │    → 必须 2 卡                                                                  │   │
│  │    → 2 卡在同一节点, 有 NVLink                                                   │   │
│  │    → 选 TP=2 ✅                                                                 │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: vllm-architecture.md 第 9 节 (多 GPU Tensor Parallelism)                       │
│        megatron-lm-deep-dive.md 第 3 节 (TP), 第 5 节 (PP)                           │
│        pipeline-parallelism.md (完整 PP 文档)                                         │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.4 GPTQ vs AWQ

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              GPTQ vs AWQ 对比                                          │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  两者都是 INT4 权重-only 量化方法, 但优化的角度不同:                                     │
│                                                                                     │
│  GPTQ (Generative Pre-Trained Transformer Quantization):                             │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  核心思想: 基于 Hessian 的逐列量化 + 误差补偿                                      │   │
│  │                                                                               │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  for 每一列 w_i in 权重矩阵:                                          │      │   │
│  │  │    ① 量化 w_i:    w_i_int4 = round((w_i - zero) / scale)            │      │   │
│  │  │    ② 计算量化误差: err = w_i_fp16 - w_i_int4 * scale                 │      │   │
│  │  │    ③ 根据 Hessian 的逆补偿剩余列:                                     │      │   │
│  │  │       w_{i+1:} -= H^{-1}_{i+1:,i} / H^{-1}_{i,i} * err              │      │   │
│  │  │    → 将量化误差分摊到后续未量化的权重上                                 │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  优点: 理论上更精确 (直接优化量化误差)                                            │   │
│  │  缺点: 计算复杂度高 (需要 Cholesky 分解 Hessian)                                 │   │
│  │       量化速度慢 (33B 模型需 ~30 分钟)                                          │   │
│  │       group_size=128 需要额外的 scales/zeros 存储                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  AWQ (Activation-Aware Weight Quantization):                                          │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  核心思想: 基于激活值的敏感度分析 + Per-Channel Scaling                             │   │
│  │                                                                               │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  关键发现: 约 1% 的 "显著通道" (salient channels)                      │      │   │
│  │  │  贡献了大部分输出, 但其权重值不一定大 → 传统量化会严重破坏它们           │      │   │
│  │  │                                                                       │      │   │
│  │  │  方法:                                                                 │      │   │
│  │  │    ① 运行少量校准数据, 收集激活值统计                                   │      │   │
│  │  │    ② 找到那些激活值异常大的通道 (salient channels)                      │      │   │
│  │  │    ③ 对这些通道乘以更大的 scale (per-channel scaling)                   │      │   │
│  │  │       → 保护重要通道, 降低其量化误差                                    │      │   │
│  │  │    ④ 对相邻权重反向调整 (数学等价变换)                                   │      │   │
│  │  │                                                                       │      │   │
│  │  │  数学形式:                                                              │      │   │
│  │  │    Y = XW = X(S * S^{-1}W) = (XS)(S^{-1}W)                            │      │   │
│  │  │    其中 S 是对角缩放矩阵 (通过网格搜索确定)                              │      │   │
│  │  │    ── 把缩放因子 S 推入 X 和 W, 等价变换, 但改变了量化难易度            │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  优点: 速度快 (不需要 Cholesky, 33B 模型 ~10 分钟)                               │   │
│  │       实际精度通常更好 (0.5-1% 更低困惑度 vs GPTQ)                               │   │
│  │       对 outlier 通道的保护更直接                                                │   │
│  │  缺点: 理论上不如 GPTQ 严谨 (启发式 vs 优化式)                                    │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  对比总结:                                                                            │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  维度           │  GPTQ                        │  AWQ                          │   │
│  │  ──────────────┼─────────────────────────────┼───────────────────────────── │   │
│  │  优化目标        │  最小化量化权重的 MSE          │  保护激活值大的显著通道        │   │
│  │  数学基础        │  Hessian-based (严格优化)     │  Activation-aware (启发式)   │   │
│  │  量化速度        │  慢 (~30min/33B)             │  快 (~10min/33B)             │   │
│  │  推理内核        │  GPTQ kernel / Marlin        │  AWQ kernel / Marlin         │   │
│  │  困惑度 (33B)   │  +0.6-1.0%                   │  +0.3-0.5% (通常更好)       │   │
│  │  下游任务        │  -0.5-1.5% (7B)              │  -0.3-1.0% (7B, 通常更好)   │   │
│  │  显存节省        │  ~75% (66GB → 17GB)          │  ~75% (66GB → 17GB)          │   │
│  │  推荐场景        │  旧模型 (已发布 GPTQ 版本)     │  新项目首选                  │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: quantization-inference.md 第 3.1 节 (GPTQ), 第 3.2 节 (AWQ),                    │
│        第 5 节 (Marlin Kernel)                                                        │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.5 Prefill vs Decode

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              Prefill vs Decode 本质对比                                 │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  在我们的请求中 (55 input tokens → 500 output tokens):                                │
│                                                                                     │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  Prefill (词: "预填充"):                                                        │   │
│  │  ───────────────────────                                                       │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │                                                                       │      │   │
│  │  │  何时执行: 请求刚开始时, 一次性处理全部 prompt tokens                    │      │   │
│  │  │  输入: 55 个 prompt token IDs                                       │      │   │
│  │  │  过程:                                                               │      │   │
│  │  │    - 55 个 token 并行通过 64 层 Transformer                           │      │   │
│  │  │    - 每层的 Attention 是 55×55 的全矩阵计算 (因果掩码)                │      │   │
│  │  │    - 每个 token 的 KV 写入 KV Cache                                   │      │   │
│  │  │                                                                       │      │   │
│  │  │  输出:                                                                 │      │   │
│  │  │    - 第 1 个生成 token 的 logits (用于采样第一个 token)                 │      │   │
│  │  │    - 55 个 token 的 KV Cache (4 个 block)                             │      │   │
│  │  │                                                                       │      │   │
│  │  │  计算特征:                                                             │      │   │
│  │  │    - Attention: O(L^2 × d) = O(55^2 × 5120) ≈ 15M FLOPs/层           │      │   │
│  │  │    - MLP: O(L × d × d_ff) = O(55 × 5120 × 13824) ≈ 3.9G FLOPs/层    │      │   │
│  │  │    - 总计: ~4G FLOPs/层 × 64 = ~256G FLOPs                           │      │   │
│  │  │    - 瓶颈: Compute-Bound (GPU 利用率 ~60%)                            │      │   │
│  │  │    - 耗时: ~150ms                                                    │      │   │
│  │  │                                                                       │      │   │
│  │  │  为什么叫 "prefill"?                                                   │      │   │
│  │  │    因为是 "预" 先 "填" 充 KV Cache, 为后续 decode 做准备                │      │   │
│  │  │                                                                       │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  │  Decode (词: "解码" / "逐 token 生成"):                                          │   │
│  │  ─────────────────────────────────                                           │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │                                                                       │      │   │
│  │  │  何时执行: Prefill 完成后, 每一步生成 1 个 token, 重复直到停止           │      │   │
│  │  │  输入: 前一步生成的 1 个 token ID                                       │      │   │
│  │  │  过程:                                                                 │      │   │
│  │  │    - 1 个 token 穿过 64 层 Transformer                                  │      │   │
│  │  │    - 每层的 Attention: 1 个 query × N 个 cached key/value               │      │   │
│  │  │    - 新 token 的 KV 追加到 KV Cache (Step 1: 56 tokens, Step 2: 57...) │      │   │
│  │  │                                                                       │      │   │
│  │  │  输出:                                                                 │      │   │
│  │  │    - 下一个 token 的 logits                                             │      │   │
│  │  │    - KV Cache 追加 1 个 slot                                           │      │   │
│  │  │                                                                       │      │   │
│  │  │  计算特征:                                                             │      │   │
│  │  │    - Attention: O(L × d) = O(56 × 5120) ≈ 0.3M FLOPs/层 (step 1)     │      │   │
│  │  │    - MLP: O(1 × d × d_ff) = O(5120 × 13824) ≈ 70M FLOPs/层            │      │   │
│  │  │    - 总计: ~70M FLOPs/层 × 64 = ~4.5G FLOPs                           │      │   │
│  │  │    - 瓶颈: Memory-Bound (GPU 利用率 ~3%)                               │      │   │
│  │  │    - 耗时: ~25ms/step                                                  │      │   │
│  │  │                                                                       │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  核心对比:                                                                            │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  维度           │  Prefill                    │  Decode                         │   │
│  │  ──────────────┼────────────────────────────┼────────────────────────────── │   │
│  │  输入 token 数  │  L=55 (整个 prompt)          │  1 (最新 token)                │   │
│  │  Attention 形状 │  [L×d] @ [d×L] = [L×L]     │  [1×d] @ [d×N] = [1×N]     │   │
│  │  FLOPs/pt/token │  ~5M FLOPs/token            │  ~9M FLOPs (但只 1 token)      │   │
│  │  算力瓶颈        │  Compute-Bound              │  Memory-Bound                  │   │
│  │  GPU 利用率      │  60-80%                     │  3-5%                          │   │
│  │  HBM 带宽压力    │  中等 (权重加载复用)          │  极高 (每个 token 都要加载全部权重) │   │
│  │  KV Cache 操作   │  写入 (首次生成)              │  读取 + 追加 1 slot              │   │
│  │  CUDA Graph      │  ❌ (动态输入长度)            │  ✅ (固定 batch size)           │   │
│  │  优化方向         │  Chunked Prefill, Prefix Cache│  量化, 更大 batch, KV Cache 优化│   │
│  │  在我们的请求中   │  55 tokens, ~150ms           │  500 tokens, ~12,500ms         │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  参考: vllm-architecture.md 第 6.7 节 (Prefill vs Decode 输入对比)                     │
│        continuous-batching.md 第 3 节 (Prefill 与 Decode 的协同调度)                   │
│        pytorch-transformer.md 第 5c 节 (Self-Attention 机制)                         │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.6 KV Cache vs Prefix Cache

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                          KV Cache vs Prefix Cache                                      │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  这两个概念经常被混淆, 但它们的使用范围和机制完全不同:                                    │
│                                                                                     │
│  KV Cache (键值缓存):                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  作用范围: 单个请求内部                                                            │   │
│  │  存储内容: 当前请求已生成的所有 token 的 Key 和 Value                                │   │
│  │  生命周期: 从 prefill 开始, 贯穿整个 decode, 请求完成后释放                          │   │
│  │  管理方式: PagedAttention Block Table (分页管理)                                  │   │
│  │                                                                               │   │
│  │  我们的请求的 KV Cache 生命周期:                                                 │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │                                                                       │      │   │
│  │  │  Prefill    Decode Step 1     Decode Step 2     ...     Decode Step 500│    │   │
│  │  │  ────────   ──────────────    ──────────────           ────────────────│    │   │
│  │  │  K[0..54]   K[0..54] + K[55] K[0..55] + K[56]         K[0..553] + K[554]│ │   │
│  │  │  V[0..54]   V[0..54] + V[55] V[0..55] + V[56]         V[0..553] + V[554]│ │   │
│  │  │                                                                       │      │   │
│  │  │  请求完成 → 释放全部 KV Cache block → 其他请求可复用                      │      │   │
│  │  │                                                                       │      │   │
│  │  │  用途: 避免重复计算之前 token 的 K 和 V                                │      │   │
│  │  │ 大小: 每 token ≈ 256 KB (Qwen2.5-32B)                                 │      │   │
│  │  │                                                                       │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  Prefix Cache (前缀缓存):                                                              │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  作用范围: 跨请求共享                                                              │   │
│  │  存储内容: 已计算的 token 前缀的 KV Cache block (通过 token hash 索引)             │   │
│  │  生命周期: 跨请求持久, 通过 LRU 淘汰                                                │   │
│  │  管理方式: Radix Tree (基数树) + 基于内容哈希的查找                                  │   │
│  │                                                                               │   │
│  │  示例 (多请求共享前缀):                                                           │   │
│  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │                                                                       │      │   │
│  │  │  请求A: system_prompt (20 tokens) + "用Python写快速排序" (10 tokens)   │      │   │
│  │  │  请求B: system_prompt (20 tokens) + "解释快速排序原理" (8 tokens)      │      │   │
│  │  │  请求C: system_prompt (20 tokens) + "快速排序的时间复杂度" (12 tokens)  │      │   │
│  │  │                                                                       │      │   │
│  │  │  无 Prefix Cache:                                                      │      │   │
│  │  │    请求A: 计算 30 tokens → 30 tokens KV Cache (独立)                   │      │   │
│  │  │    请求B: 计算 28 tokens → 28 tokens KV Cache (独立, 重复!)            │      │   │
│  │  │    请求C: 计算 32 tokens → 32 tokens KV Cache (独立, 重复!)            │      │   │
│  │  │    ─────                                                                │      │   │
│  │  │    总计算: 90 tokens prefill (30+28+32)                                 │      │   │
│  │  │    总 KV Cache: 90 tokens worth (独立存储)                               │      │   │
│  │  │                                                                       │      │   │
│  │  │  有 Prefix Cache:                                                        │      │   │
│  │  │    请求A: 计算 30 tokens → 缓存前 20 tokens 到 Prefix Cache              │      │   │
│  │  │    请求B: 命中前 20 tokens! → 仅计算 8 tokens  → 复用缓存的 KV block    │      │   │
│  │  │    请求C: 命中前 20 tokens! → 仅计算 12 tokens → 复用缓存的 KV block    │      │   │
│  │  │    ─────                                                                │      │   │
│  │  │    总计算: 50 tokens prefill (30+8+12, 节省 44%)                        │      │   │
│  │  │    总 KV Cache: ~24 tokens worth (共享 20 tokens 前缀)                   │      │   │
│  │  │                                                                       │      │   │
│  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  核心区别:                                                                            │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  维度           │  KV Cache                    │  Prefix Cache                   │   │
│  │  ──────────────┼────────────────────────────┼────────────────────────────── │   │
│  │  作用范围        │  单个请求 (per-request)       │  跨请求 (cross-request)         │   │
│  │  存储 key       │  逻辑位置索引                  │  Token 内容哈希                 │   │
│  │  数据结构        │  Block Table (数组)           │  Radix Tree / Hash Table       │   │
│  │  对外部不可见     │  ❌                          │  ✅ (通过内容共享)               │   │
│  │  释放时机        │  请求结束                     │  LRU 淘汰                       │   │
│  │  收益场景        │  所有请求 (基础机制)           │  共享前缀场景 (system prompt, RAG) │   │
│  │  命中条件        │  始终 (因为是自己之前的 token) │  Token 序列完全匹配              │   │
│  │  内存关系        │  每个请求独立分配              │  多请求共享同一物理 block         │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  记忆口诀:                                                                            │
│    KV Cache: 这顿饭自己的碗 (每个请求独立, 自己之前吃过的)                              │
│    Prefix Cache: 共享餐桌上的菜 (多个请求共享相同的前缀 token)                           │
│                                                                                     │
│  参考: paged-attention-deep.md 第 12 节 (前缀缓存), 第 3 节 (KV Cache 分块管理)          │
│        kv-cache-optimization.md 第 5 节 (前缀缓存 Prefix Caching)                      │
│        03-block-manager.md 第 5 节 (PrefixCachingBlockAllocator)                       │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Part 4: 性能瓶颈逐层排查 (Expert Troubleshooting Guide)

### 4.1 决策树: 推理太慢, 从哪查起?

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                          推理性能排查决策树                                              │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  用户反馈：推理太慢                                                                    │
│  │                                                                                  │
│  ├─ TTFT 高 (> 500ms)?                                                               │
│  │  │                                                                               │
│  │  ├─ 队列等待时间长？                                                                │
│  │  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  │  现象: metrics.time_in_queue > 200ms                                  │      │   │
│  │  │  │  原因: waiting 队列积压, 调度器来不及处理新请求                          │      │   │
│  │  │  │  解决:                                                                   │      │   │
│  │  │  │    ① 增加 max_num_seqs (如 64 → 128 → 256)                            │      │   │
│  │  │  │    ② 启用 Chunked Prefill (避免长 prompt 独占)                          │      │   │
│  │  │  │    ③ 扩容 (增加 GPU 节点)                                                │      │   │
│  │  │  │  监控: vllm:num_requests_waiting                                        │      │   │
│  │  │  │  参考: 02-scheduler-core.md 第 16 节, scheduling-strategies.md 第 8 节  │      │   │
│  │  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │  │                                                                               │   │
│  │  ├─ Prefill 慢？                                                                  │   │
│  │  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  │  现象: TTFT 中大部分时间花在 prefill 上                                  │      │   │
│  │  │  │  检查:                                                                    │      │   │
│  │  │  │    ① prompt 长度是否合理? (太长 → 让用户减小 prompt)                       │      │   │
│  │  │  │    ② 是否启用 Chunked Prefill?                                           │      │   │
│  │  │  │       Chunked: Prefill 分块, 降低单步延迟                                  │      │   │
│  │  │  │       Non-Chunked: 长 prompt 一次算完, 单步慢但总时间可能更短              │      │   │
│  │  │  │    ③ 是否命中 Prefix Cache?                                               │      │   │
│  │  │  │       cache hit rate 低 → 检查是否所有请求共享相同前缀                     │      │   │
│  │  │  │    ④ batch 中是否混入了过多的 prefill?                                     │      │   │
│  │  │  │       检查 max_num_batched_tokens 是否太小                                 │      │   │
│  │  │  │  解决:                                                                   │      │   │
│  │  │  │    ① --enable-chunked-prefill                                            │      │   │
│  │  │  │    ② --enable-prefix-caching (如果有共享前缀)                             │      │   │
│  │  │  │    ③ --max-num-batched-tokens 8192 (增大 prefill batch)                  │      │   │
│  │  │  │  参考: continuous-batching.md 第 4 节, 06-practical-tuning.md 第 4c 节    │      │   │
│  │  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │  │                                                                               │   │
│  │  └─ 模型加载慢？                                                                  │   │
│  │     ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │     │  现象: 服务启动后第一个请求特别慢 (> 1s TTFT)                              │      │   │
│  │     │  原因: 模型文件未缓存 (磁盘 I/O 瓶颈)                                      │      │   │
│  │     │  解决:                                                                   │      │   │
│  │     │    ① 将模型预缓存到 NVMe 本地盘 (不要用 NFS)                               │      │   │
│  │     │    ② 使用 safetensors + mmap (零拷贝加载)                                  │      │   │
│  │     │    ③ 第一个请求慢是 CUDA JIT 编译 (后续请求正常)                           │      │   │
│  │     │  参考: 04-model-loader.md, storage-model-distribution.md                 │      │   │
│  │     └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                                  │   │
│  ├─ TPOT 高 (> 50ms/token)?                                                          │   │
│  │  │                                                                               │   │
│  │  ├─ GPU 利用率低？                                                                │   │
│  │  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  │  现象: nvidia-smi 显示 GPU Util < 20%                                   │      │   │
│  │  │  │  注意: Decode 阶段 GPU Util 本来就只有 3-15%!                            │      │   │
│  │  │  │  真正该看的是: SM Occupancy (Nsight) 和 memory_throughput                │      │   │
│  │  │  │  原因: batch 太小, 权重加载无法复用                                         │      │   │
│  │  │  │  解决:                                                                   │      │   │
│  │  │  │    ① 增加并发请求数 (增加 qps)                                             │      │   │
│  │  │  │    ② 增大 max_num_seqs (让更多 decode 请求共存)                           │      │   │
│  │  │  │    ③ Decode 瓶颈在 memory bandwidth, 不在 compute!                       │      │   │
│  │  │  │  参考: continuous-batching.md 第 7 节, simt-parallel-model.md 第 5 节    │      │   │
│  │  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │  │                                                                               │   │
│  │  ├─ KV Cache 频繁 Swap？                                                           │   │
│  │  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  │  现象: 日志大量 "is preempted by swap/recompute"                          │      │   │
│  │  │  │  原因: GPU KV Cache 不足, 部分请求被换出/重算                               │      │   │
│  │  │  │  解决:                                                                   │      │   │
│  │  │  │    ① 降低 max_num_seqs (少并发了, 但避免 swap)                            │      │   │
│  │  │  │    ② 增大 gpu_memory_utilization (0.90 → 0.95)                           │      │   │
│  │  │  │    ③ 减小 max_model_len (节省 KV Cache 空间)                              │      │   │
│  │  │  │    ④ 使用 KV Cache 量化 (FP8 → 节省 50% 空间)                             │      │   │
│  │  │  │  参考: 02-scheduler-core.md 第 8 节, kv-cache-optimization.md 第 3 节     │      │   │
│  │  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │  │                                                                               │   │
│  │  ├─ 采样参数影响？                                                                  │   │
│  │  │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │  │  │  现象: TPOT 很高但 GPU 使用正常                                          │      │   │
│  │  │  │  可能原因: beam search (best_of > 1) → 多序列并行开销                      │      │   │
│  │  │  │  更常见: temperature > 0 时采样 (GPU 采样本身很快)                         │      │   │
│  │  │  │  解决:                                                                   │      │   │
│  │  │  │    ① temperature=0 → 贪心解码 (最快)                                     │      │   │
│  │  │  │    ② top_p=1.0, top_k=0 → 简化采样                                        │      │   │
│  │  │  │    ③ avoid beam search if not needed                                     │      │   │
│  │  │  │  参考: 05-worker-execution.md 第 9 节 (Sampler)                           │      │   │
│  │  │  └─────────────────────────────────────────────────────────────────────┘      │   │
│  │  │                                                                               │   │
│  │  └─ 量化模型 Dequant 开销？                                                        │   │
│  │     ┌─────────────────────────────────────────────────────────────────────┐      │   │
│  │     │  现象: AWQ/GPTQ 量化后居然比 FP16 慢!                                      │      │   │
│  │     │  原因: 使用了朴素 dequant kernel (先 dequant 到 FP16, 再计算)               │      │   │
│  │     │  或未使用专用 kernel (Marlin / AWQ GEMM)                                  │      │   │
│  │     │  解决:                                                                   │      │   │
│  │     │    ① 确保安装了 Marlin kernel (pip install vllm[marlin])                  │      │   │
│  │     │    ② batch size 太小 → 量化的 memory-bandwidth 优势体现不出来              │      │   │
│  │     │  参考: quantization-inference.md 第 5 节 (Marlin Kernel)                   │      │   │
│  │     └─────────────────────────────────────────────────────────────────────┘      │   │
│  │                                                                                  │   │
│  └─ 吞吐低 (< 2000 tokens/s)?                                                        │   │
│     │                                                                               │   │
│     ├─ Prefill 占太多计算？                                                            │   │
│     │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│     │  │  现象: benchmark 显示大量时间花在 prefill 上, decode 没批量                │      │   │
│     │  │  解决:                                                                   │      │   │
│     │  │    ① 启用 Chunked Prefill (prefill 和 decode 交错执行)                    │      │   │
│     │  │    ② 启用 Prefix Caching (避免重复 prefill)                               │      │   │
│     │  │  参考: scheduling-strategies.md 第 4 节, continuous-batching.md 第 4 节   │      │   │
│     │  └─────────────────────────────────────────────────────────────────────┘      │   │
│     │                                                                               │   │
│     ├─ Decode batch 太小？                                                            │   │
│     │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│     │  │  解决:                                                                   │      │   │
│     │  │    ① 增加 max_num_seqs (更多序列共存 → 更大 decode batch)                │      │   │
│     │  │    ② 增加外部请求并发 (qps)                                                │      │   │
│     │  │    ③ 使用量化 (节省显存 → 可容纳更多请求)                                  │      │   │
│     │  │  参考: 06-practical-tuning.md 第 4d 节, lab01-deploy-33b-optimize.md     │      │   │
│     │  └─────────────────────────────────────────────────────────────────────┘      │   │
│     │                                                                               │   │
│     ├─ 显存没充分利用？                                                                │   │
│     │  ┌─────────────────────────────────────────────────────────────────────┐      │   │
│     │  │  现象: nvidia-smi 显示大量空闲显存, 但吞吐不高                              │      │   │
│     │  │  检查: gpu_memory_utilization 是否设得太保守                              │      │   │
│     │  │  解决: 调大 gpu_memory_utilization (0.85 → 0.92 → 0.95)                   │      │   │
│     │  │  注意: 留一些余量给 CUDA Graph 和激活峰值                                   │      │   │
│     │  │  参考: 06-practical-tuning.md 第 4h 节                                    │      │   │
│     │  └─────────────────────────────────────────────────────────────────────┘      │   │
│     │                                                                               │   │
│     └─ CPU-GPU Swap 频繁？                                                            │   │
│        ┌─────────────────────────────────────────────────────────────────────┐      │   │
│        │  现象: 日志大量 preempt 消息, GPU 和 CPU 内存间频繁传输                     │      │   │
│        │  解决: 减少并发 (max_num_seqs), 或增大 swap_space                         │      │   │
│        │  参考: 02-scheduler-core.md 第 8.5 节                                     │      │   │
│        └─────────────────────────────────────────────────────────────────────┘      │   │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 各层排查 Checklist

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              各层排查 Checklist                                        │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  Layer 1: 网络层                                                                      │
│  □ ping/traceroute 检查延迟和丢包                                                       │
│  □ 检查 Nginx 配置: proxy_buffering off, tcp_nodelay on                              │
│  □ 检查 SSE 响应头: Content-Type: text/event-stream                                  │
│  □ strace 检查 TCP_NODELAY 是否生效                                                    │
│  □ 参考: networking.md 第 13 节                                                       │
│                                                                                     │
│  Layer 2: API 层                                                                      │
│  □ 检查 tokenization 耗时 (profile FastAPI endpoint)                                   │
│  □ 检查 chat_template 是否正确应用                                                     │
│  □ 检查 SamplingParams 是否合理 (temperature, max_tokens)                             │
│  □ 参考: python-essentials.md 第 5.4 节, vllm-architecture.md 第 2 节                │
│                                                                                     │
│  Layer 3: 调度层                                                                      │
│  □ 检查 3 个队列大小 (waiting, running, swapped)                                       │
│  □ 检查 token budget 设置 (max_num_batched_tokens)                                    │
│  □ 检查 max_num_seqs 是否合理                                                          │
│  □ 检查前缀缓存命中率 (prefix cache hit rate)                                          │
│  □ 检查抢占次数 (num_cumulative_preemption)                                            │
│  □ 参考: 02-scheduler-core.md 第 16 节                                                │
│                                                                                     │
│  Layer 4: 执行层                                                                      │
│  □ 检查 batch size (scheduled_seq_groups 数量)                                        │
│  □ 检查 prefill/decode 分别的耗时                                                      │
│  □ 检查 CUDA Graph 是否启用                                                            │
│  □ 检查 TP All-Reduce 通信开销 (Nsight Systems)                                        │
│  □ 参考: 05-worker-execution.md 第 10 节                                              │
│                                                                                     │
│  Layer 5: Attention 层                                                                │
│  □ 检查 KV Cache 命中率                                                                │
│  □ 检查 Attention 后端的实际选择 (FlashInfer / FlashAttention)                          │
│  □ Nsight Compute: 检查 memory_throughput 是否接近 HBM 峰值                            │
│  □ 参考: paged-attention-deep.md 第 10 节                                             │
│                                                                                     │
│  Layer 6: GPU 层                                                                      │
│  □ nvidia-smi: 检查 GPU 利用率、显存使用、温度                                           │
│  □ Nsight Systems: 检查 kernel launch overhead                                        │
│  □ Nsight Compute: 检查 SM Occupancy, memory throughput                               │
│  □ dcgmi: 检查 ECC Error, XID Error                                                   │
│  □ 参考: cuda-programming.md 第 8 节, monitoring-observability.md                    │
│                                                                                     │
│  Layer 7: 量化层                                                                       │
│  □ 检查量化方法是否正确应用 (AWQ/GPTQ/FP8)                                              │
│  □ 检查 Marlin kernel 是否安装                                                         │
│  □ Benchmark 对比 FP16 vs INT4 的 TPOT 和吞吐                                         │
│  □ 参考: quantization-inference.md 第 6 节                                            │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Part 5: 线上并发优化实操方案 (Production Optimization)

### 5.1 场景定义

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                     Qwen2.5-32B 部署到 2×A800, 服务 50 并发用户                         │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  目标 SLA:                                                                           │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  TTFT P50:  < 200ms                                                         │   │
│  │  TTFT P95:  < 500ms                                                         │   │
│  │  TPOT P50:  < 30ms                                                          │   │
│  │  TPOT P95:  < 60ms                                                          │   │
│  │  Throughput: > 2000 tokens/s (全系统, 非单请求)                               │   │
│  │  GPU Memory: < 150 GB (留余量)                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  用户行为假设:                                                                         │
│  - 平均 prompt 长度: 100 tokens                                                     │
│  - 平均 output 长度: 300 tokens                                                     │
│  - 50 并发用户, 请求间隔 ~1-2s                                                       │
│  - 假设有共享 system prompt (可用 Prefix Caching)                                     │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 优化路线图

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                          5 步逐级优化路线                                               │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  步骤 1: 部署基线                                                                     │
│  ═══════════════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  vllm serve /models/Qwen2.5-32B-Instruct \                                   │   │
│  │      --tensor-parallel-size 2 \                                               │   │
│  │      --port 8000                                                              │   │
│  │                                                                               │   │
│  │  参数: 全部使用默认值 (max_num_batched_tokens=2048, max_num_seqs=128,            │   │
│  │         gpu_memory_utilization=0.90, FP16)                                     │   │
│  │                                                                               │   │
│  │  Benchmark:                                                                   │   │
│  │    python -m vllm.benchmarks.benchmark_serving \                              │   │
│  │        --backend vllm \                                                        │   │
│  │        --model qwen2.5-32b \                                                   │   │
│  │        --dataset-name sharegpt \                                               │   │
│  │        --num-prompts 200 \                                                     │   │
│  │        --request-rate 8                                                        │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  步骤 2: 最大化并发 (max_num_seqs 扫描)                                               │
│  ═══════════════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  分别测试 max_num_seqs = 32, 64, 128, 256                                    │   │
│  │                                                                               │   │
│  │  预期: 32 → 64 吞吐大幅提升, 128 → 256 增长放缓或下降 (显存不够)               │   │
│  │  Sweet spot: 吞吐达到峰值 80% 时的最小 seqs 数                                  │   │
│  │  参考: 06-practical-tuning.md 第 4d 节                                        │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  步骤 3: Token Budget 调优 (max_num_batched_tokens)                                   │
│  ═══════════════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  分别测试: 2048, 4096, 8192, 16384                                            │   │
│  │                                                                               │   │
│  │  更大 budget → 更多 prefill token 可同时处理 → TTFT 降低                       │   │
│  │              但也会延长单步延迟 → TPOT 可能上升                                 │   │
│  │                                                                               │   │
│  │  推荐: 8192 (大多数场景) 或 16384 (长 prompt 场景)                              │   │
│  │  注意: Chunked Prefill 下这个值可以设得更大                                      │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  步骤 4: 启用关键优化                                                                 │
│  ═══════════════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │                                                                               │   │
│  │  ① Chunked Prefill:                                                            │   │
│  │    --enable-chunked-prefill                                                   │   │
│  │    效果: TTFT P95 大幅降低, TPOT 更稳定                                        │   │
│  │                                                                               │   │
│  │  ② Prefix Caching:                                                             │   │
│  │    --enable-prefix-caching                                                    │   │
│  │    效果: 共享 system prompt 时 TTFT 降低 50-80%                               │   │
│  │                                                                               │   │
│  │  ③ CUDA Graph:                                                                │   │
│  │    (默认启用)                                                                   │   │
│  │    效果: Decode TPOT 降低 10-30%                                               │   │
│  │    注意: 需要额外 GPU 显存 (1-3 GB)                                             │   │
│  │                                                                               │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
│  步骤 5: 量化 (AWQ INT4)                                                              │
│  ═══════════════════════════════════════════════════════════════════════════════    │
│  ┌──────────────────────────────────────────────────────────────────────────────┐   │
│  │  模型: /models/Qwen2.5-32B-Instruct-AWQ                                        │   │
│  │                                                                               │   │
│  │  vllm serve /models/Qwen2.5-32B-Instruct-AWQ \                                 │   │
│  │      --quantization awq \                                                      │   │
│  │      --tensor-parallel-size 2 \                                                 │   │
│  │      --max-model-len 16384 \                                                    │   │
│  │      --max-num-seqs 128 \                                                       │   │
│  │      --max-num-batched-tokens 8192 \                                            │   │
│  │      --gpu-memory-utilization 0.92 \                                            │   │
│  │      --enable-prefix-caching \                                                  │   │
│  │      --enable-chunked-prefill                                                   │   │
│  │                                                                               │   │
│  │  效果: 显存降低 ~75%, 吞吐提升 2-3×                                            │   │
│  └──────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 5.3 最终生产配置

```bash
#!/bin/bash
# 生产环境 Qwen2.5-32B-AWQ 推理服务启动脚本
# 硬件: 2 × A800 80GB (NVLink)
# 目标: 50 并发用户, 低延迟 + 高吞吐

vllm serve /models/Qwen2.5-32B-Instruct-AWQ \
    --quantization awq \
    --tensor-parallel-size 2 \
    --max-model-len 16384 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 8192 \
    --gpu-memory-utilization 0.92 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --host 0.0.0.0 \
    --port 8000

# 参数说明:
#   --quantization awq:          使用 AWQ INT4 量化, 权重从 66GB → 17GB
#   --tensor-parallel-size 2:    双卡 Tensor Parallelism
#   --max-model-len 16384:       最大 16K 上下文 (根据实际需求调整)
#   --max-num-seqs 64:           最多 64 个并发序列
#   --max-num-batched-tokens 8192: 每 step 最多 8192 tokens
#   --gpu-memory-utilization 0.92: 92% GPU 内存用于 KV Cache
#   --enable-prefix-caching:     启用前缀缓存 (system prompt 共享)
#   --enable-chunked-prefill:    启用分块预填充 (降低 TTFT 抖动)
```

### 5.4 优化效果记录表

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                     Qwen2.5-32B 在 2×A800 上的优化效果记录                              │
├─────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  步骤 │ 配置变更                     │ TTFT P50│ TTFT P95│ TPOT P50│ TPOT P95│ 吞吐      │ GPU Mem │
│  ────┼────────────────────────────┼─────────┼─────────┼─────────┼─────────┼──────────┼─────────│
│  基线 │ FP16, 默认参数               │ 180ms   │ 520ms   │ 32ms    │ 58ms    │ 2800 t/s │ 62GB  │
│  +1   │ max_num_seqs=64            │ 175ms   │ 480ms   │ 30ms    │ 52ms    │ 3500 t/s │ 64GB  │
│  +2   │ max_num_batched_tokens=8192│ 165ms   │ 430ms   │ 31ms    │ 54ms    │ 3400 t/s │ 63GB  │
│  +3   │ +Chunked Prefill           │ 150ms   │ 280ms   │ 29ms    │ 45ms    │ 3300 t/s │ 63GB  │
│  +4   │ +Prefix Caching            │  45ms   │ 110ms   │ 28ms    │ 43ms    │ 3800 t/s │ 61GB  │
│  +5   │ AWQ INT4 量化              │ 130ms   │ 350ms   │ 18ms    │ 38ms    │ 5500 t/s │ 22GB  │
│  +6   │ AWQ + max_num_seqs=128     │ 145ms   │ 420ms   │ 20ms    │ 42ms    │ 8200 t/s │ 25GB  │
│  ────┼────────────────────────────┼─────────┼─────────┼─────────┼─────────┼──────────┼─────────│
│  最终 │ AWQ + 64 seqs + 全部优化     │ 140ms   │ 320ms   │ 18ms    │ 35ms    │ 6500 t/s │ 22GB  │
│                                                                                     │
│  核心发现:                                                                            │
│  ① AWQ 量化是 ROI 最高的优化: 显存 -65%, 吞吐 +96%                                    │
│  ② Prefix Caching 对 TTFT 提升最显著 (共享前缀场景 -75% TTFT)                         │
│  ③ Chunked Prefill 减少了长 tail 延迟 (P95 从 520ms → 280ms)                        │
│  ④ 增大 seqs 到 128 时吞吐继续涨但 P95 也涨 (取舍!)                                  │
│  ⑤ 最终选择 64 seqs: 在延迟和吞吐间取平衡                                             │
│                                                                                     │
│  注意: 以上是示例数据, 实际值取决于硬件、工作负载和模型版本。                             │
│        每个公司的数据都需要自己 benchmark!                                             │
│                                                                                     │
│  参考: lab01-deploy-33b-optimize.md (第 2-8 节, 完整 step-by-step)                    │
│        06-practical-tuning.md (调优心法和完整 checklist)                               │
│                                                                                     │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 附录 A: 全部 41 篇文档索引

### 阶段 1: 通用计算机基础 (stage1-cs-basics)

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 1 | `stage1-cs-basics/networking.md` | TCP/IP、HTTP/SSE、NCCL、RDMA、InfiniBand、Nginx 反向代理 | Layer 1: curl 请求如何到达 FastAPI、SSE 流式输出如何传输 |
| 2 | `stage1-cs-basics/python-essentials.md` | FastAPI、Async/Await、生成器、GIL、多进程 vs 多线程、pybind11 | Layer 2: AsyncLLMEngine 的异步架构、StreamingResponse 实现 |
| 3 | `stage1-cs-basics/os-memory-process.md` | 虚拟内存、页表、TLB、PagedAttention 的 OS 类比、CUDA 内存、OOM | Layer 3: PagedAttention 的 OS 理论基础、模型加载 mmap |
| 4 | `stage1-cs-basics/cpp-for-source-reading.md` | C++ 智能指针、RAII、STL、pybind11、vLLM 源码模式 | 源码阅读: 理解 vLLM C++/CUDA 源码 |

### 阶段 2: AI Infra 底层技术 (stage2-ai-infra-foundations)

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 5 | `stage2-ai-infra-foundations/pytorch-transformer.md` | PyTorch Tensor、Autograd、Transformer 完整架构、RoPE、GQA、MLA、SwiGLU、RMSNorm | Layer 4: 64 层 Transformer 的每个计算步骤 |
| 6 | `stage2-ai-infra-foundations/deep-learning-basics.md` | 反向传播、RMSNorm、SiLU、混合精度、Einsum、梯度下降 | Layer 4: 理解 RMSNorm/SiLU 算子的数学和优化需求 |
| 7 | `stage2-ai-infra-foundations/cuda-programming.md` | GPU 架构、Tensor Core、CUDA Streams、GEMM 优化、CUDA Graphs、PagedAttention Kernel | Layer 6: GPU 微观执行、Tensor Core 矩阵乘 |
| 8 | `stage2-ai-infra-foundations/simt-parallel-model.md` | SIMT、Warp、Occupancy、延迟隐藏、SM 架构、Roofline 模型、A800 规格 | Layer 6: Decode 为什么 Memory-Bound、Roofline 分析 |

### 阶段 3-A: 算子 Kernel 开发 (stage3-direction-A-kernel)

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 9 | `stage3-direction-A-kernel/attention-kernel-optimize.md` | FlashAttention Tiling、Online Softmax、PagedAttention Kernel、FlashDecoding | Layer 5: Attention 计算的底层优化 |
| 10 | `stage3-direction-A-kernel/cuda-kernel-deep-dive.md` | SMEM Bank Conflict、Warp Shuffle、Tensor Core mma、Async Pipeline、GEMM Step by Step | Layer 6: 每个 kernel 的 CUDA 微观优化 |
| 11 | `stage3-direction-A-kernel/cutlass-triton-kernel.md` | CUTLASS 模板、Triton 编程、Epilogue 融合、RMSNorm+SiLU 融合 | 自定义算子: 用 Triton 写融合 kernel |
| 12 | `stage3-direction-A-kernel/dcu-hip-kernel.md` | DCU/AMD 架构、HIP、Wavefront vs Warp、ROCm、vLLM on AMD | 国产硬件适配: DCU 上的推理 |

### 阶段 3-B: 推理引擎开发 (stage3-direction-B-inference) -- 核心方向

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 13 | `stage3-direction-B-inference/vllm-architecture.md` | vLLM 全栈架构、AsyncLLMEngine、Scheduler、Worker、TP、CUDA Graph | Layer 2-4: vLLM 整体架构和请求生命周期 |
| 14 | `stage3-direction-B-inference/continuous-batching.md` | Static vs Continuous Batching、Prefill/Decode 协同、Chunked Prefill、抢占 | Layer 3: 调度器的核心算法 |
| 15 | `stage3-direction-B-inference/paged-attention-deep.md` | PagedAttention 完整设计、Block Table、CoW、Prefix Caching、CPU Offloading | Layer 5: KV Cache 管理机制 |
| 16 | `stage3-direction-B-inference/kv-cache-optimization.md` | KV Cache 量化 (FP8/INT8/KIVI)、MLA、GQA、Prefix Caching、Swap | Layer 5: KV Cache 优化技术 |
| 17 | `stage3-direction-B-inference/quantization-inference.md` | GPTQ、AWQ、Marlin Kernel、FP8、33B 部署方案 | Layer 7: 量化推理 |
| 18 | `stage3-direction-B-inference/scheduling-strategies.md` | FCFS、Prefill-First、MLFQ、Chunked Prefill 数学建模、工作负载模式 | Layer 3: 不同调度策略对比 |
| 19 | `stage3-direction-B-inference/speculative-decoding.md` | 推测解码、拒绝采样、树注意力、Medusa、Eagle | Decode 加速 (可选) |
| 20 | `stage3-direction-B-inference/tensorrt-llm.md` | TensorRT-LLM 架构、In-Flight Batching、层融合、Kernel Auto-Tuning | 推理框架对比 |
| 21 | `stage3-direction-B-inference/triton-inference-server.md` | Triton 架构、vLLM Backend、Ensemble/BLS、Dynamic Batching | 推理服务部署 |

### 阶段 3-C: 分布式训练 (stage3-direction-C-training)

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 22 | `stage3-direction-C-training/distributed-training-basics.md` | DDP、梯度累积、混合精度、Ring All-Reduce、FSDP | TP 推理的通信基础 |
| 23 | `stage3-direction-C-training/megatron-lm-deep-dive.md` | TP 完整数学分析、Column/Row Parallel、Sequence Parallelism、3D 并行 | Layer 4: TP 推理的权重切分和通信 |
| 24 | `stage3-direction-C-training/deepspeed-zero.md` | ZeRO-1/2/3、ZeRO-Infinity、参数分片 | 大模型加载技术 |
| 25 | `stage3-direction-C-training/fsdp-torch-distributed.md` | FSDP v1 vs v2、Device Mesh、torch.distributed | 分布式通信原语 |
| 26 | `stage3-direction-C-training/pipeline-parallelism.md` | Bubble 问题、GPipe、1F1B、Interleaved、PP vs TP | 理解何时用 PP 而非 TP |

### 阶段 3-D: MLOps (stage3-direction-D-mlops)

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 27 | `stage3-direction-D-mlops/k8s-gpu-orchestration.md` | K8s GPU Operator、MIG/MPS、vLLM Deployment、HPA、滚动更新 | 生产部署: K8s 上运行 vLLM |
| 28 | `stage3-direction-D-mlops/monitoring-observability.md` | DCGM、vLLM Metrics、Prometheus、Grafana、SLO、告警 | 生产监控: 指标和告警 |
| 29 | `stage3-direction-D-mlops/multi-tenancy-networking.md` | MIG、InfiniBand、RoCE、NVLink、GPU Direct RDMA | Layer 1/6: GPU 互联网络 |
| 30 | `stage3-direction-D-mlops/slurm-hpc-scheduling.md` | Slurm 架构、GPU 作业提交、Fair-Share | 集群调度 |
| 31 | `stage3-direction-D-mlops/storage-model-distribution.md` | Lustre、NFS、Safetensors mmap、模型分发、Dragonfly | 模型存储和分发 |

### 阶段 4-A: vLLM 源码精读 (stage4-projects/vllm-source-reading)

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 32 | `vllm-source-reading/01-entrypoint-startup.md` | vLLM 启动 9 阶段、EngineCore、Worker 初始化、内存 profiling | 启动流程: 从 CLI 到服务就绪 |
| 33 | `vllm-source-reading/02-scheduler-core.md` | Scheduler 完整源码、3 队列、SchedulingBudget、Chunked Prefill、抢占 | Layer 3: 调度器完整源码分析 |
| 34 | `vllm-source-reading/03-block-manager.md` | BlockSpaceManager、BlockTable、Prefix Caching Block、CoW、Swap | Layer 3: Block 管理源码分析 |
| 35 | `vllm-source-reading/04-model-loader.md` | ModelRegistry、Safetensors 加载、TP 分片、AWQ 量化加载 | 模型加载源码 |
| 36 | `vllm-source-reading/05-worker-execution.md` | Worker、ModelRunner、CUDA Graph 捕获、TP 执行、Sampler | Layer 4: Worker 执行源码 |
| 37 | `vllm-source-reading/06-practical-tuning.md` | 调优 3 法则、瓶颈诊断、逐参数扫描、生产配置 | Part 5: 生产调优指南 |

### 阶段 4-B: 动手实验 (stage4-projects/hands-on-labs)

| # | 文档路径 | 核心内容 | 与推理链路的关系 |
|---|---------|---------|-----------------|
| 38 | `hands-on-labs/lab01-deploy-33b-optimize.md` | 基线部署、基准测试、逐级优化 (量化/Batch/Prefix/Chunked) | Part 5: 完整优化实验 |
| 39 | `hands-on-labs/lab02-rag-claude-code.md` | BGE 嵌入、FAISS 向量检索、RAG Pipeline、Claude Code 集成 | 推理服务应用: RAG |
| 40 | `hands-on-labs/lab03-writing-custom-kernel.md` | Triton Kernel 编写、RMSNorm+SiLU 融合、Autotune、Benchmark | Layer 6: 自定义融合 kernel |

### 总览文档

| # | 文档路径 | 核心内容 |
|---|---------|---------|
| 41 | `README.md` | 整体学习路线、四阶段规划、学习建议 |

---

## 附录 B: 关键数字速查表

### B.1 Qwen2.5-32B 参数速查

```
参数总量:              33B (330 亿)
层数:                   64
隐藏维度:              5120
Q 头数:                40
KV 头数:               8 (GQA)
每头维度:              128
中间维度 (FFN):        13824 (SwiGLU)
词表大小:              152064
最大上下文:            131072
所有权重 (BF16):       ~66 GB
所有权重 (INT4):       ~17 GB
单 Token KV:           ~256 KB
单 Block (16 tokens):  ~4 MB
```

### B.2 A800 GPU 规格

```
SM 数量:                108
FP16 Tensor Core:      312 TFLOPS
INT4 Tensor Core:      1248 TOPS
HBM2e 带宽:            2039 GB/s
HBM2e 容量:            80 GB
L2 缓存:               40 MB
SMEM/SM:               164 KB
寄存器/SM:             256 KB (65536 x 32-bit)
NVLink 3.0:           600 GB/s 双向
PCIe Gen4 x16:         ~32 GB/s
```

### B.3 性能数字 (Qwen2.5-32B @ 2xA800)

```
TTFT (55 tokens):      ~150ms (Prefill)
TPOT (per token):      ~25ms (Decode, 单请求)
Prefill 吞吐:          ~366 tok/s (55 tokens / 150ms)
Decode 吞吐:           ~40 tok/s (单请求)
并发吞吐 (FP16):       ~2800 tok/s (系统总吞吐)
并发吞吐 (INT4):       ~6500 tok/s (系统总吞吐)
权重加载时间:          ~5-8s (从 NVMe)
KV Cache (555 tokens): ~140 MB
KV Cache 可用:         ~73 GB (gpu_memory_utilization=0.90)
最大并发序列 (8K ctx): ~539 (理论值)
```

### B.4 典型延迟分解 (单请求, 55 tokens → 500 tokens)

```
TCP 连接 + HTTP:       ~1ms     (0.01%)
Tokenize + API:        ~2ms     (0.02%)
调度 + 块分配:          ~0.5ms   (0.004%)
Prefill:               ~150ms   (1.2%)
Decode × 500:          ~12500ms (98.8%)
──────────────────────────────────────
总计:                   ~12653ms (100%)
```

---

## 附录 C: 核心源码文件速查

### vLLM 核心源码文件

```
vllm/
├── entrypoints/openai/
│   ├── api_server.py              # FastAPI 应用入口, 路由注册
│   ├── serving_chat.py            # /v1/chat/completions 处理
│   ├── serving_completion.py      # /v1/completions 处理
│   └── protocol.py                # OpenAI 兼容协议类型
│
├── engine/
│   ├── async_llm_engine.py        # 异步推理引擎 (核心)
│   ├── llm_engine.py              # 同步推理引擎
│   └── output_processor.py        # 输出后处理: token → text → SSE
│
├── core/
│   ├── scheduler.py               # 调度器: prefill/decode/preempt
│   └── block/
│       ├── block_manager.py       # BlockSpaceManager
│       ├── block_table.py         # Block Table 数据结构
│       └── prefix_caching_block.py # 前缀缓存块管理
│
├── worker/
│   ├── worker.py                  # Worker: GPU 进程管理
│   └── model_runner.py            # ModelRunner: execute_model, CUDA Graph
│
├── model_executor/
│   ├── model_loader.py            # 模型加载 (safetensors 等)
│   └── layers/
│       ├── attention.py           # Attention 层实现
│       └── linear.py              # 线性层 (含量化支持)
│
├── attention/
│   ├── backends/
│   │   ├── flash_attn.py          # FlashAttention 后端
│   │   ├── flashinfer.py          # FlashInfer 后端
│   │   └── xformers.py            # xFormers 后端
│   └── ops/
│       └── paged_attn.py          # PagedAttention Python 封装
│
├── csrc/                          # C++/CUDA 源码
│   ├── attention/
│   │   └── attention_kernels.cu   # PagedAttention CUDA Kernel
│   ├── cache_kernels.cu           # KV Cache 操作 kernel
│   ├── quantization/
│   │   ├── awq/                   # AWQ 量化 kernel
│   │   └── gptq_marlin/           # Marlin INT4 kernel
│   └── pybind/                    # pybind11 绑定
│
├── config.py                      # ModelConfig, CacheConfig, SchedulerConfig
├── sampling_params.py             # SamplingParams: temp, top_p, top_k
└── sequence.py                    # Sequence, SequenceGroup, SequenceStatus
```

### 关键行号速查 (scheduler.py)

```
vllm/core/scheduler.py
  L46-120   SchedulingBudget
  L122-130  ScheduledSequenceGroup
  L132-198  SchedulerOutputs
  L324-423  Scheduler.__init__()
  L437-439  add_seq_group()
  L521-683  _schedule_running()
  L895-1049 _schedule_prefills()
  L1051-1154 _schedule_default()
  L1156-1249 _schedule_chunked_prefill()
  L1289-1444 schedule() 主入口
  L1535-1575 _preempt() 抢占决策
```

---

> **本文档是 AI Infra 全链路学习资料的「总索引」和「全景图」。**
>
> **推荐使用方式**: 先通读本文档建立全景认知, 然后按照 [1.5 节](#15-文档阅读顺序建议) 的推荐顺序逐步深入各个子文档。
>
> **核心心态**: 不求速成, 先广后深。AI Infra 的深度决定了它不可能 3 个月速成, 给自己 1-2 年持续积累。每次遇到性能问题, 回到本文档的 Part 4 排查决策树定位瓶颈层, 再查阅对应深度文档。

---

*本文档覆盖全部 41 篇学习文档，串联了从 curl 请求到 GPU 返回最后一个 token 的完整路径。*
*最后更新: 2026-07-20*
