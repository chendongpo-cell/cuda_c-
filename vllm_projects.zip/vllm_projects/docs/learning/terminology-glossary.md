# AI Infra 术语通俗词典

> 每个术语附带一句「大白话」类比 + 专业定义。按拼音首字母排序，方便检索。覆盖阶段 1~4 全部核心术语。

---

## A

### All-Gather / 全收集（通信原语）
- **类比**：班级里每人有一张不同的扑克牌，所有人同时把牌亮出来——每个人都看到了所有人的牌。
- **专业定义**：每个进程贡献一块不同的数据，操作完成后所有进程都拥有所有数据的拼接结果。通信量为 (N-1)/N * D。在张量并行（TP）前向中用于将切分的激活值收集到所有 GPU；在 FSDP/ZeRO-3 中用于临时收集参数分片。
- **首次出现**：stage3-direction-C-training/distributed-training-basics.md
- **分类**：方向 C - 分布式训练

### All-Reduce / 全归约（通信原语）
- **类比**：班级里每人报一个数，所有人同时在心中算出总和——不需要班长统计，也不需依次传递。
- **专业定义**：对每个 GPU 上的数据进行归约（如求和），然后将结果广播给所有 GPU。Ring All-Reduce 通信量为 2(N-1)/N * D，步数为 2(N-1)，带宽利用率高；Tree All-Reduce 步数为 2*log2(N)，延迟低。在数据并行训练中用于梯度同步，在 TP 中每层需要 2~4 次 All-Reduce。
- **首次出现**：stage3-direction-C-training/distributed-training-basics.md
- **分类**：方向 C - 分布式训练

### Arithmetic Intensity / 算术强度
- **类比**：厨师炒菜的「翻炒次数」和「取菜次数」的比例。如果取一次菜可以炒很多盘（高算术强度），效率高；如果每次只翻炒几下又要去取菜（低算术强度），效率极低。
- **专业定义**：算术强度 = 计算操作数（FLOPs）/ 内存访问量（Bytes）。是 Roofline 模型的 X 轴。高算术强度的 GEMM（100+ FLOP/Byte）是 compute-bound；低算术强度的 element-wise 操作（~0.25 FLOP/Byte）是 memory-bound。推理优化的核心策略之一就是将多个低算术强度算子融合成少数高算术强度的 kernel。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Async/Await / 异步等待
- **类比**：餐厅服务员点完菜不站在厨房门口干等，而去服务其他桌——菜好了厨师会按铃通知（await 返回）。
- **专业定义**：Python 异步编程的核心机制。`async def` 定义协程，`await` 挂起当前协程、将控制权交还给 Event Loop。底层依赖 epoll 等 I/O 多路复用。vLLM 的 AsyncLLMEngine 就是基于 asyncio：Event Loop 驱动调度循环，GPU 推理时（释放 GIL）同时处理新请求和流式响应。
- **首次出现**：stage1-cs-basics/python-essentials.md
- **分类**：阶段 1 - 计算机基础

### Atomic Operation / 原子操作
- **类比**：公共记事本签名——一个人写完前别人不能插队。要么写完完整名字，要么一个字没写，不会出现「写了半个字」的状态。
- **专业定义**：硬件级「读-改-写」不可分割操作。C++ 中 `std::atomic<T>` 实现。GPU 上的 `atomicAdd` 用于跨线程安全累加，常用于 Online Softmax 的全局最大值/总和更新。不同 memory_order（relaxed/acquire/release）提供不同级别的可见性保证。
- **首次出现**：stage1-cs-basics/cpp-for-source-reading.md
- **分类**：阶段 1 - 计算机基础

### Attention Mechanism / 注意力机制
- **类比**：搜索引擎——你输入关键词（Query），搜索引擎拿它和所有文档（Key）算相关性，再把最相关的文档内容（Value）加权返回给你。
- **专业定义**：Transformer 的核心计算单元。公式：Attention(Q,K,V) = softmax(QK^T / sqrt(d_k)) * V。除以 sqrt(d_k)（缩放因子）防止点积方差过大导致 softmax 梯度消失。自回归解码时需加 causal mask 阻止当前位置看到未来 token。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

### Autograd / 自动求导
- **类比**：乐高积木——每拼一块自动记下拼法。拆的时候系统自动逆序告诉你每一步该怎么拆，不需要自己回忆。
- **专业定义**：PyTorch 的自动微分引擎。前向传播时动态构建有向无环计算图（define-by-run），每个 Tensor 记录自己的 `grad_fn`。调用 `backward()` 时逆拓扑序遍历图，用链式法则逐节点计算梯度。Gradient Checkpointing 利用 autograd 的重算机制——前向不保存中间激活，反向从检查点重新前向计算。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

### AWQ (Activation-aware Weight Quantization) / 激活感知权重量化
- **类比**：搬家打包——贵重花瓶（激活值大的通道）用泡沫纸包好保留高精度，普通衣服（不重要的通道）直接塞压缩袋。
- **专业定义**：面向 LLM 的 4-bit 权重量化方法。核心洞察：激活值大的通道（salient channels，~1%）对量化误差更敏感。通过分析激活分布找到这些关键通道，在量化前对权重做 per-channel scaling，将量化误差从重要通道「转移」到不重要通道。比 GPTQ 更轻量，精度几乎持平。
- **首次出现**：stage3-direction-B-inference/quantization-inference.md
- **分类**：方向 B - 推理引擎

---

## B

### Backpropagation / 反向传播
- **类比**：传话游戏链——最后一棒的人告诉你结果错了，你沿途往回走，告诉每个人他传话偏了多少，每个人据此调整下次传话方式。
- **专业定义**：训练神经网络的核心算法。通过链式法则从损失函数开始沿计算图逆向传递，计算每个可学习参数的梯度。前向传播计算输出和损失，反向传播从损失开始逐层计算局部雅可比矩阵，累积出每个参数对损失的偏导数。层数越深，乘法链越长，越容易出现梯度消失/爆炸。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### Bank Conflict / 共享内存 Bank 冲突
- **类比**：银行有 32 个柜台，32 个客户同时去 1 号柜台排队——其他 31 个柜台空着，效率极低。
- **专业定义**：GPU 共享内存被划分为 32 个 4 字节宽的 bank。当同一 warp 内多个线程访问的数据落在同一 bank 的不同地址时，访问被序列化（n-way bank conflict 需 n 个周期）。优化方法：加 padding 或调整数据布局（SoA 替代 AoS），确保 warp 内线程访问分散在不同 bank 上。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Block Size (Token) / 块大小
- **类比**：快递分拣中心按固定大小的箱子打包包裹——统一尺寸让搬运和存储都更高效，但最后一个箱子没装满的损失（内部碎片）和箱子太小导致数量太多（管理开销）需要权衡。
- **专业定义**：PagedAttention 中每个 KV Cache 块包含的 token 数，通常为 16。块越小 → 内部碎片越少但块表越大；块越大 → 块表越小但碎片更多。vLLM 默认 block_size=16，这是大量实验得出的工程最优值。
- **首次出现**：stage3-direction-B-inference/paged-attention-deep.md
- **分类**：方向 B - 推理引擎

### Block Table / 块表
- **类比**：快递仓库的分拣清单——「3 号包裹在 A-14 货架，7 号包裹在 B-03 货架」。货物可以放在任何位置，这份清单让找包裹变成 O(1)。
- **专业定义**：PagedAttention 中每个序列维护的映射表：逻辑块序号 → 物理块 ID（GPU HBM 中的实际位置）。这是 PagedAttention 类比 OS 页表的核心：Attention 看到连续的逻辑块序列，实际 KV Cache 存储在物理上不连续的 GPU 显存块中。Block Table 使得非连续分配成为可能，彻底消除 KV Cache 外部碎片。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 + 方向 B（跨阶段核心概念）

### Bubble (Pipeline) / 流水线气泡
- **类比**：工厂流水线上，第一个产品从起点走到终点时，后面的工作站正在装配但前面的已在空转等待——这段空闲就是气泡。
- **专业定义**：流水线并行中因 micro-batch 间数据依赖导致的 GPU 空闲时间。气泡大小 = (PP-1) / (M + PP - 1)，其中 PP 是流水线深度，M 是 micro-batch 数。1F1B 调度通过交错执行前后向减少气泡但无法完全消除。micro-batch 越多气泡越小，但受显存限制。Interleaved 1F1B 引入虚拟 stage 进一步减小气泡。
- **首次出现**：stage3-direction-C-training/pipeline-parallelism.md
- **分类**：方向 C - 分布式训练

---

## C

### Causal Mask / 因果掩码
- **类比**：考试时你只能参考前面做过的题，不能翻后面没做的题——每个 token 只能「看到」自己及之前的 token。
- **专业定义**：自回归语言模型中防止信息泄露的下三角矩阵。对于序列长度 S，causal mask 是 S×S 矩阵：位置 i 只能关注位置 0~i（下三角为 0/True），不能关注 i+1~S-1（上三角为 -inf/False）。在 attention score 上做 `masked_fill(-inf)` 使未来位置的 softmax 值为 0。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

### Chunked Prefill / 分块预填充
- **类比**：饭馆来了一个大团（长 prompt），不让他们一次性点完所有菜堵死厨房，而是拆成小批依次处理，中间插空照顾散客（decode）。
- **专业定义**：将长 prompt 切成固定大小 chunk（如 512 tokens），每个调度步只处理一个 chunk，chunk 之间插入 decode 请求。平滑 TTFT 与 TPOT 的权衡——减少长 prompt 对 decode 延迟的冲击，是交互式 LLM 服务的标配优化。
- **首次出现**：stage3-direction-B-inference/scheduling-strategies.md
- **分类**：方向 B - 推理引擎

### Coalesced Access / 合并访问
- **类比**：超市结账时商品整整齐齐放在传送带上挨个扫码——收银员一次扫一排，而不是东一个西一个散乱摆放。
- **专业定义**：GPU 全局内存访问效率的核心优化。同一 warp 的 32 个线程访问连续且对齐的地址时，GPU 可将其合并为一次内存事务（128 字节对齐）。非合并访问（strided 或 random）可能导致多达 32 次内存事务，带宽损失 10 倍以上。优化 CUDA kernel 的最基本原则。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Context Switch / 上下文切换
- **类比**：你正在看书（进程 A），突然要接电话——夹书签、合上书（保存状态）、接电话，挂电话后找回书签继续读（恢复状态）。
- **专业定义**：CPU 从一个任务切换到另一个任务。进程切换需切换页表（CR3 寄存器）和刷新 TLB，耗时约 1-5 微秒（含 cache miss 惩罚可达 10-50 微秒）。线程切换（同一进程内）无需切换页表和刷新 TLB，耗时仅 0.1-1 微秒。vLLM 选择多线程而非多进程的原因之一就是避免昂贵的 CUDA context 切换。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

### Continuous Batching / 连续批处理
- **类比**：机场摆渡车——不管人多人少随到随走，不等到整车坐满才出发。每站可以有人上车也有人下车。
- **专业定义**：现代 LLM 推理引擎的核心调度技术。每个推理步完成后动态决定 batch 组成：完成的请求退出、有输入到达的请求加入。相比静态 batching（必须等 batch 全部完成），GPU 利用率大幅提升。vLLM、TGI、TensorRT-LLM 均采用此策略。是 vLLM 吞吐量远超传统推理框架的主要原因之一。
- **首次出现**：stage3-direction-B-inference/continuous-batching.md
- **分类**：方向 B - 推理引擎

### Cross-Entropy / 交叉熵
- **类比**：天气预报说「70% 概率下雨」真下了，你的意外程度是 -log(0.7) ≈ 0.36。说「1% 概率下雨」但真下了，意外程度是 -log(0.01) ≈ 4.6——交叉熵衡量预测和现实的「诧异度」。
- **专业定义**：衡量两个概率分布之间差异的损失函数。H(p, q) = -Σ p(i) * log(q(i))，p 是真实分布，q 是模型预测分布。语言模型中等价于 -log(p_correct_token)。Perplexity（困惑度）= exp(cross-entropy)，表示模型在每个位置平均从多少个候选 token 中选择。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### CUDA Graph / CUDA 图
- **类比**：每天做早餐的流程（打蛋→倒油→煎蛋→装盘）录成视频，每天按播放键一键执行——省去每次看菜谱逐个步骤操作的调度时间。
- **专业定义**：CUDA 10+ 的机制，将一系列 kernel 启动和内存操作「录制」为静态执行图，后续一次 API 调用即可完整重放。消除每次 kernel launch 的 CPU 端开销（每次约 5-10 微秒）。LLM 推理的 decode 阶段每次迭代执行相同操作序列，非常适合 CUDA Graph 捕获——可减少 10-30% 的延迟。需配合 memory pool 使用（固定内存地址）。
- **首次出现**：stage2-ai-infra-foundations/cuda-programming.md
- **分类**：阶段 2 + 方向 B

### CUTLASS
- **类比**：乐高 CUDA 积木套装——CUDA 给你砖块模子（PTX/SASS），CUTLASS 给你各种现成的乐高零件（tile、warp、MMA），你只需按说明书拼装即可。
- **专业定义**：NVIDIA 开源的 CUDA C++ 模板库，提供高性能 GEMM 和卷积的模板化实现。核心抽象层级：Threadblock Tile → Warp Tile → MMA Instruction → Epilogue（后处理如 bias、激活函数）。CUTLASS 3.x 引入 Collective 抽象和 CuTe 核心层，支持 Hopper 架构的 TMA 和 FP8。FlashAttention 和许多量化推理 kernel 都基于 CUTLASS 构建。
- **首次出现**：stage3-direction-A-kernel/cutlass-triton-kernel.md
- **分类**：方向 A - Kernel 开发

---

## D

### Data Parallelism (DP) / 数据并行
- **类比**：8 条产线组装同样的产品，每条产线用不同的原料（数据）。每次产出零件后 8 条线汇总统计，统一调整产线参数。
- **专业定义**：分布式训练最基本策略。每个 GPU 持有完整模型副本，处理不同的 mini-batch。每步通过 All-Reduce 对所有 GPU 梯度求平均。通信量 = 2 * 参数量/步。当模型大到单 GPU 放不下时，必须配合 ZeRO（分片优化器状态）或模型并行（TP/PP）使用。
- **首次出现**：stage3-direction-C-training/distributed-training-basics.md
- **分类**：方向 C - 分布式训练

### DCGM (Data Center GPU Manager) / 数据中心 GPU 管理器
- **类比**：医院 ICU 监护仪——实时监测每个病人的心率、血压、血氧，有任何异常立刻报警。
- **专业定义**：NVIDIA 官方 GPU 遥测和诊断工具。提供 GPU 利用率、显存、温度、功耗、SM 时钟、XID 错误等实时指标采集。通过 `dcgm-exporter` 将数据暴露给 Prometheus，结合 Grafana 构建 GPU 集群监控大盘。是 MLOps 监控体系中的核心组件。
- **首次出现**：stage3-direction-D-mlops/monitoring-observability.md
- **分类**：方向 D - 算力集群 MLOps

### DDP (Distributed Data Parallel) / 分布式数据并行
- **类比**：Data Parallelism 的「自动化教练版」——教练帮你协调所有人的训练节奏和梯度同步，不必手动写汇总代码。
- **专业定义**：PyTorch 的分布式数据并行模块。每个 GPU 独立进程（而非多线程），使用 NCCL 后端进行梯度 All-Reduce。关键优化：梯度 bucketing（将多个参数的梯度打包通信）、通信与计算 overlap（反向传播当前层时异步通信前一层梯度）。DDP 是 FSDP 和大规模分布式训练的基础。
- **首次出现**：stage3-direction-C-training/fsdp-torch-distributed.md
- **分类**：方向 C - 分布式训练

### Decode / 解码（推理阶段）
- **类比**：你已经读了文章的前半部分（prefill 完成理解），现在逐字写续写——每写一个字只需看一眼刚写了什么（KV Cache），不必重新读全文。
- **专业定义**：自回归推理第二阶段。prefill 处理完 prompt 后，逐 token 生成输出。每次只处理 1 个新 token：计算其 Q，从 KV Cache 读取所有历史 K 和 V 做 attention、过 FFN、采样输出。Decode 是 memory-bound——大部分时间花在从 HBM 读取模型权重和 KV Cache 上，Tensor Core 利用率通常 <30%。是 Continuous Batching 和 KV Cache 优化的主要目标阶段。
- **首次出现**：stage3-direction-B-inference/continuous-batching.md
- **分类**：方向 B - 推理引擎

### DMA (Direct Memory Access) / 直接内存访问
- **类比**：秘书（DMA 引擎）帮你搬文件——你只需告诉她「把这个文件从 A 柜搬到 B 柜」，然后你继续开会，秘书自己完成搬运后通知你。
- **专业定义**：允许硬件设备（GPU、网卡、磁盘控制器）直接读写系统内存而无需 CPU 逐字节参与。GPU 推理中 `cudaMemcpyAsync` 发起 DMA 传输后 CPU 不阻塞，GPU DMA 引擎通过 PCIe 总线直接将 CPU pinned memory 数据搬到 GPU HBM。Pinned memory 是 DMA 高效运作的前提——OS 保证这些物理页不换出。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

### Draft Model / 草稿模型
- **类比**：大作家写小说很慢但质量高，请实习生先快速写草稿，大作家审核——只改不同意的地方，大幅提升出稿速度。
- **专业定义**：Speculative Decoding 中的「猜测」模型。通常参数量为 target model 的 1/10~1/100，对同一输入快速生成 K 个候选 token。Target model 并行验证这些 token，通过拒绝采样（接受概率 = min(1, P_target/P_draft)）决定接受或拒绝。理论上无损 target model 生成质量。
- **首次出现**：stage3-direction-B-inference/speculative-decoding.md
- **分类**：方向 B - 推理引擎

---

## E

### ECC Error / ECC 错误
- **类比**：银行的账本复核员——每笔交易旁写一个「校验码」，字迹模糊时可通过校验码推理出原数字并修正。
- **专业定义**：Error Correcting Code，GPU 内存的保护机制。HBM 使用 SECDED（单错纠正、双错检测）方案。单比特翻转（多由宇宙射线或芯片老化引起）透明纠正；双比特不可纠正错误标记为 XID 94（HBM）或 XID 48（GPU 内部）。频繁 ECC 错误往往预示 GPU 硬件即将故障。
- **首次出现**：stage3-direction-D-mlops/monitoring-observability.md
- **分类**：方向 D - 算力集群 MLOps

### Einsum / 爱因斯坦求和约定
- **类比**：「bhqd,bhkd->bhqk」一行字就描述了 Multi-Head Attention 的完整计算——比写几十行 transpose + matmul 代码更清晰。
- **专业定义**：Einstein Summation，用字符串下标表达张量运算的符号系统。`torch.einsum()` 按下标字符串自动推导正确的矩阵乘、转置、逐元素乘、求和、广播等操作。是从数学公式到 CUDA kernel 的桥梁——研究阶段用 einsum 清晰表达算法，生产阶段用优化的 CUDA/Triton kernel 实现。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

---

## F

### Fair-Share / 公平调度
- **类比**：食堂打饭，不是谁嗓门大谁先打——每人刷卡记次数，去得少的人优先，保证大家都差不多。
- **专业定义**：Slurm 等 HPC 调度器的经典策略。每个用户/组有 fair-share 权重，调度器跟踪历史资源使用量，使用量低于公平份额的用户获得更高优先级。是多租户 GPU 集群资源隔离的核心机制，防止少数用户霸占集群资源。
- **首次出现**：stage3-direction-D-mlops/slurm-hpc-scheduling.md
- **分类**：方向 D - 算力集群 MLOps

### Fat-Tree / 胖树拓扑
- **类比**：公司组织——底层是基层员工（GPU 节点），中层是部门经理（Leaf 交换机），顶层是总监（Spine 交换机）。越往上带宽越「胖」，保证跨部门沟通不堵。
- **专业定义**：GPU 集群最常用的网络拓扑。Spine（顶层）和 Leaf（底层）形成双层 Clos 网络。收敛比 = 下行带宽/上行带宽。1:1 为无阻塞；3:1 是常见 GPU 集群折中选择；10:1 不适合分布式训练。NCCL 的 Ring All-Reduce 在 Fat-Tree 上表现最优。
- **首次出现**：stage3-direction-D-mlops/multi-tenancy-networking.md
- **分类**：方向 D - 算力集群 MLOps

### FlashAttention / 闪速注意力
- **类比**：计算两个大矩阵的点积，传统方式是写下完整的中间矩阵再读。FlashAttention 的分块法是把大矩阵切成小块，每次拿几块到草稿纸上算完就扔，反复换块直到全部算完。草稿纸（SRAM）比书架（HBM）快 10 倍。
- **专业定义**：Tri Dao 等人提出的 IO-aware 精确注意力算法。通过 tiling 将 Q、K、V 切分到可放进 GPU SRAM 的小块，在 SRAM 内用 Online Softmax 完成计算，避免把 O(N^2) 的注意力矩阵写回 HBM。FlashAttention-2 优化了 warp 调度和工作分配；FlashAttention-3 利用 Hopper 的异步 TMA 和 warp specialization 进一步提升效率。
- **首次出现**：stage3-direction-A-kernel/attention-kernel-optimize.md
- **分类**：方向 A + 方向 B

### FP8 / INT8 / INT4（量化精度）
- **类比**：FP32 是精确到克的天平，FP16 是精确到两的菜市场秤，INT8 是用 0-255 整数粗略估计，INT4 只用 0-15 整数——秤越来越不精确但越来越省地方。
- **专业定义**：不同位宽的数值表示。INT8：-128~127 的 8 位整数；INT4：-8~7 的 4 位整数，大幅压缩但需精细量化策略（GPTQ/AWQ）。FP8（Hopper 架构引入）：E4M3（4 位指数+3 位尾数，精度优先）和 E5M2（5 位指数+2 位尾数，范围优先），推理无需 calibration，直接使用 FP8 Tensor Core 获 2 倍于 FP16 的吞吐。
- **首次出现**：stage3-direction-B-inference/quantization-inference.md
- **分类**：方向 B - 推理引擎

### FSDP (Fully Sharded Data Parallelism) / 全分片数据并行
- **类比**：8 个人合作修一栋大房子——不是每人保存完整设计图纸（太重），而是把图纸切成 8 份各持一份，需要用某份时向持有者借来看，用完归还。
- **专业定义**：PyTorch 官方实现的 ZeRO-3 等效方案。将参数、梯度、优化器状态都在数据并行维度上分片。前向/反向前通过 All-Gather 临时收集所需参数分片，计算完成后释放；梯度同步用 Reduce-Scatter 将分片归约散布。单 GPU 显存需求降至 1/N（N = GPU 数），但每步增加 3 次 All-Gather 通信开销。
- **首次出现**：stage3-direction-C-training/fsdp-torch-distributed.md
- **分类**：方向 C - 分布式训练

---

## G

### GELU (Gaussian Error Linear Unit) / 高斯误差线性单元
- **类比**：一个「根据靠谱程度放行」的门卫——输入很大（很靠谱），几乎全部放行（GELU(x) ≈ x）；中等输入按比例放行；输入为负，只放行一点点（不会完全堵死）。
- **专业定义**：GELU(x) = x * Φ(x)，其中 Φ 是标准正态分布 CDF。相比 ReLU（负半区完全归零→dying ReLU），GELU 在负半区有小幅非零输出和梯度，不会「神经元死亡」。实际用 tanh 近似实现。BERT、GPT-1/2 使用 GELU；现代模型已转向 SiLU/Swish。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### GIL (Global Interpreter Lock) / 全局解释器锁
- **类比**：银行只有一个麦克风（GIL）——虽有 3 个柜员（线程）但同一时刻只有拿麦克风的人能和客户对话。但如果柜员去后台处理文件（C/CUDA 扩展），可以放下麦克风让其他人接客。
- **专业定义**：CPython 解释器的互斥锁，任意时刻只允许一个线程执行 Python 字节码。保护的是 CPython 内部的引用计数和对象数据结构。关键洞察：GIL 不限制 GPU——PyTorch 的 CUDA 操作通过 `Py_BEGIN_ALLOW_THREADS` 释放 GIL，GPU kernel 异步执行期间 Python 线程被释放去处理其他请求。Python 3.13 引入实验性 free-threaded 模式。
- **首次出现**：stage1-cs-basics/python-essentials.md
- **分类**：阶段 1 - 计算机基础

### GPTQ (Post-Training Quantization for GPT) / GPT 后训练量化
- **类比**：压缩照片——不重新拍（不重新训练），用算法逐像素调整使压缩后的图在最重要区域与原图尽可能相似。
- **专业定义**：基于 Optimal Brain Quantization (OBQ) 的逐层权重量化方法。每层按列量化权重矩阵：量化第 i 列后，用闭式解更新未量化列以补偿量化误差。核心工具是权重 Hessian 矩阵的 Cholesky 分解，将补偿计算复杂度从 O(d^4) 降到 O(d^3)。可在一小时内完成 175B 模型 INT4 量化，精度损失极小。
- **首次出现**：stage3-direction-B-inference/quantization-inference.md
- **分类**：方向 B - 推理引擎

### GQA (Grouped Query Attention) / 分组查询注意力
- **类比**：32 个学生（Query heads）各提不同问题，传统需 32 个助教（KV heads）一一回答。GQA 让 8 个助教每人回答 4 个学生——省了 3/4 人力而答案质量差异很小。
- **专业定义**：Multi-Head Attention 的改进。Query 头数不变，但 K 和 V 头数减少（如 32 Q-heads + 8 KV-heads），每 4 个 Q 头共享一对 K/V 头。KV Cache 缩减为原来的 num_kv_heads/num_heads（如 1/4）。Llama 2 70B 使用 64 Q-heads + 8 KV-heads（8x 缩减）。实验表明在大规模模型上质量损失可忽略，是推理效率和质量的最优平衡。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

### Gradient Accumulation / 梯度累积
- **类比**：一道菜需要 8 个鸡蛋但你一次只能煎 2 个——煎 4 轮，每轮煎完攒碗里，4 轮后一次性全倒进菜里。
- **专业定义**：显存受限时模拟大 batch size 的技巧。对多个 micro-batch 分别做前向+反向，梯度不立即更新而累积起来；累积够 N 步后用总梯度做一次参数更新。有效 batch size = micro_batch_size * accumulation_steps。注意：BN 在每个 micro-batch 上独立算统计量——现代 LLM 用 LayerNorm/RMSNorm 避开了这个问题。
- **首次出现**：stage3-direction-C-training/distributed-training-basics.md
- **分类**：方向 C - 分布式训练

### Gradient Checkpointing / 梯度检查点
- **类比**：长途旅行不是全程录像（存储所有中间激活），每隔 100 公里拍一张照（检查点）。迷路时（反向需要中间激活）从最近检查点重新开过去——多花了时间，省了录像带（显存）。
- **专业定义**：用计算换显存的训练优化。只存储少数「检查点」位置的激活值，反向传播需要非检查点位置的激活时从最近检查点重新前向计算。可将激活显存从 O(num_layers) 降到 O(sqrt(num_layers))，代价约 33% 额外前向计算量。在大模型训练中几乎是必须启用的技术。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 + 方向 C

### Gradient Descent / 梯度下降
- **类比**：天黑后你站在山上想下山——看不见全景，只能感知脚下哪里最陡。每次朝最陡的方向走一小步（步长=学习率），反复多次，最终到达山底。
- **专业定义**：深度学习最基础的优化算法。θ_{t+1} = θ_t - η * ∇L(θ_t)，η 是学习率，∇L 是损失函数对参数的梯度。变体包括：SGD with Momentum（增加惯性项）、Adam（自适应学习率+动量）、AdamW（解耦 weight decay）。理解梯度下降是理解训练的根本。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### GPU Direct RDMA (GDR) / GPU 直连远程内存访问
- **类比**：两家公司交换文件——老方法是打印→快递→扫描回电脑。GDR 是 A 的电脑直接传输到 B 的电脑，跳过所有中间步骤。
- **专业定义**：允许网卡直读直写 GPU 显存而不经过 CPU 内存。数据路径：发送方 GPU → PCIe → NIC → 网络 → 对端 NIC → PCIe → 接收方 GPU，共 0 次 CPU 内存拷贝。需 GPU 和 NIC 在同一 PCIe 根复合体下，配合 NCCL 的 `NCCL_NET_GDR_LEVEL=5` 启用。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：方向 D - 算力集群 MLOps

### GPU Operator (NVIDIA)
- **类比**：一键部署的智能家居系统——以前手动装设备、配对、配置 IP、调网络，现在一个 App 完成全部安装和自动配置。
- **专业定义**：NVIDIA 为 Kubernetes 提供的 GPU 管理 Operator。自动完成 GPU 驱动安装、nvidia-container-toolkit 部署、DCGM 监控导出、GPU Feature Discovery、MIG 配置管理、时间切片配置等。使用 Kubernetes Operator 模式（CRD + Controller）自动化 GPU 节点全生命周期管理。
- **首次出现**：stage3-direction-D-mlops/k8s-gpu-orchestration.md
- **分类**：方向 D - 算力集群 MLOps

---

## H

### HBM (High Bandwidth Memory) / 高带宽显存
- **类比**：CPU 内存是普通公路（DDR5），GPU 的 HBM 是 16 车道高速公路——通过硅中介层 3D 堆叠，数据跑在路上比普通公路快 20 倍。
- **专业定义**：GPU 主显存技术。采用 3D 堆叠 + 硅中介层垂直连接多个 DRAM die，实现超宽总线（1024-bit 以上）。A100：80GB HBM2e / 2 TB/s；H100：80GB HBM3 / 3.35 TB/s；H200：141GB HBM3e / 4.8 TB/s。HBM 带宽决定了 LLM 推理 decode 阶段的天花板——decode 是 memory-bound 的，性能直接受限于权重从 HBM 加载到 SM 的速率。
- **首次出现**：stage2-ai-infra-foundations/cuda-programming.md
- **分类**：阶段 2 - AI Infra 底层技术

### Hipify / HIP 化（CUDA 到 AMD/DCU 移植）
- **类比**：把一本中文小说的人名替换成英文——语法结构（kernel 逻辑）不变，只是关键词翻译了。`cudaMalloc → hipMalloc`。
- **专业定义**：AMD 的 CUDA 到 HIP 自动转换工具。`hipify-perl` 做基本字符串替换；`hipify-clang` 基于 Clang AST 做语法级精准转换。HIP 代码可在 AMD GPU（ROCm）上原生编译，也可反向兼容 NVIDIA GPU。是国产 DCU 支持 PyTorch/vLLM 等框架的主要技术路线。
- **首次出现**：stage3-direction-A-kernel/dcu-hip-kernel.md
- **分类**：方向 A - Kernel 开发

### HPA (Horizontal Pod Autoscaler) / 水平 Pod 自动扩缩容
- **类比**：商场根据客流量自动增减收银台——人多了加开柜台，人少了关几个省电，保持每个柜台排队人数在合理范围。
- **专业定义**：Kubernetes 自动扩缩容机制。根据 CPU/内存使用率或自定义指标（如请求队列深度、GPU 利用率、推理 QPS）自动调整 Pod 副本数。LLM 推理服务常用 KEDA 配合自定义指标实现更灵活的弹性扩缩。
- **首次出现**：stage3-direction-D-mlops/k8s-gpu-orchestration.md
- **分类**：方向 D - 算力集群 MLOps

### Huge Pages / 大页
- **类比**：搬家时用大号纸箱（2MB）而不是小塑料袋（4KB）装书——箱子总数急剧减少，找某一本书（TLB 查地址）需要翻的箱子清单（页表）就短得多。
- **专业定义**：超过 4KB 标准大小的内存页。x86-64 支持 2MB 大页和 1GB 巨页。LLM 推理工作集（模型权重+KV Cache）动辄数百 GB，L2 TLB 用 4KB 页最多覆盖 6MB（覆盖不足 0.004%）。2MB 大页扩展至 3GB（提升 500 倍），1GB 巨页可达 1.5TB（几乎完全覆盖）。可通过 THP（透明大页）或显式预留 hugepages 配置。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

---

## I

### InfiniBand
- **类比**：普通以太网是普通快递，InfiniBand 是闪送专属通道——专业调度员、专用车辆、门到门免中转、超低延迟。
- **专业定义**：HPC 和 AI 集群专用的网络互连技术。与以太网「尽力而为」不同，InfiniBand 内置 RDMA 支持、无损传输（基于信用流控）、端到端延迟 ~1-2 微秒。NDR400 提供 400 Gb/s（50 GB/s）单向带宽。成本高但性能极致，是训练多节点大模型的标准选择。NCCL 在 IB 上可充分发挥拓扑感知的优势。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：方向 D - 算力集群 MLOps

---

## K

### KEDA (Kubernetes Event-Driven Autoscaling) / 事件驱动扩缩容
- **类比**：店门口的计数器——不是定期去看人多人少，而是每当排队超过 10 人就直接触发加开窗口。
- **专业定义**：Kubernetes 轻量级事件驱动扩缩容组件（补充 HPA）。支持从 Prometheus 指标、Kafka 队列深度、Redis 列表长度等事件源触发扩缩。对于 LLM 推理服务，可用请求队列深度、GPU 利用率、显存使用率等驱动 ScaledObject，实现从 0→1（冷启动）和 1→N（弹性扩容）的自动扩缩。
- **首次出现**：stage3-direction-D-mlops/k8s-gpu-orchestration.md
- **分类**：方向 D - 算力集群 MLOps

### Kernel Fusion / Kernel 融合
- **类比**：做三明治——分别做是「取面包→涂黄油→放回→取生菜→放回→取火腿→放回」，融合后是直接全部拿过来一次完成，省了中间三趟「取放」。
- **专业定义**：将多个独立 GPU kernel 合并为一个的优化技术。未融合时每个 kernel 的输出先写回 HBM、下一个 kernel 再从 HBM 读取——HBM 带宽是瓶颈。融合后中间结果保留在寄存器或共享内存中，消除多次 HBM 读写。典型融合：RMSNorm + Residual Add、Linear + GELU/SiLU、QKV 三个投影合并为一个 GEMM。FlashAttention 本质上是将整个 attention 的多个步骤融合为少数 IO-aware kernel 的极致应用。
- **首次出现**：stage3-direction-A-kernel/cutlass-triton-kernel.md
- **分类**：方向 A - Kernel 开发

### KV Cache / 键值缓存
- **类比**：逐字朗读文章做笔记——每读一个字把它的「关键词」（K）和「内容摘要」（V）记便签上。读下一个字时翻看已有的便签即可，不需要每次重新读整篇文章。
- **专业定义**：自回归 Transformer 推理的核心优化。历史 token 的 K 和 V 不会改变，缓存起来避免重复计算。KV Cache 大小 = 2 * num_layers * num_kv_heads * head_dim * total_seq_len * dtype_bytes。长序列（128K+）KV Cache 是推理显存的主要消费者，直接催生了 GQA、MQA、MLA、KV Cache 量化等技术。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

### KV Cache Quantization / KV Cache 量化
- **类比**：家里的老相册——全分辨率存储太占地方，把老照片压缩到低分辨率（FP8/INT8），用时临时放大即可。
- **专业定义**：对缓存的 K 和 V 进行低位宽压缩。FP8 KV Cache（H100/Ada 支持）将存储量减半；INT8 KV Cache 需 per-channel（Key）或 per-token（Value）缩放。更激进的 KV4/KV2 方案进一步压缩但精度挑战更大。难点在于 K 和 V 存在 outlier channels/channels 分布不均。
- **首次出现**：stage3-direction-B-inference/kv-cache-optimization.md
- **分类**：方向 B - 推理引擎

---

## L

### Layer Normalization (LayerNorm) / 层归一化
- **类比**：考试前把所有同学的分数统一到「平均 0 分、标准差 1 分」——纵向看自己各科是否平衡，而非横向比同学（那是 BatchNorm）。
- **专业定义**：在 feature 维度上对每个 token 的激活值归一化：y = γ*(x-μ)/√(σ²+ε) + β。μ、σ² 沿 hidden_dim 计算，γ、β 可学习。相比 BatchNorm，不依赖 batch size，序列长度独立，训练和推理行为一致。在 Transformer 中是标配，对训练稳定性至关重要。现代模型多用 RMSNorm（省去减均值）。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### LDS (Local Data Share) / 本地数据共享
- **类比**：AMD GPU 版本的共享内存（SMEM）——功能和 NVIDIA SMEM 一模一样，只是名字不同。如同「电梯」和「升降机」。
- **专业定义**：AMD GPU（含 DCU）中对应 NVIDIA 共享内存的片上存储单元。位于每个 Compute Unit 内部，通常 64KB，有 32 个 bank。HIP kernel 中用 `__shared__` 声明，与 CUDA 语法完全一致。64 个 线程/线程束 的 wavefront 比 NVIDIA warp 大，bank conflict 概率更高。
- **首次出现**：stage3-direction-A-kernel/dcu-hip-kernel.md
- **分类**：方向 A - Kernel 开发

### Loss Scaling / 损失缩放
- **类比**：用显微镜看极小的物体——把物体放大 1000 倍（loss * scale），看清后再把测量数据缩小 1000 倍（grad / scale），否则因太小而看不清（梯度下溢）。
- **专业定义**：FP16 混合精度训练中防止梯度下溢的技术。FP16 最小正归一化数约 6e-8，小梯度可能下溢为零。Loss Scaling 将 loss 乘大因子（如 1024），反向传播中梯度也被放大，更新前除以 scale 恢复。动态 Loss Scaling 自动调整 scale 值。BF16 因指数范围同 FP32（8 位指数），无需 Loss Scaling。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：方向 C - 分布式训练

---

## M

### Marlin Kernel
- **类比**：高速公路的 ETC 专用通道——专门针对 INT4 权重的矩阵乘法，比人工通道（普通 GEMM）快 2-4 倍。
- **专业定义**：IST-DASLab 开发的专门优化 INT4 权重 * FP16 激活矩阵乘法的 CUDA kernel。核心优化包括：定点乘加计算的极致排列最大化 Tensor Core 利用率、针对 A100/H100 微架构的汇编级调优、最小化寄存器压力实现高 occupancy。batch size ≤ 32 的推理场景下相比标准 INT4 GEMM 实现 2-4 倍加速。vLLM 和 aphrodite-engine 已集成。
- **首次出现**：stage3-direction-B-inference/quantization-inference.md
- **分类**：方向 B - 推理引擎

### Megatron-LM
- **类比**：大型建筑工地的总指挥系统——不只是安排一个施工队，而是同时协调 1000 个施工队（GPU）在建筑不同部分（模型不同层/头）同时施工，每个工人完工后立即把结果同步给相关队伍。
- **专业定义**：NVIDIA 开源分布式训练框架。核心贡献：系统化了 TP + PP + DP 的 3D 组合策略（PTD-P）。TP 在节点内 NVLink 上做高频 All-Reduce，PP 在节点间做 P2P 传递，DP 跨最慢互联做梯度同步。定义了 Column/Row Parallel Linear、Sequence Parallelism 等核心组件。是训练 175B+ 参数模型的事实标准框架。
- **首次出现**：stage3-direction-C-training/megatron-lm-deep-dive.md
- **分类**：方向 C - 分布式训练

### Micro-Batch / 微批次
- **类比**：一大卡车货物（global batch）太重一次卸不完，拆成几小车（micro-batch）分多次卸。每次卸一小车货，累积够了再统一入仓。
- **专业定义**：分布式训练中 global batch size 拆分为更小的 micro-batch，GPU 一次只处理一个。微批次大小受限于单 GPU 显存。在 PP 中多个 micro-batch 可形成流水线减少 bubble；在 DP + 梯度累积中，每个 micro-batch 梯度不立即 All-Reduce，累积完一次性同步和更新。
- **首次出现**：stage3-direction-C-training/pipeline-parallelism.md
- **分类**：方向 C - 分布式训练

### MIG (Multi-Instance GPU) / 多实例 GPU
- **类比**：大别墅用隔断墙分成几个独立小公寓——每家有自己的门、水电表、厨房，互不干扰。
- **专业定义**：NVIDIA A100/A30 支持的单 GPU 硬件分区技术。将物理 GPU 划分最多 7 个独立实例，每实例有独立 SM、显存、L2 Cache、内存带宽的硬件保证分配。每实例在软件层面是独立 CUDA 设备，故障和性能完全隔离。H100 取消 MIG 改用基于 Hopper 的多租户改进 + MPS。
- **首次出现**：stage3-direction-D-mlops/multi-tenancy-networking.md
- **分类**：方向 D - 算力集群 MLOps

### Mixed Precision Training / 混合精度训练
- **类比**：两种秤配合——大宗货物用磅秤（FP16，快但低精度），找零用电子秤（FP32，慢但精确），又快又准。
- **专业定义**：同时使用 FP16/BF16（计算和多数存储）和 FP32（关键操作存储和累积）的训练技术。前向/反向主要在下精度执行获 2 倍吞吐提升；模型权重保留 FP32 master copy，梯度累积和参数更新也在 FP32 保证精度。BF16 无需 Loss Scaling（指数范围同 FP32），比 FP16 更受欢迎。PyTorch `autocast` 提供自动化支持。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：方向 C - 分布式训练

### MLA (Multi-head Latent Attention) / 多头潜在注意力
- **类比**：传统 Attention 是把整个房间的情况都记下来（存储完整 K、V），MLA 是拿速写本画简笔画（压缩到低维潜在空间），回看时根据简笔画脑补细节——存储量从百科全书缩成几页便利贴。
- **专业定义**：DeepSeek-V2/V3 提出的核心注意力创新。通过低秩压缩将 K 和 V 映射到远小于 head_dim 的潜在维度 d_c（如 512 vs 128），再通过升维矩阵恢复到原始 K 和 V 用于计算。KV Cache 只存压缩后的 c_KV + 解耦 RoPE 部分。DeepSeek-V2 实现了约 57x 的 KV Cache 节省（32768 维→576 维）。但 MLA 需推理引擎做特殊适配，标准 FlashAttention 无法直接支持。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 + 方向 B

### mmap (Memory-Mapped I/O) / 内存映射
- **类比**：不把整本词典复印到桌上（读入内存），而是在桌上放一面镜子——需要查哪个词时镜子自动折射出那页内容。词典还在书架上，你看到的是「镜中像」。
- **专业定义**：Unix 系统调用，将文件映射到进程虚拟地址空间实现按需加载。首次访问触发 major page fault、OS 从磁盘读取到 Page Cache 并映射；后续访问走 Page Cache 命中路径。safetensors 利用 mmap 实现零拷贝模型加载——数据从 Page Cache 直接映射到用户空间，无需内核到用户态拷贝。MAP_SHARED 使多进程共享同一物理内存（vLLM 多 worker 权重共享）。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

### Move Semantics (C++) / 移动语义
- **类比**：搬家时把家具所有权单（指针）直接转给新主人，而非重新打造一套一模一样的家具（深拷贝）。家具本身没动，只是主人换了。
- **专业定义**：C++11 引入的资源所有权转移机制。通过右值引用（T&&）和移动构造/移动赋值，将资源所有权从一个对象转移到另一个对象，避免昂贵的深拷贝。vLLM 中 Tensor 的移动语义使推理结果在引擎各层间零拷贝传递——`std::move(tensor_a)` 后只有内部指针被转移，GPU 显存数据没有移动。
- **首次出现**：stage1-cs-basics/cpp-for-source-reading.md
- **分类**：阶段 1 - 计算机基础

### MPS (Multi-Process Service) / 多进程服务
- **类比**：银行大厅统一排号系统——多窗口从同一号池取客户，而非各窗口自己排队（有的排长龙有的空着）。
- **专业定义**：NVIDIA GPU 多进程共享技术。多个 CUDA 进程通过 MPS Server 共享同一 GPU 的 SM 资源，统一调度各进程 kernel 到不同 SM 并行执行（空间共享），而非传统时间片轮转。消除进程间 context 切换开销（传统多进程需 ~10-100ms）。自 Volta 起可用，H100 上 MPS 硬件支持进一步增强。
- **首次出现**：stage3-direction-D-mlops/multi-tenancy-networking.md
- **分类**：方向 D - 算力集群 MLOps

### MQA (Multi-Query Attention) / 多查询注意力
- **类比**：GQA 是几个学生拼一个助教，MQA 是全班所有学生（Query heads）共用唯一一个助教（KV head）——最省人力，但助教可能忙不过来。
- **专业定义**：GQA 的特例，所有 Q 头共享唯一的 K、V 头（num_kv_heads=1）。KV Cache 节省倍数 = num_heads，是最极端的压缩方案。使用 MQA 的模型包括 PaLM、Gemini 1.0、Falcon。训练时需特殊初始化策略（从训练好的 MHA 将多 K/V 头取均值初始化共享 K/V）来缓解质量损失。业界趋势是 GQA 作为更平衡的选择。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

### Mutex / 互斥锁
- **类比**：公共厕所门锁——进去的人锁上（lock），外面排队等；出来开锁（unlock），下一个才进。同一时刻只有一个人在用。
- **专业定义**：线程同步的最基本原语。C++ 中 `std::mutex` + `std::lock_guard`（RAII 自动加解锁）保护临界区。vLLM 的 Block Manager 用 mutex 保护 free_blocks 队列和 block_tables 哈希表的并发访问。`std::scoped_lock`（C++17）可同时锁多个 mutex 自动防死锁。GPU kernel 内部不用 mutex（代价太高），用 atomic 做轻量级同步。
- **首次出现**：stage1-cs-basics/cpp-for-source-reading.md
- **分类**：阶段 1 - 计算机基础

---

## N

### NCCL (NVIDIA Collective Communications Library) / NVIDIA 集合通信库
- **类比**：8 个人围成一圈传文章让每人修改并最终所有人都拥有最终版本——NCCL 是专业传话员团队，自动找到最快路径和最有效率的传递方式。
- **专业定义**：NVIDIA 官方多 GPU 集合通信库，提供 All-Reduce、All-Gather、Reduce-Scatter、Broadcast、All-to-All 等通信原语的高度优化实现。自动检测 GPU 拓扑（NVLink、PCIe、IB/RoCE），选择最优通信算法（Ring vs Tree vs CollNet）和路径。支持 GPU Direct RDMA 实现跨节点零拷贝通信。是分布式训练和推理中所有 TP/PP/DP 通信的底层基础。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：方向 C + 方向 D

### NUMA (Non-Uniform Memory Access) / 非统一内存访问
- **类比**：公司的两个办公区——A 区的人去 A 区打印机几步就到，去 B 区打印机需要穿过整个厂区。能就近用就别跨区。
- **专业定义**：多插槽服务器的内存架构。每个 CPU Socket 有本地内存控制器和 DRAM——访问本地内存 ~100ns，跨 Socket ~180ns（约 1.8 倍）。A800 8-GPU 服务器中 GPU 0-3 连接 CPU 0（NUMA Node 0），GPU 4-7 连接 CPU 1。推理需用 `numactl --membind` 绑定 CPU 线程和内存到对应 NUMA 节点，避免跨 NUMA 降低 10-30% 吞吐。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

### NVLink / NVSwitch
- **类比**：普通 PCIe 是城市普通道路（双向双车道 ~64GB/s），NVLink 是 GPU 间专属高速公路（双向 18 车道 ~900GB/s），NVSwitch 是高速枢纽立交桥——任意两个入口都能全速互通。
- **专业定义**：NVLink 是 NVIDIA GPU 间直连高速互连。NVLink 4.0（H100）：每条链路 50 GB/s 单向、18 条链路共 900 GB/s 双向。NVSwitch 将节点内所有 GPU 全互联——8-GPU DGX 中 4 个 NVSwitch 芯片确保任意 GPU 对全速通信。NVSwitch 还是 CollNet（单步 All-Reduce）的硬件基础——所有 GPU 同时向 Switch 发送数据，Switch 硬件完成归约后广播回所有 GPU。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：方向 D - 算力集群 MLOps

---

## O

### Occupancy (GPU) / 占用率
- **类比**：工厂 100 个工人塞进 80 个工位的装配线——实际可用 = min(100, 80) = 80。多出的 20 人在大厅等着（寄存器/共享内存不够用），实际干活的人还少了。
- **专业定义**：每个 SM 上活跃 warp 数与理论最大 warp 数的比值。受限于三个资源的任意一个：每线程寄存器数、每线程块共享内存量、每 SM 最大线程块数。高 occupancy 可隐藏内存延迟（当一个 warp 等数据时另一个可执行），但过高不一定最优——寄存器使用太多反而降低 occupancy，需权衡。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Online Softmax / 在线 Softmax
- **类比**：评委给选手打分排名——不用等全部评委打完分才统计，每收到新分就实时更新当前最高分、调整已有的排名。最终结果和等全部分数到位再算完全一致。
- **专业定义**：流式计算 softmax 的算法，不需存储完整输入。维护三个 running 量：当前最大值 m、指数和 l、部分输出。每处理一个元素，用新旧最大值差值调整已有部分和。FlashAttention 的核心就是利用 Online Softmax 将 softmax 分块化——每个 tile 在 SRAM 内完成局部 softmax，跨 tile 用 rescaling 合并，避免把完整注意力矩阵写回 HBM。
- **首次出现**：stage3-direction-A-kernel/attention-kernel-optimize.md
- **分类**：方向 A + 方向 B

---

## P

### Page Fault / 缺页异常
- **类比**：去图书馆查书发现不在架上（缺页）。轻微缺页（minor）：书就在仓库，管理员迅速取来（~1-10 微秒）。严重缺页（major）：书被借到外馆了，需从另一城市调来（~1-10 毫秒）。你只能干等。
- **专业定义**：CPU 访问虚拟地址时页表 Present 位为 0 触发的异常。Minor Page Fault：页面已在物理内存但未映射到当前进程（如 malloc 惰性分配），OS 仅更新页表。Major Page Fault：页面在磁盘（swap 或 mmap 未加载），OS 需 I/O 读取。vLLM 中 mmap 模型加载本质是「可控的 Major Page Fault」——首次访问某段权重才触发文件读取。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

### PagedAttention / 分页注意力
- **类比**：餐厅把 KV Cache 管理得像个「对号入座」系统——客人来了不包场，分配一张张独立小桌子（block）。几个客人可拼桌，先来的客人用过的桌子后来的可以接着用（Prefix Caching）。这和操作系统管理内存完全一样——应用看到的「连续地址」背后是分散的物理页。
- **专业定义**：vLLM 提出的 KV Cache 管理算法，灵感来源于 OS 虚拟内存管理。将 KV Cache 切分为固定大小块（通常 16 tokens），每序列维护 Block Table（逻辑块→物理块映射），实现非连续分配。核心优势：(1) 消除碎片——按需分配不预分配；(2) Prefix Caching——多请求共享相同前缀块（引用计数>1）；(3) 灵活抢占——换出（Swap）或释放重算（Recompute）。是 vLLM 吞吐量远超传统框架的根本原因。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 + 方向 B（跨阶段核心概念）

### Per-Channel vs Per-Token Quantization / 逐通道 vs 逐 Token 量化
- **类比**：Per-Channel 是给每个颜色通道（R/G/B）配不同精度调色盘——红色容易配准用粗略刻度，蓝色容易偏差用精细刻度。Per-Token 是给每句话配不同精度翻译器——专业术语多的句子用更多词汇量。
- **专业定义**：两种量化粒度。Per-Channel：权重矩阵每列有独立 scale 和 zero-point，适合处理不同输出通道的激活值分布差异（outlier channels）。Per-Token：每个 token 的激活向量有独立 scale，适合处理不同 token 的激活值范围差异。W8A8 推理通常用 per-channel 量化权重 + per-token 量化激活的组合（动态量化）。
- **首次出现**：stage3-direction-B-inference/quantization-inference.md
- **分类**：方向 B - 推理引擎

### Persistent Kernel / 持久化 Kernel
- **类比**：普通 kernel 是「送快递」——启动一次送一单，送完快递员消失。Persistent kernel 是「固定外卖档口」——快递员一直待命，不断处理涌入的单子，不需要每次重新叫快递员。
- **专业定义**：GPU kernel 设计模式。每个线程块启动后持续运行，用 while 循环不断从全局工作队列取新任务，队列为空才退出。消除多次 kernel launch 的 CPU 端调度开销。常用于 producer-consumer 模式、device-side 任务调度、替代 CUDA Graph 方案等。
- **首次出现**：stage3-direction-A-kernel/cuda-kernel-deep-dive.md
- **分类**：方向 A - Kernel 开发

### Preemption (Swap/Recompute) / 抢占（换出/重算）
- **类比**：超市收银台不够用——让排队超 5 分钟的人先站旁边（Swap，换出到 CPU 内存），有空档再叫回来接着排；或让他们回队尾重新排（Recompute，释放显存但需重新处理 prompt）。
- **专业定义**：GPU 显存不足时回收 KV Cache 块以释放空间的策略。Swap：将不活跃序列的 KV Cache 块拷贝到 CPU 内存，之后拷贝回 GPU（适合已生成到一半的序列）。Recompute：直接释放块，之后重新跑模型前向重建 KV Cache（适合短 prompt、重算开销可接受的序列）。vLLM 支持两种策略混合使用，自动选择最优方式。
- **首次出现**：stage3-direction-B-inference/scheduling-strategies.md
- **分类**：方向 B - 推理引擎

### Prefill / 预填充（推理阶段）
- **类比**：考试前先通读整张试卷（prefill）理解所有题目，然后逐题作答（decode）。通读只需一次，之后每做一题只需回顾题目而非重读整张卷子。
- **专业定义**：自回归推理第一阶段。将整个 prompt 序列一次性输入模型，并行计算所有 token 的 hidden states，生成所有位置的 K 和 V 存入 KV Cache。Prefill 是 compute-bound（大矩阵乘法占主导，Tensor Core 利用率高），延迟受序列长度显著影响。TTFT（首 Token 延迟）主要由 prefill 时间决定。
- **首次出现**：stage3-direction-B-inference/continuous-batching.md
- **分类**：方向 B - 推理引擎

### Prefix Caching / 前缀缓存
- **类比**：快餐店套餐——「汉堡+薯条+可乐」是很多人的共同开头，厨房提前做好套餐前半部分放保温区。来一个客人直接拿已做好的套餐部分，只做每人不同的后半部分（要不要加辣）。
- **专业定义**：PagedAttention 的共享 KV Cache 机制。多请求共享相同 prompt 前缀时（如 system prompt、RAG 中相同检索上下文），共享物理 KV Cache 块被多序列 Block Table 引用（引用计数>1）。新请求若前缀命中缓存则跳过 prefill 直接进入 decode。在聊天应用和 RAG 场景中可节省大量 prefill 计算和显存。vLLM v1 通过 Radix Tree 实现自动前缀缓存。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：方向 B - 推理引擎

### PTX / 并行线程执行（中间汇编）
- **类比**：CUDA C++ 是普通食谱（「打鸡蛋到碗里搅拌」），PTX 是操作指令（「取 3 号碗、打破鸡蛋、搅拌 30 次」），SASS 是机器内部信号（「手臂第 3 关节转 45 度」）——越底层越接近硬件。
- **专业定义**：NVIDIA GPU 的中间汇编语言（IR），CUDA C++ 编译后的中间产物。PTX 是虚拟 ISA——不同 GPU 架构编译出不同 SASS（实际二进制），但 PTX 跨架构兼容。阅读 PTX 可理解编译器做了哪些优化。理解 PTX 是手写高性能 CUDA kernel 的前提（inline PTX 使用如 `mma.sync` 等高级指令）。
- **首次出现**：stage3-direction-A-kernel/cuda-kernel-deep-dive.md
- **分类**：方向 A - Kernel 开发

### Pybind11
- **类比**：中英文同声传译——C++（中文母语者）和 Python（英文母语者）在会议室两端各自说话，同传译员实时翻译，让双方无缝对话且不损失信息（零拷贝）。
- **专业定义**：轻量级 header-only C++ 库，用于 Python 和 C++ 之间创建绑定。通过 `PYBIND11_MODULE` 宏和 `py::class_`、`m.def()` 将 C++ 类和函数暴露给 Python。支持 `py::gil_scoped_release` 在 C++ 执行期间释放 GIL。PyTorch Tensor 和 Python Tensor 之间通过 pybind11 实现自动零拷贝转换。vLLM 所有 CUDA kernel 通过 pybind11 暴露给 Python 层。
- **首次出现**：stage1-cs-basics/cpp-for-source-reading.md
- **分类**：阶段 1 - 计算机基础

---

## Q

### QoS (Quality of Service) / 服务质量
- **类比**：高速公路应急车道——普通车不许走，但救护车（高优先级推理请求）拥有专用通行权，不被堵车影响。
- **专业定义**：GPU 集群中根据优先级对计算和网络资源进行分级保证的机制。Kubernetes 中通过 Resource Quota 和 PriorityClass 实现；Slurm 中通过 QoS 定义（Priority、MaxJobs、GrpTRES 等）实现；InfiniBand 通过 Service Level（SL）和 DCB 实现网络 QoS。生产流量优先、实时交互优先于批量推理是常见需求。
- **首次出现**：stage3-direction-D-mlops/slurm-hpc-scheduling.md
- **分类**：方向 D - 算力集群 MLOps

---

## R

### RadixAttention / 基数树注意力
- **类比**：自动分类的智能书架——相同开头自动合并到同一格。有人来查「You are a helpful assistant...」时，不管后面接什么问题，书架自动定位到已存好的公共开头那一格。
- **专业定义**：SGLang 中基于 Radix Tree（基数树/前缀树）的 KV Cache 共享机制。所有请求的 token 序列组织成 Radix Tree——根到叶路径表示 token 序列，共享前缀自动合并为一个节点。新请求到达时沿树找到最长公共前缀，直接复用对应 KV Cache 节点。相比 vLLM 的哈希基 Prefix Caching，RadixAttention 能自动发现任意长度的共享前缀。
- **首次出现**：stage3-direction-B-inference/scheduling-strategies.md
- **分类**：方向 B - 推理引擎

### RAII (Resource Acquisition Is Initialization) / 资源获取即初始化
- **类比**：进房间自动开灯（构造=获取资源），出房间自动关灯（析构=释放资源）。不需要记得关灯——只要你离开房间，灯就自动关了。
- **专业定义**：C++ 核心资源管理惯用法。资源生命周期绑定到对象生命周期：构造函数获取资源（new、cudaMalloc、fopen、lock mutex），析构函数释放资源。提供异常安全——即使抛异常导致栈展开，析构函数也会被调用。vLLM 中 CudaBuffer 用 RAII 管理 GPU 显存；`std::lock_guard` 和 `std::unique_ptr` 也是 RAII 的经典应用。
- **首次出现**：stage1-cs-basics/cpp-for-source-reading.md
- **分类**：阶段 1 - 计算机基础

### RDMA (Remote Direct Memory Access) / 远程直接内存访问
- **类比**：普通网络传文件是：秘书（CPU）→ 复印文件 → 送到快递站（内核网络栈）→ 快递发出。RDMA 是你的文件柜（内存）直接对接对方的文件柜——网卡直接读写双方文件柜，不等秘书和快递站。
- **专业定义**：允许一台计算机直接访问另一台计算机内存的网络技术，绕过 OS 内核和 CPU。需要 RDMA 网卡（RNIC）和注册的 Memory Region（MR，锁定物理页）。延迟 ~1-2 微秒（vs 传统 TCP ~50 微秒）。InfiniBand 原生支持 RDMA；RoCE v2 在以太网上实现，需 PFC+ECN 保证无损传输。核心抽象：QP（通信端点）、CQ（完成通知）。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：方向 D - 算力集群 MLOps

### Reduce-Scatter / 归约散布（通信原语）
- **类比**：8 个人各有一组不同数字——先按列求和（归约），再把和切分 8 份每人拿一份（散布）——每人拿到的不是全部结果，而是一个分片。
- **专业定义**：集合通信操作，对每个 GPU 数据进行规约（如求和），然后将结果分散到各 GPU——每 GPU 得最终结果的 1/N 分片。通信量 = (N-1)/N * D。在 FSDP/Zeo-3 梯度同步中用于将梯度归约并分散存储到各 GPU，大幅减少单 GPU 梯度显存占用。NCCL 实现实际上是 All-Reduce 去掉最后一步 All-Gather 的优化版。
- **首次出现**：stage3-direction-C-training/distributed-training-basics.md
- **分类**：方向 C - 分布式训练

### Reference Counting / 引用计数
- **类比**：共享单车的使用记录——每借一次 +1，每还一次 -1。计数归零说明没人用了，车可被回收。但如果 A 借了 B 的车锁、B 又借了 A 的车锁（循环引用），计数永远不归零，车永远在路上丢不了。
- **专业定义**：内存管理策略。每个对象维护引用计数器：新引用时 +1，引用失效时 -1，归零时立即释放。CPython 用它做主要回收（确定性、即时），配合分代 GC 解决循环引用。PyTorch Tensor 不参与 Python GC——底层数据由 C++ `c10::TensorImpl` 通过 `intrusive_ptr` 引用计数管理，确保 GPU 显存确定性释放。PagedAttention 的块引用计数是同一概念在 GPU 显存管理中的应用。
- **首次出现**：stage1-cs-basics/python-essentials.md
- **分类**：阶段 1 - 计算机基础

### Residual Connection / 残差连接
- **类比**：高速公路的「辅道」——正常走是 x → 各种变换 → F(x)，但旁边有一条直接通到出口的辅道（恒等映射 x）。如果主路堵了（梯度消失），你可走辅道直接过去，极大地缓解了交通堵塞。
- **专业定义**：y = x + F(x) 形式的网络设计。残差连接使梯度在反向传播时有直通路径（∂L/∂x 包含来自残差分支的恒等项），极大缓解深层网络梯度消失问题，是训练 100+ 层网络的关键技术。现代 Transformer 用 Pre-LN 风格：y = x + F(LayerNorm(x))——先归一化再做子层再加残差。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

### RMSNorm (Root Mean Square Layer Normalization) / 均方根归一化
- **类比**：LayerNorm 是给学生成绩做标准化——减平均分再除标准差。RMSNorm 是只除标准差不减平均分——省了「减平均分」一步，快了约 10-15%，而实验证明不减平均分对最终成绩几无影响。
- **专业定义**：y = γ * x / RMS(x)，其中 RMS(x) = sqrt(mean(x^2) + ε)。与 LayerNorm 相比只做一次 reduction（算 RMS），而非两次（均值+方差），GPU 上 reduction 是跨线程同步点，能省就省。Llama、Mistral、Qwen、DeepSeek 等几乎所有现代开源 LLM 都使用 RMSNorm。在推理优化中常和残差加法融合为单一 kernel。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### RoCE (RDMA over Converged Ethernet) / 融合以太网 RDMA
- **类比**：在普通马路上（标准以太网）画出公交专用道（RoCE）——公交车可像在高速公路上一样快速行驶，前提是普通车不占用公交车道，否则速度优势就没了。
- **专业定义**：RDMA 技术在标准以太网上的实现。RoCE v2 将 RDMA 封装在 UDP/IP 包中。关键前提：需 PFC（优先级流控）防丢包和 ECN（显式拥塞通知）做拥塞控制——配置不当会导致 PFC 死锁或拥塞扩散。典型延迟 ~5 微秒（vs IB ~1-2 微秒但便宜），是大多非顶尖 GPU 集群的选择。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：方向 D - 算力集群 MLOps

### ROCm (Radeon Open Compute Platform)
- **类比**：NVIDIA CUDA 是 iOS（闭源、生态完善），AMD ROCm 是 Android（开源、兼容性好但生态稍弱）——都提供 GPU 编程能力，但 API 和工具链不同。
- **专业定义**：AMD 的 GPU 计算开源平台。核心组件：HIP（CUDA 兼容层）、rocBLAS（对标 cuBLAS）、MIOpen（对标 cuDNN）、RCCL（对标 NCCL）、ROCm-SMI（对标 nvidia-smi）。HIP kernel 编程模型几乎与 CUDA 一致，CUDA 代码可通过 hipify 工具快速移植。PyTorch 和 vLLM 都有 ROCm 版本，在 AMD Instinct 系列 GPU 和国产 DCU 上运行。
- **首次出现**：stage3-direction-A-kernel/dcu-hip-kernel.md
- **分类**：方向 A - Kernel 开发

### Roofline Model / Roofline 模型
- **类比**：厨师的能力受两件事限制——刀工速度（算力，TFLOPS）和冰箱距离（带宽，GB/s）。一道菜「切菜量/取菜量」的比例（算术强度）决定了最终做菜速度是被刀工还是被冰箱位置限制。
- **专业定义**：分析计算性能瓶颈的经典模型。Y 轴为可达到的 FLOPS，X 轴为算术强度（FLOP/Byte）。两条屋顶线：水平线=计算屋顶（峰值算力），斜线=带宽屋顶（峰值带宽*算术强度）。LLM 推理中 Prefill（高算术强度）在计算屋顶附近（compute-bound），Decode（低算术强度）在带宽屋顶附近（memory-bound）。这解释了为什么 decode 性能主要受 HBM 带宽限制。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### RoPE (Rotary Position Embedding) / 旋转位置编码
- **类比**：两个人对暗号——不是用固定条子（绝对位置编码），而是用时钟：你说 3 点方向，对方知道是相对你站位的 3 点方向。RoPE 就是把位置信息编码成「旋转角度」，两个向量的夹角只取决于它们位置相对差。
- **专业定义**：当前 LLM 最主流的位置编码方式。通过对 Q 和 K 每对相邻维度施加二维旋转（旋转角度 = 位置 * 频率），使注意力分数只依赖相对位置差。频率公式：θ_i = base^(-2i/d)，base 通常 10000（Llama 2）、500000（Llama 3）、1000000（Qwen 2）。天然支持长度外推——训练见过相对距离 0~2047 的模式，推理时可泛化到更大距离，配合 NTK-aware/YaRN 等可扩展至 128K+ 上下文。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

---

## S

### SASS (Shader Assembly)
- **类比**：PTX 是标准普通食谱，SASS 是你家这台特定烤箱的实际控制信号——不同型号烤箱控制方式不同，但食谱（PTX）是一样的。
- **专业定义**：NVIDIA GPU 的实际机器码（二进制指令）。PTX 经 ptxas 编译后生成 SASS，不同 GPU 架构（SM80=A100、SM90=H100）的 SASS 不兼容。用 `cuobjdump -sass` 可反汇编 kernel 为 SASS，阅读 SASS 可精确了解 Tensor Core 指令使用情况、寄存器分配细节、指令级并行度——是极致 kernel 性能调优的最后手段。
- **首次出现**：stage3-direction-A-kernel/cuda-kernel-deep-dive.md
- **分类**：方向 A - Kernel 开发

### SiLU / Swish 激活函数
- **类比**：一个会自己调节音量的麦克风——输入信号大时几乎原样通过（SiLU(x) ≈ x），输入信号小时自动关闭（SiLU(x) ≈ 0），中间平滑过渡。这就是「自门控」（self-gating）。
- **专业定义**：SiLU(x) = x * σ(x) = x / (1 + e^{-x})。和 Swish 是同一函数不同名称。与 ReLU 相比：负半区有非零输出（不会「死」）、处处平滑可导。与 GELU 相比：计算更快（sigmoid vs tanh）、自门控属性与 Attention 选择机制契合。Llama 全系列、Mistral、Qwen 等现代 LLM 采用 SiLU。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### Slurm (Simple Linux Utility for Resource Management)
- **类比**：大学机房的电脑预约系统——学生提交作业（sbatch），系统根据空闲资源和优先级自动分配电脑（节点），作业完成后回收。
- **专业定义**：HPC 和 GPU 集群的主流作业调度系统。核心概念：Partition（节点按属性分组）、Job（sbatch/srun 提交）、QoS（优先级和资源限制）、Account（计费和多租户管理）。支持 GPU 资源调度（`--gres=gpu:8`）、CPU 亲和性绑定、NUMA 感知任务放置。大规模 AI 训练场景下负责管理数千张 GPU 的排队、分配和故障恢复。
- **首次出现**：stage3-direction-D-mlops/slurm-hpc-scheduling.md
- **分类**：方向 D - 算力集群 MLOps

### SM (Streaming Multiprocessor) / 流式多处理器
- **类比**：GPU 是 100 层大厦，每层是一个 SM（"小型工厂"），每层有 4 个车间（warp scheduler）和 64 个工人（CUDA Cores）。代码的 <<<grid, block>>> 配置决定任务如何分配到各层各车间。
- **专业定义**：NVIDIA GPU 的基本计算单元。每 SM 包含：CUDA Cores（FP32/FP64）、Tensor Cores（矩阵乘法加速器）、SFU（超越函数）、寄存器文件（如 A100 65536 个 32-bit 寄存器）、L1/Shared Memory（可配置，通常 128-256KB）、Warp Scheduler（通常 4 个）。A100 有 108 个 SM，H100 有 132 个 SM。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Smart Pointer / 智能指针
- **类比**：三种停车方式——`unique_ptr` 是专用车位只有一个主人，主人离开自动释放；`shared_ptr` 是共享车位，所有部门都说不用了才报废；`weak_ptr` 是临时观望，你不持有权利，只看车在不。
- **专业定义**：C++ 标准库的 RAII 资源管理封装。`unique_ptr`：独占所有权、零开销、vLLM 管理唯一 GPU Buffer。`shared_ptr`：通过控制块实现引用计数共享、多请求共享 tokenizer。`weak_ptr`：不增加引用计数、打破循环引用。三者结合将 GPU 资源和内存管理从原始 new/delete 提升到编译期保证的安全层次。
- **首次出现**：stage1-cs-basics/cpp-for-source-reading.md
- **分类**：阶段 1 - 计算机基础

### SMEM (Shared Memory) / GPU 共享内存
- **类比**：工厂里每个工位（SM）旁边的小工作台——工人在台子上极快地交换工具和信息，比去工厂仓库（HBM）取材料快 20-30 倍。但台面很小，只能放少量东西。
- **专业定义**：GPU 每 SM 内部的片上高速存储，CUDA 中用 `__shared__` 声明。延迟 1-32 周期（vs 全局内存 200-800），带宽 ~1-2 TB/s。容量 48-164KB/SM（与 L1 共用硬件，可调配比）。分为 32 个 4 字节 bank——同 warp 不同线程访问不同 bank 可并行，同 bank 不同地址则序列化（bank conflict）。FlashAttention 用 SMEM 存 Q、K、V 分块做 tile-based softmax。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Socket (Network) / 套接字
- **类比**：电话系统的插孔——你打电话（connect）到交换机（server socket），交换机分配专属线路（accept 返回新 fd），此后通过各自听筒（send/recv）通话，直到挂机（close）。
- **专业定义**：OS 提供的网络通信端点抽象。BSD Socket API：`socket() → bind() → listen() → accept()`（返回每连接新 fd）；客户端 `socket() → connect()`。Linux 上 epoll（事件通知, O(1) 并发）取代 select/poll（轮询, O(N)）。推理服务 SSE 流式响应的底层是 TCP Socket 非阻塞 + TCP_NODELAY（禁用 Nagle）保证每 token 即时发送。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：阶段 1 - 计算机基础

### Speculative Decoding / 推测解码
- **类比**：老员工（大模型）负责审核，实习生（小模型）先写草稿。老员工不是逐字审核而是批量批阅时快速纠正错的——通过率高时整体产出大幅提升。
- **专业定义**：无损加速自回归推理技术。小 draft model 快速生成 K 个候选 token，大 target model 并行验证。验证用拒绝采样——每候选以概率 min(1, P_target/P_draft) 接受，拒绝时从 target 修正分布采样新 token 并停止本轮。加速比取决于 draft 质量和推理速度比。实现方案包括 Medusa（多 draft head）、EAGLE（特征级推测）、Tree Attention（多路径并行验证）。
- **首次出现**：stage3-direction-B-inference/speculative-decoding.md
- **分类**：方向 B - 推理引擎

### SSE (Server-Sent Events) / 服务器推送事件
- **类比**：微信聊天——你发问题后不挂断（SSE 长连接），对方边打字边把每个字实时发给你，不等全文写完才一次性发过来。
- **专业定义**：HTTP 协议之上的单向流式推送机制。客户端发起 GET，服务端返回 `Content-Type: text/event-stream`，保持连接不断开，以 `data: xxx\n\n` 格式持续推送事件。LLM 流式 Chat Completions 依赖 SSE 每 token 实时发送，最后发送 `data: [DONE]\n\n`。必须在反向代理上禁用缓冲（`proxy_buffering off`）并设 TCP_NODELAY 禁用 Nagle。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：阶段 1 - 计算机基础

### SwiGLU (Swish-Gated Linear Unit)
- **类比**：一个有门卫把关的资料室——一半文件送「内容通道」（up_proj），一半送「门控通道」（gate_proj * SiLU）。门卫根据重要性决定内容通道中哪些通过，最终精选的汇总成一份报告（down_proj）。
- **专业定义**：现代 LLM 标准 FFN 实现。SwiGLU(x) = (W_gate * x * SiLU(W_up * x)) * W_down。三个权重矩阵，通过门控机制让模型自适应选择信息通过量。参数量：3 * hidden * intermediate，为匹配传统 FFN 的 2*4=8 倍参数量，通常设 intermediate = 8/3 * hidden。Llama、Mistral、Qwen、DeepSeek 等几乎所有现代 LLM 都使用 SwiGLU。
- **首次出现**：stage2-ai-infra-foundations/pytorch-transformer.md
- **分类**：阶段 2 - AI Infra 底层技术

---

## T

### TCP Handshake (Three-Way Handshake) / TCP 三次握手
- **类比**：打电话——A 拨号「喂？」（SYN），B 接听「喂，听到了，你说」（SYN+ACK），A 确认「好我开始说了」（ACK）——三个回合后正式通话。
- **专业定义**：TCP 建立可靠连接的过程。(1) 客户端发 SYN(seq=x)，进入 SYN_SENT；(2) 服务端回 SYN+ACK(seq=y, ack=x+1)，进入 SYN_RCVD；(3) 客户端回 ACK(ack=y+1)，双方进入 ESTABLISHED。同机房 RTT ~0.05-0.1ms，握手花费 1 RTT。推理服务中短连接每次请求重复握手会增加首 token 延迟，应使用连接池（keep-alive）或 HTTP/2 多路复用避免。
- **首次出现**：stage1-cs-basics/networking.md
- **分类**：阶段 1 - 计算机基础

### Tensor / 张量
- **类比**：数组的泛化——标量是点（0 维）、向量是线（1 维）、矩阵是面（2 维）、张量是立体或更高维的数据容器。AI 中的任何数据都可表示为某种形状的张量。
- **专业定义**：多维数组的数学抽象，深度学习框架的核心数据结构。PyTorch 中 Tensor 是 C++ `c10::TensorImpl` 的 Python 薄封装，支持 CPU/GPU 存储和自动求导。关键属性：shape（各维度大小）、dtype（float32/bfloat16/int8 等）、device（cuda:0/cpu）、stride（内存布局步长）。Transformer 中的标准形状约定：[Batch, SeqLen, HiddenDim]。
- **首次出现**：stage2-ai-infra-foundations/deep-learning-basics.md
- **分类**：阶段 2 - AI Infra 底层技术

### Tensor Core
- **类比**：普通 CUDA Core 是通用工具箱——什么都能做但做矩阵乘法慢。Tensor Core 是专用电动螺丝刀——只做一件事（4x4 半精度矩阵乘加），但做得极快、极省电。
- **专业定义**：NVIDIA GPU 中专用于矩阵乘加（D = A*B + C）的硬件单元。Volta 起引入，每代吞吐翻倍。A100（SM80）：FP16 下每 Tensor Core 每周期完成 64 个浮点运算；H100（SM90）：支持 FP8，吞吐是 FP16 的 2 倍。LLM 推理/训练的 >90% FLOPs 由 Tensor Core 完成。在 CUDA 内通过 `mma.sync` PTX 指令或 WMMA API 或 CUTLASS 库调用。
- **首次出现**：stage2-ai-infra-foundations/cuda-programming.md
- **分类**：阶段 2 - AI Infra 底层技术

### Tensor Parallelism (TP) / 张量并行
- **类比**：超大矩阵乘法——把矩阵纵向切成 4 条分给 4 人各算一部分，算出后交换汇总。TP 的本质就是将一个 GPU 装不下的单层权重切成多份并行计算。
- **专业定义**：模型并行策略，将单层权重按列或行切分到多 GPU。Megatron-LM 方案：QKV 投影按 head 维切分（column-parallel），输出投影按行切分（row-parallel）；FFN 的 gate/up 按列切分、down 按行切分。每层需 2~4 次 All-Reduce（前向+反向），对延迟极度敏感——必须使用 NVLink（~900 GB/s, ~1 微秒），不能走慢速网络。是推理时突破单 GPU 显存限制的主要手段。
- **首次出现**：stage3-direction-C-training/megatron-lm-deep-dive.md
- **分类**：方向 B + 方向 C

### Thread Block / 线程块
- **类比**：大项目（grid）分给各楼层车间（SM），每车间派一组工人（thread block）做一部分工作——组内工人可围在一起讨论（SMEM 共享），不同组工人不能直接交流。
- **专业定义**：CUDA 编程中 warp 的上层组织单位。一个 thread block 含 1-1024 个线程（必须是 warp=32 的倍数），全部被调度到同一 SM 上执行。Block 内线程可通过 `__syncthreads()` 同步、通过 `__shared__` 共享数据。<<<gridDim, blockDim>>> 启动配置定义全局 block 数和每 block 线程数。Block 被 GPU 硬件调度器分配到 SM——一个 SM 可同时容纳多个 block。
- **首次出现**：stage2-ai-infra-foundations/cuda-programming.md
- **分类**：阶段 2 - AI Infra 底层技术

### Thread vs Process / 线程 vs 进程
- **类比**：进程是独立公寓（自己的钥匙、水电表），线程是合租室友（共享客厅厨房厕所、各有自己房间）。公寓间传东西需快递（IPC），室友间直接递就行。一个室友踢坏门，整屋人都受影响。
- **专业定义**：OS 两个基本执行单元。进程：独立虚拟地址空间、文件描述符表——强隔离但创建/切换昂贵（需切换页表+刷新 TLB）。线程：共享进程地址空间和文件描述符，仅独立寄存器和栈——创建/切换轻量（CR3 不变、TLB 大部分保留）。vLLM 选多线程架构：所有 worker 共享同一 CUDA context、共享模型权重（mmap 共享内存中）、NCCL 通信在线程间高效进行。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

### 3D Parallelism / 三维并行
- **类比**：大建筑项目同时从三个维度分工——张三李四各领施工队在不同楼上作业（TP 按层内切分），1 号楼→2 号楼→3 号楼形成流水线（PP），每施工队有 4 组在不同工地同时搬砖（DP）。这就是 Megatron-LM 的 PTD-P 策略。
- **专业定义**：TP + PP + DP 的组合使用策略。TP 在单节点 NVLink 上做高频 All-Reduce（对延迟最敏感）；PP 在节点间传递激活（对带宽需求中等）；DP 跨整个集群同步梯度（通信量最大但频率最低——通过梯度累积摊薄开销）。分层通信策略充分利用了 GPU 集群带宽层级（NVLink ~900 GB/s > IB ~50 GB/s > 慢速网络）。
- **首次出现**：stage3-direction-C-training/megatron-lm-deep-dive.md
- **分类**：方向 C - 分布式训练

### TLB (Translation Lookaside Buffer) / 转换后备缓冲器
- **类比**：每次去隔壁部门都要翻通讯录找房间号太慢了——于是把最常去的房间号记手心里（TLB）。手心记了 64 个号（L1 TLB），去第 65 个不认识的地方（TLB miss）才需翻通讯录慢慢找。
- **专业定义**：MMU 内部的硬件缓存，存储最近使用的虚拟→物理地址映射。L1 TLB：64-128 条目、1 cycle；L2 TLB：1536-2048 条目、5-8 cycles。TLB miss 触发 Page Table Walk——遍历多级页表需 4 次额外内存访问。LLM 推理 KV Cache 可达 GB 级，远超 4KB 页 TLB 覆盖范围（~6MB），使用大页是减少 TLB miss 的关键。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

### TPOT (Time Per Output Token) / 每输出 Token 时间
- **类比**：外卖的「平均出餐时间」——从厨子开始做到之后每道菜端出的平均间隔。首道菜（TTFT）可能慢（需备料），后面应很快很均匀。
- **专业定义**：LLM 推理服务关键延迟指标。TPOT = 从第一个生成 token 之后每个后续 token 的平均生成时间 = decode 阶段每次迭代的时间。受限于 HBM 带宽——decode 是 memory-bound，大部分时间花在从 HBM 读取权重和 KV Cache。大 batch size 时 KV Cache 读取量增加，TPOT 随之上升。
- **首次出现**：stage3-direction-B-inference/scheduling-strategies.md
- **分类**：方向 B - 推理引擎

### Tree Attention / 树状注意力
- **类比**：传统顺序输出是「顺藤摸瓜」——一条线往下摸。Tree Attention 是同时摸几条可能的瓜藤，到岔路口时快速比较哪条藤上瓜更大、哪条是枯藤，保留最好的。
- **专业定义**：Speculative Decoding 中用于并行验证多条推测路径的注意力变体。将多条备选 token 序列组织成树结构，通过特殊的 attention mask（每个节点只能关注其祖先节点）同时计算所有路径——共享前缀的 KV Cache 被所有分支复用。使 target model 可一次性并行验证来自 draft model 的多个候选 token 和候选序列。
- **首次出现**：stage3-direction-B-inference/speculative-decoding.md
- **分类**：方向 B - 推理引擎

### Triton DSL (OpenAI)
- **类比**：手动砌砖（CUDA 编程）太繁琐——需要精确指定每块砖位置。Triton 给你预制水泥板（tile 抽象）——你只需指定每个工人负责多大一块，Triton 自动分配工人和物料。
- **专业定义**：OpenAI 开发的 Python 语言 GPU kernel 编程框架。核心抽象是「block-level」编程——一个 kernel 函数处理一个 tile，编译器自动处理 block 内 thread-level 并行和数据加载。`@triton.jit` 装饰器标记 kernel，`tl.load/tl.store` 做分块加载/存储，`tl.dot` 调用 Tensor Core。比 CUDA 代码更短、更易优化。PyTorch 2.0 的 `torch.compile` 大量用 Triton 作为 CUDA 后端代码生成器。
- **首次出现**：stage3-direction-A-kernel/cutlass-triton-kernel.md
- **分类**：方向 A - Kernel 开发

### TTFT (Time To First Token) / 首 Token 延迟
- **类比**：叫外卖后第一道菜端上桌的时间——从下单到第一个菜出现，包括厨房备料（prefill 处理 prompt）+ 做第一道菜。你感知到的「响应速度」就是这个时间。
- **专业定义**：LLM 推理服务关键延迟指标。TTFT = 从请求到达到第一个生成 token 返回的时间，主要包括：网络往返 + 请求排队 + prefill 计算（整个 prompt 前向传播）+ 第一个 token decode + 网络返回。TTFT 主要由 prefill 时间决定（compute-bound），与 prompt 长度强相关。Chunked Prefill 和 Prefix Caching 都可有效降低 TTFT。
- **首次出现**：stage3-direction-B-inference/scheduling-strategies.md
- **分类**：方向 B - 推理引擎

---

## V

### Vectorized Load / 矢量化加载
- **类比**：一个人一次搬一个苹果 vs 一次搬一箱 4 个苹果——搬的次数少了 3/4，总搬运时间接近原来的 1/4。
- **专业定义**：GPU 全局内存访问优化技术。用 `float4`、`int4` 等 128-bit 向量类型一次内存事务加载 4 个连续 float/int（16 字节），减少内存事务数 4 倍，提升有效带宽利用率。对齐要求：地址必须 16 字节对齐。FlashAttention 等高性能 kernel 中 Q、K、V 的分块加载都用 float4 矢量化为极致榨取 HBM 带宽。
- **首次出现**：stage3-direction-A-kernel/attention-kernel-optimize.md
- **分类**：方向 A - Kernel 开发

### Virtual Memory / 虚拟内存
- **类比**：每个进程以为自己独占一整栋楼（虚拟地址空间），实际大家房间散布在真实建筑里（物理内存），有一本「楼号对应表」（页表）负责翻译——哪个虚拟房间对应哪个物理房间。
- **专业定义**：OS 提供的内存抽象。每进程拥有独立连续的虚拟地址空间（x86-64 48 位有效地址），通过多级页表（PML4→PDPT→PD→PT）映射到物理内存的离散帧。提供三大能力：隔离（进程间不可互访）、抽象（连续地址映射到分散物理页）、超卖（惰性分配，虚拟空间可超物理内存）。PagedAttention 的设计直接借鉴虚拟内存——Block Table 对应 Page Table，物理块对应物理帧，Block Fault 对应 Page Fault。
- **首次出现**：stage1-cs-basics/os-memory-process.md
- **分类**：阶段 1 - 计算机基础

---

## W

### Warp / 线程束
- **类比**：工厂装配线的 32 个工人——步调完全一致，同一时刻做同一个动作（SIMT），但每人处理的零件可以不同。如果某工人需暂停等材料，除非有另一个活可切换，否则整条线都得等他。
- **专业定义**：NVIDIA GPU 最基本调度和执行单元，32 个线程。同一 warp 内所有线程在同一个 SM 上以锁步（lockstep）方式执行——每周期执行同一条指令，但可操作不同数据（SIMT）。Warp Divergence：warp 内线程走不同分支路径时，两路径被序列化执行，效率减半。理解 warp 是理解 CUDA 编程模型的核心。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Warp Divergence / 线程束发散
- **类比**：旅游团到岔路口——领队说「看风景走左边，买特产去右边，我先带左边的人走，右边的原地等」。左边走完再带右边走。32 人里 16 左 16 右就效率减半。
- **专业定义**：同一 warp 内 32 线程的条件分支走不同路径时，GPU 序列化执行两条路径——执行路径 A 时其他线程被硬件 mask idle，完成后再执行路径 B。最佳实践：尽量保证 warp 内执行路径一致，如避免 `threadIdx.x` 参与分支条件，或用数据重排将同类分支的数据分到同 warp。
- **首次出现**：stage2-ai-infra-foundations/simt-parallel-model.md
- **分类**：阶段 2 - AI Infra 底层技术

### Wavefront (AMD GPU)
- **类比**：AMD GPU 版本的 Warp——NVIDIA 叫 Warp（32 人一队），AMD 叫 Wavefront（64 人一队）。人多一倍，步调一致的要求也更严格。
- **专业定义**：AMD GPU（含 DCU）的 Compute Unit 中的基本调度单位，64 个线程（NVIDIA warp 是 32）。同一 wavefront 内线程以锁步方式执行，条件分支同样导致 divergence。HIP kernel 中 `__syncthreads()` 等同步原语与 CUDA 一致。DCU wavefront 是 NVIDIA warp 两倍——分支敏感的 kernel 从 CUDA 移植到 DCU 时需特别注意。
- **首次出现**：stage3-direction-A-kernel/dcu-hip-kernel.md
- **分类**：方向 A - Kernel 开发

### WMMA (Warp Matrix Multiply Accumulate)
- **类比**：Tensor Core 的「傻瓜式 API」——你不用操心矩阵切片、指令编排等细节，只需说「用这 16×16 的 A 和 B 乘加 C」，它自动用 Tensor Core 算好。但傻瓜式意味着灵活性受限。
- **专业定义**：CUDA 中高层 Tensor Core 编程接口（CUDA 9+）。通过 `nvcuda::wmma` 命名空间下的 `load_matrix_sync`、`mma_sync`、`store_matrix_sync` 等 API 在 warp 级别调用 Tensor Core 算分块矩阵乘法。比直接使用 PTX `mma.sync` 指令更容易但调优空间更小。CUTLASS 在底层大量用 `mma.sync` 实现更精细的 tile 编排和数据流控制。
- **首次出现**：stage3-direction-A-kernel/cuda-kernel-deep-dive.md
- **分类**：方向 A - Kernel 开发

---

## X

### XID Error / XID 错误
- **类比**：汽车仪表盘的故障灯——发动机有问题亮黄灯（XID 48 = 双比特 ECC）、变速箱故障亮红灯（XID 31 = GPU 内部总线错误）。XID 就是 GPU 的故障码。
- **专业定义**：NVIDIA GPU 错误报告编码。常见：XID 48（双比特 ECC 错误，通常意味 HBM 有不可纠正数据损坏）、XID 31（GPU 内部总线 parity 错误）、XID 79（NVLINK 错误）、XID 13（GPU 温度过高导致降频或保护性关机）、XID 45（PCIe link down）。通过 `nvidia-smi -q -d PAGE_RETIREMENT` 可查看 HBM 中已退休页面。MLOps 监控必须捕获并告警 XID 错误。
- **首次出现**：stage3-direction-D-mlops/monitoring-observability.md
- **分类**：方向 D - 算力集群 MLOps

---

## Z

### ZeRO (Zero Redundancy Optimizer) / 零冗余优化器
- **类比**：8 个人读一本 800 页的书——之前每人都复印全书（6400 页纸）。ZeRO 把书分成 8 章节，每人只复印自己那章节的 100 页，想看别人章节时借来看完还回去。总用纸量从 6400 页降到 800 页。
- **专业定义**：DeepSpeed 提出的分阶段优化器状态和参数分片策略。ZeRO-1：分片优化器状态（Adam m,v），通信量同标准 DP。ZeRO-2：额外分片梯度，用 Reduce-Scatter 替代 All-Reduce（减半梯度通信）。ZeRO-3：额外分片参数，每 rank 只保留 1/N 参数分片，前向/反向通过 All-Gather 临时收集。单 GPU 显存需求线性降至 1/N，是让大模型训练可行最关键的技术之一。
- **首次出现**：stage3-direction-C-training/deepspeed-zero.md
- **分类**：方向 C - 分布式训练

### 1F1B (One Forward One Backward) / 一前一后调度
- **类比**：做汉堡和回收餐盘交替——不是「先做完所有汉堡再回收」（那会让一半人闲着），而是「做一个汉堡→收一个餐盘→做一个汉堡→收一个餐盘」交错进行，保持所有人忙碌。
- **专业定义**：流水线并行的一种调度策略。在完成第一个 micro-batch 前向传播后不等所有前向完成即开始反向——交错执行：Forward N → Forward N+1 → Backward N → Forward N+2 → Backward N+1...。1F1B 减小了流水线 bubble，bubble size = (pp_size - 1) / num_microbatches——micro-batch 越多 bubble 越小。Megatron-LM 和 DeepSpeed 都实现了 1F1B 调度。
- **首次出现**：stage3-direction-C-training/pipeline-parallelism.md
- **分类**：方向 C - 分布式训练

---

## 分类速查索引

### 阶段 1 - 计算机基础（CS Basics）
Virtual Memory, Page Fault, TLB, NUMA, DMA, RDMA, TCP Handshake, Socket, SSE, GIL, Reference Counting, RAII, Smart Pointer, Move Semantics, Pybind11, Mutex, Atomic, Thread vs Process, Context Switch, mmap, Huge Pages

### 阶段 2 - AI Infra 底层技术
Tensor, Autograd, Backpropagation, Gradient Descent, Adam/AdamW, LayerNorm, RMSNorm, GELU, SiLU/Swish, Cross-Entropy, RoPE, GQA, MQA, MLA, SwiGLU, Residual Connection, Attention Mechanism, Causal Mask, KV Cache, SM, Warp, Thread Block, SMEM, HBM, Tensor Core, Warp Divergence, Occupancy, Coalesced Access, Bank Conflict, CUDA Graph, Roofline Model, Arithmetic Intensity, Einsum

### 方向 A - Kernel 开发
Triton DSL, CUTLASS, PTX, SASS, Persistent Kernel, Kernel Fusion, Vectorized Load, Hipify, ROCm, Wavefront, LDS, Online Softmax, FlashAttention

### 方向 B - 推理引擎
Continuous Batching, PagedAttention, Block Table, Block Size, Prefill, Decode, TTFT, TPOT, Chunked Prefill, Preemption (Swap/Recompute), Prefix Caching, Speculative Decoding, Draft Model, Tree Attention, GPTQ, AWQ, Marlin Kernel, FP8/INT8/INT4, Per-Channel vs Per-Token Quantization, KV Cache Quantization, RadixAttention, CUDA Graph Capture, Tensor Parallelism (TP)

### 方向 C - 分布式训练
Data Parallelism, ZeRO-1/2/3, FSDP, Gradient Accumulation, Mixed Precision, Loss Scaling, DDP, Megatron-LM, 3D Parallelism, Micro-Batch, 1F1B, Bubble (Pipeline), Gradient Checkpointing, All-Reduce, All-Gather, Reduce-Scatter, NCCL

### 方向 D - 算力集群 MLOps
MIG, MPS, GPU Operator, KEDA, HPA, DCGM, XID Error, ECC Error, RDMA, InfiniBand, RoCE, NVLink, NVSwitch, GPU Direct RDMA, Fat-Tree, Slurm, Fair-Share, QoS

---

> **使用建议**：本词典按拼音首字母排序，方便按英文首字母快速查找。每个术语的类比帮你建立直觉理解，专业定义提供精确技术细节。建议在学习某阶段文档前先浏览对应分类术语，建立概念地图后再深入阅读。
