# 监控与可观测性 — AI 推理服务体系

> **方向 D：算力集群 MLOps** | 🟡 了解 | 难度：⭐⭐⭐

---

## 一、AI 推理为什么需要专门的监控

普通 Web 服务的监控（CPU、内存、QPS、HTTP 延迟）无法覆盖 AI 推理服务的真实状态：

```
传统 Web 监控                     AI 推理监控
══════════════                    ════════════
CPU 利用率                         GPU 利用率 + SM 占用率
内存使用                           显存使用 (模型 + KV Cache)
QPS                               QPS + tokens/s
P50/P99 HTTP 延迟                  TTFT P50/P95 + TPOT P50/P95
HTTP 4xx/5xx                      HTTP 错误 + CUDA 错误 + OOM
—                                 排队深度 + Cache 命中率
```

**三大 Pillar：Metrics（指标）、Logs（日志）、Traces（追踪）**。

---

## 二、监控金字塔

```
        ┌──────────────┐
        │   SLO / 告警   │  ← "99% 请求 TTFT < 500ms"
        ├──────────────┤
        │   应用层      │  ← vLLM metrics: QPS, TTFT, TPOT, cache
        ├──────────────┤
        │   系统层      │  ← CPU, Memory, Disk IO, Network
        ├──────────────┤
        │   GPU 硬件层  │  ← DCGM: SM 占用率, 显存, 温度, ECC, XID
        └──────────────┘
```

---

## 三、GPU 硬件层：DCGM（Data Center GPU Manager）

### 3.1 部署 DCGM Exporter

```bash
docker run -d --gpus all --name dcgm-exporter \
    -p 9400:9400 \
    nvcr.io/nvidia/k8s/dcgm-exporter:latest
```

```yaml
# K8s DaemonSet
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: dcgm-exporter
spec:
  selector:
    matchLabels:
      app: dcgm-exporter
  template:
    spec:
      containers:
      - name: dcgm-exporter
        image: nvcr.io/nvidia/k8s/dcgm-exporter:latest
        resources:
          limits:
            nvidia.com/gpu: 1
        ports:
        - containerPort: 9400
```

### 3.2 关键 GPU 指标

| DCGM 指标 | 含义 | 告警建议 |
|----------|------|----------|
| `DCGM_FI_DEV_GPU_UTIL` | GPU 时间片利用率（⚠️ 易误导） | 持续 100% 不一定好 |
| `DCGM_FI_PROF_SM_OCCUPANCY` | **SM 占用率**（核心！） | < 30% 说明 GPU 在空转 |
| `DCGM_FI_PROF_PIPE_TENSOR_ACTIVE` | Tensor Core 活跃占比 | 推理时应 > 50% |
| `DCGM_FI_DEV_MEM_COPY_UTIL` | 显存带宽利用率 | Decode 阶段应较高 |
| `DCGM_FI_DEV_FB_USED` | 已用显存 (MiB) | > 90% → Warning, > 95% → Critical |
| `DCGM_FI_DEV_FB_FREE` | 空闲显存 (MiB) | < 5GB → 准备 OOM |
| `DCGM_FI_DEV_GPU_TEMP` | GPU 温度 (°C) | > 80°C → 检查散热, > 85°C → 将降频 |
| `DCGM_FI_DEV_POWER_USAGE` | 功耗 (W) | 接近 TDP(300W) → 高负载 |
| `DCGM_FI_DEV_ECC_SBE_VOL_TOTAL` | ECC 单比特错误 (Counter) | 增长趋势 → 硬件老化 |
| `DCGM_FI_DEV_ECC_DBE_VOL_TOTAL` | ECC 双比特错误 (Counter) | 任何 > 0 → 紧急！ |
| `DCGM_FI_DEV_XID_ERRORS` | XID 硬件错误 (Counter) | 任何 > 0 → 紧急处理 |
| `DCGM_FI_DEV_NVLINK_BANDWIDTH_TOTAL` | NVLink 带宽利用率 | TP 推理时应 > 50% |

**⚠️ GPU 利用率是最常被误解的指标**：

```
场景：Decode 阶段 GPU 利用率 100%

真相：
[读 KV Cache (HBM)] → [算 Attention (计算)] → [等数据 (内存延迟)] → [算 MLP]
 ↑ HBM 带宽瓶颈           ↑ 很快                ↑ 等待               ↑ 很快

GPU 利用率 100% ≠ GPU 在高效计算
它只是说 "GPU 没闲着，但大部分时间在等数据"

更好的指标：SM Occupancy
- Decode 阶段通常只有 10-30%（因为只处理 1 token）
- Prefill 阶段可以达到 80-95%
```

### 3.3 XID 错误速查

| XID | 含义 | 响应 |
|-----|------|------|
| 13 | 图形引擎故障 | 重启节点 |
| 31 | GPU 内存页故障 | 数据可能损坏，检查模型输出 |
| 48 | 双比特 ECC 错误 | 硬件故障，更换 GPU |
| 61/62/63 | 内存 ECC 保护故障 | 重启节点 |
| 79 | GPU 从总线脱落 | 物理连接问题，检查硬件 |

---

## 四、vLLM 应用层指标

vLLM 自动在 `/metrics` 暴露 Prometheus 格式指标（默认端口 8000）。

### 4.1 请求类

```
vllm:num_requests_running       # 正在处理的请求数 (Gauge)
vllm:num_requests_waiting       # 排队等待的请求数 (Gauge)
vllm:num_requests_swapped       # 被 swap 到 CPU 的请求数 (Gauge)
vllm:request_success_total      # 成功请求总数 (Counter)
vllm:request_failure_total      # 失败请求总数 (Counter)
```

### 4.2 延迟类（核心）

```
vllm:time_to_first_token_seconds    # TTFT (Histogram)
    Buckets: 0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10, 30, 60, +Inf

vllm:time_per_output_token_seconds  # TPOT (Histogram)
    Buckets: 0.001, 0.005, 0.01, 0.02, 0.05, 0.1, 0.5, 1, +Inf
```

**PromQL 查询：**
```promql
# TTFT P50 / P95 / P99
histogram_quantile(0.50, rate(vllm:time_to_first_token_seconds_bucket[5m]))
histogram_quantile(0.95, rate(vllm:time_to_first_token_seconds_bucket[5m]))
histogram_quantile(0.99, rate(vllm:time_to_first_token_seconds_bucket[5m]))

# TPOT 均值
rate(vllm:time_per_output_token_seconds_sum[5m]) /
rate(vllm:time_per_output_token_seconds_count[5m])

# 错误率 (5m 窗口)
sum(rate(vllm:request_failure_total[5m])) /
(sum(rate(vllm:request_success_total[5m])) + sum(rate(vllm:request_failure_total[5m])))
```

### 4.3 Cache 类

```
vllm:gpu_cache_usage_perc        # GPU KV Cache 使用率 (0-100)
vllm:cpu_cache_usage_perc        # CPU Swap Cache 使用率 (0-100)
```

**告警规则：**
- `gpu_cache_usage_perc > 85%` → Warning：显存吃紧
- `gpu_cache_usage_perc > 95%` → Critical：即将触发 Preemption
- `num_requests_waiting > 50` → 过载，需扩容

---

## 五、Prometheus + Grafana 快速搭建

### 5.1 Prometheus 配置

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'dcgm'
    scrape_interval: 5s
    static_configs:
      - targets: ['localhost:9400']
        labels:
          cluster: 'a800-cluster'

  - job_name: 'vllm'
    scrape_interval: 5s
    static_configs:
      - targets:
          - 'localhost:8000'   # Qwen-7B
          - 'localhost:8001'   # Qwen-72B
        labels:
          service: 'vllm'

  - job_name: 'gateway'
    scrape_interval: 10s
    static_configs:
      - targets: ['localhost:8080']
```

### 5.2 Prometheus 数据类型

| 类型 | 说明 | 用法 | 示例 |
|------|------|------|------|
| **Counter** | 只增不减 | `rate()` 计算速率 | `request_success_total` |
| **Gauge** | 可增可减 | 直接用 | `gpu_cache_usage_perc` |
| **Histogram** | 分桶分布 | `histogram_quantile()` | `time_to_first_token_seconds` |

### 5.3 Grafana 仪表盘推荐布局

```
Row 1: RED 概览
  [QPS Stat] [TPS Stat] [错误率 Stat] [排队深度 Stat]
  [TTFT P50/P95/P99 (Time Series)]
  [TPOT P50/P95/P99 (Time Series)]

Row 2: GPU 详情
  [GPU0 Util Gauge] [GPU1 Util Gauge] ... [GPU7 Util Gauge]
  [GPU0 Mem Gauge]  [GPU1 Mem Gauge]  ... [GPU7 Mem Gauge]
  [GPU Temperature (Time Series)]
  [SM Occupancy (Time Series)]

Row 3: Cache & 调度
  [GPU Cache Usage % (Gauge)]
  [CPU Cache Usage % (Gauge)]
  [num_requests_running/waiting/swapped (Time Series)]

Row 4: 流量
  [Prompt tokens/s (Time Series)]
  [Generation tokens/s (Time Series)]
```

### 5.4 Docker Compose 部署

```yaml
# monitoring-stack.yml
version: '3.8'
services:
  prometheus:
    image: prom/prometheus:latest
    network_mode: host
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prom_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.retention.time=30d'

  grafana:
    image: grafana/grafana:latest
    network_mode: host
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana_data:/var/lib/grafana

  dcgm-exporter:
    image: nvcr.io/nvidia/k8s/dcgm-exporter:latest
    network_mode: host
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: all
              capabilities: [gpu]

volumes:
  prom_data:
  grafana_data:
```

```bash
docker-compose -f monitoring-stack.yml up -d
# Prometheus: http://localhost:9090
# Grafana:    http://localhost:3000 (admin/admin)
# DCGM:       http://localhost:9400/metrics
```

---

## 六、告警设计

### 6.1 告警分级

| 级别 | 响应时间 | 触发条件示例 |
|------|---------|-------------|
| **P1 (Critical)** | 立即（凌晨起床） | 服务不可用、GPU XID 错误、所有 GPU > 85°C |
| **P2 (Warning)** | 30 分钟内 | 错误率 > 1%、显存 > 95%、排队 > 50 |
| **P3 (Info)** | 工作时间 | 性能缓慢退化、ECC 单比特错误积累 |

### 6.2 Prometheus 告警规则

```yaml
# alerts.yml
groups:
  - name: vllm_alerts
    rules:
      - alert: VLLMServiceDown
        expr: up{job="vllm"} == 0
        for: 1m
        labels: { severity: critical, priority: P1 }
        annotations:
          summary: "vLLM 服务 {{ $labels.instance }} 不可用"

      - alert: GPUXIDError
        expr: rate(DCGM_FI_DEV_XID_ERRORS[5m]) > 0
        labels: { severity: critical, priority: P1 }
        annotations:
          summary: "GPU {{ $labels.gpu }} XID 硬件错误"

      - alert: HighErrorRate
        expr: |
          sum(rate(vllm:request_failure_total[5m])) /
          (sum(rate(vllm:request_success_total[5m])) + sum(rate(vllm:request_failure_total[5m]))) > 0.01
        for: 5m
        labels: { severity: warning, priority: P2 }
        annotations:
          summary: "错误率 {{ $value | humanizePercentage }}"

      - alert: GPUOutOfMemory
        expr: DCGM_FI_DEV_FB_USED / (DCGM_FI_DEV_FB_USED + DCGM_FI_DEV_FB_FREE) > 0.95
        for: 5m
        labels: { severity: warning, priority: P2 }
        annotations:
          summary: "GPU {{ $labels.gpu }} 显存使用 > 95%"

      - alert: HighQueueDepth
        expr: vllm:num_requests_waiting > 50
        for: 5m
        labels: { severity: warning, priority: P2 }
        annotations:
          summary: "排队请求 > 50"

      - alert: HighP99TTFT
        expr: |
          histogram_quantile(0.99,
            sum(rate(vllm:time_to_first_token_seconds_bucket[5m])) by (le)) > 3
        for: 10m
        labels: { severity: warning, priority: P2 }
        annotations:
          summary: "P99 TTFT > 3s，当前 {{ $value }}s"
```

---

## 七、SLO（服务水平目标）

### 7.1 推理服务典型 SLO

```
┌──────────────────────────────────────────────────────────┐
│ SLO-1: 99% 的请求 TTFT < 500ms                            │
│ SLO-2: 99.9% 的请求在 60s 内完成（不被中断）               │
│ SLO-3: 服务可用性 99.9%（月宕机 < 43.2 分钟）              │
└──────────────────────────────────────────────────────────┘
```

### 7.2 错误预算

```
月可用性 99.9%：
  允许宕机 = 30天 × 24h × 60min × (1 - 0.999) = 43.2 分钟/月

错误预算耗尽 → 冻结新功能发布 → 优先修复可靠性
```

### 7.3 SLO 监控 PromQL

```promql
# 过去 30 天的 TTFT SLO 达标率：(TTFT < 500ms 的请求占比)
avg_over_time(
  sum(rate(vllm:time_to_first_token_seconds_bucket{le="0.5"}[5m])) /
  sum(rate(vllm:time_to_first_token_seconds_bucket{le="+Inf"}[5m]))
[30d:])
```

---

## 八、分布式追踪（OpenTelemetry）

```
一次推理请求的完整 Trace：

Gateway (120μs) → vLLM Queue (12ms) → Prefill (89ms) → Decode×100 (2450ms)
                   └── TTFT (101ms) ──┘ └── TPOT (24.5ms/token) ──┘
```

```python
# API 网关注入 OpenTelemetry
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

provider = TracerProvider()
exporter = OTLPSpanExporter(endpoint="http://jaeger:4317")
provider.add_span_processor(BatchSpanProcessor(exporter))
trace.set_tracer_provider(provider)
FastAPIInstrumentor.instrument_app(app)
```

---

## 九、结构化日志

```python
import structlog
logger = structlog.get_logger()

logger.info(
    "request_completed",
    request_id="req_abc123",
    model="qwen2.5-7b",
    prompt_tokens=512,
    output_tokens=187,
    ttft_ms=145.3,
    tpot_ms=27.2,
    total_time_ms=5234.1
)
# 输出 (JSON Lines):
# {"event":"request_completed","request_id":"req_abc123","ttft_ms":145.3,...}
```

---

## 十、日常巡检清单

```
┌─────────────────────────────────────────────────────────────┐
│ 每日 (5 分钟)                                                │
│ □ Grafana: 过去 24h 无异常波动                               │
│ □ GPU 温度 < 75°C | 显存 < 85% | 错误率 < 0.1%               │
│ □ 无 Active P1/P2 告警                                      │
├─────────────────────────────────────────────────────────────┤
│ 每周 (15 分钟)                                               │
│ □ ECC 错误无增长趋势                                         │
│ □ SLO 达标率 > 99.5%（7 天窗口）                              │
│ □ TTFT/TPOT P95 无退化                                       │
├─────────────────────────────────────────────────────────────┤
│ 每月 (30 分钟)                                               │
│ □ 错误预算剩余充足                                           │
│ □ 容量规划：预测未来 3 个月扩容需求                           │
│ □ Dashboard 更新 + 告警规则 review                           │
└─────────────────────────────────────────────────────────────┘
```

---

## 十一、与 AI Infra 的关联

监控不只是"看看有没有报错"：

- **GPU 指标**告诉你推理是否高效（SM Occupancy **远**比 GPU 利用率重要）
- **vLLM 指标**告诉你服务是否健康（Cache 压力 → 即将 OOM）
- **SLO** 定义了你的服务质量承诺，是运维和开发的共同语言
- **告警**让你在用户感知之前发现问题

当你在本地部署 33B/67B 模型时，监控体系让你：
1. 量化每次优化的效果（调 `max_num_seqs` → 看 TTFT/TPOT 变化）
2. 第一时间发现 OOM 风险（Cache 使用率告警）
3. 追踪长期性能趋势（SLO 达标率）

---

## 十二、术语速查

| 术语 | 一句话类比 | 详见章节 |
|------|-----------|----------|
| **DCGM** | NVIDIA 的"GPU 体检中心"，24/7 采集每一张 GPU 的温度、显存、功耗、XID 错误 | 三、GPU 硬件层 |
| **SM Occupancy** | GPU 的"有效工作时间占比"——比 GPU 利用率更能反映推理效率，Decode 阶段通常只有 10%-30% | 3.2 关键 GPU 指标 |
| **TTFT (Time To First Token)** | 用户发送请求到看到第一个字的"首字延迟"，是用户体验的核心指标 | 四、vLLM 应用层指标 |
| **TPOT (Time Per Output Token)** | 后续每个字的"生成速度"，影响长文本输出的体感快慢 | 4.2 延迟类 |
| **SLO / 错误预算** | 对用户的服务质量承诺（如 99.9% 可用），剩余"犯错额度"用完后冻结上线 | 七、SLO |
| **Prometheus Histogram** | 不是存原始数据，而是按"桶"分档统计（0-5ms, 5-10ms...），用 histogram_quantile 算 P50/P95/P99 | 五、Prometheus + Grafana |

## 十三、A800 部署场景举例

**场景一：8×A800 推理节点全栈监控部署**

在典型 8×A800 80GB 节点上部署 DCGM + Node Exporter + vLLM metrics 三层采集：

```bash
# 1. 确认 DCGM Exporter 正常运行（每张 A800 指标是否齐全）
curl -s http://localhost:9400/metrics | grep -c "DCGM_FI_DEV_GPU_UTIL"
# 预期输出: 8（每张 GPU 一个指标）

# 2. Prometheus 配置 A800 集群专属 scrape job
cat >> /etc/prometheus/prometheus.yml << 'EOF'
  - job_name: 'a800-dcgm'
    scrape_interval: 5s
    static_configs:
      - targets:
        - 'gpu-node-01:9400'
        - 'gpu-node-02:9400'
        labels:
          cluster: 'a800-prod'
          gpu_model: 'A800-SXM4-80GB'
  - job_name: 'a800-vllm'
    scrape_interval: 5s
    static_configs:
      - targets:
        - 'gpu-node-01:8000'  # vLLM metrics endpoint
        - 'gpu-node-02:8000'
EOF

# 3. 验证关键指标可查询
curl -s 'http://prometheus:9090/api/v1/query?query=DCGM_FI_PROF_SM_OCCUPANCY' \
  | jq '.data.result[] | {instance: .metric.instance, gpu: .metric.gpu, value: .value[1]}'
```

**场景二：A800 推理服务关键告警规则**

针对 8×A800 推理节点的生产级告警配置：

```yaml
# prometheus-alerts-a800.yml
groups:
  - name: a800_inference_alerts
    rules:
      # A800 显存告警（80GB 大显存，KV Cache 碎片化是常见问题）
      - alert: A800_GPU_MEM_HIGH
        expr: DCGM_FI_DEV_FB_USED / (DCGM_FI_DEV_FB_USED + DCGM_FI_DEV_FB_FREE) > 0.92
        for: 5m
        labels: { severity: warning, priority: P2, gpu: A800-80GB }
        annotations:
          summary: "A800 GPU {{ $labels.gpu }} 显存使用率 > 92%，KV Cache 可能即将耗尽"

      # SM 占用率低 = GPU 空转（Decode 阶段正常 10-30%，但 < 5% 可能异常）
      - alert: A800_SM_Occupancy_Low
        expr: DCGM_FI_PROF_SM_OCCUPANCY < 5
        for: 10m
        labels: { severity: info, priority: P3 }
        annotations:
          summary: "A800 GPU {{ $labels.gpu }} SM 占用率持续 < 5%，可能服务已空载"

      # 温度告警（A800 最高工作温度 85°C，建议控制在 75°C 以下）
      - alert: A800_GPU_Temp_High
        expr: DCGM_FI_DEV_GPU_TEMP > 80
        for: 5m
        labels: { severity: warning, priority: P2 }
        annotations:
          summary: "A800 GPU {{ $labels.gpu }} 温度 > 80°C，请检查机房散热或降低负载"

      # vLLM 排队深度告警
      - alert: A800_VLLM_Queue_Deep
        expr: vllm:num_requests_waiting > 30
        for: 3m
        labels: { severity: warning, priority: P2 }
        annotations:
          summary: "A800 推理队列积压 > 30，当前排队: {{ $value }}，建议 HPA 扩容"
```

## 十四、上下游串联

```
                     AI Infra MLOps 监控可观测性全景
  ========================================================================

  ┌─────────────────────────────────────────────────────────────────────┐
  │                        告警与 SLO 层                                  │
  │   P1 紧急(立即响应) / P2 警告(30min内) / P3 通知(工作时间)           │
  │   错误预算追踪: 99.9% 可用 = 月宕机 < 43.2 分钟                      │
  └─────────────────────────────────────────────────────────────────────┘
       ▲
       │ Dashboard / AlertManager
       │
  ┌────┴────────────────────────────────────────────────────────────────┐
  │                    ★ 本文：监控与可观测 ★                             │
  │                                                                     │
  │  ┌──────────────┐  ┌──────────────────┐  ┌──────────────────┐     │
  │  │ GPU 硬件层    │  │   推理应用层       │  │   分布式追踪      │     │
  │  │ DCGM Exporter│  │ vLLM /metrics     │  │ OpenTelemetry    │     │
  │  │ SM Occ./温度  │  │ TTFT/TPOT/QPS     │  │ Gateway→vLLM     │     │
  │  │ 显存/XID/ECC │  │ Cache 使用率       │  │ Prefill→Decode   │     │
  │  └──────┬───────┘  └────────┬─────────┘  └────────┬─────────┘     │
  │         │                   │                     │                │
  └─────────┼───────────────────┼─────────────────────┼────────────────┘
            │                   │                     │
            v                   v                     v
  ┌─────────────────────────────────────────────────────────────────────┐
  │              Prometheus (采集) + Grafana (可视化)                    │
  │            scrape_interval: 5s, retention: 30d                      │
  └─────────────────────────────────────────────────────────────────────┘
       │
       │ 数据来源
       v
  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐
  │ K8s 编排  │  │ Slurm 调度 │  │ 网络/多租户│  │ 存储分发   │
  │ (doc #1)  │  │ (doc #4)  │  │ (doc #3)  │  │ (doc #5)  │
  │ kube-state │  │ sacct统计  │  │ NCCL指标  │  │ Lustre IO │
  │ metrics    │  │ GPU 计费   │  │ IB 带宽   │  │ NVMe 延迟 │
  └─────┬─────┘  └─────┬─────┘  └─────┬─────┘  └─────┬─────┘
        │              │              │              │
        └──────────────┴──────────────┴──────────────┘
                              │
                              v
                    ┌─────────────────┐
                    │   日志聚合层      │
                    │ Loki / ELK /     │
                    │ structlog JSON   │
                    └─────────────────┘

  本文角色：监控可观测性是 MLOps 的"眼睛和神经系统"。它从下层所有组件
  （K8s、Slurm、网络、存储）采集信号，向上层提供 SLO 衡量、告警触达、
  容量规划等决策依据。没有监控，运维就是在"盲飞"。
```

---

## 深入学习资源

- **DCGM 官方文档**: https://docs.nvidia.com/datacenter/dcgm/latest/
- **vLLM Metrics 文档**: https://docs.vllm.ai/en/latest/serving/metrics.html
- **Prometheus 官方教程**: https://prometheus.io/docs/tutorials/
- **Grafana Dashboard 最佳实践**: https://grafana.com/docs/grafana/latest/dashboards/
- **Google SRE Book**: https://sre.google/books/
- **OpenTelemetry Python**: https://opentelemetry.io/docs/instrumentation/python/
- **NVIDIA XID 错误码参考**: https://docs.nvidia.com/deploy/xid-errors/
