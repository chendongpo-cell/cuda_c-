#  第 1 章  Kubernetes (K8s) 高并发管理

##  1.1  写在前面：为什么要学 K8s 管理

GPU 硬件（NVIDIA A800）价格昂贵、资源稀缺，而上层的分布式训练（Megatron/DeepSpeed）、推理服务（Triton/vLLM）、数据处理（Spark/Flink）及存储服务（Lustre/MinIO）都需要协同配合。高效的编排调度平台是算力利用率最大化、运维成本最小化的关键。

Kubernetes (K8s) 已成为 AI 基础设施编排的事实标准，但**盲写 YAML 可能会直接拖垮一个集群**。本章的目的是帮助你**系统性地、从零到一**理解如何在 K8s 上高效、安全地运行 GPU 工作负载。

### 1.1.1  GPU Worker 示例（帮助理解）

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: gpu-training-pod
spec:
  restartPolicy: Never
  containers:
    - name: cuda-container
      image: nvidia/samples:vectoradd-cuda11.4.2
      resources:
        limits:
          nvidia.com/gpu: 2
```

>   **生产提示**：上面的示例只能运行 `nvidia-smi` 类的一次性任务，真正落地你需要完整的 Deployment/Job 和持久化存储（见本章后续部分）。

---

##  1.2  核心概念

### 1.2.1  管控循环（Control Loop）

K8s 的核心是声明式 API 与控制循环的闭环：

```text
     ┌──────────────────────────────┐
     │            API Server         │
     └──────────────┬───────────────┘
                    │
         ┌──────────┴──────────┐
         │                     │
    ┌────▼─────┐          ┌────▼─────┐
    │Scheduler │          │Controller│
    │          │          │ Manager  │
    └────┬─────┘          └────┬─────┘
         │                     │
    ┌────▼──────────────────────▼─────┐
    │             Kubelet             │
    │   (Container Runtime + Plugin)  │
    └─────────────────────────────────┘
```

- **API Server**：接收声明（Pod、Deployment、Job 等），持久化到 etcd。
- **Scheduler**：监听未绑定的 Pod，选择最适合的节点（CPU/内存/GPU/拓扑）。
- **Controller Manager**：运行各种控制器（Deployment、Job、DaemonSet 等），确保集群状态与声明一致。
- **Kubelet**：节点上的代理，接收调度结果，调用容器运行时启动容器，上报节点状态。
- **Device Plugin**：向 Kubelet 注册硬件资源（如 `nvidia.com/gpu`），是 GPU 可见的关键组件。

---

##  1.3  NVIDIA GPU Operator：一键部署完整 GPU 软件栈

NVIDIA GPU Operator 封装了以下组件：

```text
┌──────────────────────────────────────────────────────────────┐
│                    GPU Operator (Helm)                        │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│  │Driver        │  │Device Plugin │  │DCGM Exporter     │   │
│  │Container     │  │(nvidia.com/  │  │(GPU 监控指标)    │   │
│  │(提前编译驱动) │  │ gpu 资源)    │  │                  │   │
│  └──────────────┘  └──────────────┘  └──────────────────┘   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│  │MIG Manager   │  │GPU Feature   │  │K8s 验证 Webhook │   │
│  │(A100/A800    │  │Discovery     │  │(GPU 节点标签)    │   │
│  │ 实例分区)    │  │(自动标签)    │  │                  │   │
│  └──────────────┘  └──────────────┘  └──────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         Node Feature Discovery (NFD)                  │   │
│  │  硬件特性发现：PCIe ID、GPU 型号、CUDA 版本等          │   │
│  └──────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────┘
```

### 1.3.1  Operator 核心能力

| 组件 | 作用 | 说明 |
|------|------|------|
| **Driver Container** | 节点上自动安装 NVIDIA 驱动 | 无需手动 `apt install nvidia-driver-xxx` |
| **Device Plugin** | 让 Kubelet 识别 `nvidia.com/gpu` 资源 | Pod 通过 `limits.nvidia.com/gpu` 请求 GPU |
| **DCGM Exporter** | 输出 DCGM 指标（GPU 利用率/显存/温度等） | Prometheus 数据源 |
| **GPU Feature Discovery** | 为节点打上 GPU 型号、CUDA 版本等标签 | 调度器可据此精确调度 |
| **MIG Manager** | 支持 MIG（多实例 GPU）分区 | A100/A800 可将 1 张物理卡切分为最多 7 个实例 |
| **Sandboxed Workloads** | （可选）安全容器内使用 CUDA | 适用于多租户环境 |

### 1.3.2  部署示例（Helm）

```bash
# 1. 添加 NVIDIA Helm 仓库
helm repo add nvidia https://helm.ngc.nvidia.com/nvidia \
  && helm repo update

# 2. 安装 GPU Operator
helm install --wait --generate-name \
  -n gpu-operator --create-namespace \
  nvidia/gpu-operator

# 3. 验证 Device Plugin 是否正常
kubectl describe node <gpu-node> | grep nvidia.com/gpu
```

>   **注意**：Driver Container 需要节点允许特权容器。生产环境建议使用预装驱动的节点（跳过 Driver Container）。

---

## 1.4  GPU 调度策略

### 1.4.1  显式请求与节点选择

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: gpu-inference-pod
spec:
  containers:
    - name: vllm
      image: vllm/vllm-openai:latest
      resources:
        limits:
          nvidia.com/gpu: 4              #   A800 * 4
        requests:
          nvidia.com/gpu: 4              # 保证资源预留
      args:
        - "--model"
        - "/models/Qwen2.5-72B-Instruct"
        - "--tensor-parallel-size"
        - "4"
  nodeSelector:
    accelerator: nvidia-a800             #  仅 NVIDIA A800 节点
  tolerations:
    - key: "nvidia.com/gpu"
      operator: "Exists"
      effect: "NoSchedule"
```

### 1.4.2  GPU 亲和性（Topology-Aware Scheduling）

```yaml
spec:
  containers:
    - name: nccl-bench
      resources:
        limits:
          nvidia.com/gpu: 8
  affinity:
    podAntiAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        - labelSelector:
            matchLabels:
              app: nccl-allreduce
          topologyKey: kubernetes.io/hostname
```

> ** 关键提醒**：分布式训练（AllReduce）需要 GPU 间高带宽，尽可能将同组 GPU 调度到同一节点（NUMA 亲和），或在支持 NVSwitch 的节点上调度。

### 1.4.3  GPU 共享方式

| 共享方式 | 隔离强度 | 利用率 | 适用场景 |
|---------|---------|--------|---------|
| **整卡独占** |  强 | 低（碎片化） | 生产训练任务 |
| **MIG** |  强 | 中 | 小模型推理（A100/A800） |
| **MPS** |  弱 | 高 | 同租户多进程 |
| **Time-Slicing** |  无 | 高 | 开发测试（不建议生产） |

**MIG 分区示例**：

```bash
# 查看 A800 支持的分区方案
nvidia-smi mig -lgip
# 创建 2 个 3g.20gb 实例
nvidia-smi mig -cgi 9,9 -C
```

```yaml
# Pod 使用 MIG 设备
resources:
  limits:
    nvidia.com/mig-3g.20gb: 1
```

**Time-Slicing 配置**：

```yaml
# device-plugin-config.yaml
version: v1
sharing:
  timeSlicing:
    resources:
      - name: nvidia.com/gpu
        replicas: 8   # 1 张 GPU 模拟 8 个逻辑设备
```

---

##  1.5  存储管理

### 1.5.1  CSI (Container Storage Interface)

K8s 通过 CSI 支持多种存储后端：

```text
┌───────────────────────────────────────────────────────┐
│                     PVC (持久卷声明)                    │
│              "我需要 500GB SSD，读写速度 2GB/s"         │
└──────────────────────┬────────────────────────────────┘
                       │
┌──────────────────────▼────────────────────────────────┐
│                  StorageClass                           │
│   provisioner: nfs.csi.k8s.io / lustre.csi.xxx        │
│   parameters:                                          │
│     server: 10.128.0.100                              │
│     path: /data/models                                │
└───────────────────────────────────────────────────────┘
```

### 1.5.2  模型权重缓存（RWX vs RWO）

- **RWO (ReadWriteOnce)**：单节点独占，适合本地 SSD 训练数据。
- **RWX (ReadWriteMany)**：多节点共享，适合**模型权重仓库**（所有推理 Pod 需要读取同一份模型文件）。

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: model-qwen-72b
spec:
  accessModes:
    - ReadWriteMany           # 多个推理 Pod 可同时读取
  storageClassName: nfs-csi
  resources:
    requests:
      storage: 200Gi         # 72B 模型 ≈ 150GB + 冗余
---
apiVersion: apps/v1
kind: Deployment
spec:
  template:
    spec:
      containers:
        - name: vllm
          image: vllm/vllm-openai:latest
          volumeMounts:
            - name: models
              mountPath: /models
              readOnly: true
      volumes:
        - name: models
          persistentVolumeClaim:
            claimName: model-qwen-72b
```

---

##  1.6  推理服务部署实战

### 1.6.1  vLLM 多副本部署

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vllm-qwen-7b
spec:
  replicas: 3
  selector:
    matchLabels:
      app: vllm-qwen-7b
  template:
    metadata:
      labels:
        app: vllm-qwen-7b
    spec:
      containers:
        - name: vllm-server
          image: vllm/vllm-openai:v0.6.6.post1
          command:
            - python3
            - -m
            - vllm.entrypoints.openai.api_server
          args:
            - "--model"
            - "/models/Qwen2.5-7B-Instruct"
            - "--served-model-name"
            - "qwen2.5-7b"
            - "--port"
            - "8000"
            - "--gpu-memory-utilization"
            - "0.90"
            - "--max-model-len"
            - "8192"
          ports:
            - containerPort: 8000
              name: http
          resources:
            limits:
              nvidia.com/gpu: 1
              memory: "40Gi"
              cpu: "8"
            requests:
              nvidia.com/gpu: 1
              memory: "20Gi"
              cpu: "4"
          volumeMounts:
            - name: models
              mountPath: /models
              readOnly: true
          readinessProbe:
            httpGet:
              path: /health
              port: 8000
            initialDelaySeconds: 60      #   JIT 编译需要时间
            periodSeconds: 10
          livenessProbe:
            httpGet:
              path: /health
              port: 8000
            initialDelaySeconds: 120
            periodSeconds: 30
            failureThreshold: 3
      volumes:
        - name: models
          persistentVolumeClaim:
            claimName: model-qwen-7b
      nodeSelector:
        nvidia.com/gpu.product: NVIDIA-A800
```

### 1.6.2  服务暴露（Service + Ingress）

```yaml
apiVersion: v1
kind: Service
metadata:
  name: vllm-qwen-7b
spec:
  selector:
    app: vllm-qwen-7b
  ports:
    - port: 80
      targetPort: 8000
      protocol: TCP
      name: http
  type: ClusterIP
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: llm-gateway
  annotations:
    nginx.ingress.kubernetes.io/proxy-body-size: "10m"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "120"
    nginx.ingress.kubernetes.io/proxy-buffering: "off"    #   SSE 必配
spec:
  rules:
    - host: llm.internal.company.com
      http:
        paths:
          - path: /v1
            pathType: Prefix
            backend:
              service:
                name: vllm-qwen-7b
                port:
                  number: 80
```

---

##  1.7  监控体系

### 1.7.1  GPU 指标采集 (DCGM)

DCGM Exporter 默认端口 9400，Prometheus 自动发现：

```yaml
# ServiceMonitor (Prometheus Operator)
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: dcgm-exporter
spec:
  selector:
    matchLabels:
      app: dcgm-exporter
  endpoints:
    - port: metrics
      interval: 15s
```

**关键 GPU 指标：**

| Prometheus 指标 | 含义 | 告警建议 |
|-----------------|------|----------|
| `DCGM_FI_DEV_GPU_UTIL` | GPU 时间片利用率 | 持续 > 95% 表示饱和 |
| `DCGM_FI_DEV_FB_USED` | 已用显存 (MiB) | > 90% → Warning |
| `DCGM_FI_DEV_GPU_TEMP` | GPU 温度 (°C) | > 80°C → Warning, > 85°C → Critical |
| `DCGM_FI_DEV_XID_ERRORS` | XID 硬件错误 | 任意 > 0 → 紧急处理 |

### 1.7.2  推理服务指标

vLLM 暴露 `/metrics` 端点（OpenMetrics 格式）：

```text
vllm:num_requests_running
vllm:num_requests_waiting
vllm:gpu_cache_usage_perc
vllm:time_to_first_token_seconds_sum
vllm:time_per_output_token_seconds_sum
vllm:request_success_total
```

---

##  1.8  自动伸缩

### 1.8.1  HPA（水平自动伸缩）

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: vllm-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: vllm-qwen-7b
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Pods
      pods:
        metric:
          name: vllm_num_requests_waiting
        target:
          type: AverageValue
          averageValue: "5"           # 每个 Pod 排队 > 5 即扩容
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300   # 5 分钟后缩容（防止抖动）
    scaleUp:
      stabilizationWindowSeconds: 60
```

### 1.8.2  KEDA（事件驱动伸缩）

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: vllm-scaler
spec:
  scaleTargetRef:
    name: vllm-qwen-7b
  minReplicaCount: 2
  maxReplicaCount: 10
  triggers:
    - type: prometheus
      metadata:
        serverAddress: http://prometheus:9090
        metricName: vllm_waiting_requests
        query: sum(vllm:num_requests_waiting)
        threshold: "10"
```

---

##  1.9  滚动更新与零停机

```yaml
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1           # 更新期间允许超出 1 个 Pod
      maxUnavailable: 0     # 不允许出现不可用状态
  minReadySeconds: 30
```

> ⚠️ **重要**：模型更新时（如切换 LoRA 适配器），需确保新 Pod 的 readiness 检查通过后才终止旧 Pod。

---

##  1.10  故障排查速查表

| 问题 | 现象 | 排查命令 |
|------|------|----------|
| GPU 不可见 | `kubectl describe node` 无 `nvidia.com/gpu` | `kubectl logs -n gpu-operator <driver-pod>` |
| OOM Killed | Pod 被 Kill | 增大 `--gpu-memory-utilization 0.70` 或改用 MIG |
| NCCL 超时 | 多 Pod 训练长时间无输出 | 检查主机 NVLink 拓扑 (`nvidia-smi topo -m`) |
| 模型下载慢 | Pod 启动 10 分钟+ | 使用 PVC + initContainer 预下载 |
| SSE 流中断 | 客户端收不到流式数据 | Ingress 配置 `proxy-buffering: off` |

---

##  1.11  与 AI Infra 的关联

K8s GPU 编排是方向 D（MLOps）的核心。掌握本章内容后，你可以：

1.  **自动化部署**：一键拉起 vLLM/Triton 推理服务，无需手动 `python3 -m vllm...`
2.  **弹性伸缩**：根据请求队列深度自动增减 GPU 推理节点，降低运维成本
3.  **多租户隔离**：通过 MIG + Namespace + Network Policy 实现安全、高效的算力共享
4.  **可观测性**：整合 DCGM 指标与 vLLM 应用指标，构建统一监控告警

---

##  1.13  术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| **Device Plugin** | K8s 的"硬件翻译官"，让 Kubelet 听懂 `nvidia.com/gpu` 这种资源语言 | 1.2.1 管控循环 |
| **MIG (Multi-Instance GPU)** | 把一张 A800 "切蛋糕"，每个租户分到独立的一块，硬件级隔离 | 1.4.3 GPU 共享方式 |
| **CSI (Container Storage Interface)** | K8s 的"存储插座标准"，任何存储系统只要符合这个接口就能插上用 | 1.5.1 CSI |
| **HPA / KEDA** | HPA 是"自动阀门"按 CPU/内存调整副本数；KEDA 是"智能阀门"可以按 Prometheus 指标或消息队列深度伸缩 | 1.8 自动伸缩 |
| **DCGM Exporter** | GPU 的"健康手环"，把温度/显存/利用率/XID 错误等指标实时上报给 Prometheus | 1.7.1 GPU 指标采集 |

##  1.14  A800 部署场景举例

**场景一：8×A800 推理集群上部署 Qwen2.5-72B 服务**

在典型 8×A800 80GB 节点上通过 K8s 部署大模型推理：

```bash
# 1. 确认节点 GPU 资源（8×A800 80GB）
kubectl describe node gpu-node-01 | grep nvidia.com/gpu
# 预期输出: nvidia.com/gpu: 8

# 2. 创建 RWX PVC 存放模型权重（72B 约 150GB）
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: model-qwen-72b
spec:
  accessModes: [ReadWriteMany]
  storageClassName: nfs-csi
  resources:
    requests:
      storage: 200Gi
EOF

# 3. 部署 vLLM，TP=4 跨 4 张 A800 做张量并行
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: qwen-72b-tp4
spec:
  replicas: 1
  template:
    spec:
      containers:
        - name: vllm
          image: vllm/vllm-openai:v0.6.6.post1
          args:
            - "--model" "/models/Qwen2.5-72B-Instruct"
            - "--tensor-parallel-size" "4"
            - "--gpu-memory-utilization" "0.90"
            - "--max-model-len" "32768"
          resources:
            limits:
              nvidia.com/gpu: 4
              memory: "320Gi"
          volumeMounts:
            - name: models
              mountPath: /models
              readOnly: true
      volumes:
        - name: models
          persistentVolumeClaim:
            claimName: model-qwen-72b
      nodeSelector:
        nvidia.com/gpu.product: NVIDIA-A800-SXM4-80GB
EOF
```

**场景二：A800 MIG 多租户推理**

将单张 A800-80GB 切分为 4 个 2g.20gb MIG 实例，每个运行一个 7B 模型：

```bash
# 在 GPU 节点上配置 MIG
nvidia-smi -i 0 -mig 1
nvidia-smi mig -i 0 -cgi 14,14,14,14 -C  # 4×2g.20gb

# K8s Pod 申请 MIG 实例
resources:
  limits:
    nvidia.com/mig-2g.20gb: 1  # 申请 1 个 2g.20gb MIG 实例

# 一个 8×A800 节点最多承载 8×4=32 个 7B 模型推理实例
```

**场景三：基于 vLLM 排队深度的 HPA 自动伸缩**

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: qwen-72b-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: qwen-72b-tp4
  minReplicas: 1
  maxReplicas: 4   # 最多 4 副本 = 16 张 A800
  metrics:
    - type: Pods
      pods:
        metric:
          name: vllm_num_requests_waiting
        target:
          type: AverageValue
          averageValue: "10"  # 每副本排队 > 10 就触发扩容
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
    scaleUp:
      stabilizationWindowSeconds: 60
```

##  1.15  上下游串联

```
                     AI Infra MLOps 流水线 (方向 D)
  ========================================================================

  ┌──────────┐    ┌──────────┐    ┌─────────────┐    ┌──────────────┐
  │ 硬件层    │    │ 存储层    │    │  编排调度层   │    │  推理/训练层   │
  │ A800 GPU │    │ Lustre   │    │  ★ K8s ★    │    │ vLLM/Triton  │
  │ NVLink   │    │ NFS CSI  │    │  GPU Oper.  │    │ DeepSpeed    │
  │ IB/RoCE  │    │ MinIO    │    │  HPA/KEDA   │    │ Megatron     │
  └────┬─────┘    └────┬─────┘    └──────┬──────┘    └──────┬───────┘
       │               │               │                   │
       │          ┌────┴────┐     ┌────┴────┐         ┌────┴────┐
       │          │ 存储分发  │     │ 本 文 ★  │         │ 推理服务  │
       │          │ doc #5  │     │ K8s编排  │         │ 训练作业  │
       │          └─────────┘     └────┬────┘         └─────────┘
       │                              │
       v                              v
  ┌──────────────────────────────────────────────────────────────┐
  │                     监控与可观测 (doc #2)                      │
  │          DCGM → Prometheus → Grafana → AlertManager          │
  └──────────────────────────────────────────────────────────────┘
       │
       v
  ┌──────────────────────────────────────────────────────────────┐
  │                   网络与多租户 (doc #3)                        │
  │         InfiniBand / NCCL / MIG / NetworkPolicy              │
  └──────────────────────────────────────────────────────────────┘
       │
       v
  ┌──────────────────────────────────────────────────────────────┐
  │                    Slurm 训练调度 (doc #4)                     │
  │              批处理作业 / Fair-Share / 计费                   │
  └──────────────────────────────────────────────────────────────┘

  本文角色：K8s 是推理服务的"操作系统"，负责声明式部署、GPU 资源调度、
  自动伸缩和服务发现。上游依赖存储系统（模型 PVC）和网络（InfiniBand CNI），
  下游对接监控系统（DCGM 指标采集）和推理框架（vLLM/Triton）。
```

---

##  1.12  深入学习资源

- **NVIDIA GPU Operator 官方文档**：https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest
- **Kubernetes 官方文档 (GPU 调度)**：https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/
- **NVIDIA MIG 用户指南**：https://docs.nvidia.com/datacenter/tesla/mig-user-guide/
- **KEDA 官方文档**：https://keda.sh/docs
- **NVIDIA DeepOps**：https://github.com/NVIDIA/deepops （GPU 集群自动化部署参考）
- **Prometheus Operator**：https://prometheus-operator.dev
- **Kubernetes in Action (中文版)**：https://book.douban.com/subject/30450155/
