#   Slurm HPC 调度系统 — GPU 集群作业管理

> **方向 D：算力集群 MLOps** | 🟡 了解 | 难度：⭐⭐⭐

---

## 一、为什么 AI 集群用 Slurm

大多数 GPU 集群（高校、研究所、企业 AI 平台）采用 Slurm 而非 K8s 来管理训练作业，原因：

```
┌───────────────────────────────────────────────────────────────┐
│                      Slurm 的设计优势                          │
├───────────────────────────────────────────────────────────────┤
│  批处理优先    → 作业提交、排队、资源分配、完成后释放            │
│  GPU 原生支持  → --gres=gpu:8 即可申请 GPU，无需额外配置         │
│  HPC 级规模    → 单集群可管理数万节点，数十年验证                  │
│  公平调度      → fair-share、QoS、抢占、资源预留                   │
│  精确计费      → 按 GPU 小时、CPU 小时、内存小时精确统计           │
│  多节点协调    → srun 一键启动跨节点分布式任务                   │
└───────────────────────────────────────────────────────────────┘
```

Slurm 控制一台机器上的所有 GPU，确保同一时刻只有被授权的作业能使用 GPU，避免资源冲突。

---

## 二、Slurm 架构

```text
┌─────────────────────────────────────────────────────────────────┐
│                        slurmctld (控制器)                         │
│  - 维护集群状态（节点、分区、作业、资源）                           │
│  - 调度决策：哪个作业分配到哪些节点                                  │
│  - 运行在管理节点上                                               │
└──────────┬──────────────────────────────────┬───────────────────┘
           │                                  │
    ┌──────▼──────┐                    ┌──────▼──────┐
    │slurmdbd     │                    │   slurmd    │× N
    │ (数据库)     │                    │ (节点守护进程) │
    │             │                    │             │
    │ - 作业历史   │                    │ - 启动/停止   │
    │ - 计费数据   │                    │   作业任务    │
    │ - 用户/账户  │                    │ - 上报节点    │
    │   管理      │                    │   状态       │
    └─────────────┘                    │ - 资源监控    │
                                       └─────────────┘
```

- **slurmctld**：大脑，做调度决策
- **slurmd**：每台计算节点一个，执行作业、监控资源
- **slurmdbd**：持久化作业历史和计费数据（MariaDB/MySQL 后端）

---

## 三、核心概念

| 概念 | 说明 | 示例 |
|------|------|------|
| **Partition（分区）** | 节点的逻辑分组 | `gpu`（GPU 节点）、`cpu`（CPU 节点） |
| **Job（作业）** | 一次提交的批处理任务 | 训练脚本、推理服务 |
| **Job Step** | 作业内的一个步骤 | 数据预处理 → 训练 → 评估 |
| **Node（节点）** | 一台物理服务器 | node[001-064]（64 台 GPU 服务器） |
| **TRES** | 可追踪资源 | GPU、CPU、内存、能源 |
| **QoS** | 服务质量等级 | 优先级、资源上限、抢占权限 |
| **Account** | 账户（用于计费和 fair-share） | `team-nlp`、`team-cv` |

---

## 四、GPU 作业提交

### 4.1 交互式作业

```bash
# 申请 4 块 GPU，交互式 shell
srun --gres=gpu:4 --cpus-per-task=32 --mem=128G --time=02:00:00 --pty bash

# 进入后：
nvidia-smi                     # 验证 GPU 可见
python train.py --gpus 4       # 启动训练
```

### 4.2 批处理作业

```bash
#!/bin/bash
#SBATCH --job-name=train-llm-7b
#SBATCH --partition=gpu
#SBATCH --nodes=2                    # 2 个节点
#SBATCH --gres=gpu:8                 # 每节点 8 块 GPU = 共 16 块
#SBATCH --ntasks-per-node=8          # 每节点 8 个任务（1 per GPU）
#SBATCH --cpus-per-task=16           # 每个任务 16 CPU 核
#SBATCH --mem=500G                   # 每节点 500GB 内存
#SBATCH --time=72:00:00              # 最长运行 72 小时
#SBATCH --output=%j_%N.out           # 输出文件 (%j=jobid, %N=节点名)
#SBATCH --error=%j_%N.err            # 错误文件
#SBATCH --mail-type=END,FAIL         # 作业结束/失败时发邮件
#SBATCH --mail-user=user@company.com

# Slurm 自动设置环境变量：
# SLURM_JOB_ID, SLURM_NTASKS, SLURM_NODELIST
# 配合 torchrun：
export MASTER_ADDR=$(scontrol show hostname $SLURM_NODELIST | head -n1)
srun torchrun --nnodes=$SLURM_NNODES \
    --nproc_per_node=8 \
    --node_rank=$SLURM_NODEID \
    train.py
```

### 4.3 常用命令

```bash
sbatch job.sh                       # 提交作业
squeue                              # 查看队列
squeue -u $USER                     # 查看我的作业
squeue -p gpu                       # 查看 GPU 分区的作业
scancel <jobid>                     # 取消作业
scontrol show job <jobid>           # 查看作业详情
sinfo                               # 查看节点状态
sinfo -p gpu -o "%n %t %G %C %m"   # GPU 分区节点详细信息
sacct -j <jobid> --format=JobID,Elapsed,MaxRSS,ReqMem  # 作业资源使用
```

---

## 五、GPU 亲和性与拓扑

```bash
#SBATCH --gpus-per-node=8
#SBATCH --gpu-bind=closest          # 将 GPU 绑定到最近的 CPU socket
```

```
NUMA 节点拓扑（DGX A800 示例）：

NUMA Node 0 (CPU 0-31)            NUMA Node 1 (CPU 32-63)
    ├── GPU 0                         ├── GPU 4
    ├── GPU 1                         ├── GPU 5
    ├── GPU 2                         ├── GPU 6
    └── GPU 3                         └── GPU 7
    NVLink 互联                       NVLink 互联
    NVSwitch (可选)                   NVSwitch (可选)

--gpu-bind=closest 确保任务运行在离 GPU 最近的 CPU 上
避免跨 NUMA 节点的数据传输延迟
```

---

## 六、Partition 和 QoS 配置

### 6.1 典型分区设计

```
分区 "gpu-train"  ← 训练作业，可抢占推理
  - 节点：64×A800
  - 最大时间：168 小时（7 天）
  - 优先级：高
  - MaxJobs=1 per user（防止资源垄断）

分区 "gpu-inference" ← 推理服务，长期运行
  - 节点：8×A800
  - 最大时间：INFINITE
  - 优先级：中
  - 不允许抢占

分区 "gpu-debug" ← 开发调试
  - 节点：2×A800
  - 最大时间：2 小时
  - 优先级：最高
```

### 6.2 QoS 配置示例

```bash
# slurm.conf
PartitionName=gpu-train Nodes=gpu[001-064] MaxTime=168:00:00 Default=YES

# QoS
sacctmgr add qos normal
sacctmgr modify qos normal set GrpTRES=gres/gpu=64     # 组最大 64 GPU
sacctmgr modify qos normal set MaxTRESPerJob=gres/gpu=16 # 单作业最大 16 GPU
sacctmgr modify qos normal set MaxWall=72:00:00          # 单作业最长 72h
```

---

## 七、Job Array（参数扫描）

```bash
#!/bin/bash
#SBATCH --job-name=hparam-sweep
#SBATCH --array=1-100%10              # 100 个作业，最多 10 个并发
#SBATCH --gres=gpu:1

# SLURM_ARRAY_TASK_ID 自动递增
LR=$(sed -n "${SLURM_ARRAY_TASK_ID}p" lr_list.txt)
BATCH=$(sed -n "${SLURM_ARRAY_TASK_ID}p" batch_list.txt)

python train.py --lr $LR --batch-size $BATCH
```

---

## 八、分布式训练集成

### 8.1 与 torchrun 结合

```bash
#!/bin/bash
#SBATCH --nodes=4
#SBATCH --gres=gpu:8
#SBATCH --ntasks-per-node=8

# 获取主节点地址
MASTER_ADDR=$(scontrol show hostname $SLURM_NODELIST | head -n1)

# 所有 GPU 任务在 srun 中启动
srun --ntasks=$SLURM_NTASKS \
    torchrun \
        --nnodes=$SLURM_NNODES \
        --nproc_per_node=8 \
        --rdzv_backend=c10d \
        --rdzv_endpoint=$MASTER_ADDR:29500 \
        train.py \
        --model megatron-llm \
        --tensor-parallel-size 4 \
        --pipeline-parallel-size 2
```

### 8.2 与 DeepSpeed 结合

```bash
srun --ntasks=$SLURM_NTASKS \
    deepspeed \
        --num_nodes=$SLURM_NNODES \
        --num_gpus=8 \
        train.py \
        --deepspeed_config ds_config.json
```

---

## 九、Fair-Share 调度

```
优先级 = 历史使用量 / 分配份额

用户 A（份额 1000）：
  历史使用：5000 GPU-hours → 优先级 = 5000/1000 = 5.0

用户 B（份额 1000）：
  历史使用：100 GPU-hours  → 优先级 = 100/1000 = 0.1  ← 优先级更高！

长期多占资源的用户优先级降低，确保新人也能获得资源。
历史使用随时间衰减（半衰期通常 7-14 天）。
```

```bash
# 查看 fair-share 信息
sshare -u $USER
sshare -A team-nlp
```

---

## 十、容器支持（Enroot + Pyxis）

```bash
# 使用容器运行 GPU 作业
srun --gres=gpu:4 \
    --container-image=nvcr.io#nvidia/pytorch:24.01-py3 \
    --container-mounts=/data:/data \
    python train.py
```

```
Enroot：NVIDIA 的轻量级容器运行时（无守护进程，用户态）
Pyxis：Slurm 插件，让 srun/sbatch 支持 --container-image 参数

优势：
  - 无需 root 权限
  - 无 Docker daemon 依赖
  - 自动挂载 GPU 设备和驱动
```

---

## 十一、GPU 计费与统计

```bash
# 查看作业 GPU 使用情况
sacct -j <jobid> --format=JobID,User,Account,Elapsed,AllocTRES,ReqTRES

# 查看用户 GPU 使用统计
sreport user TopUsage TopCount=10 Start=2024-01-01 End=2024-01-31 \
    -t gres/gpu

# 查看账户 GPU 使用
sacct -A team-nlp --starttime=2024-01-01 --format=JobID,Elapsed,AllocTRES
```

**常用计费公式**：
```
费用 = GPU数量 × 运行小时 × 单价（元/GPU-小时）
```

---

## 十二、Slurm vs K8s 选型决策

| 维度 | Slurm | Kubernetes |
|------|-------|------------|
| 作业类型 | 批处理（训练） | 长期服务（推理） |
| GPU 调度 | 原生 `--gres=gpu:8` | 需 GPU Operator |
| 弹性伸缩 | 无（固定节点数） | 原生支持 HPA/KEDA |
| 多节点启动 | `srun` 原生支持 | 需 MPI Operator |
| 调度粒度 | 作业级（整块 GPU） | Pod 级（可 MIG/TimeSlice） |
| 网络要求 | InfiniBand 原生支持 | 需额外配置 |
| 运维复杂度 | 较低，HPC 团队熟悉 | 较高，需 K8s 专业知识 |
| 社区 | 传统 HPC | 云原生 |

**混合方案（推荐）**：
```
Slurm → 管理训练作业（占集群 80% 算力）
  └── 预留 2-4 台 GPU 节点给 K8s
      └── K8s → 管理推理服务（长期运行、弹性伸缩）
```

---

## 十三、常见问题与排查

### 作业一直 Pending？

```bash
# 检查原因
scontrol show job <jobid> | grep Reason

# 常见原因：
# "Resources"       → 资源不足（GPU 被占用）
# "Priority"        → 优先级不够，前面有人排队
# "QOSMaxGRES"     → 超出 QoS GPU 限制
# "PartitionTimeLimit" → 分区时间限制不够
# "AssocGrpGRES"    → 账户组 GPU 配额用完
```

### 节点状态异常？

```bash
sinfo -R                           # 查看异常节点及原因
scontrol show node <nodename>      # 查看节点详细信息

# 常见状态：
# down  → 节点挂了
# drain → 管理员排空了节点（维护中）
# drng → 排空中
# resv → 已预留
```

### GPU 不可见？

```bash
# 查看节点 GPU 配置
scontrol show node <nodename> | grep Gres

# 验证 GPU 驱动
ssh <nodename> nvidia-smi

# NFS/Lustre 挂载异常 → 作业启动失败（不是 Slurm 的问题）
ssh <nodename> df -h /data
```

---

## 十四、与 AI Infra 的关联

Slurm 是大部分 GPU 集群的入口。掌握 Slurm 后你可以：

1. **提交大规模训练作业**：2000 卡训练 GPT-3 级别模型
2. **管理资源配额**：公平分配 GPU 资源给不同团队
3. **追踪 GPU 利用率**：通过计费数据发现资源浪费
4. **设计混合调度方案**：Slurm 管训练 + K8s 管推理

---

## 十五、术语速查

| 术语 | 一句话类比 | 详见章节 |
|------|-----------|----------|
| **Partition（分区）** | Slurm 的"资源分类标签"——把 GPU 节点分为 train、inference、debug 等不同的逻辑池 | 六、Partition 和 QoS |
| **QoS (Quality of Service)** | GPU 集群的"VIP 会员等级"——限制每个用户/组最多用多少 GPU、最长跑多久、能否抢占别人 | 6.2 QoS 配置示例 |
| **Fair-Share** | "多退少补"的公平调度——用得越多优先级越低，确保新人也能排到 GPU | 九、Fair-Share 调度 |
| **TRES (Trackable Resources)** | Slurm 的"计费科目"——GPU、CPU、内存、能源都可以按小时精确统计和计费 | 十一、GPU 计费与统计 |
| **Job Array** | 超参数搜索的"批量订单"——一次提交 100 个不同学习率的任务，自动按顺序或并发执行 | 七、Job Array |
| **Enroot + Pyxis** | Slurm 的"免 root 容器方案"——不需要 Docker daemon，用户态即可用 `--container-image` 跑 GPU 容器 | 十、容器支持 |

## 十六、A800 部署场景举例

**场景一：64 节点 8×A800 集群 Slurm 分区设计**

典型 64 节点 8×A800 80GB 集群的生产级分区配置：

```bash
# slurm.conf — A800 集群分区配置
# 64 节点 = 512 张 A800，按用途分为三个分区

# 训练分区：56 节点 × 8 A800，单作业最长 7 天
PartitionName=gpu-train Nodes=gpu[001-056] MaxTime=168:00:00 Default=YES
  State=UP

# 推理分区：6 节点 × 8 A800，长期运行不限制时间
PartitionName=gpu-inference Nodes=gpu[057-062] MaxTime=INFINITE
  State=UP Default=NO

# 调试分区：2 节点 × 8 A800，最长 2 小时，最高优先级
PartitionName=gpu-debug Nodes=gpu[063-064] MaxTime=2:00:00
  State=UP Default=NO Priority=high

# QoS 策略
sacctmgr add qos normal
sacctmgr modify qos normal set \
  GrpTRES=gres/gpu=256 \          # 每组最多 256 张 A800
  MaxTRESPerJob=gres/gpu=64 \     # 单作业最多 64 张 A800 (8 节点)
  MaxWall=72:00:00                 # 单作业最长 72 小时

sacctmgr add qos inference
sacctmgr modify qos inference set \
  GrpTRES=gres/gpu=48 \           # 推理组最多 48 张 A800
  MaxWall=INFINITE \               # 推理服务长期运行
  PreemptExemptTime=INFINITE       # 不可被抢占
```

**场景二：A800 大规模分布式训练作业提交**

在 8 节点 × 8 A800（共 64 卡）上训练 70B 模型：

```bash
#!/bin/bash
#SBATCH --job-name=train-70b-64gpu
#SBATCH --partition=gpu-train
#SBATCH --nodes=8                     # 8 个 A800 节点
#SBATCH --gres=gpu:8                  # 每节点 8 张 A800 = 共 64 卡
#SBATCH --ntasks-per-node=8           # 每节点 8 个 task (1 per GPU)
#SBATCH --cpus-per-task=16            # 每 task 16 核 CPU（A800 节点通常 2×64C）
#SBATCH --mem=0                       # 使用节点全部内存（约 2TB）
#SBATCH --time=72:00:00              # 最长 72 小时
#SBATCH --output=/lustre/logs/%j_%N.out
#SBATCH --qos=normal

# IB 网络环境设置
export NCCL_IB_HCA=mlx5_0,mlx5_1    # A800 节点 ConnectX-6 IB 网卡
export NCCL_IB_GID_INDEX=3
export NCCL_DEBUG=WARN

# 获取主节点地址
MASTER_ADDR=$(scontrol show hostname $SLURM_NODELIST | head -n1)

# 启动 64 卡分布式训练
srun --ntasks=$SLURM_NTASKS \
    torchrun \
        --nnodes=$SLURM_NNODES \
        --nproc_per_node=8 \
        --rdzv_backend=c10d \
        --rdzv_endpoint=$MASTER_ADDR:29500 \
        train.py \
        --model llama-70b \
        --global-batch-size 4096 \
        --tensor-parallel-size 4 \
        --pipeline-parallel-size 2

# 查看作业 GPU 使用情况（作业完成后）
sacct -j $SLURM_JOB_ID --format=JobID,User,Elapsed,AllocTRES%40,MaxRSS
```

**场景三：A800 集群 Fair-Share + 计费**

```bash
# 按团队配置 Account 和份额
sacctmgr add account team-nlp  FairShare=1000
sacctmgr add account team-cv   FairShare=500
sacctmgr add account team-asr  FairShare=300

# 添加用户到对应账户
sacctmgr add user alice Account=team-nlp
sacctmgr add user bob   Account=team-cv

# 查看 Fair-Share 排名（值越低优先级越高）
sshare -a --format=User,Account,FairShare,LevelFS

# 月度 GPU 使用报告
sreport cluster UserUtilizationByAccount \
  Start=2026-06-01 End=2026-07-01 \
  format=Account,Used,Allocated -t gres/gpu

# 按 15 元/GPU-小时 计算团队费用
# team-nlp: 用了 12000 GPU-hr × 15 = 180,000 元/月
```

## 十七、上下游串联

```
                   AI Infra HPC 调度生态位 (方向 D)
  ========================================================================

  ┌─────────────────────────────────────────────────────────────────────┐
  │                         用户 / 团队                                   │
  │    提交训练任务、查询排队状态、申请 GPU 配额                         │
  └──────────────────────────────┬──────────────────────────────────────┘
                                 │ sbatch / srun / salloc
                                 v
  ┌─────────────────────────────────────────────────────────────────────┐
  │                    ★ 本文：Slurm HPC 调度 ★                           │
  │                                                                     │
  │   ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐   │
  │   │ slurmctld (大脑) │  │ slurmdbd (数据库)│  │ slurmd (执行器) │   │
  │   │ 调度决策         │  │ 作业历史/计费     │  │ 每节点 × N      │   │
  │   │ Partition/QoS   │  │ Fair-Share       │  │ GPU 监控/上报   │   │
  │   │ 公平分配         │  │ Account 管理     │  │ 容器(Enroot)    │   │
  │   └────────┬────────┘  └────────┬────────┘  └────────┬────────┘   │
  │            │                    │                    │              │
  └────────────┼────────────────────┼────────────────────┼──────────────┘
               │                    │                    │
               v                    v                    v
  ┌─────────────────────────────────────────────────────────────────────┐
  │                        物理 GPU 资源层                               │
  │                                                                     │
  │   ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
  │   │ A800 × 8 │  │ A800 × 8 │  │ A800 × 8 │  │ A800 × 8 │  ...     │
  │   │ NVSwitch │  │ NVSwitch │  │ NVSwitch │  │ NVSwitch │          │
  │   │ IB HDR   │  │ IB HDR   │  │ IB HDR   │  │ IB HDR   │          │
  │   └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘          │
  │        │             │             │             │                  │
  │        └─────────────┴─────────────┴─────────────┘                  │
  │                          │                                         │
  │              Lustre / NFS 共享存储 (doc #5)                         │
  │              InfiniBand 互联网络 (doc #3)                           │
  └─────────────────────────────────────────────────────────────────────┘
               │
               │ 计量与监控
               v
  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
  │  K8s 编排(doc #1)│  │ 监控(doc #2)     │  │ 存储(doc #5)     │
  │ (推理服务)       │  │ DCGM 指标采集    │  │ Checkpoint 落盘 │
  │ HPA 自动伸缩     │  │ Grafana 仪表盘   │  │ 训练数据加载    │
  └──────────────────┘  └──────────────────┘  └──────────────────┘

  本文角色：Slurm 是 AI 训练集群的"中央调度室"。它决定"哪个团队/用户"
  在"哪些 GPU 节点"上运行"什么训练任务"并"多长时间"。Slurm 管理集群中
  约 80% 的 GPU 算力（训练任务），K8s 管理剩余 20%（推理服务）。
  Slurm 向上游对接用户（sbatch/srun），向下游依赖网络（IB/NCCL）和
  存储（Lustre checkpoint），向侧面被监控系统采集指标（sacct 计费）。
```

---

## 深入学习资源

- **Slurm 官方文档**：https://slurm.schedmd.com
- **Slurm GPU 调度指南**：https://slurm.schedmd.com/gres.html#GPU
- **Enroot 文档**：https://github.com/NVIDIA/enroot
- **Pyxis Slurm 插件**：https://github.com/NVIDIA/pyxis
- **NVIDIA DGX Slurm 最佳实践**：https://docs.nvidia.com/dgx/
- **Slurm 邮件列表**：https://slurm.schedmd.com/mail.html
