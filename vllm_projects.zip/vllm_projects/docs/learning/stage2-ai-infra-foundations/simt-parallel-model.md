# SIMT 并行执行模型：GPU 计算的基石

> **学习目标**：深入理解 GPU 的 SIMT 执行模型，掌握 warp 调度、延迟隐藏、occupancy 计算和 roofline 分析，为 AI Infra 工作（kernel 优化、推理引擎开发）打下扎实的硬件基础。
>
> **前置知识**：基本的 CUDA 编程概念（thread、block、grid），对 GPU 硬件有初步了解。
>
> **预计学习时间**：4-6 小时（仔细阅读 + 动手验证）

---

## 白话引入：流水线上的 32 个工人

想象一条高科技流水线。传送带上有 1024 个待组装的芯片，工头一声令下——但不是 1024 个工人各做各的，而是 32 个工人一组，同时拿起螺丝刀，同时拧同一个位置的螺丝。下一拍，32 个人同时拿起烙铁，同时焊同一个引脚。再下一拍，32 个人同时拿起放大镜，同时检查同一个焊点。

这 32 个工人不能有人"私自做不同的事"——如果工头喊"拧螺丝"，所有人都必须拧螺丝，不能有人在旁边偷偷焊引脚。如果某个工人的芯片上没有那颗螺丝（比如它是另一个型号），那他只能空着手干等着——但他不能跳过这一步去做别的。

**这就是 SIMT（Single Instruction, Multiple Threads）——GPU 的最底层执行模型。**

32 个线程组成一个 **Warp**（NVIDIA）或 64 个线程组成一个 **Wavefront**（AMD），是 GPU 硬件执行的最小单位。在一个 Warp 内部，所有线程在同一时刻执行同一条指令，只是操作不同的数据。这意味着：

1. **"看起来是标量代码，实际上在并行执行"**：你写 `c[i] = a[i] + b[i]`，看起来是给一个线程写的，但实际上 Warp 内 32 个线程同时执行这条加法，只是 `i` 不同。
2. **"if-else 是性能杀手"**：如果一个 Warp 内前半线程走 `if`，后半线程走 `else`，它们不能同时执行——必须串行：先执行 `if` 路径（后半线程空等），再执行 `else` 路径（前半线程空等）。这叫 **Warp Divergence**，是最常见的 GPU 性能陷阱。
3. **"GPU 不怕慢，只怕闲着"**：GPU 不像 CPU 有巨大的缓存来减少延迟。它的策略是"用并行度换延迟"——当一个 Warp 在等数据从显存读回来（可能要等 800 个时钟周期），调度器立刻切换到另一个就绪的 Warp。只要有足够多的 Warp 可以轮换，ALU 就永远不会闲着。这就是**延迟隐藏（Latency Hiding）**——GPU 最优雅的设计哲学。

理解 SIMT，你就能从根本上回答以下 AI Infra 核心问题：
- 为什么 Decode 阶段 GPU 利用率只有 30% 但却是"正常的"？→ 因为它是 Memory-Bound，Warp 都在等显存数据。
- 为什么 FlashAttention 要把 attention matrix 切成小块在 shared memory 里算？→ 因为 HBM 读一次要 800 cycles，而 shared memory 只要 20 cycles，把数据搬到片上然后反复用，算术强度就能跨过 Roofline 转折点。
- 为什么 vLLM 的 PagedAttention 能提高吞吐？→ 因为它把 KV Cache 碎片化问题解决了，能塞进更多并发请求，每个 SM 上有更多 Warp 可以轮换，延迟隐藏效果更好。

本文从 SIMT 的概念出发，深入到 Warp 调度、延迟隐藏机制、A800 SM 架构、Roofline 模型和 DCU 国产加速卡架构，帮你建立从硬件到框架的完整认知链。

---

## 术语预检

| 术语 | 英文/全称 | 一句话解释 |
|------|----------|-----------|
| **SIMT** | Single Instruction, Multiple Threads | GPU 核心执行模型：一个 Warp 内的 32 个线程在同一时刻执行同一条指令，但操作不同数据 |
| **Warp** | — | NVIDIA GPU 的硬件执行最小单位，固定 32 个线程。一个 SM 上最多可驻留 64 个 Warp |
| **Wavefront** | — | AMD GPU 的硬件执行最小单位，固定 64 个线程。是 AMD CDNA 架构的 Warp 等价概念 |
| **SM** | Streaming Multiprocessor | NVIDIA GPU 的核心计算单元。A800 有 108 个 SM，每个 SM 包含 4 个 Warp Scheduler、64 个 FP32 Core、4 个 Tensor Core |
| **Occupancy** | — | SM 上活跃 Warp 数 ÷ 最大 Warp 数。决定延迟隐藏能力。不是越高越好——算术密集 kernel 25-50% 可能就够 |
| **Roofline** | Roofline Model | 将 kernel 性能上界与两个硬件极限（算力 TFLOPS、显存带宽 TB/s）联系的"第一性原理"分析模型。桥梁是算术强度（FLOPs/Byte） |

---

## 目录

1. [SIMT: Single Instruction, Multiple Threads](#1-simt-single-instruction-multiple-threads)
2. [Warp 执行模型](#2-warp-执行模型)
3. [延迟隐藏 (Latency Hiding)](#3-延迟隐藏-latency-hiding)
4. [A800 (GA100) SM 架构深入](#4-a800-ga100-sm-架构深入)
5. [Roofline 模型](#5-roofline-模型)
6. [DCU 架构（国产加速卡）](#6-dcu-架构国产加速卡)
7. [为什么这些对 AI Infra 至关重要](#7-为什么这些对-ai-infra-至关重要)
8. [易混淆技术辨析](#8-易混淆技术辨析)
9. [AI Infra 专家视角](#9-ai-infra-专家视角)
10. [深入学习资源](#10-深入学习资源)

---

## 1. SIMT: Single Instruction, Multiple Threads

### 1.1 核心概念

SIMT（Single Instruction, Multiple Threads）是 NVIDIA GPU 最核心的执行模型。它的本质是：

> **所有 warp 内的线程在同一时刻执行同一条指令，但操作不同的数据。**

这不是一个实现细节——它是理解 GPU 上一切性能行为的基础。你写的每一行 CUDA kernel，最终都在 SIMT 的约束下运行。

```
+---------------------------------------------------------------------------+
|                           SIMT 执行示意                                    |
|                                                                           |
|   指令流 (单一 PC)                                                         |
|   +--------------+                                                        |
|   |  LD R0,      |---> Thread 0:  LD R0, a[0]    (从 a[0] 加载)          |
|   |  [a+idx]     |---> Thread 1:  LD R0, a[1]    (从 a[1] 加载)          |
|   |              |---> Thread 2:  LD R0, a[2]    (从 a[2] 加载)          |
|   |              |---> ...                                                |
|   |              |---> Thread 31: LD R0, a[31]  (从 a[31] 加载)          |
|   +--------------+                                                        |
|   +--------------+                                                        |
|   |  FMA R2,     |---> Thread 0..31: 同时执行乘加，不同数据               |
|   |  R0,R1,R2    |                                                        |
|   +--------------+                                                        |
|   +--------------+                                                        |
|   |  ST [c+idx], |---> Thread 0..31: 存储到不同位置                       |
|   |  R2          |                                                        |
|   +--------------+                                                        |
|                                                                           |
|   关键点：所有 32 个线程共享同一个 PC（Program Counter）                   |
|   它们在 SIMD 单元上以"锁步"(lockstep) 方式执行                            |
+---------------------------------------------------------------------------+
```

### 1.2 详细对比：SIMT vs CPU SIMD

理解 SIMT 最好的方式是把它和你可能已经熟悉的 CPU SIMD 进行对比。

| 维度 | CPU SIMD (AVX-512) | CPU SIMD (ARM NEON) | GPU SIMT (NVIDIA) |
|------|---------------------|----------------------|--------------------|
| **宽度** | 512 bits (16x FP32) | 128 bits (4x FP32) | 32 threads (1024 bits FP32 等效) |
| **指令集** | 显式 SIMD 指令 (vaddps) | 显式 SIMD 指令 (fadd) | 标量指令，硬件自动广播 |
| **编程模型** | 显式向量化 (intrinsics/auto-vec) | 显式向量化 | 标量编程，隐式并行 |
| **分支处理** | 程序员手动处理 mask | 程序员手动处理 | 硬件 SIMT stack + 谓词 |
| **寄存器** | 512-bit 向量寄存器 (zmm0-zmm31) | 128-bit 向量寄存器 (v0-v31) | 每线程私有标量寄存器 |
| **上下文切换** | OS 级，数百 cycles | OS 级 | 硬件零开销 warp 切换 |
| **线程数** | 核数 × 2 (HT) | 核数 × 1-2 | 数千个 warp 同时驻留 |

**核心区别：编程模型**

CPU SIMD 要求程序员显式地思考向量化：

```c
// CPU AVX-512: 显式向量编程
#include <immintrin.h>
void add_arrays_avx512(float* a, float* b, float* c, int n) {
    for (int i = 0; i < n; i += 16) {
        // 显式加载 512-bit (16 个 float) 到向量寄存器
        __m512 va = _mm512_loadu_ps(&a[i]);
        __m512 vb = _mm512_loadu_ps(&b[i]);
        // 显式向量加法
        __m512 vc = _mm512_add_ps(va, vb);
        _mm512_storeu_ps(&c[i], vc);
    }
}
```

GPU SIMT 允许你写标量代码，硬件自动并行化：

```cuda
// CUDA SIMT: 看起来是标量代码，实则 32 线程并行执行
__global__ void add_arrays(float* a, float* b, float* c, int n) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        c[idx] = a[idx] + b[idx];  // 看起来是标量，实则 warp 内 32 线程同时执行
    }
}
```

这是 SIMT 最大的编程优势：**编程人员的思维模型是标量的、逐线程的，但硬件执行模型是并行的、SIMD 的。** 你写的是 `threadIdx.x`，不需要写 `_mm512_add_ps`。

### 1.3 SIMT vs SMT (Simultaneous Multi-Threading)

很多人会混淆 SIMT 和 SMT（Intel 的超线程/Hyper-Threading）。它们名字相似但目的完全不同：

```
+---------------------------------------------------------------------------+
|              SIMT (GPU)              vs         SMT (CPU)                  |
|                                                                           |
|  SIMT: 同一指令，多线程数据并行             SMT: 利用空闲执行单元跑另一线程  |
|                                                                           |
|  GPU Warp:                                CPU Core with SMT:              |
|  +---+ +---+ +---+ ... +---+             +----------+ +----------+        |
|  |T0 | |T1 | |T2 |     |T31|             | Thread A | | Thread B |        |
|  +---+ +---+ +---+ ... +---+             | (整数运算)| | (浮点运算)|        |
|    |     |     |         |               +----------+ +----------+        |
|    +--+--+--+--+----+----+                         \        /             |
|       |              |                              \      /              |
|    +--v--------------v--+                           +------+               |
|    | 同一条指令 (FMA)    |                          | CPU  |               |
|    | 不同数据元素        |                          | Core |               |
|    +--------------------+                          +------+               |
|                                                                           |
|  目标: 数据并行 (吞吐量)                      目标: 隐藏延迟 (利用率)      |
|  同一指令在不同数据上执行                      不同指令交织执行              |
|  每个线程做同样的事                           每个线程做不同的事            |
+---------------------------------------------------------------------------+
```

| 特性 | SIMT (GPU) | SMT / Hyper-Threading (CPU) |
|------|------------|----------------------------|
| **目标** | 数据级并行，最大化吞吐量 | 隐藏指令/访存延迟，提高利用率 |
| **线程行为** | 所有线程执行相同指令 | 各线程独立执行不同指令 |
| **寄存器** | 每个线程独立寄存器文件 | 共享物理寄存器文件 (重命名) |
| **切换粒度** | warp 级，零开销 | 线程级，有上下文切换开销 |
| **硬件支持** | 每 warp 独立 PC、栈 | 共享取指/译码，复制架构状态 |
| **典型规模** | 数千线程驻留在 SM | 每个核心 2 线程 |

### 1.4 历史演进：从图形着色器到 AI 加速器

SIMT 并非凭空产生，它根植于 GPU 的图形渲染起源：

```
1999-2006: 固定功能管线
    GeForce 256 → 顶点/像素着色器 (固定功能，不可编程)
    |
    v
2006-2012: 统一着色器模型
    G80 (8800 GTX): 首个统一着色器架构
    - 引入 CUDA，推出 SIMT 概念
    - 128 CUDA cores, 每个 SM 有 8 个 SP
    - Tesla 架构: warp = 32 threads
    |
    v
2012-2017: 通用计算深化
    Kepler  (GK110): Dynamic Parallelism, Hyper-Q, 共享内存可配置
    Maxwell (GM204): 改进能效，每 SM 拆分为 4 个子分区
    Pascal  (GP100): HBM2, NVLink, FP16 支持
    |
    v
2017-2020: AI 专用硬件
    Volta  (GV100): 首个 Tensor Core! 640 TOPS (FP16)
    Turing (TU102): RT Core (光追), INT8/INT4 Tensor Core
    |
    v
2020-至今: 数据中心 AI
    Ampere (GA100): 第三代 Tensor Core, TF32, 结构化稀疏
                   A100: 312 TFLOPS (FP16 Tensor Core)
    Hopper  (GH100): 第四代 Tensor Core, FP8, Transformer Engine
                   H100: 989 TFLOPS (FP8 Tensor Core)
    Blackwell (GB100): 第五代 Tensor Core, FP4, 第二代 Transformer Engine
                   B200: 4.5 PFLOPS (FP4 Tensor Core)
```

每一次架构迭代，都在增加 Tensor Core 的能力。但 SIMT 模型始终是底层基础——Tensor Core 也是 warp 内的线程协同执行的。

### 1.5 编程幻觉：每个线程都是独立的

这是理解 SIMT 最关键的一点，也是最容易被忽视的：

```
如果你觉得每个线程是独立执行的，那你就错了。
如果你觉得所有线程完全同步，那你也错了。
真相在两者之间——它们看起来独立，但在 warp 内部是锁步的。
```

**你写代码时要像每个线程独立运行一样去思考**（这是 NVIDIA 给你的编程抽象），但**你做性能优化时必须意识到 warp 内线程是锁步的**（这是硬件的真实情况）。

举个例子说明这种"编程抽象 vs 硬件真相"的张力：

```cuda
// 这段代码"看起来"每个线程独立做判断
__global__ void divergent_kernel(float* data, int n) {
    int idx = threadIdx.x;
    if (idx % 2 == 0) {
        data[idx] = data[idx] * 2.0f;  // 偶数线程：乘 2
    } else {
        data[idx] = data[idx] + 1.0f;  // 奇数线程：加 1
    }
}

// 编程模型视角：32 个线程各自执行各自的分支，看起来是并行的
// 硬件真相：warp 内只能有一条指令在执行。执行流程：
//   步骤 1: 偶数线程执行 data[idx]*2.0f，奇数线程被"屏蔽"(predicated off)
//   步骤 2: 奇数线程执行 data[idx]+1.0f，偶数线程被"屏蔽"
//   结果：这个 warp 花了 2 倍的时间，只有 50% 的利用率
```

这就是所谓的 **warp divergence（warp 发散）**，我们会在第 2 节深入讨论。

---

## 2. Warp 执行模型

### 2.1 Warp：最小的执行单元

在 NVIDIA GPU 中，**warp 是硬件执行的最小单位**。无论你 launch 了多少个 thread，硬件总是以 32 个线程为一组（一个 warp）来调度和执行。

```
+---------------------------------------------------------------------------+
|                        Block / Warp 层级关系                               |
|                                                                           |
|   Grid                                                                   |
|   +-- Block (0,0) --------+                                             |
|   |  +-- Warp 0 ----------+  +-- Warp 1 ----------+  +-- Warp 2 -----+  |
|   |  | T0  T1  T2  ... T31|  | T32 T33 T34 ... T63|  | T64 ... T95  |  |
|   |  +--------------------+  +--------------------+  +---------------+  |
|   |  +-- Warp 3 ----------+  +-- ...              |                    |
|   |  | T96 ... T127       |                       |                    |
|   |  +--------------------+                       |                    |
|   +------------------------------------------------+                   |
|                                                                           |
|   Block (1,0)                                                             |
|   +------------------------------------------------+                   |
|   |  Warp 0, Warp 1, Warp 2, ...                   |                   |
|   +------------------------------------------------+                   |
|                                                                           |
|   关键规则：                                                               |
|   - 1 warp = 32 threads (自 G80 以来从未变过)                             |
|   - Block 中的线程按 threadIdx 顺序分组为 warp                             |
|   - Warp 0: threadIdx.x = 0..31                                           |
|   - Warp 1: threadIdx.x = 32..63                                          |
|   - 多层 blockDim：threadIdx.z 变化最慢，threadIdx.x 变化最快             |
+---------------------------------------------------------------------------+
```

### 2.2 Lockstep（锁步）执行

```
+---------------------------------------------------------------------------+
|                      Lockstep 执行时序图                                   |
|                                                                           |
|   时间轴 (cycles)                                                         |
|   |                                                                       |
|   | Cycle 0:  [========== 指令获取/译码 ==========]                       |
|   |           所有 32 个线程的指令是同一个!                                 |
|   |                                                                       |
|   | Cycle 1:  [========== 操作数读取 ==============]                      |
|   |           T0读reg0   T1读reg1   T2读reg2 ... T31读reg31               |
|   |           32 个不同的寄存器，同时读取                                   |
|   |                                                                       |
|   | Cycle 2:  [========== 执行 ====================]                      |
|   |           T0:FMA  T1:FMA  T2:FMA ... T31:FMA                          |
|   |           32 个 ALU 同时做同样的 FMA 运算                               |
|   |                                                                       |
|   | Cycle 3:  [========== 写回 ====================]                      |
|   |           T0写回  T1写回  T2写回 ... T31写回                           |
|   |                                                                       |
|   | 然后立即: [========== 下一条指令 ==============]                       |
|   |                                                                       |
|   +---> 时间                                                            |
|                                                                           |
|   注意：硬件设计保证每个 cycle 所有 32 个 lane 执行完全相同的操作。        |
|   不存在"T0 在执行加法而 T1 在执行乘法"的情况——永远不会。                  |
+---------------------------------------------------------------------------+
```

### 2.3 每条 Warp 一个 PC（Program Counter）

这是 SIMT 与 MIMD（多指令多数据）的本质区别：

```
+---------------------------------------------------------------------------+
|                PC: 按 Warp 管理，而非按线程                                 |
|                                                                           |
|   SM 中的 Warp Scheduler:                                                 |
|                                                                           |
|   +-----------+     +-----------+     +-----------+     +-----------+     |
|   |  Warp 0   |     |  Warp 1   |     |  Warp 2   |     |  Warp 3   |     |
|   |  PC:0x100 |     |  PC:0x200 |     |  PC:0x340 |     |  PC:0x100 |     |
|   |  Mask:0xFF|     |  Mask:0x3F|     |  Mask:0xFF|     |  Mask:0xAA|     |
|   +-----------+     +-----------+     +-----------+     +-----------+     |
|                                                                           |
|   Warp 0 的 32 个线程共享同一个 PC = 0x100                                |
|   Warp 1 的 32 个线程共享同一个 PC = 0x200                                |
|                                                                           |
|   不同 warp 可以执行不同的指令（不同的 PC），但同一 warp 内的所有线程      |
|   必须执行相同的指令（只有数据不同）。                                      |
|                                                                           |
|   这就是为什么叫 "Single Instruction" —— 在 warp 内部，指令是唯一的。      |
+---------------------------------------------------------------------------+
```

### 2.4 SIMT Stack：分支发散的处理

GPU 如何处理 if-else 分支？答案是通过 **SIMT Stack**（也叫收敛栈）和 **Active Mask**。

```
+---------------------------------------------------------------------------+
|                    SIMT Stack 工作原理                                      |
|                                                                           |
|   代码:                                                                   |
|   if (threadIdx.x < 16) {          // 条件: 只有前 16 个线程满足          |
|       A();                          // 路径 A                              |
|   } else {                                                                 |
|       B();                          // 路径 B                              |
|   }                                                                       |
|   C();                              // 收敛点                              |
|                                                                           |
|   SIMT Stack 的演化:                                                       |
|                                                                           |
|   初始状态:                                                                |
|   +---+                                                                    |
|   | T |  PC=C, Mask=0xFFFFFFFF (全活跃)                                    |
|   +---+                                                                    |
|                                                                           |
|   遇到 if 分支:                                                            |
|   +---+                                                                    |
|   | R |  PC=reconverge@C, Mask=0xFFFF0000 (else 路径，稍后执行)           |
|   +---+                                                                    |
|   | T |  PC=A, Mask=0x0000FFFF (前 16 线程先执行 if 路径)                 |
|   +---+                                                                    |
|                                                                           |
|   执行完 A() 后返回到收敛点:                                               |
|   +---+                                                                    |
|   | T |  PC=B, Mask=0xFFFF0000 (后 16 线程执行 else 路径)                 |
|   +---+                                                                    |
|                                                                           |
|   执行完 B() 后 (栈已清空):                                                |
|   +---+                                                                    |
|   | T |  PC=C, Mask=0xFFFFFFFF (全活跃，收敛)                             |
|   +---+                                                                    |
|                                                                           |
|   T = 当前活跃的栈顶                                                       |
|   R = 等待执行的"另一条路径"的重聚点                                        |
+---------------------------------------------------------------------------+
```

**Active Mask** 是一个 32-bit 的位掩码，每位对应 warp 中的一个 lane（线程）。值为 1 表示该线程在当前位置"活跃"（应该执行指令），值为 0 表示该线程被"谓词关闭"（predicated off）——硬件仍然取指、译码，但结果不写回。

### 2.5 Warp Divergence（Warp 发散）：详细的性能分析

这是 AI Infra 工作中最常见的性能陷阱之一。我们通过几个分层递进的例子来深入理解。

#### 示例 1：50% 发散——基于奇偶判断

```cuda
__global__ void divergence_50pct(float* a, float* b, float* c, int n) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if (threadIdx.x % 2 == 0) {
        // 偶数线程执行此路径
        c[idx] = a[idx] * b[idx];
    } else {
        // 奇数线程执行此路径
        c[idx] = a[idx] + b[idx];
    }
}
```

```
执行过程（一个 warp 的视角）：

时刻 T0: 遇到 if (threadIdx.x % 2 == 0)
         |
         +---> 偶数线程 (0,2,4,...,30) 活跃 mask = 0x55555555
         |    奇数线程 (1,3,5,...,31) 被谓词关闭
         |
         |    执行: c[idx] = a[idx] * b[idx];   // 只有 16 个 ALU 工作
         |    耗时: 假设 N cycles
         |
         +---> 奇数线程 (1,3,5,...,31) 活跃 mask = 0xAAAAAAAA
              偶数线程 被谓词关闭
              |
              执行: c[idx] = a[idx] + b[idx];   // 只有 16 个 ALU 工作
              耗时: N cycles

总耗时: 2N cycles  (如果无发散只需 N cycles)
利用率: 50%
```

```
可视化:

无发散时 (理想):
  ALU0  ALU1  ALU2  ALU3  ...  ALU31   时间
  [===] [===] [===] [===]      [===]   |     N cycles, 100% 利用率
  [===] [===] [===] [===]      [===]   |

有发散时 (本例):
  偶数: [===] [---] [===] [---] ...    |     N cycles
  奇数: [---] [===] [---] [===] ...    |     N cycles
                                        +---> 2N cycles, 50% 利用率
  [===] = ALU 工作中
  [---] = ALU 被谓词关闭 (空闲)
```

#### 示例 2：无发散——连续线程条件

```cuda
// 这个分支不会导致发散！为什么？
__global__ void no_divergence(float* data, int n) {
    int idx = threadIdx.x;

    if (idx < 16) {
        data[idx] = data[idx] * 2.0f;    // 线程 0-15
    } else {
        data[idx] = data[idx] + 1.0f;    // 线程 16-31
    }
}
```

```
关键洞察: 因为 warp 内的线程不是随机分组的！
Warp 内的线程 0..31 被分为连续的 lane。

Active Mask 在不同路径:
    if 路径: mask = 0x0000FFFF (低 16 位为 1) — 所有活跃线程是连续的低 16 位
    else 路径: mask = 0xFFFF0000 (高 16 位为 1) — 所有活跃线程是连续的高 16 位

    但是！在CUDA中，只有 mask 是全1或全0时才是"真"无发散。
    这里仍然是发散——if 路径 mask=0x0000FFFF，else 路径 mask=0xFFFF0000。
    
    真正无发散的情况是:
    if (threadIdx.x < 32) { ... }  或者 根本没有 if-else

实际上，对于 threadIdx.x < 16 这种模式:
    只有当 warp 边界对齐时才能避免发散。如果 blockDim.x 是 32 的倍数，
    每个 warp 要么全走 if (最后一个 warp 可能不全)，要么全不满足。
    
    但如果 threadIdx.x 指 warp 内部偏移 (laneid = threadIdx.x % 32):
    if (laneid < 16)  — 这会导致发散！因为每个 warp 内部前 16 和后 16 走不同分支。
    
    因此：要分析发散，关键看"条件对于 warp 内 32 个线程是否一致"。
```

更准确的说法：

```cuda
// 情况 A: 无发散 (条件跨越 warp 边界对齐)
// 假设 blockDim.x = 256
if (threadIdx.x < 128) {
    // Warp 0-3: 全部走 if (32*4 = 128 线程, 正好 cover)
    // Warp 4-7: 全部走 else
    // 每个 warp 内部一致, 无发散!
}

// 情况 B: 有发散 (条件在 warp 内部变化)
if (threadIdx.x % 2 == 0) {
    // 每个 warp 内部都有奇偶, 100% 发散
}

// 情况 C: 有发散 (条件在 warp 内部变化)
if (threadIdx.x % 32 < 16) {
    // 等于 if (laneid < 16), 每个 warp 内部都有前 16 和后 16
    // 50% 发散
}
```

#### 示例 3：嵌套发散——最坏情况

```cuda
__global__ void nested_divergence(float* data) {
    int idx = threadIdx.x;

    if (idx % 2 == 0) {          // 第一层: 50% 利用率
        if (idx % 4 == 0) {      // 第二层: 25% 利用率
            if (idx % 8 == 0) {  // 第三层: 12.5% 利用率
                data[idx] = 1.0f;
            } else {
                data[idx] = 2.0f;
            }
        } else {
            data[idx] = 3.0f;
        }
    } else {
        data[idx] = 4.0f;
    }
}
```

```
嵌套发散的执行路径 (总共 4 个串行路径):

路径 1 (mask = 0x11111111): idx % 8 == 0  -> data[idx] = 1.0f  (4 线程活跃)
路径 2 (mask = 0x44444444): idx % 4 == 0  -> data[idx] = 2.0f  (4 线程活跃)
路径 3 (mask = 0x22222222): idx % 2 == 0  -> data[idx] = 3.0f  (8 线程活跃)
路径 4 (mask = 0x88888888): else           -> data[idx] = 4.0f  (16 线程活跃)

总耗时: 4x 单路径时间
平均利用率: (4+4+8+16)/(32*4) = 32/128 = 25%

最坏情况: 32 个完全不同的路径 -> 1/32 = 3.125% 利用率！
```

#### 示例 4：对 AI 工作负载的实际影响

发散不是理论问题——它在 attention kernel 中直接出现：

```cuda
// FlashAttention 中的简化示例: 因果 mask
// 对于 decoder-only 模型 (GPT, LLaMA 等)
__global__ void causal_attention_mask(float* scores, int seq_len, int head_dim) {
    int row = blockIdx.x * blockDim.x + threadIdx.x;
    int col = blockIdx.y * blockDim.y + threadIdx.y;

    if (row < seq_len && col < seq_len) {
        float val = scores[row * seq_len + col];

        // 因果 mask: 不允许 attend 到未来位置
        if (col <= row) {   // <-- 这就是发散点!
            // 上三角 (包含对角线): 正常计算
            val = val / sqrtf(head_dim);
        } else {
            // 下三角: 设为 -inf
            val = -INFINITY;
        }
        scores[row * seq_len + col] = val;
    }
}

// 运行分析 (seq_len=128, blockDim=(32, 4)):
// 一个 block 有 128 个线程, 处理 8 行 16 列
// col <= row 的条件对于不同的 col 不同, 导致每个 warp 内部发散
// 性能损失: 约 2x (因为两个分支的工作量不同)
```

**FlashAttention 的解决方案**：通过重排计算顺序和 block 划分策略（如按对角线分块），尽量减少 warp 内部的发散。

### 2.6 发散的实际性能数据

以下是在 A100 上测量的数据（来自公开 benchmark 和笔者经验）：

| 发散程度 | 有效利用率 | 相对性能 | 典型场景 |
|---------|-----------|---------|---------|
| 无发散 | 100% | 1.0x (基准) | element-wise ops, GEMM 内部 tile 计算 |
| 2-way (50%) | 50% | 0.5x | 奇偶分支, 因果 mask 的边界行 |
| 4-way (25%) | 25% | 0.25x | 嵌套条件, 复杂控制流 |
| 重度发散 | <10% | <0.1x | 图遍历, 不规则数据结构 |

---

## 3. 延迟隐藏 (Latency Hiding)

### 3.1 GPU 的基本洞察：用并行度换延迟

这是 GPU 设计的核心哲学，也是最优雅的部分:

> **CPU 用大缓存 + 分支预测 + 乱序执行来减少延迟。GPU 用海量线程来隐藏延迟。**

```
+---------------------------------------------------------------------------+
|               CPU  vs  GPU 延迟处理策略                                    |
|                                                                           |
|   CPU 策略: 减少延迟 (latency reduction)                                   |
|   +------------------------------------------------------+                |
|   | L1 Cache (32KB) -> L2 (256KB) -> L3 (16MB) -> DRAM  |                |
|   | 延迟:   4 cycles     12 cycles    40 cycles   200+   |                |
|   |                                                      |                |
|   | 大数据 + 巨大缓存 + 预取 + 乱序执行 = 尽量不 miss      |                |
|   +------------------------------------------------------+                |
|                                                                           |
|   GPU 策略: 隐藏延迟 (latency hiding)                                      |
|   +------------------------------------------------------+                |
|   | Warp 0: [==== 等待内存 (800 cycles) ===============] |                |
|   | Warp 1:    [==== 等待内存 (800 cycles) ============] |                |
|   | Warp 2:       [==== 等待内存 (800 cycles) ========]  |                |
|   | Warp 3:          [计算] [等待内存] [计算]             |                |
|   | Warp 4:             [计算] [等待内存] [计算]          |                |
|   | ...                                                   |                |
|   +------------------------------------------------------+                |
|   |                                                      |                |
|   | 小缓存 + 零开销 warp 切换 + 大量 warp = 让 ALU 一直忙   |                |
|   +------------------------------------------------------+                |
+---------------------------------------------------------------------------+
```

### 3.2 内存延迟的数值

这是理解延迟隐藏必要性的关键数据：

```
典型的 GPU 内存层次延迟 (A100, 单位: clock cycles):

寄存器:        0 cycles (同一 cycle 可用)
共享内存:      ~20-30 cycles (无 bank conflict)
L1 Cache:      ~30-40 cycles
L2 Cache:      ~200-300 cycles
HBM2e (DRAM):  ~600-800 cycles

换算为绝对时间 (A100 @ 1.41 GHz):
800 cycles / 1.41 GHz ≈ 567 ns

在 567 ns 内，A100 的 SM 可以执行:
- FP32 FMA: 567 ns × 19.5 TFLOPS / (2 ops) ≈ 567 × 19.5/2 ≈ 5500+ 次 FMA
- 也就是说，一次 HBM 访问的时间足够做 5500 多次乘加运算！

这对于 attention 等访存密集的内核是致命的：
如果每个 warp 只有 1 个活跃的 memory request，
ALU 就会有 99.98% 的时间在等数据。
```

### 3.3 Warp 切换：零开销的关键

为什么 GPU 可以做到零开销的 warp 切换？因为**每个 warp 的上下文（寄存器、PC、栈）已经物理存在硬件中**：

```
+---------------------------------------------------------------------------+
|                Warp 硬件上下文管理                                         |
|                                                                           |
|   SM 寄存器文件 (64K × 32-bit registers on A100):                        |
|   +-------------------------------------------------------------------+  |
|   | Warp 0 寄存器 (比如 128 regs × 32 threads = 4096 regs)            |  |
|   | Warp 1 寄存器 (4096 regs)                                          |  |
|   | Warp 2 寄存器 (4096 regs)                                          |  |
|   | ...                                                                |  |
|   | Warp N 寄存器 (4096 regs)                                          |  |
|   +-------------------------------------------------------------------+  |
|                                                                           |
|   当 Scheduler 从 Warp 0 切换到 Warp 1:                                   |
|                                                                           |
|   CPU 上下文切换:                                                         |
|   - 保存所有寄存器到内存 (~数百 bytes)                                    |
|   - 恢复新线程的寄存器 (~数百 bytes)                                      |
|   - 刷新 TLB, 更新页表                                                    |
|   - 耗时: 数百到数千 cycles                                               |
|                                                                           |
|   GPU Warp 切换:                                                          |
|   - 寄存器已经在物理文件中                                                 |
|   - 只需改变"当前 warp 的基地址指针"                                       |
|   - 不保存/恢复任何东西！                                                  |
|   - 耗时: 0 cycles (指令调度器下个 cycle 就可以切换到别的 warp)           |
|                                                                           |
|   这就是为什么 GPU 需要海量寄存器 (64K/SM)：                               |
|   不是给一个 warp 用的，是给所有驻留 warp 的上下文空间。                   |
+---------------------------------------------------------------------------+
```

### 3.4 延迟隐藏的工作原理

```
+---------------------------------------------------------------------------+
|                    延迟隐藏的时序示意                                       |
|                                                                           |
|   时间 (cycles)                                                           |
|   0         200       400       600       800       1000      1200       |
|   |         |         |         |         |         |         |          |
|                                                                           |
|   Warp 0:   [==== 计算 (50 cycles) ====][======== 等待 HBM (700) ========|
|   Warp 1:   [==== 等待 HBM ====][== 计][==== 等待 HBM ====][== 计][==    |
|   Warp 2:               [=计=][==== 等待 HBM ====][计][==== 等待 HBM     |
|   Warp 3:        [== 等待 HBM ==][计][==== 等待 HBM ====][=计=][====     |
|   Warp 4:   [=计=][==== 等待 HBM ====][=计=][==== 等待 HBM ====][=计     |
|   Warp 5:   [==== 等待 HBM ====][== 计算 ==][==== 等待 HBM ====][==      |
|   Warp 6:        [=计=][==== 等待 HBM ====][==== 计算 ====][====         |
|   Warp 7:   [======== 等待 HBM ========][==== 计算 ====][==== 等待       |
|                                                                           |
|   ALU 使用:  [==][==][==][==][==][==][==][==][==][==][==][==][==][==]    |
|              ALU 几乎一直在忙，虽然每个 warp 大部分时间在等内存！          |
|                                                                           |
|   [计] = 执行计算   [等待] = 等待内存                                     |
+---------------------------------------------------------------------------+
```

关键公式：**需要的活跃 warp 数 >= 内存延迟 / 计算延迟**

```
如果一次内存访问需要 700 cycles，一个 warp 的计算段平均持续 50 cycles:
最少需要 700 / 50 = 14 个 warp 来隐藏内存延迟。

实际上因为各种因素 (bank conflict, 指令依赖等), 通常需要:
- 算术密集 kernel: 4-8 个 warp/SM 可能就够了
- 访存密集 kernel: 16-32+ 个 warp/SM 可能还不够
```

### 3.5 Occupancy 计算（详细，逐步推导）

**Occupancy = 每个 SM 上活跃 warp 数 / 每个 SM 最大 warp 数**

Occupancy 告诉你：在所有限制条件下，SM 上能同时驻留多少 warp。

#### 步骤 1：找到你的 kernel 的资源使用

```bash
# 用 nvcc 编译时添加 --ptxas-options=-v 查看资源使用
nvcc -arch=sm_80 --ptxas-options=-v my_kernel.cu -o my_kernel

# 输出示例:
# ptxas info    : Used 128 registers        <-- 每线程寄存器数
# ptxas info    : Used 48 bytes smem         <-- 每 block 共享内存
# ptxas info    : Used 0 bytes cmem[0]       <-- 常量内存
```

#### 步骤 2：计算寄存器限制的 Occupancy

在 A100 (GA100) 上：
- 每 SM 有 **65536** 个 32-bit 寄存器
- 每 warp = 32 threads

```
MaxWarps_reg = floor(65536 / (regs_per_thread × 32))

示例 1: 128 regs/thread (重型 kernel, 如 attention)
  MaxWarps_reg = 65536 / (128 × 32) = 65536 / 4096 = 16 warps

示例 2: 64 regs/thread (中型 kernel, 如 GEMM)
  MaxWarps_reg = 65536 / (64 × 32) = 65536 / 2048 = 32 warps

示例 3: 32 regs/thread (轻量 kernel, 如 element-wise)
  MaxWarps_reg = 65536 / (32 × 32) = 65536 / 1024 = 64 warps (已达 SM 上限)
  GA100 每 SM 最多 64 warps (2048 threads)
```

#### 步骤 3：计算共享内存限制的 Occupancy

在 A100 上：
- 每 SM 最大共享内存：**164 KB**（如配置为最大值）
- 也有 100 KB 和 132 KB 等配置

```
MaxBlocks_smem = floor(smem_per_SM / smem_per_block)

示例: smem_per_block = 48 KB
  MaxBlocks_smem = 164 KB / 48 KB = 3 blocks
  = 3 blocks × (假设 block 中有 N warps) warps

如果 block 有 256 threads = 8 warps:
  MaxWarps_smem = 3 × 8 = 24 warps
```

#### 步骤 4：计算 Block 维度限制

A100 每 SM 最多 **32 个 block**（实际上一般到不了这个限制）。

```
MaxBlocks_dim = min(32, 最大驻留 block 数)
```

#### 步骤 5：计算最终的 Occupancy

```
MaxWarps_total = min(MaxWarps_reg, MaxWarps_smem, MaxWarps_dim × warps_per_block, 64)

Occupancy = MaxWarps_total / 64 × 100%

其中 64 = GA100 每 SM 的最大 warp 数
```

#### 完整示例：分析一个 vLLM 风格的 attention kernel

```python
# 假设 kernel 资源使用:
#   regs_per_thread = 128
#   smem_per_block  = 48 KB  (for KV cache tiles)
#   threads_per_block = 256  (8 warps)
#   GA100: 65536 regs/SM, 164 KB smem/SM, max 64 warps/SM

# 寄存器限制:
max_warps_reg = 65536 // (128 * 32)  # = 65536 // 4096 = 16 warps

# 共享内存限制:
max_blocks_smem = 164 // 48  # = 3 blocks
max_warps_smem = 3 * 8  # = 24 warps

# SM 最大 warp 限制:
max_warps_cap = 64

# 最终:
max_warps = min(16, 24, 64) = 16 warps
occupancy = 16 / 64 = 25.0%

# 结论: 这个 kernel 是寄存器瓶颈。只有 25% 的理论 occupancy。
# 这意味着 GPU 的延迟隐藏能力有限，kernel 更可能是访存或延迟瓶颈。
```

#### 为什么更高的 Occupancy 不一定更好

这是一个常见的误区。更高的 occupancy 不一定意味着更高的性能：

```
Occupancy 的权衡:

高 Occupancy (64 warps/SM):
  + 更好的延迟隐藏
  + 访存密集型 kernel 受益明显
  - 每线程可用寄存器少 (可能导致 spill 到 local memory)
  - 每 block 可用共享内存少
  - 隐藏效率的边际收益递减

低 Occupancy (16-32 warps/SM):
  + 每线程更多寄存器 (高性能计算)
  + 每 block 更多共享内存 (更大的 tile)
  - 延迟隐藏能力较弱
  - 可能不足以隐藏内存延迟

经验法则:
  - 算术密集 kernel (GEMM, conv): 25-50% occupancy 通常已足够
  - 访存密集 kernel (element-wise, LayerNorm): 50-75%+ occupancy 更好
  - 延迟敏感的 kernel (reduction): 尽量高的 occupancy
```

### 3.6 Little's Law 应用于 GPU

Little's Law 可以优美地描述 GPU 的延迟隐藏：

$$L = O \times \frac{L_{req}}{BW}$$

其中：
- $L$ = 隐藏的内存延迟 (cycles)
- $O$ = occupancy (活跃 warp 数)
- $L_{req}$ = 每个请求的延迟 (cycles)
- $BW$ = 带宽 (bytes/cycle)

```
如果 O = 16 warps, L_req = 800 cycles, 每个 warp 每次请求 128 bytes, BW = 64 bytes/cycle:

可以隐藏的延迟 = 16 × (128/64) × 800 / ... 

更直观的理解:
    O 个 warp 轮流发射请求。Warp 0 发射后等待，Warp 1 发射...
    到 Warp 15 发射完，Warp 0 可能还没返回（如果 Occupancy 不够高）。
    如果 O 不够大，ALU 就会空闲等待。
```

### 3.7 Warp 调度时序图

```
+---------------------------------------------------------------------------+
|            4 个 Warp Scheduler 的调度时序 (A100 SM)                        |
|                                                                           |
|   Scheduler 0:  |W0-I0|W1-I0|W2-I0|W3-I0|W0-I1|W1-I1|W2-I1|W3-I1|...    |
|   Scheduler 1:  |W4-I0|W5-I0|W6-I0|W7-I0|W4-I1|W5-I1|W6-I1|W7-I1|...    |
|   Scheduler 2:  |W8-I0|W9-I0|W10  |W11  |W8-I1|W9-I1|W10  |W11  |...    |
|   Scheduler 3:  |W12  |W13  |W14  |W15  |W12  |W13  |W14  |W15  |...    |
|                                                                           |
|   每秒 (1.4 GHz):                                                        |
|   4 scheduler × 1 instr/cycle = 4 instr/cycle per SM                     |
|   = 108 SM × 4 instr/cycle × 1.41 GHz = 609 Giga instructions/sec       |
|                                                                           |
|   每个 scheduler 在自己的 warp 池中循环调度:                               |
|   + 如果 warp 在等待内存 -> 跳过                                         |
|   + 如果 warp 在等待 barrier -> 跳过                                     |
|   + 如果 warp 就绪 -> 发射下一条指令                                     |
|                                                                           |
|   在任意时刻，16 个 warp 驻留在 SM 上时:                                   |
|   每个 scheduler 分管 4 个 warp                                           |
|   如果 4 个 warp 都处于等待状态 -> scheduler 空闲 (stall)                 |
+---------------------------------------------------------------------------+
```

---

## 4. A800 (GA100) SM 架构深入

### 4.1 整体规格

```
+===========================================================================+
|                    NVIDIA A800 (GA100) 完整规格                            |
+===========================================================================+
|                                                                           |
|  核心配置:                                                                |
|  +-- 108 Streaming Multiprocessors (SMs)                                 |
|  +-- 54 Texture Processing Clusters (TPCs) = 每个 TPC 含 2 个 SM          |
|  +-- 8 Graphics Processing Clusters (GPCs)                               |
|      每个 GPC 含 7 个 TPC (1 个 TPC 被禁用 = 108 而非 112 SM)            |
|                                                                           |
|  每个 SM 的关键资源:                                                      |
|  +-- 4 Warp Schedulers (每个 dispatch 1 指令/cycle)                      |
|  +-- 64 FP32 CUDA Cores (分在 4 个分区, 每分区 16)                       |
|  +-- 64 INT32 Cores (分在 4 个分区, 每分区 16)                           |
|  +-- 4 第三代 Tensor Cores (每分区 1 个)                                 |
|  +-- 2 FP64 Cores (双精度被严重限制，面向 HPC 的 A100 有更多)             |
|  +-- 164 KB 共享内存 + L1 数据缓存 (可配置)                               |
|  +-- 65536 × 32-bit 寄存器                                               |
|  +-- 4 Load/Store 单元                                                    |
|  +-- 1 RT Core (光追核心, AI 工作负载基本不用)                            |
|                                                                           |
|  全局资源:                                                                |
|  +-- 40 MB L2 Cache (跨所有 SM 共享)                                     |
|  +-- 5 个 HBM2e 内存控制器, 5120-bit 总线                                |
|  +-- 80 GB HBM2e 显存, 带宽 2039 GB/s                                    |
|  +-- 12 个 NVLink 通道, 600 GB/s (双向)                                  |
|  +-- 基础时钟 1.4 GHz, Boost 1.7 GHz                                     |
|                                                                           |
|  计算吞吐量 (with Tensor Cores, 稀疏):                                    |
|  +-- FP32: 19.5 TFLOPS                                                    |
|  +-- FP16/BF16 Tensor Core: 312 TFLOPS                                   |
|  +-- TF32 Tensor Core: 156 TFLOPS                                        |
|  +-- INT8 Tensor Core: 624 TOPS                                          |
|  +-- FP64: 9.7 TFLOPS (A100; A800 可能有差异)                            |
+===========================================================================+
```

注意：A800 是中国市场的特供版本，相比 A100 主要在 NVLink 带宽上有限制（400 GB/s vs 600 GB/s），核心计算规格基本一致。

### 4.2 SM 内部架构：逐层分解

```
+===========================================================================+
|                    GA100 SM (Streaming Multiprocessor) 内部结构            |
+===========================================================================+
|                                                                           |
|  +-------------------------------------------------------------------+   |
|  |                        L1 Instruction Cache                        |   |
|  +-------------------------------------------------------------------+   |
|         |                        |                        |               |
|    +----v----+              +----v----+              +----v----+          |
|    | Warp    |              | Warp    |              | Warp    |  ...     |
|    |Schedu-  |              |Schedu-  |              |Schedu-  |         |
|    | ler 0   |              | ler 1   |              | ler 2   |         |
|    | 1 instr |              | 1 instr |              | 1 instr |          |
|    | /cycle  |              | /cycle  |              | /cycle  |          |
|    +----+----+              +----+----+              +----+----+          |
|         |                        |                        |               |
|    +----v------------------------v------------------------v----+          |
|    |                       Dispatch Unit                        |          |
|    |          (将指令路由到对应的执行单元)                       |          |
|    +----+-------------------+-------------------+--------------+          |
|         |                   |                   |                         |
|    +----v----+         +----v----+        +----v----+                    |
|    |Partition|         |Partition|        |Partition|   ...              |
|    |   0     |         |   1    |         |   2    |                    |
|    +---------+         +---------+        +---------+                    |
|    | 16 FP32 |         | 16 FP32 |        | 16 FP32 |                    |
|    | 16 INT32|         | 16 INT32|        | 16 INT32|                    |
|    | 1 Tensor|         | 1 Tensor|        | 1 Tensor|                    |
|    |   Core  |         |   Core  |        |   Core  |                    |
|    | 1 LSU   |         | 1 LSU   |        | 1 LSU   |                    |
|    | 4 LSU   |         | 4 LSU   |        | 4 LSU   |                    |
|    +---------+         +---------+        +---------+                    |
|         |                   |                   |                         |
|    +----+-------------------+-------------------+----+                    |
|    |              共享内存 / L1 Data Cache (164 KB)      |               |
|    |             (可配置: 最多 164 KB 共享内存)          |               |
|    +---------------------------------------------------+               |
|         |                   |                   |                         |
|    +----+-------------------+-------------------+----+                    |
|    |                纹理单元 / 特殊功能单元               |               |
|    +---------------------------------------------------+               |
|                                                                           |
+===========================================================================+
```

#### 分区 (Partition) 结构详解

每个 SM 被分为 4 个相同的处理分区，每个分区是独立的且可以并行工作：

```
+---------------------------------------------------------------------------+
|                     SM Partition (1/4) 详细结构                            |
|                                                                           |
|   +-------------------------------------------------------------------+  |
|   |                                                                     |  |
|   |   [FP32 ALU × 16]    [INT32 ALU × 16]    [Tensor Core × 1]         |  |
|   |        |                    |                     |                  |  |
|   |        +---------+----------+----------+----------+                  |  |
|   |                  |                     |                             |  |
|   |           [Operand Collector]    [Register File]                     |  |
|   |                  |                     |                             |  |
|   |           [Load/Store Unit]    [Special Function Unit]               |  |
|   |                                                                     |  |
|   +-------------------------------------------------------------------+  |
|                                                                           |
|   每 cycle 每个 partition:                                                |
|   - 执行最多 16 个 FP32 操作 (一个 warp 的分片 = 32/4 = 8 ops/partition  |
|     需要 2 个 partition-cycle 才能完成一个 warp 的完整 FP32 操作)         |
|   - 或执行最多 16 个 INT32 操作                                           |
|   - Tensor Core 操作在独立流水线上                                        |
+---------------------------------------------------------------------------+
```

### 4.3 Tensor Core 深入

第三代 Tensor Core 是 Ampere 架构的核心创新：

```
+---------------------------------------------------------------------------+
|                      Tensor Core 操作 (Ampere GA100)                       |
|                                                                           |
|   每个 Tensor Core 每 cycle 可以执行:                                      |
|   +-- FP16 矩阵乘加: D = A × B + C                                       |
|       输入: A (FP16), B (FP16), C (FP16/FP32)                            |
|       输出: D (FP16/FP32)                                                |
|       tile 大小: 16×16×16 (A:16×16, B:16×16)                            |
|                                                                           |
|   +-- BF16 矩阵乘加: 同上, 使用 bfloat16 格式                             |
|                                                                           |
|   +-- TF32 矩阵乘加:                                                      |
|       输入: A (TF32), B (TF32), C (FP32)                                 |
|       输出: D (FP32)                                                     |
|       精度: TF32 = 19-bit (10-bit mantissa + 8-bit exponent + 1 sign)    |
|       等价于: FP32 的 range + FP16 的 precision                           |
|       tile 大小: 8×8×4                                                  |
|                                                                           |
|   +-- INT8 矩阵乘加:                                                      |
|       tile 大小: 8×8×16                                                 |
|                                                                           |
|   +-- FP64 矩阵乘加:                                                      |
|       tile 大小: 4×4×4                                                  |
|       只有 HPC 优化的 A100 有完整的 FP64 Tensor Core                     |
|                                                                           |
|   Tensor Core 的计算吞吐量公式:                                            |
|   TFLOPS = SM数 × 4(TC/SM) × 每个TC每cycle的FMA数 × 时钟频率 × 2         |
|                                                                           |
|   FP16 on GA100:                                                          |
|   108 SM × 4 TC/SM × 256 FMA/TC/cycle × 1.41 GHz × 2 = 312 TFLOPS       |
|   (256 = A tile 16×16=256, B tile 16×16=256, C tile 16×16=256)           |
|   所以 每个 TC 每 cycle 做 256 个 FMA = 512 FP ops                       |
|                                                                           |
|   注意: 挂载 Tensor Core 的 warp 中只有部分线程活跃                        |
|   Tensor Core 指令使用 warp-collective 模式:                              |
|   warp 内所有线程协作 feed 数据给 Tensor Core                             |
+---------------------------------------------------------------------------+
```

### 4.4 共享内存架构

```
+---------------------------------------------------------------------------+
|                   GA100 共享内存 / L1 配置选项                             |
|                                                                           |
|   总共 192 KB SRAM per SM (实际物理大小):                                  |
|                                                                           |
|   配置选项 1 (默认):                                                       |
|   +-- 128 KB 共享内存 + 64 KB L1 缓存                                     |
|                                                                           |
|   配置选项 2:                                                              |
|   +-- 164 KB 共享内存 + 28 KB L1 缓存                                     |
|                                                                           |
|   配置选项 3:                                                              |
|   +-- 100 KB 共享内存 + 92 KB L1 缓存                                     |
|                                                                           |
|   (还有其他中间选项)                                                       |
|                                                                           |
|   共享内存的 bank 结构:                                                    |
|   +-- 32 个 bank                                                          |
|   +-- 每个 bank 宽度 4 bytes (32-bit)                                     |
|   +-- 相邻 4-byte 字映射到相邻 bank                                       |
|                                                                           |
|   Bank Conflict:                                                          |
|   +-- 无冲突: 32 个线程访问 32 个不同的 bank (0..31) -> 1 cycle          |
|   +-- 2-way 冲突: 两个线程访问同一个 bank -> 2 cycles (串行化)           |
|   +-- N-way 冲突: N 个线程访问同一 bank -> N cycles                      |
|                                                                           |
|   典型 bank 计算: bank = (byte_address / 4) % 32                          |
|                                                                           |
|   对于 AI 工作负载 (GEMM, attention):                                     |
|   +-- 使用 float4 加载可以合并为 128-bit 访问                             |
|   +-- 需要 padding 来避免 bank conflict (经典的 tile 加 1 列 padding)    |
+---------------------------------------------------------------------------+
```

### 4.5 L2 Cache 架构

```
+---------------------------------------------------------------------------+
|                         GA100 L2 Cache (40 MB)                            |
|                                                                           |
|   40 MB 跨 108 个 SM 共享                                                 |
|   分为多个 L2 slice (每个 memory controller 对应一部分)                   |
|                                                                           |
|   每个 slice 的配置:                                                      |
|   +-- 大小: 65536 KB / slice 数量                                        |
|   +-- 典型延迟: 200-300 cycles                                            |
|   +-- 缓存行大小: 128 bytes (一个 sector = 32 bytes, 4 sectors/line)     |
|                                                                           |
|   L2 的缓存策略对于 kernel 性能至关重要:                                   |
|                                                                           |
|   +-- 读缓存 (默认): global loads 缓存到 L2                               |
|   +-- 流式 (streaming): 绕过 L2, 直接写入 DRAM                           |
|   +-- 缓存驱逐 (evict): 标记数据为低优先级，优先被驱逐                    |
|                                                                           |
|   可以通过 PTX 指令控制缓存行为:                                           |
|   +-- ld.global.ca (cache at all levels)                                  |
|   +-- ld.global.cg (cache at global = L2 only, bypass L1)                |
|   +-- ld.global.cs (cache streaming = 绕过 L2, 只到 L1)                  |
|   +-- ld.global.lu (last use = 最后使用, 驱逐 L1 但不驱逐 L2)            |
|                                                                           |
|   对于 attention kernel:                                                  |
|   +-- KV cache 很大 (几 GB), 远超出 L2 容量                              |
|   +-- 所以每次访问 KV cache 大概率 L2 miss                                |
|   +-- FlashAttention 通过分块计算避免写中间结果，减少内存流量              |
+---------------------------------------------------------------------------+
```

### 4.6 指令分发机制

```
+---------------------------------------------------------------------------+
|                4 Warp Scheduler 的指令分发流水线                           |
|                                                                           |
|   +-------+    +-----------+    +-----------+    +-----------+           |
|   | WSch 0|    |  WSch 1   |    |  WSch 2   |    |  WSch 3  |           |
|   | 管理  |    |  管理     |    |  管理     |    |  管理    |           |
|   | Warps |    |  Warps    |    |  Warps    |    |  Warps   |           |
|   | 0-15  |    |  16-31    |    |  32-47    |    |  48-63   |           |
|   +---+---+    +-----+-----+    +-----+-----+    +-----+-----+           |
|       |              |                |                |                 |
|       +------+-------+--------+-------+--------+-------+                 |
|              |                |                |                         |
|         +----v----------------v----------------v----+                    |
|         |            Dispatch Crossbar              |                    |
|         |   (将指令路由到正确的执行单元)              |                    |
|         +----+----------------+----------------+----+                    |
|              |                |                |                         |
|     +--------v---+   +-------v----+   +-------v----+                    |
|     | FP32 Pipe  |   | INT32 Pipe |   | Tensor Pipe|                    |
|     | (每分区    |   | (每分区    |   | (独立的    |                    |
|     |  16 cores) |   |  16 cores) |   | 流水线)    |                    |
|     +------------+   +------------+   +------------+                    |
|                                                                           |
|   关键约束:                                                               |
|   - 每个 scheduler 每个 cycle 最多发射 1 条指令                          |
|   - 一个 warp 的指令在两个 cycle 内只能发射一次 (dual-issue 限制)         |
|   - FP32 和 INT32 可以同时发射到不同的执行单元 (co-issue)                 |
|   - Tensor Core 指令与其他指令不能同时发射                                |
+---------------------------------------------------------------------------+
```

### 4.7 与 H100 和 A100 的架构对比

| 特性 | A100 (GA100) | A800 (GA100) | H100 (GH100) |
|------|-------------|-------------|-------------|
| **制程** | TSMC 7nm | TSMC 7nm | TSMC 4nm |
| **SM 数量** | 108 | 108 | 132 |
| **CUDA Cores/SM** | 64 FP32 + 64 INT32 | 同 | 128 FP32 + 64 INT32 |
| **Tensor Core** | 第三代 (4/SM) | 同 | 第四代 (4/SM) |
| **FP16 TC TFLOPS** | 312 | 312 | 989 |
| **FP8 TC TFLOPS** | - | - | 1979 |
| **SMEM/SM** | 164 KB (max) | 同 | 228 KB (max) |
| **L2 Cache** | 40 MB | 40 MB | 50 MB |
| **HBM 容量** | 40/80 GB | 80 GB | 80 GB |
| **HBM 带宽** | 2039 GB/s (80G) | 2039 GB/s | 3352 GB/s |
| **最大 SMEM 配置** | 164 KB | 164 KB | 228 KB |
| **寄存器/SM** | 65536 | 65536 | 65536 |
| **最大 Warps/SM** | 64 | 64 | 64 |
| **NVLink** | 600 GB/s | 400 GB/s (受限) | 900 GB/s |
| **PCIe** | Gen4 x16 | Gen4 x16 | Gen5 x16 |
| **TDP** | 400W | 300W? | 700W |
| **Transformer Engine** | 无 | 无 | 有 (FP8 自动混合精度) |
| **TMA (Tensor Memory Accelerator)** | 无 | 无 | 有 (异步数据搬运) |
| **DSM (Distributed Shared Memory)** | 无 | 无 | 有 (跨 SM 共享内存) |

**关键变化（Hopper 相对于 Ampere）：**

1. **FP8 Tensor Core**：H100 的 FP8 带来 ~2x 的吞吐提升（1979 vs 989 TFLOPS），对应 FlashAttention-3 的优化基础。
2. **TMA (Tensor Memory Access)**：硬件异步数据搬运单元，减少寄存器压力和指令开销，大幅简化了数据加载代码。
3. **DSC (Distributed Shared Memory)**：允许一个 SM 访问另一个 SM 的共享内存，使得跨 SM 通信更高效。
4. **Thread Block Cluster**：允许 block 之间协作和同步，对于 GEMM/attention 等大型 kernel 特别有用。

---

## 5. Roofline 模型

### 5.1 Roofline 的核心概念

Roofline 模型是 GPU 性能分析的"第一性原理"——它将一个 kernel 的性能上界与两个硬件极限联系起来：

> **计算极限（Compute Ceiling）**：GPU 每秒能做多少运算（TFLOPS）
>
> **带宽极限（Bandwidth Ceiling）**：GPU 每秒能搬运多少数据（TB/s）

而连接两者的桥梁是 **算术强度（Arithmetic Intensity）**：

$$AI = \frac{\text{FLOPs}}{\text{Bytes Read}} = \frac{\text{总浮点运算次数}}{\text{从 DRAM 读取的总字节数}}$$

```
+===========================================================================+
|                         Roofline 模型 (Log-Log Scale)                     |
|                                                                           |
|   Attainable                                                              |
|   TFLOPS                                                                  |
|     ^                                                                     |
|     |                                                                     |
|  312|------------------------+--------------+--------------+              |
|     |  Memory-Bound          |  Compute-Bound| (Tensor Core)|              |
|     |  (斜率 = 带宽)         |  (水平 = 峰值)|              |              |
|     |   /                    |              |              |              |
|     |  /                     |              |              |              |
|     | /                      |              |              |              |
|  156|/                       |              |              |              |
|     |/    (TF32 TC)          |              |              |              |
|     |                        |              |              |              |
|   19|                        |              |              |              |
|     |/   (FP32 CUDA Core)    |              |              |              |
|     |                        |              |              |              |
|     +-----+------+-----------+------+-------+------+-------+----->        |
|    1/16   1/8    1/4         1      2       4      8      16    ...       |
|               Arithmetic Intensity (FLOPs / Byte)                         |
|                                                                           |
|  Kernel 位置:                                                             |
|  +-- LayerNorm:    AI ≈ 0.05 (深陷 memory-bound)                          |
|  +-- Softmax:      AI ≈ 0.1  (memory-bound)                              |
|  +-- Element-wise: AI ≈ 0.25 (memory-bound)                              |
|  +-- Attention (decode): AI ≈ 1 (memory-bound, 取决于 head_dim)           |
|  +-- GEMM (small): AI ≈ 5-10 (可能 memory-bound 或 在转折点)             |
|  +-- GEMM (large): AI ≈ 100+ (compute-bound, 用 Tensor Core 能达到峰值) |
|  +-- Conv (large): AI ≈ 50+ (compute-bound)                              |
+===========================================================================+
```

### 5.2 算术强度的详细计算

让我们看几个实际的 AI 工作负载 kernel 的算术强度。

#### Softmax

```python
# Softmax 的数学定义:
# y_i = exp(x_i) / sum(exp(x_j))
#
# 对于长度为 N 的向量:
# FLOPs (近似):
#   - N 次 exp (约 8-10 FLOPs each, 实际更多) ≈ 10N
#   - N-1 次加法 (求和) ≈ N
#   - N 次除法 (归一化) ≈ N
#   总计: ≈ 12N FLOPs
#
# Bytes read:
#   - 输入 x: N × 4 bytes (FP32) = 4N
#   - 输出 y: N × 4 bytes = 4N
#   总计: 8N bytes (理想情况, 全部 cache miss)
#
# AI = 12N / 8N = 1.5 FLOPs/byte
#
# 但是! exp 的 FLOP 数实际上很小，而且 Softmax 需要多次遍历数据
# (一次求 max, 一次求 sum, 一次 normalization = 3 passes)
# 实际 AI ≈ 0.5 FLOPs/byte 或更低 -> 极强 memory-bound
```

#### Attention Scores (QK^T)

```python
# QK^T: Q [N, d] × K^T [d, N] -> S [N, N]
#
# FLOPs: 2 × N × N × d  (2 因为一次乘一次加 = 1 FMA = 2 ops)
#
# Bytes read (假设 cache miss, 无 kernel fusion):
#   - Q: N × d × 2 bytes (FP16) = 2Nd
#   - K: N × d × 2 bytes = 2Nd
#   - S (写入): N × N × 2 bytes = 2N^2  (通常很大)
#   总计: 4Nd + 2N^2 bytes
#
# AI = 2N^2 d / (4Nd + 2N^2)
#
# 情况 1: Prefill (N = 4096, d = 128):
#   AI = 2 × 4096^2 × 128 / (4 × 4096 × 128 + 2 × 4096^2)
#      = 4.3 × 10^9 / (2.1 × 10^6 + 3.4 × 10^7)
#      = 4.3e9 / 3.6e7 ≈ 119 FLOPs/byte -> Compute-bound!
#
# 情况 2: Decode (N = 1, 即每次 decode 只看一个 token):
#   对于 decode: Q shape [1, d] × K^T [d, seq_len]
#   实际更复杂, 但本质是: N=1, FLOPs很小, bytes ≈ seq_len×d
#   AI ≈ 2 × 1 × seq_len × d / (2d + 2×seq_len×d)
#      ≈ 2 × seq_len / (2 + 2×seq_len) ≈ 1 FLOP/byte -> Memory-bound!
#
#   这就是为什么 prefill 是 compute-bound, decode 是 memory-bound!
```

#### GEMM (General Matrix Multiply)

```python
# C[M,N] = A[M,K] × B[K,N]
#
# FLOPs: 2 × M × N × K (2 × M × N × K)
# Byte reads (naive, 无 tiling):
#   - A: M × K × 2 bytes (FP16)
#   - B: K × N × 2 bytes
#   - C: M × N × 2 bytes (写入)
#   总计: 2(MK + KN + MN) bytes
#
# AI = 2MNK / 2(MK + KN + MN) = MNK / (MK + KN + MN)
#
# 对于方阵 (M=N=K):
#   AI = N^3 / (3N^2) = N/3
#
# N=64  (小矩阵):  AI = 21 FLOPs/byte
# N=256 (中矩阵):  AI = 85 FLOPs/byte
# N=4096 (大矩阵): AI = 1365 FLOPs/byte -> 远超 roofline 转折点, compute-bound
#
# 实际 GEMM 使用 tiling (寄存器/共享内存复用):
#   每个 tile 只从 DRAM 读一次，在片上复用多次
#   实际 effective AI >> 理论 naive AI
#   这就是为什么 GEMM 能达到接近峰值性能
```

#### LayerNorm

```python
# y = (x - mean) / sqrt(var + eps) * gamma + beta
# N = hidden dimension
#
# FLOPs:
#   - mean: N 次加法 + 1 次除法 ≈ N + 1
#   - (x - mean): N 次减法
#   - (x - mean)^2: N 次乘法
#   - var: N 次加法 + 1 次除法 ≈ N + 1
#   - (x - mean)/sqrt(var+eps): N 次除法
#   - * gamma: N 次乘法
#   - + beta: N 次加法
#   总计: ≈ 7N FLOPs
#
# Bytes:
#   - 读取 x: N × 2 bytes (FP16)
#   - 读取 gamma: N × 2 bytes
#   - 读取 beta: N × 2 bytes
#   - 写入 y: N × 2 bytes
#   总计: 8N bytes
#
# AI ≈ 7N / 8N ≈ 0.875 FLOPs/byte -> 强 memory-bound
#
# 这就是为什么 LayerNorm 是 memory-bound 的经典例子。
# 优化方向: kernel fusion (把 LayerNorm 和前面/后面的 kernel 合并)
```

### 5.3 不同精度的 Roofline

```
+===========================================================================+
|                  A100 不同精度的 Roofline 对比                              |
|                                                                           |
|   TFLOPS                                                                  |
|     ^                                                                     |
|     |                                                                     |
|  312|                                        .............. FP16/BF16 TC |
|     |                                        .                            |
|  156|                         ............... TF32 TC                    |
|     |                         .                                           |
|   78|              ........... INT8 TC (TOPS)                             |
|     |              .                                                      |
|   39|     .........                                                       |
|     |     .                                                               |
|  19.5|..... FP32 CUDA Core                                               |
|     |                                                                     |
|     +-----+------+------+------+------+------+------+------+------>      |
|         0.1    0.5    1      2      5     10     20     50    100        |
|                         Arithmetic Intensity                              |
|                                                                           |
|   相同算术强度下，更低的精度 = 更高的峰值 = 但需要更高的 AI 才能达到峰值   |
|   例如 FP16 TC 需要 AI > 156 / 2.039 ≈ 76 FLOPs/byte 才能达峰           |
|   而 FP32 只需要 AI > 19.5 / 2.039 ≈ 9.6 FLOPs/byte 就能达峰            |
|                                                                           |
|   但实际应用中, FP16 的 2x bytes 节省意味着:                              |
|   - 同样的算术强度, FP16 可以用一半的内存带宽                             |
|   - 或者同样的内存带宽, FP16 有更高的有效算术强度                         |
+===========================================================================+
```

### 5.4 如何在实践中使用 Roofline

#### 步骤 1：测量你的 Kernel

```bash
# 用 ncu (NVIDIA Nsight Compute) 测量 kernel
ncu --metrics gpu__time_duration.sum,\
               sm__throughput.avg.pct_of_peak_sustained_elapsed,\
               dram__throughput.avg.pct_of_peak_sustained_elapsed,\
               smsp__sass_inst_executed.avg.per_second,\
               dram__bytes_read.sum,dram__bytes_write.sum \
    --kernel-name my_kernel \
    ./my_program
```

#### 步骤 2：计算算术强度

```
从 ncu 输出:
  - gpu__compute_memory_request_throughput.avg.pct_of_peak_sustained_elapsed
  - dram__bytes_read.sum + dram__bytes_write.sum = total_bytes
  - sm__sass_inst_executed.sum 中计算 FLOPs

AI = FLOPs / total_bytes
```

#### 步骤 3：定位在 Roofline 上

```
如果 kernel 在:
  带宽倾斜线上 (memory-bound):
    +-- 用 f16/bf16 替代 f32 (减少字节)
    +-- kernel fusion (减少不必要的内存读写)
    +-- 更好的数据复用 (使用共享内存)

  平台线上 (compute-bound):
    +-- 用 Tensor Core (更高的 TFLOPS)
    +-- 优化指令级并行度 (ILP)
    +-- 减少寄存器 spilling

  离两条线都很远 (inefficient):
    +-- 检查 warp divergence
    +-- 检查 bank conflict
    +-- 检查 occupancy 是否过低
    +-- 检查是否存在 launch overhead
```

#### 步骤 4：优化策略

```
+---------------------------------------------------------------------------+
|                    从 Roofline 出发的优化策略                              |
+---------------------------------------------------------------------------+
|                                                                           |
|  Memory-Bound Kernel 优化:                                                |
|  +---+                                                                    |
|  | 1 | Kernel Fusion: 将多个 memory-bound kernel 合并为一个               |
|  +---+ 例: LayerNorm + Dropout + Residual -> 一个 kernel                  |
|  | 2 | 低精度: FP32 -> FP16/BF16 (字节减半, AI 翻倍)                      |
|  +---+                                                                    |
|  | 3 | 数据复用: 利用共享内存缓存重用数据                                  |
|  +---+                                                                    |
|  | 4 | 合并访存: 确保 warp 内线程访问连续地址 (coalesced access)          |
|  +---+                                                                    |
|                                                                           |
|  Compute-Bound Kernel 优化:                                               |
|  +---+                                                                    |
|  | 1 | Tensor Core: FP32 CUDA Core -> TF32/FP16/BF16 Tensor Core         |
|  +---+                                                                    |
|  | 2 | Tiling: 更好的分块策略, 提高数据复用率                              |
|  +---+                                                                    |
|  | 3 | 寄存器优化: 循环展开, ILP, 减少寄存器压力                           |
|  +---+                                                                    |
|  | 4 | FP8 (H100+): 如果可以接受精度损失                                   |
|  +---+                                                                    |
|                                                                           |
|  AI Infra 的经典应用:                                                      |
|  +---+                                                                    |
|  | FlashAttention: 融合 QK^T + Softmax + PV, 消除 O(N²) 中间结果写 DRAM |
|  | 效果: memory traffic 从 O(N²) 降到 O(N)                                 |
|  +---+                                                                    |
|  | PagedAttention (vLLM): 用分页管理 KV cache, 减少碎片,                 |
|  | 结合 kernel fusion + 优化内存访问模式                                  |
|  +---+                                                                    |
|  | Gradient Accumulation: 微观上, 减少 optimizer step 的频率,            |
|  | 等价于增大 batch size, 提高算术强度                                    |
|  +---+                                                                    |
+---------------------------------------------------------------------------+
```

### 5.5 Roofline 分析的局限性与注意事项

```
1. Roofline 假设计算和数据搬移完全重叠 — 实际不一定
2. 没有考虑 kernel launch overhead
3. 没有考虑 I/O (PCIe, NVLink) 瓶颈
4. 算术强度计算中"Bytes"的精确测量很难 (L1/L2 cache hit 怎么算?)
5. 对混合精度 kernel 不太直观 (TC 的 TFLOPS 和普通 FP32 的 TFLOPS 不同)

改进:
- 使用 "empirical roofline": 实测不同 AI 下的性能, 拟合实际曲线
- Cache-aware roofline: 考虑 L1/L2 bandwidth, 而不只是 HBM
```

---

## 6. DCU 架构（国产加速卡）

### 6.1 海光 DCU 概述

海光 DCU（Deep Computing Unit）基于 AMD CDNA (Compute DNA) 架构，是国内自主可控的 GPGPU 解决方案。理解 DCU 不仅是技术需要，也是战略需要。

```
+===========================================================================+
|                   海光 DCU (CDNA 架构) 整体概览                            |
+===========================================================================+
|                                                                           |
|   CDNA 架构特点:                                                          |
|   +-- 计算单元 (Compute Unit, CU) 替代 SM                                 |
|   +-- Wavefront = 64 threads (NVIDIA warp = 32)                           |
|   +-- 双寄存器文件: 向量寄存器 (vGPR) + 标量寄存器 (sGPR)                 |
|   +-- LDS (Local Data Share) = 共享内存 (通常 64 KB/CU)                  |
|   +-- Matrix Core Unit = 矩阵乘加单元 (类似 Tensor Core)                  |
|                                                                           |
|   典型 DCU (如 K100 系列) 规格:                                           |
|   +-- 架构: CDNA 2 / CDNA 3                                               |
|   +-- CU 数量: ~60-120+ (视型号而定)                                      |
|   +-- FP32 TFLOPS: ~20-50+                                                |
|   +-- FP16/BF16 TFLOPS: ~80-200+ (Matrix Core)                           |
|   +-- HBM2e 容量: 32-64 GB                                                |
|   +-- HBM2e 带宽: ~1.2-1.6 TB/s                                          |
|   +-- 制程: 7nm                                                          |
+===========================================================================+
```

### 6.2 关键架构差异对比

```
+===========================================================================+
|            NVIDIA GA100 SM  vs  AMD CDNA2 CU  架构对比                     |
+===========================================================================+
|                                                                           |
|   特性                  | NVIDIA A100 SM    | AMD CDNA2 CU                |
|  ----------------------|-------------------|-----------------------------|
|   线程组基本单元       | Warp (32 threads) | Wavefront (64 threads)      |
|   每 CU/SM 的线程组数  | 最多 64 warps     | 最多 32 wavefronts          |
|   每 CU/SM 线程数      | 最多 2048         | 最多 2048                   |
|  ----------------------|-------------------|-----------------------------|
|   寄存器类型           | 统一 32-bit GPR   | 向量 vGPR + 标量 sGPR       |
|   每 CU/SM 向量寄存器  | 65536 × 32-bit    | 65536 × 32-bit (vGPR)       |
|   每 CU/SM 标量寄存器  | 无 (统一)         | 800-1024 (sGPR, 独立)       |
|  ----------------------|-------------------|-----------------------------|
|   FP32 ALU per CU      | 64                | 64 (4 SIMD × 16 lanes)     |
|   Matrix Core per CU   | 4 (TC)            | 4 (Matrix Core Unit)       |
|  ----------------------|-------------------|-----------------------------|
|   共享内存 (per CU)    | 164 KB (max)      | 64 KB LDS                  |
|   L1 Cache (per CU)    | 与 SMEM 共享      | 16 KB (独立)               |
|   L2 Cache (全局)      | 40 MB             | 8 MB (较小)                |
+===========================================================================+
```

### 6.3 Wavefront vs Warp：64 线程的深远影响

```
+---------------------------------------------------------------------------+
|                  Wavefront (64) vs Warp (32) 的影响分析                    |
+---------------------------------------------------------------------------+
|                                                                           |
|   更大的线程组意味着:                                                      |
|                                                                           |
|   1. 发散代价更高:                                                         |
|      Warp (32 threads):                                                   |
|        if (laneid < 16): 2 passes × 16 active                             |
|        利用率: 50%                                                        |
|                                                                           |
|      Wavefront (64 threads):                                              |
|        if (laneid < 16): 4 passes × 16 active                             |
|        利用率: 25%   <-- 更差!                                            |
|                                                                           |
|   2. 分支条件更敏感:                                                       |
|      在 NVIDIA 上很多"安全"的模式在 DCU 上可能导致严重发散。               |
|      例如:                                                                |
|        if (threadIdx.x % 2 == 0)  // NVIDIA: 50%, DCU: 也是50%           |
|        if (threadIdx.x < 32)       // NVIDIA: 可能无发散, DCU: 50%发散!  |
|                                                                           |
|   3. 更大的寄存器压力:                                                     |
|       Wavefront 的 64 个线程共享 65536 个 vGPR                             |
|       每个 wavefront 的寄存器需求: 64 × regs_per_thread                   |
|       例: 128 regs/thread → 64×128 = 8192 regs/wavefront                  |
|       最多 wavefronts = 65536/8192 = 8                                    |
|       相比 NVIDIA: 65536/(32×128) = 16 warps                             |
|       → DCU 的 occupancy 可能更低 (大约一半!)                              |
|                                                                           |
|   4. 延迟隐藏需求不同:                                                     |
|       更少的 wavefront (occupancy) + 更大的 wavefront                     |
|       = 延迟隐藏能力不同, 需要重新 tuning                                  |
+---------------------------------------------------------------------------+
```

### 6.4 双寄存器文件：vGPR + sGPR

这是 CDNA 架构独有的设计优势：

```
+---------------------------------------------------------------------------+
|                   vGPR (向量寄存器) + sGPR (标量寄存器)                    |
+---------------------------------------------------------------------------+
|                                                                           |
|   vGPR (Vector GPR):                                                      |
|   +-- 每个线程私有 (类似 NVIDIA 的寄存器)                                  |
|   +-- 用于存储 SIMD 计算中的数据                                          |
|   +-- 65536 × 32-bit per CU, 由 64 threads/wavefront 共享                |
|   +-- 大量 vGPR 用于复杂 kernel (attention, GEMM)                        |
|                                                                           |
|   sGPR (Scalar GPR):                                                      |
|   +-- 每个 wavefront 共用 (不是每线程!)                                   |
|   +-- 用于存储对整个 wavefront 都相同的值                                  |
|   +-- 约 800-1024 个 per CU                                               |
|   +-- 优势: 对于 wavefront-uniform 的数据 (如 base pointers, grid dims)   |
|       不需要消耗宝贵的 vGPR 空间!                                         |
|   +-- 编译器自动优化: 将统一值放入 sGPR                                   |
|                                                                           |
|   实际收益:                                                               |
|                                                                           |
|   // 在 NVIDIA GPU 上, base_ptr 存在每个线程的 GPR 中 (浪费 32 个 regs)  |
|   global float* base_ptr;  // LD: R0 = base_ptr  <- 32 个线程各存一份     |
|                                                                           |
|   // 在 DCU 上, base_ptr 存在 sGPR 中 (只消耗 1 个标量寄存器!)            |
|   global float* base_ptr;  // s_load: s[0:1] = base_ptr <- 64线程共享    |
|                                                                           |
|   对于 pointer-chasing kernel (GNN, 图算法), sGPR 可以大幅节省寄存器!     |
|                                                                           |
|   但这给 occupancy 计算带来复杂性:                                         |
|   occupancy 可能被 vGPR 限制 (常见) 或 sGPR 限制 (罕见)                   |
|   需要用 ROCm profiling 工具来确认                                        |
+---------------------------------------------------------------------------+
```

### 6.5 HIP：从 CUDA 到 DCU 的翻译层

HIP（Heterogeneous-Compute Interface for Portability）是将 CUDA 代码移植到 AMD GPU 的关键工具。

#### API 映射表

| CUDA API | HIP API | 说明 |
|----------|---------|------|
| `cudaMalloc` | `hipMalloc` | 设备内存分配 |
| `cudaMemcpy` | `hipMemcpy` | 数据拷贝 |
| `cudaMemcpyAsync` | `hipMemcpyAsync` | 异步拷贝 |
| `cudaFree` | `hipFree` | 内存释放 |
| `cudaSetDevice` | `hipSetDevice` | 设置设备 |
| `cudaStreamCreate` | `hipStreamCreate` | 创建流 |
| `cudaStreamSynchronize` | `hipStreamSynchronize` | 同步流 |
| `cudaEventCreate` | `hipEventCreate` | 创建事件 |
| `cudaEventRecord` | `hipEventRecord` | 记录事件 |
| `cudaEventElapsedTime` | `hipEventElapsedTime` | 事件间耗时 |
| `__global__` | `__global__` | 相同 |
| `__device__` | `__device__` | 相同 |
| `__shared__` | `__shared__` | 相同 |
| `threadIdx.x` | `threadIdx.x` (via `hipThreadIdx_x`) | 等价, 用宏展开 |
| `blockIdx.x` | `blockIdx.x` (via `hipBlockIdx_x`) | 等价 |
| `blockDim.x` | `blockDim.x` (via `hipBlockDim_x`) | 等价 |
| `__syncthreads()` | `__syncthreads()` | 相同 |
| `atomicAdd` | `atomicAdd` | 相同 |
| `<<<grid, block>>>` | `hipLaunchKernelGGL` | 启动 kernel |

#### hipify：自动转换工具

```bash
# hipify-perl: 基于 perl 脚本, 做简单的文本替换
# 快速但有局限性, 对于复杂模板代码可能出错
hipify-perl my_cuda_kernel.cu > my_hip_kernel.cpp

# hipify-clang: 基于 clang 的 AST 级别转换
# 更准确, 能处理复杂 C++ 模板
hipify-clang my_cuda_kernel.cu --cuda-device-lib-path=/usr/local/cuda/lib64 \
    -o my_hip_kernel.cpp
```

#### ROCm 生态系统 vs CUDA 生态系统

| CUDA 生态 | ROCm 生态 | 说明 |
|-----------|----------|------|
| cuBLAS | rocBLAS | BLAS 库 |
| cuFFT | rocFFT | FFT 库 |
| cuRAND | rocRAND | 随机数生成 |
| cuSPARSE | rocSPARSE | 稀疏矩阵运算 |
| cuSOLVER | rocSOLVER | 线性代数求解器 |
| CUB | hipCUB | 并行算法 primitives |
| Thrust | rocThrust | C++ 并行算法模板库 |
| cuDNN | MIOpen | 深度学习 primitives |
| cuTensor | rocTensor?(composable_kernel) | Tensor 运算 |
| NCCL | RCCL | 多 GPU 通信 |
| Nsight Compute | rocProf / omniperf | Profiler |
| Nsight Systems | rocTracer | System-level profiler |

### 6.6 性能移植挑战

从 CUDA 移植到 HIP 不只是一个语法替换，下面是一些实际的挑战：

#### 挑战 1：Wavefront 发散

```cuda
// 原始 CUDA kernel: 在 NVIDIA 上 fine
__global__ void attention_causal_mask(float* scores, int seq_len) {
    int row = blockIdx.x * blockDim.x + threadIdx.x;
    int col = blockIdx.y * blockDim.y + threadIdx.y;

    if (col <= row) {  // 因果 mask
        scores[row * seq_len + col] /= sqrtf(128);
    } else {
        scores[row * seq_len + col] = -INFINITY;
    }
}
// NVIDIA: 2-way divergence (每个 warp 内 col 可能 < 或 > row)
// DCU: 同样的 2-way divergence, 但 wavefront=64 -> 每条路径有更多空闲线程
// 解决方案: 考虑按对角线重排 tile, 减少 wavefront 内发散
```

#### 挑战 2：LDS Bank Conflict

```
NVIDIA 共享内存 (A100): 32 banks × 4 bytes, bank = (addr/4) % 32
DCU LDS (CDNA2): 32 banks × 4 bytes, bank = (addr/4) % 32 (但是! 64 threads!)

关键区别: 当 64 个线程同时访问 LDS 时:
  - NVIDIA (warp=32): 最大 32 个并行访问, 刚好 32 banks
  - DCU (wavefront=64): 最大 64 个并行访问, 但只有 32 banks!
    意味着至少有 2-way bank conflict (如果访问模式不好)

解决方案: 使用 padding 调整布局, 或者对 wavefront 分两次访问
```

#### 挑战 3：Occupancy 计算不同

```python
# NVIDIA A100:
# max_warps = min(65536//(32*regs_per_thread), smem_limit, ..., 64)

# DCU CDNA2:
# max_wavefronts_vgpr = vgpr_per_CU // (64 * vgpr_per_thread)
# max_wavefronts_sgpr = sgpr_per_CU // sgpr_per_wavefront
# max_wavefronts_lds = lds_per_CU // lds_per_workgroup
# 
# 注意: vgpr 和 sgpr 的 constraint 是独立的!
# 总 wavefronts = min(各限制)
# 但可能 vgpr 够用但 sgpr 不够, 或反过来
```

#### 挑战 4：Reduction Kernel 适配示例

```cuda
// NVIDIA CUDA: warp shuffle reduction
__device__ float warp_reduce_sum(float val) {
    for (int offset = 16; offset > 0; offset /= 2) {
        val += __shfl_down_sync(0xffffffff, val, offset);
    }
    return val;
}

// DCU HIP: 需要适配 64-thread wavefront
__device__ float wavefront_reduce_sum(float val) {
    // AMD 的 shuffle 指令不同, 且 wavefront = 64
    for (int offset = 32; offset > 0; offset /= 2) {  // 从 32 开始!
        val += __shfl_down(val, offset);  // HIP 中不需要 mask
    }
    return val;
}

// 关键差异:
// 1. offset 起始值不同 (32 vs 16)
// 2. __shfl_down_sync 的参数不同
// 3. 如果 block 中只有 32 个线程在做 reduction,
//    在 DCU 上 wavefront 的另外 32 个线程是浪费的
```

### 6.7 对国内 AI Infra 的战略意义

```
+---------------------------------------------------------------------------+
|               DCU 在国内 AI Infra 部署中的角色                             |
+---------------------------------------------------------------------------+
|                                                                           |
|   1. 自主可控:                                                              |
|      - 不受出口管制影响 (A100/H100 对华禁售)                               |
|      - 国内数据中心可以大规模部署                                          |
|      - 政企客户的首选合规方案                                              |
|                                                                           |
|   2. 生态适配现状:                                                          |
|      - PyTorch: 官方支持 ROCm backend                                     |
|        torch.cuda.is_available() -> 在 ROCm 上也返回 True                 |
|        大部分模型可以直接运行                                              |
|      - vLLM: 社区支持 AMD GPU (ROCm)                                       |
|        通过 docker 镜像 vllm/vllm-openai 部署                             |
|        PagedAttention 关键 kernel 已适配                                   |
|      - DeepSpeed: 部分支持 ROCm                                           |
|      - FlashAttention: 有 ROCm 移植版本                                   |
|        (https://github.com/ROCm/flash-attention)                          |
|                                                                           |
|   3. 性能差距:                                                              |
|      - 在同样的算力指标下, 实际 AI 训练/推理性能:                           |
|        NVIDIA ≈ 1.0x (基准)                                               |
|        DCU ≈ 0.7-0.85x (取决于工作负载)                                   |
|      - 差距来源:                                                           |
|        a) 软件生态成熟度 (cuDNN vs MIOpen)                                |
|        b) 编译器优化质量 (nvcc vs hipcc)                                  |
|        c) L2 cache 较小 (8 MB vs 40 MB)                                   |
|        d) 驱动和 runtime 的稳定性                                          |
|                                                                           |
|   4. 作为 AI Infra 工程师需要掌握:                                          |
|      - 同时熟悉 CUDA 和 HIP 两套工具链                                     |
|      - 理解架构差异, 写出 portable 的高性能 kernel                         |
|      - 能够用条件编译实现一套代码多平台运行:                               |
|        #if defined(__HIP__) ... #else ... #endif                          |
|      - 了解各平台的 profiling 工具 (ncu, rocprof, omniperf)               |
+---------------------------------------------------------------------------+
```

---

## 7. 为什么这些对 AI Infra 至关重要

这一章把前面所有的技术概念串起来，解释它们如何直接应用于 AI Infra 的日常工作。

### 7.1 每个 Kernel 优化根本上都是 Roofline 的问题

```
+---------------------------------------------------------------------------+
|              AI Infra Kernel 优化的本质思维框架                            |
+---------------------------------------------------------------------------+
|                                                                           |
|   拿到一个 kernel 的性能数据后, 问自己:                                     |
|                                                                           |
|   第 1 步: 它在 roofline 的哪里?                                           |
|     +-- Memory-bound?  -> 减少字节搬运 (fusion, low-precision, better    |
|     |                      reuse, coalesced access)                       |
|     +-- Compute-bound? -> 提高计算效率 (Tensor Core, better tiling,      |
|     |                      more ILP, FP8)                                 |
|     +-- 离两条线都远?  -> 找瓶颈 (divergence, bank conflict, occupancy,  |
|                           launch overhead, data dependency)                |
|                                                                           |
|   第 2 步: 检查 warp 利用率                                                |
|     +-- 有 warp divergence 吗? (nsight compute 中的 avg. active threads  |
|     |    per warp)                                                        |
|     +-- Occupancy 够吗?  (理论 vs 实际)                                   |
|                                                                           |
|   第 3 步: 检查内存访问模式                                                |
|     +-- 是 coalesced 访问吗?                                              |
|     +-- Bank conflict 严重吗?                                             |
|     +-- L1/L2 cache hit rate 如何?                                        |
+---------------------------------------------------------------------------+
```

### 7.2 理解 Warp 让你真正读懂 Profiler 输出

```
nsight compute (ncu) 的关键指标与 warp 模型的关系:

sm__warps_active.avg.pct_of_peak_sustained_active
    -> 实际有多少 warp 在 SM 上活跃 (vs 理论最大值)
    -> 低 = occupancy 不够, 延迟隐藏能力弱

smsp__average_warps_issue_stalled_barrier_per_issue_active.ratio
    -> warp 在 barrier (__syncthreads) 上 stall 的时间占比
    -> 高 = block 间同步过多, 负载不均衡

smsp__average_warps_issue_stalled_long_scoreboard_per_issue_active.ratio
    -> warp 在等待数据 (scoreboard stall) 的时间占比
    -> 高 = 内存延迟是瓶颈 (memory-bound)

smsp__average_warps_issue_stalled_short_scoreboard_per_issue_active.ratio
    -> warp 因指令依赖等待的短 stall
    -> 高 = 需要更多 ILP (指令级并行)

smsp__average_warps_issue_stalled_not_selected_per_issue_active.ratio
    -> warp 就绪但 scheduler 选了别的 warp
    -> 高 = 有足够的 warp->好! 延迟隐藏在工作
```

### 7.3 延迟隐藏解释为什么小 Batch Size GPU 利用率低

这是推理引擎中最重要的性能洞察之一：

```
+---------------------------------------------------------------------------+
|           Batch Size 对 GPU 利用率的影响 (推理场景)                        |
+---------------------------------------------------------------------------+
|                                                                           |
|   大 Batch Size (BS=64, seq_len=2048):                                    |
|   +-- Grid 大: 很多 block, 每个 SM 都分配了足够多的 block                |
|   +-- 很多 warp: 每个 SM 上有大量的 warp 可以切换                        |
|   +-- 延迟隐藏好: ALU 利用率高, GPU 接近 roofline                        |
|   +-- 吞吐量高: tokens/second 接近理论上限                                |
|                                                                           |
|   小 Batch Size (BS=1, seq_len=2048):                                     |
|   +-- Grid 小: 只有少数 block (可能只有几个 SM 被使用!)                  |
|   +-- Warp 少: 每个 SM 只有少量 warp                                     |
|   +-- 延迟隐藏差: ALU 经常 stall 等内存                                  |
|   +-- 吞吐量低: 单个 token 的延迟低, 但总吞吐量远低于峰值                |
|                                                                           |
|   具体例子 (A100, LLaMA-7B, FP16):                                         |
|   BS=1  decode: ~40 tokens/s  (GPU 利用率 <5%)                            |
|   BS=32 decode: ~800 tokens/s (GPU 利用率 ~60%)                           |
|   BS=128 decode: ~1500 tokens/s (接近 memory bandwidth limit)             |
|                                                                           |
|   这就是为什么 vLLM 需要 continuous batching:                               |
|   动态地把多个请求打成一个 batch, 保持 GPU busy                           |
+---------------------------------------------------------------------------+
```

### 7.4 PagedAttention Kernel 设计中的 SIMT 智慧

```python
# vLLM 的 PagedAttention 核心思想与硬件理解:

# 传统 KV Cache: 连续的, 预分配的
# 问题: 碎片化 (每个 sequence 预分配 max_seq_len, 大量浪费)
# 内存浪费 -> 能服务的请求更少 -> batch size 更小 -> GPU 利用率更低!

# PagedAttention: 分页管理 (类 OS 虚拟内存)
# KV cache 按"页"(block) 组织, 不连续存储
# 好处: 零碎片, 内存利用率高 -> 更大 batch size -> 更高 GPU 利用率

# 从 SIMT 角度看 PagedAttention kernel 的设计挑战:
# 1. 非连续内存访问: KV cache block 之间不连续
#    -> 需要额外的指针追踪 (block table lookup)
#    -> 可能破坏 coalesced access 模式
#    -> 解决方案: 在 shared memory 中重组数据
#
# 2. 变长 sequence: 每个请求的 seq_len 不同
#    -> warp 内的线程可能处理不同数量的元素
#    -> 需要处理 warp divergence
#    -> 解决方案: 按 block 粒度的 mask
#
# 3. GQA (Grouped Query Attention): Q head 数 < KV head 数
#    -> 同一个 KV head 被多个 Q head 共享
#    -> 需要高效的数据复用
#    -> 与 shared memory tiling 策略紧密耦合
```

### 7.5 FlashAttention 设计中的硬件考量

```
+---------------------------------------------------------------------------+
|        FlashAttention 设计: 从硬件约束出发的算法创新                        |
+---------------------------------------------------------------------------+
|                                                                           |
|   FlashAttention 的核心洞察:                                               |
|   注意力计算的瓶颈不是 FLOPs, 是内存带宽。                                  |
|                                                                           |
|   O(N²) 的 attention matrix 如果全部写回 HBM:                              |
|     N=8192, FP16: 8192² × 2 bytes = 128 MB per layer!                    |
|     LLaMA-70B (80 layers): 128 MB × 80 = 10 GB, 超出 L2 cache             |
|                                                                           |
|   但 SRAM (shared memory) 的容量限制决定了 FlashAttention 的 block size:   |
|     A100 SMEM = 164 KB per SM                                             |
|     Attention tile: Q_block [Br, d] × K_block [Bc, d]^T                   |
|     Q_block + K_block + V_block + S_partial + O_partial <= 164 KB         |
|     → Br 和 Bc 由 SRAM 大小决定!                                          |
|                                                                           |
|   这就是为什么:                                                             |
|     - H100 的 228 KB SMEM 允许更大的 tile -> 更少的 pass -> 更快          |
|     - DCU 的 64 KB LDS 需要更小的 tile -> 更多的 pass -> 更慢            |
|     - FlashAttention-3 (Hopper) 利用 TMA 做异步数据搬运                   |
|                                                                           |
|   SRAM 的 bank 结构影响 tile 布局:                                         |
|     32 banks × 4 bytes -> 需要用 padding 避免 bank conflict               |
|     这是 FlashAttention 实现中的细节优化                                   |
+---------------------------------------------------------------------------+
```

### 7.6 训练优化中的算术强度思维

```python
# 梯度累积 (Gradient Accumulation) 本质上是在提高算术强度:

# 场景: 显存不够, 无法使用大 batch size
# 比如模型只能 fit BS=2, 但想要 effective BS=64

# 方案: 梯度累积
# accumulation_steps = 64 / 2 = 32
# 每个 micro-batch 计算梯度但不更新参数, 累积 32 步后更新

# 从算术强度角度看:
# - 不累积 (BS=2): 每个 optimizer step, 模型参数从 DRAM 读取一次
#   AI = compute_FLOPs / (param_bytes + grad_bytes + optimizer_state_bytes)
#   参数读取占比高 -> memory-bound in optimizer step

# - 累积 (BS=64 effective): 32 个 forward+backward 共享一次 optimizer step
#   optimizer step 的参数读取被 amortize 到 32 个 micro-batch 上
#   AI 变高 -> 更 compute-bound

# 这实际上是 trade: 用更多的 compute (32x forward+backward) 换更少的
# optimizer 内存流量 (1x instead of 32x)
```

### 7.7 vLLM 调度策略中的硬件理解

```
+---------------------------------------------------------------------------+
|             vLLM 的 Continuous Batching 与 GPU 利用率                      |
+---------------------------------------------------------------------------+
|                                                                           |
|   传统 Static Batching:                                                    |
|   +-- 等所有请求完成才提交下一批                                           |
|   +-- 长短序列混合时, 短序列等长序列 -> GPU 空闲                           |
|   |                                                                       |
|   |  [==== Request A (long) ================================]              |
|   |  [== Request B (short) ==]                                            |
|   |  [==== Request C (long) ================================]              |
|   |                              ^                                        |
|   |                              | GPU 利用率低, B 已完成但整个 batch 阻塞|
|   |                                                                       |
|   vLLM Continuous Batching:                                                |
|   +-- 每次 iteration 动态选择哪些请求参与                                  |
|   +-- 完成的请求立即出队, 新请求立即入队                                   |
|   |                                                                       |
|   |  [==== A ====][==== A ====][==== A ====][==== A ====]                 |
|   |  [== B ==]     [=== D ===][=== D ===][=== D ===]                     |
|   |  [==== C ====][==== C ====][==== C ====][=== E ====]                 |
|   |                                                                       |
|   |  核心优势:                                                             |
|   |  1. 最大化 batch size (充分利用 GPU)                                  |
|   |  2. 减少 tail latency (短请求不等长请求)                              |
|   |  3. 提高吞吐量 (tokens/s) 和 GPU 利用率                               |
|   |                                                                       |
|   |  从硬件理解:                                                           |
|   |  - prefill 是 compute-bound -> batch 越大, 每个 token 均摊的          |
|   |    kernel launch overhead 越小                                        |
|   |  - decode 是 memory-bound -> batch 越大, memory bandwidth 越饱和      |
|   |  - vLLM 需要足够多的活跃请求来填满 memory bandwidth                    |
+---------------------------------------------------------------------------+
```

### 7.8 SIMT 模型：AI 加速的"汇编语言"

```
+---------------------------------------------------------------------------+
|              将 SIMT 视为 AI 加速的"底层语言"                              |
+---------------------------------------------------------------------------+
|                                                                           |
|   类比:                                                                    |
|   Python/PyTorch     ~ 高级语言 (你写的训练脚本)                           |
|   CUDA/HIP C++       ~ C 语言 (kernels 的实现)                            |
|   PTX/ISA            ~ 汇编 (编译器生成的中间表示)                         |
|   SIMT (Warp/Tensor) ~ 微架构 (硬件如何真正执行)                          |
|                                                                           |
|   一个优秀的 AI Infra 工程师需要:                                          |
|   +-- 能用 PyTorch 快速 prototyping                                       |
|   +-- 能写高效的 CUDA/HIP kernel                                          |
|   +-- 能读 PTX/ISA 确认编译器没有做傻事                                   |
|   +-- 深入理解 SIMT, 预测 warp divergence 和 occupancy                    |
|                                                                           |
|   实际例子:                                                                |
|   在 attention kernel 中看到 ncu 报告 avg. active threads per warp = 18   |
|   (意思是 32 个线程中平均只有 18 个活跃)                                   |
|   如果你不理解 SIMT: "这个数字好像有点低?"                                 |
|   如果你理解 SIMT: "有 warp divergence, 检查因果 mask 的条件判断,          |
|                     可能需要重排 tile 布局"                               |
+---------------------------------------------------------------------------+
```

---

## 8. 易混淆技术辨析

### 8.1 SIMT vs SIMD vs SMT

这三个概念名字相似但本质和层级完全不同：

```
┌──────────────────┬──────────────────────┬──────────────────────┬──────────────────────┐
│  维度             │  SIMT (GPU)          │  SIMD (CPU)          │  SMT (CPU 超线程)     │
├──────────────────┼──────────────────────┼──────────────────────┼──────────────────────┤
│  全称             │  Single Instruction  │  Single Instruction  │  Simultaneous        │
│                  │  Multiple Threads    │  Multiple Data       │  Multi-Threading     │
│  层级             │  硬件执行模型         │  指令集扩展           │  CPU 微架构技术       │
│  目标             │  数据并行，最大化吞吐  │  数据并行             │  隐藏延迟，提高利用率  │
│  编程方式         │  标量代码，自动并行    │  显式向量指令          │  操作系统级线程调度    │
│                  │  (c[i]=a[i]+b[i])    │  (_mm512_add_ps)     │  (完全透明)          │
│  线程行为         │  Warp 内所有线程锁步   │  单线程执行向量操作    │  各线程独立，可不同指令 │
│                  │  执行同一条指令        │                     │                      │
│  分支处理         │  SIMT Stack + 谓词    │  程序员手动 mask      │  CPU 分支预测器       │
│  上下文切换成本    │  0 cycles            │  N/A (单线程)        │  数百 cycles          │
│  并行度           │  数千线程/SM          │  4-16 路/SIMD 单元   │  2 线程/核心          │
└──────────────────┴──────────────────────┴──────────────────────┴──────────────────────┘

一句话区分：
  SIMT = GPU 用 32 个"傀儡"线程同时执行你的标量代码
  SIMD = CPU 用一条指令同时操作 16 个 float（需要你显式编程）
  SMT  = CPU 在你等内存的时候偷偷跑另一个线程（对程序员透明）
```

### 8.2 Warp vs Wavefront (NVIDIA vs AMD)

这是理解两个 GPU 生态差异的根源：

```
┌──────────────────────┬─────────────────────────┬───────────────────────────┐
│  维度                 │  NVIDIA Warp             │  AMD Wavefront             │
├──────────────────────┼─────────────────────────┼───────────────────────────┤
│  线程数               │  32 (固定，自 G80 以来)  │  64 (固定)                 │
│  执行单元             │  SM (Streaming MP)       │  CU (Compute Unit)         │
│  每 SM/CU 最大数量    │  64 Warps                │  32 Wavefronts             │
│  寄存器               │  统一 32-bit GPR         │  向量 vGPR + 标量 sGPR     │
│  寄存器/SM            │  65536 × 32-bit          │  65536 × 32-bit (vGPR)     │
│  共享内存             │  164 KB (SMEM)           │  64 KB (LDS)               │
│  L2 Cache             │  40 MB                   │  8 MB                      │
│  分支发散影响         │  2-way 分支 = 50% 效率    │  2-way 分支 = 50% 效率      │
│                      │  但 Warp 小 (32)，        │  但 Wavefront 大 (64)，     │
│                      │  路径数更少               │  路径数更多，发散代价更大   │
│  延迟隐藏需求         │  需要 4-8 Warps/SM        │  需要更多 Wavefront (64线程 │
│                      │  (算术密集场景)           │  需要更高的带宽利用率)      │
│                       │                         │                             │
│  Occupancy 计算       │  min(regs, smem, cap)    │  min(vGPR, sGPR, LDS, cap) │
│                      │                          │  vGPR 和 sGPR 独立约束！    │
└──────────────────────┴─────────────────────────┴───────────────────────────┘

对 AI Infra 工程师的影响：
  1. 在 NVIDIA 上 "安全" 的分支条件（如 laneid < 32）在 AMD 上可能产生发散（64 线程中只有 32 个走同一分支）
  2. AMD 的 LDS (64KB) 比 NVIDIA 的 SMEM (164KB) 小得多 → FlashAttention tile 更小 → 更多 pass → 更慢
  3. AMD 的 sGPR（标量寄存器）可以有效减少对 Wavefront-uniform 数据的寄存器浪费，部分弥补劣势
  4. 移植 kernel 时，所有 warp shuffle 代码的 offset 从 16→32 需要重新设计
```

### 8.3 Occupancy vs Utilization

这两个词经常被混用，但含义完全不同：

```
Occupancy (占用率):
  定义: SM 上活跃 Warp 数 / SM 最大 Warp 数
  公式: Occupancy = min(65536/(regs_per_thread×32), 164KB/smem_per_block, ..., 64) / 64
  含义: SM 能"同时驻留"多少个 Warp。纯资源约束（寄存器、共享内存）。
  典型值: 25-75%
  高 Occupancy 好处: 更好的延迟隐藏，更多 Warp 可切换
  高 Occupancy 代价: 每线程寄存器更少，可能 spill 到 local memory

GPU Utilization (GPU 利用率):
  定义: nvidia-smi 显示的百分比
  含义: 过去采样周期内，GPU 上有 kernel 在运行的时间比例。
  典型值: Decode 阶段 20-40%，Prefill 阶段 80-100%
  注意: GPU-Util=20% 在 Decode 阶段是正常的！不代表有问题。

关键区别:
  ┌─────────────────────────────────────────────────────────────────┐
  │                                                                 │
  │  Occupancy = 理论上有多少 Warp "可以"同时驻留                    │
  │  GPU-Util = 实际上 GPU 有多"忙"                                  │
  │                                                                 │
  │  高 Occupancy + 低 GPU-Util = Memory-Bound (Warp 都在等数据)    │
  │  低 Occupancy + 高 GPU-Util = Compute-Bound (少数 Warp 跑满 ALU) │
  │  低 Occupancy + 低 GPU-Util = Scheduling-Bound (CPU 跟不上)     │
  │                                                                 │
  │  不要只看 GPU-Util 判断性能！                                    │
  │  Decode 阶段 GPU-Util=25% 是完全正常的——瓶颈在显存带宽，         │
  │  而不是算力。提高 Occupancy 可能反而降低性能（减少了寄存器）。    │
  │                                                                 │
  └─────────────────────────────────────────────────────────────────┘

实战经验:
  - 算术密集 kernel (GEMM, Conv): 25-50% Occupancy 通常足够，不需要追求高 Occupancy
  - 访存密集 kernel (LayerNorm, Element-wise): 50-75%+ Occupancy 可能有益
  - 永远不要为了高 Occupancy 而牺牲每线程寄存器（会导致 spill 到 global memory，得不偿失）
```

---

## 9. AI Infra 专家视角

### 9.1 性能瓶颈排查流程

在 AI Infra 工作中遇到 kernel 性能问题时，按以下决策树逐层排查：

```
第一层：kernel 在 Roofline 的哪个位置？
├── 用 ncu 测量核心指标
│   ncu --metrics sm__throughput.avg.pct_of_peak_sustained_elapsed,\
│            dram__throughput.avg.pct_of_peak_sustained_elapsed \
│        --kernel-name my_kernel ./my_program
│
├── sm__throughput > 70% → Compute-Bound
│   ├── 已经接近峰值，优化空间有限
│   ├── 检查是否用了 Tensor Core（FP16 TC = 312 TFLOPS vs FP32 Core = 19.5 TFLOPS）
│   ├── 如果没用 TC → 重写 kernel 用 Tensor Core（16x 潜在加速）
│   └── 如果已用 TC → 检查 tiling 策略和寄存器 spilling
│
├── dram__throughput > 70% → Memory-Bound
│   ├── 减少每次读取的字节数
│   │   ├── FP32 → FP16（字节减半，AI 翻倍）
│   │   ├── Kernel Fusion（消除中间结果的显存读写）
│   │   └── 更好的数据复用（Shared Memory tiling）
│   ├── 改善访问模式
│   │   ├── Coalesced Access（线程访问连续地址）
│   │   ├── 避免 Bank Conflict（padding）
│   │   └── 利用 L2 Cache（调整 block 调度顺序）
│   └── 如果 dram__throughput 已经 > 90% → 已达硬件带宽极限
│
└── sm__throughput < 40% 且 dram__throughput < 40% → Inefficient
    ├── 检查 Warp Divergence
    │   ncu --metrics smsp__average_warps_issue_stalled_long_scoreboard_per_issue_active.ratio
    │   如果高 + sm 低 → 大量 Warp 在等内存但利用率低 → 检查 occupancy
    ├── 检查 Occupancy
    │   ncu --metrics sm__warps_active.avg.pct_of_peak_sustained_active
    │   如果 < 30% → 寄存器或共享内存限制
    │   ├── 减少每线程寄存器（加 __launch_bounds__ 或 maxrregcount）
    │   └── 减少共享内存使用（更小的 tile）
    ├── 检查 Launch Overhead
    │   nsys profile --trace=cuda → 看 kernel 间是否有 >20μs 的 gap
    └── 检查是否有大量 Stall
        ncu --metrics smsp__average_warps_issue_stalled_not_selected_per_issue_active.ratio
        如果高 → 有足够 Warp 就绪但 scheduler 没选 → 正常（延迟隐藏在工作）

第二层：分析 Stall Reasons（基于第一层结果深入）

├── Long Scoreboard Stall 高 (smsp__average_warps_issue_stalled_long_scoreboard...)
│   → Warp 在等 global memory 数据
│   → 这是 Memory-Bound 的特征
│   → 优化方向：减少内存流量、改善访问模式、提高数据复用
│
├── Short Scoreboard Stall 高 (smsp__average_warps_issue_stalled_short_scoreboard...)
│   → Warp 在等上一条指令的结果（流水线延迟）
│   → 需要更多 ILP（指令级并行），如循环展开
│
├── Barrier Stall 高 (smsp__average_warps_issue_stalled_barrier...)
│   → Warp 在 __syncthreads() 处等待
│   → Block 内负载不均衡，某些 Warp 提前到达 barrier
│
└── Not Selected 高 (smsp__average_warps_issue_stalled_not_selected...)
    → Warp 就绪但 Scheduler 选了别的 Warp
    → 这是好事！说明有足够的活跃 Warp 在轮换
```

### 9.2 A800 部署实操：从硬件参数到推理性能

**A800 (GA100) 关键硬件参数回顾：**

```
A800 与 A100 的核心差异（中国特供版）：
┌────────────────────┬─────────────────────┬──────────────────────┐
│  参数               │  A100 80GB          │  A800 80GB           │
├────────────────────┼─────────────────────┼──────────────────────┤
│  SM 数量            │  108                │  108 (相同)          │
│  FP16 TC TFLOPS     │  312                │  312 (相同)          │
│  INT8 TC TOPS       │  624                │  624 (相同)          │
│  HBM2e 带宽         │  2039 GB/s          │  2039 GB/s (相同)    │
│  NVLink 带宽        │  600 GB/s           │  400 GB/s (受限!)   │
│  L2 Cache           │  40 MB              │  40 MB               │
│  SMEM/SM            │  164 KB             │  164 KB              │
│  寄存器/SM          │  65536              │  65536               │
└────────────────────┴─────────────────────┴──────────────────────┘

关键结论: A800 的计算能力和显存带宽与 A100 完全一致。
唯一差异是 NVLink 带宽降低 33% (400 vs 600 GB/s)。
这意味着：
  - 单卡推理：A800 = A100（无差异）
  - 多卡 TP：A800 的 AllReduce 通信慢 33%（影响 TP=4/8 场景，TP=2 影响较小）
```

**从 Roofline 理解推理性能瓶颈：**

```
A800 Roofline 分析 (FP16 Tensor Core):

Ridge Point = 312 TFLOPS / 2039 GB/s ≈ 153 FLOPs/Byte

推理各阶段的算术强度 vs Ridge Point:

  Prefill (batch=num_prompt_tokens, seq_len=2048):
    AI ≈ 50-200+ FLOPs/Byte → Compute-Bound (超过 Ridge Point)
    → 瓶颈在 312 TFLOPS Tensor Core 算力
    → 优化方向：量化权重（降低单 token FLOPs）、增大 batch

  Decode (batch=64, seq_len=1 per step):
    AI ≈ 1-5 FLOPs/Byte → Memory-Bound (远低于 Ridge Point)
    → 瓶颈在 2039 GB/s HBM 带宽
    → GPU-Util 20-40% 是正常的！
    → 优化方向：量化权重（减少每步读取的字节数）、KV Cache 量化

  Attention Score (QK^T), decode 阶段:
    AI ≈ 1-2 FLOPs/Byte → 极端 Memory-Bound
    → 这就是 FlashAttention 要解决的问题
    → vLLM PagedAttention 进一步优化了 KV Cache 的存储效率
```

**Qwen2.5-32B 推理的 Occupancy 估算：**

```python
# 32B 模型，decode 阶段 attention kernel 的 occupancy 估算
# 假设: d_head=128, num_kv_heads=8 (GQA), block_size=16 (PagedAttention)

# 寄存器使用 (vLLM PagedAttention kernel):
regs_per_thread = 128  # attention kernel 通常寄存器密集

# SM 资源限制:
max_warps_reg = 65536 // (128 * 32)  # = 65536 // 4096 = 16 warps/SM
max_warps_sm = 64                      # A800 硬件上限

# 共享内存限制:
smem_per_block = 48  # KB (KV tile + Q tile + partial sums)
max_blocks_smem = 164 // 48  # = 3 blocks
warps_per_block = 256 // 32  # = 8 warps (假设 block 256 threads)
max_warps_smem = 3 * 8  # = 24 warps

# 最终 Occupancy:
max_warps = min(16, 64, 24) = 16 warps
occupancy = 16 / 64 = 25%

# 结论: 25% occupancy for attention kernel。
# 这意味着 decode 阶段每个 SM 只有 16 个 Warp 可以轮换。
# 需要至少 700/(50×4) ≈ 3.5 个 Warp 来隐藏内存延迟 → 16 足够了。
# 但 Kernel 仍然是 Memory-Bound，因为算术强度太低。
```

**实战调优建议（基于 SIMT 理解）：**

```
1. PagedAttention Block Size 的选择:
   block_size=16 (默认): 更多 block → 更好的 KV Cache 利用率 → 更多并发
   block_size=32: 更少 block → 更好的连续访问 → 单次读取效率更高
   对 A800: 默认 16 即可，因为 HBM 带宽够大，碎片化成本 < 增大并发带来的收益

2. 为什么量化能加速 Decode:
   从 SIMT 角度: 每个 Warp 的 decode step = 从 HBM 读权重 + 计算。
   权重 FP16 (2 bytes) → 读 2×hidden×hidden bytes。
   权重 INT4 (0.5 bytes) → 读 0.5×hidden×hidden bytes。
   虽然反量化增加了计算，但在 Memory-Bound 场景下，
   节省的 75% 内存读取 >> 增加的反量化计算。
   → TPOT 从 25ms 降到 16ms (提升 36%)

3. 为什么 TP 对小模型是负优化:
   TP=2 时每个 Transformer 层后都有一个 AllReduce。
   对于 7B 模型 (hidden=4096)，AllReduce 通信量 ≈ 2×4096×2 = 16KB/层。
   28 层 × 2 (attn + ffn) × 16KB = 896KB total per step。
   A800 NVLink 400 GB/s → 896KB / 400GB/s ≈ 2.2μs。
   看起来很快，但这 2.2μs 是串行化延迟——在 decode 阶段（每 step ≈ 10ms），
   2.2μs 影响不大。但 TP 后每卡只算一半的 FFN → 计算时间减半 →
   如果原本就是 Memory-Bound（计算不是瓶颈），减半计算量没有收益！
   → 这就是为什么小模型 + TP 往往是负优化。
```

---

## 10. 深入学习资源

### 8.1 必读论文

| 论文 | 主题 | 为什么重要 |
|------|------|-----------|
| **NVIDIA CUDA Programming Guide** | CUDA 编程模型完整文档 | 最权威 warp/SIMT 参考 |
| **"Dissecting the NVIDIA Volta GPU Architecture via Microbenchmarking"** (Jia et al., 2018) | Volta 架构逆向 | 通过微基准测试揭示真实硬件行为 |
| **"Dissecting the Ampere GPU Architecture via Microbenchmarking"** (Jia et al., 2021+) | Ampere 架构 | 最新架构的深度剖析 |
| **"Roofline: An Insightful Visual Performance Model for Multicore Architectures"** (Williams et al., 2009) | Roofline 模型原论文 | 整个roofline方法论的起源 |
| **"FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness"** (Dao et al., 2022) | 从IO复杂度出发设计算法 | 硬件感知算法设计的典范 |
| **"Efficient Memory Management for Large Language Model Serving with PagedAttention"** (Kwon et al., 2023) | vLLM/PagedAttention | AI Infra 的经典工作 |
| **"GPU Performance Modeling and Optimization"** (Konstantinidis et al.) | GPU 性能建模 | 系统的性能分析方法 |

### 8.2 推荐书籍

| 书籍 | 适用阶段 |
|------|---------|
| **《Programming Massively Parallel Processors》(Kirk & Hwu)** | 入门 CUDA/SIMT 的最佳教材, 第4版覆盖到Ampere |
| **《CUDA by Example》(Sanders & Kandrot)** | CUDA 编程实战 |
| **《Professional CUDA C Programming》(Cheng, Grossman, McKercher)** | 进阶 CUDA, 深入 warp/occupancy |
| **《CUDA C++ Best Practices Guide》(NVIDIA官方)** | 性能优化指南 |
| **《Parallel and High Performance Computing》(Robey & Zamora)** | 并行的通用理论 |

### 8.3 GPU 架构深度分析资源

```
Chips and Cheese 博客 (https://chipsandcheese.com/):
  - "Microbenchmarking Ampere's Tensor Cores"
  - "Inside Ampere's SM: Partition, Scheduler, and Dispatch"
  - "AMD's CDNA2 Architecture" 系列

NVIDIA 官方白皮书:
  - "NVIDIA A100 Tensor Core GPU Architecture" (GA100 whitepaper)
  - "NVIDIA H100 Tensor Core GPU Architecture" (GH100 whitepaper)
  - "NVIDIA Ampere GA102 GPU Architecture" (GeForce, 但有SM细节)

AMD 官方文档:
  - "AMD CDNA2 Architecture Whitepaper"
  - "AMD Instinct MI200 Series Accelerator"
  - ROCm Documentation (https://docs.amd.com/)

学术资源:
  - "A Performance Analysis Framework for Identifying
     Potential Benefits in GPGPU Applications" (Sim et al.)
  - "Understanding GPU Performance" (UT Austin CS 课程)
```

### 8.4 vLLM Kernel 源码推荐阅读

```
vLLM 仓库中的关键 kernel 文件:

1. csrc/attention/attention_kernels.cu
   -> 主要的 PagedAttention kernel 实现
   -> 学习: shared memory tiling, block table traversal,
            warp-level cooperative fetching

2. csrc/cache_kernels.cu
   -> KV cache 的 copy/swap/free kernel
   -> 学习: 简单的 memory-bound kernel, coalesced access

3. csrc/activation_kernels.cu
   -> SiLU, GELU 等激活函数
   -> 学习: element-wise kernel, 无 shared memory

4. csrc/layernorm_kernels.cu
   -> RMSNorm, LayerNorm kernel
   -> 学习: warp reduction, memory-bound optimization

5. csrc/pos_encoding_kernels.cu
   -> RoPE positional encoding
   -> 学习: warp shuffle, 复杂数据布局

6. csrc/quantization/
   -> AWQ, GPTQ, FP8 量化 kernel
   -> 学习: 低精度计算, 特殊数据格式处理

阅读建议: 从简到难
   1) activation_kernels (最简单)
   2) layernorm_kernels
   3) pos_encoding_kernels
   4) cache_kernels
   5) attention_kernels (最难, 也是最需要理解的)
```

### 8.5 DCU/HIP 学习资源

```
ROCm 官方平台:
  - https://github.com/ROCm/ROCm
  - https://docs.amd.com/ (ROCm documentation)
  - https://github.com/ROCm/hip-tutorials
  - https://github.com/ROCm/rocBLAS

HIP 编程指南:
  - "HIP Programming Guide" (AMD 官方)
  - "Porting CUDA to HIP" (AMD 官方迁移指南)
  - https://github.com/ROCm-Developer-Tools/HIPIFY

DCU 适配的开源项目:
  - vLLM ROCm: https://github.com/vllm-project/vllm (ROCm docker 镜像)
  - FlashAttention ROCm: https://github.com/ROCm/flash-attention
  - PyTorch ROCm: https://pytorch.org/get-started/locally/ (选 ROCm 版本)
  - xformers ROCm: https://github.com/facebookresearch/xformers

性能分析工具:
  - rocprof: AMD GPU profiler (类似 ncu)
  - omniperf: 更高级的 AMD profiling 框架
  - rocTracer: system-level tracing (类似 nsys)
```

### 8.6 Roofline 工具

```
1. Empirical Roofline Toolkit (ERT):
   https://github.com/NERSC/roofline-on-nersc

2. NVIDIA Nsight Compute:
   内置 roofline 分析功能
   用法: ncu --set roofline ./my_program

3. 自定义 Roofline 脚本:
   基于 ncu 输出, 用 Python 脚本计算 AI 并绘图
   参考: https://gitlab.com/NERSC/roofline-modeling

4. Intel Advisor:
   支持 GPU roofline (主要是 Intel GPU)
```

### 8.7 实践建议

```
1. 用 Nsight Compute 分析你写的每个 kernel
   - 关注 warp occupancy, stall reasons, memory pattern
   - 不要只看 wall time

2. 写 micro-benchmark 验证你的理解
   - 写一个故意发散的 kernel, 测量性能
   - 写不同 occupancy 的 kernel, 比较延迟隐藏能力
   - 写不同访问模式的 kernel, 测量 bank conflict 影响

3. 对比 NVIDIA 和 AMD 的行为
   - 如果你有 DCU 机器, 跑同样的 kernel 对比
   - 理解架构差异带来性能差异的根本原因

4. 阅读开源 kernel 源码
   - FlashAttention, vLLM, CUTLASS
   - 关注注释中的"为什么"(设计决策), 不只是"是什么"(代码)

5. 建立自己的性能直觉
   - FP16 GEMM on A100: ~300 TFLOPS (接近峰值)
   - FP16 LayerNorm on A100: ~1-2 TFLOPS (memory-bound)
   - 两者差距 100-300x! 这来自 roofline 理解
```

---

## 附录 A: 术语速查表

| 术语 | 全称 | 含义 |
|------|------|------|
| **SIMT** | Single Instruction, Multiple Threads | warp 内所有线程执行同一指令 |
| **SIMD** | Single Instruction, Multiple Data | CPU 向量指令 (AVX/NEON) |
| **SMT** | Simultaneous Multi-Threading | CPU 超线程技术 |
| **Warp** | - | NVIDIA 的 32 线程执行单元 |
| **Wavefront** | - | AMD 的 64 线程执行单元 |
| **SM** | Streaming Multiprocessor | NVIDIA GPU 的核心计算单元 |
| **CU** | Compute Unit | AMD GPU 的核心计算单元 |
| **Occupancy** | - | 活跃 warp 占最大 warp 的比例 |
| **AI** | Arithmetic Intensity | FLOPs / Bytes 的比值 |
| **HBM** | High Bandwidth Memory | GPU 的高带宽显存 |
| **SMEM / LDS** | Shared Memory / Local Data Share | 片上的用户管理高速缓存 |
| **TC** | Tensor Core | NVIDIA 的矩阵乘加硬件单元 |
| **TMA** | Tensor Memory Accelerator | Hopper 的异步数据搬运单元 |
| **ILP** | Instruction-Level Parallelism | 指令级并行 |
| **PC** | Program Counter | 程序计数器, 指向当前指令 |
| **PTX** | Parallel Thread Execution | NVIDIA 的虚拟 ISA |
| **ISA** | Instruction Set Architecture | 指令集架构 |
| **GPGPU** | General-Purpose GPU | 通用计算 GPU |

## 附录 B: GA100 每个 SM 的 Warp 状态转换

```
+---------------------------------------------------------------------------+
|                    Warp 生命周期状态机                                     |
+---------------------------------------------------------------------------+
|                                                                           |
|                        +-----------+                                      |
|                        |  Eligible | <---+ (数据到达 / barrier 解除)      |
|                        | (就绪)    |     |                                 |
|                        +-----+-----+     |                                 |
|                              |           |                                 |
|                     (scheduler 选中)     |                                 |
|                              |           |                                 |
|                        +-----v-----+     |                                 |
|           +----------->|  Issued   |     |                                 |
|           |            | (发射指令) |     |                                 |
|           |            +-----+-----+     |                                 |
|           |                  |           |                                 |
|     (继续发射)         (需要等待)        |                                 |
|           |                  |           |                                 |
|           |     +------------+-------+   |                                 |
|           |     |                    |   |                                 |
|           | +---v---------+  +------v---v-+                               |
|           | | Short Stall |  | Long Stall |                                |
|           | | (指令依赖)  |  | (内存访问) |                                |
|           | +------+------+  +------+-----+                               |
|           |        |                |                                      |
|           +--------+----------------+                                      |
|                                                                           |
|   Short Stall:                                                             |
|   - 前一条指令结果还未就绪 (pipeline latency)                              |
|   - 通常 < 20 cycles                                                      |
|   - 其他 warp 可以在此期间发射指令                                       |
|                                                                           |
|   Long Stall:                                                              |
|   - 等待 global memory load (200-800 cycles)                              |
|   - 等待 shared memory (20-30 cycles, bank conflict)                      |
|   - 等待 __syncthreads() barrier                                          |
|   - 需要有很多其他 warp 来填充这段时间                                     |
+---------------------------------------------------------------------------+
```

## 附录 C: 常见 AI Workload 的算术强度和瓶颈分类

| Kernel / Operation | 典型 AI (FLOP/Byte) | 瓶颈 | 优化方向 |
|-------------------|---------------------|------|---------|
| **Linear (GEMM, large)** | 100+ | Compute (Tensor Core) | TC 利用率, tiling |
| **Linear (GEMM, small)** | 20-50 | Mixed | 取决于具体维度 |
| **Attention (prefill)** | 50-150 | Compute | FlashAttention tiling |
| **Attention (decode)** | 1-5 | Memory (KV cache) | PagedAttention, KV 量化 |
| **LayerNorm/RMSNorm** | 0.5-1 | Memory | Kernel fusion |
| **Softmax** | 0.5-2 | Memory | Fusion with attention |
| **ReLU/GELU/SiLU** | 0.25 | Memory | Fusion with previous op |
| **Dropout** | <0.1 | Memory | Fusion, 或训练时不用 |
| **RoPE** | 2-10 | Memory | 优化访问模式, fusion |
| **Embedding Lookup** | 0 | Memory | 大 batch 提高复用率 |
| **Reduction (sum/mean)** | 0.5-2 | Memory (多次遍历) | Warp shuffle, shared memory |
| **Copy / Concat** | 0 | Memory bandwidth | 避免不必要拷贝 |

---

> **最后的建议**：本文覆盖了 SIMT 执行模型的广度，但真正的深入需要你在实践中验证每个概念。打开 Nsight Compute，跑一个你写的 kernel，观察 warp divergence、occupancy、stall reasons。只有当你亲眼看到那些数字，你才能真正内化这些知识。
>
> GPU 不是黑盒。每一个 cycle、每一个 stall、每一个 bank conflict 都是可解释的。SIMT 模型就是这把钥匙。

---

*本文档为 AI Infra 学习系列的第二阶段核心内容。建议结合 CUDA kernel 编程实践和 Nsight Compute profiling 一起学习。*
