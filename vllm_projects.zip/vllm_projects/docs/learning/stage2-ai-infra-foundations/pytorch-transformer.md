# PyTorch 与 Transformer 架构深度解析

> **文档定位**：AI Infra 四大方向（推理引擎、训练框架、模型压缩、分布式系统）的共同基础。
> 掌握本文的所有内容，是深入 vLLM、DeepSpeed、Megatron-LM、llama.cpp 等项目的必要前提。

---

## 白话引入

想象你面前有一盒乐高积木。每块积木就是一个 **Tensor**——它可以是 1x1 的小方块（标量），可以是一排积木（向量），也可以是一整块底板（矩阵），甚至是一个立体的城堡部件（高维张量）。PyTorch 给了你操作这些积木的工具：你可以把两块积木拼在一起（加法）、把一排积木复制成一面墙（广播）、或者把整个结构旋转一个角度看（转置/permute）。

而 **Transformer** 就是一本搭建复杂建筑的说明书。说明书里定义了标准的建筑模块：注意力层（Attention）负责让每一块积木"看到"其他积木之间的关系；前馈网络（FFN）负责对每块积木做独立的加工；残差连接（Residual）是一条贯穿整栋建筑的"信息高速公路"，保证高层的变化不会压垮底层的基础。位置编码（RoPE）则是给每块积木贴上"我在第几排第几列"的标签，让模型知道谁是左邻右舍。

本文的目标是帮你从"认识每一块积木"到"看懂整本建筑说明书"，再到"能自己画图纸（从零实现一个 Mini GPT-2）"。这是深入 vLLM、DeepSpeed、Megatron-LM 等 AI Infra 项目的共同前提。

### 术语预检

在深入阅读之前，先过一遍本文最核心的术语。下表用一句话类比帮你建立直觉，再用专业定义给出准确边界。

| 术语 | 一句话类比 | 专业释义 |
|------|-----------|---------|
| Tensor | 像乐高积木一样，是最基本的数据容器 | PyTorch 中的多维数组，可以在 GPU 上加速计算，支持自动微分。底层由 Storage（实际数据）+ Stride（步长）+ Offset（偏移）三元组描述 |
| Autograd | 像自动记账系统，每笔"支出"（前向计算）都会自动算出对应的"账目变化"（梯度） | PyTorch 的动态自动微分引擎，在 forward 时实时构建计算图，backward 时沿图反向自动计算所有叶子节点的梯度 |
| Attention (Q/K/V) | 像图书馆检索：Query 是你想问的问题，Key 是所有书的索引标签，Value 是书的内容；你匹配最相关的标签，取对应的内容 | Self-Attention 的核心机制：Q 和 K 的点积决定"注意力权重"，用权重对 V 加权求和。`Attention(Q,K,V) = softmax(QK^T/√d_k) × V` |
| RoPE (旋转位置编码) | 像给每个 token 贴上一枚"旋转指针"，两个指针的夹角就代表它们之间的距离 | 通过对 Q 和 K 向量施加按维度分组的旋转变换，使得 Q 和 K 的点积仅依赖于相对位置，天然支持长度外推。是现代 LLM 的主流位置编码方案 |
| GQA (分组查询注意力) | 像多个学生（Q heads）共享同一本参考书（KV heads），节省了书的存放空间（KV Cache） | 将 Q heads 分成若干组，每组共享一对 K、V。num_kv_heads 远小于 num_heads，KV Cache 可减少 num_heads/num_kv_heads 倍。Llama 2 70B 用 64 Q heads + 8 KV heads |
| KV Cache | 像草稿纸：每写一个新 token 时，不需要重新推导前面所有的计算，只需翻看之前已经写好的草稿 | 自回归推理中缓存的 Key 和 Value 张量。每生成一个 token 只需计算新 token 的 QKV，历史的 K、V 直接从缓存读取，避免重复计算 |

---

## 目录

1. [PyTorch Tensor 操作深入](#1-pytorch-tensor-操作深入)
2. [Autograd 引擎：backward() 的工作原理](#2-autograd-引擎backward-的工作原理)
3. [nn.Module：构建一切的基石](#3-nnmodule构建一切的基石)
4. [Dataset 与 DataLoader：高效数据管线](#4-dataset-与-dataloader高效数据管线)
5. [Transformer 架构完整走读](#5-transformer-架构完整走读)
   - 5a. Token Embedding
   - 5b. 位置编码：从 Absolute 到 RoPE
   - 5c. Self-Attention：核心机制
   - 5d. Multi-Head Attention：为何需要多头
   - 5e. GQA（Grouped Query Attention）
   - 5f. MQA（Multi-Query Attention）
   - 5g. MLA（Multi-head Latent Attention）
   - 5h. Feed-Forward Network：SwiGLU vs 标准 FFN
   - 5i. 残差连接与 Pre-LN vs Post-LN
   - 5j. RMSNorm
6. [Transformer 前向传播内存分析](#6-transformer-前向传播内存分析)
7. [从零实现 Mini GPT-2](#7-从零实现-mini-gpt-2约-200-行带详细注释)
8. [模型加载：Safetensors、分片与延迟加载](#8-模型加载safetensors-分片与延迟加载)
9. [HuggingFace Transformers 库内部机制](#9-huggingface-transformers-库内部机制)
10. [深入学习资源](#10-深入学习资源)

---

## 1. PyTorch Tensor 操作深入

### 1.1 Tensor 的创建

Tensor 是 PyTorch 的核心数据结构，本质上是一个多维数组，可以在 GPU 上加速计算。

```python
import torch
import numpy as np

# ========== 基础创建 ==========
a = torch.zeros(3, 4)          # 全零张量，shape (3, 4)
b = torch.ones(2, 3)           # 全一张量，shape (2, 3)
c = torch.randn(4, 5)          # 标准正态分布 N(0,1)，shape (4, 5)
d = torch.arange(0, 10, 2)     # [0, 2, 4, 6, 8] -- 类似 Python range
e = torch.tensor([1, 2, 3])    # 从 Python 列表创建，自动推断 dtype

# ========== 从 NumPy 创建（零拷贝共享内存） ==========
np_arr = np.array([[1, 2], [3, 4]], dtype=np.float32)
t1 = torch.from_numpy(np_arr)   # 共享内存！修改 tensor 会影响 numpy array
t2 = torch.tensor(np_arr)       # 深拷贝，不共享内存

# ========== as_strided：零拷贝视图，极其危险但强大 ==========
# as_strided 可以创建任意的假视图，不复制数据，只改变元数据
x = torch.arange(1, 10).float()  # [1, 2, 3, 4, 5, 6, 7, 8, 9]
# 创建一个 3x3 的滑动窗口视图
sliding = torch.as_strided(x, size=(7, 3), stride=(1, 1))
# 注意：sliding 和 x 共享内存！修改 sliding[0,0] 会改变 x[0]

# ========== 指定 dtype 和 device ==========
f = torch.zeros(3, 4, dtype=torch.float16, device='cuda:0')
```

### 1.2 索引操作

```python
# ========== 高级索引（Advanced Indexing） ==========
x = torch.randn(4, 5)               # shape (4, 5)
rows = torch.tensor([0, 2, 3])      # 索引张量
selected = x[rows]                   # shape (3, 5)

# 多维索引：同时指定行和列
cols = torch.tensor([4, 3, 2])
selected = x[rows, cols]             # shape (3,), 取 (0,4), (1,3), (2,2)

# ========== 布尔遮罩（Boolean Masking） ==========
mask = x > 0.5                       # 布尔张量
positive = x[mask]                   # 一维张量，所有 >0.5 的元素

# ========== gather：按索引收集元素 ==========
# out[i][j][k] = input[index[i][j][k]][j][k]   (dim=0)
t_env = torch.tensor([[1, 2], [3, 4], [5, 6]])  # shape (3, 2)
index = torch.tensor([[0, 1], [2, 0], [1, 2]])
result = torch.gather(t_env, dim=0, index=index)
# 结果: [[1, 4], [5, 2], [3, 6]]

# ========== scatter_：gather 的逆操作 ==========
# 常用于 one-hot 编码、分布式通信中的 reduce-scatter
```

### 1.3 形状变换：view vs reshape vs permute

这是 PyTorch 中最容易出错的地方之一，核心问题在于**内存连续性（contiguity）**。

```python
x = torch.randn(2, 3, 4)       # shape (2, 3, 4)

# view：要求底层内存连续，不复制数据，零拷贝
y = x.view(2, 12)               # OK
z = x.view(-1, 4)               # -1 自动推断 -> (6, 4)

# transpose 破坏连续性
t_env = x.transpose(0, 1)           # shape (3, 2, 4)，但内存不再连续！
print(t_env.is_contiguous())        # False
# t_env.view(-1)                     # 报错！
t_fixed = t_env.contiguous()        # 强制创建连续副本（复制数据）

# reshape：优先尝试 view，不连续则自动 contiguous() + view()
# 更安全，但有隐藏的拷贝开销
t_reshape = t_env.reshape(-1)       # OK，自动处理

# permute：任意维度重排，同样破坏连续性
p = x.permute(2, 0, 1)          # shape (4, 2, 3)

# unsqueeze：插入维度
a_env = torch.randn(3, 4)           # shape (3, 4)
b_env = a_env.unsqueeze(0)              # shape (1, 3, 4)
c_env = a_env.unsqueeze(-1)             # shape (3, 4, 1)
```

### 1.4 设备管理

```python
# CPU <-> GPU 传输
x_cpu = torch.randn(1000, 1000)
x_gpu = x_cpu.to('cuda:0')          # 最通用的方法
x_gpu = x_cpu.cuda()                # 快捷方式
x_cpu_back = x_gpu.cpu()            # 回到 CPU

# ========== 传输开销：AI Infra 中最重要的性能考量之一 ==========
# PCIe 4.0 x16: ~32 GB/s (理论), 实际 ~20-25 GB/s
# 70B 参数模型(140GB FP16): 单次 CPU->GPU 加载需要 ~6-7 秒
# GPU HBM 带宽: A100: ~2 TB/s, H100: ~3.35 TB/s
# 带宽层级: GPU 计算 > GPU HBM > PCIe 传输 > CPU 内存 > 磁盘
```

### 1.5 内存布局：C-contiguous vs Fortran-contiguous

理解 Tensor 的内存布局对于优化 CUDA kernel 至关重要。

```
假设一个 3x4 的矩阵:
逻辑视图:                    内存中的实际存储 (C-contiguous, row-major):
[[a, b, c, d],              [a, b, c, d, e, f, g, h, i, j, k, l]
 [e, f, g, h],              地址: 0  1  2  3  4  5  6  7  8  9  10 11
 [i, j, k, l]]

stride = (4, 1): 移动到下一行 +4 个元素，移动到下一列 +1 个元素

transpose(0, 1) 变成 4x3:
逻辑视图:                    内存布局不变，但 stride 变成 (1, 4)!
[[a, e, i],
 [b, f, j],
 [c, g, k],
 [d, h, l]]

这就是 transpose 后 is_contiguous() 返回 False 的原因:
stride 不再从大到小递减排列
```

```python
x = torch.randn(3, 4)
print(x.stride())                # (4, 1) -- C-contiguous
t_env = x.transpose(0, 1)
print(t_env.stride())            # (1, 4) -- 非 contiguous
```

### 与 AI Infra 的关联

- **Tensor Layout 优化**：连续内存可以矢量化加载（float4 一次加载 4 个 float），而非连续访问会导致 bank conflict 和缓存未命中。
- **NCHW vs NHWC**：卷积网络中通道维度的排布选择（NVIDIA 偏好 NCHW，TPU 偏好 NHWC）本质上是选择不同的 stride 模式来优化内存访问。
- **FlashAttention**：通过分块（tiling）技术，将 attention 计算重新组织为对 GPU SRAM 友好的内存访问模式。理解 stride 是前提。
- **vLLM 的 PagedAttention**：通过将 KV cache 组织为非连续的内存页，解决 KV cache 内存碎片问题。需要精细控制 tensor 的 stride 和内存布局。

---

## 2. Autograd 引擎：backward() 的工作原理

### 2.1 计算图：动态构建

PyTorch 使用**动态计算图**（define-by-run）：每次前向传播时实时构建图，图结构可以随输入数据变化。

```python
x = torch.randn(3, 4, requires_grad=True)  # 标记需要梯度
# requires_grad=True 的效果:
# 1. 所有以 x 为输入的操作都会被跟踪
# 2. x.grad 初始化为 None，backward 后会累积梯度
# 3. x 的 grad_fn 为 None（叶子节点）

w_env = torch.randn(4, 2, requires_grad=True)
b_env = torch.randn(2, requires_grad=True)

# 前向传播：一边计算，一边自动构建计算图
y = x @ w_env + b_env      # y.shape = (3, 2)
loss = y.sum()             # 标量

# 图结构（自动构建）:
# x [leaf] --.
#             +--> mm --> add --> sum [output]
# w [leaf] --'         |
# b [leaf] ------------'

print(f'x 是叶子节点: {x.is_leaf}')      # True
print(f'y 是叶子节点: {y.is_leaf}')      # False (由操作产生)
print(f'y.grad_fn: {y.grad_fn}')        # <AddBackward0>
```

### 2.2 backward()：梯度计算与累积

```python
loss.backward()  # 从 loss 开始，沿图反向传播，计算所有叶子节点的梯度
# 梯度存储在 .grad 中:
print(w_env.grad.shape)   # (4, 2) -- 和 w_env 相同

# ========== 关键：梯度是累积的（非覆盖）！ ==========
# 如果再次调用 backward() 而不清零:
y2 = x @ w_env + b_env
loss2 = y2.sum()
loss2.backward()  # w_env.grad 会加上新的梯度！

# ========== zero_grad()：训练循环中必须的操作 ==========
# 标准训练循环:
# for epoch in range(num_epochs):
#     for batch in dataloader:
#         optimizer.zero_grad()   # 清零所有参数的 .grad
#         output = model(batch)
#         loss = criterion(output, target)
#         loss.backward()          # 累积当前 batch 的梯度
#         optimizer.step()         # 使用梯度更新参数

# 手动清零方式比较:
# 方式 1: optimizer.zero_grad()  -- 标准做法
# 方式 2: model.zero_grad()      -- 模型级别
# 方式 3: param.grad = None      -- 最底层，最高效，比 .zero_() 更好
```

### 2.3 torch.no_grad() vs torch.inference_mode()

```python
# torch.no_grad(): 禁用梯度计算，但保留 autograd 痕迹
# 适合: 验证、测试、需要微调时临时禁用梯度
with torch.no_grad():
    y = model(x)          # 不记录计算图

# torch.inference_mode(): 更激进，完全禁用 autograd 跟踪
# 性能更好，限制更多。适合: 纯推理场景
with torch.inference_mode():
    y = model(x)          # 完全不记录任何 autograd 信息

# 性能对比（相对）:
# 正常模式:       100%  (baseline)
# no_grad():      ~95%  (仍有一些 autograd 开销)
# inference_mode(): ~85-90% (几乎无 autograd 开销)
```

### 2.4 retain_graph：多次 backward

```python
# 默认 backward() 会释放计算图的中间缓冲区以节省内存
# 再次调用会报错: Trying to backward through the graph a second time

# 解决方案: retain_graph=True
# z.backward(retain_graph=True)   # 图保留
# z.backward()                     # OK, 梯度会累积

# 何时需要:
# 1. 多任务学习：多个损失函数共享同一子图
# 2. GAN 训练：生成器和判别器共享部分网络
# 3. 元学习（MAML）：需要对同一图进行多次微分
```

### 与 AI Infra 的关联

- **推理引擎必须使用 `torch.inference_mode()`**：vLLM、TGI 等推理框架在推理时禁用 autograd，节省约 10-15% 的显存和时间开销。
- **训练框架需要精细控制梯度**：DeepSpeed、Megatron 在实现 pipeline parallelism 时，需要在不同 micro-batch 之间手动管理 backward() 的调用时机。
- **Gradient Checkpointing**：利用 `torch.no_grad()` 在前向时不保存中间激活，反向时重算 -- 这是 autograd 系统的反向利用。
- **混合精度训练中的梯度缩放**：autograd 的 hook 机制（`register_hook`）被广泛用于实现 loss scaling、梯度裁剪等。

---

## 3. nn.Module：构建一切的基石

### 3.1 基本结构

```python
import torch.nn as nn

class MyModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super().__init__()  # 必须调用！注册内部状态
        self.weight = nn.Parameter(torch.randn(input_dim, hidden_dim))
        self.linear = nn.Linear(hidden_dim, output_dim)
        self.counter = 0  # 普通变量不会被注册到 state_dict

    def forward(self, x):
        # __call__ 会自动调用 forward，并在前后处理 hooks
        x = x @ self.weight
        return self.linear(x)

# nn.Module 的核心能力:
# 1. 自动发现所有 nn.Parameter 和子 nn.Module
# 2. .to(device), .train(), .eval(), .cuda() 递归传播
# 3. state_dict() / load_state_dict() 序列化
# 4. apply(fn) 对所有子模块递归应用函数
# 5. register_forward_hook / register_backward_hook 钩子系统
```

### 3.2 parameters() 与 Buffers

```python
# parameters(): 只返回 nn.Parameter（可训练参数）
total = sum(p.numel() for p in model.parameters())
trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)

# named_parameters(): 返回 (name, parameter) 对
# 命名规则: 子模块名用 '.' 分隔，如 'linear.weight', 'linear.bias'

# Buffers: 不可训练的状态（如 BatchNorm 的 running_mean）
self.register_buffer('running_mean', torch.zeros(64))  # 随模型保存但不训练

# 常见的 buffer 用途:
# 1. BatchNorm: running_mean, running_var
# 2. 固定正弦位置编码: 预计算的 sin/cos 表
# 3. 因果掩码: 预计算的 mask 矩阵
# 4. RoPE: 预计算的 cos/sin 频率缓存
```

### 3.3 state_dict() 和 load_state_dict()

```python
torch.save(model.state_dict(), 'model.pth')  # 只保存参数和 buffer
state_dict = torch.load('model.pth')
model.load_state_dict(state_dict, strict=True)  # strict: 所有 key 必须匹配

# 部分加载（微调场景）:
pretrained = torch.load('pretrained.pth')
model_dict = model.state_dict()
pretrained = {k: v for k, v in pretrained.items()
              if k in model_dict and v.shape == model_dict[k].shape}
model_dict.update(pretrained)
model.load_state_dict(model_dict, strict=False)
```

### 3.4 train() vs eval()

```python
model.train()  # training=True, Dropout 激活, BN 用 batch 统计量
model.eval()   # training=False, Dropout 恒等映射, BN 用 running 统计量

# 常见陷阱:
# 1. 推理时必须调用 model.eval()，否则 Dropout 会引入随机性
# 2. 验证集上也要 model.eval()，否则 BN 统计不准确
# 3. 微调时冻结 BN 需要同时设置 BN 为 eval 模式
```

### 与 AI Infra 的关联

- **模型分片必须处理 state_dict**：Megatron-LM 的张量并行将一个 Linear 的权重按列/行切分。checkpoint 需要知道切分方式才能正确合并/拆分。
- **推理优化中的 operator fusion**：了解 nn.Module 结构有助于识别可融合的操作序列，如 Linear + LayerNorm + Residual 融合。
- **Hook 系统在 Profiling 中的应用**：被 PyTorch Profiler、DeepSpeed 等工具广泛用于捕获中间激活、分析内存。
- **PEFT（LoRA 等）**：通过 register_parameter 添加低秩矩阵，依赖 nn.Module 的参数注册机制。

---

## 4. Dataset 与 DataLoader：高效数据管线

### 4.1 Dataset 基类

```python
from torch.utils.data import Dataset, DataLoader, IterableDataset

class TextDataset(Dataset):
    def __init__(self, texts, tokenizer, max_length=512):
        self.texts = texts
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        tokens = self.tokenizer(
            self.texts[idx],
            max_length=self.max_length,
            truncation=True,
            padding='max_length',
            return_tensors='pt'
        )
        return {'input_ids': tokens['input_ids'].squeeze(0),
                'attention_mask': tokens['attention_mask'].squeeze(0)}

# IterableDataset: 流式数据，适合超大数据集
class StreamingTextDataset(IterableDataset):
    def __init__(self, file_path, tokenizer):
        self.file_path = file_path
        self.tokenizer = tokenizer
    def __iter__(self):
        with open(self.file_path) as f:
            for line in f:
                yield self.tokenizer(line.strip())
```

### 4.2 DataLoader 核心参数

```python
dataloader = DataLoader(
    dataset,
    batch_size=32,           # 每个 batch 的样本数
    shuffle=True,            # 每个 epoch 打乱数据
    num_workers=4,           # 子进程数，并行加载
    pin_memory=True,         # page-locked memory，加速 GPU 传输
    drop_last=True,          # 丢弃不完整的最后一个 batch
    collate_fn=None,         # 自定义 batch 组装
    prefetch_factor=2,       # 每个 worker 预取 batch 数
    persistent_workers=True, # worker 进程跨 epoch 保持存活
)

# num_workers 选择指南:
# - 太少: GPU 等待数据（GPU 饥饿）
# - 太多: CPU 内存和进程间通信开销大
# - 经验值: 4 * num_gpus 是常见起点

# pin_memory 原理:
# 普通内存 -> GPU: 需要先拷贝到 pinned 临时缓冲区（多一次拷贝）
# Pinned 内存 -> GPU: GPU DMA 直接访问（更快，但占用物理内存）
```

### 4.3 collate_fn 与 DistributedSampler

```python
# 自定义 collate: 处理变长序列
def custom_collate(batch):
    input_ids = [item['input_ids'] for item in batch]
    max_len = max(len(ids) for ids in input_ids)
    padded = torch.zeros(len(batch), max_len, dtype=torch.long)
    for i, ids in enumerate(input_ids):
        padded[i, :len(ids)] = ids
    return padded

# LLM 预训练中拼接+chunk 更高效
def lm_collate(batch):
    all_tokens = torch.cat([item['input_ids'] for item in batch])
    total_len = (all_tokens.size(0) // 2048) * 2048
    return all_tokens[:total_len].view(-1, 2048)

# DistributedSampler: 分布式训练的数据划分
from torch.utils.data.distributed import DistributedSampler
sampler = DistributedSampler(
    dataset, num_replicas=world_size, rank=rank, shuffle=True)
# 每个 epoch 调用 sampler.set_epoch(epoch) 确保数据顺序不同
```

### 与 AI Infra 的关联

- **推理服务的 Continuous Batching**：vLLM 的核心创新 -- 动态地从 batch 中添加/移除请求，最大化 GPU 利用率。本质上是更复杂的 collate_fn + 状态管理。
- **Prefill 和 Decode 分离调度**：prefill（处理 prompt）是 compute-bound，decode（逐 token 生成）是 memory-bound，推理引擎将两者分开调度。
- **DataLoader 是训练吞吐的关键瓶颈**：NVIDIA DALI 和 WebDataset 格式都是为了加速数据加载。
- **Streaming dataset 用于大规模预训练**：Megatron-LM 使用自定义 indexed dataset 格式配合二进制索引文件。

---

## 5. Transformer 架构完整走读

### 整体架构速览

```
                     Transformer 整体架构 (Pre-LN 风格)

                         Input Token IDs
                               |
                    +----------+----------+
                    |    Token Embedding   |
                    +----------+----------+
                               |
                    +----------+----------+
                    |  Position Encoding  |  (RoPE: 作用在 Attention 内部)
                    +----------+----------+
                               |
               +---------------+---------------+
               |     Transformer Block x N      |
               |  +----------------------------+|
               |  |        RMSNorm             ||
               |  +----------------------------+|
               |  |  Multi-Head Attention      ||
               |  |  (with GQA / MLA / ...)    ||
               |  +----------------------------+|
               |  |    Residual Connection     ||
               |  +----------------------------+|
               |  |        RMSNorm             ||
               |  +----------------------------+|
               |  |  Feed-Forward (SwiGLU)     ||
               |  +----------------------------+|
               |  |    Residual Connection     ||
               |  +----------------------------+|
               +-------------------------------+
                               |
                    +----------+----------+
                    |      RMSNorm         |
                    +----------+----------+
                               |
                    +----------+----------+
                    |    LM Head (Linear)  |  -> logits -> softmax -> next token
                    +---------------------+
```

输入 token 序列经过 N 层 Transformer Block 后，最后一层的 hidden states 通过 LM Head 投影到词表大小，产生每个位置对下一个 token 的预测。

---

### 5a. Token Embedding

```python
# nn.Embedding 本质上是一个可训练的查找表
# 参数形状: [vocab_size, hidden_dim]
# Llama 2 7B: vocab_size=32000, hidden_dim=4096 -> 131M 参数 (~2%)

class TokenEmbedding(nn.Module):
    def __init__(self, vocab_size, hidden_dim):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, hidden_dim)

    def forward(self, input_ids):
        # input_ids: [batch, seq_len] -> output: [batch, seq_len, hidden_dim]
        return self.embedding(input_ids)

# ========== Weight Tying（权重共享） ==========
# 许多模型将 Embedding 和 LM Head 共享权重，减少参数量
class GPTModel(nn.Module):
    def __init__(self, vocab_size, hidden_dim):
        super().__init__()
        self.token_embedding = nn.Embedding(vocab_size, hidden_dim)
        self.lm_head = nn.Linear(hidden_dim, vocab_size, bias=False)
        self.lm_head.weight = self.token_embedding.weight  # 共享！

# Embedding 层的计算特性: gather 操作 -> memory-bound
# 计算量极小（只做索引查找），内存访问大（需要从 HBM 读取嵌入表）
```

### 与 AI Infra 的关联

- **Embedding 层是 Memory-Bound 的**：大词表（250K+ tokens）使 embedding 矩阵非常大。embedding lookup 和 lm_head projection 都是 memory-bound 操作。
- **Embedding 的分片策略**：张量并行中 embedding 通常按词表维度切分（vocab parallelism）。
- **Weight tying 的分布式约束**：共享权重意味着 embedding 和 lm_head 必须在同一设备上。

---

### 5b. 位置编码：从 Absolute 到 RoPE

#### (1) Learned Absolute Position

```python
class LearnedPositionEmbedding(nn.Module):
    """可学习的绝对位置编码（GPT-1 使用）"""
    def __init__(self, max_seq_len, hidden_dim):
        super().__init__()
        self.position_embedding = nn.Embedding(max_seq_len, hidden_dim)

    def forward(self, x):
        # x: [batch, seq_len, hidden_dim]
        seq_len = x.size(1)
        positions = torch.arange(seq_len, device=x.device)
        pos_emb = self.position_embedding(positions)  # [seq_len, hidden_dim]
        return x + pos_emb.unsqueeze(0)

# 优点: 简单直观   缺点: 无法外推到超过 max_seq_len 的长度
```

#### (2) Sinusoidal Position Encoding

```python
class SinusoidalPositionEmbedding(nn.Module):
    """固定的正弦位置编码（原始 Transformer、BERT 使用）"""
    def __init__(self, max_seq_len, hidden_dim):
        super().__init__()
        pe = torch.zeros(max_seq_len, hidden_dim)
        position = torch.arange(max_seq_len).unsqueeze(1).float()
        # div_term = 10000^(2i/d)
        div_term = torch.exp(
            torch.arange(0, hidden_dim, 2).float() *
            -(torch.log(torch.tensor(10000.0)) / hidden_dim)
        )
        pe[:, 0::2] = torch.sin(position * div_term)  # 偶数位
        pe[:, 1::2] = torch.cos(position * div_term)  # 奇数位
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:x.size(1)]

# 特点: 位置 pos+k 的编码可以表示为 pos 编码的线性变换
# 有一定外推能力（但不完美），被 BERT、原始 Transformer 使用
```

#### (3) RoPE (Rotary Position Embedding) -- 现代标准

RoPE 是目前 LLM 的主流位置编码方式（Llama, Mistral, Qwen, DeepSeek 等都在使用）。

**核心思想**: 通过对 Query 和 Key 向量施加旋转变换，使得它们的点积仅依赖于 token 之间的相对位置。

```
RoPE 的数学本质:

在 2D 空间中的旋转矩阵:
    R(theta) = [cos(theta)   -sin(theta)]
               [sin(theta)    cos(theta)]

应用于向量 x = [x1, x2] 时:
    R(theta) * x = [x1*cos(theta) - x2*sin(theta)]
                   [x1*sin(theta) + x2*cos(theta)]

将 hidden_dim 分成 d/2 对，每对使用不同的旋转角度:
    theta_i = base^(-2i/d),  其中 base = 10000 (常用值)
    i = 0, 1, 2, ..., d/2 - 1

对于位置 m 的 query 和位置 n 的 key:
    q_m^T * k_n = (R(m*theta) * q)^T * (R(n*theta) * k)
                = q^T * R((n-m)*theta) * k

关键: 点积结果只依赖于 (n-m) 即相对位置!

这是为什么 RoPE 支持长度外推:
- 训练时见过相对距离 0, 1, ..., 2047
- 推理时遇到相对距离 4096 -> 因为是位置差的函数，
  模型可以通过类似距离的模式来泛化
```

```python
class RotaryEmbedding(nn.Module):
    """RoPE 的标准实现"""
    def __init__(self, head_dim, max_seq_len=2048, base=10000.0):
        super().__init__()
        self.head_dim = head_dim
        self.max_seq_len = max_seq_len
        self.base = base
        self.register_buffer('cos_cached', None)
        self.register_buffer('sin_cached', None)
        self._build_cache()

    def _build_cache(self):
        # theta_i = base^(-2i/d)
        theta = 1.0 / (
            self.base ** (torch.arange(0, self.head_dim, 2).float() / self.head_dim)
        )
        position = torch.arange(self.max_seq_len).float()
        freq = torch.outer(position, theta)  # [max_seq_len, head_dim/2]
        self.cos_cached = freq.cos()
        self.sin_cached = freq.sin()

    def forward(self, x, position_ids=None):
        # x: [batch, num_heads, seq_len, head_dim]
        seq_len = x.size(2)
        if position_ids is None:
            cos = self.cos_cached[:seq_len].unsqueeze(0).unsqueeze(0)
            sin = self.sin_cached[:seq_len].unsqueeze(0).unsqueeze(0)
        else:
            cos = self.cos_cached[position_ids].unsqueeze(1)
            sin = self.sin_cached[position_ids].unsqueeze(1)

        # 将 head_dim 分成对: [x0, x1, x2, x3, ...] -> [(x0, x1), (x2, x3), ...]
        x_reshaped = x.float().reshape(*x.shape[:-1], -1, 2)
        x1, x2 = x_reshaped[..., 0], x_reshaped[..., 1]
        # 应用旋转: [x1*cos - x2*sin, x1*sin + x2*cos]
        x_rotated = torch.stack([
            x1 * cos - x2 * sin,
            x1 * sin + x2 * cos
        ], dim=-1).flatten(-2)
        return x_rotated.to(x.dtype)
```

### 与 AI Infra 的关联

- **RoPE 的 Kernel Fusion**：FlashAttention-2 将 RoPE 计算融合到 attention kernel 内部，避免单独读写 Q 和 K，对长序列推理特别重要。
- **RoPE 的微调扩展**：YaRN 将 base frequency 缩放并配合 NTK-aware interpolation，可将上下文长度扩展 4-8 倍无需完全重新训练。
- **不同 base 的影响**：Llama 3 用 500,000，Qwen 2 用 1,000,000 -- 更大的 base 更好地支持长上下文。

---

### 5c. Self-Attention：核心机制

#### 缩放点积注意力

```
Attention(Q, K, V) = softmax(Q @ K^T / sqrt(d_k)) @ V

         +-------+     +-------+     +-------+
         |   Q   |     |   K   |     |   V   |
         +---|---+     +---|---+     +---|---+
             |               |             |
             |   Q @ K^T     |             |
             +------>--------+             |
             |                            |
        +----v----+                      |
        |  Scale  |  (/ sqrt(d_k))        |
        +----+----+                      |
             |                            |
        +----v----+                      |
        |  +Mask  |  (causal mask)        |
        +----+----+                      |
             |                            |
        +----v----+                      |
        | Softmax |                      |
        +----+----+                      |
             |                            |
             |       weights @ V          |
             +------------->-------------+
             |
        +----v----+
        |  Output |
        +---------+

为什么除以 sqrt(d_k)?
Q 和 K 的元素独立同分布 N(0,1)，Q@K^T 的方差 = d_k。
d_k 越大 -> 点积越大 -> softmax 进入饱和区 -> 梯度接近 0。
除以 sqrt(d_k) 使方差归一到 1，保持梯度健康。
```

```python
def scaled_dot_product_attention(Q, K, V, mask=None):
    # Q: [batch, num_heads, seq_q, head_dim]
    # K: [batch, num_heads, seq_k, head_dim]
    # V: [batch, num_heads, seq_k, head_dim]
    d_k = Q.size(-1)
    scores = torch.matmul(Q, K.transpose(-2, -1))  # [batch, h, seq_q, seq_k]
    scores = scores / math.sqrt(d_k)                # 缩放
    if mask is not None:
        scores = scores.masked_fill(mask == 0, float('-inf'))
    attn_weights = torch.softmax(scores, dim=-1)
    return torch.matmul(attn_weights, V)

# Causal Mask: 确保每个 token 只能看到它自己和之前的 token
def create_causal_mask(seq_len):
    mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1)
    return mask == 0  # True=可见, False=不可见
# seq_len=4:
#    [ T  F  F  F ]  pos0 只看自己
#    [ T  T  F  F ]  pos1 看 0,1
#    [ T  T  T  F ]  pos2 看 0,1,2
#    [ T  T  T  T ]  pos3 看所有
```

### 与 AI Infra 的关联

- **Attention 的 O(n^2) 是长上下文推理的瓶颈**：128K 上下文时 attention score 矩阵 16G 元素，一个 attention 层就需要 32GB (FP16)。
- **FlashAttention**：softmax 可在分块（tile）基础上正确计算，将 O(n^2) 内存访问降为 O(n)。
- **KV Cache**：每生成一个 token 都需要访问整个 KV cache。128K 上下文 Llama 2 70B 需约 640GB 显存。直接催生了 GQA、MQA、MLA。

---

### 5d. Multi-Head Attention：为何需要多头

```
MHA 流程:
1. 线性投影: Q=x@W_Q, K=x@W_K, V=x@W_V  [batch, seq_len, hidden_dim]
2. 拆分为多头: reshape -> [batch, num_heads, seq_len, head_dim]
   拆分示意 (num_heads=4, head_dim=64, hidden_dim=256):
   Head 0: dims[0:64], Head 1: dims[64:128], etc.
3. 每个头独立做 Attention -> [batch, seq_len, head_dim]
4. 拼接 -> [batch, seq_len, hidden_dim]
5. 输出投影: output = concat @ W_O

为什么需要多头？
- 不同头关注不同的关系模式（语法、语义、位置）
- 集成效果，在不同表示子空间中同时关注
- 经验表明多头 > 单头加宽
```

```python
class MultiHeadAttention(nn.Module):
    def __init__(self, hidden_dim, num_heads, dropout=0.0):
        super().__init__()
        assert hidden_dim % num_heads == 0
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        # 合并 QKV 投影为一个 Linear 以提高效率
        self.qkv_proj = nn.Linear(hidden_dim, 3 * hidden_dim, bias=False)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)

    def forward(self, x, mask=None):
        batch, seq_len, _ = x.shape
        qkv = self.qkv_proj(x)  # [batch, seq_len, 3*hidden_dim]
        qkv = qkv.reshape(batch, seq_len, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # [3, batch, num_heads, seq_len, head_dim]
        Q, K, V = qkv[0], qkv[1], qkv[2]
        attn = scaled_dot_product_attention(Q, K, V, mask)
        # [batch, num_heads, seq_len, head_dim] -> merge heads
        attn = attn.transpose(1, 2).contiguous()
        attn = attn.reshape(batch, seq_len, self.hidden_dim)
        return self.out_proj(attn)
```

### 与 AI Infra 的关联

- **head_dim 影响 Tensor Core 效率**：需要是 8（FP16）或 16（int8）的倍数。head_dim=64 效率高，80 需要 padding。
- **Heads 可并行**：FlashAttention 利用 head 间独立性并行处理。
- **Tensor Parallelism 按 Head 切分**：Megatron-LM 中 QKV 投影按 head 维度切分到不同 GPU。

---

### 5e. GQA (Grouped Query Attention)：KV Cache 优化

```
GQA 的核心思想:

MHA (num_heads=8):
  Q: [Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7]  (8 个查询头)
  K: [K0, K1, K2, K3, K4, K5, K6, K7]  (8 个键头)
  V: [V0, V1, V2, V3, V4, V5, V6, V7]  (8 个值头)
  KV cache: 8 组 K, V per layer

GQA (num_heads=8, num_kv_heads=4):
  Q: [Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7]  (不变)
  K: [K0,      K2,      K4,      K6   ]  (4 个键头)
  V: [V0,      V2,      V4,      V6   ]  (4 个值头)
  分组: [Q0,Q1] [Q2,Q3] [Q4,Q5] [Q6,Q7]
      共享 K0,V0    共享 K2,V2   共享 K4,V4   共享 K6,V6
  KV cache 节省: 50%

Llama 2 70B: num_heads=64, num_kv_heads=8 -> 8x KV cache 减少!
```

```python
class GroupedQueryAttention(nn.Module):
    def __init__(self, hidden_dim, num_heads, num_kv_heads, dropout=0.0):
        super().__init__()
        assert num_heads % num_kv_heads == 0
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = hidden_dim // num_heads
        self.num_queries_per_kv = num_heads // num_kv_heads
        # Q 投影: num_heads * head_dim 输出
        self.q_proj = nn.Linear(hidden_dim, num_heads * self.head_dim, bias=False)
        # K, V 投影: num_kv_heads * head_dim 输出（更少！）
        self.k_proj = nn.Linear(hidden_dim, num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(hidden_dim, num_kv_heads * self.head_dim, bias=False)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)

    def repeat_kv(self, kv, n_rep):
        batch, n_kv, seq_len, hd = kv.shape
        if n_rep == 1:
            return kv
        # expand KV heads 以匹配 Q heads 数量
        kv = kv.unsqueeze(2).expand(batch, n_kv, n_rep, seq_len, hd)
        return kv.reshape(batch, n_kv * n_rep, seq_len, hd)

    def forward(self, x, mask=None):
        batch, seq_len, _ = x.shape
        Q = self.q_proj(x).view(batch, seq_len, self.num_heads, self.head_dim)
        K = self.k_proj(x).view(batch, seq_len, self.num_kv_heads, self.head_dim)
        V = self.v_proj(x).view(batch, seq_len, self.num_kv_heads, self.head_dim)
        Q, K, V = Q.transpose(1, 2), K.transpose(1, 2), V.transpose(1, 2)
        # 扩展 KV 以匹配 Q 的头数
        K = self.repeat_kv(K, self.num_queries_per_kv)
        V = self.repeat_kv(V, self.num_queries_per_kv)
        attn = scaled_dot_product_attention(Q, K, V, mask)
        attn = attn.transpose(1, 2).contiguous().view(batch, seq_len, -1)
        return self.out_proj(attn)
```

### 与 AI Infra 的关联

- **KV Cache 是推理的绝对瓶颈**：batch=32, seq_len=32K, Llama 2 70B (GQA 64/8) 的 KV cache 仍占用 ~64GB。
- **GQA 无可争议地更好**：Llama 3, Mistral, Qwen 2, Gemma 2 全部使用 GQA -- KV cache 节省远超微小质量损失。
- **PagedAttention**：vLLM 需要精细管理 KV cache 页，GQA 减少了页数量，降低管理开销。

---

### 5f. MQA (Multi-Query Attention)：极端情况

```
MQA: GQA 的特例，num_kv_heads = 1

Q heads: [Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7]  (8 个查询头)
K heads: [K0                                    ]  (1 个键头)
V heads: [V0                                    ]  (1 个值头)
所有 Q 头共享同一个 K 和 V
KV cache 节省: num_heads 倍 (例如 8x)

使用 MQA 的模型: PaLM, Gemini 1.0, Falcon

优缺点:
+ 最大化的 KV cache 节省
+ 推理最简单（KV 只有一个头）
- 可能损失一些质量（注意力模式受限）
- 训练时需要通过特殊初始化来缓解质量损失
```

### 与 AI Infra 的关联

- **MQA 推理最简单**：因为只有一个 KV 头，推理引擎的内存管理和 kernel 实现最简单。但多数模型选择 GQA 作为质量和效率的折中。
- **Uptraining**：从 MHA checkpoint 初始化 MQA，通过对 K 和 V 头取均值来初始化共享的 K, V。

---

### 5g. MLA (Multi-head Latent Attention)：DeepSeek 的创新

MLA 是 DeepSeek-V2/V3 最核心的创新之一，通过将 K 和 V 压缩到低维潜在空间来大幅减少 KV cache。

```
MLA 的核心架构:

传统 Attention (以单头为例):
  Q = x @ W_Q    K = x @ W_K    V = x @ W_V
  KV cache 需要存储: K 和 V，每层每头 head_dim*2 元素 per token

MLA 的做法:
  Step 1: 将 x 压缩到低维潜在空间
    c_KV = x @ W_DKV      [batch, seq_len, d_c]  d_c << head_dim
    其中 W_DKV: [hidden_dim, d_c] 是降维矩阵

  Step 2: 从潜在表示恢复 K 和 V
    K = c_KV @ W_UK       [batch, seq_len, head_dim]
    V = c_KV @ W_UV       [batch, seq_len, head_dim]
    其中 W_UK, W_UV: [d_c, head_dim] 是升维矩阵

  Step 3: 对 Q 也做类似的压缩
    c_Q = x @ W_DQ        [batch, seq_len, d_c']
    Q = c_Q @ W_UQ        [batch, seq_len, head_dim]

  RoPE 处理: 使用解耦 RoPE 策略
    - K 的一部分携带位置信息（通过 RoPE 添加），不压缩
    - K 的其他部分通过 MLA 压缩

  KV cache 存储: c_KV + K_RoPE portion (而非完整的 K, V)

DeepSeek-V2 实际参数:
  hidden_dim=5120, num_heads=128, head_dim=128
  d_c (KV 压缩维度) = 512
  原始 MHA: 128 heads * 128 dim * 2 (K+V) = 32768 维/token
  MLA: 512 (c_KV) + 64 (RoPE portion) = 576 维/token
  节省: 32768 / 576 ≈ 56.9x !
```

```
MLA 架构图:

输入 x [hidden_dim]
    |
    +---> W_DKV [hidden_dim, d_c] ---> c_KV [d_c] ---> KV Cache (只存这个!)
    |         |
    |         +---> W_UK [d_c, head_dim] ---> K (no RoPE)
    |         |
    |         +---> W_UV [d_c, head_dim] ---> V
    |
    +---> W_DQ [hidden_dim, d_c'] --> W_UQ [d_c', head_dim*h] --> Q (no RoPE)
    |
    +---> W_KR [hidden_dim, head_dim] ---> 分离的 K_RoPE ---> KV Cache
    +---> W_QR [hidden_dim, head_dim] ---> 分离的 Q_RoPE

    Final K = concat(K_no_RoPE, K_RoPE)
    Final Q = concat(Q_no_RoPE, Q_RoPE)
    Attention(Q, K, V) as usual
```

```python
class MultiHeadLatentAttention(nn.Module):
    """MLA 的简化实现，展示核心思想"""
    def __init__(self, hidden_dim, num_heads, head_dim,
                 kv_lora_rank=512, q_lora_rank=1536,
                 qk_rope_head_dim=64):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.kv_lora_rank = kv_lora_rank  # c_KV 的维度
        self.q_lora_rank = q_lora_rank
        self.qk_rope_head_dim = qk_rope_head_dim  # RoPE 部分维度
        self.qk_nope_head_dim = head_dim - qk_rope_head_dim  # 非 RoPE 部分

        # KV 压缩投影: x -> c_KV + K_RoPE
        self.kv_a_proj_with_mqa = nn.Linear(
            hidden_dim, kv_lora_rank + qk_rope_head_dim, bias=False)
        self.kv_a_layernorm = nn.LayerNorm(kv_lora_rank)
        # 从压缩表示恢复到 K 和 V
        self.kv_b_proj = nn.Linear(
            kv_lora_rank,
            num_heads * (self.qk_nope_head_dim + head_dim),
            bias=False)

        # Q 压缩投影
        self.q_a_proj = nn.Linear(hidden_dim, q_lora_rank, bias=False)
        self.q_a_layernorm = nn.LayerNorm(q_lora_rank)
        self.q_b_proj = nn.Linear(
            q_lora_rank, num_heads * head_dim, bias=False)
        self.q_rope_proj = nn.Linear(
            hidden_dim, num_heads * qk_rope_head_dim, bias=False)
        self.out_proj = nn.Linear(num_heads * head_dim, hidden_dim, bias=False)

    def forward(self, x, position_ids=None):
        batch, seq_len, _ = x.shape
        # 1. KV 压缩: x -> c_KV + K_RoPE
        kv_a = self.kv_a_proj_with_mqa(x)
        kv_a_nope = kv_a[:, :, :self.kv_lora_rank]  # 压缩的非 RoPE 部分
        k_rope = kv_a[:, :, self.kv_lora_rank:]     # RoPE 部分

        # 2. 从压缩表示恢复 K 和 V
        kv_a_normed = self.kv_a_layernorm(kv_a_nope)
        kv_b = self.kv_b_proj(kv_a_normed)
        k_nope = kv_b[:, :, :self.num_heads * self.qk_nope_head_dim]
        v = kv_b[:, :, self.num_heads * self.qk_nope_head_dim:]
        k_nope = k_nope.view(batch, seq_len, self.num_heads, self.qk_nope_head_dim)
        k_rope = k_rope.view(batch, seq_len, 1, self.qk_rope_head_dim)
        k_rope = k_rope.expand(-1, -1, self.num_heads, -1)
        v = v.view(batch, seq_len, self.num_heads, self.head_dim)
        K = torch.cat([k_nope, k_rope], dim=-1)

        # 3. Q 压缩: x -> c_Q -> Q
        q_a = self.q_a_proj(x)
        q_nope = self.q_b_proj(self.q_a_layernorm(q_a))
        q_nope = q_nope.view(batch, seq_len, self.num_heads, self.qk_nope_head_dim)
        q_rope = self.q_rope_proj(x).view(
            batch, seq_len, self.num_heads, self.qk_rope_head_dim)
        Q = torch.cat([q_nope, q_rope], dim=-1)

        # 4. Attention
        Q, K, V = Q.transpose(1, 2), K.transpose(1, 2), V.transpose(1, 2)
        output = scaled_dot_product_attention(Q, K, V)
        output = output.transpose(1, 2).contiguous().view(batch, seq_len, -1)
        return self.out_proj(output)
```

### 与 AI Infra 的关联

- **MLA 是 DeepSeek-V2/V3 能与 GPT-4 竞争同时成本更低的关键技术**。KV cache 的 10-50 倍减少意味着可以用更少的 GPU 服务更长的上下文。
- **inference 引擎适配 MLA 并不容易**：标准 FlashAttention 期望 K 和 V 的头数与 Q 相同，而 MLA 的压缩-解压结构需要自定义 kernel。vLLM 和 SGLang 都专门为 MLA 添加了支持。
- **MLA 的硬件效率**：更小的 KV cache 意味着 memory-bound 程度降低，可更充分地利用计算单元。

---

### 5h. Feed-Forward Network：SwiGLU vs 标准 FFN

```
标准 FFN (原始 Transformer):
    y = W2 @ ReLU(W1 @ x + b1) + b2
    参数量: 2 * hidden_dim * intermediate_dim

    x -> [Linear: hidden->intermediate] -> ReLU -> [Linear: intermediate->hidden] -> y

SwiGLU (Llama, Mistral, Qwen 等现代模型):
    y = (W1 @ x * SiLU(Wg @ x)) @ W2
    参数量: 3 * hidden_dim * intermediate_dim  (3 个权重矩阵)

    x ---+---> [Linear: hidden->intermediate] ---+
         |                                       |
         +---> [Linear: hidden->intermediate] -> SiLU -> gate
         |                                       |
                                                  * ---> [Linear: intermediate->hidden] -> y

SiLU (Sigmoid Linear Unit) = x * sigmoid(x)
也被称为 Swish 激活函数，其平滑性带来更好的梯度流

为什么 SwiGLU 更好?
- Gating mechanism: gate 控制哪些信息通过
- 更好的梯度流: SiLU 平滑且无上界
- 实证上优于 ReLU/GeLU: 在各种 benchmark 上表现更好

维度分析:
标准 FFN 通常 intermediate_dim = 4 * hidden_dim
SwiGLU 为匹配参数量，通常 intermediate_dim = 8/3 * hidden_dim
因为 SwiGLU 有 3 个矩阵而非 2 个:
   2 * hidden * 4*hidden = 8 * hidden^2  (标准 FFN)
   3 * hidden * (8/3)*hidden = 8 * hidden^2  (SwiGLU，参数量匹配)
```

```python
class SwiGLUFeedForward(nn.Module):
    def __init__(self, hidden_dim, intermediate_dim):
        super().__init__()
        self.gate_proj = nn.Linear(hidden_dim, intermediate_dim, bias=False)
        self.up_proj = nn.Linear(hidden_dim, intermediate_dim, bias=False)
        self.down_proj = nn.Linear(intermediate_dim, hidden_dim, bias=False)

    def forward(self, x):
        # gate: [batch, seq_len, intermediate_dim]
        gate = torch.nn.functional.silu(self.gate_proj(x))
        # up: [batch, seq_len, intermediate_dim]
        up = self.up_proj(x)
        # element-wise 乘积
        return self.down_proj(gate * up)

# 对比标准 FFN:
class StandardFFN(nn.Module):
    def __init__(self, hidden_dim, intermediate_dim):
        super().__init__()
        self.fc1 = nn.Linear(hidden_dim, intermediate_dim)
        self.fc2 = nn.Linear(intermediate_dim, hidden_dim)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))
```

### 与 AI Infra 的关联

- **FFN 主导参数数量和计算量**：在大型模型中，FFN 的参数远多于 Attention。在推理时 FFN 也是主要的计算瓶颈（尤其是 decode 阶段）。
- **FFN 的 MoE（Mixture of Experts）扩展**：Mixtral、DeepSeek-V2 等模型将 FFN 替换为多个 expert，每次只激活一部分。这是 scaling law 的另一维度。
- **FFN kernel 优化**：SwiGLU 的 gate*up 操作可以融合为单一 CUDA kernel，避免中间结果的显存读写。

---

### 5i. 残差连接与 Pre-LN vs Post-LN

```
残差连接: y = x + F(x)
使网络学习残差而非完整映射，是训练深度网络的关键技术

Post-LN (原始 Transformer):
    x -> Attention -> LayerNorm -> +残差 -> FFN -> LayerNorm -> +残差
    SubLayer(x) = LayerNorm(x + F(x))  -- LN 在残差之后

    x ------> Attention ------> + ------> LN ------> FFN ------> + ------> LN --> out
    |                           ^                         |          ^
    +--- (residual) -----------+                          +----------+

Pre-LN (现代标准, Llama/Mistral/Qwen):
    x -> LayerNorm -> Attention -> +残差 -> LayerNorm -> FFN -> +残差
    SubLayer(x) = x + F(LayerNorm(x))  -- LN 在子层之前

    x ------> LN ------> Attention ------> + ------> LN ------> FFN ------> + --> out
    |                                       ^  |                            ^
    +--- (residual) -----------------------+   +--- (residual) -------------+

为什么 Pre-LN 更好?
- 更稳定的训练: 梯度从输出到输入有直接的残差通路
- 更好的梯度流: 尤其是在深层网络中（100+ 层）
- 无需 warmup: Post-LN 需要学习率 warmup，Pre-LN 通常不需要

最终 LayerNorm (Final LN):
在所有 Transformer Block 之后、LM Head 之前还有一个 RMSNorm/LayerNorm
这确保输出有稳定的统计特性
```

### 与 AI Infra 的关联

- **Norm 位置影响 Kernel Fusion**：Pre-LN 模式下，RMSNorm + Attention QKV 投影可以融合；Post-LN 模式下不这么方便。
- **FlashAttention 与 Norm 融合**：最新的 FlashAttention-3 和 FlashInfer 支持将 RMSNorm 融合到 attention kernel 内部。
- **Pipeline Parallelism 中的 Norm**：Norm 层通常与相邻的 Linear 层放在同一个 GPU 上。

---

### 5j. RMSNorm：公式与为什么比 LayerNorm 快

```
LayerNorm:
    y = (x - mu) / sigma * gamma + beta
    mu = mean(x)           <- 需要一次 reduction
    sigma = sqrt(var(x) + epsilon)  <- 需要另一次 reduction（计算方差需要均值）

RMSNorm:
    y = x / RMS(x) * gamma
    RMS(x) = sqrt(mean(x^2) + epsilon)  <- 只需要一次 reduction!

关键区别: RMSNorm 不需要减去均值（re-centering），省去一次 reduction 操作。
在 GPU 上，reduction 操作是同步点（需要跨线程同步），所以能省就省。
典型加速: 10-15%

实验证明: 减去均值（re-centering）并不是关键操作，去掉对模型质量几乎没有影响。
```

```python
class RMSNorm(nn.Module):
    def __init__(self, hidden_dim, eps=1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(hidden_dim))  # gamma
        # 注意: RMSNorm 没有 beta (bias)，也没有减均值

    def forward(self, x):
        # x: [..., hidden_dim]
        # RMS = sqrt(mean(x^2) + eps)
        rms = torch.sqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + self.eps)
        x_normed = x / rms
        return x_normed * self.weight  # gamma 缩放

# ========== RMSNorm + Residual 融合 ==========
# 这是推理引擎中常见的优化:
def fused_rms_norm_residual(x, residual, weight, eps=1e-6):
    """将 RMSNorm + residual add 融合为一个操作"""
    # input = x + residual
    combined = x + residual
    rms = torch.sqrt(torch.mean(combined ** 2, dim=-1, keepdim=True) + eps)
    return combined / rms * weight
```

### 与 AI Infra 的关联

- **Kernel Fusion**：RMSNorm + Residual Add 可以融合为一个 CUDA kernel，避免两次读写 HBM。FlashInfer 和 vLLM 都利用了这种融合。
- **量化中的 Norm**：在 W8A8 量化中，RMSNorm 的输出需要保持较高精度（FP32/FP16）以保持归一化效果，然后再量化到 int8 送入下一层。
- **LayerNorm vs RMSNorm 的选择**：几乎所有新模型都使用 RMSNorm（Llama, Mistral, Qwen, DeepSeek, Gemma），唯一的例外是需要特殊归一化策略的架构。

---

## 6. Transformer 前向传播内存分析

### 6.1 前向传播中的内存在哪里？

```
前向传播中 GPU 显存的分布 (以 Llama 2 7B, batch=1, seq_len=2048, FP16 为例):

1. 模型权重 (Model Weights):
   7B params * 2 bytes (FP16) = 14 GB
   存放位置: GPU HBM，整个推理过程持续占用

2. KV Cache (仅在推理阶段):
   2 * num_layers * num_kv_heads * head_dim * seq_len * 2 bytes
   = 2 * 32 * 32 * 128 * 2048 * 2 = ~1 GB (per token position)
   累积大小随 seq_len 线性增长!
   对于 32K 上下文: ~16 GB

3. 激活值 (Activations，仅在训练时存储):
   每个 Transformer 层的中间结果:
   - Q, K, V: 3 * [batch, seq_len, hidden_dim]
   - Attention scores: [batch, num_heads, seq_len, seq_len]
   - Attention output: [batch, seq_len, hidden_dim]
   - FFN intermediate: [batch, seq_len, intermediate_dim]
   - Block input: [batch, seq_len, hidden_dim]

   粗略估算 (batch=1, seq_len=2048, hidden_dim=4096):
   每层激活 ~ seq_len * hidden_dim * (3+2+2+1) * 2 bytes
             ~ 2048 * 4096 * 8 * 2 = ~134 MB per layer
   32 层总计: ~4.3 GB
   注意: attention scores = 2048^2 * 32 * 2 = ~268 MB per layer!
   32 层: ~8.6 GB (仅 attention scores)
   总激活: ~15-20 GB

4. 优化器状态 (仅训练时):
   Adam: 2 * model_params = 28 GB (FP32 存储)
   总计训练显存: 14 (权重) + 0 (KV, 不存) + 15 (激活) + 28 (优化器) ≈ 57 GB
   实际上还需要梯度 (14 GB), 所以总共 ~71 GB!
   这就是为什么 7B 模型训练需要至少 8 张 A100 (80GB) 的原因
```

### 6.2 Activation Checkpointing（激活检查点）

```python
# 原理: 不在前向传播中存储所有中间激活，反向传播时重新计算
# 这是训练框架中最重要的内存优化技术之一

from torch.utils.checkpoint import checkpoint

class TransformerBlockWithCheckpoint(nn.Module):
    def __init__(self, hidden_dim, num_heads):
        super().__init__()
        self.attention = MultiHeadAttention(hidden_dim, num_heads)
        self.ffn = SwiGLUFeedForward(hidden_dim, hidden_dim * 8 // 3)
        self.norm1 = RMSNorm(hidden_dim)
        self.norm2 = RMSNorm(hidden_dim)

    def forward(self, x):
        # 使用 checkpoint，中间激活不存储，反向时重算
        x = x + checkpoint(self._attention_forward, x, use_reentrant=False)
        x = x + checkpoint(self._ffn_forward, x, use_reentrant=False)
        return x

    def _attention_forward(self, x):
        return self.attention(self.norm1(x))

    def _ffn_forward(self, x):
        return self.ffn(self.norm2(x))

# 代价: 反向传播时前向重算 -> 额外 33% 计算量
# 收益: 节省 ~70% 激活内存
# 实际训练中必不可少的技巧
```

### 6.3 不同规模模型的显存需求

```
模型规模              参数数      FP16 权重    推理 (seq=2048)    训练 (Adam)
-------------------------------------------------------------------------
Llama 2 7B            7B         14 GB        ~20 GB             ~70 GB
Llama 2 13B           13B        26 GB        ~35 GB             ~120 GB
Llama 2 70B           70B        140 GB       ~180 GB            ~640 GB
Llama 3 8B            8B         16 GB        ~22 GB             ~80 GB
Llama 3 70B           70B        140 GB       ~180 GB            ~640 GB
DeepSeek-V2 (MoE)     236B (21B active)  42 GB   ~50 GB          ~160 GB

注: 以上为单 GPU 粗略估计，实际还依赖 batch_size 和 seq_len。
多 GPU 推理/训练时，每 GPU 的显存可按 GPU 数量近似线性减少。
```

### 与 AI Infra 的关联

- **激活内存决定 batch size 上限**：训练时激活内存是主要约束，activation checkpointing 通过计算换内存来突破这个限制。
- **推理内存由 KV Cache 主导**：这就是为什么 GQA、MQA、MLA、KV cache 量化（KV8/4/2bit）等技术如此重要 -- 每个 bit 的压缩都直接转化为可服务的并发用户数。
- **内存规划是推理引擎的核心工作**：vLLM 的 PagedAttention 本质上是 KV cache 的内存分配器，类似操作系统中的虚拟内存管理。

---

## 7. 从零实现 Mini GPT-2（约 200 行，带详细注释）

以下是一个完整可运行的 Mini GPT-2 实现，包含了所有现代 Transformer 特性：RMSNorm、RoPE、GQA、SwiGLU、Pre-LN 以及 KV cache 推理。

```python
import torch
import torch.nn as nn
import torch.nn.functional as F
import math


# ============================================================
# 1. RMSNorm: 简化版 LayerNorm，不需要减均值
# ============================================================
class RMSNorm(nn.Module):
    """RMSNorm - 现代 Transformer 的标准归一化方式"""
    def __init__(self, dim, eps=1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))  # 可学习的缩放参数 gamma

    def forward(self, x):
        # x: [batch, seq_len, dim]
        # RMS = sqrt(mean(x^2) + eps) -- 只需要一次 reduction
        rms = torch.sqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + self.eps)
        return x / rms * self.weight


# ============================================================
# 2. RotaryEmbedding (RoPE): 旋转位置编码
#    通过对 Q 和 K 施加旋转变换来编码位置信息
#    核心性质: 点积只依赖于相对位置
# ============================================================
class RotaryEmbedding(nn.Module):
    def __init__(self, head_dim, max_seq_len=2048, base=10000.0):
        super().__init__()
        self.head_dim = head_dim
        self.max_seq_len = max_seq_len
        self.base = base
        # 预计算 cos 和 sin 表（注册为 buffer，随模型保存但不训练）
        self.register_buffer('cos_cached', None)
        self.register_buffer('sin_cached', None)
        self._build_cache()

    def _build_cache(self):
        # theta_i = base^(-2i/d), i = 0, 1, ..., d/2 - 1
        theta = 1.0 / (self.base ** (torch.arange(0, self.head_dim, 2).float() / self.head_dim))
        position = torch.arange(self.max_seq_len).float()
        # freq[m, i] = m * theta_i  -> 外积
        freq = torch.outer(position, theta)
        self.cos_cached = freq.cos()  # [max_seq_len, head_dim/2]
        self.sin_cached = freq.sin()

    def forward(self, x, position_ids=None):
        # x: [batch, num_heads, seq_len, head_dim]
        # position_ids: [batch, seq_len] 或 None
        seq_len = x.size(2)
        if position_ids is None:
            cos = self.cos_cached[:seq_len].unsqueeze(0).unsqueeze(0)  # [1, 1, seq_len, head_dim/2]
            sin = self.sin_cached[:seq_len].unsqueeze(0).unsqueeze(0)
        else:
            cos = self.cos_cached[position_ids].unsqueeze(1)  # [batch, 1, seq_len, head_dim/2]
            sin = self.sin_cached[position_ids].unsqueeze(1)

        # 将 head_dim 分成 d/2 对，每对独立旋转
        # [x0, x1, x2, x3, ...] -> [[x0, x1], [x2, x3], ...]
        x_reshaped = x.float().reshape(*x.shape[:-1], -1, 2)
        x1, x2 = x_reshaped[..., 0], x_reshaped[..., 1]  # 每对的第一个和第二个元素

        # 复数旋转: x' = x * e^(i*theta)
        # 实部: x1*cos - x2*sin, 虚部: x1*sin + x2*cos
        x_rotated = torch.stack([
            x1 * cos - x2 * sin,   # 实部
            x1 * sin + x2 * cos    # 虚部
        ], dim=-1).flatten(-2)

        return x_rotated.to(x.dtype)


# ============================================================
# 3. CausalSelfAttention with GQA support
#    支持 Grouped Query Attention (num_kv_heads <= num_heads)
#    支持 KV Cache 用于自回归推理
# ============================================================
class CausalSelfAttention(nn.Module):
    """因果自注意力，支持 GQA 和 KV Cache"""
    def __init__(self, hidden_dim, num_heads, num_kv_heads=None, max_seq_len=2048, dropout=0.0):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads or num_heads  # GQA: num_kv_heads <= num_heads
        self.head_dim = hidden_dim // num_heads
        self.num_queries_per_kv = num_heads // self.num_kv_heads

        # Q 投影: num_heads * head_dim = hidden_dim
        self.q_proj = nn.Linear(hidden_dim, num_heads * self.head_dim, bias=False)
        # K, V 投影: num_kv_heads * head_dim (GQA 时更少)
        self.k_proj = nn.Linear(hidden_dim, self.num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(hidden_dim, self.num_kv_heads * self.head_dim, bias=False)
        # 输出投影: 将多头结果映射回 hidden_dim
        self.out_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.dropout = nn.Dropout(dropout)

        # RoPE: 作用在 Q 和 K 上
        self.rope = RotaryEmbedding(self.head_dim, max_seq_len)

    def forward(self, x, mask=None, kv_cache=None, position_ids=None):
        """
        x: [batch, seq_len, hidden_dim] 当前输入
        mask: 注意力掩码 (causal mask)
        kv_cache: 可选，(K_cache, V_cache) 用于加速自回归生成
        position_ids: 用于 RoPE 的位置 id (在 KV cache 场景下不等于 0..seq_len)
        """
        batch, seq_len, _ = x.shape

        # --- 1. 投影到 Q, K, V ---
        Q = self.q_proj(x).view(batch, seq_len, self.num_heads, self.head_dim)
        K = self.k_proj(x).view(batch, seq_len, self.num_kv_heads, self.head_dim)
        V = self.v_proj(x).view(batch, seq_len, self.num_kv_heads, self.head_dim)

        # --- 2. 应用 RoPE 位置编码到 Q 和 K ---
        # 转置为 [batch, num_heads/num_kv_heads, seq_len, head_dim]
        Q = Q.transpose(1, 2)  # [batch, num_heads, seq_len, head_dim]
        K = K.transpose(1, 2)  # [batch, num_kv_heads, seq_len, head_dim]
        Q = self.rope(Q, position_ids)   # 仅对 Q 和 K 施加 RoPE
        K = self.rope(K, position_ids)   # V 不需要位置信息

        # --- 3. 处理 KV Cache（推理时的优化） ---
        if kv_cache is not None:
            K_cache, V_cache = kv_cache
            K = torch.cat([K_cache, K], dim=2)  # 拼接历史 K 和当前 K
            V = torch.cat([V_cache, V], dim=2)  # 拼接历史 V 和当前 V
        # 返回新的 KV Cache（用于下一个 token）
        new_kv_cache = (K, V)

        # --- 4. GQA: 扩展 KV heads 以匹配 Q heads ---
        if self.num_queries_per_kv > 1:
            K = self._repeat_kv(K, self.num_queries_per_kv)
            V = self._repeat_kv(V, self.num_queries_per_kv)
        # 现在 K, V: [batch, num_heads, total_seq_len, head_dim]

        # --- 5. 缩放点积注意力 ---
        scale = 1.0 / math.sqrt(self.head_dim)
        attn_scores = torch.matmul(Q, K.transpose(-2, -1)) * scale
        # [batch, num_heads, seq_len, total_seq_len]

        if mask is not None:
            attn_scores = attn_scores + mask  # mask 中不可见位置为 -inf

        attn_weights = F.softmax(attn_scores, dim=-1, dtype=torch.float32).to(Q.dtype)
        attn_weights = self.dropout(attn_weights)
        attn_output = torch.matmul(attn_weights, V)  # [batch, num_heads, seq_len, head_dim]

        # --- 6. 合并多头 ---
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(batch, seq_len, self.hidden_dim)
        # [batch, seq_len, hidden_dim]

        return self.out_proj(attn_output), new_kv_cache

    def _repeat_kv(self, kv, n_rep):
        """将 KV heads 重复以匹配 Q heads 的数量 (GQA 的核心操作)"""
        batch, num_kv_heads, seq_len, head_dim = kv.shape
        if n_rep == 1:
            return kv
        # 插入一个维度然后 expand
        kv = kv[:, :, None, :, :]  # [batch, num_kv_heads, 1, seq_len, head_dim]
        kv = kv.expand(batch, num_kv_heads, n_rep, seq_len, head_dim)
        return kv.reshape(batch, num_kv_heads * n_rep, seq_len, head_dim)


# ============================================================
# 4. SwiGLU Feed-Forward Network
#    gate_proj(x) * up_proj(x) -> down_proj()
#    使用 SiLU 激活函数的门控 FFN
# ============================================================
class SwiGLUFeedForward(nn.Module):
    """SwiGLU FFN: y = (W_gate @ x * silu(W_up @ x)) @ W_down"""
    def __init__(self, hidden_dim, intermediate_dim):
        super().__init__()
        self.gate_proj = nn.Linear(hidden_dim, intermediate_dim, bias=False)
        self.up_proj = nn.Linear(hidden_dim, intermediate_dim, bias=False)
        self.down_proj = nn.Linear(intermediate_dim, hidden_dim, bias=False)

    def forward(self, x):
        # gate: 控制哪些信息通过
        gate = F.silu(self.gate_proj(x))  # SiLU = x * sigmoid(x)
        # up: 被门控的信息
        up = self.up_proj(x)
        # element-wise 乘积后降维
        return self.down_proj(gate * up)


# ============================================================
# 5. TransformerBlock (Pre-LN style)
#    x -> RMSNorm -> Attention -> + -> RMSNorm -> FFN -> +
#    Pre-LN: 归一化在子层之前，更稳定的训练
# ============================================================
class TransformerBlock(nn.Module):
    """单个 Transformer Block，Pre-LN 风格"""
    def __init__(self, hidden_dim, num_heads, num_kv_heads=None,
                 intermediate_dim=None, max_seq_len=2048, dropout=0.0):
        super().__init__()
        if intermediate_dim is None:
            # SwiGLU 通常用 8/3 * hidden_dim 来匹配标准 FFN 的参数量
            intermediate_dim = int(8 / 3 * hidden_dim)
            # 确保是 256 的倍数（对 GPU 更友好）
            intermediate_dim = ((intermediate_dim + 255) // 256) * 256

        self.norm1 = RMSNorm(hidden_dim)       # Attention 前的归一化
        self.attn = CausalSelfAttention(
            hidden_dim, num_heads, num_kv_heads, max_seq_len, dropout)
        self.norm2 = RMSNorm(hidden_dim)       # FFN 前的归一化
        self.ffn = SwiGLUFeedForward(hidden_dim, intermediate_dim)

    def forward(self, x, mask=None, kv_cache=None, position_ids=None):
        # Pre-LN: 先归一化，再做 attention，再加残差
        attn_out, new_kv_cache = self.attn(
            self.norm1(x), mask=mask, kv_cache=kv_cache, position_ids=position_ids)
        x = x + attn_out  # 残差连接

        # Pre-LN: 先归一化，再做 FFN，再加残差
        x = x + self.ffn(self.norm2(x))  # 残差连接

        return x, new_kv_cache


# ============================================================
# 6. GPTModel: 完整的 GPT-2 风格模型
#    组装所有组件: Embedding + Transformer Blocks + LM Head
# ============================================================
class MiniGPT2(nn.Module):
    """Mini GPT-2: 完整的自回归语言模型"""
    def __init__(self, vocab_size, hidden_dim, num_layers, num_heads,
                 num_kv_heads=None, max_seq_len=2048, dropout=0.0):
        super().__init__()
        self.vocab_size = vocab_size
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.max_seq_len = max_seq_len

        # Token Embedding: 将 token id 映射到 hidden_dim
        self.token_embedding = nn.Embedding(vocab_size, hidden_dim)

        # Transformer Blocks
        self.layers = nn.ModuleList([
            TransformerBlock(hidden_dim, num_heads, num_kv_heads,
                           max_seq_len=max_seq_len, dropout=dropout)
            for _ in range(num_layers)
        ])

        # 最终 RMSNorm (在 LM Head 之前)
        self.norm = RMSNorm(hidden_dim)

        # LM Head: 将 hidden states 投影回词表大小
        self.lm_head = nn.Linear(hidden_dim, vocab_size, bias=False)

        # Weight Tying: 共享 embedding 和 lm_head 的权重
        # 减少参数，同时有理论依据
        self.lm_head.weight = self.token_embedding.weight

        # 注册 causal mask 为 buffer（不需要训练，不需要梯度）
        causal_mask = torch.triu(
            torch.full((max_seq_len, max_seq_len), float('-inf')), diagonal=1)
        self.register_buffer('causal_mask', causal_mask, persistent=False)

    def forward(self, input_ids, kv_caches=None, position_ids=None):
        """
        input_ids: [batch, seq_len] 输入 token id
        kv_caches: 可选的 KV cache 列表，用于加速推理
        position_ids: [batch, seq_len] 位置 id
        Returns: logits [batch, seq_len, vocab_size]
        """
        batch, seq_len = input_ids.shape

        # 1. Token Embedding
        # shape: [batch, seq_len] -> [batch, seq_len, hidden_dim]
        x = self.token_embedding(input_ids)

        # 2. 构建 causal mask
        # 如果是 KV cache 场景（每次只处理 1 个新 token），mask 只需覆盖当前 token
        if kv_caches is not None and kv_caches[0][0].size(2) > 0:
            # 已有 KV cache: 只处理最新的 token，mask 它可以看到所有历史
            total_len = kv_caches[0][0].size(2) + seq_len  # 历史长度 + 当前
            mask = None  # 因为只需要看过去所有 token
        else:
            # 训练/首次 prefill: 完整的 causal mask
            mask = self.causal_mask[:seq_len, :seq_len]

        # 3. 逐层经过 Transformer Blocks
        new_kv_caches = []
        for i, layer in enumerate(self.layers):
            layer_kv_cache = kv_caches[i] if kv_caches is not None else None
            x, new_kv = layer(x, mask=mask, kv_cache=layer_kv_cache,
                            position_ids=position_ids)
            new_kv_caches.append(new_kv)

        # 4. 最终归一化
        x = self.norm(x)

        # 5. 投影到词表: [batch, seq_len, hidden_dim] -> [batch, seq_len, vocab_size]
        logits = self.lm_head(x)

        return logits, new_kv_caches

    @torch.inference_mode()  # 推理时完全禁用 autograd，节省内存和加速
    def generate(self, input_ids, max_new_tokens, temperature=1.0, top_k=None):
        """
        自回归生成文本，使用 KV cache 加速
        input_ids: [batch, seq_len] 初始 prompt
        max_new_tokens: 最多生成的 token 数
        temperature: 温度参数（越高越随机，越低越确定）
        top_k: 只从概率最高的 k 个 token 中采样
        """
        batch, seq_len = input_ids.shape
        generated = input_ids.clone()  # 生成的完整序列

        # 初始化 KV cache 为 None（第一轮 prefill 不使用 cache）
        kv_caches = None

        for step in range(max_new_tokens):
            if kv_caches is None:
                # Prefill 阶段: 处理整个 prompt，一次性计算所有 KV
                current_input = generated
                position_ids = torch.arange(seq_len, device=input_ids.device)
                position_ids = position_ids.unsqueeze(0).expand(batch, -1)
            else:
                # Decode 阶段: 只处理最新生成的 token
                current_input = generated[:, -1:]  # [batch, 1]
                current_pos = seq_len + step
                position_ids = torch.full((batch, 1), current_pos,
                                         device=input_ids.device, dtype=torch.long)

            # 前向传播
            logits, kv_caches = self.forward(
                current_input, kv_caches=kv_caches, position_ids=position_ids)

            # 取最后一个位置的 logits: [batch, 1, vocab_size] -> [batch, vocab_size]
            next_logits = logits[:, -1, :]

            # 温度缩放
            if temperature > 0:
                next_logits = next_logits / temperature

            # Top-k 过滤
            if top_k is not None:
                top_k_values, _ = torch.topk(next_logits, top_k, dim=-1)
                min_top_k = top_k_values[:, -1].unsqueeze(-1)
                next_logits[next_logits < min_top_k] = float('-inf')

            # 采样下一个 token
            probs = F.softmax(next_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)  # [batch, 1]

            # 拼接到已生成的序列
            generated = torch.cat([generated, next_token], dim=-1)

        return generated


# ============================================================
# 7. 实例化和测试
# ============================================================
if __name__ == '__main__':
    # 配置一个约 124M 参数的小模型（类似 GPT-2 small）
    config = {
        'vocab_size': 50257,      # GPT-2 词表大小
        'hidden_dim': 768,        # 隐藏维度
        'num_layers': 12,         # Transformer 层数
        'num_heads': 12,          # 注意力头数
        'num_kv_heads': 4,        # GQA 的 KV 头数 (12/4 = 3 Q 头共享 1 对 KV)
        'max_seq_len': 1024,      # 最大序列长度
        'dropout': 0.0,           # dropout 率
    }

    model = MiniGPT2(**config)

    # 统计参数量
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'Total params: {total/1e6:.1f}M'
          f', Trainable: {trainable/1e6:.1f}M')

    # 前向传播测试 (训练模式)
    dummy_input = torch.randint(0, config['vocab_size'], (2, 64))  # [batch=2, seq=64]
    logits, _ = model(dummy_input)
    print(f'Input shape: {dummy_input.shape} -> Output shape: {logits.shape}')
    # Expected: Input shape: torch.Size([2, 64]) -> Output shape: torch.Size([2, 64, 50257])

    # 前向传播形状追踪:
    # 1. Input: [2, 64] token ids
    # 2. Embedding: [2, 64, 768]
    # 3. Per Block: Attention QKV each [2, 64, 768] -> after attention same shape
    # 4. FFN: gate,up each [2, 64, 2048] -> down [2, 64, 768]
    # 5. After 12 blocks: [2, 64, 768]
    # 6. Final Norm + LM Head: [2, 64, 50257]

    # 推理测试 (KV cache)
    prompt = torch.randint(0, config['vocab_size'], (1, 10))
    output = model.generate(prompt, max_new_tokens=20, temperature=0.8, top_k=50)
    print(f'Prompt shape: {prompt.shape} -> Generated shape: {output.shape}')
    # Expected: Prompt shape: torch.Size([1, 10]) -> Generated shape: torch.Size([1, 30])
```

### 代码说明

上述实现涵盖了现代 LLM 的所有核心组件：

1. **RMSNorm**：简化版归一化，比 LayerNorm 快 10-15%
2. **RoPE**：旋转位置编码，预计算 cos/sin 缓存，支持任意长度外推
3. **GQA**：通过 `repeat_kv` 实现分组查询注意力，KV cache 减少 3x
4. **SwiGLU**：门控 FFN，使用 SiLU 激活函数
5. **Pre-LN**：LayerNorm 在子层之前，梯度更稳定
6. **KV Cache**：推理时缓存历史 K, V，避免重复计算
7. **generate()**：自回归生成，支持 prefill/decode 两阶段、temperature 和 top-k 采样
8. **Weight Tying**：共享 Embedding 和 LM Head 权重，减少参数量

### 与 AI Infra 的关联

- **上述实现是理解推理引擎优化起点的关键**。vLLM 的 PagedAttention 本质上是对 KV cache 的内存管理优化，而 FlashAttention 是对 attention 计算本身的 kernel 级优化。
- **训练时需要在每个 TransformerBlock 外围加上梯度检查点和混合精度**。DeepSpeed 和 Megatron-LM 的代码就是从这类实现扩展到分布式环境。
- **KV cache 的 `cat` 操作（内存拷贝）是推理的主要开销之一**。这就是为什么 vLLM 使用 PagedAttention（整页复用，避免频繁拷贝）。

---

## 8. 模型加载：Safetensors、分片与延迟加载

### 8.1 safetensors vs pickle (.pt)

```
传统 PyTorch 保存格式 (pickle):
  torch.save(model.state_dict(), 'model.pt')
  问题:
  - 安全性: pickle 可以执行任意代码（反序列化攻击）
  - 不支持零拷贝: 必须完整加载到内存
  - 不支持延迟加载: 必须加载整个文件

Safetensors 格式:
  from safetensors.torch import save_file, load_file
  save_file(model.state_dict(), 'model.safetensors')
  优势:
  - 安全: 纯数据格式，不允许代码执行
  - 零拷贝: 支持 memory-mapped I/O (mmap)
  - 延迟加载: 可以只加载需要的 tensor
  - 跨框架: TensorFlow, JAX 也可以读取
  - 更快的加载速度（尤其是大模型）
```

```python
import torch
from safetensors.torch import save_file, load_file

# 保存
state_dict = model.state_dict()
save_file(state_dict, 'model.safetensors')

# 普通加载
state_dict = load_file('model.safetensors')
model.load_state_dict(state_dict)

# 零拷贝加载 (mmap)
from safetensors import safe_open
with safe_open('model.safetensors', framework='pt', device='cuda:0') as f:
    # 只加载需要的 tensor，不需要完整读取文件
    weight = f.get_tensor('model.layers.0.attn.q_proj.weight')
```

### 8.2 分片模型（Sharded Models）

```
大模型通常被切分成多个文件（shards）存储:

pytorch_model-00001-of-00005.bin  (第 1 个分片)
pytorch_model-00002-of-00005.bin  (第 2 个分片)
pytorch_model-00003-of-00005.bin
pytorch_model-00004-of-00005.bin
pytorch_model-00005-of-00005.bin
pytorch_model.bin.index.json      (索引文件)
config.json                        (模型配置)

index.json 的结构:
{
  'metadata': {'total_size': 14000000000},
  'weight_map': {
    'model.layers.0.attn.q_proj.weight': 'pytorch_model-00001-of-00005.bin',
    'model.layers.0.attn.k_proj.weight': 'pytorch_model-00001-of-00005.bin',
    'model.layers.20.attn.q_proj.weight': 'pytorch_model-00003-of-00005.bin',
    # ... 每个参数名映射到它所在的 shard 文件
  }
}

分片策略:
- 按层分片: layer 0-5 在 shard 1, layer 6-11 在 shard 2, ...
- 按大小分片: 每个 shard 约 10GB，不割裂参数矩阵
```

### 8.3 Lazy Loading 与 device_map

```python
# accelerate 库的自动设备放置
from accelerate import init_empty_weights, load_checkpoint_and_dispatch

# 1. 先创建空壳模型（不分配实际内存）
with init_empty_weights():
    model = MiniGPT2(vocab_size=50257, hidden_dim=768, num_layers=12, num_heads=12)

# 2. 自动将权重分配到可用 GPU 上
model = load_checkpoint_and_dispatch(
    model,
    checkpoint='path/to/model',
    device_map='auto',           # 自动决定每个层放在哪个 GPU
    no_split_module_classes=['TransformerBlock'],  # 不割裂这些模块
    dtype=torch.float16
)

# device_map='auto' 的工作原理:
# 1. 计算每层的参数量和显存需求
# 2. 将层依次放到 GPU 上，直到显存不够
# 3. 溢出部分放到 CPU 上（或使用 offload）
# 4. 跨 GPU 的 tensor 会自动通过 all-gather 等方式通信

# 设备放置示例 (2x A100 80GB, Llama 2 70B):
# GPU 0: layers 0-39  (前 40 层)
# GPU 1: layers 40-79 (后 40 层)
# lm_head + embedding 可以根据需要放置
```

### 与 AI Infra 的关联

- **推理服务器必须高效加载和分发模型权重**：vLLM 使用 safetensors + mmap 实现零拷贝加载，配合自定义的内存分配器管理 KV cache。
- **检查点格式影响恢复速度**：大规模训练中，checkpoint 的保存和加载时间直接影响故障恢复速度。Megatron-LM 使用分片检查点 + 异步保存。
- **Weight streaming**：llama.cpp 支持直接从磁盘流式加载模型（mmap），适合在资源受限设备上运行大模型。

---

## 9. HuggingFace Transformers 库内部机制

### 9.1 AutoModel.from_pretrained() 的完整流程

```
AutoModel.from_pretrained('meta-llama/Llama-2-7b-hf') 的完整流程:

Step 1: 下载
  检查 ~/.cache/huggingface/hub/ 中是否有缓存
  如果没有，从 HuggingFace Hub 下载: config.json, tokenizer, 模型文件
  缓存在: ~/.cache/huggingface/hub/models--meta-llama--Llama-2-7b-hf/

Step 2: 读取 config.json
  {
    'architectures': ['LlamaForCausalLM'],
    'hidden_size': 4096,
    'num_hidden_layers': 32,
    'num_attention_heads': 32,
    'num_key_value_heads': 32,  # Llama 2 7B 没有 GQA
    'intermediate_size': 11008,
    'max_position_embeddings': 4096,
    'rms_norm_eps': 1e-6,
    'vocab_size': 32000,
    ...
  }
  根据 architectures 字段动态导入对应的模型类: LlamaForCausalLM

Step 3: 初始化模型
  model = LlamaForCausalLM(config)
  此时模型参数是随机初始化的（CPU 上）

Step 4: 加载权重
  读取 index.json 获取参数 -> 文件的映射
  逐个 shard 文件加载权重
  调用 model.load_state_dict(state_dict, strict=True)
  检查是否有缺失/多余的 key

Step 5: 后处理
  model.eval()  (默认推理模式)
  如果指定了 device_map，自动分发到 GPU
```

### 9.2 generate()：自回归生成管道

```
model.generate() 的内部流程:

Phase 1: Prefill (预填充)
  输入: prompt tokens [1, prompt_len]
  处理: 一次性通过模型，计算所有位置的 hidden states
  产出: first token + 所有层的 KV cache
  时间: 与 prompt_len^2 成正比 (attention 的 O(n^2))

Phase 2: Decode (逐 token 解码) -- 循环
  for step in range(max_new_tokens):
    输入: 上一次生成的 token [1, 1]
    处理: 通过模型 + 与已有 KV cache 拼接
    产出: next token + 更新 KV cache
    时间: 每步与 seq_len 成正比 (attention kv lookup)

Procedures run inside generate():
  1. LogitsProcessor: 对 logits 进行变换 (如 repetition penalty)
  2. LogitsWarper: 温度缩放、top-k、top-p
  3. Sampler: 从处理后的 logits 中采样 (multinomial, greedy, beam search)
  4. StoppingCriteria: 检查是否应该停止 (EOS token, max length)

关键参数:
  max_new_tokens: 最多生成 token 数
  temperature: 温度参数 (1.0=normal, <1.0=确定, >1.0=随机)
  top_k: 只从概率最高的 k 个 token 中采样
  top_p: nucleus sampling, 累积概率超过 p 后截断
  repetition_penalty: 惩罚重复 token
  do_sample: True=采样, False=greedy
  num_beams: beam search 的束宽
```

### 9.3 缓存系统

```
HuggingFace Hub 缓存结构:
~/.cache/huggingface/hub/
  models--meta-llama--Llama-2-7b-hf/
    blobs/
      <sha256_hash_1>  # config.json 的内容
      <sha256_hash_2>  # pytorch_model-00001-of-00002.bin
      ...
    refs/
      main  # 指向当前版本的引用
    snapshots/
      <commit_hash>/
        config.json -> ../../blobs/<sha256_hash_1>
        pytorch_model-00001-of-00002.bin -> ...  (符号链接)

# 环境变量:
# HF_HOME: 缓存根目录 (默认 ~/.cache/huggingface)
# HF_HUB_CACHE: 模型缓存位置
# HF_ENDPOINT: 自定义 Hub 地址 (镜像站)
```

### 与 AI Infra 的关联

- **理解 HF generate() 是优化它的前提**：vLLM 替换了整个 generate 流程，使用 continuous batching + PagedAttention，但接口（输入/输出语义）保持不变。
- **LogitsProcessor 在推理服务中的应用**：vLLM 继承了 HF 的 logits processor 和 sampling 接口，用户可以自定义采样策略。
- **HF 的模型加载是推理引擎的起点**：无论是 vLLM 还是 TGI，都使用 HF 的 config + safetensors 作为标准模型格式。

---

## 11. 易混淆技术辨析

本节对比三组最容易被面试官和同行追问的概念，帮助你在技术讨论中精准表达。

### 11.1 GQA vs MQA vs MLA

这三者本质上是 **KV Cache 压缩程度的递进**——从无压缩到极致压缩再到有损压缩+恢复。

```
KV Cache 压缩率递进:

  MHA ──────────► GQA ──────────► MQA ──────────► MLA
  (无压缩)         (分组共享)       (全共享)        (低秩压缩)
  KV Cache: 1x    0.125~0.5x      1/num_heads     ~1/50x

  示例 (num_heads=64, head_dim=128):
  ┌──────────┬─────────────────┬──────────────────────┬───────────┐
  │          │ MHA             │ GQA (8 KV heads)     │ MLA       │
  ├──────────┼─────────────────┼──────────────────────┼───────────┤
  │ 每 token │ 64×128×2        │ 8×128×2              │ 576 dims  │
  │ KV 大小  │ = 16384 dims    │ = 2048 dims          │ (压缩后)  │
  │ 压缩比   │ 1x (基线)       │ 8x                   │ ~28x      │
  │ 质量损失 │ 无              │ 几乎无                │ 几乎无    │
  │ 推理实现 │ 最简单           │ repeat_kv 操作        │ 需要解压  │
  │ 代表模型 │ GPT-3, 原始     │ Llama 2/3, Mistral,  │ DeepSeek  │
  │          │ Transformer     │ Qwen 2, Gemma 2      │ V2/V3     │
  └──────────┴─────────────────┴──────────────────────┴───────────┘
```

**决策表：**

| 场景 | 推荐 | 原因 |
|------|------|------|
| 长上下文推理 (32K+) | MLA > GQA > MQA | MLA 的 KV Cache 最小，支持更多并发 |
| 训练新模型 | GQA (num_kv_heads=8) | 工程实现成熟，收敛稳定 |
| 极致低成本推理 | MQA 或 MLA | 单 KV head 或低秩压缩，显存最小 |
| 从 MHA checkpoint 微调 | GQA | mean-pool 原始 KV heads 初始化，微调即可 |
| FlashAttention 兼容 | GQA | FA2/3 原生支持，MLA 需要自定义 kernel |

### 11.2 RoPE vs ALiBi

RoPE 和 ALiBi 是实现长度外推的两种不同路线：RoPE 在 attention 内部注入位置信息，ALiBi 在 attention score 上直接加偏置。

```
RoPE:
  原理: 对 Q 和 K 施加与位置相关的旋转变换
  公式: q_m = R(mθ) × q,  k_n = R(nθ) × k
         q_m · k_n = q^T · R((n-m)θ) · k  (仅依赖相对位置!)
  优势: 可以微调扩展 (YaRN, NTK-aware scaling)
  代表: Llama, Mistral, Qwen, DeepSeek

ALiBi:
  原理: 直接在 attention score 上减去一个与距离成正比的偏置
  公式: score[i,j] = score[i,j] - m × |i - j|
        m 是 head-specific slope (如 2^{-8/n})
  优势: 零额外参数，天然外推
  代表: BLOOM, MPT, Falcon (早期版本)
```

| 维度 | RoPE | ALiBi |
|------|------|-------|
| 位置信息注入方式 | 旋转 Q、K 向量 | 加偏置到 attention score |
| 额外参数量 | 无（预计算 cos/sin 表） | 无（固定 slope） |
| 长序列外推能力 | 需要微调或插值 | 天然外推（但有衰减上限） |
| 对 attention kernel 的影响 | 需要融合 RoPE 计算，FA2/3 已支持 | 对 kernel 几乎无影响 |
| 社区采用率 | **绝对主流** | 少数模型，逐渐被淘汰 |
| 长度外推上限 | 配合 YaRN 可达 128K+ | 通常 4-8K 后质量下降明显 |

### 11.3 SwiGLU vs Standard FFN

两者都属于 Transformer 的 Feed-Forward Network，但 SwiGLU 引入门控机制。

```
Standard FFN:   out = W2 @ ReLU(W1 @ x + b1) + b2
SwiGLU FFN:     out = (Wg @ x ⊙ SiLU(W_up @ x)) @ W_down

关键区别: SwiGLU 有一个 "gate" 路径和 "up" 路径的逐元素乘积。
SiLU(x) = x × σ(x) —— 平滑且无上界的激活函数。
```

| 维度 | Standard FFN | SwiGLU |
|------|-------------|--------|
| 激活函数 | ReLU 或 GeLU | SiLU (Sigmoid Linear Unit) |
| 权重矩阵数量 | 2 个 (W1, W2) | 3 个 (W_gate, W_up, W_down) |
| 中间维度 (等参数) | 4d | 8d/3 (约 2.67d) |
| 门控机制 | 无 | gate ⊙ up (逐元素门控) |
| 梯度流 | ReLU 在负半区梯度为零 | SiLU 处处可导，梯度更平滑 |
| 实证效果 | 基准线 | 在几乎所有 benchmark 上更优 |
| 推理 compute | 略少 | 多一个逐元素乘积（可忽略） |
| 主流模型 | BERT, GPT-2 | Llama, Mistral, Qwen, DeepSeek |

---

## 12. AI Infra 专家视角

### 12.1 性能瓶颈排查流程

当你的推理服务吞吐不达标或延迟抖动时，按以下决策树排查：

```
                          ┌─────────────────────┐
                          │ 性能问题: 延迟/吞吐  │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │ 先判断瓶颈侧:        │
                          │ nvidia-smi dmon -s u │
                          └──────────┬──────────┘
                                     │
                      ┌──────────────┼──────────────┐
                      ▼                             ▼
             GPU 利用率 < 50%               GPU 利用率 > 80%
             (CPU 侧瓶颈)                   (GPU 侧瓶颈)
                      │                             │
         ┌────────────▼────────────┐    ┌───────────▼───────────┐
         │ 检查 1: 请求是否塞满?    │    │ 检查 1: 是 prefill 还  │
         │ curl API 并发是否足够    │    │ 是 decode 瓶颈?        │
         │ - 增大 --max-num-seqs   │    │ nsys profile 看时间线  │
         │ - 增大并发客户端数       │    └───────────┬───────────┘
         └────────────┬────────────┘                │
                      │                   ┌─────────┼─────────┐
         ┌────────────▼────────────┐      ▼                   ▼
         │ 检查 2: tokenizer 瓶颈? │  Prefill 慢        Decode 慢
         │ py-spy top -p PID       │  (compute-bound)   (memory-bound)
         │ 看 tokenizer 耗时占比    │      │                   │
         └────────────┬────────────┘      ▼                   ▼
                      │          ┌──────────────┐  ┌──────────────────┐
         ┌────────────▼─────────┐ │ 调大 chunked  │  │ 1. 确认 CUDA     │
         │ 检查 3: 调度器开销?   │ │ prefill 块大小│  │    Graphs 开启   │
         │ 看 waiting 队列长度   │ │ --max-num-    │  │    (默认开启)    │
         │ 看 preemption 频率    │ │ batched-tokens│  │ 2. 换 FlashInfer  │
         │ → 增大 block_size    │ │ = 2048/4096   │  │    后端 (更快)   │
         │ → 调 gpu-mem-util    │ └──────────────┘  │ 3. ncu 查 kernel  │
         └──────────────────────┘                    │    看 L2 命中率   │
                                                    │ 4. 增大 batch_size│
                                                    │    (提升带宽利用) │
                                                    └──────────────────┘
```

具体命令速查：
```bash
# GPU 状态概览
nvidia-smi dmon -s pucvmet -d 1

# CPU 侧热点分析
py-spy top --pid $(pgrep -f vllm) -r 100

# Kernel 级性能分析
ncu --set basic --kernel-name regex:attention -o profile python bench.py

# 查看显存分布
nvidia-smi --query-gpu=memory.used,memory.total --format=csv
```

### 12.2 A800 部署实操：Qwen-33B on 2xA800

以下是在 2 张 A800 (80GB) 上部署 Qwen-33B 的完整实战，展示本文所有概念如何落地。

**环境：**
- 硬件：2x NVIDIA A800 80GB，NVLink 600 GB/s 互联
- 模型：Qwen-33B (实际 33B 参数, 64 layers, num_heads=64, num_kv_heads=8, head_dim=128, hidden_dim=6656, intermediate_dim=17728)
- 框架：vLLM v0.6.3+

**显存计算（单卡 FP16）：**
```
模型权重: 33B × 2 bytes (FP16) = 66 GB
经过 TP=2 切分:
  每卡权重: 66 / 2 = 33 GB  (列切分 + 行切分, 近似均分)
KV Cache (每卡, seq_len=4096, block_size=16):
  每 token KV: 2 × num_kv_heads × head_dim × num_layers × 2 bytes
              = 2 × 8 × 128 × 64 × 2 = 262,144 bytes ≈ 256 KB
  800 tokens 的 KV Cache ≈ 800 × 256 KB ≈ 200 MB per token? 

  准确计算 (per sequence per GPU, TP=2):
    KV = 2 × num_kv_heads × head_dim × num_layers × dtype
       = 2 × 8 × 128 × 64 × 2 bytes = 262,144 bytes/token
    一个 4096 token 的序列: 4096 × 256 KB ≈ 1.0 GB
  按 gpu_memory_utilization=0.85:
    可用显存: 80 × 0.85 = 68 GB
    剩余给 KV Cache: 68 - 33 = 35 GB
    可支持序列数: 35 / 1.0 ≈ 35 个并发序列
```

**启动命令：**
```bash
vllm serve Qwen/Qwen-33B \
  --host 0.0.0.0 --port 8000 \
  --tensor-parallel-size 2 \
  --dtype float16 \
  --max-model-len 4096 \
  --gpu-memory-utilization 0.85 \
  --max-num-seqs 32 \
  --max-num-batched-tokens 4096 \
  --enable-prefix-caching \
  --enable-chunked-prefill \
  --block-size 16 \
  --swap-space 8
```

**关键参数解读：**

| 参数 | 值 | 依据 |
|------|-----|------|
| `--tensor-parallel-size 2` | TP=2 | Qwen-33B FP16 权重 66GB，单卡放不下。2xA800 通过 NVLink 600GB/s 互联，TP=2 通信开销可接受 |
| `--max-model-len 4096` | 4K | 平衡 KV Cache 占用和业务需求。若要 8K 上下文则需降低 `--max-num-seqs` 或 `--gpu-memory-utilization` |
| `--gpu-memory-utilization 0.85` | 85% | 给 CUDA context 和其他临时分配留 15% 余量 |
| `--max-num-seqs 32` | 32 | 见上文显存计算，35 GB KV Cache 最多撑约 35 个序列 |
| `--max-num-batched-tokens 4096` | 4096 | 平衡 prefill 延迟（一次性处理 token 越多，单步越慢但总吞吐高） |
| `--enable-prefix-caching` | 开启 | 多轮对话场景命中率 >50%，大幅降低 TTFT |
| `--block-size 16` | 16 | 默认值，平衡碎片率和查表开销。长上下文可调大到 32 |

**预期性能：**
```
Prefill (prompt=512 tokens):
  - TTFT (Time To First Token): ~200-300ms
  - 瓶颈: compute-bound, GPU SM 利用率 >80%

Decode (per token):
  - ITL (Inter-Token Latency): ~15-25ms @ batch=1
  - ITL @ batch=32: ~30-45ms per token, 但并发处理 32 个序列
  - 瓶颈: memory-bound, HBM 带宽利用率 ~70-85%
  - Key insight: decode 阶段 GPU SM 利用率通常只有 5-20%

总吞吐 (online serving, mixed lengths):
  - ~1500-2500 tokens/s (取决于 prompt/response 长度分布)
  - 对比 HF Transformers: ~80-120 tokens/s → 提升 15-25x

TP=2 vs TP=1 (若能放下):
  - TP 通信开销约占 decode 延迟的 10-15%
  - NVLink 600 GB/s 下每层 2 次 All-Reduce 耗时约 50-100μs
  - 32 层共 64 次 All-Reduce: ~3-6ms overhead per step
```

---

## 13. 深入学习资源

### 论文（必读）

| 论文 | 核心贡献 | 发布时间 |
|------|---------|---------|
| [Attention Is All You Need](https://arxiv.org/abs/1706.03762) | 原始 Transformer 架构 | 2017 |
| [RoFormer: RoPE](https://arxiv.org/abs/2104.09864) | 旋转位置编码 | 2021 |
| [GQA: Training Generalized Multi-Query Transformers](https://arxiv.org/abs/2305.13245) | 分组查询注意力 | 2023 |
| [FlashAttention](https://arxiv.org/abs/2205.14135) | IO-aware attention kernel | 2022 |
| [FlashAttention-2](https://arxiv.org/abs/2307.08691) | 更好的并行策略 | 2023 |
| [Llama 2](https://arxiv.org/abs/2307.09288) | GQA, SwiGLU, RMSNorm, Pre-LN | 2023 |
| [DeepSeek-V2 (MLA)](https://arxiv.org/abs/2405.04434) | Multi-head Latent Attention | 2024 |
| [vLLM (PagedAttention)](https://arxiv.org/abs/2309.06180) | KV cache 内存管理 | 2023 |
| [YaRN: Efficient Context Window Extension](https://arxiv.org/abs/2309.00071) | RoPE 长度外推 | 2023 |
| [Mixtral of Experts](https://arxiv.org/abs/2401.04088) | MoE + GQA 在 8x7B 模型中的应用 | 2024 |

### 代码仓库（必看）

| 仓库 | 核心价值 | 难度 |
|------|---------|------|
| [nanoGPT](https://github.com/karpathy/nanoGPT) | 最简洁的 GPT-2 实现 | 入门 |
| [lit-gpt](https://github.com/Lightning-AI/litgpt) | 多模型支持的清晰实现 | 入门-中级 |
| [vLLM](https://github.com/vllm-project/vllm) | 生产级推理引擎，PagedAttention | 高级 |
| [FlashAttention](https://github.com/Dao-AILab/flash-attention) | GPU kernel 级优化 | 高级 |
| [Megatron-LM](https://github.com/NVIDIA/Megatron-LM) | 分布式训练框架 | 高级 |
| [DeepSpeed](https://github.com/microsoft/DeepSpeed) | ZeRO 优化 + 推理 | 高级 |
| [llama.cpp](https://github.com/ggerganov/llama.cpp) | CPU/GPU 混合推理 | 中级 |
| [DeepSeek-V3](https://github.com/deepseek-ai/DeepSeek-V3) | MLA 完整实现 | 高级 |

### 学习路径建议

```
AI Infra 学习路径:

Phase 1: 基础 (本文覆盖)
  |- PyTorch tensors & autograd
  |- nn.Module & DataLoader
  |- Transformer 架构 (MHA/GQA/MQA/MLA, RoPE, SwiGLU, RMSNorm)
  |- 从零实现 Mini GPT-2

Phase 2: 推理优化 (Inference Engine 方向)
  |- FlashAttention 论文精读 + 源码分析
  |- vLLM 源码通读 (PagedAttention, Scheduler, Worker)
  |- KV cache 量化和压缩技术
  |- Continuous batching 和调度算法
  |- Speculative decoding

Phase 3: 训练优化 (Training Framework 方向)
  |- Megatron-LM 源码分析 (TP, PP, DP 组合)
  |- DeepSpeed ZeRO 系列算法
  |- Gradient checkpointing 与 activation offloading
  |- 混合精度训练 (AMP) 和 loss scaling
  |- FlashAttention 在训练中的应用

Phase 4: 模型压缩 (Model Compression 方向)
  |- GPTQ, AWQ (权重量化)
  |- SmoothQuant (激活量化)
  |- KV Cache 量化 (KIVI, KVQuant)
  |- 剪枝和蒸馏技术
  |- LoRA/QLoRA (参数高效微调)

Phase 5: 分布式系统 (Distributed Systems 方向)
  |- NCCL 通信原语 (all-reduce, all-gather, reduce-scatter)
  |- Pipeline parallelism 的调度策略 (1F1B, interleaved)
  |- Expert parallelism 和 MoE 路由
  |- 故障恢复和弹性训练
  |- 多节点推理部署 (Ray, K8s)
```

---

> **本文档是 AI Infra 方向的学习基石。** 
> 建议配合 nanoGPT 源码逐行阅读，并在 GPU 上实际运行和修改代码。
> 下一步：选择你感兴趣的 AI Infra 方向，深度学习 Phase 2-5 中的内容。



## Part 1: PyTorch 深度剖析

---

## 1. Tensor 内部机制：Storage、Stride、Contiguous

### 1.1 三个核心概念

PyTorch Tensor 看似简单，实则由三层抽象构成：

```
┌──────────────────────────────────────────────────────────────────┐
│                      torch.Tensor                                │
│  ┌────────────────────┐  ┌──────────────┐  ┌──────────────────┐ │
│  │    Storage          │  │   Stride     │  │   Metadata       │ │
│  │  (一维连续内存块)    │  │  (跨步信息)   │  │  shape, dtype,   │ │
│  │                     │  │              │  │  device, layout  │ │
│  │  物理存储，          │  │  逻辑索引到   │  │                  │ │
│  │  多个 Tensor 可以    │  │  物理偏移的   │  │  requires_grad,  │ │
│  │  共享同一个 Storage   │  │  映射规则    │  │  grad, ...       │ │
│  └────────────────────┘  └──────────────┘  └──────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

**为什么理解这个很重要？** 在 GPU 推理优化中，contiguous vs non-contiguous 直接影响 CUDA kernel 能否高效执行。Stride 决定了内存访问模式，从而决定了是否有合并访问 (coalesced access)。

### 1.2 Storage：数据的物理存放

```python
import torch

# 创建一个 3x4 的 float32 Tensor
x = torch.randn(3, 4)

# 访问底层 Storage
print(x.storage())  # 输出一维内存视图
#  0.1234
# -0.5678
#  0.9012
# ... (共 12 个元素)

print(x.storage_offset())  # 0 — 这个 Tensor 从 storage 的第几个元素开始
print(x.stride())           # (4, 1) — 沿每个维度移动一个"格子"需要跨越的 storage 元素数

# Storage 大小：所有 Tensor 元素的总和（含 padding 情况较少）
print(x.storage().size())   # 12
```

**核心关系**：访问元素 `x[i, j]` 时，PyTorch 计算：
```
storage_index = storage_offset + i * stride[0] + j * stride[1]
             = 0 + i * 4 + j * 1
             = i * 4 + j
```

### 1.3 Stride：逻辑到物理的映射

Stride 是多维索引到一维偏移的转换系数。对于形状为 `(d0, d1, d2)` 的 Tensor：
```
offset = storage_offset + i * stride[0] + j * stride[1] + k * stride[2]
```

```
以 3×4 Tensor 为例 (stride = (4, 1)):

  Memory layout (row-major / C-contiguous):
  索引:  0   1   2   3   4   5   6   7   8   9   10  11
  数据: [0,0][0,1][0,2][0,3][1,0][1,1][1,2][1,3][2,0][2,1][2,2][2,3]

  x[1, 2] = storage[1*4 + 2*1] = storage[6] = [1,2] ✓
```

```python
# 创建一个 3D Tensor 并观察 stride
x = torch.randn(2, 3, 4)
print(f"shape:  {x.shape}")   # torch.Size([2, 3, 4])
print(f"stride: {x.stride()}") # (12, 4, 1)

# 解释：
# - dim=0 走一步跨 12 个元素（跨过一个完整的 3×4 平面）
# - dim=1 走一步跨 4 个元素  （跨过一行）
# - dim=2 走一步跨 1 个元素  （跨过一个标量）
```

### 1.4 Contiguous vs Non-Contiguous

Contiguous Tensor 的定义：`stride[i] >= stride[i+1] * shape[i+1]`（对于所有 i），且 `stride[-1] == 1`。

简单来说，就是数据在内存中按 C 语言的 row-major 顺序连续存放。

```python
x = torch.randn(3, 4)
print(x.is_contiguous())  # True
print(x.stride())         # (4, 1)

# Transpose 产生 non-contiguous view
y = x.T  # 或 x.transpose(0, 1) — 注意这不是深拷贝！
print(y.shape)            # torch.Size([4, 3])
print(y.stride())         # (1, 4) — stride 颠倒了！
print(y.is_contiguous())  # False

# 内存布局没有变！只是 stride 改变了
print(x.storage().data_ptr() == y.storage().data_ptr())  # True — 同一个 storage
```

**可视化 Non-Contiguous 访问模式**：

```
x (3×4, stride=(4,1)):               y = x.T (4×3, stride=(1,4)):
┌──────────────────────┐              ┌──────────────────────┐
│ [0] [1] [2] [3]      │              │ [0] [4] [8]          │
│  ↓   ↓   ↓   ↓       │              │  ↓   ↓   ↓           │
│ [4] [5] [6] [7]      │              │ [1] [5] [9]          │
│  ↓   ↓   ↓   ↓       │              │  ↓   ↓   ↓           │
│ [8] [9] [10][11]     │              │ [2] [6] [10]         │
└──────────────────────┘              │  ↓   ↓   ↓           │
  连续访问：[0][1][2][3]...            │ [3] [7] [11]         │
  每次 +1 步                          └──────────────────────┘
                                        访问 [0][4][8]...
                                        每次 +4 步（跳跃！）
```

### 1.5 为什么 Contiguous 对 GPU 至关重要

GPU 的显存带宽虽然很高（HBM2e ~2 TB/s），但需要合并访问才能充分利用。

```
GPU 合并访问 (Coalesced Access) 的原理：

┌─────────────────────────────────────────────────────────────────┐
│            Warp 中 32 个线程同时访问显存                          │
│                                                                 │
│  合并访问（高效）：                                              │
│  Thread 0 → addr 0x1000                                         │
│  Thread 1 → addr 0x1004  ← 地址连续，一次 128B 事务完成          │
│  Thread 2 → addr 0x1008                                          │
│  ...                                                             │
│  Thread 31→ addr 0x107C                                          │
│  → 1 次显存事务，带宽利用率 ~100%                                 │
│                                                                 │
│  非合并访问（低效）：                                            │
│  Thread 0 → addr 0x1000                                          │
│  Thread 1 → addr 0x1400  ← 地址跳跃，需要 32 次独立的显存事务     │
│  Thread 2 → addr 0x1800                                          │
│  ...                                                             │
│  → 最多 32 次显存事务，带宽利用率 ~3%                            │
└─────────────────────────────────────────────────────────────────┘
```

**在 PyTorch 中的实际影响**：

```python
import time

x = torch.randn(1024, 1024, device='cuda')
y = x.T  # non-contiguous

# contiguous 操作更快
z = x.contiguous()  # 创建一个新的 contiguous copy

# 对于需要 contiguous 输入的操作（如 view），
# non-contiguous 的 tensor 会先触发一次隐式拷贝
try:
    y.view(-1)  # RuntimeError! view 要求 contiguous
except RuntimeError as e:
    print(f"Error: {e}")

# 解决方案
y_contig = y.contiguous()  # 显式拷贝
y_contig.view(-1)          # OK
```

### 1.6 Tensor 操作：View vs Copy

```python
# ===== VIEW：共享 storage，仅改变 metadata =====
x = torch.randn(3, 4)
v1 = x.view(4, 3)        # succeed (x 是 contiguous 的)
v2 = x.reshape(4, 3)     # 可能返回 view 也可能返回 copy（更安全但不可预测）
v3 = x.T                 # view
v4 = x[None, :, :]       # view (unsqueeze)
v5 = x.expand(2, 3, 4)   # view (stride 中可以有 0)

# ===== COPY：创建新的 storage =====
c1 = x.contiguous()      # 只有在 non-contiguous 时才 copy
c2 = x.clone()           # 总是 deep copy
c3 = x[0, :]             # 基本索引 → view
c4 = x[[0, 1], :]        # 高级索引 → copy

# 判断是否共享 storage
def shares_storage(a, b):
    return a.storage().data_ptr() == b.storage().data_ptr()

print(shares_storage(x, v1))  # True
print(shares_storage(x, c2))  # False
```

### 1.7 实践要点

| 场景 | 需要 contiguous？ | 原因 |
|------|------------------|------|
| `view()` / `reshape()` | 是 | view 要求连续内存布局 |
| `torch.matmul()` / `@` | 否 | cuBLAS 内部处理 stride |
| `F.linear()` | 否 | 内部调用 matmul |
| 自定义 CUDA kernel | 通常需要 | 大多数 kernel 假设连续输入 |
| CPU→GPU 拷贝 (pin_memory) | 自动处理 | pin_memory 使用 DMA |
| `nn.Parameter` | 建议 | 初始化后保持 contiguous 以提高训练效率 |

**核心要点**：
- Tensor = Storage（数据） + Stride（映射） + Metadata（元信息）
- Stride 是核心：同样的 Storage，不同 Stride 产生不同"视图"
- Transpose 是 view 操作，不拷贝数据，但改变 stride
- 自定义 CUDA kernel 或调用 `view()` 前确保 contiguous
- `reshape()` 比 `view()` 更安全但更不可预测性能

---

## 2. 广播机制全解

### 2.1 广播规则

PyTorch 的 broadcasting 遵循 NumPy 规则，从右向左对齐维度：

```
规则 1：如果两个 Tensor 维度数不同，在维度较少的 Tensor 左侧补 1
规则 2：对齐后，每个维度上：
        - 如果相等 → 保留
        - 如果一个为 1 → 广播为另一个的大小
        - 如果都不为 1 且不相等 → 报错
```

### 2.2 逐步广播示例

```
示例 1：形状 (3, 4) 和 (4,) → 广播为 (3, 4)

  (3, 4)     →  (3, 4)
  (4,)       →  (1, 4)  ← 左侧补 1
              ─────────
              →  (3, 4)  ← dim=0: 1→3 广播

  可视化：
  a: ┌────────────┐       b: ┌────────────┐
     │ a0 a1 a2 a3 │          │ b0 b1 b2 b3 │
     │ a4 a5 a6 a7 │          └────────────┘
     │ a8 a9 aA aB │               ↓ 广播
     └────────────┘          ┌────────────┐
                             │ b0 b1 b2 b3 │
                             │ b0 b1 b2 b3 │
                             │ b0 b1 b2 b3 │
                             └────────────┘

  a + b = ┌──────────────────┐
          │ a0+b0 a1+b1 ...   │
          │ a4+b0 a5+b1 ...   │
          │ a8+b0 a9+b1 ...   │
          └──────────────────┘
```

```python
# 经典广播场景
# 1. 向量 + 标量
x = torch.randn(3, 4)
bias = torch.randn(4)      # (4,) → (1, 4) → 广播为 (3, 4)
y = x + bias               # 等价于 x + bias.unsqueeze(0)

# 2. batch 操作
batch = torch.randn(32, 10, 64)   # (batch, seq_len, hidden)
weight = torch.randn(64, 128)     # (hidden, out_dim) → (1, 64, 128) → (32, 10, 128)
output = batch @ weight           # (32, 10, 64) @ (64, 128) = (32, 10, 128)
# 注意：matmul 的广播是特殊的 batch matmul，与逐元素广播规则不完全相同

# 3. 不兼容的情况
a = torch.randn(3, 4)
b = torch.randn(3, 1)     # OK → 广播 dim=1: 1→4
c = a + b                 # (3, 4)

b = torch.randn(3, 5)     # Error!
# c = a + b                # RuntimeError: shape [3,4] + [3,5]，dim=1 不兼容
```

### 2.3 广播的显存含义

```python
# 广播不复制数据！它通过 stride=0 实现
a = torch.randn(1, 4)
print(a.stride())   # (4, 1)

b = a.expand(3, 4)  # 广播 — 不分配新显存
print(b.stride())   # (0, 1) ← stride[0]=0 表示沿 dim=0 "前进"时不移动
print(a.storage().data_ptr() == b.storage().data_ptr())  # True

# 这在训练中对节省显存很重要：
# 比如 attention mask (batch, 1, seq, seq)，只需存一个 (seq, seq) 的副本
```

### 2.4 实践：Attention Mask 广播

```python
# 标准 causal mask 的广播
seq_len = 512
# 只需要一个上三角矩阵
mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()  # (seq, seq)

# 在 attention 计算中自动广播到 (batch, num_heads, seq, seq)
scores = torch.randn(2, 8, 512, 512)  # (batch, heads, seq, seq)
scores.masked_fill_(mask, float('-inf'))  # mask (512, 512) → 广播到 (2, 8, 512, 512)
```

**核心要点**：
- 广播通过 stride=0 实现，绝不复制数据
- 从右向左对齐，补 1 后匹配
- 常见的 attention mask、bias、scale 都利用了广播
- `expand()` 是广播的显式 API，等价于隐式广播

---

## 3. einsum 完全指南

### 3.1 为什么 einsum 是 AI Infra 工程师的必备工具

einsum (Einstein Summation) 用简洁的字符串描述复杂的张量运算。在阅读 attention 代码、分析模型结构时，einsum 表示法比多维 matmul/transpose 组合更清晰。

```
可读性对比：

  # 标准写法：需要跟踪所有轴的顺序
  attn = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(d_k)

  # einsum 写法：一目了然
  attn = torch.einsum('bhqd,bhkd->bhqk', Q, K) * scale
```

### 3.2 einsum 语法规则

```
torch.einsum('下标串', tensor1, tensor2, ...)

规则：
1. 逗号分隔各输入的下标，箭头后是输出的下标
2. 出现在输入但不在输出中的下标 → 求和（缩并）
3. 出现在输入和输出中的下标 → 保留
4. 可以用 ... 表示省略的维度（批处理友好）
```

### 3.3 逐步示例：从简单到复杂

```python
import torch

# ===== 示例 0：向量点积 =====
a = torch.randn(4)
b = torch.randn(4)
c = torch.einsum('i,i->', a, b)      # 对 i 求和 → 标量
# 等价于 torch.dot(a, b) 或 (a * b).sum()

# ===== 示例 1：矩阵乘法 =====
A = torch.randn(3, 4)
B = torch.randn(4, 5)
C = torch.einsum('ik,kj->ij', A, B)  # 求和 k，保留 i,j → (3, 5)
# 等价于 A @ B

# ===== 示例 2：外积 =====
a = torch.randn(3)
b = torch.randn(4)
c = torch.einsum('i,j->ij', a, b)    # 不求和 → (3, 4)
# 等价于 a.unsqueeze(1) * b.unsqueeze(0) 或 torch.outer(a, b)

# ===== 示例 3：批量矩阵乘法 (常用！) =====
A = torch.randn(32, 3, 4)  # (batch, m, k)
B = torch.randn(32, 4, 5)  # (batch, k, n)
C = torch.einsum('bmk,bkn->bmn', A, B)  # (32, 3, 5)
# 等价于 torch.bmm(A, B) 或 A @ B

# ===== 示例 4：提取对角线 =====
M = torch.randn(4, 4)
d = torch.einsum('ii->i', M)   # (4,) — 对角线元素
# 等价于 torch.diag(M)

# ===== 示例 5：Trace =====
M = torch.randn(4, 4)
t = torch.einsum('ii->', M)    # 标量 — 对角线求和
# 等价于 torch.trace(M)

# ===== 示例 6：转置 =====
M = torch.randn(3, 4)
Mt = torch.einsum('ij->ji', M)  # (4, 3)
# 等价于 M.T

# ===== 示例 7：全元素求和 =====
M = torch.randn(3, 4)
s = torch.einsum('ij->', M)     # 标量
# 等价于 M.sum()
```

### 3.4 Attention 中的 einsum — 最重要的实战

在 Transformer 中，einsum 让 attention 计算一目了然：

```python
# ===== Scaled Dot-Product Attention 的 einsum 分解 =====
batch, heads, seq_q, seq_k, d_k = 2, 8, 128, 128, 64

Q = torch.randn(batch, heads, seq_q, d_k)   # (B, H, Q, D)
K = torch.randn(batch, heads, seq_k, d_k)   # (B, H, K, D)
V = torch.randn(batch, heads, seq_k, d_k)   # (B, H, K, D)

# Step 1: 计算注意力分数 — Q·K^T
scores = torch.einsum('bhqd,bhkd->bhqk', Q, K)  # (B, H, Q, K)
#        等价于 torch.matmul(Q, K.transpose(-2, -1))
#        含义：对 d 维度做点积，输出 Q_len × K_len 的注意力矩阵

# Step 2: Scale + Mask + Softmax
scores = scores / (d_k ** 0.5)
# ... 应用 causal mask
attn_weights = torch.softmax(scores, dim=-1)    # (B, H, Q, K)

# Step 3: 加权求和
output = torch.einsum('bhqk,bhkd->bhqd', attn_weights, V)  # (B, H, Q, D)
#        含义：对 K 维度加权求和，输出每个 query 位置的上下文向量

# ===== FlashAttention 风格的 einsum 写法 =====
# FlashAttention 等价于上述三步，但在一个 fused kernel 中完成
# 这里展示的是概念等价的计算
```

### 3.5 GQA (Grouped Query Attention) 的 einsum

```python
# GQA: H=32 query heads, G=8 kv heads
# 需要 broadcasts kv heads 到 query heads
batch, num_q_heads, num_kv_heads, seq_q, seq_k, d_head = 2, 32, 8, 128, 128, 128
group_size = num_q_heads // num_kv_heads  # 4

Q = torch.randn(batch, num_q_heads, seq_q, d_head)      # (B, 32, Q, D)
K = torch.randn(batch, num_kv_heads, seq_k, d_head)     # (B, 8,  K, D)
V = torch.randn(batch, num_kv_heads, seq_k, d_head)     # (B, 8,  K, D)

# 方法 1：显式重复 KV heads
K_expanded = K.unsqueeze(2).expand(-1, -1, group_size, -1, -1)  # (B, 8, 4, K, D)
K_expanded = K_expanded.reshape(batch, num_q_heads, seq_k, d_head)  # (B, 32, K, D)
# 然后正常做 attention

# 方法 2：使用 einsum 加 reshape
# 将 Q 重塑为 (B, G, group_size, Q, D)，然后与 K (B, G, 1, K, D) 广播
Q_r = Q.reshape(batch, num_kv_heads, group_size, seq_q, d_head)  # (B, 8, 4, Q, D)
K_r = K.reshape(batch, num_kv_heads, 1, seq_k, d_head)           # (B, 8, 1, K, D)
scores = torch.einsum('bgqhd,bgkld->bgqkl', Q_r, K_r)            # (B, 8, 4, Q, K)
# 或者更简洁地让 einsum 处理广播
scores = torch.einsum('bhqd,bgkd->bhqk', Q, K)  # 不同下标字母=独立维度，不会自动广播
# 正确做法：
# 不变，K 的 heads 用不同的字母，einsum 要求显式
```

### 3.6 einsum 性能注意事项

```python
# einsum 在内部会转换成矩阵乘法或缩减操作
# 对于标准操作（matmul, bmm），直接使用对应 API 更快

# 快：直接 matmul
output = torch.matmul(Q, K.transpose(-2, -1))  # cuBLAS 优化

# 略慢：einsum（但差距在缩小）
output = torch.einsum('bhqd,bhkd->bhqk', Q, K)  # 也会调用 cuBLAS

# einsum 的真正价值在于：
# 1. 可读性 — 复杂张量操作一目了然
# 2. 组合操作 — 一次调用完成 matmul + transpose + sum
# 3. 避免中间张量 — 'ij,jk,kl->il' 一步到位

# 避免中间的显存分配
# 标准写法：
tmp1 = A @ B   # 分配中间结果显存
result = tmp1 @ C

# einsum 写法：
result = torch.einsum('ij,jk,kl->il', A, B, C)  # 可能融合为一个 kernel

# 但是！对于大矩阵，标准矩阵乘法的 cuBLAS 优化更成熟
# 所以实际上 'bhqd,bhkd->bhqk' 这种等价于 bmm 的操作用 matmul 可能更快
# PyTorch 2.0+ 的 torch.compile 已经在缩小这个差距
```

### 3.7 字母约定 (Conventions)

```
在 AI Infra 代码中常见的 einsum 下标约定：

b = batch_size
h = num_heads
g = num_kv_heads (GQA)
q = query_seq_len
k = key_seq_len
d = head_dim
m = model_dim / hidden_dim
v = vocab_size
o = output_dim

常见模式：
'bhqd,bhkd->bhqk'  — Attention scores
'bhqk,bhkd->bhqd'  — Attention output
'bld,md->blm'      — Linear projection (batch, seq, hidden) @ (hidden, out)
'bmk,bkn->bmn'     — Batch matmul
'bld,dv->blv'      — LM head
```

**核心要点**：
- einsum 用字符串描述张量缩并，比多层 matmul/transpose 清晰 10 倍
- `'bhqd,bhkd->bhqk'` 是 attention 的标准写法
- 重复下标表示求和（缩并），独有下标表示保留
- 对于等价于标准 matmul 的操作直接用 matmul，组合操作才用 einsum
- 字母约定有助于团队协作和代码审查

---

## 4. Autograd 自动微分引擎

### 4.1 计算图 (Computational Graph)

PyTorch 的 autograd 构建**动态计算图**——每次 forward 时动态创建，backward 后自动销毁。与 TensorFlow 1.x 的静态图不同，这让调试和动态控制流变得自然。

```
一次 forward + backward 的完整过程：

  Forward:
  ┌──────┐    ┌──────┐    ┌──────┐    ┌──────┐
  │  x   │───→│  ×2  │───→│  +3  │───→│ ²    │───→ loss
  │(leaf)│    │      │    │      │    │      │
  └──────┘    └──────┘    └──────┘    └──────┘
     │           │            │           │
     │ grad_fn=Mul          │           │
     │            │ grad_fn=Add        │
     │           │            │ grad_fn=Pow
     │           │            │           │
     ▼           ▼            ▼           ▼
  Backward:
  计算图从 loss 反向遍历，每个节点调用其 grad_fn 计算梯度

  loss.grad_fn = <PowBackward0>
    │
    ├── y.grad_fn = <AddBackward0>
    │     │
    │     └── z.grad_fn = <MulBackward0>
    │           │
    │           └── x (leaf tensor, 累积梯度)
    │
    └── (无子节点)
```

### 4.2 自动微分原理

```python
import torch

# 创建需要梯度的 Tensor
x = torch.tensor([2.0], requires_grad=True)  # leaf tensor

# Forward：构建计算图
y = x * 2       # y.retains_grad, grad_fn=<MulBackward0>
z = y + 3       # z.grad_fn=<AddBackward0>
loss = z ** 2   # loss.grad_fn=<PowBackward0>

# 数学上：loss = (2x + 3)²
# d(loss)/dx = 2 * (2x + 3) * 2 = 4 * (2x + 3)

# Backward：自动计算梯度
loss.backward()                    # 从 loss 开始反向传播
print(x.grad)  # tensor([28.])     # 4*(2*2+3) = 4*7 = 28 ✓

# 验证手动计算：
# loss = (2*2 + 3)² = 7² = 49
# d(loss)/dx = 2*z * dz/dx = 2*7 * 2 = 28 ✓
```

### 4.3 Gradient Accumulation（梯度累积）

这是大模型训练的核心技巧，允许在显存受限时模拟更大的 batch size：

```python
# 为什么需要梯度累积？
# 假设模型只能容纳 batch_size=4，但需要 effective batch_size=32
# → 每 8 个 micro-batch 后更新一次参数

model = SomeLargeModel()
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
accumulation_steps = 8

optimizer.zero_grad()                    # 梯度清零
for i, batch in enumerate(dataloader):
    loss = model(batch)                  # forward
    loss = loss / accumulation_steps     # 归一化！重要！
    loss.backward()                      # backward — 梯度累加到 .grad 中

    if (i + 1) % accumulation_steps == 0:
        optimizer.step()                 # 更新参数
        optimizer.zero_grad()            # 清零梯度，开始下一轮累积
```

**梯度累积的原理**：

```
迭代 1: loss₁, backward() → grad₁ 存入 param.grad
迭代 2: loss₂, backward() → grad₂ 累加到 param.grad (grad₁ + grad₂)
...
迭代 8: loss₈, backward() → grad₈ 累加到 param.grad (grad₁+...+grad₈)
        optimizer.step() → 用累积的梯度更新参数
        zero_grad()      → param.grad 清零

   效果等价于 batch_size=32 的单次 forward/backward
   （对于大多数优化器；对于带状态的如 Adam 略有差异）
```

### 4.4 retain_graph 与多次 backward

```python
x = torch.tensor([2.0], requires_grad=True)
y = x ** 2
z = y * 3

# 默认：计算图在 backward 后销毁
z.backward()       # OK
# z.backward()     # RuntimeError! 计算图已销毁

# 需要多次 backward 时（如 GAN、多任务学习）：
x = torch.tensor([2.0], requires_grad=True)
y = x ** 2
z = y * 3

z.backward(retain_graph=True)  # 保留计算图
print(x.grad)  # tensor([12.])  # 3*2*x|_{x=2} = 12

# 清零梯度，再做一次 backward
x.grad.zero_()
z.backward()  # 不需要 retain_graph（这是最后一次）
print(x.grad)  # tensor([12.])
```

### 4.5 detach() 与 .data 的区别

```python
# detach(): 返回一个共享 storage 但不需要梯度的 tensor
# 同时切断计算图，防止梯度回传

x = torch.tensor([2.0], requires_grad=True)
y = x ** 2          # y 需要梯度
y_detached = y.detach()  # 共享数据，但不追踪梯度

# .data: 旧版的 detach()，不推荐使用
# 区别：.data 绕过了 autograd 的版本检查，可能导致错误梯度
#        .detach() 被 autograd 引擎感知，更安全

# 实战用法：在 GAN 的训练中
# Generator 输出后 detach 再送入 Discriminator
fake = generator(noise)
fake_detached = fake.detach()  # 不对 Generator 回传梯度
d_fake = discriminator(fake_detached)
```

### 4.6 torch.no_grad() vs torch.inference_mode() — 见下一节

**核心要点**：
- Forward 构建动态计算图；backward 从 loss 反向遍历
- `loss.backward()` 将梯度累加到 `.grad`（不清零→累积效应）
- 梯度累积是实现大 batch 训练的关键技巧，注意 loss 归一化
- `retain_graph=True` 保持计算图，用于多次 backward
- `detach()` 安全切断计算图，`.data` 已过时

---

## 5. 推理模式：no_grad vs inference_mode

这是每个推理工程师都必须深刻理解的区别。

### 5.1 torch.no_grad()

```python
with torch.no_grad():
    output = model(input_ids)  # 不构建计算图，节省显存

# 特点：
# 1. 不追踪 autograd 历史
# 2. Tensor 操作结果 requires_grad=False
# 3. 但是！Tensor 本身仍然可以被原地修改 (in-place mutation)
# 4. 版本计数器 (version counter) 仍然递增
```

### 5.2 torch.inference_mode()

```python
with torch.inference_mode():
    output = model(input_ids)

# 特点：
# 1. 包含 no_grad() 的所有效果
# 2. 额外限制：禁止任何可能改变 Tensor 版本号的操作
# 3. 性能比 no_grad() 更好 — 因为禁用了版本跟踪
```

### 5.3 深入：Tensor 版本计数器

```python
# PyTorch 维护每个 Tensor 的 version counter
# 用于检测 saved tensor 是否在 backward 使用前被修改

x = torch.tensor([1.0, 2.0, 3.0])
print(x._version)  # 0

x.add_(1)          # in-place 操作
print(x._version)  # 1 — 版本号递增

# inference_mode 禁用版本跟踪
with torch.inference_mode():
    x = torch.tensor([1.0, 2.0, 3.0])
    print(x._version)  # 0
    x.add_(1)          # 在 inference_mode 下这可能被允许，但版本号不增
```

### 5.4 性能对比和选择指南

```
┌──────────────────────────────────────────────────────────────┐
│                     no_grad vs inference_mode                │
│                                                              │
│  ┌──────────────────┬──────────────┬──────────────────────┐ │
│  │      特性         │   no_grad    │   inference_mode     │ │
│  ├──────────────────┼──────────────┼──────────────────────┤ │
│  │ 不追踪 autograd   │     ✓        │        ✓             │ │
│  │ 禁用版本跟踪      │     ✗        │        ✓             │ │
│  │ in-place 操作     │     ✓        │   受限（不建议）       │ │
│  │ Tensor 可修改     │     ✓        │   不建议              │ │
│  │ 性能             │    较好      │      更好             │ │
│  │ 适用场景         │  训练 eval   │   纯推理              │ │
│  └──────────────────┴──────────────┴──────────────────────┘ │
│                                                              │
│  推荐：                                                       │
│  - 推理部署：torch.inference_mode() （vLLM 使用这个）          │
│  - 训练中的 eval：torch.no_grad()                             │
│  - 需要修改 tensor：torch.no_grad()                           │
└──────────────────────────────────────────────────────────────┘
```

```python
# vLLM 中的实际用法（简化版）
import torch

class ModelRunner:
    @torch.inference_mode()  # 整个 forward 在 inference_mode 中
    def execute_model(self, *args, **kwargs):
        # 1. 准备输入
        # 2. 模型 forward
        # 3. Sampling
        return output

# 为什么 vLLM 用 inference_mode 而不是 no_grad：
# 1. 推理不需要梯度，也不需要版本跟踪
# 2. 版本跟踪有微小开销，在大规模推理中累积可观
# 3. 防止意外的 in-place 修改导致难以调试的 bug
```

### 5.5 注意事项

```python
# TIP 1: inference_mode 不能和 requires_grad=True 的 tensor 混用
x = torch.randn(10, requires_grad=True)
with torch.inference_mode():
    pass  # x 仍然有 requires_grad=True，但计算不会追踪

# TIP 2: 可以在 inference_mode 中创建新的 tensor
with torch.inference_mode():
    x = torch.randn(100)  # 新 tensor，requires_grad=False

# TIP 3: 嵌套使用 — 内层装饰器生效
with torch.no_grad():
    with torch.inference_mode():
        # 这里是 inference_mode
        pass
    # 这里是 no_grad

# TIP 4: 在推理中需要使用 model.eval() + inference_mode()
model.eval()  # 影响 Dropout、BatchNorm 等层的 behavior
with torch.inference_mode():  # 影响 autograd
    output = model(x)
# 两者作用不同！都需要！
```

**核心要点**：
- `inference_mode() = no_grad() + 禁用版本跟踪 → 推理首选`
- `no_grad()` 用于训练中的 eval 阶段
- `model.eval()` 和 `inference_mode()` 作用不同，都要设置
- vLLM 全面使用 `inference_mode()` 以获得最佳推理性能

---

## 6. nn.Module 深度解析

### 6.1 三要素：Parameter、Buffer、State Dict

```python
import torch
import torch.nn as nn

class MyModule(nn.Module):
    def __init__(self):
        super().__init__()
        # ===== nn.Parameter：需要梯度的可学习参数 =====
        self.weight = nn.Parameter(torch.randn(64, 128))
        # 自动注册到 self._parameters，optimizer 会更新

        # ===== 普通 Tensor：不会注册到 module =====
        self.not_a_param = torch.randn(10)
        # 不会出现在 parameters() 中，不会被 optimizer 更新

        # ===== Buffer：不需要梯度的持久化状态 =====
        self.register_buffer('running_mean', torch.zeros(128))
        # 会出现在 state_dict() 中，会随 model.cuda() 移动
        # 但不会出现在 parameters() 中，optimizer 也不更新

        # ===== Sub-Module：自动注册 =====
        self.linear = nn.Linear(128, 256)
        # 赋值给 self.xxx 的 nn.Module 自动注册

    def forward(self, x):
        return self.linear(x)

# 验证注册
model = MyModule()
print("Parameters:")
for name, p in model.named_parameters():
    print(f"  {name}: {p.shape}")   # weight, linear.weight, linear.bias

print("\nBuffers:")
for name, b in model.named_buffers():
    print(f"  {name}: {b.shape}")   # running_mean

print("\nAll modules:")
for name, m in model.named_modules():
    print(f"  {name}: {type(m).__name__}")
```

### 6.2 参数注册机制

nn.Module 通过 `__setattr__` 和 `__getattr__` 机制自动注册：

```
当你写 self.linear = nn.Linear(128, 256) 时：

1. nn.Module.__setattr__ 被调用
2. 检测到 linear 是 nn.Module 实例
3. 将 linear 注册到 self._modules['linear']
4. linear 的 parameters 被递归包含到 self.parameters()
5. 调用 model.cuda() 时，递归移动所有子模块和参数
6. state_dict() 递归收集所有参数的名称和值
```

### 6.3 forward：你唯一需要重写的方法

```python
# nn.Module 的核心约定：重写 forward()
# PyTorch 内部调用 __call__() → forward() + hooks

class AttentionBlock(nn.Module):
    def __init__(self, dim, num_heads):
        super().__init__()
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.o_proj = nn.Linear(dim, dim)
        self.num_heads = num_heads
        self.head_dim = dim // num_heads

    def forward(self, x):
        # __call__ 会自动调用 pre_forward_hook → forward → post_forward_hook
        B, T, C = x.shape
        q = self.q_proj(x).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        # ... attention computation ...
        return self.o_proj(out)
```

### 6.4 state_dict 与模型持久化

```python
# state_dict() 返回一个 OrderedDict
# key = 参数名（如 'layers.0.attention.q_proj.weight'）
# value = 参数 Tensor

model = MyModel()

# 保存
torch.save(model.state_dict(), 'model_weights.pt')
# 或使用 safetensors（推荐，见 Part 4）
from safetensors.torch import save_file
save_file(model.state_dict(), 'model_weights.safetensors')

# 加载
state_dict = torch.load('model_weights.pt')
model.load_state_dict(state_dict, strict=True)  # strict=False 允许部分加载

# 查看 state_dict 结构
for key, tensor in model.state_dict().items():
    print(f"{key}: {tensor.shape}, {tensor.dtype}")
# 输出示例：
# token_embedding.weight: torch.Size([32000, 4096]), torch.float16
# layers.0.input_layernorm.weight: torch.Size([4096]), torch.float16
# layers.0.self_attn.q_proj.weight: torch.Size([4096, 4096]), torch.float16
# ...
```

### 6.5 常用 Hooks

```python
# Hooks 用于在不修改模型代码的情况下注入自定义行为

# 1. Forward Hook：在 forward() 之后执行
def forward_hook(module, input, output):
    print(f"{module.__class__.__name__}: output shape = {output.shape}")

# 2. Forward Pre-Hook：在 forward() 之前执行
def forward_pre_hook(module, input):
    print(f"{module.__class__.__name__}: input shape = {input[0].shape}")

# 3. Backward Hook：在 backward() 时执行
def backward_hook(module, grad_input, grad_output):
    print(f"grad norm = {grad_output[0].norm()}")

# 注册
handle_fwd = model.layers[0].register_forward_hook(forward_hook)
handle_pre = model.layers[0].register_forward_pre_hook(forward_pre_hook)
handle_bwd = model.layers[0].register_full_backward_hook(backward_hook)

# 不需要时移除
handle_fwd.remove()
```

### 6.6 设备管理与 to() 方法

```python
# 所有相关张量移动到同一设备
model = model.to('cuda')          # 移动到 GPU
model = model.to(dtype=torch.float16)  # 转换精度
model = model.to('cuda', dtype=torch.bfloat16)  # 同时移动 + 转换

# 内部实现：
# nn.Module.to() 递归调用 _apply()
# _apply() 先处理 parameter 和 buffer，再递归子模块
```

**核心要点**：
- `nn.Parameter`：可学习参数，optimizer 更新
- `register_buffer()`：无需梯度的持久化状态（如 BatchNorm 的 running_mean）
- `state_dict()`：递归收集所有 parameter 和 buffer
- `forward()`：需要重写；`__call__()` 自动包裹 hooks
- 赋值给 `self.xxx` 的 Module/Parameter/Buffer 自动注册

---

## 7. Dataset 与 DataLoader 最佳实践

### 7.1 pin_memory：CPU→GPU 传输优化

```python
# pin_memory=True 将数据放入 CPU 的 page-locked memory
# GPU 可以通过 DMA (Direct Memory Access) 直接读取
# 避免了 CPU 先拷贝到 staging buffer 再 DMA 的开销

dataloader = torch.utils.data.DataLoader(
    dataset,
    batch_size=32,
    pin_memory=True,     # 启用 pinned memory
    pin_memory_device='cuda',  # PyTorch 2.1+ 直接 pin 到 GPU
)

# 内存传输路径对比：
#
# 无 pin_memory：
#   CPU Pageable Memory → CPU Staging Buffer → GPU (DMA)
#   需要一次 CPU 拷贝 + 一次 DMA 传输
#
# 有 pin_memory：
#   CPU Pinned Memory → GPU (DMA)
#   只需一次 DMA 传输，且 GPU 可以异步拷贝（与 kernel 执行重叠）
```

### 7.2 num_workers 与 prefetch_factor

```python
# num_workers：子进程数量，用于并行加载数据
# prefetch_factor：每个 worker 提前加载的 batch 数

dataloader = torch.utils.data.DataLoader(
    dataset,
    batch_size=32,
    num_workers=4,           # 4 个子进程并行加载
    prefetch_factor=2,       # 每个 worker 提前准备 2 个 batch
    pin_memory=True,
)

# 工作原理：
#
#  Worker 0: [batch 0] → [batch 4] → [batch 8] → ...
#  Worker 1: [batch 1] → [batch 5] → [batch 9] → ...
#  Worker 2: [batch 2] → [batch 6] → [batch 10]→ ...
#  Worker 3: [batch 3] → [batch 7] → [batch 11]→ ...
#                   ↓
#            主进程队列 (prefetch_factor=2 → 容量 4×2=8)
#                   ↓
#            GPU 训练循环
#
#  num_workers=0：主进程自己加载（调试用，慢）
#  num_workers>0：子进程加载（生产环境）


# 最佳实践：
# 1. num_workers = min(4*cpu_count, gpu_count*4) 作为起点
# 2. prefetch_factor=2 是安全的默认值
# 3. 如果数据预处理很重（图片解码等），增加 num_workers
# 4. 如果 I/O 是瓶颈，考虑将数据放到更快的存储（NVMe SSD）
```

### 7.3 自定义 Dataset

```python
from torch.utils.data import Dataset, DataLoader
import json

class TextDataset(Dataset):
    """文本数据集，返回 tokenized 的 input_ids"""
    def __init__(self, data_path, tokenizer, max_length=2048):
        with open(data_path, 'r') as f:
            self.data = [json.loads(line) for line in f]
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        text = self.data[idx]['text']
        tokens = self.tokenizer.encode(text)
        # 截断或填充到 max_length
        if len(tokens) > self.max_length:
            tokens = tokens[:self.max_length]
        else:
            tokens = tokens + [self.tokenizer.pad_token_id] * (self.max_length - len(tokens))
        return {
            'input_ids': torch.tensor(tokens, dtype=torch.long),
        }

# 使用
dataset = TextDataset('data.jsonl', tokenizer, max_length=2048)
dataloader = DataLoader(
    dataset,
    batch_size=8,
    shuffle=True,
    num_workers=2,
    pin_memory=True,
    prefetch_factor=2,
)

for batch in dataloader:
    input_ids = batch['input_ids'].to('cuda')  # pin_memory 加速此传输
    # ... training ...
```

### 7.4 collate_fn：自定义批处理

```python
def collate_fn(batch):
    """将变长序列填充到相同长度"""
    # batch 是一个 list of samples
    input_ids = [item['input_ids'] for item in batch]
    attention_mask = [item['attention_mask'] for item in batch]

    # 填充到批次内最大长度（动态 padding，节省计算）
    max_len = max(len(ids) for ids in input_ids)
    padded_ids = []
    padded_mask = []

    for ids, mask in zip(input_ids, attention_mask):
        pad_len = max_len - len(ids)
        padded_ids.append(torch.cat([ids, torch.zeros(pad_len, dtype=torch.long)]))
        padded_mask.append(torch.cat([mask, torch.zeros(pad_len, dtype=torch.long)]))

    return {
        'input_ids': torch.stack(padded_ids),
        'attention_mask': torch.stack(padded_mask),
    }

dataloader = DataLoader(dataset, batch_size=8, collate_fn=collate_fn)
```

### 7.5 IterableDataset：流式数据

```python
class StreamingTextDataset(torch.utils.data.IterableDataset):
    """适用于数据量远大于内存的情况"""
    def __init__(self, file_pattern, tokenizer, max_length=2048):
        import glob
        self.files = sorted(glob.glob(file_pattern))
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __iter__(self):
        # 在每个 worker 中重新打开文件
        worker_info = torch.utils.data.get_worker_info()
        if worker_info is not None:
            # 多 worker：每个 worker 处理不同的文件
            per_worker = len(self.files) // worker_info.num_workers
            worker_id = worker_info.id
            my_files = self.files[worker_id * per_worker : (worker_id + 1) * per_worker]
        else:
            my_files = self.files

        for file_path in my_files:
            with open(file_path, 'r') as f:
                for line in f:
                    data = json.loads(line)
                    tokens = self.tokenizer.encode(data['text'])[:self.max_length]
                    yield torch.tensor(tokens, dtype=torch.long)

# IterableDataset 无法 shuffle（因为数据流是无限的）
# 但可以通过 shuffle buffer 实现近似的 shuffle
```

**核心要点**：
- `pin_memory=True` 利用 DMA 加速 CPU→GPU 传输，是推理必须的
- `num_workers` 根据 CPU 核数和 I/O 负载调整，一般为 2-8
- `prefetch_factor=2` 让 GPU 在计算当前 batch 时 CPU 已在准备下一批
- 自定义 `Dataset.__getitem__` 或 `IterableDataset.__iter__`
- 动态 padding（batch 内填充到最大长度）比全局固定长度更省计算

---

## Part 2: Transformer 架构完全走读

---

## 8. Token Embedding：词嵌入与权重共享

### 8.1 基本概念

Token Embedding 将离散的 token ID 映射为连续的向量表示：

```
Token ID (整数)  →  Embedding Matrix (vocab_size × d_model)  →  Vector (d_model)

  输入: [15, 234, 89, 1024]              Embedding 矩阵
                                        ┌─────────────┐
                                     15→│[0.12, -0.34, │  ← W_e[15, :]
                                        │ 0.56, ...]   │
                                    234→│[0.78, 0.23,  │  ← W_e[234, :]
                                        │ -0.45, ...]  │
                                     89→│[-0.12, 0.67, │  ← W_e[89, :]
                                        │ 0.34, ...]   │
                                   1024→│[0.45, -0.12, │  ← W_e[1024, :]
                                        │ 0.89, ...]   │
                                        └─────────────┘
                                              ↑
                                     vocab_size × d_model
                                     一个巨大的查找表
```

### 8.2 实现细节与 Scaling

```python
import torch
import torch.nn as nn

class TokenEmbedding(nn.Module):
    def __init__(self, vocab_size, d_model):
        super().__init__()
        # 标准初始化：N(0, 1)，然后在 forward 中乘以 sqrt(d_model)
        self.embed = nn.Embedding(vocab_size, d_model)
        self.d_model = d_model
        # 重置权重为 N(0, 0.02)，许多模型用这个小方差
        nn.init.normal_(self.embed.weight, mean=0.0, std=0.02)

    def forward(self, input_ids):
        # input_ids: (batch, seq_len), dtype=long
        # 输出: (batch, seq_len, d_model)
        x = self.embed(input_ids)
        # GPT-2/LLaMA 风格的 scaling：防止嵌入向量过大
        x = x * (self.d_model ** 0.5)
        # 原因：embedding 初始化为 N(0,1)，但实际值可能较大
        # 乘以 sqrt(d_model) 平衡了 embedding 和后续层的数值范围
        return x

# 为什么需要 scaling？
# 假设 d_model=4096，embedding 向量的 L2 范数约为 sqrt(4096)=64
# 如果 attention 的 softmax 输入太大 → 梯度消失
# 乘以 sqrt(d_model) 后，输出范围更稳定
```

### 8.3 Weight Tying：Embedding 与 LM Head 共享权重

```python
# 在 GPT/LLaMA 等模型中，输入 embedding 和输出 lm_head 共享权重
# 这称为 weight tying，减少了大量参数

class GPTWithWeightTying(nn.Module):
    def __init__(self, vocab_size, d_model, num_layers, num_heads):
        super().__init__()
        # 输入 embedding
        self.token_embedding = nn.Embedding(vocab_size, d_model)
        # Transformer blocks
        self.blocks = nn.ModuleList([
            TransformerBlock(d_model, num_heads) for _ in range(num_layers)
        ])
        self.ln_f = nn.LayerNorm(d_model)
        # 输出投影：d_model → vocab_size
        # 注意：不是 nn.Linear，而是直接复用 embedding 的权重！
        self.lm_head_weight = self.token_embedding.weight  # 引用同一个 Tensor！

    def forward(self, input_ids):
        x = self.token_embedding(input_ids)
        for block in self.blocks:
            x = block(x)
        x = self.ln_f(x)
        # 使用 F.linear + embedding.weight.T 做 projection
        logits = torch.nn.functional.linear(x, self.lm_head_weight)
        return logits

# 为什么 weight tying 有效？
# 1. 语义一致性：如果两个 token 在 embedding 空间相近，
#    那么它们的输出 logit 也应该相近
# 2. 参数效率：vocab_size × d_model 通常很大
#    例如 LLaMA-7B：32000 × 4096 = 131M 参数
#    共享后节省了 131M 参数
# 3. 正则化效果：减少过拟合
```

**核心要点**：
- Embedding 是一个 `vocab_size × d_model` 的查找表
- 输入乘以 `sqrt(d_model)` 用于数值稳定
- Weight tying：embedding 矩阵 = lm_head 权重，节省大量参数
- 初始化通常使用小方差正态分布（如 std=0.02）


## 9. 位置编码演变史：Sinusoidal → Learned → RoPE → ALiBi → YaRN

位置编码是 Transformer 中最精妙的设计之一。没有它，attention 就是"词袋模型"——完全忽略词的顺序。

### 9.1 为什么需要位置编码

```
Self-Attention 是置换等变的 (permutation equivariant)：

  输入顺序 [A, B, C] → 输出顺序 [A', B', C']
  输入顺序 [C, A, B] → 输出顺序 [C', A', B']
  仅仅重排，不改变每个位置的输出！

  对于序列建模，这意味着：
  "狗 咬 人" 和 "人 咬 狗" 在 attention 中产生相同的表示
  → 这是不可接受的

  解决：在输入 embedding 中加入位置信息
  → 同一个词在不同位置有不同的表示
```

### 9.2 第一代：Sinusoidal Position Encoding (Transformer 2017)

```python
import math
import torch

def sinusoidal_position_encoding(seq_len, d_model):
    """
    PE(pos, 2i)   = sin(pos / 10000^(2i/d_model))
    PE(pos, 2i+1) = cos(pos / 10000^(2i/d_model))

    pos: 位置索引
    i:   维度索引
    """
    pe = torch.zeros(seq_len, d_model)
    position = torch.arange(0, seq_len, dtype=torch.float).unsqueeze(1)  # (seq_len, 1)
    # 计算 1/10000^(2i/d_model) = exp(-2i * log(10000) / d_model)
    div_term = torch.exp(
        torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model)
    )

    pe[:, 0::2] = torch.sin(position * div_term)   # 偶数维用 sin
    pe[:, 1::2] = torch.cos(position * div_term)   # 奇数维用 cos

    return pe

# 可视化
import matplotlib.pyplot as plt
pe = sinusoidal_position_encoding(256, 128)
# 低维度（高频率）：短距离位置区分度高
# 高维度（低频率）：长距离位置区分度高
# → 类似二进制的不同位
```

**Sinusoidal 编码的性质**：

```
性质 1：相对位置可以用线性变换表示

  PE(pos+k) = M_k · PE(pos)  （M_k 只与 k 有关，与 pos 无关）
  这意味着 attention 可以学习关注相对位置

性质 2：不同维度的频率呈几何级数递减

  频率范围: 2π/10000 ≈ 0.0006 到 2π/10000^(d/2) → 非常宽的范围

性质 3：不需要训练参数，可以外推到训练时未见过的长度

  但实际中外推效果有限，因为高频维度的"周期"太短
```

**为什么 Sinusoidal 后来被淘汰了？**

```
1. 不可学习 → 模型无法找到最优的位置表示
2. 外推能力有限 → 虽然理论上可以，实际效果不佳
3. 绝对位置 → 比后来的相对位置编码（RoPE）表现差
4. 固定频率 → 无法适应不同任务和不同层
```

### 9.3 第二代：Learned Position Embedding (GPT/LLaMA 早期)

```python
class LearnedPositionEmbedding(nn.Module):
    def __init__(self, max_seq_len, d_model):
        super().__init__()
        # 可学习的位置编码表
        self.pos_embed = nn.Embedding(max_seq_len, d_model)
        # 初始化
        nn.init.normal_(self.pos_embed.weight, mean=0.0, std=0.02)

    def forward(self, seq_len, device):
        positions = torch.arange(0, seq_len, device=device)
        return self.pos_embed(positions)  # (seq_len, d_model)

# 优点：可学习，效果通常好于 Sinusoidal
# 缺点：max_seq_len 固定，无法外推
```

### 9.4 第三代：RoPE (Rotary Position Embedding) — 最重要的一节

RoPE 是目前主流模型（LLaMA, Qwen, Mistral, DeepSeek）使用的标准位置编码。它的核心思想极其优雅：**通过旋转变换将位置信息编码到 attention 的内积中**。

#### 9.4.1 核心思想：二维旋转

在二维空间中，将向量旋转角度 θ：

```
旋转矩阵 R(θ)：
  R(θ) = [cos(θ)  -sin(θ)]
         [sin(θ)   cos(θ)]

将向量 (x₁, x₂) 旋转 θ → (x₁cos(θ)-x₂sin(θ), x₁sin(θ)+x₂cos(θ))
```

这个变换有一个关键性质：
```
R(θ₁) · R(θ₂) = R(θ₁+θ₂)       — 旋转可加性
R(θ₁)^T · R(θ₂) = R(θ₂-θ₁)     — 内积只与相对角度有关
```

#### 9.4.2 扩展到高维：分组旋转

将 d 维向量拆成 d/2 组二维向量，每组用不同频率旋转：

```
┌─────────────────────────────────────────────────────────────────┐
│         RoPE 将 d 维空间分解为 d/2 个独立的二维子空间            │
│                                                                 │
│  dim 0-1:   频率 ω₀ = 1/θ₀  (高频，区分相邻位置)                │
│   ┌───┐     R(ω₀·pos)                                          │
│   │x₀ │ ────→ cos(ω₀·pos)·x₀ - sin(ω₀·pos)·x₁                  │
│   │x₁ │ ────→ sin(ω₀·pos)·x₀ + cos(ω₀·pos)·x₁                  │
│   └───┘                                                         │
│                                                                 │
│  dim 2-3:   频率 ω₁ = 1/θ₁  (较低频)                            │
│   ┌───┐     R(ω₁·pos)                                          │
│   │x₂ │ ────→ cos(ω₁·pos)·x₂ - sin(ω₁·pos)·x₃                  │
│   │x₃ │ ────→ sin(ω₁·pos)·x₂ + cos(ω₁·pos)·x₃                  │
│   └───┘                                                         │
│                                                                 │
│  ...                                                            │
│                                                                 │
│  dim d-2, d-1: 频率 ω_d/2-1 = 1/θ^(d/2-1)  (最低频，长距离)     │
│   ┌─────┐   R(ω_d/2-1·pos)                                      │
│   │x_d-2│ ────→ ...                                             │
│   │x_d-1│ ────→ ...                                             │
│   └─────┘                                                       │
└─────────────────────────────────────────────────────────────────┘

频率从高频到低频呈几何级数递减：
  ωᵢ = 1 / (base^(2i/d))   其中 base 通常取 10000
```

#### 9.4.3 数学推导：RoPE 如何编码相对位置

```
设 q_m 是位置 m 的 query 向量，k_n 是位置 n 的 key 向量。

RoPE 变换：
  qᵣ = R(m) · q    （将 q 按位置 m 旋转）
  kᵣ = R(n) · k    （将 k 按位置 n 旋转）

Attention 内积：
  qᵣ^T · kᵣ = (R(m)q)^T · (R(n)k)
           = q^T · R(m)^T · R(n) · k
           = q^T · R(n-m) · k           ← 只与相对位置 (n-m) 有关！

  因为 R(m)^T · R(n) = R(-m) · R(n) = R(n-m)  （旋转的可加性）

这意味着：attention score 自动编码了相对位置信息！
不需要额外的位置编码相加或学习。
```

#### 9.4.4 完整实现

```python
def precompute_freqs_cis(dim: int, end: int, theta: float = 10000.0):
    """
    预计算 RoPE 所需的 cos/sin 表

    输入：
      dim:   head dimension (必须是偶数)
      end:   最大序列长度
      theta: 频率基数 (LLaMA 用 10000.0)

    输出：
      freqs_cis: (end, dim//2) 的复数张量
                 用复数表示旋转：cis(θ) = cos(θ) + i·sin(θ)
    """
    # Step 1: 计算每个维度对的频率
    # freqs_i = 1 / (theta^(2i/dim)) = theta^(-2i/dim)
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2)[: (dim // 2)].float() / dim))
    # freqs: (dim//2,)

    # Step 2: 每个位置的旋转角度 = pos * freq
    t = torch.arange(end, dtype=torch.float)
    freqs = torch.outer(t, freqs)  # (end, dim//2)
    # freqs[pos, i] = pos * theta^(-2i/dim)

    # Step 3: 转为复数表示 cis(θ) = e^(iθ) = cos(θ) + i sin(θ)
    freqs_cis = torch.polar(torch.ones_like(freqs), freqs)
    # torch.polar(abs, angle) = abs * e^(i*angle)
    return freqs_cis


def apply_rotary_emb(xq, xk, freqs_cis):
    """
    将 RoPE 应用到 query 和 key

    使用复数的技巧：旋转等价于复数乘法
    (a+bi) * cis(θ) = (a·cosθ - b·sinθ) + i(a·sinθ + b·cosθ)
    这和我们之前的分组旋转一致！

    输入：
      xq: query tensor, shape (batch, seq_len, n_heads, head_dim)
      xk: key tensor,   shape (batch, seq_len, n_heads, head_dim)
      freqs_cis:        shape (seq_len, head_dim//2) 复数

    输出：
      xq_out, xk_out:   shape 同输入
    """
    # Step 1: 将最后一维 reshape 为 (..., head_dim//2, 2)
    # 然后当作复数处理
    xq_ = xq.float().reshape(*xq.shape[:-1], -1, 2)  # (..., head_dim/2, 2)
    xk_ = xk.float().reshape(*xk.shape[:-1], -1, 2)

    # Step 2: 转为复数
    # 把 (real, imag) 对转成复数 real + i*imag
    xq_complex = torch.view_as_complex(xq_)   # (..., head_dim/2)
    xk_complex = torch.view_as_complex(xk_)

    # Step 3: 广播 freqs_cis 并做复数乘法（旋转）
    # freqs_cis: (seq_len, head_dim/2)
    # 需要 reshape 以匹配 batch 和 heads 维度
    freqs_cis = freqs_cis.unsqueeze(0).unsqueeze(0)  # (1, 1, seq_len, head_dim/2)

    xq_out = torch.view_as_real(xq_complex * freqs_cis).flatten(3)
    xk_out = torch.view_as_real(xk_complex * freqs_cis).flatten(3)

    return xq_out.type_as(xq), xk_out.type_as(xk)


# ===== 不使用复数的等效实现（更直观） =====
def apply_rotary_emb_manual(xq, xk, cos, sin):
    """
    手动实现 RoPE，不依赖复数技巧

    cos: (seq_len, head_dim//2)
    sin: (seq_len, head_dim//2)
    """
    # xq: (batch, seq_len, n_heads, head_dim)
    # 将 head_dim 拆成 head_dim//2 组，每组 2 维
    xq_reshaped = xq.reshape(*xq.shape[:-1], -1, 2)  # (..., head_dim/2, 2)
    xk_reshaped = xk.reshape(*xk.shape[:-1], -1, 2)

    xq_r, xq_i = xq_reshaped[..., 0], xq_reshaped[..., 1]  # 实部和"虚部"
    xk_r, xk_i = xk_reshaped[..., 0], xk_reshaped[..., 1]

    # 广播 cos/sin
    cos = cos.unsqueeze(0).unsqueeze(0)  # (1, 1, seq_len, head_dim/2)
    sin = sin.unsqueeze(0).unsqueeze(0)

    # 旋转：(a+bi) * (cos+sin i) = (a*cos - b*sin) + i(a*sin + b*cos)
    xq_out_r = xq_r * cos - xq_i * sin
    xq_out_i = xq_r * sin + xq_i * cos
    xk_out_r = xk_r * cos - xk_i * sin
    xk_out_i = xk_r * sin + xk_i * cos

    # 恢复 shape
    xq_out = torch.stack([xq_out_r, xq_out_i], dim=-1).flatten(3)
    xk_out = torch.stack([xk_out_r, xk_out_i], dim=-1).flatten(3)

    return xq_out, xk_out
```

#### 9.4.5 频率带与长距离衰减

```
RoPE 的频率分布：

  dim 0-1 (最高频):  周期 ≈ 2π/1.0 ≈ 6 个 token
  dim 2-3:           周期 ≈ 2π/θ^(2/d)
  dim 4-5:           周期 ≈ 2π/θ^(4/d)
  ...
  dim d-2, d-1 (最低频): 周期 ≈ 2π/θ = 62832 个 token (θ=10000)


  作用：
  ┌────────────────────────────────────────────────────────────┐
  │  高频维度 (低索引):                                         │
  │  - 对相邻位置敏感，能区分 "A before B" vs "B before A"     │
  │  - 快速衰减 → 只编码局部位置信息                            │
  │                                                            │
  │  低频维度 (高索引):                                         │
  │  - 对远距离位置敏感，能区分段落级别的位置                    │
  │  - 缓慢衰减 → 编码长距离位置信息                            │
  └────────────────────────────────────────────────────────────┘

  → 模型的 attention 可以自动学习使用不同频率维度的组合
    来关注不同距离范围的 token
```

#### 9.4.6 θ (theta) 基数的选择与长上下文

```python
# LLaMA 使用 theta = 10000.0
# 不同模型可能使用不同的 theta：

# 默认 theta 的问题：长序列 (>4K) 时，RoPE 的波长不够
# 解决方案：
# 1. 增大 theta → 降低所有频率 → 波长变长 → 适合更长上下文
#    CodeLLaMA 使用 theta = 1,000,000
# 2. NTK-aware interpolation → 动态缩放 RoPE
#    YaRN (Yet another RoPE extensioN) 方法

# 不同模型的 theta：
# LLaMA / LLaMA-2:       10000
# LLaMA-3:               500000
# CodeLLaMA:             1000000
# Qwen-2:                1000000
# Mistral:               1000000 (默认), 可使用任意 theta
# DeepSeek-V2:           10000

# theta 越大 → 低频维度的波长越长 → 长距离位置区分度越好
# 但太大会降低短距离的区分度 → 需要权衡
```

#### 9.4.7 RoPE 在 Attention 中的位置

```
标准 GQA Attention 的完整流程：

  x (batch, seq, d_model)
    │
    ├──→ q_proj → Q (batch, seq, n_q_heads, head_dim)
    │              │
    │              ├── RoPE ──→ Q_rotated
    │              │
    ├──→ k_proj → K (batch, seq, n_kv_heads, head_dim)
    │              │
    │              ├── RoPE ──→ K_rotated
    │              │
    └──→ v_proj → V (不变，不需要位置编码)

    Attention:
      scores = Q_rotated @ K_rotated^T / sqrt(head_dim)
      # scores 自动编码了相对位置信息！
      # 因为 Q_rotated[m] @ K_rotated[n] = f(q_m, k_n, m-n)
```

### 9.5 ALiBi (Attention with Linear Biases)

ALiBi 是一种完全不同的方法——不做 embedding，而是直接在 attention scores 上加 bias：

```python
def alibi_bias(num_heads, seq_len):
    """
    ALiBi: 在 attention score 上加上线性递减的偏置

    偏置: bias[h, i, j] = -(i - j) * m_h
    其中 m_h 是 head 相关的斜率

    近处 token 偏置≈0，远处 token 负偏置 → 惩罚对远距离的注意力
    """
    # 预定义的斜率（几何数列）
    # 对于 8 heads: m = 2^(-8/n) 的序列
    if num_heads == 8:
        slopes = 2.0 ** (-(2 ** -(torch.arange(1, num_heads + 1) * (8.0 / num_heads))))
    # ... 其他 head 数量的斜率

    # 构建 bias 矩阵
    positions = torch.arange(seq_len)
    distance = positions.unsqueeze(0) - positions.unsqueeze(1)  # (seq, seq), j-i
    distance = distance.unsqueeze(0)  # (1, seq, seq)
    slopes = slopes.unsqueeze(1).unsqueeze(2)  # (heads, 1, 1)

    bias = distance * slopes  # (heads, seq, seq)
    return bias  # 直接加到 attention scores 上

# 优点：
# - 极简单：没有额外的 embedding 或旋转
# - 天然支持外推（训练 1024，推理 4096 也 work）
# - 计算开销 ≈ 0

# 缺点：
# - 不如 RoPE 精确（只能编码"距离"不能编码"方向"）
# - 目前较少使用，被 RoPE 替代

# 使用模型：BLOOM、MPT
```

### 9.6 YaRN (Yet another RoPE extensioN)

当需要将预训练好的短上下文模型扩展到长上下文时，需要修改 RoPE 的频率：

```python
# YaRN 通过 NTK-aware 插值修改 RoPE 的频率表

# 核心思想：
# - 高频维度（区分相邻 token）保持不变
# - 低频维度（编码远距离）按比例缩放

def yarn_freq_cis(dim, seq_len, original_max_seq_len, scale, theta=10000.0):
    """
    YaRN: 部分频率缩放

    scale: 扩展倍数 (如 4x → scale=4)
    """
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2).float() / dim))

    # NTK-aware interpolation:
    # 高频维度保持原样，低频维度按 scale 缩放
    # 使用一个平滑的过渡函数

    # 波长 = 2π / freq
    wavelength = 2 * math.pi / freqs
    original_max_wavelength = 2 * math.pi * original_max_seq_len / theta

    # 调整 theta_base
    # 使得最低频维度在扩展后的序列中仍然有足够的区分度
    new_theta = theta * (scale ** (dim / (dim - 2)))

    # ... (简化，完整实现较复杂)
    return new_freq_cis

# 使用 YaRN 的模型：Mistral-7B-128K、LLaMA-2 的长上下文 fine-tune
```

### 9.7 位置编码对比总结

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        位置编码方案对比                                   │
│                                                                         │
│  ┌─────────────┬──────────┬──────────┬──────────┬──────────┬──────────┐ │
│  │    方案      │ 可学习？  │  类型    │ 外推能力  │ 计算开销  │ 代表模型 │ │
│  ├─────────────┼──────────┼──────────┼──────────┼──────────┼──────────┤ │
│  │ Sinusoidal   │   否     │  绝对    │   一般    │    低    │原版 Trans.│ │
│  │ Learned      │   是     │  绝对    │   差     │    低    │ GPT-2    │ │
│  │ RoPE         │   否     │  相对    │  较好    │   中等   │ LLaMA全系│ │
│  │ ALiBi        │   否     │  相对    │   好     │   极低   │ BLOOM    │ │
│  │ YaRN         │   否     │  相对    │   很好   │   中等   │ Mistral  │ │
│  └─────────────┴──────────┴──────────┴──────────┴──────────┴──────────┘ │
│                                                                         │
│  当前主流（2024-2025）：RoPE + YaRN 扩展 → 几乎统治了开源 LLM            │
└──────────────────────────────────────────────────────────────────────────┘
```

**核心要点**：
- RoPE 通过旋转矩阵编码位置，内积自动包含相对位置信息
- RoPE 的数学核心：`R(m)^T · R(n) = R(n-m)`
- 频率从高到低分布：高频区分短距离，低频区分长距离
- theta (基数) 控制频率分布，增大了可以提高长上下文性能
- YaRN 是 RoPE 的长上下文扩展，通过部分频率插值实现


## 10. Multi-Head Attention：核心计算引擎

### 10.1 为什么需要 Multi-Head

单头注意力的局限：一个 query 只能关注一种模式。

```
Multi-Head 的思想：让模型同时从多个"视角"看输入

  ┌──────────────────────────────────────────────────────────────┐
  │  "The cat sat on the mat because it was tired"              │
  │                                                              │
  │  Head 0 (语法头):    关注动词和主语的关系                     │
  │    "it" ──关注──→ "cat"  (代词指代)                          │
  │                                                              │
  │  Head 1 (局部头):    关注邻居词                               │
  │    "it" ──关注──→ "was"  (相邻词)                             │
  │                                                              │
  │  Head 2 (语义头):    关注语义相关词                           │
  │    "tired" ──关注──→ "sat"  (原因-动作)                      │
  │                                                              │
  │  ... (其余 head 关注其他模式)                                 │
  └──────────────────────────────────────────────────────────────┘
```

### 10.2 标准 Multi-Head Attention 的完整数据流

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Multi-Head Self-Attention 完整流程图                      │
│                                                                             │
│  输入: x ∈ R^(B×T×D)    (Batch, Tokens, d_model)                           │
│                                                                             │
│  ┌───────────────────────────────────┐                                      │
│  │          QKV 投影 (Linear)         │                                      │
│  │  Q = x @ W_Q     (B×T×D) @ (D×D)  │  W_Q, W_K, W_V ∈ R^(D×D)           │
│  │  K = x @ W_K     → (B×T×D)       │                                      │
│  │  V = x @ W_V                       │                                      │
│  └───────────────┬───────────────────┘                                      │
│                  │                                                          │
│                  ▼                                                          │
│  ┌───────────────────────────────────┐                                      │
│  │       Split into Heads            │                                      │
│  │  Q → (B, T, H, D_h) → (B, H, T, D_h)  │  D_h = D / H (head_dim)       │
│  │  K → (B, T, H, D_h) → (B, H, T, D_h)  │                                │
│  │  V → (B, T, H, D_h) → (B, H, T, D_h)  │                                │
│  └───────────────┬───────────────────┘                                      │
│                  │                                                          │
│                  ▼                                                          │
│  ┌───────────────────────────────────┐                                      │
│  │         Apply RoPE                 │  (见第 9 节)                        │
│  │  Q ← RoPE(Q), K ← RoPE(K)        │  只旋转 Q 和 K，不旋转 V             │
│  └───────────────┬───────────────────┘                                      │
│                  │                                                          │
│                  ▼                                                          │
│  ┌───────────────────────────────────┐                                      │
│  │     Scaled Dot-Product Attention  │                                      │
│  │                                   │                                      │
│  │  scores = Q @ K^T / sqrt(D_h)     │  (B, H, T, T)                       │
│  │  scores += causal_mask            │  上三角 = -inf                       │
│  │  attn_weights = softmax(scores)   │  (B, H, T, T)                       │
│  │  output = attn_weights @ V         │  (B, H, T, D_h)                     │
│  └───────────────┬───────────────────┘                                      │
│                  │                                                          │
│                  ▼                                                          │
│  ┌───────────────────────────────────┐                                      │
│  │        Merge Heads                │                                      │
│  │  output → (B, T, H×D_h) = (B,T,D)│                                      │
│  └───────────────┬───────────────────┘                                      │
│                  │                                                          │
│                  ▼                                                          │
│  ┌───────────────────────────────────┐                                      │
│  │       Output Projection           │                                      │
│  │  output = output @ W_O            │  W_O ∈ R^(D×D)                       │
│  │  → (B, T, D)                      │                                      │
│  └───────────────────────────────────┘                                      │
│                                                                             │
│  输出: y ∈ R^(B×T×D)                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 10.3 实现代码

```python
import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, num_heads, dropout=0.0, bias=False):
        super().__init__()
        assert d_model % num_heads == 0, "d_model 必须能被 num_heads 整除"
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads

        # QKV 投影：通常合并为一个矩阵 (3*d_model, d_model) 提高效率
        self.qkv_proj = nn.Linear(d_model, 3 * d_model, bias=bias)
        # 输出投影
        self.out_proj = nn.Linear(d_model, d_model, bias=bias)

        self.attn_dropout = nn.Dropout(dropout)
        self.out_dropout = nn.Dropout(dropout)

    def forward(self, x, mask=None):
        B, T, D = x.shape

        # 1. QKV 投影 (可以分开投影或合并投影)
        qkv = self.qkv_proj(x)  # (B, T, 3*D)
        q, k, v = qkv.chunk(3, dim=-1)  # 每份 (B, T, D)

        # 2. Split into heads
        q = q.view(B, T, self.num_heads, self.head_dim).transpose(1, 2)  # (B, H, T, D_h)
        k = k.view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.num_heads, self.head_dim).transpose(1, 2)

        # 3. Scaled Dot-Product Attention
        scale = math.sqrt(self.head_dim)
        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / scale  # (B, H, T, T)

        if mask is not None:
            attn_scores = attn_scores.masked_fill(mask == 0, float('-inf'))

        attn_weights = F.softmax(attn_scores, dim=-1)
        attn_weights = self.attn_dropout(attn_weights)

        # 4. Weighted sum
        output = torch.matmul(attn_weights, v)  # (B, H, T, D_h)

        # 5. Merge heads
        output = output.transpose(1, 2).contiguous().view(B, T, D)  # (B, T, D)

        # 6. Output projection
        output = self.out_proj(output)
        return self.out_dropout(output)
```

### 10.4 Causal Mask (因果掩码)

```python
def create_causal_mask(seq_len, device):
    """
    创建因果掩码：每个 token 只能看到自己和之前的 token
    """
    mask = torch.triu(
        torch.ones(seq_len, seq_len, device=device, dtype=torch.bool),
        diagonal=1
    )  # 上三角为 True（需要 mask 掉的位置）
    return mask
    # 输出示例 (seq_len=4)：
    # [[False, True,  True,  True ],   ← token 0 只能看到自己
    #  [False, False, True,  True ],   ← token 1 能看到 0,1
    #  [False, False, False, True ],   ← token 2 能看到 0,1,2
    #  [False, False, False, False]]   ← token 3 能看到所有

# 使用
causal_mask = create_causal_mask(seq_len=T, device=x.device)
attn_scores = attn_scores.masked_fill(causal_mask, float('-inf'))
# 被 mask 的位置在 softmax 后变为 0 (因为 exp(-inf) = 0)
```

### 10.5 内存分析

```
Attention 的显存瓶颈（训练时）：

  假设: B=2, H=32, T=4096, D_h=128, dtype=FP16 (2 bytes)

  Q/K/V:  每个 (B, H, T, D_h) = 2*32*4096*128*2 = 67 MB, 3个 ≈ 200 MB
  scores: (B, H, T, T) = 2*32*4096*4096*2 = 2.1 GB  ← 主要瓶颈！
  weights:同 scores ≈ 2.1 GB
  output: (B, H, T, D_h) ≈ 67 MB

  总计约 4.5 GB，严重限制 batch size 和序列长度

  这就是为什么需要 FlashAttention！它通过分块计算避免存储完整的 score 矩阵。
```

**核心要点**：
- Q、K、V 先投影再分头，每个 head 有自己的子空间
- `head_dim = d_model / num_heads`，必须整除
- Scaled Dot-Product: `softmax(QK^T/sqrt(d_k))V`
- Causal mask 保证自回归：token i 只能注意 token [0..i]
- Attention score 矩阵 (B, H, T, T) 是训练时的显存杀手

---

## 11. GQA：分组查询注意力

### 11.1 问题：KV Cache 显存开销

自回归推理时，每生成一个新 token 需要所有历史 token 的 K 和 V。为了避免重复计算，需要缓存它们——这就是 KV Cache。

```
KV Cache size (per token):
  = 2 × num_layers × num_kv_heads × head_dim × dtype_bytes

  对于 LLaMA-2-70B (MHA, H=64, D_h=128):
  = 2 × 80 × 64 × 128 × 2 = 2.5 MB/token
  4096 token → 10 GB 仅为 KV Cache！
  这就是为什么 70B 模型很难在单卡服务。

  GQA 的解决方案：
  将 Q heads 分组，每组共享一对 K/V head
  → KV heads 数量从 H 减少到 G
  → KV Cache 减少 H/G 倍
```

### 11.2 GQA 结构

```
GQA：H 个 Query heads 共享 G 组 Key-Value heads

  MHA (H=8, G=8):                 GQA (H=8, G=2):
                                  group_size = 8/2 = 4
  ┌───┬───┬───┬───┬───┬───┬───┬───┐    ┌───┬───┬───┬───┬───┬───┬───┬───┐
  │Q0 │Q1 │Q2 │Q3 │Q4 │Q5 │Q6 │Q7 │    │Q0 │Q1 │Q2 │Q3 │Q4 │Q5 │Q6 │Q7 │
  └─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┘    └─┬─┘  │   │   │  └─┬─┘  │   │   │
    │   │   │   │   │   │   │   │         │ ┌──┴───┴───┘   │ ┌──┴───┴───┘
  ┌─▼─┬─▼─┬─▼─┬─▼─┬─▼─┬─▼─┬─▼─┬─▼─┐    ┌─▼─▼─┐           ┌─▼─▼─┐
  │K0 │K1 │K2 │K3 │K4 │K5 │K6 │K7 │    │ K0  │           │ K1  │
  └───┴───┴───┴───┴───┴───┴───┴───┘    └─────┘           └─────┘
  ┌───┬───┬───┬───┬───┬───┬───┬───┐    ┌─────┐           ┌─────┐
  │V0 │V1 │V2 │V3 │V4 │V5 │V6 │V7 │    │ V0  │           │ V1  │
  └───┴───┴───┴───┴───┴───┴───┴───┘    └─────┘           └─────┘

  Attention:                         Attention:
  Q0 @ K0^T → score_0              Q0...Q3 @ K0^T → scores[0:4]
  Q1 @ K1^T → score_1              Q4...Q7 @ K1^T → scores[4:8]
  ...                              每个 group 内共享 K,V
  Q7 @ K7^T → score_7

  KV Cache: H head pairs          KV Cache: G head pairs
  → 最大                        → 减少到 G/H
```

### 11.3 显存公式

```
KV Cache per token (bytes):
  = 2 × num_layers × num_kv_heads × head_dim × dtype_bytes

  三种注意力方案的对比（以常见配置为例）：

  ┌───────────────────┬──────────┬────────┬───────────┬─────────────┐
  │ 模型               │ num_q_heads│ num_kv_heads│ head_dim │ KV Cache/token│
  ├───────────────────┼──────────┼────────┼───────────┼─────────────┤
  │ LLaMA-2-7B (MHA)  │    32     │   32    │    128    │   0.5 MB     │
  │ LLaMA-2-70B (MHA) │    64     │   64    │    128    │   2.5 MB     │
  │ LLaMA-3-8B (GQA)  │    32     │    8    │    128    │   0.13 MB    │
  │ LLaMA-3-70B (GQA) │    64     │    8    │    128    │   0.63 MB    │
  │ Qwen-2-7B (GQA)   │    28     │    4    │    128    │   0.07 MB    │
  │ Qwen-2-72B (GQA)  │    64     │    8    │    128    │   0.63 MB    │
  │ DeepSeek-V2 (MLA) │   128     │    1*   │    512    │   ~0.02 MB   │
  └───────────────────┴──────────┴────────┴───────────┴─────────────┘

  * DeepSeek-V2 的 MLA 不是传统的 GQA，见第 13 节

  关键洞察：
  - KV Cache ∝ num_kv_heads，不 ∝ num_q_heads
  - GQA 将 KV heads 从 64 减少到 8 → ~8× 减少
  - 模型越大，GQA 收益越大（因为通常 num_heads 更多）
```

### 11.4 GQA 实现

```python
class GroupedQueryAttention(nn.Module):
    """GQA 实现：H 个 Q heads 共享 G 个 KV heads"""
    def __init__(self, d_model, num_q_heads, num_kv_heads, dropout=0.0):
        super().__init__()
        assert num_q_heads % num_kv_heads == 0, "Q heads 必须是 KV heads 的整数倍"
        self.d_model = d_model
        self.num_q_heads = num_q_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = d_model // num_q_heads
        self.group_size = num_q_heads // num_kv_heads  # 每组几个 Q head

        # Q 投影：完整大小
        self.q_proj = nn.Linear(d_model, num_q_heads * self.head_dim, bias=False)
        # KV 投影：只有 num_kv_heads 个 head
        self.k_proj = nn.Linear(d_model, num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(d_model, num_kv_heads * self.head_dim, bias=False)
        # 输出投影
        self.o_proj = nn.Linear(d_model, d_model, bias=False)

    def forward(self, x, mask=None):
        B, T, D = x.shape

        # Q: (B, T, num_q_heads * head_dim)
        q = self.q_proj(x).view(B, T, self.num_q_heads, self.head_dim).transpose(1, 2)
        # K: (B, T, num_kv_heads * head_dim)
        k = self.k_proj(x).view(B, T, self.num_kv_heads, self.head_dim).transpose(1, 2)
        # V: (B, T, num_kv_heads * head_dim)
        v = self.v_proj(x).view(B, T, self.num_kv_heads, self.head_dim).transpose(1, 2)

        # 将 KV heads 扩展以匹配 Q heads
        # 方法 1：repeat KV heads
        # k = k.unsqueeze(2).expand(-1, -1, self.group_size, -1, -1)
        # k = k.reshape(B, self.num_q_heads, T, self.head_dim)
        # 方法 2：在 attention 计算中使用广播（更高效）

        # 这里使用方法 2：在 einsum 中广播
        # 需要 reshape Q: (B, num_kv_heads, group_size, T, head_dim)
        q = q.reshape(B, self.num_kv_heads, self.group_size, T, self.head_dim)

        # k: (B, num_kv_heads, 1, T, head_dim)
        k = k.unsqueeze(2)
        # v: (B, num_kv_heads, 1, T, head_dim)
        v = v.unsqueeze(2)

        # Attention (利用广播)
        scale = math.sqrt(self.head_dim)
        attn_scores = torch.einsum('bghtd,bghsd->bghts', q, k) / scale  # (B, G, group, T, T)

        if mask is not None:
            attn_scores = attn_scores.masked_fill(mask == 0, float('-inf'))

        attn_weights = F.softmax(attn_scores, dim=-1)
        output = torch.einsum('bghts,bghsd->bghtd', attn_weights, v)  # (B, G, group, T, D_h)

        # 恢复原始 shape
        output = output.reshape(B, self.num_q_heads, T, self.head_dim)
        output = output.transpose(1, 2).contiguous().view(B, T, D)

        return self.o_proj(output)
```

### 11.5 GQA 为什么有效

```
GQA 保留性能的原因：

1. Attention 中 Q 和 K 的信息是不对称的：
   - Q (Query): 决定"我要找什么"
   - K (Key):   决定"我提供什么"
   - 多个 Q head 可以共享同一组 K/V head 而性能损失很小

2. 实验证据（来自 GQA 论文）：
   ┌─────────────────┬──────────┬──────────┐
   │  配置            │ 参数量    │ MMLU    │
   ├─────────────────┼──────────┼──────────┤
   │ MHA (H=H=8)    │  基准     │  基准    │
   │ GQA (H=8,G=4)  │  略少     │  几乎相同 │
   │ GQA (H=8,G=2)  │  更少     │  轻微下降 │
   │ MQA (G=1)      │  最少     │  最差    │
   └─────────────────┴──────────┴──────────┘

3. 实用建议：
   - G = H/4 或 H/8 是最常见的折中选择
   - LLaMA-3-70B: H=64, G=8 → group_size=8
   - Qwen-2-7B:   H=28, G=4 → group_size=7
```

**核心要点**：
- GQA 的核心：多个 Q head 共享同一对 K/V head
- KV Cache 大小 ∝ G (num_kv_heads)，不 ∝ H (num_q_heads)
- 将 G 从 H 减少到 H/4∼H/8 可大幅降低推理显存
- 性能损失很小（<1%），显存节省巨大（4-8x）
- 几乎所有 2024+ 的开源大模型都使用 GQA

---

## 12. MQA：极端情况 G=1

### 12.1 概念

MQA (Multi-Query Attention) 是 GQA 的极端特例：所有 Q heads 共享同一对 K/V head。

```
MQA (H=8, G=1):

  ┌───┬───┬───┬───┬───┬───┬───┬───┐
  │Q0 │Q1 │Q2 │Q3 │Q4 │Q5 │Q6 │Q7 │  ← 8 个不同的 Query
  └─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┴─┬─┘
    │   │   │   │   │   │   │   │
    └───┴───┴───┴─┬─┴───┴───┴───┘
               ┌──▼──┐
               │  K  │  ← 只有一个 Key 向量
               └─────┘
               ┌─────┐
               │  V  │  ← 只有一个 Value 向量
               └─────┘

  KV Cache: 只有一个 head pair → 最小可能的 KV Cache
  但注意力多样性最差 → 模型能力下降
```

### 12.2 显存收益与能力损失

```
KV Cache 对比（LLaMA-2-70B 规模）：

  MHA (H=64,G=64):  2.5 MB/token × 4096 = 10.2 GB    (基准)
  GQA (H=64,G=8):   0.31 MB/token × 4096 = 1.3 GB    (8×减少)
  MQA (H=64,G=1):   0.04 MB/token × 4096 = 0.16 GB   (64×减少！)

  但 MQA 在复杂任务上的能力下降明显：
  - MMLU 下降 2-3%
  - 长文档理解下降更明显
  - 代码生成容易出错

  MQA 的代表模型：Google PaLM、Falcon (早期版本)
  目前主流已经转向 GQA，在能力和效率间取得更好的平衡
```

```python
class MultiQueryAttention(nn.Module):
    """MQA 实现：所有 Q heads 共享一对 KV head"""
    def __init__(self, d_model, num_heads, dropout=0.0):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads

        self.q_proj = nn.Linear(d_model, num_heads * self.head_dim, bias=False)
        # KV 投影：只有 1 个 head
        self.k_proj = nn.Linear(d_model, self.head_dim, bias=False)
        self.v_proj = nn.Linear(d_model, self.head_dim, bias=False)
        self.o_proj = nn.Linear(d_model, d_model, bias=False)

    def forward(self, x, mask=None):
        B, T, D = x.shape

        q = self.q_proj(x).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        # k, v: 只有一个 head，广播到所有 Q heads
        k = self.k_proj(x).unsqueeze(1)  # (B, T, 1, D_h)
        v = self.v_proj(x).unsqueeze(1)  # (B, T, 1, D_h)

        # Attention: k, v 沿 head 维度广播
        scale = math.sqrt(self.head_dim)
        attn = torch.matmul(q, k.transpose(-2, -1)) / scale  # (B, H, T, T)
        if mask is not None:
            attn = attn.masked_fill(mask == 0, float('-inf'))
        attn = F.softmax(attn, dim=-1)
        output = torch.matmul(attn, v)  # (B, H, T, D_h)
        output = output.transpose(1, 2).contiguous().view(B, T, D)
        return self.o_proj(output)
```

**核心要点**：
- MQA = GQA 的特例，G=1
- KV Cache 最小，但模型能力受损最大
- 目前几乎被 GQA 取代


## 13. MLA：DeepSeek 的低秩 KV 压缩

### 13.1 问题再审视

GQA 将 KV Cache 减少了 H/G 倍，但仍有优化空间。对于 DeepSeek-V2 (236B 总参数, 21B 激活参数)，KV Cache 仍然是瓶颈。

```
KV Cache in GQA 仍然不便宜：
  假设 G=8, head_dim=128, 80 layers, FP16:
  = 2 × 80 × 8 × 128 × 2 = 0.33 MB/token

  对于 128K 上下文（DeepSeek-V2 的特性）：
  = 0.33 MB × 128000 = 42 GB 仅 KV Cache！
  即使在 8 卡 A800 上，每卡也要 5+ GB 用于 KV Cache
```

### 13.2 MLA 的核心思想

MLA 的核心理念：**KV Cache 存储的向量是高维的(head_dim×num_kv_heads)，但信息其实存在于低维流形上。我们可以压缩后再存储，使用时再解压。**

```
MHA/GQA:                               MLA (Multi-head Latent Attention):
                                       
Q: ──→ W_Q ──→ [h1,h2,...,h_d]  (d维)   Q: ──→ W_Q ──→ [h1,...,h_d]
K: ──→ W_K ──→ [h1,h2,...,h_d]  (d维)   K: ──→ W_DK ──→ [c1,...,c_l]  (l维, l<<d)
V: ──→ W_V ──→ [h1,h2,...,h_d]  (d维)   V: ──→ W_DV ──→ [c1,...,c_l]  (l维, l<<d)
                                               │                    │
缓存 K,V: 2×d 维                         缓存 K: l 维 (latent/压缩)     │
缓存 V: l 维 (latent/压缩)
                                               │                    │
使用时: 直接使用                          使用时: ──→ W_UK ──→ K (d维解压)
                                               ──→ W_UV ──→ V (d维解压)

压缩比 = d/l，通常 8-16×
```

### 13.3 DeepSeek-V2 的具体配置

```
DeepSeek-V2 MLA 配置：
┌────────────────────────────────────────────────────────────┐
│                                                            │
│  d_model = 5120 (hidden size)                              │
│  num_heads = 128 (query heads)                             │
│  head_dim_q = 192 (per query head, 含 RoPE 部分)           │
│  head_dim_kv = 128 (per key/value head)                    │
│  kv_lora_rank = 512 (压缩后的 latent 维度)                  │
│  q_lora_rank = 1536 (Q 的 low-rank 维度)                   │
│                                                            │
│  传统 KV Cache:                                            │
│    2 × layers × num_heads × head_dim_kv                    │
│    = 2 × layers × 128 × 128                                │
│    (对于 60 层: 2 × 60 × 128 × 128 = 1.97M params 缓存)    │
│                                                            │
│  MLA KV Cache:                                             │
│    layers × kv_lora_rank  (只需存压缩后的 latent!)          │
│    = layers × 512                                          │
│    (内存减少 ~32×!)                                         │
│                                                            │
│  实际效果：                                                 │
│    128K 上下文 KV Cache: 约 ~3.2 GB (vs ~42 GB for GQA)   │
│    ~13× 实际 KV Cache 减少                                  │
└────────────────────────────────────────────────────────────┘
```

### 13.4 MLA 的数学细节

```python
# DeepSeek-V2 MLA 的简化原理代码
class MultiHeadLatentAttention(nn.Module):
    """
    MLA: 用低秩分解压缩 KV Cache

    核心公式：
      c_KV = x @ W_down_KV         # 降维：d_model → kv_lora_rank (低秩)
      K = c_KV @ W_up_K            # 升维：kv_lora_rank → num_heads×head_dim
      V = c_KV @ W_up_V            # 升维：kv_lora_rank → num_heads×head_dim

    推理时只缓存 c_KV (低秩向量)，使用时再投影回 K、V

    此外 Q 也使用类似的 low-rank 分解：
      c_Q = x @ W_down_Q           # d_model → q_lora_rank
      Q = c_Q @ W_up_Q             # q_lora_rank → num_heads×head_dim
    """
    def __init__(self, d_model=5120, num_heads=128, kv_lora_rank=512, q_lora_rank=1536):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.kv_lora_rank = kv_lora_rank  # K,V 的压缩维度
        self.q_lora_rank = q_lora_rank    # Q 的压缩维度
        self.head_dim = 192               # 含 RoPE 部分

        # ===== KV 的 Low-Rank 分解 =====
        # 压缩：d_model → kv_lora_rank
        self.kv_a_proj_with_mqa = nn.Linear(d_model, kv_lora_rank, bias=False)
        # 解压：kv_lora_rank → num_heads * head_dim
        self.kv_a_layernorm = nn.LayerNorm(kv_lora_rank)
        self.k_b_proj = nn.Linear(kv_lora_rank, num_heads * self.head_dim, bias=False)
        self.v_b_proj = nn.Linear(kv_lora_rank, num_heads * self.head_dim, bias=False)

        # ===== Q 的 Low-Rank 分解 =====
        # 压缩：d_model → q_lora_rank
        self.q_a_proj = nn.Linear(d_model, q_lora_rank, bias=False)
        self.q_a_layernorm = nn.LayerNorm(q_lora_rank)
        # 解压：q_lora_rank → num_heads * head_dim
        self.q_b_proj = nn.Linear(q_lora_rank, num_heads * self.head_dim, bias=False)

        # 输出投影
        self.o_proj = nn.Linear(num_heads * self.head_dim, d_model, bias=False)

    def forward(self, x):
        B, T, D = x.shape

        # ===== KV 路径：压缩 → 缓存 → 解压 =====
        # Step 1: 压缩到低秩空间
        c_kv = self.kv_a_proj_with_mqa(x)  # (B, T, kv_lora_rank=512)
        c_kv = self.kv_a_layernorm(c_kv)

        # Step 2: 从低秩空间解压出 K 和 V
        k = self.k_b_proj(c_kv)  # (B, T, num_heads * head_dim)
        v = self.v_b_proj(c_kv)  # (B, T, num_heads * head_dim)

        # ===== Q 路径：压缩 → 解压 =====
        c_q = self.q_a_proj(x)  # (B, T, q_lora_rank=1536)
        c_q = self.q_a_layernorm(c_q)
        q = self.q_b_proj(c_q)  # (B, T, num_heads * head_dim)

        # reshape for multi-head
        q = q.view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.num_heads, self.head_dim).transpose(1, 2)

        # Attention (标准流程)
        scale = self.head_dim ** 0.5
        attn = torch.matmul(q, k.transpose(-2, -1)) / scale
        attn = F.softmax(attn, dim=-1)
        out = torch.matmul(attn, v)
        out = out.transpose(1, 2).contiguous().view(B, T, -1)

        return self.o_proj(out)

    # 推理时的 KV Cache 用 c_kv 而不是 k
    # c_kv 只有 kv_lora_rank 维，远小于 k 的 num_heads × head_dim 维
```

### 13.5 MLA vs GQA 的 KV Cache 数学

```
假设 d_model=5120, num_heads=128, head_dim=128, kv_lora_rank=512:

方案 A (GQA, G=8):
  K 维度 per token: 8 × 128 = 1024
  V 维度 per token: 8 × 128 = 1024
  KV Cache per token: 2048 floats
  per layer KV Cache (FP16): 2048 × 2 = 4096 bytes = 4 KB

方案 B (MLA):
  c_KV 维度 per token: 512 (latent)
  KV Cache per token: 512 floats
  per layer KV Cache (FP16): 512 × 2 = 1024 bytes = 1 KB

  MLA 比 GQA 减少: 2048/512 = 4× (在不考虑其他因素的情况下)
  实际 DeepSeek-V2 因为还有 RoPE 的额外维度，压缩比约 ~10×

  更重要的是：MLA 的压缩与 head 数量几乎无关
  即使 num_heads 从 128 增加到 256，KV Cache 仍然只存 512 维
  → 你可以增加 head 数量而几乎不增加 KV Cache！
```

### 13.6 MLA 的关键洞察

```
MLA 为什么有效：

1. 信息冗余性：K 和 V 矩阵的行之间高度相关
   → 低秩分解损失很小

2. 共享压缩：K 和 V 共享同一个压缩投影 (kv_a_proj_with_mqa)
   → 进一步减少参数量

3. 正交设计：压缩维度(lora_rank)和 head 数量解耦
   → 可以独立增加 head 数量以增加模型容量，而不增加 KV Cache

4. 训练和推理一致：训练时就使用 low-rank 结构
   → 不需要训练后压缩，没有精度损失
```

**核心要点**：
- MLA 用低秩分解将 KV Cache 从 O(num_heads × head_dim) 压缩到 O(kv_lora_rank)
- 压缩比通常 8-16×，实际有效 ~10×
- 推理时只缓存低秩 latent 向量，使用时再投影回完整维度
- 使 128K+ 长上下文推理在合理的显存内成为可能
- DeepSeek-V2/V3 的核心创新之一

---

## 14. FFN：从标准 MLP 到 SwiGLU

### 14.1 标准 FFN

```python
class StandardFFN(nn.Module):
    """标准 Transformer FFN：两个线性层 + 激活函数"""
    def __init__(self, d_model, d_ff, dropout=0.1):
        super().__init__()
        # d_ff 通常是 d_model 的 4 倍
        self.fc1 = nn.Linear(d_model, d_ff)      # 扩展
        self.fc2 = nn.Linear(d_ff, d_model)       # 压缩回原始维度
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.GELU()  # 或 ReLU

    def forward(self, x):
        # x: (batch, seq, d_model) → (batch, seq, d_ff) → (batch, seq, d_model)
        return self.dropout(self.fc2(self.activation(self.fc1(x))))

# 计算量：
# fc1: B×T × d_model × d_ff × 2 (乘加)
# fc2: B×T × d_ff × d_model × 2
# 总计: B×T × 2 × d_model × d_ff × 2 = B×T × 4 × d_model × d_ff
# 对于 d_ff=4×d_model: B×T × 16 × d_model²
```

### 14.2 SwiGLU：门控 FFN

SwiGLU 是现代 LLM (LLaMA, Qwen, DeepSeek) 的标准选择，用一个门控机制替代简单的激活函数：

```python
class SwiGLUFFN(nn.Module):
    """
    SwiGLU (Swish-Gated Linear Unit):
    output = (x @ W_gate ⊙ SiLU(x @ W_up)) @ W_down

    相当于：门控信号 × 激活后的信息流
    """
    def __init__(self, d_model, d_ff, dropout=0.0):
        super().__init__()
        self.gate_proj = nn.Linear(d_model, d_ff, bias=False)   # 门控投影
        self.up_proj = nn.Linear(d_model, d_ff, bias=False)     # 上投影
        self.down_proj = nn.Linear(d_ff, d_model, bias=False)   # 下投影
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # Gate: 决定哪些信息通过
        gate = self.gate_proj(x)              # (B, T, d_ff)
        # Up: 信息本身
        up = self.up_proj(x)                  # (B, T, d_ff)
        # SiLU 激活 + 门控
        hidden = F.silu(gate) * up            # (B, T, d_ff) 逐元素乘
        # 投影回 d_model
        return self.dropout(self.down_proj(hidden))

# SiLU (Sigmoid Linear Unit) = x · σ(x) = x · 1/(1+e^(-x))
```

### 14.3 SwiGLU vs 标准 FFN 的参数量

```
注意：SwiGLU 有三个投影矩阵，标准 FFN 只有两个

  标准 FFN (d_model → 4×d_model → d_model):
    参数 = d_model × 4×d_model + 4×d_model × d_model
         = 8 × d_model²

  SwiGLU (d_model → d_ff → d_model):
    参数 = d_model × d_ff + d_model × d_ff + d_ff × d_model
         = 3 × d_model × d_ff

  为了使参数量相当：
    设 3 × d_model × d_ff = 8 × d_model²
    → d_ff = (8/3) × d_model ≈ 2.67 × d_model

  但实际上大多数实现设置 d_ff 为可以整除的值：
  LLaMA: d_model=4096, d_ff=11008 ≈ 2.69×d_model
  LLaMA-3: d_model=4096, d_ff=14336 = 3.5×d_model
```

```python
# 常见模型的 FFN 配置
# ┌─────────────┬──────────┬────────────┬───────────┬──────────────┐
# │ 模型         │ d_model  │   d_ff     │  比率     │   FFN 类型    │
# ├─────────────┼──────────┼────────────┼───────────┼──────────────┤
# │ LLaMA-2-7B  │  4096    │   11008    │  2.69×    │  SwiGLU      │
# │ LLaMA-3-8B  │  4096    │   14336    │  3.5×     │  SwiGLU      │
# │ Qwen-2-7B   │  3584    │   18944    │  5.3×     │  SwiGLU      │
# │ DeepSeek-V2 │  5120    │   12288    │  2.4×     │  SwiGLU      │
# │ Mistral-7B  │  4096    │   14336    │  3.5×     │  SwiGLU      │
# │ GPT-2       │   768    │    3072    │  4×       │  GELU (标准)  │
# │ OPT-6.7B    │  4096    │   16384    │  4×       │  ReLU (标准)  │
# └─────────────┴──────────┴────────────┴───────────┴──────────────┘
```

**核心要点**：
- FFN 是 Transformer block 中参数量最大的部分 (~2/3)
- SwiGLU = gate_proj + up_proj + down_proj，三个权重矩阵
- SiLU 激活函数：`x * sigmoid(x)`，比 ReLU 更平滑
- 门控机制让网络选择性传递信息，类似 LSTM 的 gates
- d_ff 通常为 d_model 的 2.7~5.3 倍

---

## 15. RMSNorm vs LayerNorm

### 15.1 LayerNorm 回顾

```python
# LayerNorm: 对每个样本的特征维度做归一化
# 对于输入 x ∈ R^(B, T, D)，沿 dim=D 计算均值和方差

def layer_norm(x, eps=1e-5):
    """
    x: (..., D) — 沿最后一个维度做归一化
    """
    mean = x.mean(dim=-1, keepdim=True)        # (..., 1)
    var = x.var(dim=-1, unbiased=False, keepdim=True)  # (..., 1)
    x_norm = (x - mean) / torch.sqrt(var + eps)
    return x_norm  # 通常还有可学习的 scale 和 bias

# 计算：
# mean = (1/D) Σ x_i
# var = (1/D) Σ (x_i - mean)²
# 两步遍历数据：先求 mean，再求 var
```

### 15.2 RMSNorm

RMSNorm 只使用 Root Mean Square，不计算均值：

```python
def rms_norm(x, eps=1e-6):
    """
    x: (..., D)
    RMSNorm: x / RMS(x) 其中 RMS(x) = sqrt(mean(x²))
    """
    rms = torch.sqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + eps)
    return x / rms

# 与 LayerNorm 的比较：
# LayerNorm: (x - mean) / std
# RMSNorm:    x / rms
# 少了一次减均值的操作！
```

### 15.3 为什么 RMSNorm 更快

```
LayerNorm 的计算：
  1. 计算 mean:    遍历所有元素求和
  2. 计算 var:     再遍历一次（需要 mean）
  3. 归一化:        第三次遍历（减去 mean，除以 std）
  共 3 次遍历

RMSNorm 的计算：
  1. 计算 rms:     遍历所有元素算 x² 的 mean
  2. 归一化:        第二次遍历（除以 rms）
  共 2 次遍历

  → ~33% 的加速

另外：减均值 (centering) 的操作在实验中被证明不是必需的
      去除它不仅更快，还略好于 LayerNorm（在某些任务上）
```

### 15.4 完整实现对比

```python
import torch
import torch.nn as nn

class LayerNorm(nn.Module):
    def __init__(self, normalized_shape, eps=1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))   # 可学习 scale
        self.bias = nn.Parameter(torch.zeros(normalized_shape))    # 可学习 bias
        self.eps = eps

    def forward(self, x):
        # 使用 PyTorch 的内置实现（CUDA fused kernel）
        return F.layer_norm(x, self.weight.shape, self.weight, self.bias, self.eps)


class RMSNorm(nn.Module):
    def __init__(self, normalized_shape, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))  # 只有 scale
        # 注意：没有 bias！减均值的操作也没有了
        self.eps = eps

    def forward(self, x):
        # 使用 PyTorch 的 RMSNorm（如果版本支持）或手动计算
        # 手动实现：
        input_dtype = x.dtype
        x = x.to(torch.float32)  # 在更高精度下计算以提高数值稳定性
        variance = x.pow(2).mean(-1, keepdim=True)
        x = x * torch.rsqrt(variance + self.eps)
        return (self.weight * x).to(input_dtype)


# LLaMA 中的实际用法（来自 LLaMA 源码的简化）
class LLaMARMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def _norm(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)

    def forward(self, x):
        output = self._norm(x.float()).type_as(x)
        return output * self.weight
```

### 15.5 哪些模型用 RMSNorm

```
使用 RMSNorm 的模型（几乎所有 2023+ 的 LLM）：
  - LLaMA / LLaMA-2 / LLaMA-3
  - Mistral / Mixtral
  - Qwen / Qwen-2
  - DeepSeek-V2 / DeepSeek-V3
  - Gemma
  - Phi-3

使用 LayerNorm 的模型：
  - 原始 Transformer (2017)
  - BERT
  - GPT-2 / GPT-3
  - T5

→ RMSNorm 已成为新的标准
```

**核心要点**：
- RMSNorm 去掉了减均值的操作，比 LayerNorm 快 ~33%
- 只需要学习 scale (weight)，不需要 bias
- 所有 2023+ 的主流 LLM 都使用 RMSNorm
- 实现中常在 float32 下计算以提高数值稳定性

---

## 16. Pre-LN vs Post-LN：梯度流动的博弈

### 16.1 两种放置方式

```
Post-LN (原始 Transformer):              Pre-LN (现代 LLM):
                                       ┌──────────────────────┐
┌──────────────────────┐               │       Input x         │
│       Input x         │               └──────────┬───────────┘
└──────────┬───────────┘                          │
           │                                      ▼
           ▼                              ┌───────────────┐
   ┌───────────────┐                      │    RMSNorm    │
   │   Attention   │                      └───────┬───────┘
   └───────┬───────┘                              │
           │                                      │
     x = x + Attn(x)                              ▼
           │                              ┌───────────────┐
           ▼                              │   Attention   │
   ┌───────────────┐                      └───────┬───────┘
   │   LayerNorm   │                              │
   └───────┬───────┘                        x = x + Attn(x)
           │                                      │
           ▼                                      ▼
   ┌───────────────┐                      ┌───────────────┐
   │     FFN       │                      │    RMSNorm    │
   └───────┬───────┘                      └───────┬───────┘
           │                                      │
     x = x + FFN(x)                               ▼
           │                              ┌───────────────┐
           ▼                              │     FFN       │
   ┌───────────────┐                      └───────┬───────┘
   │   LayerNorm   │                              │
   └───────┬───────┘                        x = x + FFN(x)
           │                                      │
           ▼                                      ▼
          ...                             ┌───────────────┐
                                          │   (next layer)│
                                          └───────────────┘
```

### 16.2 Pre-LN 为什么更好

```
Post-LN 的问题（原始 Transformer 的做法）：

  1. 梯度消失：归一化在最后 → 梯度需要穿过整个残差分支
     → 在深层网络中，梯度容易消失

  2. 训练不稳定：warmup 阶段 post-LN 的梯度方差很大
     → 需要仔细的学习率 warmup

  3. 容易发散：深层 post-LN 网络在训练初期容易发散


Pre-LN 的优势：

  1. 梯度流动：归一化在最前面 → 每条路径都有"干净"的梯度通道
     gradient ∝ ∂(output)/∂(input) 在 Pre-LN 中更加稳定

  2. 训练稳定：不需要复杂的学习率 warmup
     → LLaMA 使用简单的 cosine schedule，不需要特殊的 warmup

  3. 残差流畅通：x 直接通过残差连接，不受归一化扭曲

  4. 深层友好：支持更多层（80+）而不出现训练不稳定


数学直觉（简化）：

  Post-LN: x_{l+1} = LN(x_l + F(x_l))
  Pre-LN:  x_{l+1} = x_l + F(LN(x_l))

  Post-LN 中，LN 同时作用于残差和主路径 → 残差的缩放被 LN 消除
  Pre-LN 中，LN 只作用于子层的输入 → 残差保持原始缩放
```

### 16.3 实际使用

```python
# Pre-LN Transformer Block (现代版本，如 LLaMA)
class TransformerBlock(nn.Module):
    def __init__(self, d_model, num_heads, d_ff, dropout=0.0):
        super().__init__()
        # Pre-LN: 每个子层前先做 RMSNorm
        self.attn_norm = RMSNorm(d_model)
        self.attention = GroupedQueryAttention(d_model, num_heads, num_kv_heads)
        self.ffn_norm = RMSNorm(d_model)
        self.ffn = SwiGLUFFN(d_model, d_ff)

    def forward(self, x):
        # Pre-LN: 归一化→子层→残差连接
        x = x + self.attention(self.attn_norm(x))
        x = x + self.ffn(self.ffn_norm(x))
        return x

# 对比：Post-LN Transformer Block (原始版本)
class TransformerBlockPostLN(nn.Module):
    def __init__(self, d_model, num_heads, d_ff, dropout=0.0):
        super().__init__()
        self.attention = MultiHeadAttention(d_model, num_heads)
        self.attn_norm = nn.LayerNorm(d_model)
        self.ffn = StandardFFN(d_model, d_ff)
        self.ffn_norm = nn.LayerNorm(d_model)

    def forward(self, x):
        # Post-LN: 子层→残差连接→归一化
        x = self.attn_norm(x + self.attention(x))
        x = self.ffn_norm(x + self.ffn(x))
        return x
```

**核心要点**：
- Pre-LN 将归一化放在子层前面，Post-LN 放在子层后面
- Pre-LN 梯度流动更好，训练更稳定，支持更深的网络
- 几乎所有 2022+ 的大模型使用 Pre-LN
- Pre-LN 配合 RMSNorm 是现代 LLM 的标准配置

---

## 17. 残差流：信息高速公路

### 17.1 残差连接的本质

残差流 (Residual Stream) 是 Transformer 的核心设计模式，让信息能够绕过变换直接传递。

```
Transformer 的残差流模型：

  Layer 0:  x₁ = x₀ + Attn₀(LN(x₀)) + FFN₀(LN(x₁_mid))
  Layer 1:  x₂ = x₁ + Attn₁(LN(x₁)) + FFN₁(LN(x₂_mid))
  ...
  Layer L:  x_L = x_{L-1} + Attn_{L-1}(LN(...)) + FFN_{L-1}(LN(...))

  每一层的输出 = 输入 + 增量更新

  ┌──────────────────────────────────────────────────────────────┐
  │  输入 Embedding                                               │
  │      │                                                        │
  │      ├──── Resid 0 ────┬──── Resid 1 ────┬──── ... ────→ LM Head
  │      │       │         │       │         │                    │
  │      │    ┌──▼──┐      │    ┌──▼──┐      │                    │
  │      │    │Attn │      │    │Attn │      │                    │
  │      │    │  0  │      │    │  1  │      │                    │
  │      │    └──┬──┘      │    └──┬──┘      │                    │
  │      │       │         │       │         │                    │
  │      ├── + ──┘         ├── + ──┘         │                    │
  │      │       │         │       │         │                    │
  │      │    ┌──▼──┐      │    ┌──▼──┐      │                    │
  │      │    │FFN  │      │    │FFN  │      │                    │
  │      │    │  0  │      │    │  1  │      │                    │
  │      │    └──┬──┘      │    └──┬──┘      │                    │
  │      │       │         │       │         │                    │
  │      └── + ──┘         └── + ──┘         │                    │
  │                │                  │                            │
  │                ▼                  ▼                            │
  └────────────────────────────────────────────────────────────────┘

  残差流 = 所有之前层的信息累积
  x_L = x_0 + Σ_{l=0}^{L-1} [Attn_l(LN(x_l)) + FFN_l(LN(x_l_mid))]
```

### 17.2 为什么残差流是"信息高速公路"

```
1. 梯度可以直接传播：
   ∂x_L/∂x_0 = I + Σ 雅可比矩阵的乘积
   即使后面的层梯度为 0，identity 路径仍然保证梯度 ≥ 1

2. 信息不被压缩：
   x 的维度 (d_model) 始终保持不变
   所有子层都输出相同维度的增量

3. 早期层的信息可以直接被后期层访问：
   如果 Layer 0 提取了重要特征
   Layer 40 可以直接读取（通过 identity 路径）

4. 训练信号可以直接传递：
   loss 的梯度可以直接流过 identity 回到早期层
   = 训练深层网络成为可能
```

### 17.3 残差流的实践意义

```python
# 1. 残差流可以"读出"和"写入"
#    (来自 Anthropic 的 Transformer Circuits 研究)

# "写入"残差流：
#   每个 attention head 和 FFN 神经元都向残差流写入增量
x_new = x_old + attention_output + ffn_output

# "读出"残差流：
#   后续层的 attention 和 FFN 从残差流读取信息
attention_output = softmax(Q(x) @ K(x)^T) @ V(x)
#   这里的 x 包含了所有之前层的累积信息

# 2. 在推理中，残差流允许 speculative decoding
#   因为你可以从中间层的残差流直接"读取"预测信息

# 3. LayerNorm/Pre-LN 的位置影响残差流的大小
#   在 Pre-LN 中：
#     x = x + F(LN(x))
#   残差流的大小随深度增长（因为 F 的输出不受限制）
#   → 需要最终的 LayerNorm (如 LLaMA 的 model.norm)
#   来在输出前做归一化
```

**核心要点**：
- 残差流 = 跨层 identity 连接 + 各层的增量更新
- 让梯度能够直接传播，支持深层网络训练
- 信息维度始终保持 d_model，不压缩
- 每层"读取"残差流，又"写入"新的增量
- 最终输出前的 LayerNorm 对残差流做最后的归一化
