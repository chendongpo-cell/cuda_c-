# CUDA 编程深度指南：从 GPU 架构到 AI Infra 生产级内核开发

> **目标读者**: AI Infra 工程师、推理/训练框架开发者、GPU 性能优化工程师
> **前置知识**: C/C++ 基础、基本的并行计算概念
> **学习建议**: 边读边写代码，每学完一个概念就动手验证。不要只读文档。

---

## 白话引入

想象你管理一座巨型工厂，需要在一小时内加工完成 100 万件产品。如果只有一条流水线，一个一个来，根本不可能完成。于是你把工厂设计成：108 个**并行车间**（SM），每个车间里有几十组工人（Warp），每组 32 人（Thread）同步作业。每组的工人都穿着同样的"工服"（共享同一个程序计数器），在同一时刻执行相同的动作，只是每个人手里拿的零件不同。

工厂的中心仓库（Global Memory / HBM）存放着所有原材料和成品，空间大（80GB）但离车间远，取一趟要花相当于在车间内操作 200 倍的时间。所以聪明的做法是：提前用小推车（Shared Memory）把当天要用的原材料从中心仓库拉到车间边的临时存放点（164KB per SM），甚至可以贴身放在每个工人的操作台上（Register），随用随取，零等待。

CUDA 编程就是写一份"工单"，告诉每个车间、每组工人、每个人在什么时间做什么事、从哪取材料、把成品放哪。写得好，工厂满负荷运转（接近 312 TFLOPS）；写得不好，大部分工人在喝茶等材料，效率不到峰值的 1%。本文就是从认识工厂图纸到写出这家工厂有史以来最高效的工单。

### 术语预检

| 术语 | 一句话类比 | 专业释义 |
|------|-----------|---------|
| SM (Streaming Multiprocessor) | 像工厂里的独立车间，有自己的设备、缓存和工人队伍 | GPU 的基本计算单元，A800 有 108 个 SM。每个 SM 包含 CUDA Cores、Tensor Cores、L1 Cache、Shared Memory 和寄存器文件。SM 之间通过 L2 Cache 和 HBM 间接通信 |
| Warp | 像一组 32 人的同步作业小队，所有人同时做同一个动作 | GPU 调度的最小单位，由 32 个线程组成。同一 Warp 内的线程以 SIMT（单指令多线程）方式锁步执行，共享同一个程序计数器。Warp Scheduler 在每个时钟周期从就绪 Warp 中选择一个发射指令 |
| Shared Memory (SMEM) | 像车间边的小推车/临时存放点，block 内所有线程共享 | 每个 SM 上的片上 SRAM，A800 最高 164 KB。比 HBM 快 ~20 倍（~30 cycles vs ~700 cycles），由 `__shared__` 关键字声明，是 tiling 优化的核心存储介质 |
| Tensor Core | 像一台专用冲压机床，一压就能同时完成一整块板上的所有运算 | NVIDIA 从 Volta 架构引入的专用矩阵乘加硬件单元，单周期完成 D=A×B+C 操作。FP16 下每个指令处理 16×16×8 的三维矩阵乘法（2048 FMA），提供 8x（FP32）到 16x 的加速 |
| Occupancy (占用率) | 像车间里同时忙碌的工人小队数量——越多越好，但不能太多，因为工具台（SMEM/寄存器）有限 | Active Warps per SM / Max Warps per SM。A800 每 SM 最多 64 个 Warp（2048 线程）。高 Occupancy 有助于隐藏内存延迟，但过高的寄存器/SMEM 使用会限制并发 Warp 数 |
| Roofline Model | 像工厂的"极限管理看板"——告诉你当前工艺是卡在原材料运输（memory-bound）还是加工速度（compute-bound） | GPU 性能分析模型，横轴为算术强度（FLOPS/Byte），纵轴为可达 TFLOPS。Memory-bound 区域的性能受限于 HBM 带宽，compute-bound 区域受限于计算峰值。是确定优化方向的第一工具 |

---

## 目录

1. [GPU 硬件架构](#1-gpu-硬件架构)
2. [CUDA 编程模型](#2-cuda-编程模型)
3. [Tensor Cores](#3-tensor-cores)
4. [异步执行](#4-异步执行)
5. [CUDA Graphs](#5-cuda-graphs)
6. [实战：逐步优化 GEMM 内核](#6-实战逐步优化-gemm-内核)
7. [阅读 vLLM 内核](#7-阅读-vllm-内核)
8. [调试与性能分析](#8-调试与性能分析)
9. [深入学习资源](#9-深入学习资源)

---

## 1. GPU 硬件架构

### 1.1 为什么理解硬件是第一步

GPU 编程的本质是**将算法映射到硬件**。不理解硬件的并行层级、内存系统和计算单元，就永远只能写出"能跑但慢"的代码。AI Infra 中每一个高性能内核（FlashAttention、PagedAttention、Fused MoE）都是硬件特性的精心利用，不是巧合。

### 1.2 SM (Streaming Multiprocessor) 内部结构

SM 是 GPU 的核心计算单元。每个 SM 是独立的微型处理器，拥有自己的指令调度器、执行单元、寄存器文件和本地存储器。

```
┌──────────────────────────────────────────────────────────────────────────┐
│                      NVIDIA A800 (GA100) 芯片架构                         │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │                    80 GB HBM2e @ 1935 GB/s                         │  │
│  │                                                                      │  │
│  │   ┌──────────────────────────────────────────────────────────────┐ │  │
│  │   │              L2 Cache: 40 MB @ ~4 TB/s (共享)                │ │  │
│  │   │                                                              │ │  │
│  │   │   ┌─────────┐  ┌─────────┐  ┌─────────┐       ┌─────────┐  │ │  │
│  │   │   │  SM 0   │  │  SM 1   │  │  SM 2   │  ...  │ SM 107  │  │ │  │
│  │   │   │         │  │         │  │         │       │         │  │ │  │
│  │   │   │  ┌────┐ │  │  ┌────┐ │  │  ┌────┐ │       │ ┌────┐  │  │ │  │
│  │   │   │  │Reg │ │  │  │Reg │ │  │  │Reg │ │       │ │Reg │  │  │ │  │
│  │   │   │  │256 │ │  │  │256 │ │  │  │256 │ │       │ │256 │  │  │ │  │
│  │   │   │  │KB  │ │  │  │KB  │ │  │  │KB  │ │       │ │KB  │  │  │ │  │
│  │   │   │  └────┘ │  │  └────┘ │  │  └────┘ │       │ └────┘  │  │ │  │
│  │   │   │  ┌────┐ │  │  ┌────┐ │  │  ┌────┐ │       │ ┌────┐  │  │ │  │
│  │   │   │  │L1+ │ │  │  │L1+ │ │  │  │L1+ │ │       │ │L1+ │  │  │ │  │
│  │   │   │  │SMEM│ │  │  │SMEM│ │  │  │SMEM│ │       │ │SMEM│  │  │ │  │
│  │   │   │  │164 │ │  │  │164 │ │  │  │164 │ │       │ │164 │  │  │ │  │
│  │   │   │  │KB  │ │  │  │KB  │ │  │  │KB  │ │       │ │KB  │  │  │ │  │
│  │   │   │  └────┘ │  │  └────┘ │  │  └────┘ │       │ └────┘  │  │ │  │
│  │   │   └─────────┘  └─────────┘  └─────────┘       └─────────┘  │ │  │
│  │   │                                                              │ │  │
│  │   │   每个 SM 包含:                                                │ │  │
│  │   │   ├── 4 个 Warp Scheduler (每周期各发射 1 条指令)               │ │  │
│  │   │   ├── 64 个 FP32 CUDA Core + 64 个 FP32/INT32 CUDA Core       │ │  │
│  │   │   ├── 4 个第 3 代 Tensor Core                                 │ │  │
│  │   │   ├── 8 个 LD/ST 单元 (加载/存储)                              │ │  │
│  │   │   ├── 4 个 SFU (特殊函数单元: sin, cos, exp, sqrt)            │ │  │
│  │   │   ├── 65536 个 32-bit 寄存器 (= 256 KB)                       │ │  │
│  │   │   └── 164 KB Shared Memory + L1 (可配置分配比)                 │ │  │
│  │   └──────────────────────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
```

### 1.3 A800 (GA100) 关键规格总览

| 硬件单元 | 数量/规格 | 备注 |
|---------|----------|------|
| Streaming Multiprocessor (SM) | 108 | 每个 SM 独立调度、独立执行 |
| CUDA Core (FP32) | 6912 | 108 SM × 64 FP32 core |
| CUDA Core (FP32/INT32 混合) | 6912 | 108 SM × 64，可与 FP32 并行执行 INT32 |
| Tensor Core (第 3 代) | 432 | 108 SM × 4 |
| HBM2e 显存 | 80 GB | ECC 保护 |
| HBM2e 带宽 | 1935 GB/s (~2 TB/s) | 5 个 HBM2e stack，5120-bit 总线 |
| L2 Cache | 40 MB | 所有 SM 共享，~4 TB/s 带宽 |
| Shared Memory / L1 (per SM) | 高达 164 KB | 可配置为 SMEM 优先 (164K+0) 或 L1 优先 |
| 寄存器文件 (per SM) | 65536 × 32-bit = 256 KB | ~8 TB/s 的片上带宽 |
| Warp Scheduler (per SM) | 4 | 每周期每个调度器可发射 1 条指令 |
| Max Threads per SM | 2048 | 即 64 个 Warp |
| Max Threads per Block | 1024 | 硬件限制 |
| Max Blocks per SM | 32 | 理论最大值 |
| NVLink 3.0 | 600 GB/s per GPU | 12 条链路，每链路 50 GB/s |
| PCIe 4.0 x16 | ~32 GB/s | 主机-设备数据传输 |

### 1.4 内存层级与带宽 (核心)

这是 GPU 编程中**最重要的图**。所有性能优化的本质都是在更快的层级上做更多的计算。

```
                         ┌────────────────────────────────────┐
   最快 / 最小            │          Register File             │
                         │     256 KB per SM, ~8 TB/s         │
                         │     零延迟访问 (0 cycle)             │
                         │     >> 每个线程最多 255 个寄存器     │
                         ├────────────────────────────────────┤
                         │       Shared Memory + L1           │
                         │     164 KB per SM, ~20 TB/s        │
                         │     ~20-30 cycles latency          │
                         │     >> Block 内线程共享             │
                         │     >> 用户显式管理 (__shared__)     │
                         ├────────────────────────────────────┤
                         │           L2 Cache                 │
                         │     40 MB (共享), ~4 TB/s          │
                         │     ~200 cycles latency            │
                         │     >> 所有 SM 共享，自动管理        │
                         ├────────────────────────────────────┤
   较慢 / 较大            │          HBM2e (Global Memory)     │
                         │     80 GB, ~2 TB/s (1935 GB/s)     │
                         │     ~600-800 cycles latency        │
                         │     >> 内核间持久化 (KV Cache 存放地) │
                         ├────────────────────────────────────┤
                         │     CPU RAM (Pinned Memory)        │
                         │     ~32 GB/s (PCIe 4.0 x16)        │
                         │     >> cudaMemcpy 的数据通路        │
   最慢 / 最大            │      NVMe SSD (GPU Direct)         │
                         │     ~7 GB/s (PCIe 4.0 x4)          │
                         │     >> Offloading / Checkpointing  │
                         └────────────────────────────────────┘

关键数字记忆:
  - Register ~8 TB/s    : SMEM ~20 TB/s   :   HBM2e ~2 TB/s   :   PCIe ~32 GB/s
  - 比例                : 10x             :   1x              :   0.016x
  - 延迟 ~0 cycles      : ~30 cycles      :   ~700 cycles     :   ~10000+ cycles
```

**AI Infra 启示**: FlashAttention 的核心创新就是利用 SRAM (Register+SMEM) 做计算，避免将中间结果写回 HBM。这是从 O(N^2) 显存降到 O(N) 的关键。

### 1.5 H800 vs A100 vs H100 简要对比

| 特性 | A800 (GA100) | A100 (GA100 满血) | H100 (GH100) | H800 (GH100 阉割) |
|------|-------------|-------------------|--------------|-------------------|
| SM 数量 | 108 | 108 | 132 | 132 |
| CUDA Core | 6912×2 | 6912×2 | 16896 (含 FP8) | 16896 |
| Tensor Core | 432 (Gen3) | 432 (Gen3) | 528 (Gen4) | 528 (Gen4) |
| HBM | 80 GB HBM2e | 80 GB HBM2e | 80 GB HBM3 | 80 GB HBM3 |
| HBM 带宽 | 1935 GB/s | 1935 GB/s | 3350 GB/s | 3350 GB/s |
| L2 Cache | 40 MB | 40 MB | 50 MB | 50 MB |
| NVLink 带宽 | 600 GB/s | 600 GB/s | 900 GB/s | 400 GB/s (限速) |
| FP16 TFLOPS | 312 | 312 | 990 | 990 |
| TF32 TFLOPS | 156 | 156 | 495 | 495 |
| FP8 TFLOPS | - | - | 1980 | 1980 |
| 关键区别 | 中国特供版 | 原始 GA100 | 新一代 Hopper | 中国特供 H100 |
| SMEM per SM | 164 KB | 164 KB | 228 KB | 228 KB |
| Max Threads/SM | 2048 | 2048 | 2048 | 2048 |

**核心差异总结**：
- **A100 → H100**: NVLink 带宽从 600→900 GB/s，SM 从 108→132，新增 FP8 支持 (2x 吞吐)，SMEM 从 164→228 KB。HBM3 替代 HBM2e，带宽从 ~2→~3.35 TB/s。
- **H100 → H800**: 主要限制在 NVLink 互连带宽 (900→400 GB/s)，影响多 GPU 通信。计算能力和单卡 HBM 带宽保持不变。
- **A100 → A800**: 基本等同于 A100，NVLink 略有降低 (600→400 GB/s)。

### 1.6 计算层级：Grid → Block → Warp → Thread

```
┌──────────────────────────────────────────────────────────────────────┐
│                           GRID (网格)                                 │
│                     整个 Kernel 的任务空间                              │
│                                                                      │
│    ┌──────────┬──────────┬──────────┬──────────────┐                │
│    │ Block(0) │ Block(1) │ Block(2) │     ...      │  ← Thread Block│
│    │   在 SM0  │   在 SM1  │   在 SM2  │              │    独立调度    │
│    └──────────┴──────────┴──────────┴──────────────┘                │
│                                                                      │
│    每个 Block 内部:                                                   │
│    ┌─────────────────────────────────────────────────┐               │
│    │  Block 分配到 1 个 SM 上执行，不可跨 SM            │               │
│    │                                                 │               │
│    │  Warp 0    Warp 1    Warp 2    ...   Warp N-1   │  ← Warp = 32  │
│    │  ┌──────┐ ┌──────┐ ┌──────┐         ┌──────┐   │    个线程     │
│    │  │T0-T31│ │T0-T31│ │T0-T31│  ...    │T0-T31│   │    锁步执行   │
│    │  └──────┘ └──────┘ └──────┘         └──────┘   │               │
│    │                                                 │               │
│    │  Warp 内的 32 个线程:                              │               │
│    │  ┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐       │               │
│    │  │T0 │T1 │T2 │T3 │...│T28│T29│T30│T31│       │  ← 同一个 PC   │
│    │  └───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘       │    同一个指令   │
│    │  同一周期执行同一条指令，但操作不同的数据             │               │
│    └─────────────────────────────────────────────────┘               │
│                                                                      │
│    关键规则:                                                         │
│    - 一个 Block 的所有 Warp 在同一个 SM 上执行                        │
│    - 一个 Warp 的 32 个线程以锁步 (lockstep) 方式执行                 │
│    - 不同 Block 之间执行顺序不确定，无法直接同步                       │
│    - SM 可以在多个 Block 的 Warp 之间零开销切换 (隐藏延迟)             │
└──────────────────────────────────────────────────────────────────────┘
```

**Warp 是 GPU 执行的基本调度单位**。每个 Warp 包含恰好 32 个线程，它们共享同一个程序计数器 (Program Counter)，在同一周期内执行同一条指令——这就是 SIMT 模型 (Single Instruction, Multiple Threads)。Warp Scheduler 在每个时钟周期从就绪的 Warp 中选择一个发射指令，这种"零开销"的 Warp 切换正是 GPU 隐藏内存延迟的核心机制。

---

## 2. CUDA 编程模型

### 2.1 Kernel 启动语法

```cpp
kernel_function<<<gridDim, blockDim, sharedMemBytes, stream>>>(args...);
```

四个启动参数：
- `gridDim`: `dim3` 类型，指定 Grid 中的 Block 数量及排列 (1D/2D/3D)
- `blockDim`: `dim3` 类型，指定每个 Block 中的线程数量及排列
- `sharedMemBytes`: `size_t`，动态分配的 Shared Memory 字节数 (可选，默认 0)
- `stream`: `cudaStream_t`，指定在哪个流中执行 (可选，默认使用 default stream)

```cpp
// 1D kernel 启动
int blockSize = 256;
int gridSize = (N + blockSize - 1) / blockSize;
myKernel<<<gridSize, blockSize>>>(d_input, d_output, N);

// 2D kernel 启动：处理 1024×768 图像
dim3 blockDim(16, 16);     // 16×16 = 256 threads per block
dim3 gridDim((W + 15) / 16, (H + 15) / 16);
imageKernel<<<gridDim, blockDim>>>(d_image, W, H);

// 3D kernel 启动：处理体积数据
dim3 blockDim(8, 8, 4);    // 256 threads
dim3 gridDim((DX + 7) / 8, (DY + 7) / 8, (DZ + 3) / 4);
volumeKernel<<<gridDim, blockDim>>>(d_volume, DX, DY, DZ);

// 带动态 Shared Memory 的启动
size_t smemSize = 2 * TILE_SIZE * TILE_SIZE * sizeof(float);
tiledKernel<<<gridDim, blockDim, smemSize, stream>>>(d_A, d_B, d_C, M, N, K);
```

### 2.2 线程索引体系

CUDA 提供了一套内建变量来唯一定位每个线程：

```
Grid (dim3 gridDim)
│
├── Block (blockIdx.x, blockIdx.y, blockIdx.z)  ← Block 在 Grid 中的索引
│   │
│   ├── Block 维度: blockDim.x, blockDim.y, blockDim.z
│   │
│   └── Thread (threadIdx.x, threadIdx.y, threadIdx.z) ← 线程在 Block 内的索引

全局线程 ID 计算公式:

  1D:  global_tid = blockIdx.x * blockDim.x + threadIdx.x

  2D:  global_x   = blockIdx.x * blockDim.x + threadIdx.x
       global_y   = blockIdx.y * blockDim.y + threadIdx.y

  3D:  global_x   = blockIdx.x * blockDim.x + threadIdx.x
       global_y   = blockIdx.y * blockDim.y + threadIdx.y
       global_z   = blockIdx.z * blockDim.z + threadIdx.z

  全局线性 ID (将多维映射到 1D):
       tid = threadIdx.x + threadIdx.y * blockDim.x +
             threadIdx.z * blockDim.x * blockDim.y

       bid = blockIdx.x + blockIdx.y * gridDim.x +
             blockIdx.z * gridDim.x * gridDim.y
```

内建变量类型：`uint3` (对于 gridDim 和 blockDim) 和 `uint3` (对于 blockIdx 和 threadIdx)。

### 2.3 第一个 Kernel：向量加法 (完整代码)

```cpp
#include <cuda_runtime.h>
#include <cstdio>

// CUDA Kernel: 每个线程计算一个元素的加法
__global__ void vectorAdd(const float* A, const float* B, float* C, int N) {
    // 计算全局线程 ID (1D)
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    // 边界检查：防止越界访问 (N 不一定是 blockDim 的整数倍)
    if (tid < N) {
        C[tid] = A[tid] + B[tid];
    }
}

// 2D Kernel 示例：矩阵转置
__global__ void matrixTranspose(const float* input, float* output,
                                 int rows, int cols) {
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    int row = blockIdx.y * blockDim.y + threadIdx.y;

    if (row < rows && col < cols) {
        // output 按列优先存储 (转置)
        output[col * rows + row] = input[row * cols + col];
    }
}

int main() {
    int N = 1 << 20;  // 1M elements
    size_t bytes = N * sizeof(float);

    // 1. 分配 Host 内存
    float *h_A = (float*)malloc(bytes);
    float *h_B = (float*)malloc(bytes);
    float *h_C = (float*)malloc(bytes);

    // 2. 初始化数据
    for (int i = 0; i < N; i++) {
        h_A[i] = rand() / (float)RAND_MAX;
        h_B[i] = rand() / (float)RAND_MAX;
    }

    // 3. 分配 Device 内存
    float *d_A, *d_B, *d_C;
    cudaMalloc(&d_A, bytes);
    cudaMalloc(&d_B, bytes);
    cudaMalloc(&d_C, bytes);

    // 4. 拷贝数据到 Device (H2D)
    cudaMemcpy(d_A, h_A, bytes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_B, h_B, bytes, cudaMemcpyHostToDevice);

    // 5. 启动 Kernel
    int threadsPerBlock = 256;
    int blocksPerGrid = (N + threadsPerBlock - 1) / threadsPerBlock;
    vectorAdd<<<blocksPerGrid, threadsPerBlock>>>(d_A, d_B, d_C, N);

    // 6. 同步 + 检查错误
    cudaError_t err = cudaDeviceSynchronize();
    if (err != cudaSuccess) {
        printf("Kernel error: %s\n", cudaGetErrorString(err));
    }

    // 7. 拷贝结果回 Host (D2H)
    cudaMemcpy(h_C, d_C, bytes, cudaMemcpyDeviceToHost);

    // 8. 验证
    for (int i = 0; i < N; i++) {
        if (fabs(h_A[i] + h_B[i] - h_C[i]) > 1e-5) {
            printf("Error at %d! Expected %f, got %f\n",
                   i, h_A[i] + h_B[i], h_C[i]);
            break;
        }
    }
    printf("Vector addition verified successfully!\n");

    // 9. 清理
    cudaFree(d_A); cudaFree(d_B); cudaFree(d_C);
    free(h_A); free(h_B); free(h_C);
    return 0;
}
```

### 2.4 内存类型全景

CUDA 有六种内存类型，它们在位置、带宽、访问模式上截然不同：

```
┌────────────────────────────────────────────────────────────────────┐
│                     CUDA 内存类型全景图                              │
│                                                                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │   Register   │  │   Shared Mem │  │   L1 Cache   │              │
│  │   每线程私有   │  │  每 Block 共享│  │  每 SM 私有   │              │
│  │   最快 (0 cyc)│  │  ~30 cycles  │  │  ~30 cycles  │              │
│  │   ~8 TB/s    │  │  ~20 TB/s    │  │  ~20 TB/s    │              │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘              │
│         │                 │                 │                       │
│         │    On-Chip (SRAM)                 │                       │
│         └─────────────────┴─────────────────┘                       │
│                           │                                         │
│                    ┌──────┴──────┐                                  │
│                    │   L2 Cache  │                                  │
│                    │  40 MB 共享  │                                  │
│                    │  ~4 TB/s    │                                  │
│                    │ ~200 cycles │                                  │
│                    └──────┬──────┘                                  │
│                           │                                         │
│         ┌─────────────────┼─────────────────┐                      │
│         │                 │                 │                       │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐                 │
│  │Global Memory│  │  Constant   │  │   Texture   │                 │
│  │ 80 GB HBM2e │  │  64 KB      │  │  (通过 L1)   │                 │
│  │ ~2 TB/s     │  │  Broadcast  │  │  2D 局部性   │                 │
│  │ ~700 cycles │  │  优化       │  │  硬件插值    │                 │
│  └─────────────┘  └─────────────┘  └─────────────┘                 │
│                                                                    │
│  ┌──────────────┐                                                   │
│  │ Local Memory │  ← 寄存器溢出时自动使用，实际存储在 Global Memory    │
│  │ (寄存器溢出)   │    完全是对性能的灾难 (与 Global Memory 一样慢)     │
│  └──────────────┘                                                   │
└────────────────────────────────────────────────────────────────────┘
```

#### Global Memory (全局内存)

- **最大** (80 GB)，**最慢** (700 cycles 延迟)
- 所有线程都可以访问，Kernel 启动期间持续存在
- **必须合并访问 (Coalesced Access)** 才能达到峰值带宽
- 在 AI Infra 中：**KV Cache 完全存储在 Global Memory 中**——这是推理延迟的主要瓶颈之一

#### Shared Memory (共享内存)

- `__shared__` 关键字声明，per-Block
- 大小有限 (A800: 最高 164 KB per SM)，需要手动管理
- 比 Global Memory 快约 20-30 倍
- 在 AI Infra 中：FlashAttention 的 tile 全部放在 SMEM 中，这是其高效率的核心

```cpp
// 静态 Shared Memory
__global__ void kernel() {
    __shared__ float smem[256];  // 编译时确定大小
    // ...
}

// 动态 Shared Memory (大小在 kernel 启动时指定)
__global__ void kernel_dynamic() {
    extern __shared__ float smem[];  // 大小由 <<<grid, block, smem_bytes>>> 指定
    // ...
}
```

#### Constant Memory (常量内存)

- 64 KB，只读，所有线程可访问
- 硬件对同一 Warp 内所有线程读取相同地址有 **广播优化** (broadcast)
- 适合存储 kernel 参数、查找表

```cpp
__constant__ float const_data[256];  // 全局声明

// Host 端拷贝
cudaMemcpyToSymbol(const_data, h_data, 256 * sizeof(float));
```

#### Texture Memory (纹理内存)

- 通过 Texture Object 访问，有专用的硬件缓存
- 2D 空间局部性优化 (相邻 2D 位置的访问会被缓存)
- 硬件插值 (线性、双线性)
- 在 AI Infra 中使用较少，主要在上采样、图像预处理中使用

#### Local Memory (本地内存)

- 这不是物理上独立的内存！它是寄存器溢出时的"备份存储"，实际存放在 Global Memory 中
- 编译器在以下情况会使用 Local Memory：
  - 寄存器不够用 (每个线程最多 255 个寄存器)
  - 数组索引不是编译时常量
  - 太大的结构体

**Local Memory 是性能杀手**。使用 `--ptxas-options=-v` 编译可以看到 lmem 使用量：

```bash
nvcc --ptxas-options=-v -o kernel kernel.cu
# 输出示例: 0 bytes stack frame, 0 bytes spill stores, 0 bytes spill loads
#           → 完美的零 Local Memory 使用
```

### 2.5 合并访问 (Coalesced Access)

这是**最容易被忽视但最重要的** Global Memory 访问优化。

GPU 的内存系统以 **事务 (transaction)** 为单位读取 Global Memory：
- L2 Cache Line: 32 bytes (1 sector)
- 一次内存事务读取: 32、64 或 128 字节

**合并访问 (Coalesced Access) 是指一个 Warp 的 32 个线程访问的地址落在尽可能少的内存事务中。**

```
合并访问 vs 非合并访问示意图:

  合并访问 (stride-1, 连续):
      线程: T0  T1  T2  T3  T4  T5  ...  T31
      地址: A0  A1  A2  A3  A4  A5  ...  A31
             └─── 1 个 128-byte 事务 ───┘
      利用率: 100% (128 bytes loaded / 128 bytes used)

  非合并访问 (stride-2, 跳跃):
      线程: T0  T1  T2  T3  ...
      地址: A0  A2  A4  A6  ...
             └─ 事务0 ─┘└─ 事务1 ─┘  ...
      利用率: 50% (加载了 2 倍所需数据)

  随机访问 (最坏情况):
      线程: T0   T1   T2   T3   ...
      地址: A0  A100 A50  A200  ...
      需要 32 个独立的 32-byte 事务！
      利用率: ~3% (128 bytes × 32 loaded / 128 bytes used)
      性能退化: 30x+

  列优先访问矩阵 (stride-N):
      线程: T0     T1     T2     ...
      地址: A0     A1024  A2048  ...
            A0+0   A0+N   A0+2N
      需要 32 个事务，每个只用了 4 bytes out of 32
      利用率: 12.5%
```

**代码对比**：

```cpp
// 好的访问模式: 线程访问连续地址 (合并访问)
__global__ void good_access(float* data, int N) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < N) {
        data[tid] = data[tid] * 2.0f;  // T0→data[0], T1→data[1], ...
    }
}

// 坏的访问模式: 线程跳跃访问
__global__ void bad_access(float* data, int N, int stride) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid * stride < N) {
        data[tid * stride] = data[tid * stride] * 2.0f;
        // T0→data[0], T1→data[stride], T2→data[2*stride], ...
    }
}
```

**AI Infra 实践**：
- KV Cache 存储格式需要精心设计，确保在 Attention 计算中访问是合并的
- PagedAttention 中的 Block 化存取会打破完美的合并模式——这是灵活性换性能的 trade-off
- 在自定义 Kernel 设计数据布局时，"让连续线程访问连续地址"应是一条铁律

### 2.6 Bank Conflict (Bank 冲突)

Shared Memory 被组织成 32 个 Bank，每个 Bank 宽度为 4 字节 (32-bit)。每个时钟周期，每个 Bank 可以服务一个地址。如果同一 Warp 内的多个线程访问同一个 Bank 的不同地址，就会发生 Bank Conflict——这些访问会被串行化。

```
Shared Memory Bank 结构:

  Bank:  0    1    2    3   ...  30   31
       ┌────┬────┬────┬────┬────┬────┬────┐
  Row0 │ 0  │ 1  │ 2  │ 3  │... │ 30 │ 31 │  ← 地址 0-31  (每地址 4B)
  Row1 │ 32 │ 33 │ 34 │ 35 │... │ 62 │ 63 │  ← 地址 32-63
  Row2 │ 64 │ 65 │ 66 │ 67 │... │ 94 │ 95 │
  Row3 │ 96 │ 97 │ 98 │ 99 │... │126 │127 │
  ...  │ .. │ .. │ .. │ .. │... │ .. │ .. │
       └────┴────┴────┴────┴────┴────┴────┘
       address % 32 决定属于哪个 Bank

  无冲突 (最优):
    所有线程访问不同 Bank
    T0→Bank0, T1→Bank1, ..., T31→Bank31
    1 个周期完成 ✓

  2-way Bank Conflict:
    两个线程访问同一 Bank 的不同地址
    T0→Bank0(addr=0),  T16→Bank0(addr=128)
    2 个周期完成 (串行化)

  32-way Bank Conflict (最坏):
    所有 32 个线程访问同一 Bank 的不同地址
    32 个周期完成 → 32x 减速!!

  广播 (特殊——无冲突):
    所有线程访问相同地址 (同一 Bank 同一地址)
    硬件自动广播，1 个周期完成 ✓
```

**常见的 Bank Conflict 场景与解决方案**：

```cpp
// ==========================================
// 场景 1: stride-32 导致 32-way Bank Conflict
// ==========================================
__shared__ float smem[32][32];

// 坏: 列访问 —— 同一列的 32 个元素都在同一个 Bank!
float val = smem[threadIdx.x][0];  // T0→Bank0, T1→Bank0, ...
// 解决: 访问前转置，或者在声明时加 Padding

// ==========================================
// 场景 2: stride-1 连续访问 —— 无冲突
// ==========================================
float val = smem[threadIdx.x][threadIdx.x];  // T0→Bank0, T1→Bank1, ...

// ==========================================
// 场景 3: stride by odd number —— 无冲突
// ==========================================
// stride-3 访问: T0→0, T1→3, T2→6, T3→9, ...
// 32 和 3 互质 → 不会回到同一 Bank 直到 32 步后
float val = smem[(threadIdx.x * 3) % 32][0];

// ==========================================
// 经典解决方案: Padding
// ==========================================
#define TILE_SIZE 32

// 坏: 无 Padding
__shared__ float As_bad[TILE_SIZE][TILE_SIZE];
// 从 As_bad 按列读取 (如转置访问) 触发 Bank Conflict

// 好: 加 Padding
__shared__ float As_good[TILE_SIZE][TILE_SIZE + 1];  // +1
// 现在 As_good[i][j] 和 As_good[i+1][j] 不在同一个 Bank 了!
// 因为一行的大小从 32×4=128B 变成了 33×4=132B (≠32B 的倍数)
```

**Bank Conflict 的实质**：`(地址/4) % 32` 决定 Bank 编号。如果两个地址的这个值相同但地址不同，就冲突。

### 2.7 Warp 级原语 (Warp-Level Primitives)

Warp 级原语允许 Warp 内的 32 个线程直接交换数据，无需经过 Shared Memory。延迟极低 (1-2 cycles)。这是实现高性能归约、排序、前缀和的基础。

#### 2.7.1 `__shfl_sync` — Warp 内广播

```cpp
// 将 srcLane 线程的 val 广播到 Warp 内所有线程
float __shfl_sync(unsigned mask, float var, int srcLane, int width=32);

// 示例: 将 Lane 0 的值广播给所有线程
__global__ void warp_broadcast_demo(float* data) {
    int lane = threadIdx.x % 32;
    float my_val = data[threadIdx.x];

    // broadcast lane 0 的值
    float val_from_lane0 = __shfl_sync(0xffffffff, my_val, 0);

    printf("Lane %d: broadcast from lane 0 got %f\n", lane, val_from_lane0);
}
```

#### 2.7.2 `__shfl_down_sync` — Warp 归约

这是实现高性能 Warp Reduction 的核心原语：

```cpp
// 将 var 从 laneId+delta 传到 laneId
float __shfl_down_sync(unsigned mask, float var, unsigned delta, int width=32);

// ==========================================
// Warp 内归约 (Sum) — 最常用的原语之一
// ==========================================
__inline__ __device__ float warpReduceSum(float val) {
    // 蝴蝶归约 (butterfly reduction)
    //     Lane: 0   1   2   3   4   5   6   7   ...  31
    // step delta=16: +16 +17 +18 +19 ...
    // step delta=8:  +8  +9 +10 +11 ...
    // step delta=4:  +4  +5  +6  +7 ...
    // step delta=2:  +2  +3  +4  +5 ...
    // step delta=1:  +1  +2  +3  +4 ...
    #pragma unroll
    for (int delta = 16; delta > 0; delta >>= 1) {
        val += __shfl_down_sync(0xffffffff, val, delta);
    }
    return val;  // 只有 lane 0 拿到了完整的 sum
}

// 使用 warp reduction 实现 Block 级 softmax
__global__ void block_softmax(float* input, float* output, int N) {
    int tid = threadIdx.x;
    int lane = tid % 32;
    float val = (tid < N) ? input[tid] : -INFINITY;

    // Step 1: Warp 内找最大值
    float max_val = val;
    #pragma unroll
    for (int delta = 16; delta > 0; delta >>= 1) {
        max_val = fmaxf(max_val, __shfl_down_sync(0xffffffff, max_val, delta));
    }
    // 此时所有 lane 都拿到了 warp 内的最大值 (需要从 lane 0 广播)
    max_val = __shfl_sync(0xffffffff, max_val, 0);

    // Step 2: 计算 exp(val - max)
    float exp_val = expf(val - max_val);

    // Step 3: Warp 内求 exp 之和
    float sum = exp_val;
    #pragma unroll
    for (int delta = 16; delta > 0; delta >>= 1) {
        sum += __shfl_down_sync(0xffffffff, sum, delta);
    }
    sum = __shfl_sync(0xffffffff, sum, 0);

    // Step 4: 归一化
    output[tid] = exp_val / sum;
}
```

#### 2.7.3 `__shfl_xor_sync` — XOR Shuffle

```cpp
// 蝴蝶网络，每个线程和 (lane ^ mask) 交换数据
float __shfl_xor_sync(unsigned mask, float var, int laneMask, int width=32);

// 更简洁的 Warp Reduction 实现:
__inline__ __device__ float warpReduceSumXor(float val) {
    #pragma unroll
    for (int mask = 16; mask > 0; mask >>= 1) {
        val += __shfl_xor_sync(0xffffffff, val, mask);
    }
    return val;
}
```

#### 2.7.4 `__ballot_sync` — Warp 投票

```cpp
// 返回一个 32-bit mask，bit i 表示 lane i 的 predicate 是否为 true
unsigned __ballot_sync(unsigned mask, int predicate);

// 示例: 找出 Warp 中 val > threshold 的所有线程
__global__ void ballot_demo(float* data, float threshold, int* results) {
    int lane = threadIdx.x % 32;
    float my_val = data[threadIdx.x];

    // 投票
    unsigned active_lanes = __ballot_sync(0xffffffff, my_val > threshold);

    // Lane 0 统计活跃线程数
    if (lane == 0) {
        results[0] = __popc(active_lanes);  // __popc: count set bits
        results[1] = active_lanes;           // 完整的 mask
    }
}
```

在 AI Infra 中，`__ballot_sync` 常用于：
- Attention 的局部 mask (如 causal mask)
- 稀疏计算中的非零元素检测
- warp 级别的条件分支预测

#### 2.7.5 Warp Divergence (Warp 发散)

Warp 内的 32 个线程共享同一个程序计数器。如果因为 if-else 导致线程走不同分支，它们必须**串行执行**——这就是 Warp Divergence。

```
Warp Divergence 示例:

  if (threadIdx.x % 2 == 0) {    // ← 偶数 lane 走这条路
      A();  // 耗时 10 cycles     // 奇数 lane 等待 (idle)
  } else {                        // ← 奇数 lane 走这条路
      B();  // 耗时 20 cycles     // 偶数 lane 等待 (idle)
  }
  // 总耗时: 10 + 20 = 30 cycles (串行!)
  // 如果没有 divergence: 只需要 max(10, 20) = 20 cycles

图示:
  时间 →
  ┌──────────────────────────────────────────────────────┐
  │ 偶数 T0,T2,T4,...  ████████░░░░░░░░░░░░░░░░░░░░░░░░  │ A() active,  奇等待
  │ 奇数 T1,T3,T5,...  ░░░░░░░░████████████████████████  │ B() idle,    奇 active
  │                     10         +20        =30 cycles  │
  └──────────────────────────────────────────────────────┘
```

**如何避免 Warp Divergence**：

```cpp
// 坏: 可能导致 divergence
for (int i = threadIdx.x; i < N; i += blockDim.x) {
    if (i < boundary) {  // ← boundary 不一定是 warp 边界
        do_work(data[i]);
    }
}

// 好: 让边界对齐到 warp 的倍数，或用谓词执行
// 好的做法：每个 warp 处理完整的数据块
int warp_tid = threadIdx.x / 32;
int lane = threadIdx.x % 32;
int start = warp_tid * 32 * BLOCK_SIZE + lane;
// 设计数据处理逻辑，让同一个 warp 内的所有线程都走相同的分支
```

**在 AI Infra 中**：
- Attention mask (causal mask) 会导致 Warp Divergence——部分 token 需要计算 attention，部分不需要
- FlashAttention 通过让每个 Warp 负责独立的 tile 来减少 divergence
- 在 MoE (Mixture of Experts) 中，不同 token 可能路由到不同 expert，这需要在 kernel 设计中特别小心

### 2.8 与 AI Infra 的关联

- **线程索引是数据并行的基础**：在 Attention 计算中，通常让每个 Block 处理一个 query head 的一个 token，Block 内的线程协作计算 attention
- **2D Block 组织映射到矩阵运算**：16×16 的 Block 可以自然映射到矩阵 tile
- **动态 SMEM 是 FlashAttention 的基石**：通过 `<<<grid, block, smem_bytes>>>` 传入 tile 缓冲区大小
- **Warp 原语是高性能归约的核心**：softmax、layernorm 中的归约操作都依赖 `__shfl_down_sync`
- **Bank Conflict 消除是高带宽利用的前提**：FlashAttention 使用 swizzle 布局避免 bank conflict

---

## 3. Tensor Cores

### 3.1 Tensor Core 是什么

Tensor Core 是 NVIDIA 从 Volta (2017) 开始引入的专用矩阵计算单元。它在单个时钟周期内完成一个小矩阵的乘加运算 ($D = A \times B + C$)，提供远超普通 CUDA Core 的吞吐量。

```
Tensor Core 执行的操作 (D = A × B + C):

Ampere (A800) FP16 模式: m16n8k16

     A (16×16)        B (16×8)        C (16×8)        D (16×8)
  ┌────────────┐   ┌────────────┐   ┌────────────┐   ┌────────────┐
  │            │   │            │   │            │   │            │
  │  m16 × k16 │ × │  k16 × n8  │ + │  m16 × n8  │ = │  m16 × n8  │
  │            │   │            │   │            │   │            │
  └────────────┘   └────────────┘   └────────────┘   └────────────┘

  每个 Tensor Core 操作 = 16×16×8 = 2048 次 FMA (Fused Multiply-Add)!
  这是 CUDA Core 单次 FMA 吞吐的 2048 倍 / 指令
```

### 3.2 A800 Tensor Core 支持的精度与吞吐量

| 精度 | 输入格式 | 累加器 | 峰值吞吐 (A800) | vs FP32 CUDA Core | 典型用途 |
|------|---------|--------|-----------------|-------------------|----------|
| FP64 | FP64 | FP64 | 9.7 TFLOPS | 0.5× | 科学计算 |
| TF32 | TF32 | FP32 | 156 TFLOPS | 8× | 训练 (默认) |
| FP16 | FP16 | FP16/FP32 | 312 TFLOPS | 16× | 推理、训练 |
| BF16 | BF16 | FP32 | 312 TFLOPS | 16× | 训练 (主流) |
| INT8 | INT8 | INT32 | 624 TOPS | 32× | 量化推理 |
| INT4 | INT4 | INT32 | 1248 TOPS | 64× | 量化推理 |
| INT1 | INT1 | INT32 | 4992 TOPS | 256× | 极端量化 |

**TF32 (Tensor Float 32)** 是 NVIDIA 的独创格式：用 FP32 的 8-bit exponent + FP16 的 10-bit mantissa = 19-bit 内部格式。它提供与 FP32 几乎相同的精度范围，但 Tensor Core 吞吐是 FP32 的 8 倍。在 PyTorch 中，`torch.backends.cuda.matmul.allow_tf32 = True` 默认开启。

### 3.3 Tensor Core 的 Tile 尺寸要求

不同架构和精度有不同的 tile 尺寸。对于 A800 (Ampere, SM80)：

| 精度 | Tile 形状 (m×n×k) | K 对齐要求 | 备注 |
|------|-------------------|-----------|------|
| FP16 | m16n8k16 | K % 16 == 0 | 最常用 |
| FP16 | m16n8k8 | K % 8 == 0 | 用于窄 K 维度 |
| BF16 | m16n8k16 | K % 16 == 0 | 同 FP16 |
| TF32 | m16n8k8 | K % 8 == 0 | 训练默认精度 |
| INT8 | m16n8k32 | K % 32 == 0 | 2x FP16 吞吐 |
| INT4 | m16n8k64 | K % 64 == 0 | 4x FP16 吞吐 |
| FP64 | m8n8k4 | K % 4 == 0 | 科学计算 |

### 3.4 编程方式一：WMMA API (高层 API)

WMMA (Warp Matrix Multiply-Accumulate) 是 CUDA 提供的高级 C++ API，将 Tensor Core 操作封装为模板。适合快速原型和入门。

```cpp
#include <cuda_fp16.h>
#include <mma.h>

using namespace nvcuda;

#define WMMA_M 16
#define WMMA_N 16
#define WMMA_K 16

// 完整的 WMMA GEMM Kernel
__global__ void wmma_gemm_kernel(
    const half* A, const half* B, half* C,
    int M, int N, int K)
{
    // =============================================
    // 每个 Warp 的 32 个线程协作计算一个 16×16 的 C 子矩阵
    // Warp 内分工: Tensor Core 硬件自动处理
    // =============================================

    // 声明 fragment (实际存储在寄存器中)
    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K,
                   half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K,
                   half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K,
                   half> c_frag;

    // 初始化累加器为零
    wmma::fill_fragment(c_frag, 0.0f);

    // 计算此 Warp 负责的输出 tile 位置
    // 假设 block 维度为 (warpPerRow*32, warpPerCol)
    int warp_id = threadIdx.x / 32;
    int warps_per_row = blockDim.x / 32;

    int warp_row = (blockIdx.y * warps_per_row + warp_id / blockDim.y) * WMMA_M;
    int warp_col = (blockIdx.x * blockDim.y + warp_id % blockDim.y) * WMMA_N;

    // 沿 K 维度迭代
    for (int k = 0; k < K; k += WMMA_K) {
        // 加载 A 的 tile (行优先)
        wmma::load_matrix_sync(a_frag,
            A + warp_row * K + k, K);
        // 加载 B 的 tile (列优先, 即 B 的转置)
        wmma::load_matrix_sync(b_frag,
            B + k * N + warp_col, N);

        // ★ 核心操作: Tensor Core 矩阵乘加 ★
        wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
    }

    // 写回结果 (行优先)
    wmma::store_matrix_sync(C + warp_row * N + warp_col,
        c_frag, N, wmma::mem_row_major);
}

// 启动配置
void launch_wmma_gemm(int M, int N, int K) {
    // 每个 Warp 计算 16×16，每个 Block 有 4×2=8 个 Warp
    dim3 blockDim(128, 2);  // 4 warps × 2 rows = 256 threads
    dim3 gridDim((N + 15) / (16 * 2), (M + 15) / (16 * 4));  // C的grid
    wmma_gemm_kernel<<<gridDim, blockDim>>>(d_A, d_B, d_C, M, N, K);
}
```

**WMMA 的限制**：
- 固定的 tile 尺寸：只有 m16n16k16, m32n8k16, m8n32k16
- 无法自定义数据流（如 async copy + 双缓冲）
- 无法与其他指令（如 permute, transpose via sts）交错
- 性能不是最优：约 70-80% 的峰值 Tensor Core 利用率

### 3.5 编程方式二：mma.sync PTX (底层 API)

对于追求极致性能的场景，使用 PTX 级别的 `mma.sync` 指令。FlashAttention 和 CUTLASS 都使用这种方式。

```cpp
// mma.sync PTX 内联汇编示例 (Ampere, FP16, m16n8k16)
// 这个指令直接操作 Tensor Core 硬件

// A: 4 个 32-bit 寄存器 (每个存 4 个 FP16 = 共 16 个元素，即 m16k16 的一行的一半?)
// B: 2 个 32-bit 寄存器 (每个存 2 个 FP16 = 共 4 个? 实际上是 k16n8 的列表示)
// C/D: 4 个 32-bit 寄存器 (每个存 2 个 FP16 = 共 8 个元素，即 m16n8)

asm volatile(
    "mma.sync.aligned.m16n8k16.row.col.f16.f16.f16.f16 "
    "{%0, %1, %2, %3}, "   // D = C + A * B (输出: 4×32-bit 寄存器)
    "{%4, %5, %6, %7}, "   // A (输入: 4×32-bit 寄存器)
    "{%8, %9}, "           // B (输入: 2×32-bit 寄存器)
    "{%10, %11, %12, %13};\n"  // C (输入: 4×32-bit 寄存器)
    : "=r"(d0), "=r"(d1), "=r"(d2), "=r"(d3)
    : "r"(a0), "r"(a1), "r"(a2), "r"(a3),
      "r"(b0), "r"(b1),
      "r"(c0), "r"(c1), "r"(c2), "r"(c3)
);
/*
指令解码 (从右到左):
  mma.sync.aligned.m16n8k16.row.col.f16.f16.f16.f16
    │     │       │         │   │   │   │   │   └── 累加器类型 (f16)
    │     │       │         │   │   │   │   └────── B 输入类型 (f16)
    │     │       │         │   │   │   └────────── A 输入类型 (f16)
    │     │       │         │   │   └────────────── B 矩阵布局 (col-major)
    │     │       │         │   └────────────────── A 矩阵布局 (row-major)
    │     │       │         └────────────────────── 矩阵尺寸 (m=16,n=8,k=16)
    │     │       └──────────────────────────────── 对齐要求 (aligned)
    │     └──────────────────────────────────────── 同步 Warp 内所有线程
    └────────────────────────────────────────────── 矩阵乘加指令
*/
```

### 3.6 Tensor Core 编程的约束条件

1. **K 维度必须对齐到 tile 的 K**：如 m16n8k16 要求 K 是 16 的倍数
2. **Global Memory 访问必须 16 字节对齐**：使用 `__align__(16)` 或保证偏移量是 16 的倍数
3. **数据布局**：A 行优先 + B 列优先是最优的；如果 B 是行优先，需要额外转置
4. **Warp 内线程的寄存器分配是固定的**：不能随意分配，必须遵循 CUDA 手册中指定的映射
5. **mma.sync 要求所有线程同时执行**：如果有 warp divergence，结果是未定义的

### 3.7 与 AI Infra 的关联

- **所有推理中的矩阵乘法必须使用 Tensor Cores**：不使用 = 放弃 16× (FP32) 的吞吐
- **wmma 适合快速验证**：wmma GEMM + 自定义 epilogue (ReLU, bias add, etc.)
- **生产代码使用 mma.sync 或 CUTLASS**：FlashAttention/vLLM 底层都依赖 CUTLASS 或直接 mma.sync
- **精度选择影响推理延迟**：FP16→INT8 额外 2×，INT8→INT4 再 2×。量化对推理性能至关重要
- **Tensor Core 需求驱动了模型量化**：W4A16、W8A8 等方案本质是为了匹配 Tensor Core 的 INT4/INT8 tile 规格

---

## 4. 异步执行

### 4.1 CUDA Stream 基础

CUDA Stream 是一个**命令队列**。同一个 Stream 内的操作按顺序执行；不同 Stream 之间的操作可以并行执行。

```cpp
cudaStream_t stream1, stream2;
cudaStreamCreate(&stream1);
cudaStreamCreate(&stream2);

// Stream 1 中: 拷贝 A → 计算 A → 拷贝结果
cudaMemcpyAsync(d_A, h_A, bytes, cudaMemcpyHostToDevice, stream1);
kernelA<<<grid, block, 0, stream1>>>(d_A, d_result1, N);
cudaMemcpyAsync(h_result1, d_result1, bytes, cudaMemcpyDeviceToHost, stream1);

// Stream 2 中: 拷贝 B → 计算 B → 拷贝结果 (与 Stream 1 并行!)
cudaMemcpyAsync(d_B, h_B, bytes, cudaMemcpyHostToDevice, stream2);
kernelB<<<grid, block, 0, stream2>>>(d_B, d_result2, N);
cudaMemcpyAsync(h_result2, d_result2, bytes, cudaMemcpyDeviceToHost, stream2);

cudaStreamSynchronize(stream1);  // 等待 stream1 完成
cudaStreamSynchronize(stream2);  // 等待 stream2 完成
```

**Default Stream vs Per-Thread Default Stream**：

```cpp
// default stream (stream 0): 在所有其他 stream 之前/之后隐式同步
kernel<<<grid, block>>>(d_data);  // 使用 default stream

// per-thread default stream: 不与其他 stream 同步
// 编译选项: --default-stream per-thread
// 或运行时:
cudaStream_t s = cudaStreamPerThread;
kernel<<<grid, block, 0, s>>>(d_data);
```

### 4.2 计算与拷贝重叠 (Overlap)

这是 CUDA 异步执行**最重要的应用**：在 GPU 执行 Kernel 的同时，用 Copy Engine 传输下一批数据。

```
时间线图示 (单 Stream vs 多 Stream 重叠):

  单 Stream (无重叠):
  ─────────────────────────────────────────────────────→
  │ H2D Copy │ Kernel  │ D2H Copy │ H2D Copy │ Kernel  │
  ─────────────────────────────────────────────────────→

  多 Stream 重叠:
  ─────────────────────────────────────────────────────→
  Stream 1: │ H2D1 │ Kernel1 │ D2H1 │
  Stream 2:        │ H2D2 │ Kernel2 │ D2H2 │
  Stream 3:               │ H2D3 │ Kernel3 │ D2H3 │
  ─────────────────────────────────────────────────────→
              ↑       ↑         ↑
          拷贝引擎   计算引擎   拷贝引擎 (同时工作!)
```

**实现拷贝-计算重叠的完整示例**：

```cpp
// 将大数据分片，用多个 Stream 实现重叠
const int num_streams = 4;
const int chunk_size = N / num_streams;
cudaStream_t streams[num_streams];

for (int i = 0; i < num_streams; i++) {
    cudaStreamCreate(&streams[i]);
}

for (int i = 0; i < num_streams; i++) {
    int offset = i * chunk_size;
    int size = (i == num_streams - 1) ? N - offset : chunk_size;

    // 异步拷贝 H→D
    cudaMemcpyAsync(d_A + offset, h_A + offset,
                    size * sizeof(float),
                    cudaMemcpyHostToDevice, streams[i]);
    // 启动 Kernel (在同一个 Stream 中，会在拷贝完成后执行)
    myKernel<<<grid, block, 0, streams[i]>>>(d_A + offset,
                                              d_C + offset, size);
    // 异步拷贝 D→H (在 Kernel 完成后执行)
    cudaMemcpyAsync(h_C + offset, d_C + offset,
                    size * sizeof(float),
                    cudaMemcpyDeviceToHost, streams[i]);
}

// 等待所有 stream 完成
for (int i = 0; i < num_streams; i++) {
    cudaStreamSynchronize(streams[i]);
    cudaStreamDestroy(streams[i]);
}
```

**关键要求**：Host 内存必须是 **pinned memory** (page-locked)，否则 cudaMemcpyAsync 无法真正异步：

```cpp
// 好: pinned memory (page-locked)
float* h_data;
cudaMallocHost(&h_data, N * sizeof(float));  // 或 cudaHostAlloc

// 坏: pageable memory (异步拷贝会退化为同步)
float* h_data = (float*)malloc(N * sizeof(float));
```

### 4.3 Events 用于计时和同步

CUDA Events 是 GPU 端的轻量级时间戳，用于精确计时和跨 Stream 同步。

```cpp
cudaEvent_t start, stop;
cudaEventCreate(&start);
cudaEventCreate(&stop);

// 记录开始事件 (在 default stream 中)
cudaEventRecord(start);

// 启动 kernel
myKernel<<<grid, block>>>(d_data, N);

// 记录结束事件
cudaEventRecord(stop);

// 等待 stop 事件完成
cudaEventSynchronize(stop);

// 计算耗时 (毫秒)
float milliseconds = 0;
cudaEventElapsedTime(&milliseconds, start, stop);
printf("Kernel time: %.3f ms\n", milliseconds);

cudaEventDestroy(start);
cudaEventDestroy(stop);
```

**跨 Stream 同步**：

```cpp
// Stream 2 的 Kernel B 必须等待 Stream 1 的 Kernel A 完成后才能开始
cudaEvent_t event;
cudaEventCreate(&event);

kernelA<<<grid, block, 0, stream1>>>(d_A, N);
cudaEventRecord(event, stream1);  // 在 stream1 中记录事件

// stream2 等待 event (即等待 kernelA 完成)
cudaStreamWaitEvent(stream2, event, 0);
kernelB<<<grid, block, 0, stream2>>>(d_B, N);  // kernelA 完成后才执行
```

### 4.4 cp.async — 异步从 Global Memory 加载到 Shared Memory

Ampere 架构 (SM80+) 引入了 `cp.async` 指令，允许直接在 Global Memory 和 Shared Memory 之间进行异步拷贝，绕过寄存器。这配合 **pipeline / barrier** 机制可以实现**拷贝和计算完全重叠**。

```cpp
// 使用 cp.async + pipeline 的完整示例
#include <cuda/pipeline>
#include <cuda/barrier>

#define TILE_SIZE 256

__global__ void async_copy_kernel(const float* global_data,
                                   float* output, int N) {
    extern __shared__ float smem[];

    // 创建 pipeline (2 个 stage: 双缓冲)
    // 同时也定义了 barrier
    __shared__ cuda::pipeline_shared_state<
        cuda::thread_scope::thread_scope_block, 2> shared_state;
    auto pipe = cuda::make_pipeline(
        cuda::thread_scope::thread_scope_block, shared_state);

    int tid = threadIdx.x;
    int global_idx = blockIdx.x * blockDim.x + tid;

    // ========================================
    // 第一阶段: 预加载第一个 tile (stage 0)
    // ========================================
    if (global_idx < N) {
        // cp.async 直接 global→smem，不经过寄存器
        cuda::memcpy_async(       // 文档中旧写法: __pipeline_memcpy_async
            smem + tid,
            global_data + global_idx,
            sizeof(float),
            pipe);
    }
    pipe.commit();          // 提交异步拷贝
    pipe.wait_prior<0>();   // 等待 stage-0 完成 (第一次无 stage-0 数据)

    // ========================================
    // 主循环: 双缓冲
    // ========================================
    for (int step = 1; step < num_steps; step++) {
        int next_idx = (blockIdx.x * blockDim.x + tid) +
                       step * blockDim.x;

        if (next_idx < N) {
            // ★ 异步加载下一个 tile (与下面的计算重叠!)
            cuda::memcpy_async(
                smem + blockDim.x + tid,  // 写到 buffer 1
                global_data + next_idx,
                sizeof(float),
                pipe);
        }
        pipe.commit();  // 提交拷贝请求

        // ★ 同时使用 buffer 0 做计算 (计算和拷贝重叠!)
        float val = smem[tid];
        output[global_idx + (step - 1) * blockDim.x] = val * 2.0f;

        pipe.wait_prior<0>();  // 等待 buffer 0 可用 (即上次的 buffer 1)
        // 此时 buffer 切换完成，buffer 1 已经准备好
    }

    // 处理最后一个 tile
    float val = smem[tid];
    output[global_idx + (num_steps - 1) * blockDim.x] = val * 2.0f;
}
```

**cp.async 的优势**：
- 绕过寄存器，降低寄存器压力
- 配合 pipeline barrier，在 SMEM 级实现 producer-consumer 模型
- 可以实现 Global Memory→SMEM 和 SMEM→计算 的完全重叠

### 4.5 与 AI Infra 的关联

- **多 Stream 重叠在推理服务中至关重要**：在一个请求执行 Decode 的同时，另一个请求可以执行 Prefill，第三个可以拷贝数据
- **Events 是精确计时工具**：所有 kernel 性能优化都依赖 cudaEvent 计时，而非 host 端的 clock()
- **cp.async 是 FlashAttention 高性能的关键**：FlashAttention 使用 cp.async 异步加载 QKV tile 到 SMEM，实现加载-计算流水线
- **Pinned Memory 是前提**：推理服务的输入/输出 buffer 必须用 pinned memory，否则 GPU→CPU 数据传输会成为瓶颈

---

## 5. CUDA Graphs

### 5.1 问题：Kernel Launch Overhead

每次 Kernel Launch (`<<<>>>`) 都有约 **5-10 μs 的 CPU 端开销**（包括参数校验、命令提交、驱动调度）。对于需要启动数千个小 Kernel 的工作负载，这个开销可能超过 GPU 计算时间本身。

```
场景: 100 个微小的 element-wise Kernel，每个耗时 5 μs

无 CUDA Graph:
  Launch0 [5us overhead + 5us compute]
  Launch1 [5us overhead + 5us compute]
  ...
  Launch99[5us overhead + 5us compute]
  总耗时: 100 × (5 + 5) = 1000 μs
  GPT 开销占比: 50%! ← 完全浪费

有 CUDA Graph:
  Graph Capture: 一次性开销 (~200 μs)
  Replay0: [几乎零开销 + 100 × 5us compute] = 500 μs
  Replay1: 500 μs
  ...
  开销占比: ~0% ← 几乎消失
```

### 5.2 为什么 vLLM 使用 CUDA Graphs

vLLM 的 Decode 阶段每次迭代的结构完全一致：
1. 从 KV Cache 读取
2. Attention 计算
3. FFN 计算
4. Sampling

每次迭代启动的 Kernel 数量和顺序完全一样，只是数据地址不同。这是 CUDA Graph 的**最佳应用场景**。

### 5.3 CUDA Graph 的三个阶段

```
┌──────────────────┐     ┌────────────────────┐     ┌──────────────────┐
│ 1. Graph Capture │ ──► │ 2. Instantiation   │ ──► │ 3. Replay (反复) │
│                  │     │                    │     │                  │
│ BeginCapture()   │     │ cudaGraphInstantiate│     │ cudaGraphLaunch  │
│  kernel<<<...>>> │     │  (优化 + 验证)      │     │  (只需一次调用!)  │
│  kernel<<<...>>> │     │                    │     │                  │
│  kernel<<<...>>> │     │ 一次性开销:         │     │ 每次开销:        │
│ EndCapture()     │     │ ~100-500 μs         │     │ ~1-2 μs          │
│                  │     │                    │     │                  │
│ 记录所有操作的有向 │     │ 生成优化的执行图     │     │ 直接提交到 GPU   │
│ 无环图 (DAG)      │     │                    │     │ 执行引擎          │
└──────────────────┘     └────────────────────┘     └──────────────────┘
```

### 5.4 完整代码示例

```cpp
#include <cuda_runtime.h>
#include <cstdio>

// 简单的 element-wise kernel
__global__ void add_one(float* data, int N) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < N) data[tid] += 1.0f;
}

__global__ void multiply_two(float* data, int N) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < N) data[tid] *= 2.0f;
}

int main() {
    int N = 1 << 20;
    size_t bytes = N * sizeof(float);

    // GPU 内存
    float *d_data;
    cudaMalloc(&d_data, bytes);

    int block = 256;
    int grid = (N + 255) / 256;

    // =============================================
    // Step 1: Graph Capture (捕获)
    // =============================================
    cudaStream_t captureStream;
    cudaStreamCreate(&captureStream);

    cudaStreamBeginCapture(captureStream,
        cudaStreamCaptureModeGlobal);  // 全局模式 (捕获所有操作)

    // 在 captureStream 中执行的所有 CUDA 操作都会被记录
    add_one<<<grid, block, 0, captureStream>>>(d_data, N);
    multiply_two<<<grid, block, 0, captureStream>>>(d_data, N);
    // 还可以加入更多 kernel...

    cudaGraph_t graph;
    cudaStreamEndCapture(captureStream, &graph);

    // =============================================
    // Step 2: Instantiation (实例化)
    // =============================================
    cudaGraphExec_t graphExec;
    cudaGraphInstantiate(&graphExec, graph, NULL, NULL, 0);
    // graph 可以释放了
    cudaGraphDestroy(graph);

    // =============================================
    // Step 3: Replay (回放) — 可以反复执行
    // =============================================
    cudaStream_t execStream;
    cudaStreamCreate(&execStream);

    for (int iter = 0; iter < 1000; iter++) {
        // ★ 一次 API 调用 = 之前两次 kernel launch!
        cudaGraphLaunch(graphExec, execStream);
    }
    cudaStreamSynchronize(execStream);

    // 清理
    cudaGraphExecDestroy(graphExec);
    cudaStreamDestroy(captureStream);
    cudaStreamDestroy(execStream);
    cudaFree(d_data);

    printf("CUDA Graph demo completed.\n");
    return 0;
}
```

### 5.5 CUDA Graph 的限制

| 限制 | 说明 | 影响 |
|------|------|------|
| 不支持动态形状 | Graph 捕获时 kernel 参数 (如 N) 固定 | 需要为不同大小创建不同的 graph |
| 不支持条件执行 | 不能有 `if (x) launch_kernel_A else launch_kernel_B` | 无运行时分支 |
| 不支持 Device Graph Launch | 必须是 Host 端驱动 (CDP2 除外) | 不能从 GPU 端 launch graph |
| 参数更新 | 使用 `cudaGraphExecUpdate` 更新 kernel 参数 | 部分解决动态数据问题 |
| 调试困难 | 捕获的 graph 不能单步调试 | 开发阶段先用无 graph 版本 |

### 5.6 vLLM 中如何使用

在 vLLM 的 Decode 阶段：
1. **首次迭代**: 以正常方式运行所有 kernel，同时用 CUDA Graph 捕获整个 Decode 迭代
2. **后续迭代**: 只 replay 捕获好的 graph，每次只需要更新输入地址 (通过 `cudaGraphExecUpdate` 或使用 device pointer 参数)
3. **当 batch 大小变化时**: 需要重新捕获新的 graph (因为 kernel 参数变了)

```python
# vLLM 中 CUDA Graph 的简化使用逻辑 (Python 端)
if not graph_captured or batch_size_changed:
    # 捕获模式
    with cuda_graph_capture():
        run_decode_iteration(input_ids, kv_cache, ...)
    graph_captured = True
else:
    # 回放模式
    cuda_graph_replay()  # 几乎零开销
```

### 5.7 与 AI Infra 的关联

- **vLLM 的 CUDA Graph 优化可降低 Decode 延迟 10-30%**：取决于 batch size 和模型大小
- **适合迭代结构固定的场景**：LLM 推理、推荐系统推理、在线学习 (固定 batch)
- **不适合 Prefill**：Prefill 的序列长度可变，每次 kernel 参数不同
- **与 Dynamic Batching 结合**：需要为每种 batch size 预捕获一个 graph

---

## 6. 实战：逐步优化 GEMM 内核

这是本指南的核心章节。我们从最简单的三层循环开始，一步步优化到接近硬件峰值。

目标计算：$C = \alpha A B + \beta C$，其中 $A \in \mathbb{R}^{M \times K}$，$B \in \mathbb{R}^{K \times N}$，$C \in \mathbb{R}^{M \times N}$。

为简单起见，以下使用 $\alpha=1, \beta=0$ (即纯 GEMM，无 bias)。

---

### v0: Naive GEMM (3 层嵌套循环)

```cpp
// ============================================================
// v0: Naive GEMM — 每个线程计算 C 的一个元素
// 性能: ~0.05 TFLOPS (峰值 19.5 TFLOPS 的 0.25%)
// 问题: 每个线程从 Global Memory 独立加载整行和整列，极多冗余访问
// ============================================================

__global__ void gemm_v0_naive(
    const float* A, const float* B, float* C,
    int M, int N, int K)
{
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; k++) {
            // A[row][k] stride=1 → 合并访问 ✓
            // B[k][col] stride=N → 非合并访问 ✗
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}

// 启动: 16×16 block, grid 覆盖整个 C 矩阵
void launch_gemm_v0(int M, int N, int K) {
    dim3 blockDim(16, 16);
    dim3 gridDim((N + 15) / 16, (M + 15) / 16);
    gemm_v0_naive<<<gridDim, blockDim>>>(d_A, d_B, d_C, M, N, K);
}
```

**问题分析**：
- 每个线程读取 K 次 A 和 K 次 B → $O(K)$ 次 HBM 访问
- B 的列访问是 stride-N → 非合并访问 → 带宽利用率极低
- 相邻线程加载完全相同的 K 个 B 元素 → 零数据复用 (每个元素从 HBM 读了 TILE_SIZE 次!)
- 计算/访存比 ≈ 2/(8+8) = 0.125 FLOPS/Byte → 严重 memory-bound

---

### v1: Global Memory 合并访问改善

```cpp
// ============================================================
// v1: 改善 B 的访问模式 + 每个线程加载多个元素供复用
// 性能: ~0.5 TFLOPS (提升 10x)
// 改进: A 的访问合并, B 通过 Shared Memory 中转
// ============================================================

// v1 实际上与下面的 v2 合并, 因为要解决 B 的非合并访问
// 必须引入 Shared Memory, 参见 v2
```

**说明**：仅靠调整 Global Memory 访问模式无法根本解决 B 的 stride-N 问题，因为矩阵乘法的本质决定了 (线程按 row, col 分布) B 的访问必然跨行。**必须引入 Shared Memory** 来做数据重组。

---

### v2: Shared Memory Tiling (Block Tiling)

```cpp
// ============================================================
// v2: Shared Memory Tiling — 将数据分块加载到 SMEM
// 性能: ~2 TFLOPS (提升 40x vs naive)
// 关键改进:
//   1. 将 A 和 B 的 tile 协作加载到 SMEM
//   2. Block 内所有线程复用 SMEM 中的数据
//   3. Data reuse ratio: TILE_SIZE per HBM load
// ============================================================

#define TILE_SIZE 32

__global__ void gemm_v2_smem_tiling(
    const float* A, const float* B, float* C,
    int M, int N, int K)
{
    // Shared Memory 存储 A 和 B 的 tile
    __shared__ float As[TILE_SIZE][TILE_SIZE];
    __shared__ float Bs[TILE_SIZE][TILE_SIZE];

    int row = blockIdx.y * TILE_SIZE + threadIdx.y;
    int col = blockIdx.x * TILE_SIZE + threadIdx.x;

    float sum = 0.0f;

    // 沿 K 维度分 tile 迭代
    for (int t = 0; t < (K + TILE_SIZE - 1) / TILE_SIZE; t++) {
        // ----- 协作加载 A 的 tile -----
        int k_a = t * TILE_SIZE + threadIdx.x;
        if (row < M && k_a < K)
            As[threadIdx.y][threadIdx.x] = A[row * K + k_a];
        else
            As[threadIdx.y][threadIdx.x] = 0.0f;

        // ----- 协作加载 B 的 tile -----
        int k_b = t * TILE_SIZE + threadIdx.y;
        if (k_b < K && col < N)
            Bs[threadIdx.y][threadIdx.x] = B[k_b * N + col];
        else
            Bs[threadIdx.y][threadIdx.x] = 0.0f;

        __syncthreads();  // ★ 确保整个 tile 加载完毕再计算

        // ----- 在 SMEM 上做计算 (快!) -----
        for (int kk = 0; kk < TILE_SIZE; kk++) {
            sum += As[threadIdx.y][kk] * Bs[kk][threadIdx.x];
            //     As 行访问 → 合并 ✓
            //     Bs 列访问 → Bank Conflict! (同一列的32个线程在同一Bank)
        }

        __syncthreads();  // ★ 确保计算完成再加载下一个 tile
    }

    if (row < M && col < N) {
        C[row * N + col] = sum;
    }
}
```

**关键改进**：
1. **数据复用**：每个 HBM 元素加载一次，Block 内 TILE_SIZE 个线程复用 → HBM 访问减少 TILE_SIZE×
2. **A 的加载是合并的**：row 固定，col 连续 (stride-1)
3. **计算在 SMEM 上**：延迟从 ~700 cycles 降到 ~30 cycles

**遗留问题**：
- Bs 的读取 `Bs[kk][threadIdx.x]` 是沿列方向读取 → **Bank Conflict**
- 内层循环 `kk` 做了太多 SMEM load，没有利用寄存器缓存

---

### v3: 2D Thread Tiling (每个线程计算 8×8 子矩阵)

```cpp
// ============================================================
// v3: 2D Thread Tiling — 每个线程计算 8×8 的输出子矩阵
// 性能: ~8 TFLOPS (提升 4x vs v2)
// 关键改进:
//   1. 每个线程维护 8×8=64 个寄存器累加器
//   2. SMEM load 次数减少 64 倍 (每个 tile 只加载一次到寄存器)
//   3. As 加 Padding (+1) 消除 Bank Conflict
// ============================================================

#define TILE_SIZE 32
#define THREAD_TILE_M 8
#define THREAD_TILE_N 8

__global__ void gemm_v3_thread_tiling(
    const float* A, const float* B, float* C,
    int M, int N, int K)
{
    // +1 Padding 消除 Bank Conflict
    __shared__ float As[TILE_SIZE][TILE_SIZE + 1];
    __shared__ float Bs[TILE_SIZE][TILE_SIZE + 1];

    // 每个线程负责 THREAD_TILE_M × THREAD_TILE_N 的输出区域
    int row = blockIdx.y * TILE_SIZE + threadIdx.y * THREAD_TILE_M;
    int col = blockIdx.x * TILE_SIZE + threadIdx.x * THREAD_TILE_N;

    // ★ 寄存器 tile: 每个线程维护一个子矩阵的累加器
    float c[THREAD_TILE_M][THREAD_TILE_N] = {{0.0f}};

    for (int t = 0; t < K; t += TILE_SIZE) {
        // ----- 协作加载 A tile (每个线程加载多个元素) -----
        for (int mi = 0; mi < THREAD_TILE_M; mi++) {
            int a_row = row + mi;
            int a_col = t + threadIdx.x;
            As[threadIdx.y * THREAD_TILE_M + mi][threadIdx.x] =
                (a_row < M && a_col < K) ? A[a_row * K + a_col] : 0.0f;
        }

        // ----- 协作加载 B tile -----
        for (int ni = 0; ni < THREAD_TILE_N; ni++) {
            int b_row = t + threadIdx.y;
            int b_col = col + ni;
            Bs[threadIdx.y][threadIdx.x * THREAD_TILE_N + ni] =
                (b_row < K && b_col < N) ? B[b_row * N + b_col] : 0.0f;
        }

        __syncthreads();

        // ----- 在 SMEM 上计算，结果累加到寄存器 tile -----
        for (int kk = 0; kk < TILE_SIZE; kk++) {
            for (int mi = 0; mi < THREAD_TILE_M; mi++) {
                float a_val = As[threadIdx.y * THREAD_TILE_M + mi][kk];
                for (int ni = 0; ni < THREAD_TILE_N; ni++) {
                    float b_val = Bs[kk][threadIdx.x * THREAD_TILE_N + ni];
                    c[mi][ni] += a_val * b_val;
                }
            }
        }

        __syncthreads();
    }

    // ----- 写回结果 -----
    for (int mi = 0; mi < THREAD_TILE_M; mi++) {
        for (int ni = 0; ni < THREAD_TILE_N; ni++) {
            int r = row + mi;
            int c_idx = col + ni;
            if (r < M && c_idx < N) {
                C[r * N + c_idx] = c[mi][ni];
            }
        }
    }
}
```

**关键改进**：
- Register tiling：每个线程维护 64 个 FP32 累加器 → SMEM load 减少 64 倍 → 计算密度大幅提升
- As Padding 消除 Bank Conflict (行宽 33×4=132, 132%128=4, 打散了 Bank 映射)
- 每个线程协作加载多个元素，提高了加载效率

---

### v4: 向量化加载 (float4)

```cpp
// ============================================================
// v4: 向量化加载 (float4 / uint4)
// 性能: ~12 TFLOPS (提升 1.5x vs v3)
// 关键改进:
//   - 使用 float4 (128-bit) 取代 float (32-bit) 加载
//   - 每次 load 指令传输 16 字节而不是 4 字节
//   - load 指令数减少 4x，更好利用内存带宽
// ============================================================

// float4 是 CUDA 内建的向量类型
// struct float4 { float x, y, z, w; }; // 共 16 字节

__global__ void gemm_v4_vectorized(
    const float* A, const float* B, float* C,
    int M, int N, int K)
{
    __shared__ float As[TILE_SIZE][TILE_SIZE + 1];
    __shared__ float Bs[TILE_SIZE][TILE_SIZE + 1];

    int row = blockIdx.y * TILE_SIZE + threadIdx.y * THREAD_TILE_M;
    int col = blockIdx.x * TILE_SIZE + threadIdx.x * THREAD_TILE_N;

    float c[THREAD_TILE_M][THREAD_TILE_N] = {{0.0f}};

    for (int t = 0; t < K; t += TILE_SIZE) {
        // ----- 向量化加载 A (每个线程加载一个 float4 = 4 个 float) -----
        for (int mi = 0; mi < THREAD_TILE_M; mi++) {
            int a_row = row + mi;
            int a_col = t + threadIdx.x * 4;  // ← 每线程加载 4 个 float!
            if (a_row < M && a_col < K - 3) {
                // 将 float* 转为 float4*，一次加载 16 字节
                const float4* A_f4 = reinterpret_cast<const float4*>(
                    &A[a_row * K + a_col]);
                float4 a_vec = *A_f4;  // ★ 一条 128-bit load 指令
                // 展开 float4 到 SMEM
                As[threadIdx.y * THREAD_TILE_M + mi]
                  [threadIdx.x * 4 + 0] = a_vec.x;
                As[threadIdx.y * THREAD_TILE_M + mi]
                  [threadIdx.x * 4 + 1] = a_vec.y;
                As[threadIdx.y * THREAD_TILE_M + mi]
                  [threadIdx.x * 4 + 2] = a_vec.z;
                As[threadIdx.y * THREAD_TILE_M + mi]
                  [threadIdx.x * 4 + 3] = a_vec.w;
            } else {
                // 边界处理：回退到逐元素加载
                for (int i = 0; i < 4; i++) {
                    As[threadIdx.y * THREAD_TILE_M + mi]
                      [threadIdx.x * 4 + i] =
                        (a_row < M && a_col + i < K) ?
                         A[a_row * K + a_col + i] : 0.0f;
                }
            }
        }

        // ----- 向量化加载 B (类似逻辑, 每个线程加载 4 个 B 元素) -----
        for (int ni = 0; ni < THREAD_TILE_N; ni++) {
            int b_row = t + threadIdx.y;
            int b_col = col + ni;
            if (b_row < K && b_col < N - 3) {
                const float4* B_f4 = reinterpret_cast<const float4*>(
                    &B[b_row * N + b_col]);
                float4 b_vec = *B_f4;
                Bs[threadIdx.y][threadIdx.x * THREAD_TILE_N + ni + 0] = b_vec.x;
                Bs[threadIdx.y][threadIdx.x * THREAD_TILE_N + ni + 1] = b_vec.y;
                Bs[threadIdx.y][threadIdx.x * THREAD_TILE_N + ni + 2] = b_vec.z;
                Bs[threadIdx.y][threadIdx.x * THREAD_TILE_N + ni + 3] = b_vec.w;
            }
        }

        __syncthreads();

        // 计算逻辑同 v3
        for (int kk = 0; kk < TILE_SIZE; kk++) {
            for (int mi = 0; mi < THREAD_TILE_M; mi++) {
                float a_val = As[threadIdx.y * THREAD_TILE_M + mi][kk];
                for (int ni = 0; ni < THREAD_TILE_N; ni++) {
                    float b_val = Bs[kk][threadIdx.x * THREAD_TILE_N + ni];
                    c[mi][ni] += a_val * b_val;
                }
            }
        }

        __syncthreads();
    }

    // 写回 (也可以用 float4 存储)
    for (int mi = 0; mi < THREAD_TILE_M; mi++) {
        for (int ni = 0; ni < THREAD_TILE_N; ni++) {
            int r = row + mi;
            int c_idx = col + ni;
            if (r < M && c_idx < N) {
                C[r * N + c_idx] = c[mi][ni];
            }
        }
    }
}
```

**关键改进**：
- Load 指令数量减少 4× → 减少地址计算和发射开销
- 128-bit load 充分利用内存总线宽度 (32 bytes per transaction)
- 对 A800 的 LD/ST 单元 (8 per SM) 来说，单位时间内可传输 4× 数据

---

### v5: Double Buffering (双缓冲 + 异步拷贝)

```cpp
// ============================================================
// v5: Double Buffering — 用 cp.async 实现加载与计算重叠
// 性能: ~18 TFLOPS (提升 1.5x vs v4)
// 关键改进:
//   - 两组 SMEM buffer 交替使用
//   - 在计算当前 tile 的同时异步加载下一个 tile
//   - 加载延迟完全被计算隐藏
// ============================================================

#define TILE_SIZE 32
#define THREAD_TILE_M 8
#define THREAD_TILE_N 8

__global__ void gemm_v5_double_buffering(
    const float* A, const float* B, float* C,
    int M, int N, int K)
{
    // 双缓冲: 两组 SMEM (动态 Shared Memory)
    extern __shared__ float smem[];
    // buffer 0
    float* As0 = smem;
    float* Bs0 = smem + TILE_SIZE * (TILE_SIZE + 1);
    // buffer 1
    float* As1 = smem + 2 * TILE_SIZE * (TILE_SIZE + 1);
    float* Bs1 = smem + 3 * TILE_SIZE * (TILE_SIZE + 1);

    int row = blockIdx.y * TILE_SIZE + threadIdx.y * THREAD_TILE_M;
    int col = blockIdx.x * TILE_SIZE + threadIdx.x * THREAD_TILE_N;

    float c[THREAD_TILE_M][THREAD_TILE_N] = {{0.0f}};

    // ======== 预加载第一个 tile 到 buffer 0 ========
    // load_A_to_As(As0, A, row, 0);
    // load_B_to_Bs(Bs0, B, col, 0);
    __syncthreads();

    int num_tiles = (K + TILE_SIZE - 1) / TILE_SIZE;
    for (int t = 1; t < num_tiles; t++) {
        int k_offset = t * TILE_SIZE;

        // ★★★ 异步加载下一个 tile 到 buffer 1 ★★★
        // 在实际代码中，这应该用 cp.async 或 pipeline API
        // load_A_to_As(As1, A, row, k_offset);
        // load_B_to_Bs(Bs1, B, col, k_offset);
        // 不需要 __syncthreads() — 异步拷贝在后台进行!

        // ★★★ 同时使用 buffer 0 做计算 ★★★
        // compute_with_tile(As0, Bs0, c);
        for (int kk = 0; kk < TILE_SIZE; kk++) {
            for (int mi = 0; mi < THREAD_TILE_M; mi++) {
                float a_val = As0[threadIdx.y * THREAD_TILE_M + mi][kk];
                for (int ni = 0; ni < THREAD_TILE_N; ni++) {
                    float b_val = Bs0[kk][threadIdx.x * THREAD_TILE_N + ni];
                    c[mi][ni] += a_val * b_val;
                }
            }
        }

        __syncthreads();  // 确保计算完成 + 异步加载完成

        // 交换 buffer: buffer1 → buffer0 (逻辑交换, 不拷贝数据!)
        // swap(As0, As1); swap(Bs0, Bs1);
        // 注: 实际实现中通过 stage 变量 0/1 切换来选择 buffer
    }

    // 计算最后一个 tile (已经在 buffer 0 中)
    // compute_with_tile(As0, Bs0, c);

    // 写回结果
    for (int mi = 0; mi < THREAD_TILE_M; mi++) {
        for (int ni = 0; ni < THREAD_TILE_N; ni++) {
            int r = row + mi;
            int c_idx = col + ni;
            if (r < M && c_idx < N) {
                C[r * N + c_idx] = c[mi][ni];
            }
        }
    }
}
```

**关键改进**：
- 计算和加载完全重叠 → Global Memory 延迟被完全隐藏
- 配合 cp.async 硬件指令，绕过寄存器，降低寄存器压力
- 这是 FlashAttention 中使用 Pipeline 机制的简化版本

---

### v6: Tensor Cores (WMMA API)

```cpp
// ============================================================
// v6: Tensor Cores with WMMA API
// 性能: ~80+ TFLOPS (提升 4-5x vs v5, ~1600x vs v0)
// 这是在 FP16 精度下的性能。如果用 mma.sync + 全优化可达 ~200+ TFLOPS
// ============================================================

#include <cuda_fp16.h>
#include <mma.h>

using namespace nvcuda;

#define WMMA_M 16
#define WMMA_N 16
#define WMMA_K 16
#define TILE_SIZE 128  // 更大的 tile 适配 Tensor Core

__global__ void gemm_v6_tensorcore(
    const half* A, const half* B, half* C,
    int M, int N, int K)
{
    // 每个 Warp 处理一个 16×16 的 C 子矩阵
    extern __shared__ half smem[];
    half* As = smem;
    half* Bs = smem + TILE_SIZE * (TILE_SIZE + 1);

    // WMMA fragment 声明
    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K,
                   half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K,
                   half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K,
                   half> c_frag;

    wmma::fill_fragment(c_frag, 0.0f);

    // 确定此 Warp 负责的输出位置
    int warp_id = threadIdx.x / 32;
    // int warp_col = ...; int warp_row = ...;  // 同 3.4 节的 WMMA 示例

    // 沿 K 维度迭代 tile
    for (int k = 0; k < K; k += TILE_SIZE) {
        // 加载 A/B tile 到 SMEM (同 v2-v5 的加载逻辑)
        __syncthreads();

        // 沿 k 维度用 WMMA 迭代
        for (int kk = 0; kk < TILE_SIZE; kk += WMMA_K) {
            // 从 SMEM 用 WMMA load matrix (支持 SMEM 参数)
            wmma::load_matrix_sync(a_frag,
                As + (warp_row - block_row) * (TILE_SIZE + 1) + kk,
                TILE_SIZE + 1);
            wmma::load_matrix_sync(b_frag,
                Bs + kk * (TILE_SIZE + 1) + (warp_col - block_col),
                TILE_SIZE + 1);

            // ★ Tensor Core 矩阵乘加 ★
            wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
        }

        __syncthreads();
    }

    // 写回结果
    wmma::store_matrix_sync(C + warp_row * N + warp_col,
        c_frag, N, wmma::mem_row_major);
}
```

**关键改进**：
- Tensor Core 的 mma_sync 指令在单个周期内完成 16×16×8=2048 次 FMA
- FP16 的 312 TFLOPS 峰值 vs FP32 的 19.5 TFLOPS → 16× 理论加速
- 实际 ~80 TFLOPS (WMMA, 未完全优化) → 还得继续优化才能逼近峰值

---

### 6.7 各版本性能对比总结

```
  GEMM 优化路线图 — 从 0.05 TFLOPS 到 80+ TFLOPS

  TFLOPS
   80 ┤                                                      ★ v6 (TC)
      │
   70 ┤
      │
   60 ┤
      │
   50 ┤
      │
   40 ┤
      │
   30 ┤
      │
   20 ┤                                         ★ v5 (双缓冲)
      │                              ★ v4 (向量化)
   10 ┤                   ★ v3 (线程tiling)
      │        ★ v2 (SMEM)
    0 ┤─★ v0 ─┼─────────┼──────────┼──────────┼──────────┼──────────►
      naive    2 TFLOPS  8 TFLOPS   12 TFLOPS  18 TFLOPS  80+ TFLOPS
      0.05
```

| 版本 | 技术要点 | 核心瓶颈 | 性能 (TFLOPS) | 相对加速 | AI Infra 映射 |
|------|---------|---------|--------------|---------|-------------|
| v0 | 3 层循环, 纯 Global Mem | HBM 延迟, 非合并访问 | ~0.05 | 1× | 原型验证 |
| v1 | Global Mem 合并 | B 的 stride-N | ~0.5 | 10× | 简单 kernel |
| v2 | SMEM Tiling | HBM 带宽, Bank Conflict | ~2 | 40× | 基础融合 kernel |
| v3 | 2D Thread Tiling (8×8) | SMEM 带宽 | ~8 | 160× | Layernorm+Dropout |
| v4 | float4 向量化加载 | SMEM 带宽, 指令开销 | ~12 | 240× | Attention tile 加载 |
| v5 | 双缓冲 + cp.async | 计算瓶颈 | ~18 | 360× | FlashAttention 流水线 |
| v6 | Tensor Cores (WMMA) | Tensor Core 利用率 | ~80+ | 1600× | 生产级 GEMM/Attention |
| **CUTLASS 全优化** | mma.sync + swizzle + 完美流水 | L2 带宽 | ~280+ | 5600× | **生产基准** |

**核心洞察**：
- **Tensor Core 是质变点**：v5→v6 的跳跃 (18→80) 几乎等于前面所有优化的总和
- **每一步解决一个瓶颈**：naive→SMEM (HBM延迟), SMEM→reg tiling (SMEM带宽), reg tiling→向量化 (指令效率), 向量化→双缓冲 (加载延迟), 双缓冲→TC (计算密度)
- **实际生产中不要从头写 GEMM**：使用 CUTLASS。但你需要理解这些优化技术来设计自定义 kernel

---

## 7. 阅读 vLLM 内核

### 7.1 PagedAttention 的核心思想

传统 KV Cache 是连续分配（一个序列 = 一段连续显存），导致严重内存碎片。不同序列长度不同，释放后留下不可用的小块。

PagedAttention 借鉴操作系统的虚拟内存/分页思想：
- KV Cache 分成固定大小的 **Block**（如每 Block 16 个 token）
- 每个序列维护一个 **Block Table**，记录该序列的 KV 数据存在哪些物理 Block
- Attention 计算时，通过 Block Table 查找物理地址，逐 Block 计算

```
传统 KV Cache:
  Seq 1: [████████████████░░░░░░░░░░░░░░░░░░░] ← 预分配大块, 内部碎片
  Seq 2:         [████████░░░░░░░░░░░░░░░░░░░]
  问题: 两个序列都预分配了最大长度, 释放后碎片不可用

Paged KV Cache:
  物理内存: [Block0][Block1][Block2][Block3][Block4][Block5][Block6]...
                │                ▲       ▲
                ▼                │       │
  Seq 1:   [Block0]─────────►[Block3]───►[Block5]  (逻辑序列)
           逻辑 Block 0     逻辑 Block 1  逻辑 Block 2
           Block Table: [0, 3, 5, ...]

  Seq 2:   [Block1]───►[Block2]───►[Block6]  (逻辑序列)
           Block Table: [1, 2, 6, ...]

  利用率: 接近 100% (几乎零碎片), 浪费率 < 4%
```

### 7.2 PagedAttention Kernel 伪代码

```cpp
// ==========================================
// PagedAttention Kernel — 简化伪代码
// 每个 Block 处理 1 个 query token × 1 个 head
// ==========================================

template <typename T, int HEAD_SIZE, int BLOCK_SIZE, int NUM_THREADS>
__global__ void paged_attention_kernel(
    T* out,                    // [num_tokens, num_heads, head_size]
    const T* q,                // [num_tokens, num_heads, head_size]
    const T* k_cache,          // [num_blocks, num_kv_heads, block_size, head_size]
    const T* v_cache,          // [num_blocks, num_kv_heads, block_size, head_size]
    const int* block_tables,   // [num_seqs, max_blocks_per_seq]
    const int* context_lens,   // [num_seqs]
    int max_blocks_per_seq,
    float scale)
{
    // ---------------------------------------------------------
    // 线程组织:
    //   blockIdx → (seq_id, head_id) 索引
    //   threadIdx → 线程在 Block 内的编号
    //   warp_id = threadIdx / 32
    // ---------------------------------------------------------
    const int seq_idx = blockIdx.x;
    const int head_idx = blockIdx.y;
    const int context_len = context_lens[seq_idx];

    // ---------------------------------------------------------
    // SMEM 布局:
    //   q_smem[HEAD_SIZE]:       当前 query 向量 (所有线程共享的 Q)
    //   block_table_smem[...]:   当前序列的 Block Table (缓存)
    //   reduction_buffer[...]:   用于跨 Warp 归约
    // ---------------------------------------------------------
    extern __shared__ char shared_mem[];
    T* q_smem = (T*)shared_mem;
    int* block_table_smem = (int*)(shared_mem + HEAD_SIZE * sizeof(T));
    float* reduction = (float*)(shared_mem + HEAD_SIZE * sizeof(T)
                                + max_blocks_per_seq * sizeof(int));

    // ============ 阶段 1: 加载 Q 到 SMEM + 加载 Block Table ============
    // 多个线程协作加载 Q (每个线程加载一部分维度)
    for (int i = threadIdx.x; i < HEAD_SIZE; i += NUM_THREADS) {
        q_smem[i] = q[seq_idx * num_heads * HEAD_SIZE
                      + head_idx * HEAD_SIZE + i];
    }
    // 加载 Block Table (提前，方便后续查表)
    for (int i = threadIdx.x; i < max_blocks_per_seq; i += NUM_THREADS) {
        block_table_smem[i] = block_tables[seq_idx * max_blocks_per_seq + i];
    }
    __syncthreads();

    // ============ 阶段 2: 在线 Softmax Attention 主循环 ============
    // 每个 warp 负责 K 的不同维度 partition
    constexpr int NUM_WARPS = NUM_THREADS / 32;
    const int warp_id = threadIdx.x / 32;
    const int lane_id = threadIdx.x % 32;

    // 在线 softmax 状态 (每个线程维护自己的)
    float max_logit = -FLT_MAX;
    float exp_sum = 0.0f;
    float acc[PARTITION_SIZE] = {0.0f}; // attention output 累加器

    // 遍历物理 Block (通过 Block Table 间接寻址)
    const int num_blocks = (context_len + BLOCK_SIZE - 1) / BLOCK_SIZE;

    for (int block_idx = 0; block_idx < num_blocks; block_idx++) {

        // ---- 2a. 查 Block Table 获取物理 Block ID ----
        const int physical_block = block_table_smem[block_idx];

        // ---- 2b. 计算 Q · K^T (点积) ----
        // 对于这个物理 Block 内的每个 token:
        const int block_start = block_idx * BLOCK_SIZE;
        const int n_tokens_in_block = min(BLOCK_SIZE,
                                          context_len - block_start);

        // Warp 分工: 每个 warp 负责 HEAD_SIZE/WARP_SIZE 个维度
        // 从 k_cache 读取 (非连续, 通过 physical_block 间接寻址)
        // Q 在 SMEM 中 (低延迟), K 在 Global Memory (HBM) 中
        //
        // for each token j in this block:
        //   for each dim d (本 warp 负责的部分):
        //     qk += q_smem[d] * k_cache[physical_block][kv_head][j][d]
        //   qk *= scale
        //   qk = (j < context_len) ? qk : -inf  // mask padding tokens

        // ---- 2c. 在线 softmax 更新 ----
        // 使用 Warp Shuffle 在 warp 内归约 max_logit 和 exp_sum
        // new_max = max(max_logit, max(q_values_in_block))
        // exp_sum = exp_sum * exp(max_logit - new_max)
        //         + sum(exp(q_value - new_max))
        // acc *= exp(max_logit - new_max)
        // acc += sum(exp(q_value - new_max) * v_value)
        // max_logit = new_max

        // ---- 2d. 用 V 更新 acc ----
        // 利用刚算好的 softmax weight × v_cache 累加到 acc
    }

    // ============ 阶段 3: 最终归约和写回 ============
    // acc /= exp_sum (softmax 归一化)
    // 跨 Warp 归约 (使用 Shared Memory reduction_buffer)
    // 写回 out[seq_idx * num_heads * HEAD_SIZE + head_idx * HEAD_SIZE + ...]
    for (int d = 0; d < PARTITION_SIZE; d++) {
        int global_d = warp_id * PARTITION_SIZE + d;
        if (global_d < HEAD_SIZE) {
            out[seq_idx * num_heads * HEAD_SIZE
                + head_idx * HEAD_SIZE + global_d] = acc[d] / exp_sum;
        }
    }
}
```

### 7.3 关键设计决策与数据流

```
数据流示意图:

  Global Memory (HBM)                           Shared Memory (SRAM)
  ┌──────────────────────┐                     ┌──────────────────────┐
  │                      │     加载 (1次)        │                      │
  │  Q [token×head×dim]  │ ──────────────────► │  q_smem[HEAD_SIZE]   │
  │                      │     (合并访问)        │  (Block 内共享)       │
  │                      │                     │                      │
  │  Block Table         │ ──────────────────► │  block_table_smem    │
  │                      │     加载 (1次)        │  (快速查表)          │
  │                      │                     │                      │
  │  K Cache (Paged)     │ ──────────► 寄存器   │                      │
  │  [block×kv_head×     │   逐 Block 迭代      │  (每次只加载当前      │
  │   block_size×dim]    │   非连续访问          │   Block 的 K tile)   │
  │                      │                     │                      │
  │  V Cache (Paged)     │ ──────────► 寄存器   │                      │
  │  [block×kv_head×     │   逐 Block 迭代       │                      │
  │   block_size×dim]    │                     │                      │
  │                      │                     │                      │
  │  Output              │ ◄── 写回 ─── 寄存器  │                      │
  │  [token×head×dim]    │     (最终结果)       │  (累加在寄存器中)      │
  └──────────────────────┘                     └──────────────────────┘

关键:
  - Q 在 SMEM → 对每个 K tile 都可以低延迟访问 (复用)
  - K/V 在 HBM, 逐 Block 加载 → HBM 访问量 = context_len × head_size
  - Block Table 在 SMEM → 每次查表无需访问 HBM
  - 在线 softmax → 不需要存储 N×N 的 attention matrix (O(N²)→O(N) 显存)
```

| 设计决策 | 原因 | 性能影响 |
|---------|------|---------|
| Paged KV Cache | 消除显存碎片，支持动态 batching | 引入 Block Table 间接寻址，但换来了接近零的显存浪费 |
| Block Table 在 SMEM | 每个 token 都需要查表 | 避免反复从 HBM 读取 Block Table |
| Q 放在 SMEM | Q 在每次点积中都用到 | 每个 K token 计算节省 HEAD_SIZE 次 HBM 读取 |
| 在线 Softmax | 不需要存储整个 attention matrix | 显存从 O(N²) 降到 O(N) |
| Warp 分工 | 每个 Warp 负责 K 的不同维度 partition | 最大化 Warp 级并行 |
| 每个 Block 处理一个 Query Head | 避免跨 Head 的 SMEM 竞争 | Block 分布在更多 SM 上 |

### 7.4 如何阅读 Nsight Compute 对这个 Kernel 的输出

使用 Nsight Compute 分析 PagedAttention kernel 时，关注以下关键指标：

```bash
ncu --set full -o paged_attn_profile \
    --kernel-name paged_attention_kernel \
    python your_benchmark.py
```

**关键指标解读**：

| 指标 | 期望值 | 如果不达标说明 |
|------|--------|---------------|
| `memory_throughput` | 接近 1935 GB/s 的 80-90% | KV Cache 访问不是合并的 → 检查 block 大小和数据布局 |
| `sm__throughput` | > 50% 峰值 | Warp 数量不足 → 调整 block size 和 SMEM 分配 |
| `l1tex__throughput` | > 80% | Q_smem 的使用效率不够 → 检查 Q 是否确实在 SMEM 中 |
| `lts__throughput` (L2) | < 20% | 如果 L2 命中率太低，HBM 访问会成为瓶颈 |
| `dram__throughput` | ≤ 1935 GB/s | 太高说明数据局部性不够 |
| `occupancy` | > 50% (32 warps/SM) | 太低 → SMEM 用得太多或 Block size 太小 |
| `stall_long_scoreboard` | < 30% | 太高 → Global Memory 延迟是瓶颈 |
| `stall_short_scoreboard` | < 20% | 太高 → Shared Memory 延迟是瓶颈 |
| `warp_execution_efficiency` | > 90% | < 90% → 有 Warp Divergence (可能是 causal mask 导致) |

**Roofline 分析**：

```
  TFLOPS
   312 ┤ ┌─────────────────────────────┐  ← FP16 Tensor Core 峰值
       │ │   Memory-Bound      Compute-  │
       │ │     Region           Bound     │
   200 ┤ │    (斜率 = 带宽)     Region    │
       │ │                              │
   100 ┤ │   ★ PagedAttention            │
       │ │   (通常在这附近)              │
    50 ┤ │                              │
       │ │                              │
     0 ┼─┴──────────────────────────────┴───► 算术强度 (FLOPS/Byte)
       0    1    2    4    8   16   32

  PagedAttention 的算术强度 ≈ 1/(2×2) = ~0.25 FLOPS/Byte (memory-bound)
  位于 Roofline 的 Memory-Bound 区域 → 优化方向是减少 HBM 访问
```

---

## 8. 调试与性能分析

### 8.1 compute-sanitizer (GPU 内存错误检测)

`compute-sanitizer` 是 NVIDIA 的 GPU 端内存错误检测工具（替代旧的 cuda-memcheck）。

```bash
# 内存越界检查 (最常用)
compute-sanitizer --tool memcheck ./your_program

# 输出示例:
# ========= COMPUTE-SANITIZER
# ========= Invalid __global__ read of size 4 bytes
# =========     at 0x1a0 in kernel.cu:42:myKernel
# =========     by thread (15,0,0) in block (3,0,0)
# =========     Address 0x7f1234000000 is out of bounds
# =========     读取地址越界! 行号、线程号、Block号都给出了

# Race condition 检查 (Shared Memory 和 Global Memory 的 data race)
compute-sanitizer --tool racecheck ./your_program

# 常用组合: 同时检查 memcheck + racecheck + initcheck
compute-sanitizer --tool memcheck,racecheck,initcheck ./your_program

# 常见参数:
# --target-processes all          : 检查所有子进程
# --launch-timeout 0              : 无限等待 kernel 启动
# --report-mode summary           : 只输出摘要
```

**常见错误类型**：
- **Out-of-bounds access**: 线程索引计算错误，越界读写
- **Misaligned address**: Tensor Core 数据未对齐
- **Use of uninitialized memory**: SMEM 或 register 未初始化就读取
- **Race condition**: 多个线程无同步地写同一地址 (缺少 `__syncthreads()`)

### 8.2 cuda-gdb 基础

cuda-gdb 是 NVIDIA 的 CUDA 专用调试器（基于 GDB）。

```bash
# 编译时加调试信息
nvcc -g -G -o my_program my_kernel.cu

# -g: 主机端调试信息
# -G: 设备端调试信息 (会禁用优化, 性能大幅下降)

# 启动 cuda-gdb
cuda-gdb ./my_program

# ========== 常用命令 ==========

# 设置断点
(cuda-gdb) break myKernel          # 在 kernel 入口设断点
(cuda-gdb) break kernel.cu:42      # 在特定行设断点

# 查看当前线程和 Block
(cuda-gdb) info cuda threads       # 列出所有活跃线程
(cuda-gdb) info cuda blocks        # 列出所有活跃 Block
(cuda-gdb) cuda thread (0,0,0)     # 切换到特定线程

# 查看寄存器和内存
(cuda-gdb) info registers          # 查看寄存器
(cuda-gdb) print my_var            # 打印变量值
(cuda-gdb) print/x *(float*)0x...  # 查看特定地址

# 查看 Shared Memory
(cuda-gdb) info cuda shared_memory # 查看当前 Block 的 SMEM

# 继续执行
(cuda-gdb) continue
(cuda-gdb) step                     # 单步 (所有线程)
(cuda-gdb) cuda step                # 单步 (当前线程, 其他暂停)

# 条件断点
(cuda-gdb) break kernel.cu:42 if threadIdx.x == 0 && blockIdx.x == 0
```

### 8.3 Nsight Systems (系统级性能分析)

Nsight Systems 提供**时间线视图**，显示 CPU 和 GPU 上的所有活动。

```bash
# 收集系统级 profile
nsys profile --stats=true -o my_profile ./your_program

# 常用参数:
# --trace=cuda,nvtx,osrt       : 追踪 CUDA API + NVTX 标记 + OS 运行时
# --capture-range=cudaProfilerApi  : 只在 cudaProfilerStart/Stop 之间收集
# --cuda-memory-usage=true      : 追踪 GPU 显存使用

# 在 Python 脚本中:
nsys profile --stats=true \
    --trace=cuda,nvtx,osrt,cublas,cusparse,cudnn \
    -o my_profile \
    python benchmark.py
```

**时间线分析要点**：
- **CPU-GPU Gap**: CPU 提交 Kernel 到 GPU 开始执行之间的延迟
- **Kernel Duration**: 每个 Kernel 在 GPU 上的执行时间
- **Copy Overlap**: 拷贝操作是否和 Kernel 计算重叠
- **Idle Gap**: GPU 空闲的时间段（可能是 CPU 端瓶颈）

### 8.4 Nsight Compute (Kernel 级性能分析)

Nsight Compute 是最重要的**Kernel 级性能分析工具**，提供逐指令的性能指标。

```bash
# 基础用法: 分析特定 Kernel
ncu --kernel-name myKernel -o my_kernel_profile ./your_program

# 收集完整指标 (数据量大，时间较长)
ncu --set full -o my_kernel_profile ./your_program

# 只收集关键指标 (快速)
ncu --set basic -o my_kernel_profile ./your_program

# 指定 GPU
ncu --target-processes all --device 0 -o profile ./your_program

# Python 中分析
ncu --set full \
    --kernel-name regex:paged_attention \
    -o pa_profile \
    python benchmark.py

# 输出报告
ncu --import my_kernel_profile.ncu-rep  # 打开 GUI
ncu --page details --csv my_kernel_profile.ncu-rep > report.csv  # 导出 CSV
```

**Speed of Light (SOL) 指标**是最快速的诊断入口：

```
Nsight Compute SOL 输出示例:

  Section: Speed Of Light
  ------------------------
  Memory Throughput:  85.3%  ← 使用了 85% 的 HBM 带宽
  Compute Throughput: 12.1%  ← 使用了 12% 的计算能力
  → 结论: 这是一个 Memory-Bound kernel!

  Section: Memory Workload Analysis
  ---------------------------------
  L1 Cache Hit Rate:    28.5%  ← 不高, 说明数据局部性不好
  L2 Cache Hit Rate:    45.2%
  HBM Throughput:       1647 GB/s  ← 接近峰值 (1935)
  → 确认: HBM 带宽是瓶颈

  Section: Occupancy
  ------------------
  Theoretical Occupancy: 75% (48/64 warps)
  Achieved Occupancy:    72.3%
  → Occupancy 还好, 问题不在 Occupancy
```

### 8.5 实际分析一个慢 Kernel 的步骤

```
  1. 先用 Nsight Systems (nsys) 找到最慢的 Kernel
     ↓ 找出哪个 Kernel 占用了最多的 GPU 时间
  2. 用 Nsight Compute (ncu) 分析这个 Kernel
     ↓
  3. 看 SOL (Speed of Light) 确定 Memory-Bound 还是 Compute-Bound
     ↓
     ├── Memory-Bound:
     │   ├── 检查合并访问 (coalescing)
     │   ├── 检查 L1/L2 命中率
     │   ├── 增加数据复用 (tiling, SMEM)
     │   └── 使用向量化加载 (float4)
     │
     └── Compute-Bound:
         ├── 检查 Tensor Core 利用率
         ├── 检查 Occupancy
         ├── 检查 Warp Divergence
         └── 使用更低精度 (FP16/INT8)
     ↓
  4. 修改代码 → 重新 Profile → 验证改进
     ↓ (迭代直到满意)
  5. 如果接近 Roofline 限制 (85%+ 峰值), 考虑算法层面的优化
```

### 8.6 常见 Bug 总结

| Bug 类型 | 症状 | 检测工具 | 修复方法 |
|---------|------|---------|---------|
| 越界访问 | 随机错误 / segmentation fault | compute-sanitizer memcheck | 加边界检查 `if (tid < N)` |
| Data Race | 非确定性结果 | compute-sanitizer racecheck | 加 `__syncthreads()` |
| 未初始化内存 | NaN / 随机值 | compute-sanitizer initcheck | 初始化寄存器/ SMEM |
| Bank Conflict | 性能低于预期 | Nsight Compute | Padding / Swizzle |
| Warp Divergence | 某些 warp 很慢 | Nsight Compute | 重构分支, 对齐 warp 边界 |
| 非合并访问 | 带宽利用率低 | Nsight Compute | 改数据布局或线程索引 |
| 寄存器溢出 (lmem) | 性能骤降 | `--ptxas-options=-v` | 减少局部变量, 拆分 kernel |

### 8.7 与 AI Infra 的关联

- **compute-sanitizer 是开发自定义 Kernel 的必备工具**：在 vLLM/FlashInfer 中开发新的自定义 Kernel 时，第一步就是确保没有内存错误
- **nsys 发现系统级瓶颈**：CPU 端的 tokenizer / scheduler 开销，GPU 空闲窗口，stream 依赖关系
- **ncu 指导 Kernel 级优化**：判断 kernel 是 Memory-Bound 还是 Compute-Bound 直接决定优化方向
- **SOL 指标是快速诊断工具**：如果 Memory 利用率高而 Compute 利用率低，优化方向是减少 HBM 访问

---

## 9. 易混淆技术辨析

### 9.1 SMEM vs L1 Cache vs Register

这三者都在 GPU 片上（on-chip），但容量、延迟、控制和共享范围完全不同。

```
                         Register         L1 Cache        Shared Memory
                         ─────────        ────────        ──────────────
  容量 (per SM)          256 KB           164 KB (合并)    164 KB (合并)
  延迟                   0 cycles         ~30 cycles       ~30 cycles
  控制方式               编译器自动        硬件自动         程序员显式 (__shared__)
  共享范围               单线程            全 SM            Block 内线程
  带宽                   约 8 TB/s         约 20 TB/s       约 20 TB/s
  Bank Conflict          无               可能 (硬件处理)   需要注意 (且最常见)
  可配置性               无法手动分配      可与 SMEM 配比   可与 L1 配比
  AI Infra 典型用途      累加器、临时变量   自动缓存全局数据  FlashAttention tile
```

| 维度 | Register | L1 Cache | Shared Memory |
|------|----------|----------|---------------|
| 何时用 | 任何局部变量自动分配 | 透明的全局内存缓存 | 需要 block 内数据复用 |
| 如何声明 | 无需特殊声明 | 无需声明，自动 | `__shared__ float arr[N]` |
| 是否跨线程可见 | 否 | 是（硬件级） | 是（代码级，需 `__syncthreads`） |
| 溢出后果 | 自动到 Local Memory (HBM!) | Cache miss 到 L2 | 编译报错（超限） |
| 速度 | 最快 | 快 | 快（需注意 Bank Conflict） |

**决策表：**

| 场景 | 用什么 | 原因 |
|------|--------|------|
| 单线程内多次使用的标量 | Register | 零延迟，编译器自动处理 |
| Block 内线程需共享的数据 | SMEM | 程序员控制，按 tile 粒度加载 |
| warp 内广播（shuffle） | Register | `__shfl_sync` 直接操作寄存器，零 SMEM 开销 |
| 大数组无法放入 SMEM | L1 Cache | 让硬件自动缓存，程序员无法控制但至少透明 |
| 需要跨 kernel 调用的数据 | Global Memory | SMEM 和 Register 在 kernel 结束时消失 |

### 9.2 Warp vs Thread Block vs Grid

```
层级关系:

    Grid (整个 kernel 的任务空间)
    ├── Thread Block 1 ───── 分配到 SM1 上执行
    │   ├── Warp 0 (32 threads)
    │   ├── Warp 1 (32 threads)
    │   └── ...
    ├── Thread Block 2 ───── 分配到 SM2 上执行
    │   ...
    └── Thread Block N ───── 当 SM 空闲时动态分配

核心约束:
  - Block 内的线程可以在 SMEM 上协作（__syncthreads）
  - 不同 Block 之间无法直接同步
  - Block 和 SM 是多对多映射
  - Warp 不可分割：始终 32 线程，不可手动创建
```

| 维度 | Warp | Thread Block | Grid |
|------|------|-------------|------|
| 线程数 | 固定 32 | 用户指定 (≤1024) | 用户指定 |
| 调度单位 | 是，由 Warp Scheduler 调度 | GPU 分配给 SM | 不直接调度 |
| 同步机制 | 隐式锁步，warp shuffle | `__syncthreads()` | 无法在 grid 级同步 |
| 共享内存范围 | 通过 shuffle 交换 | `__shared__` | 无 |
| AI Infra 中的角色 | softmax/归约的核心 | attention tile 协作 | 并行处理多个 token/head |
| 何时出问题 | Warp Divergence（分支发散） | Bank Conflict、Occupancy | Grid 太小导致 SM 空闲 |

### 9.3 Tensor Core vs CUDA Core

| 维度 | CUDA Core | Tensor Core |
|------|-----------|-------------|
| 执行的操作 | 单次 FMA (a×b+c) | 小矩阵乘加 D=A×B+C |
| 每个指令的 FMA 数 | 1 (FP32/FMA) | 2048 (FP16 m16n8k16) |
| 编程方式 | 普通 C++ 代码 | WMMA API 或 mma.sync PTX |
| 精度支持 | FP32, FP64, INT32 | TF32, FP16, BF16, INT8, INT4, FP8 |
| 数据对齐要求 | 无特殊要求 | K 维度必须对齐到 tile K (如 16)，16 字节对齐 |
| 吞吐 (A800, FP16) | 19.5 TFLOPS | 312 TFLOPS (16x!) |
| 适合操作类型 | element-wise, reduction | 矩阵乘法, 卷积 |
| Transformer 中使用 | RMSNorm, SiLU, softmax | QKV 投影, attention score, FFN |

**决策表：**

| 你看的操作 | 用哪个 | 原因 |
|-----------|--------|------|
| `C = A @ B` (矩阵乘法) | Tensor Core | 16x 吞吐提升 |
| `y = x + residual` (element-wise) | CUDA Core | Tensor Core 不支持标量操作 |
| softmax, layer norm | CUDA Core + shuffle | 归约操作不需要矩阵乘加 |
| GEMM + ReLU 融合 | Tensor Core + epilogue | TC 做乘法，CUDA Core 做激活函数 |
| `gate * up` (SwiGLU) | CUDA Core | 逐元素乘积 |

---

## 10. AI Infra 专家视角

### 10.1 性能瓶颈排查流程

当自定义 kernel 或整个推理 pipeline 达不到预期性能时，按以下决策树排查：

```
                               ┌─────────────────────────┐
                               │ Kernel 性能不符合预期    │
                               └────────────┬────────────┘
                                            │
                               ┌────────────▼────────────┐
                               │ 1. 先用 nsys 定位最慢    │
                               │    Kernel (时间线视图)   │
                               │ nsys profile --stats=true│
                               └────────────┬────────────┘
                                            │
                               ┌────────────▼────────────┐
                               │ 2. 用 ncu 分析该 Kernel  │
                               │ ncu --set basic -o p ... │
                               │ 看 Speed of Light 指标   │
                               └────────────┬────────────┘
                                            │
                     ┌──────────────────────┼──────────────────────┐
                     ▼                                             ▼
         Memory Throughput > 70%                         Compute Throughput > 70%
         → Memory-Bound Kernel                           → Compute-Bound Kernel
                     │                                             │
     ┌───────────────┼───────────────┐                 ┌───────────┼───────────┐
     ▼                               ▼                 ▼                       ▼
┌─────────┐                    ┌──────────┐     ┌───────────┐          ┌────────────┐
│检查合并访│                    │检查数据复用│     │检查 Occupancy│          │检查精度/指令│
│问 (Coal.)│                    │(SMEM tiling)│   │ncu occup.   │          │ncu workb.  │
└────┬────┘                    └────┬─────┘     │太少 warps   │          │是否用了 TC │
     │                              │           └──────┬──────┘          └─────┬──────┘
     ▼                              ▼                  ▼                       ▼
┌───────────┐              ┌─────────────┐   ┌─────────────┐         ┌────────────┐
│连续线程访问│              │用 SMEM 做 tiling│  │减少寄存器使用 │         │确保数据对齐到│
│连续地址    │              │每个 block 共享 │  │/SMEM 使用    │         │TC 要求      │
│stride=1    │              │同一块数据      │  │增大 block size│         │(K%16=0等)  │
└───────────┘              └─────────────┘   └─────────────┘         └────────────┘
```

**常见 ncu 指标解读：**

| 指标 | 健康值 | 报警值 | 应对措施 |
|------|--------|--------|---------|
| `stall_long_scoreboard` | < 30% | > 60% | Global Memory 延迟是瓶颈，增加 SMEM tiling |
| `stall_short_scoreboard` | < 20% | > 40% | Shared Memory 延迟是瓶颈，检查 Bank Conflict |
| `l1tex__throughput` | > 50% | < 20% | L1 cache 利用率低，数据可能没进 L1 |
| `sm__throughput` | > 50% | < 20% | SM 空闲太多，增大 grid size 或 block size |
| `warp_execution_efficiency` | > 90% | < 70% | 有严重 Warp Divergence，检查分支逻辑 |
| `achieved_occupancy` | > 50% | < 25% | 寄存器或 SMEM 用太多，限制了并发 warp |

**内存泄漏检测（开发新 kernel 的第一步）：**
```bash
# 编译时必须用 -G 保留调试信息
nvcc -g -G -o test_kernel kernel.cu

# 三步检查
compute-sanitizer --tool memcheck ./test_kernel    # 越界访问
compute-sanitizer --tool racecheck ./test_kernel   # 数据竞争
compute-sanitizer --tool initcheck ./test_kernel   # 未初始化内存
```

### 10.2 A800 部署实操：FlashAttention Kernel 在单卡上的性能验证

以下通过 Nsight Compute 分析一个自实现的 GEMM kernel，展示 CUDA 编程文档中所有概念的实际落地。

**环境：**
- 硬件：1x NVIDIA A800 80GB
- CUDA：12.1+
- 目标：验证 FP16 GEMM kernel 的 Tensor Core 利用率

**编译与分析流程：**
```bash
# 1. 编译 (确保针对 sm_80 架构，启用 FMAD 优化)
nvcc -arch=sm_80 -O3 --use_fast_math \
     -o gemm_bench gemm_kernel.cu

# 2. 快速检查基本指标
ncu --set basic --kernel-name gemm_v6_tensorcore \
    -o gemm_profile ./gemm_bench

# 3. 深入分析 Tensor Core 利用率
ncu --set full \
    --section SpeedOfLight \
    --section TensorPipeUtilization \
    --section Occupancy \
    --kernel-name gemm_v6_tensorcore \
    -o gemm_full_profile ./gemm_bench

# 4. 查看报告
ncu --page details gemm_full_profile.ncu-rep
```

**预期 ncu 输出解读（A800 FP16 GEMM, M=N=K=4096）：**

```
Section: Speed Of Light
────────────────────────────────────────────────
  Memory Throughput:   35.2%  ← GEMM 是 compute-bound，内存使用合理
  Compute Throughput:  68.5%  ← 相对 312 TFLOPS 峰值，达到约 214 TFLOPS
  → Kernel 是 Compute-Bound，优化方向是提高 TC 利用率

Section: Tensor Pipe Utilization
────────────────────────────────────────────────
  Tensor Active:       72.3%  ← Tensor Core 活跃占比，不错
  Tensor Issue Active: 68.1%  ← TC 指令发射占比
  → 还能提升：增加 tile size、减少 SMEM 同步

Section: Occupancy
────────────────────────────────────────────────
  Theoretical Occupancy: 75.0%  (48 / 64 warps)
  Achieved Occupancy:    68.2%
  → 瓶颈：每线程寄存器使用量（64 registers/thread）限制了 Occupancy

Section: Memory Workload Analysis
────────────────────────────────────────────────
  L1 Hit Rate:    85.3%  ← SMEM tiling 工作良好
  L2 Hit Rate:    92.1%  ← 大部分 L1 miss 被 L2 消化
  HBM Throughput: 678 GB/s / 1935 GB/s = 35.0%  ← 非瓶颈
```

**关键优化 Action：**
```
如果 Tensor Active < 60%:
  → 增大 tile 尺寸 (TILE_SIZE 从 128→256)
  → 减少 __syncthreads() 数量 (合并 tile 迭代)
  → 使用 cp.async 做流水线加载

如果 Occupancy < 50%:
  → 减少寄存器使用 (拆分过大的局部结构体)
  → 减少 SMEM 分配 (动态 SMEM 而非静态大数组)
  → 调小 THREAD_TILE_M/N

如果 L1 Hit Rate < 50%:
  → 增大 SMEM tile 尺寸
  → 确保 SMEM 访问无 Bank Conflict (加 Padding)
  → 检查数据复用率 (SMEM 用完即弃 vs 多次复用)
```

**单卡 FP16 GEMM 性能基准（A800, M=N=K=4096）：**
```
  v0 (naive):             0.05 TFLOPS  (峰值 0.02%)
  v2 (SMEM tiling):       2.0  TFLOPS  (峰值 0.6%)
  v4 (float4 vectorized): 12   TFLOPS  (峰值 3.8%)
  v5 (double buffering):  18   TFLOPS  (峰值 5.8%)
  v6 (Tensor Cores):      80   TFLOPS  (峰值 25.6%)
  cuBLAS (官方):          260+ TFLOPS  (峰值 83%+) ← 生产基准
  CUTLASS (开源):         280+ TFLOPS  (峰值 90%+) ← 生产基准
```

---

## 11. 深入学习资源

### 9.1 必读官方文档

| 文档 | 内容 | 优先级 |
|------|------|-------|
| [CUDA C++ Programming Guide](https://docs.nvidia.com/cuda/cuda-c-programming-guide/) | CUDA 编程核心指南，涵盖所有 API、内存模型、执行模型 | ★★★★★ 必读 |
| [CUDA C++ Best Practices Guide](https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/) | 性能优化最佳实践 | ★★★★★ 必读 |
| [CUDA PTX ISA Reference](https://docs.nvidia.com/cuda/parallel-thread-execution/) | PTX 指令集参考（Tensor Core 底层编程必备） | ★★★★ |
| [CUDA Math API](https://docs.nvidia.com/cuda/cuda-math-api/) | 数学函数 API (exp, sin, etc.) | ★★★ |
| [NVIDIA Tensor Core Documentation](https://docs.nvidia.com/cuda/cuda-c-programming-guide/index.html#wmma) | WMMA API 文档 | ★★★★ |

### 9.2 经典书籍

| 书名 | 作者 | 适合阶段 | 特点 |
|------|------|---------|------|
| 《Programming Massively Parallel Processors》(第4版) | David Kirk / Wen-mei Hwu | 入门-进阶 | GPU 并行计算的哈佛教材，从原理到实践 |
| 《Professional CUDA C Programming》 | John Cheng, Max Grossman, Ty McKercher | 进阶 | CUDA 编程全面教材，代码详尽 |
| 《CUDA Programming: A Developer's Guide》 | Shane Cook | 进阶 | 偏向工程实践 |
| 《Parallel Computing in CUDA C》 (NVIDIA 官方培训) | NVIDIA | 入门 | 快速入门 |

### 9.3 关键博客和教程

| 资源 | 链接 | 内容 |
|------|------|------|
| **Simon Boehm 的 GEMM 优化系列** | https://siboehm.com/articles/22/CUDA-MMM | 手把手从 0 优化 GEMM 到 CUTLASS 水平，必读！ |
| **Lei Mao 的 CUDA 笔记** | https://leimao.github.io/blog/CUDA/ | 清晰简洁的 CUDA 概念解释，各种优化技术的代码示例 |
| **NVIDIA Technical Blog (CUDA 标签)** | https://developer.nvidia.com/blog/tag/cuda/ | 深度技术文章，涵盖新架构特性、性能优化案例 |
| **Horace He 的 GPU 优化博客** | https://horace.io/ | Triton 和 GPU 编程实战，对理解 Attention kernel 优化极有帮助 |
| **CUTLASS 官方文档** | https://github.com/NVIDIA/cutlass | 生产级 GEMM 实现，学习 Pipeline、Epilogue、Swizzle 技术 |
| **Colfax Research CUDA 教程** | https://research.colfax-intl.com/ | 高质量 CUDA 教程和优化指南 |

### 9.4 重要开源项目 (阅读源码)

| 项目 | 关键路径 | 学习重点 |
|------|---------|---------|
| **vLLM** | `csrc/attention/attention_kernels.cu` | PagedAttention 完整实现 |
| **vLLM** | `csrc/cache_kernels.cu` | KV Cache 管理、Block Table 操作 |
| **vLLM** | `csrc/quantization/` | INT8/INT4/FP8 量化 GEMM |
| **FlashAttention** | `csrc/flash_attn/src/flash_fwd_kernel.h` | Forward pass 的 tiling、scheduling、pipeline |
| **FlashAttention** | `csrc/flash_attn/src/flash_bwd_kernel.h` | Backward pass 的 recomputation 策略 |
| **FlashInfer** | `csrc/*.cu` | 高性能 Attention、Sampling、Page Table 操作 |
| **CUTLASS** | `include/cutlass/gemm/kernel/` | 生产级 GEMM 模板抽象 |
| **CUTLASS** | `include/cutlass/gemm/collective/` | Pipeline 和异步拷贝实现 |
| **llama.cpp** | `ggml-cuda/` | 轻量级 CUDA 推理 Kernel（对比学习） |
| **TensorRT-LLM** | `cpp/tensorrt_llm/kernels/` | 商业级推理 Kernel 实现 |

### 9.5 建议学习路线

```
第一阶段: CUDA 基础 (2-3 周)
├── 阅读 CUDA C++ Programming Guide 前 5 章
├── 手写向量加法、归约、转置、矩阵乘法 (naive)
├── 理解内存模型、线程组织、Warp 概念
├── 使用 Nsight Compute 分析自己的 Kernel
└── 目标: 能写出正确的 CUDA Kernel

第二阶段: 性能优化核心 (3-4 周)
├── 学习 Shared Memory Tiling 技术
├── 实现 GEMM v2-v4 (SMEM tiling → register tiling → vectorized)
├── 学习 Bank Conflict 和 Padding 技术
├── 学习 Warp Shuffle 和 Warp Reduction
├── 学习 Roofline Model 和 Memory/Compute Bound 判断
└── 目标: 能将一个 naive GEMM 优化到 ~12 TFLOPS (FP32)

第三阶段: Tensor Core 和高级特性 (2-3 周)
├── 学习 WMMA API → 实现 Tensor Core GEMM
├── 学习 mma.sync PTX 指令
├── 学习 cp.async 和 pipeline (双缓冲)
├── 学习 CUDA Graphs
├── 阅读 CUTLASS 源码 (至少理解 Pipeline 和 Collective 概念)
└── 目标: 能用 Tensor Cores 写出 80+ TFLOPS 的 GEMM

第四阶段: 生产系统深入 (持续)
├── 阅读 vLLM 的 PagedAttention Kernel 实现
├── 阅读 FlashAttention 的 forward kernel
├── 阅读 FlashInfer 的优化技巧
├── 尝试为 vLLM 贡献一个小的 kernel 优化
├── 学习 Triton 语言 (对比理解 CUDA 和 Triton 的抽象层级)
└── 目标: 能独立设计和优化 AI Infra 中的自定义 Kernel
```

### 9.6 最终总结：CUDA 知识与 AI Infra 方向的对应关系

| AI Infra 方向 | 核心 CUDA 知识 | 典型应用 |
|--------------|---------------|---------|
| **推理引擎开发** | Tensor Core, SMEM tiling, Warp 原语, CUDA Graphs | FlashAttention, PagedAttention, Fused MoE |
| **训练框架开发** | NCCL, NVLink, Multi-GPU, Stream 并发 | 梯度 AllReduce, 数据加载 pipeline |
| **模型量化部署** | INT4/INT8 Tensor Core, 自定义反量化 Kernel | W4A16/W8A8 GEMM, GPTQ/AWQ kernel |
| **分布式系统** | GPUDirect RDMA, NVSwitch, Multi-Node | 跨节点推理, 分布式 KV Cache |
| **性能分析** | Nsight Systems, Nsight Compute, Roofline | 所有上述方向的性能瓶颈诊断 |

**最重要的建议**：不要只读文档，一定要写代码。从最简单的向量加法开始，逐步实现你自己的 GEMM 优化版本。每优化一步，用 Nsight Compute 验证你的假设。**理解为什么性能提升了，比达到某个性能数字重要得多。** 当你能自信地解释每一行 CUDA 代码在硬件上的行为时，你就掌握了 AI Infra 的核心技能。

---

*本文档涵盖了 AI Infra GPU 编程的核心知识体系，建议结合 NVIDIA 官方文档和真实框架源码一起学习。GPU 编程是一门"理解硬件"的艺术——只有深刻理解 SM、Warp、Tensor Core 和内存层级，才能真正写出高性能的 AI Infra 内核。*

*持续更新于 2026-07*
