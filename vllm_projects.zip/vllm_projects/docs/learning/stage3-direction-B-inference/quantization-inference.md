# 推理量化：从原理到部署的完整指南

> **目标读者**：需要将 33B/67B 大模型部署到有限 GPU 资源上的工程师。本文从数值表示的基础概念讲起，逐步深入到 GPTQ、AWQ、GGUF、FP8 等量化方法，最后给出可操作的部署方案。
>
> **前置知识**：了解 Transformer 架构、熟悉 Python、用过 vLLM 或类似推理框架。
>
> **学习方式**：本文适合慢速深度阅读。每个概念都有 ASCII 图解、伪代码、真实命令和 benchmark 数据。建议跟着敲一遍代码。

---

## 白话引入：照片压缩的启示

想象你手机里有一张 20MB 的 RAW 格式照片。你想发朋友圈，但原图太大——流量扛不住、上传太慢、对方加载也卡。于是你把它导出为 JPEG——文件变成了 1MB，但看起来几乎一样清晰。

JPEG 是怎么做到的？它利用了人眼的两个弱点：对亮度细节敏感，对颜色细节迟钝；对大块色块敏感，对高频纹理迟钝。于是 JPEG 大胆地扔掉了那些"人眼看不出来"的信息——色度下采样、DCT 变换后量化高频分量。你得到了一张肉眼看不出区别但体积缩小 20 倍的照片。

**模型量化（Quantization）就是大模型的 JPEG 压缩。**

一个 33B 参数的模型，用 FP16 存储要 66GB 显存，两张 A800 才能勉强跑起来。但经过 4-bit 量化后，权重只有 16.5GB，单卡就能跑，而且效果几乎没有区别——因为大模型的参数中也存在大量"模型看不出来"的冗余精度。模型在训练时学到了 16 位精度的权重，但推理时用 4 位精度就够了——就像照片用 8 位 JPEG 就够了。

```
原始照片 (RAW 20MB)      →  JPEG 压缩  →  1MB (肉眼无损)
FP16 模型权重 (66GB)     →  INT4 量化  →  16.5GB (精度近乎无损)
```

量化之所以可行，背后有两条核心原理：
1. **大模型参数冗余度极高**：70B 模型的 INT4 量化精度损失通常小于 0.5%，因为参数够多，容错空间大。
2. **推理是 Memory-Bound**：Decode 阶段，GPU 大部分时间在等显存搬运数据，而不是在计算。权重从 16-bit 减到 4-bit，读取量直接减半，decode 速度反而变快。

本文从浮点数表示原理讲起，深入到 GPTQ、AWQ、GGUF、FP8 等业界主流方案，最后给出可在 A800 上直接部署的 33B 模型实操方案。

---

## 术语预检

在深入学习前，确保你理解以下核心术语：

| 术语 | 英文 | 一句话解释 |
|------|------|-----------|
| **量化** | Quantization | 将浮点数权重映射到低精度整数（如 INT4），以减小模型体积和加速推理 |
| **反量化** | Dequantization | 推理时将整数权重恢复为浮点数（或直接在整数域计算），恢复公式：`x_fp = x_int × scale + zero_point` |
| **Scale / Zero Point** | Scale / Zero Point | 量化的两个核心参数：scale 控制映射的比例尺，zero_point 控制映射的零点偏移 |
| **校准数据** | Calibration Data | 用来统计激活值分布的代表性数据，决定 scale 和 zero_point 的质量，通常需要 128-256 个样本 |
| **PTQ (后训练量化)** | Post-Training Quantization | 不重新训练，只用少量校准数据对已训练好的模型做量化。GPTQ、AWQ、GGUF 都属于此类 |
| **W4A16 / W8A8** | Weight-bit / Activation-bit | W4A16 表示权重 4-bit、激活 16-bit（仅权重量化）；W8A8 表示权重和激活都 8-bit（需要硬件支持 FP8） |

---

## 目录

1. [为什么推理需要量化](#1-为什么推理需要量化)
2. [数值表示格式详解](#2-数值表示格式详解)
3. [权重量化方法](#3-权重量化方法)
   - 3.1 [GPTQ：基于 Hessian 的后训练量化](#31-gptq基于-hessian-的后训练量化)
   - 3.2 [AWQ：激活感知权重量化](#32-awq激活感知权重量化)
   - 3.3 [GGUF/GGML：llama.cpp 生态](#33-ggufggmllamacpp-生态)
4. [量化粒度：Per-Tensor / Per-Channel / Per-Group](#4-量化粒度per-tensor--per-channel--per-group)
5. [GPTQ Marlin Kernel：极致性能](#5-gptq-marlin-kernel极致性能)
6. [FP8 推理：Hopper 架构专属](#6-fp8-推理hopper-架构专属)
7. [vLLM 中部署量化模型](#7-vllm-中部署量化模型)
8. [精度评估](#8-精度评估)
9. [33B 模型部署实操方案](#9-33b-模型部署实操方案)
10. [深入学习资源](#10-深入学习资源)

---

## 1. 为什么推理需要量化

### 1.1 显存是最硬的约束

大语言模型的权重以浮点数存储。以 33B 参数模型为例，不同精度下的显存占用：

```
FP32:  33B × 4 bytes = 132 GB    ██████████████████████████████████████████████████████████████████
FP16:  33B × 2 bytes =  66 GB    █████████████████████████████████
BF16:  33B × 2 bytes =  66 GB    █████████████████████████████████
INT8:  33B × 1 byte  =  33 GB    █████████████████
INT4:  33B × 0.5 B   =  16.5 GB  ████████
```

**这还不包括 KV Cache。** KV Cache 的计算公式：

```
KV Cache (bytes) = 2 × num_layers × hidden_dim × max_seq_len × dtype_bytes × batch_size

示例 (33B, 类似 Qwen2.5-32B, hidden_dim=5120, num_layers=64, context=8192, batch=8, FP16):
= 2 × 64 × 5120 × 8192 × 2 × 8
≈ 17.2 GB  ← 仅 KV Cache！
```

**总显存 = 模型权重 + KV Cache + 激活值（临时）**

```
┌──────────────────────────────────────────────────────────────────────┐
│                   A100/A800 (80GB) 单卡资源分配                       │
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  FP16 33B in vLLM:                                                   │
│  ┌───────────────────┬──────────────────┬───────────────────────────┐│
│  │ 模型权重 66GB      │ KV Cache ~17GB   │ 激活 ~6GB → 总计 ~89GB    ││
│  │ █████████████████  │ ██████████       │ ████                     ││
│  └───────────────────┴──────────────────┴───────────────────────────┘│
│  ❌ 超出一张 A800 (80GB)，至少需要 2 卡 TP                            │
│                                                                      │
│  INT4 33B in vLLM:                                                    │
│  ┌───────────────────┬──────────────────┬───────────────────────────┐│
│  │ 模型权重 16.5GB    │ KV Cache ~17GB   │ 激活 ~6GB → 总计 ~39.5GB  ││
│  │ ████████           │ ██████████       │ ████                     ││
│  └───────────────────┴──────────────────┴───────────────────────────┘│
│  ✅ 轻松放入一张 A800，剩余 40GB 可增大 batch_size 或 context_len     │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 1.2 推理的两个阶段与量化收益

大模型推理分为两个阶段，它们的性能瓶颈不同：

```
                    Prefill（预填充）               Decode（逐 token 生成）
                    ──────────────                  ─────────────────────
                    输入: "今天天气"                 已生成: "今天天气很好"
                    一次处理所有 token              每次生成 1 个 token
                          │                              │
                    瓶颈: 计算能力                  瓶颈: 显存带宽
                    (Compute-Bound)               (Memory-Bound)
                          │                              │
                    量化效果:                       量化效果:
                    可能有开销                      大幅加速！
                    (反量化需计算)                  (读权重时间减半)
```

**为什么 Decode 阶段是 Memory-Bound？**

```
算术强度 (Arithmetic Intensity) = FLOPs / Bytes Read

Decode 阶段 (batch=1, hidden=5120, FFN=4×hidden):
  计算量 = 2 × hidden² × (1 + 4) = 10 × 5120² ≈ 262M FLOPs
  读取量 = hidden² × 2 bytes = 5120² × 2 ≈ 52 MB  (FP16)
  算术强度 = 262M / 52M ≈ 5 FLOPs/Byte

A800 算力: 312 TFLOPS (FP16) → 312T / 5 ≈ 62 TB/s 所需带宽
A800 带宽: 2 TB/s → 实际只能达到 2T × 5 ≈ 10 TFLOPS
                         ─────────────────────────────
                         只用了 3% 的算力！瓶颈全在带宽。

INT4:
  读取量 = 5120² × 0.5 bytes ≈ 13 MB
  算术强度 = 262M / 13M ≈ 20 FLOPs/Byte
  所需带宽变为 312T / 20 = 15.6 TB/s → 还是带宽瓶颈
  但带宽需求降低 75% → decode 吞吐提升 2-4x！
```

### 1.3 量化收益汇总

```
┌─────────────────────────────────────────────────────────────────────┐
│                      量化收益与代价                                   │
├────────────┬────────────────────────┬────────────────────────────────┤
│  维度       │  收益                   │  代价                          │
├────────────┼────────────────────────┼────────────────────────────────┤
│  显存占用   │  INT4: 减少 75%         │  激活值仍为 FP16（通常）        │
│            │  INT8: 减少 50%         │                                │
├────────────┼────────────────────────┼────────────────────────────────┤
│  Decode速度 │  提升 2-4x              │  Prefill 可能有 10-20% 开销    │
│            │  (memory-bound 场景)    │  (反量化计算)                   │
├────────────┼────────────────────────┼────────────────────────────────┤
│  Batch Size │  可增大 2-3x            │                                 │
│            │  (省下显存给 KV Cache)  │                                │
├────────────┼────────────────────────┼────────────────────────────────┤
│  模型精度   │  INT8 <0.1% 损失        │  小模型 (<3B) 损失较大          │
│            │  INT4 <1% 损失 (大模型)  │  数学/代码任务更敏感            │
├────────────┼────────────────────────┼────────────────────────────────┤
│  硬件需求   │  1卡替代 2-4卡          │  需 GPU 支持 INT4 Tensor Core  │
│            │                        │  (SM75+ Volta 以上)            │
└────────────┴────────────────────────┴────────────────────────────────┘
```

---

## 2. 数值表示格式详解

### 2.1 浮点数的本质：科学计数法

任何计算机中的浮点数都在模仿科学计数法：

```
十进制科学计数法:  1.234 × 10³
                   ├─┘    ├─┘
                  尾数    指数

二进制浮点数:     1.XXXX × 2^E
                   ├──┘     ├─┘
                  尾数     指数
                  (Mantissa) (Exponent)
```

IEEE 754 浮点数格式的位布局：

```
sign bit  exponent bits    mantissa (fraction) bits
    │     ┌──────────┐    ┌──────────────────────┐
    │     │          │    │                       │
   [S] [E E E E E E E E] [M M M M M M M M M M ... ]
    └─┬─┘
      0=正, 1=负
```

### 2.2 完整格式对比表

```
┌──────────┬──────┬───────────┬───────────────┬────────────┬──────────────────────────┐
│  格式     │ Bits │ 指数位     │ 尾数位         │ 表示范围     │ 典型用途                  │
├──────────┼──────┼───────────┼───────────────┼────────────┼──────────────────────────┤
│  FP32    │  32  │  8 (E8)   │  23 (M23)      │ ±3.4×10³⁸  │ 训练主参数 (master copy)  │
│  TF32    │  19  │  8        │  10            │ ±3.4×10³⁸  │ Ampere Tensor Core 内部   │
│  BF16    │  16  │  8 (E8)   │  7 (M7)        │ ±3.4×10³⁸  │ 训练 (稳定, 范围大)       │
│  FP16    │  16  │  5 (E5)   │  10 (M10)      │ ±65504     │ 推理权重, 混合精度训练    │
│  FP8 E5M2│  8   │  5 (E5)   │  2 (M2)        │ ±57344     │ Hopper 梯度 (范围优先)    │
│  FP8 E4M3│  8   │  4 (E4)   │  3 (M3)        │ ±448       │ Hopper 前向 (精度优先)    │
│  INT8    │  8   │  0        │  N/A           │ ±127       │ PTQ 后训练量化            │
│  INT4    │  4   │  0        │  N/A           │ ±7 (有符号) │ 权重量化 (GPTQ/AWQ)       │
│  NF4     │  4   │  0        │  N/A           │ ~±1.0      │ QLoRA (自适应正态分布)     │
│  FP4     │  4   │  0        │  N/A           │ —          │ 实验性, 极低精度          │
└──────────┴──────┴───────────┴───────────────┴────────────┴──────────────────────────┘
```

### 2.3 各位格式的位布局图解

```
FP32 (32-bit IEEE 754):
┌───┬────────────────┬───────────────────────────────────────────────────────┐
│ S │    Exponent    │                    Mantissa                           │
│ 1 │    8 bits      │                    23 bits                            │
└───┴────────────────┴───────────────────────────────────────────────────────┘
  bit31  bits 30-23      bits 22-0

  value = (-1)^S × 2^(E-127) × (1.M)
  其中 E 是 8-bit 无符号整数, M 是 23-bit 分数部分
  隐含的"1."使有效精度为 24 bits ≈ 7.2 位十进制数字


BF16 (Brain Float 16):
┌───┬────────────────┬───────────────────────┐
│ S │    Exponent    │       Mantissa        │
│ 1 │    8 bits      │        7 bits         │
└───┴────────────────┴───────────────────────┘
  bit15  bits 14-7       bits 6-0

  value = (-1)^S × 2^(E-127) × (1.M)
  指数范围和 FP32 相同 (8 bits) → 不会上溢/下溢
  精度较低 (~2 位十进制) → 但对训练中梯度更新已足够


FP16 (IEEE 754 Half Precision):
┌───┬──────────────────┬─────────────────────────────┐
│ S │     Exponent     │          Mantissa           │
│ 1 │     5 bits       │          10 bits            │
└───┴──────────────────┴─────────────────────────────┘
  bit15  bits 14-10        bits 9-0

  value = (-1)^S × 2^(E-15) × (1.M)
  指数只有 5 bits → 范围 ±65504, 超范围则 infinity
  尾数 10 bits → ~3 位十进制精度


FP8 E4M3 (推理用, 精度优先):
┌───┬──────────────┬─────────────────┐
│ S │   Exponent   │    Mantissa     │
│ 1 │   4 bits     │     3 bits      │
└───┴──────────────┴─────────────────┘
  bit7  bits 6-3       bits 2-0

  value = (-1)^S × 2^(E-7) × (1.M)   (正常数)
  范围 ±448, ~1 位十进制精度
  Hopper SM90 原生支持


FP8 E5M2 (反向/梯度, 范围优先):
┌───┬──────────────────┬───────────────┐
│ S │     Exponent     │   Mantissa    │
│ 1 │     5 bits       │    2 bits     │
└───┴──────────────────┴───────────────┘
  bit7  bits 6-2          bits 1-0

  value = (-1)^S × 2^(E-15) × (1.M)
  范围 ±57344, ~0.5 位十进制精度
  更大的动态范围适合梯度值


INT4 (4-bit 有符号整数, GPTQ/AWQ 使用):
┌───────────────┐
│ 4-bit signed  │
│   integer     │
└───────────────┘
  bits 3-0

  值范围: -8 to +7 (或 0 to 15 无符号)
  每个权重占用 0.5 字节
  需要 scale + zero_point 来映射到浮点范围


NF4 (4-bit NormalFloat, QLoRA 使用):
┌──────────────────────────────────────────────────┐
│     16 个量化级别, 非均匀分布                       │
│     (按照正态分布 N(0,1) 的分位点来划分)             │
└──────────────────────────────────────────────────┘

  分位点: 正态分布的 16 等分
  qᵢ = ¹⁄₂[Φ⁻¹(i/16) + Φ⁻¹((i+1)/16)]  for i=0..15
  其中 Φ⁻¹ 是标准正态的逆 CDF (probit function)

  [-1.0,  -0.696, -0.525, -0.395, -0.284,
   -0.188, -0.098, -0.014,  0.014,  0.098,
    0.188,  0.284,  0.395,  0.525,  0.696,  1.0 ]
  ← 中间密集, 两端稀疏 → 匹配神经网络权重的正态分布特性
```

### 2.4 硬件对格式的支持

```
┌─────────────────────────────┬──────────────┬──────────────┬──────────────┐
│  GPU 架构                    │  FP16 TC     │  INT8 TC     │  FP8 TC      │
├─────────────────────────────┼──────────────┼──────────────┼──────────────┤
│  V100 (Volta, SM70)          │  ✅ 125 TF   │  ❌           │  ❌           │
│  T4 (Turing, SM75)           │  ✅ 65 TF    │  ✅ 130 TF   │  ❌           │
│  A100 (Ampere, SM80)         │  ✅ 312 TF   │  ✅ 624 TF   │  ❌           │
│  A800 (Ampere, SM80)         │  ✅ 312 TF   │  ✅ 624 TF   │  ❌           │
│  H100 (Hopper, SM90)         │  ✅ 990 TF   │  ✅ 1980 TF  │  ✅ 1980 TF  │
│  H800 (Hopper, SM90, China)  │  ✅ ~660 TF  │  ✅ ~1320 TF │  ✅ ~1320 TF │
│  L40S (Ada, SM89)            │  ✅ 366 TF   │  ✅ 733 TF   │  ❌           │
│  DCU Z100 (架构无关)          │  ✅ (MIOPEN) │  ⚠️ 有限      │  ❌           │
└─────────────────────────────┴──────────────┴──────────────┴──────────────┘

关键结论:
  • A800 (国内常见): 支持 INT4/INT8 量化 → GPTQ/AWQ/GGUF 均可用
  • H800 (国内): 额外支持 FP8 → 可使用 Transformer Engine 的 FP8 推理
  • A800 不支持 FP8 → 如果买不到 H800, FP8 方案不可用
```

### 2.5 量化的通用公式

将浮点数映射到整数表示的通用公式：

```
量化 (float → int):
  q = round( (x - zero_point) / scale )
  q = clamp(q, q_min, q_max)

反量化 (int → float):
  x_hat = q × scale + zero_point

其中:
  scale  = (x_max - x_min) / (q_max - q_min)     [非对称量化]
  scale  = max(|x|) / q_max                       [对称量化, zero_point=0]
  x_max, x_min = 原始浮点值的范围
  q_max, q_min = 整数范围 (如 INT4: -8 to 7 或 0 to 15)
```

---

## 3. 权重量化方法

在推理场景中，最实用的是**仅对权重进行量化**（Weight-Only Quantization），激活值保持 FP16/BF16。这样既获得显存节省，又不引入激活量化的精度损失。

### 3.1 GPTQ：基于 Hessian 的后训练量化

#### 3.1.1 核心思想

GPTQ (Generative Pre-trained Transformer Quantization) 的核心是逐列量化权重矩阵，每量化一列后，用剩余未量化的列来"补偿"量化误差。

```
理论根源 — Optimal Brain Quantization (OBQ):

问题: 给定权重矩阵 W ∈ R^(d_row × d_col) 和校准数据 X,
     找到量化后的权重 Ŵ (每列独立量化) 使得:
     argmin_Ŵ || WX - ŴX ||²

思路: 不要一次性量化所有列，而是逐列进行。
     每次量化第 q 列后，调整剩余列来吸收误差。

┌─────────────────────────────────────────────────────────────────┐
│                        GPTQ 算法流程图                           │
└─────────────────────────────────────────────────────────────────┘

        ┌──────────────┐
        │  加载模型权重  │
        │  W ∈ R^(d×d) │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │  准备校准数据  │
        │  前向传播得到  │
        │  X (activations)│
        └──────┬───────┘
               │
               ▼
        ┌──────────────────────┐
        │  计算 Hessian 矩阵     │
        │  H = 2XX^T + λI      │ ← λ 阻尼项防奇异
        │  (累积多个 batch)     │
        └──────┬───────────────┘
               │
               ▼
        ┌──────────────────────────┐
        │  Cholesky 分解            │
        │  H = LL^T                │ ← L 是下三角矩阵
        │  H^(-1) = L^(-T)L^(-1)   │   用于高效求逆
        └──────┬───────────────────┘
               │
               ▼
        ┌──────────────────────────────┐
        │  for q in 0..d_col (逐一列):  │
        │                              │
        │  1. 量化第 q 列:              │
        │     Ŵ_q = quantize(W_q)      │
        │                              │
        │  2. 计算量化误差:             │
        │     δ_q = Ŵ_q - W_q          │
        │                              │
        │  3. 更新剩余列 (误差补偿):    │
        │     W[:,q+1:] -= δ_q ×       │
        │       H_inv[q,q+1:] /        │
        │       H_inv[q,q]             │ ← 关键公式
        │                              │
        │  4. 更新 H_inv (移除第 q 行/列)│
        └──────┬───────────────────────┘
               │
               ▼
        ┌──────────────┐
        │  保存量化权重  │
        │  (INT4 values │
        │   + scales)   │
        └──────────────┘
```

#### 3.1.2 数学推导

**第 1 步：定义优化目标**

```
我们要最小化量化前后输出的均方误差:

  L = || WX - ŴX ||²_F
    = Σ_i || W_i X - Ŵ_i X ||²       (按输出通道分解)

其中 W_i 是第 i 个输出通道的权重行向量。
```

**第 2 步：引入 Hessian 矩阵**

```
对于线性层 Y = WX，输出误差与权重误差的关系由 Hessian 矩阵决定:

  L = Σ_i (W_i - Ŵ_i) H (W_i - Ŵ_i)^T

  其中 H = 2XX^T  (对 W 的 Hessian)

  证明思路 (对平方损失求二阶导):
    ∂²/∂W² [||WX - ŴX||²]
    = ∂²/∂W² [(W-Ŵ)X X^T (W-Ŵ)^T]
    = 2 X X^T
    = H
```

**第 3 步：逐列量化策略**

```
假设我们一次只量化一列 (第 q 列):

权重矩阵分块:
  ┌──────────────────────────────────────┐
  │        已量化列        │   未量化列     │
  │    (列 0..q-1)        │ (列 q+1..d-1) │
  └──────────────────────────────────────┘
                            ↑
                       第 q 列正在量化

量化第 q 列: Ŵ[:,q] = quantize(W[:,q])
误差: δ_q = Ŵ[:,q] - W[:,q]

为了补偿这个误差，我们调整第 q+1 到 d-1 列的未量化权重:

  W[:,q+1:] ← W[:,q+1:] - ξ_q · H_inv[q,q+1:] / H_inv[q,q]

其中 ξ_q 是量化误差向量 (即 δ_q)。

这个更新公式的直观解释:
  H_inv[q,q+1:] / H_inv[q,q] 告诉我们应该如何按比例
  把第 q 列带来的误差分摊到后面各列上去。
```

**第 4 步：为什么需要 Cholesky 分解**

```
朴素地求 H^(-1) 是 O(d³) 的，每量化一列都要重算一遍。

但利用 Cholesky 分解后:
  H = LL^T,  L 是下三角矩阵
  H^(-1) = L^(-T)L^(-1)

逐列移除变量时，可以通过对 Cholesky 因子做低秩更新 (rank-1 update)，
将复杂度从 O(d³) 降到 O(d²)。这是 GPTQ 在实际中可行的关键。

具体来说，移除第 q 行/列后:
  新的 Cholesky 因子 L' 满足 L'L'^T = H[-q,-q]
  这可以通过 Givens 旋转或 Householder 反射完成。
```

**第 5 步：Lazy Batch Update（GPTQ 的关键优化）**

```
基本 OBQ: 逐列量化 + 逐列更新 → 太慢 (O(d³) total)

GPTQ 改进: 将列分成多个 block (如 block_size=128):
  ┌──────┬──────┬──────┬──────┬──────┐
  │ Blk0 │ Blk1 │ Blk2 │ Blk3 │ ...  │
  │ 128列│ 128列│ 128列│ 128列│      │
  └──────┴──────┴──────┴──────┴──────┘

  块内: 逐列量化，但不立即更新 (lazy)
  块结束时: 一次性更新所有剩余列

这样总复杂度降为 O(d_col × d_row² / block_size)
块越大越精确但越慢，block_size=128 是常用平衡点。
```

#### 3.1.3 GPTQ 完整伪代码

```python
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer


def gptq_quantize_layer(
    W: torch.Tensor,           # 权重矩阵 [d_out, d_in]
    H: torch.Tensor,           # Hessian [d_in, d_in]
    bits: int = 4,             # 量化位宽
    group_size: int = 128,     # 组大小
    blocksize: int = 128,      # lazy batch update 块大小
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    GPTQ 量化单个线性层权重。

    Returns:
        qweight:  打包后的 INT4 权重 [d_out, d_in // 2]
        scales:   每组的 scale [d_out, ceil(d_in / group_size)]
        zeros:    每组的 zero_point [d_out, ceil(d_in / group_size)]
    """
    d_out, d_in = W.shape
    W = W.clone().float()       # 使用 float32 确保数值稳定
    H = H.clone().float()

    # 记录哪些列已量化
    dead = torch.zeros(d_in, dtype=torch.bool, device=W.device)
    # 最终量化的权重值
    Q = torch.zeros_like(W)

    # --- Cholesky 分解 H = LL^T, 得到 H_inv ---
    # 加阻尼项防止数值不稳定
    damp = 0.01 * torch.mean(torch.diag(H))
    H.diagonal().add_(damp)
    L = torch.linalg.cholesky(H)                     # [d_in, d_in] 下三角
    H_inv = torch.cholesky_inverse(L)                # [d_in, d_in]

    perm = torch.arange(d_in, device=W.device)       # 列处理顺序
    invperm = torch.arange(d_in, device=W.device)    # 逆排列

    # --- 量化参数 ---
    qmax = 2 ** (bits - 1) - 1                       # INT4: 7
    qmin = -(2 ** (bits - 1))                        # INT4: -8

    # --- 逐块处理 ---
    for block_start in range(0, d_in, blocksize):
        block_end = min(block_start + blocksize, d_in)

        for col in range(block_start, block_end):
            actual_col = perm[col]

            # --- 计算当前列的 scale 和 zero ---
            # 按 group_size 分组
            group_idx = col // group_size
            g_start = group_idx * group_size
            g_end = min(g_start + group_size, d_in)

            # 临时 scale: 基于该列的最大绝对值
            w_col = W[:, actual_col]
            max_val = w_col.abs().max()
            scale = max_val / qmax
            scale = torch.clamp(scale, min=1e-8)

            # --- 量化 ---
            q = torch.round(w_col / scale).clamp(qmin, qmax)
            Q[:, actual_col] = q * scale

            # --- 量化误差 ---
            err = (Q[:, actual_col] - w_col) / scale   # [d_out]
            # err 对每个输出通道可能不同，但对 H 的更新需要取平均
            # 简化处理：使用每个通道的 Hessian 对角元的加权平均
            err_scalar = err.mean()                     # 简化：取平均

            # --- 更新剩余列 (误差补偿) ---
            # W[:, q+1:] -= ξ × H_inv[q, q+1:] / H_inv[q, q]
            remaining_cols = perm[col + 1:block_end]
            if len(remaining_cols) > 0:
                compensation = err_scalar * (
                    H_inv[actual_col, remaining_cols] / H_inv[actual_col, actual_col]
                )
                W[:, remaining_cols] -= compensation.unsqueeze(0)

            # --- 更新 H_inv (消除第 actual_col 行/列) ---
            # H_inv' = H_inv[-q, -q] - H_inv[-q, q] H_inv[q, -q] / H_inv[q, q]
            mask = perm[col + 1:]  # 剩余激活列
            H_inv_qq = H_inv[actual_col, actual_col]
            H_inv_q_rest = H_inv[actual_col, mask]
            H_inv_rest_q = H_inv[mask, actual_col]
            # rank-1 更新
            H_inv_sub = H_inv[mask.unsqueeze(-1), mask.unsqueeze(0)]
            H_inv[mask.unsqueeze(-1), mask.unsqueeze(0)] = (
                H_inv_sub
                - torch.outer(H_inv_q_rest, H_inv_rest_q) / H_inv_qq
            )
            dead[actual_col] = True

    # --- 最终按 group 重新量化 (保证每组有独立的 scale/zero) ---
    num_groups = (d_in + group_size - 1) // group_size
    scales = torch.zeros(d_out, num_groups, device=W.device)
    zeros = torch.zeros(d_out, num_groups, device=W.device)
    qweight = torch.zeros(d_out, d_in, dtype=torch.int8, device=W.device)

    for g in range(num_groups):
        g_start = g * group_size
        g_end = min(g_start + group_size, d_in)
        w_group = W[:, g_start:g_end]

        max_val = w_group.abs().max(dim=1, keepdim=True).values
        scales[:, g:g+1] = max_val / qmax
        q = torch.round(w_group / scales[:, g:g+1]).clamp(qmin, qmax)
        qweight[:, g_start:g_end] = q.to(torch.int8)

    # --- 4-bit 打包: 两个 INT4 放入一个 INT8 ---
    qweight_packed = torch.zeros(d_out, d_in // 2, dtype=torch.int8,
                                  device=W.device)
    for i in range(0, d_in, 2):
        low = qweight[:, i] & 0x0F
        high = (qweight[:, i + 1] & 0x0F) << 4
        qweight_packed[:, i // 2] = low | high

    return qweight_packed, scales, zeros


def gptq_quantize_model(
    model: nn.Module,
    calibration_data: list[torch.Tensor],
    bits: int = 4,
    group_size: int = 128,
    blocksize: int = 128,
):
    """
    对整个模型的线性层执行 GPTQ 量化。

    calibration_data: 代表性输入样本列表
    """
    model.eval()
    model = model.cuda()

    # --- 第一步: 收集 Hessian 矩阵 ---
    # 注册 hook 来捕获每层的输入激活值
    layer_inputs = {}

    def make_hook(name):
        def hook(module, input, output):
            # input[0] shape: [batch, seq_len, hidden_dim]
            # 需要 reshape 为 [batch*seq_len, hidden_dim]
            x = input[0].detach().float()
            x_flat = x.view(-1, x.shape[-1])
            if name not in layer_inputs:
                layer_inputs[name] = []
            layer_inputs[name].append(x_flat)
        return hook

    hooks = []
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            hooks.append(module.register_forward_hook(make_hook(name)))

    # 前向传播收集激活值
    with torch.no_grad():
        for batch in calibration_data:
            batch = batch.cuda()
            model(batch)

    for h in hooks:
        h.remove()

    # 计算每层的 Hessian
    layer_hessians = {}
    for name, inputs in layer_inputs.items():
        X = torch.cat(inputs, dim=0)           # [total_tokens, hidden_dim]
        n = X.shape[0]
        H = 2 * (X.T @ X) / n                  # 经验 Hessian [d_in, d_in]
        layer_hessians[name] = H

    # --- 第二步: 逐层量化 ---
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            print(f"Quantizing {name}...")
            W = module.weight.data
            H = layer_hessians.get(name, None)
            if H is None:
                print(f"  Warning: no Hessian for {name}, skipping")
                continue
            # 确保 H 的维度匹配
            if H.shape[0] != W.shape[1]:
                H = torch.eye(W.shape[1], device=W.device) * 0.01

            qweight, scales, zeros = gptq_quantize_layer(
                W, H.cuda(), bits=bits,
                group_size=group_size, blocksize=blocksize
            )
            # 替换权重: 这里简化，实际需用 QuantizedLinear 替换
            module.register_buffer('qweight', qweight.cpu())
            module.register_buffer('scales', scales.cpu())
            module.register_buffer('zeros', zeros.cpu())
            module.is_quantized = True
            del module.weight

    return model


# ================= 使用示例 =================
if __name__ == "__main__":
    # 加载模型
    model_name = "Qwen/Qwen2.5-7B"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto",
    )

    # 准备校准数据 (WikiText-2 的若干文本段)
    calibration_texts = [
        "The history of natural language processing dates back to...",
        "Machine learning is a subset of artificial intelligence...",
        # ... 128 个样本
    ]
    calibration_data = []
    for text in calibration_texts:
        inputs = tokenizer(
            text, return_tensors="pt",
            truncation=True, max_length=2048
        )
        calibration_data.append(inputs.input_ids)

    # 执行量化
    quantized_model = gptq_quantize_model(
        model,
        calibration_data,
        bits=4,
        group_size=128,
    )

    # 保存
    quantized_model.save_pretrained("./qwen-7b-gptq-int4")
    tokenizer.save_pretrained("./qwen-7b-gptq-int4")
```

### 3.2 AWQ：激活感知权重量化

#### 3.2.1 核心洞察

AWQ (Activation-aware Weight Quantization) 的发现简单而深刻：

```
问题: GPTQ 对所有权重通道一视同仁，但实际上不是所有通道都同等重要。

观察 (通过分析激活值的分布):
┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│  对于某一层的权重矩阵 W ∈ R^(d_out × d_in):                       │
│                                                                  │
│  输入激活值 X=[x₁, x₂, ..., x_d_in] (按输入通道)                  │
│                                                                  │
│  通道 i 对输出的贡献 = W[:,i] × x_i                               │
│                                                                  │
│  ┌──────────────────────────────────────┐                        │
│  │ 通道0: |x₀| = 0.3  (小激活)          │ ← 重要性较低            │
│  │ 通道1: |x₁| = 12.5 (大激活) ★重点★   │ ← 重要性极高            │
│  │ 通道2: |x₂| = 0.1  (小激活)          │                         │
│  │ 通道3: |x₃| = 8.2  (大激活) ★重点★   │ ← 重要性极高            │
│  │ ...                                  │                         │
│  └──────────────────────────────────────┘                        │
│                                                                  │
│  大约 1% 的通道贡献了绝大部分输出 → "显著通道" (salient channels)  │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

**直观理解**: 如果一个输入通道的激活值很大（绝对值），那么它对应的权重列的量化误差会被放大很多倍。这些"显著通道"需要更高的量化精度。

#### 3.2.2 AWQ 的方法：Per-Channel Scaling

```
AWQ 核心操作:

┌──────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  对每个输入通道 c:                                                    │
│                                                                      │
│  1. 计算该通道的平均激活幅度:                                          │
│     s_c = mean(|X[:,c]|)  ← 校准数据的平均绝对值                       │
│                                                                      │
│  2. 对权重进行缩放 (在量化前):                                         │
│     W'[:,c] = W[:,c] / s_c                                           │
│                                                                      │
│     (数学上等价于对激活进行反方向缩放: X'[:,c] = X[:,c] × s_c)        │
│                                                                      │
│  3. 在缩放后的空间进行均匀量化:                                        │
│     Q'[:,c] = round(W'[:,c] / Δ)                                     │
│                                                                      │
│  4. 推理时，这些 scale 吸收到上/下层的权重中:                          │
│     不需要额外计算！                                                  │
│                                                                      │
│  效果: 显著通道的权重被缩小后才量化，量化间隔相对变小，精度提高         │
│        非显著通道的权重被放大后量化，但它们的激活本来就小，误差不大     │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘

为什么要 scale 吸收？
  缩放后的前向传播: Y = (W / s) × (X × s) = W × X  ← 数学恒等
  所以 scale 因子 s 可以被吸收到前一层或后一层的权重中，
  推理时没有任何额外开销！
```

#### 3.2.3 寻找最优 Scale

```python
# AWQ 寻找最优 per-channel scale 的简化实现

def awq_search_scale(
    W: torch.Tensor,               # 原始权重 [d_out, d_in]
    X: torch.Tensor,               # 校准激活 [N, d_in]
    alpha_range: list[float],      # 搜索空间, 如 [0.5, 0.6, ..., 1.5]
    bits: int = 4,
) -> torch.Tensor:
    """
    通过网格搜索找到最优的 per-channel scale。

    思路: s_c = (sx_c)^α, 其中 sx_c = mean(|X[:,c]|)
    搜索最优的 α 值使得量化误差最小。
    """
    d_in = W.shape[1]
    # 计算每个输入通道的平均激活幅度
    sx = X.abs().mean(dim=0)  # [d_in]

    best_alpha = 1.0
    best_error = float('inf')

    for alpha in alpha_range:
        # 计算 scale: s_c = sx_c^α
        s = sx.pow(alpha)                          # [d_in]
        s = s / s.max() * s.shape[0] ** 0.5        # 归一化

        # 缩放权重
        W_scaled = W / s.unsqueeze(0)               # [d_out, d_in]

        # 量化 + 反量化
        qmax = 2**(bits-1) - 1
        qmin = -(2**(bits-1))
        # per-channel 量化
        scale_per_channel = W_scaled.abs().max(dim=1, keepdim=True).values / qmax
        W_quant = (W_scaled / scale_per_channel).round().clamp(qmin, qmax)
        W_dequant = W_quant * scale_per_channel * s.unsqueeze(0)

        # 计算输出误差
        error = ((W @ X.T - W_dequant @ X.T) ** 2).mean().item()

        if error < best_error:
            best_error = error
            best_alpha = alpha

    print(f"Best alpha: {best_alpha}, error: {best_error:.6f}")
    return sx.pow(best_alpha)
```

**实战中 AWQ 的简化**: 通常直接使用 alpha=0.5 就能获得很好的效果（不需要网格搜索），因为激活幅度的平方根已经是很好的近似。这就是你在 HuggingFace 上看到的 AWQ 模型的 scale 是怎么来的。

#### 3.2.4 AWQ vs GPTQ 对比

```
┌──────────────────┬─────────────────────────┬──────────────────────────┐
│  维度             │  GPTQ                    │  AWQ                      │
├──────────────────┼─────────────────────────┼──────────────────────────┤
│  核心机制         │  逐列量化 + Hessian 补偿  │  Per-channel scaling      │
│  校准数据依赖     │  需要 (计算 Hessian)      │  需要 (统计激活幅度)       │
│  量化时间         │  ~几分钟到几小时 (7B)     │  ~几分钟 (7B)              │
│                  │  取决于 block_size        │  远快于 GPTQ              │
│  数学复杂度       │  高 (Cholesky, 矩阵逆)    │  低 (只需统计)            │
│  精度 (WikiText-2)│  PPL 差异 < 0.5 (7B+)    │  PPL 差异 < 0.3 (7B+)     │
│  是否保护显著通道 │  间接 (Hessian 体现)      │  直接 (scale 显式处理)    │
│  推理格式         │  GPTQ 格式 (exllama/vLLM)│  AWQ 格式 (vLLM/TGI)      │
│  vLLM 支持        │  ✅ 原生支持              │  ✅ 原生支持              │
│  Marlin Kernel    │  ✅ (GPTQ-Marlin)         │  ✅ (AWQ-Marlin)          │
│  论文             │  GPTQ (Frantar et al.)    │  AWQ (Lin et al.)         │
└──────────────────┴─────────────────────────┴──────────────────────────┘
```

### 3.3 GGUF/GGML：llama.cpp 生态

GGUF (GPT-Generated Unified Format) 是 llama.cpp 项目的模型文件格式，广泛用于 CPU 推理和边缘设备部署。

#### 3.3.1 量化类型命名规则

```
GGUF 量化类型命名: Q{bits}_{K}_{size}

  Q   = Quantized
  bits = 量化位宽 (2/3/4/5/6/8)
  K   = K-quant (混合精度, 对不同层/张量使用不同精度)
  size = M (Medium) 或 S (Small) 或 L (Large)
         越大 → 更多张量使用更高精度 → 质量更好, 文件更大

常见类型:
┌──────────────┬──────────────────────────────────────────────────────────┐
│  名称         │  说明                                                     │
├──────────────┼──────────────────────────────────────────────────────────┤
│  Q2_K        │  极低精度, 大幅压缩, 质量损失显著                           │
│  Q3_K_S/M/L  │  低精度, 适合极大模型 (>100B) 或低资源环境                  │
│  Q4_K_S/M    │  最常用, 平衡文件大小和质量                                 │
│  Q4_K_M      │  ★推荐★ 33B 模型, 压缩到 ~20GB, 质量损失很小               │
│  Q5_K_S/M    │  更高质量, 文件稍大                                        │
│  Q5_K_M      │  质量接近 FP16, 推荐质量优先场景                           │
│  Q6_K        │  极高质量, 接近无损                                        │
│  Q8_0        │  INT8 量化, 几乎无损, 文件是 FP16 的一半                    │
│  F16         │  原始 FP16 (不量化)                                       │
└──────────────┴──────────────────────────────────────────────────────────┘
```

#### 3.3.2 K-quant 混合精度策略

```
K-quant 的核心: 不同张量类型使用不同的精度

模型的张量分为:
  ┌───────────────┐
  │  attention.wq  │ ← Q{bits}  (如 Q6_K 中: 量化到 6-bit)
  │  attention.wk  │
  │  attention.wv  │
  │  attention.wo  │
  ├───────────────┤
  │  ffn.w1        │ ← Q{bits}  (相同的位宽)
  │  ffn.w2        │
  │  ffn.w3        │
  ├───────────────┤
  │  output.weight │ ← Q{bits}  (lm_head, 输出层)
  ├───────────────┤
  │  token_embd    │ ← F16 或 Q{bits}+1 (嵌入层, 精度更重要)
  │  norm.weight   │ ← F16 或 Q{bits}+1 (归一化参数, 少量但对精度敏感)
  └───────────────┘

以 Q4_K_M 为例:
  大多数 attn/ffn 权重: 4-bit
  token_embd 和 output:    6-bit  ← 这两个层对最终质量影响大
  norm 参数:               F16    ← 参数量极小，不值得量化
```

#### 3.3.3 llama.cpp 部署

```bash
# 1. 下载模型 (HuggingFace 上通常有 GGUF 版本)
# 或者用 llama.cpp 的转换脚本自己转

# 2. 用 llama.cpp 转换 PyTorch 模型为 GGUF + 量化
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp && make -j

# 转换 HF 模型为 GGUF (FP16)
python convert_hf_to_gguf.py /path/to/model --outtype f16 --outfile model-f16.gguf

# 量化 GGUF 文件
./build/bin/llama-quantize model-f16.gguf model-Q4_K_M.gguf Q4_K_M

# 3. 用 llama.cpp 推理
./build/bin/llama-cli \
  -m model-Q4_K_M.gguf \
  -p "请介绍一下量化推理的优势" \
  -n 512 \
  -t 8                 # 线程数

# 4. 用 llama-cpp-python (Python 接口, 支持 OpenAI 兼容 API)
pip install llama-cpp-python

python -m llama_cpp.server \
  --model model-Q4_K_M.gguf \
  --n_ctx 8192 \
  --host 0.0.0.0 \
  --port 8000

# 5. 也可以对接 vLLM 的 GGUF 支持 (实验性)
# vLLM 0.6+ 支持直接加载 GGUF 文件
vllm serve ./model-Q4_K_M.gguf --tokenizer /path/to/tokenizer
```

#### 3.3.4 GGUF vs GPTQ/AWQ 选型

```
┌────────────────────────┬───────────────┬───────────────┬───────────────┐
│  场景                   │  GPTQ/AWQ     │  GGUF          │  推荐          │
├────────────────────────┼───────────────┼───────────────┼───────────────┤
│  GPU 服务器推理 (vLLM)  │  高性能, 原生   │  可支持, 略慢   │  GPTQ/AWQ     │
│  CPU 推理               │  不支持        │  ✅ 专业设计    │  GGUF         │
│  Mac/Apple Silicon      │  不可用        │  ✅ Metal 加速  │  GGUF         │
│  移动端 / 边缘设备       │  不可用        │  ✅ 轻量        │  GGUF         │
│  最大吞吐量 (GPU)        │  Marlin kernel │  一般          │  GPTQ/AWQ     │
│  社区生态                │  HuggingFace   │  llama.cpp     │  视平台而定    │
│  对接 Claude Code / RAG │  ✅ vLLM 稳定   │  ⚠️ 需额外配置  │  GPTQ/AWQ     │
└────────────────────────┴───────────────┴───────────────┴───────────────┘
```

---

## 4. 量化粒度：Per-Tensor / Per-Channel / Per-Group

量化粒度决定了 scale 和 zero_point 的共享范围，直接影响精度和存储开销的平衡。

### 4.1 四种粒度的直观图解

```
假设权重矩阵 W ∈ R^(d_out × d_in), d_out=4, d_in=12

┌──────────────────────────────────────────────────────────────────────┐
│  ① Per-Tensor (张量级): 整个矩阵共享一个 scale                     │
│                                                                      │
│      输入维度 d_in (12列) →                                          │
│  ┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐                 │
│  │   │   │   │   │   │   │   │   │   │   │   │   │ ← 全部共享       │
│  │   │   │   │   │   │   │   │   │   │   │   │   │   1 个 scale     │
│  │   │   │   │   │   │   │   │   │   │   │   │   │                 │
│  │   │   │   │   │   │   │   │   │   │   │   │   │                 │
│  └───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘                 │
│                                                                      │
│  优点: 开销最小 (1 个 float32 scale)                                  │
│  缺点: 精度最差，因为不同列的数值范围可能相差很大                     │
│  使用: 一般不用，太粗糙                                               │
├──────────────────────────────────────────────────────────────────────┤
│  ② Per-Channel (通道级): 每个输出通道一个 scale                     │
│                                                                      │
│  ┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐  ← scale₀     │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤  ← scale₁     │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤  ← scale₂     │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤  ← scale₃     │
│  └───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘                 │
│                                                                      │
│  优点: d_out 个 scale, 每个输出通道独立量化                           │
│  缺点: 同一通道内不同列的范围差异无法处理                              │
│  使用: 权重量化的标准粒度 (GPTQ/AWQ 的基础单位)                      │
├──────────────────────────────────────────────────────────────────────┤
│  ③ Per-Token (Token级): 每个输入 token 一个 scale (用于激活量化)    │
│                                                                      │
│      不同 token 的激活值范围不同，每个 token 一个 scale:              │
│                                                                      │
│  Token₀ 激活: [12.3, 0.1, -8.2, ...]  →  scale₀ = max(|...|)/127   │
│  Token₁ 激活: [0.5,  0.3,  0.1, ...]  →  scale₁ = max(|...|)/127   │
│  Token₂ 激活: [1.2, -0.3,  0.8, ...]  →  scale₂ = max(|...|)/127   │
│                                                                      │
│  使用: SmoothQuant, FP8 W8A8 中的激活量化                            │
├──────────────────────────────────────────────────────────────────────┤
│  ④ Per-Group (组级): 每个大小为 group_size 的通道组一个 scale        │
│                                                                      │
│  ┌───┬───┬───┬───┐───┬───┬───┬───┐───┬───┬───┬───┐                  │
│  │   │   │   │   │   │   │   │   │   │   │   │   │ ← scale₀,₀   │
│  │  Group₀,₀ (128列) │ Group₀,₁ (128列) │ Group₀,₂ (128列) │        │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                  │
│  │      Group₁,₀     │     Group₁,₁     │     Group₁,₂     │ ← ... │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                  │
│  │      Group₂,₀     │     Group₂,₁     │     Group₂,₂     │        │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                  │
│  │      Group₃,₀     │     Group₃,₁     │     Group₃,₂     │        │
│  └───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘                  │
│                                                                      │
│  Scale 数量: d_out × ceil(d_in / group_size)                         │
│  例如 d_out=5120, d_in=5120, group_size=128:                         │
│    scale 数量 = 5120 × 40 = 204,800 (每个 FP16 → 400KB)              │
│                                                                      │
│  优点: 比 per-channel 更精细，比 per-element 开销小                   │
│  使用: GPTQ/AWQ 的实际部署格式 (group_size=128 是标准)                │
└──────────────────────────────────────────────────────────────────────┘
```

### 4.2 Group Size 对精度和存储的影响

```
group_size 权衡分析 (以 33B INT4 量化为例):

┌──────────────┬───────────────────────┬──────────────────────┬──────────┐
│  group_size  │  额外存储 (scale/zero)│  精度 (Wiki PPL)     │  推荐场景 │
├──────────────┼───────────────────────┼──────────────────────┼──────────┤
│  16          │  较大 (~3.2 GB)       │  几乎无损 (~1× 开销) │  极端质量│
│  32          │  ~1.6 GB              │  极小损失            │  高质量  │
│  64          │  ~0.8 GB              │  轻微损失            │  平衡    │
│  128         │  ~0.4 GB (★推荐★)     │  小损失 (<1% PPL↑)  │  通用    │
│  256         │  ~0.2 GB              │  中损失              │  存储受限│
│  -1 (per-ch) │  几乎为 0             │  较大损失            │  不推荐  │
└──────────────┴───────────────────────┴──────────────────────┴──────────┘

  ★ group_size=128 是社群默认标准:
    - 额外存储可忽略 (~0.4GB for 33B)
    - 精度损失极小
    - Marlin Kernel 针对 group_size=128 做了优化
```

---

## 5. GPTQ Marlin Kernel：极致性能

### 5.1 问题：为什么需要专用 Kernel？

标准的 INT4 推理流程需要：

```
普通 INT4 Matmul (每条计算路径):
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  1. 从显存读取 INT4 权重 (packed)                                    │
│  2. 解包 (unpack) → INT8 / INT16                                    │
│  3. 反量化 (INT → FP16):                                            │
│     w_fp16 = w_int × scale + zero_point                             │
│  4. FP16 Matmul: 计算 W_fp16 × X                                   │
│                                                                     │
│  问题:                                                              │
│  • 步骤 2-3 需要额外计算和显存带宽                                    │
│  • 步骤 4 在 FP16 CUDA Core 上执行 → 慢                             │
│  • 没有利用 Tensor Core 的 INT4 矩阵乘法能力                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 5.2 Marlin 的解决思路

Marlin 是一个高度优化的 CUDA Kernel，直接在 Tensor Core 上执行 INT4 矩阵乘法，避免反量化的开销。

```
Marlin Kernel 的核心优化:

① 权重重排 (Permutation):
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  原始 INT4 打包 (按行):                                              │
│  ┌────┬────┬────┬────┬────┬────┬────┬────┐                          │
│  │ w₀ │ w₁ │ w₂ │ w₃ │ w₄ │ w₅ │ w₆ │ w₇ │  ...                    │
│  │   byte₀    │   byte₁    │   byte₂    │                          │
│  └────┴────┴────┴────┴────┴────┴────┴────┘                          │
│                                                                     │
│  Marlin 重排后 (适合 Tensor Core 的 mma.sync 指令):                 │
│  将权重交错的重新排列, 使得 Tensor Core 可以在一个 warp 内           │
│  并行处理多个输出通道和输入通道。                                     │
│                                                                     │
│  ┌──────────────────────────────────────────┐                       │
│  │  32 个线程 × 4 列 × 8 行 = 1024 个 INT4   │  (Marlin tile)     │
│  │  组成一个 64×64 的输出块 (INT4→FP16)      │                       │
│  └──────────────────────────────────────────┘                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

② FP16 Accumulation:
  乘积和 scale 累加全部在 FP16 中完成，利用 Tensor Core 的 FP16 累加能力。

③ 融合的 Scale 乘法和 Zero-point 处理:
  将 scale 乘法和 zp 偏移融合到同一个 kernel 中，减少显存往返。

④ Shared Memory 优化:
  将 scales 和 zeros 预加载到 shared memory，避免重复从 global memory 读取。
```

### 5.3 Marlin 性能数据

```
Marlin Kernel 在 A100 (80GB) 上的性能 (7B 模型, 单 token decode):

┌────────────────────┬───────────────┬───────────────┬──────────────┐
│  Kernel             │  延迟 (ms)     │  vs FP16      │  吞吐 (tok/s)│
├────────────────────┼───────────────┼───────────────┼──────────────┤
│  FP16 (cublas)      │  1.0×         │  baseline     │  ~40         │
│  GPTQ (naive)       │  2.3×         │  慢 130%      │  ~17         │
│  GPTQ + Marlin      │  0.65×        │  快 35%       │  ~62         │
│  AWQ + Marlin       │  0.62×        │  快 38%       │  ~65         │
│  FP8 (H100 only)    │  0.45×        │  快 55%       │  ~89         │
└────────────────────┴───────────────┴───────────────┴──────────────┘

  ★ Marlin 使得 INT4 模型的 decode 延迟反而低于 FP16！
  虽然 INT4 模型的 compute 精度低，但 Memory-Bound 场景下
  读取权重的带宽减半带来的收益超过了所有反量化开销。
```

### 5.4 vLLM 中 Marlin 的使用

```bash
# vLLM 在启动时会自动检测并选择最优 kernel:
# 如果检测到 Marlin 兼容的 GPTQ/AWQ 模型 → 自动使用 Marlin

# 显式禁用/启用 Marlin (调试用):
VLLM_FORCE_MARLIN_KERNEL=0 vllm serve ...  # 禁用
VLLM_FORCE_MARLIN_KERNEL=1 vllm serve ...  # 强制

# 检查 vLLM 是否在使用 Marlin:
import vllm
print(vllm.envs.VLLM_USE_MARLIN_KERNEL)  # 默认 True
```

---

## 6. FP8 推理：Hopper 架构专属

### 6.1 FP8 的硬件前提

FP8 Tensor Core 仅在 NVIDIA Hopper 架构（SM90，Compute Capability 9.0）上可用。

```
支持 FP8 的 GPU:
  • H100 SXM/NVL
  • H800 (中国特供版，算力受限但 FP8 TC 仍然可用)
  • GH200 (Grace Hopper Superchip)

不支持 FP8 的 GPU:
  ✗ A100/A800 (Ampere, SM80)  ← 国内最常见的卡
  ✗ L40S (Ada Lovelace, SM89)
  ✗ V100 (Volta, SM70)
  ✗ T4 (Turing, SM75)

⚠️ 重要实际提示:
  如果你的集群全是 A800，那么 FP8 方案完全不可用。
  不要浪费时间试！直接选 GPTQ/AWQ (INT4)。
```

### 6.2 E4M3 vs E5M2：两个 FP8 变体

```
┌──────────────┬─────────────────────────┬──────────────────────────┐
│  变体          │  E4M3 (推理模式)          │  E5M2 (训练模式)          │
├──────────────┼─────────────────────────┼──────────────────────────┤
│  Exponent     │  4 bits → 偏置 7        │  5 bits → 偏置 15        │
│  Mantissa     │  3 bits                  │  2 bits                  │
│  动态范围      │  ±448                    │  ±57344                  │
│  精度         │  更高 (~1 位十进制)       │  更低 (~0.5 位十进制)     │
│  典型用途      │  前向传播 (权重+激活)     │  反向传播 (梯度)          │
│  vLLM 使用     │  W8A8 (权重和激活都用)   │  —                        │
└──────────────┴─────────────────────────┴──────────────────────────┘

为什么需要两种 FP8？
  • 前向传播: 值域较窄 (通常在 [-10, 10])，需要更高的精度
    → E4M3: 更多的 mantissa bits = 更高的相对精度
  • 反向传播: 梯度可能很大也可能很小 (动态范围宽)，精度可以粗糙
    → E5M2: 更多的 exponent bits = 更大的动态范围
```

### 6.3 Transformer Engine 与 FP8

NVIDIA Transformer Engine (TE) 提供了一个完整的 FP8 推理/训练方案：

```python
# Transformer Engine 的使用 (简化示例)
import transformer_engine.pytorch as te
from transformer_engine.common.recipe import Format, DelayedScaling

# 1. 定义 FP8 recipe
fp8_recipe = DelayedScaling(
    fp8_format=Format.HYBRID,  # E4M3 for fwd, E5M2 for bwd
    amax_history_len=16,
    amax_compute_algo="max",
)

# 2. 使用 FP8 Linear (替代 nn.Linear)
with te.fp8_autocast(enabled=True, fp8_recipe=fp8_recipe):
    # Te.Linear 内部使用 FP8 Tensor Core 执行矩阵乘法
    hidden_states = te.Linear(hidden_size, ffn_size)(hidden_states)

# 3. FP8 的 scale 管理
# TE 使用 delayed scaling 机制:
#   • 不在每次前向时计算 amax (max absolute value)
#   • 使用前几步的 amax 历史来估计当前 scale
#   • 避免了昂贵的 reduction 操作
```

### 6.4 vLLM 中的 FP8 支持

```bash
# vLLM 支持加载 FP8 量化模型 (Hopper only!)
# 模型可以是:
#   a) 原生 FP8 训练/量化的 (如 neuralmagic 发布的 FP8 模型)
#   b) 通过 llm-compressor / auto_fp8 转换的

# 部署 FP8 模型:
vllm serve neuralmagic/Meta-Llama-3.1-8B-Instruct-FP8 \
  --quantization fp8 \
  --dtype auto \
  --max-model-len 8192

# ⚠️ 在 A800 上运行此命令会报错:
#   "FP8 is not supported on the current GPU"
```

```python
# 用 llm-compressor 将 BF16 模型转为 FP8 (需要 H100/H800)
from llmcompressor.transformers import oneshot

# 单次前向校准即可完成 FP8 量化 (比 GPTQ 快得多)
model = oneshot(
    model="meta-llama/Meta-Llama-3.1-8B-Instruct",
    recipe="quantization/llama3.1-8b-fp8-compressor.yaml",
    save_path="./llama3.1-8b-fp8",
)
```

---

## 7. vLLM 中部署量化模型

### 7.1 每种量化格式的部署命令

```bash
# ======================
# 1. AWQ 模型
# ======================
vllm serve Qwen/Qwen2.5-7B-Instruct-AWQ \
  --quantization awq \
  --dtype auto \
  --max-model-len 32768 \
  --gpu-memory-utilization 0.90 \
  --host 0.0.0.0 \
  --port 8000

# 内部流程:
#   1. vLLM 检测 config.json 中的 "quantization_config": {"quant_method": "awq"}
#   2. 加载 packed INT4 weights + scales + zeros
#   3. 使用 AWQ-Marlin kernel (如果 GPU 支持) 或 AWQ-GEMM kernel
#   4. 激活值保持 FP16, 仅在 matmul 前将权重反量化

# ======================
# 2. GPTQ 模型
# ======================
vllm serve Qwen/Qwen2.5-7B-Instruct-GPTQ-Int4 \
  --quantization gptq \
  --dtype auto \
  --max-model-len 32768 \
  --gpu-memory-utilization 0.90

# 内部流程:
#   1. 检测 "quantization_config": {"quant_method": "gptq"}
#   2. 读取 group_size (通常 128), desc_act (是否按激活值排序)
#   3. 使用 GPTQ-Marlin kernel (desc_act=False 时)
#      或 Exllama kernel (desc_act=True 时)
#   4. desc_act=True 精度略好但速度较慢 → 一般不推荐

# ======================
# 3. FP8 模型 (仅 H100/H800)
# ======================
vllm serve neuralmagic/Meta-Llama-3.1-8B-Instruct-FP8 \
  --quantization fp8 \
  --dtype auto

# ======================
# 4. BitsAndBytes (即时量化, 不需要预量化模型)
# ======================
vllm serve Qwen/Qwen2.5-7B-Instruct \
  --quantization bitsandbytes \
  --load-format bitsandbytes

# 内部使用 bitsandbytes 库的 NF4 量化
# 优点: 不用预先量化任何模型
# 缺点: 加载时需要做量化, 启动慢; 性能不如 GPTQ/AWQ

# ======================
# 5. GGUF (实验性)
# ======================
vllm serve ./qwen2.5-7b-Q4_K_M.gguf \
  --tokenizer Qwen/Qwen2.5-7B-Instruct
```

### 7.2 加载量化模型时的显存对比

```
部署 33B 模型 (如 Qwen2.5-32B-Instruct), batch=8, context=8192, 1×A800 (80GB):

┌──────────────────┬───────────┬───────────┬───────────┬──────────────┐
│  格式             │  权重 (GB) │  KV (GB)  │  总计 (GB)│  A800 可行性  │
├──────────────────┼───────────┼───────────┼───────────┼──────────────┤
│  FP16            │  ~66.0    │  ~17.2    │  ~89.2    │  ❌ 需要 2卡  │
│  FP8 (H800 only) │  ~33.0    │  ~8.6     │  ~47.6    │  ✅ 1卡      │
│  INT8            │  ~33.0    │  ~17.2    │  ~56.2    │  ✅ 1卡      │
│  INT4 (GPTQ/AWQ) │  ~16.5    │  ~17.2    │  ~39.7    │  ✅ 1卡, 余量大│
│  GGUF Q4_K_M     │  ~20.0    │  ~17.2    │  ~43.2    │  ✅ 1卡      │
└──────────────────┴───────────┴───────────┴───────────┴──────────────┘

  ★ INT4 量化把 33B 从 "必须 2 卡" 降为 "1 卡绰绰有余"
    剩余 ~40GB 可以:
      → 增大 max-model-len 到 32768
      → 增大 batch size 到 32+
      → 同时跑多个 LoRA adapter
```

### 7.3 vLLM 中的高级量化配置

```bash
# ======================
# 多卡张量并行 + 量化
# ======================
# INT4 33B 双卡并行 (如果还想更快的 decode):
vllm serve Qwen/Qwen2.5-32B-Instruct-AWQ \
  --quantization awq \
  --tensor-parallel-size 2 \
  --gpu-memory-utilization 0.90

# ======================
# 混合量化 + LoRA
# ======================
vllm serve Qwen/Qwen2.5-7B-Instruct-AWQ \
  --quantization awq \
  --enable-lora \
  --max-lora-rank 64 \
  --lora-modules my-adapter=./my-lora-adapter

# LoRA 权重在 BF16 中, base model 在 INT4 中
# 推理时: base_out(INT4) + lora_out(BF16) = final_out

# ======================
# 量化 + 投机解码 (Speculative Decoding)
# ======================
vllm serve Qwen/Qwen2.5-32B-Instruct-AWQ \
  --quantization awq \
  --speculative-model Qwen/Qwen2.5-0.5B-Instruct \
  --num-speculative-tokens 5
# draft model (0.5B, FP16, <1GB) 做快速猜测
# target model (32B, INT4) 做验证
```

---

## 8. 精度评估

### 8.1 困惑度 (Perplexity) 对比

困惑度（Perplexity, PPL）是衡量语言模型质量最直接的指标。越低越好。

```
WikiText-2 上的困惑度 (越低越好):

模型规模       FP16 (baseline)    GPTQ-INT4        AWQ-INT4         FP8
─────────────────────────────────────────────────────────────────────────
Llama-2-7B     5.47               5.53 (+0.06)     5.50 (+0.03)     5.48 (+0.01)
Llama-2-13B    4.88               4.91 (+0.03)     4.90 (+0.02)     4.89 (+0.01)
Llama-2-70B    3.31               3.34 (+0.03)     3.33 (+0.02)     3.32 (+0.01)
─────────────────────────────────────────────────────────────────────────
Qwen2.5-7B     6.12               6.18 (+0.06)     6.15 (+0.03)     N/A
Qwen2.5-14B    5.43               5.47 (+0.04)     5.45 (+0.02)     N/A
Qwen2.5-32B    4.36               4.39 (+0.03)     4.38 (+0.02)     N/A
Qwen2.5-72B    3.67               3.69 (+0.02)     3.68 (+0.01)     N/A
─────────────────────────────────────────────────────────────────────────

观察:
  1. 模型越大，量化损失越小 → 大模型冗余度更高
  2. AWQ 通常比 GPTQ 略好 0.01-0.03 PPL
  3. FP8 几乎无损 (<0.02 PPL)
  4. 7B 级别的量化损失也完全可以接受 (<1.5% PPL 增加)
```

### 8.2 下游任务评估

```
下游任务精度 (以 Llama-2-7B 为例):

┌──────────────────┬────────┬──────────┬──────────┬──────────┐
│  任务              │  FP16   │  GPTQ-I4 │  AWQ-I4  │  GGUF Q4 │
├──────────────────┼────────┼──────────┼──────────┼──────────┤
│  MMLU (5-shot)    │  45.3% │  44.8%   │  45.1%   │  44.5%   │
│  GSM8K (8-shot)   │  14.6% │  13.9%   │  14.3%   │  13.2%   │
│  HumanEval (0-s)  │  12.8% │  12.2%   │  12.8%   │  11.6%   │
│  HellaSwag (10-s) │  78.9% │  78.2%   │  78.6%   │  77.8%   │
│  ARC-C (25-shot)  │  53.1% │  52.8%   │  53.0%   │  52.3%   │
└──────────────────┴────────┴──────────┴──────────┴──────────┘

下游任务精度 (以 Llama-2-70B 为例, 大模型的量化鲁棒性更好):

┌──────────────────┬────────┬──────────┬──────────┐
│  任务              │  FP16   │  GPTQ-I4 │  AWQ-I4  │
├──────────────────┼────────┼──────────┼──────────┤
│  MMLU             │  68.9% │  68.7%   │  68.8%   │
│  GSM8K            │  56.8% │  56.2%   │  56.5%   │
│  HumanEval        │  29.9% │  29.3%   │  29.9%   │
│  HellaSwag        │  87.3% │  87.1%   │  87.2%   │
└──────────────────┴────────┴──────────┴──────────┘

★ 核心结论: 70B+ 模型的 INT4 量化精度损失通常 <0.5%, 几乎可忽略
  但对于数学/代码任务 (GSM8K, HumanEval), 损失略大 (~1-2%)
```

### 8.3 量化何时会失败

```
⚠️ 以下场景量化损失可能较大:

1. 小模型 (<3B)
   → 小模型参数冗余少, 量化损失比例大
   → 建议: 使用 INT8 或 GGUF Q6_K 以上

2. 数学密集型任务
   → 数值精度对中间计算结果影响大
   → 建议: 至少 INT8, 或使用 FP16 进行数学相关的层

3. 领域特定的低资源语言
   → 校准数据分布与推理场景不匹配
   → 建议: 使用目标场景数据做校准

4. 极长文本 (>32K tokens)
   → 量化误差随序列长度累积
   → 建议: 考虑 INT8 或 group_size 设更小 (如 64)

5. 输出层 (lm_head)
   → 直接映射到 vocabulary logits, 误差影响大
   → 建议: 保持 lm_head 为 FP16 (GPTQ/AWQ 通常默认这样做)

量化精度保障检查清单:
  □ 模型参数量 >= 7B
  □ 使用代表性校准数据 (与推理场景分布一致)
  □ 校准数据量: 128-256 samples × 2048 tokens
  □ 避免对 lm_head 和 LayerNorm 做量化
  □ 部署前在目标任务上做 A/B 对比
```

---

## 9. 33B 模型部署实操方案

### 9.1 完整的决策与操作流程

```
                        ┌───────────────────────┐
                        │  需要部署 33B 模型?     │
                        └───────────┬───────────┘
                                    │
                          ┌─────────▼─────────┐
                          │  GPU 是什么?        │
                          └──┬──────────────┬──┘
                             │              │
                    ┌────────▼───┐    ┌─────▼─────────┐
                    │ H100/H800  │    │ A100/A800/其他 │
                    └──────┬─────┘    └─────┬─────────┘
                           │                │
                    ┌──────▼──────┐   ┌─────▼──────────────┐
                    │ FP8 (最优)   │   │ HF 有无现成 AWQ/GPTQ│
                    │ ~50GB/卡    │   │ 版本?               │
                    │ 最快推理    │   └──┬──────────────┬───┘
                    └─────────────┘      │              │
                                ┌────────▼───┐   ┌─────▼──────────┐
                                │ 有现成版本  │   │ 没有,自己量化   │
                                │ → 直接下载  │   │ → 走量化流程    │
                                └──────┬─────┘   └─────┬──────────┘
                                       │               │
                                       ▼               ▼
                                 ┌──────────────────────────┐
                                 │  部署到 vLLM 并 benchmark │
                                 │  与 FP16 做 A/B 对比      │
                                 └──────────┬───────────────┘
                                            │
                                   ┌────────▼────────┐
                                   │ 质量可接受?       │
                                   └──┬───────────┬──┘
                                      │           │
                               ┌──────▼──┐  ┌─────▼──────────┐
                               │  部署上线 │  │ 退回到 BF16/   │
                               │  ✅      │  │ 降低group_size │
                               └─────────┘  │ 或换更大的卡    │
                                            └────────────────┘
```

### 9.2 第一步：检查现成量化版本

```bash
# ======================
# 方法 1: HuggingFace Hub 搜索
# ======================

# 搜索 AWQ 版本
# 访问: https://huggingface.co/models?search=Qwen2.5-32B-AWQ

# 搜索 GPTQ 版本
# 访问: https://huggingface.co/models?search=Qwen2.5-32B-GPTQ

# 搜索 GGUF 版本
# 访问: https://huggingface.co/models?search=Qwen2.5-32B-GGUF

# ======================
# 方法 2: ModelScope (国内, 速度快)
# ======================
# https://modelscope.cn/models?name=Qwen2.5-32B-AWQ

# ======================
# 方法 3: 用 huggingface_hub 命令行搜索
# ======================
pip install huggingface_hub

huggingface-cli search Qwen2.5-32B-Instruct-AWQ --limit 5
huggingface-cli search Qwen2.5-32B-Instruct-GPTQ --limit 5
huggingface-cli search Qwen2.5-32B-Instruct-GGUF --limit 5

# ======================
# 常见可用的社区量化版本 (以 Qwen2.5 系列为例):
# ======================
# AWQ:    Qwen/Qwen2.5-32B-Instruct-AWQ
#         (由 Qwen 官方维护, 质量有保障)
# GPTQ:   Qwen/Qwen2.5-32B-Instruct-GPTQ-Int4
#         ModelCloud/Qwen2.5-32B-Instruct-GPTQ-Int4
# GGUF:   bartowski/Qwen2.5-32B-Instruct-GGUF
#         (bartowski 是知名的 GGUF 社区维护者)
```

### 9.3 第二步：如果没现成的，自己量化

```python
# ======================
# 用 AutoGPTQ 量化 33B 模型
# ======================
# 安装:
# pip install auto-gptq optimum

from transformers import AutoTokenizer
from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
import torch
import time

# --- 配置 ---
model_name = "Qwen/Qwen2.5-32B-Instruct"
output_dir = "./Qwen2.5-32B-Instruct-GPTQ-Int4"

quantize_config = BaseQuantizeConfig(
    bits=4,                    # 4-bit 量化
    group_size=128,            # 每组 128 列
    desc_act=False,            # 不按激活值排序 (更快, Marlin 兼容)
    damp_percent=0.01,         # Hessian 阻尼系数
    sym=True,                  # 对称量化 (zero_point=0)
    true_sequential=True,      # 真正的逐层顺序量化
)

# --- 加载模型 ---
# 33B 模型约需 66GB+ 显存 (FP16), 至少需要 2×A800 或 1×H800
# 如果显存不够，加上 device_map="auto" + max_memory 限制
model = AutoGPTQForCausalLM.from_pretrained(
    model_name,
    quantize_config=quantize_config,
    torch_dtype=torch.float16,
    device_map="auto",         # 自动分配到多卡
)

tokenizer = AutoTokenizer.from_pretrained(model_name)

# --- 准备校准数据 ---
# 使用 WikiText-2 或 C4 的 128 个样本
from datasets import load_dataset

calibration_dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
calibration_data = []
for item in calibration_dataset:
    text = item["text"].strip()
    if len(text) > 100:
        calibration_data.append(
            tokenizer(text, truncation=True, max_length=2048)
        )

# 只需要 128 个样本
calibration_data = calibration_data[:128]

# --- 执行量化 ---
print("Starting GPTQ quantization...")
start_time = time.time()

model.quantize(
    calibration_data,
    batch_size=1,              # 33B 太大, 一次只能处理 1 个样本
    use_triton=False,          # 不用 Triton (A800 上可能更快)
    cache_examples_on_gpu=True, # 校准数据放在 GPU 上
)

elapsed = time.time() - start_time
print(f"Quantization completed in {elapsed/60:.1f} minutes")

# --- 保存模型 ---
model.save_quantized(
    output_dir,
    use_safetensors=True,      # 使用 safetensors 格式
)

tokenizer.save_pretrained(output_dir)

print(f"Quantized model saved to {output_dir}")
# 预期文件大小: ~18-20 GB (vs FP16 的 ~66 GB)
```

### 9.4 第三步：Benchmark 对比

```bash
# ======================
# 启动 FP16 baseline (基准) 服务
# ======================
# 需要 2×A800
vllm serve Qwen/Qwen2.5-32B-Instruct \
  --dtype float16 \
  --tensor-parallel-size 2 \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.90 \
  --host 0.0.0.0 --port 8000

# ======================
# 启动 INT4 量化服务
# ======================
# 只需 1×A800
vllm serve ./Qwen2.5-32B-Instruct-GPTQ-Int4 \
  --quantization gptq \
  --dtype float16 \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.90 \
  --host 0.0.0.0 --port 8001
```

```python
# ======================
# Benchmark 脚本
# ======================
"""benchmark_quantized.py — 对比 FP16 vs INT4 的性能和质量"""
import time
import json
from openai import OpenAI

# 连接两个服务
client_fp16 = OpenAI(base_url="http://localhost:8000/v1", api_key="not-needed")
client_int4 = OpenAI(base_url="http://localhost:8001/v1", api_key="not-needed")

test_prompts = [
    "请用 Python 写一个快速排序算法",
    "解释量子计算的基本原理",
    "Summarize the history of the Roman Empire in 100 words",
    "Translate the following to French: The weather is beautiful today",
    "What is the capital of Mongolia?",
    # ... 更多测试 prompt
]

results = []

for prompt in test_prompts:
    result = {"prompt": prompt}

    for name, client in [("fp16", client_fp16), ("int4", client_int4)]:
        t0 = time.time()
        response = client.completions.create(
            model="default",
            prompt=prompt,
            max_tokens=256,
            temperature=0.0,
        )
        elapsed = time.time() - t0

        completion = response.choices[0].text
        usage = response.usage

        result[name] = {
            "ttft_ms": elapsed * 1000,
            "completion_tokens": usage.completion_tokens,
            "prompt_tokens": usage.prompt_tokens,
            "tpot_ms": (elapsed * 1000) / max(usage.completion_tokens, 1),
            "text": completion,
        }

    results.append(result)

# 保存结果
with open("benchmark_results.json", "w") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)

# 打印汇总
fp16_tpot = sum(r["fp16"]["tpot_ms"] for r in results) / len(results)
int4_tpot = sum(r["int4"]["tpot_ms"] for r in results) / len(results)

print(f"FP16 平均 TPOT: {fp16_tpot:.1f} ms/token")
print(f"INT4 平均 TPOT: {int4_tpot:.1f} ms/token")
print(f"加速比: {fp16_tpot/int4_tpot:.2f}x")
```

```python
# ======================
# 输出质量对比 (需要人工评判或用 LLM-as-Judge)
# ======================
"""quality_eval.py — 用 GPT-4/Claude 评判量化模型的输出质量"""

import json

# 每条结果包含 FP16 和 INT4 两个输出
# 可以打乱顺序，用 Claude 做 blind evaluation
# 或者直接用业务指标判断

def compare_outputs(results_file: str):
    with open(results_file) as f:
        results = json.load(f)

    for i, r in enumerate(results):
        print(f"\n{'='*60}")
        print(f"Prompt #{i+1}: {r['prompt'][:100]}...")
        print(f"\n--- FP16 ---")
        print(r['fp16']['text'][:200])
        print(f"\n--- INT4 ---")
        print(r['int4']['text'][:200])

        # 人工判定: 相同 / FP16好 / INT4好
        # 或者在业务数据集上计算定量指标

# 保存结果供 Claude 评审
# 在 Claude Code 中:
# "请对比以下两个回答的质量，从准确性、完整性、流畅度三个维度评价"
```

### 9.5 第四步：内存与吞吐量实测

```bash
# ======================
# 用 vLLM 的 benchmark 工具测吞吐量
# ======================

# 安装 benchmark 依赖
pip install vllm[benchmark]

# 运行 benchmark (对 FP16 服务)
vllm bench serve \
  --backend openai-chat \
  --model default \
  --endpoint /v1/chat/completions \
  --base-url http://localhost:8000 \
  --num-prompts 512 \
  --request-rate 8 \
  --result-filename fp16_bench.json

# 运行 benchmark (对 INT4 服务)
vllm bench serve \
  --backend openai-chat \
  --model default \
  --endpoint /v1/chat/completions \
  --base-url http://localhost:8001 \
  --num-prompts 512 \
  --request-rate 8 \
  --result-filename int4_bench.json
```

预期的 Benchmark 结果（33B 模型，1×A800）：

```
┌──────────────────┬─────────────┬──────────────┬──────────────┐
│  指标              │  FP16 (2卡)  │  INT4 (1卡)   │  对比         │
├──────────────────┼─────────────┼──────────────┼──────────────┤
│  GPU 数量          │  2 × A800   │  1 × A800     │  节省 50%    │
│  模型权重显存       │  ~66 GB     │  ~16.5 GB     │  节省 75%    │
│  KV Cache 可用     │  ~10 GB/卡  │  ~58 GB       │  5.8x 更大   │
│  最大 batch_size   │  ~16        │  ~64          │  4x          │
│  Time-To-First-Tok │  1.2s       │  1.4s         │  慢 17%      │
│  TPOT (decode)     │  25 ms/tok  │  16 ms/tok    │  快 36%      │
│  最大吞吐量         │  640 tok/s  │  1024 tok/s   │  1.6x        │
│  单卡成本 (估算)    │  2× 卡时     │  1× 卡时       │  节省 50%    │
└──────────────────┴─────────────┴──────────────┴──────────────┘

结论: INT4 量化在 1 张 A800 上不仅跑起来了，decode 比 FP16 双卡还快。
     虽然 TTFT 略慢 (prefill 的反量化开销)，但整体吞吐量显著提升。
```

### 9.6 部署决策建议

```
┌─────────────────────────────────────────────────────────────────────┐
│                      量化部署决策树 (33B/67B)                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Q1: 你的 GPU 是 H100/H800?                                         │
│  ├── YES → 使用 FP8 量化 (W8A8), 几乎无损 + 最强性能                 │
│  │         命令: vllm serve model-fp8 --quantization fp8            │
│  │                                                                   │
│  └── NO (A100/A800/其他) →                                           │
│      │                                                               │
│      Q2: 目标是最大化吞吐量? 还是最大化精度?                          │
│      │                                                               │
│      ├── 最大化吞吐量 → 使用 AWQ INT4                                 │
│      │    • HF 上有现成版本 → 直接下载部署                            │
│      │    • 没有现成版本 → 用 auto_gptq 自己量化                      │
│      │    • 命令: vllm serve model-awq --quantization awq            │
│      │    • 预期: 1×A800 可跑, decode 速度 ~1.5x FP16                │
│      │                                                               │
│      ├── 最大化精度 → 使用 INT8                                       │
│      │    • 显存需求仍是 FP16 的一半 (33GB)                           │
│      │    • 33B 仍需 1 卡, 但 KV Cache 空间减少                       │
│      │    • 精度几乎无损 (<0.1% PPL 增加)                             │
│      │                                                               │
│      └── 对接 Claude Code → 使用 AWQ                                 │
│           • vLLM 提供 OpenAI 兼容 API                                │
│           • 在 Claude Code 中配置为 custom API endpoint               │
│           • 33B+INT4 的 latency 适合交互式代码补全                     │
│                                                                     │
│  ⚠️ 对接 Claude Code / RAG 的特殊考虑:                               │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                                                                │  │
│  │  1. API 兼容性:                                                │  │
│  │     vLLM 启动后提供 /v1/chat/completions (OpenAI 兼容)         │  │
│  │     在 Claude Code 中配置:                                      │  │
│  │     {                                                          │  │
│  │       "apiKey": "not-needed",                                  │  │
│  │       "baseURL": "http://your-server:8000/v1",                │  │
│  │       "provider": "openai-compatible"                          │  │
│  │     }                                                          │  │
│  │                                                                │  │
│  │  2. RAG 场景的量化选择:                                         │  │
│  │     • 检索准确率对 embedding 质量很敏感                         │  │
│  │     • 建议: 生成模型用 INT4, embedding 模型保持 FP16            │  │
│  │     • 或者: 全部用 INT8 (兼顾精度和速度)                        │  │
│  │                                                                │  │
│  │  3. 长上下文的量化稳定性:                                       │  │
│  │     • RAG 场景常有长 prompt (检索文档 + 历史对话)                │  │
│  │     • INT4 的 KV Cache 仍需 FP16 (标准做法)                    │  │
│  │     • 建议 group_size=128 或 64, 确保稳定性                    │  │
│  │                                                                │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 9.7 端到端部署脚本

```bash
#!/bin/bash
# ============================================================
# deploy_33b_int4.sh — 一键部署 33B INT4 模型
# ============================================================

set -euo pipefail

MODEL_NAME="${1:-Qwen/Qwen2.5-32B-Instruct-AWQ}"
QUANT_METHOD="${2:-awq}"
PORT="${3:-8000}"
MAX_LEN="${4:-32768}"

echo "=========================================="
echo "  部署量化模型"
echo "  Model:       $MODEL_NAME"
echo "  Quantization: $QUANT_METHOD"
echo "  Port:        $PORT"
echo "=========================================="

# 启动 vLLM 服务
vllm serve "$MODEL_NAME" \
  --quantization "$QUANT_METHOD" \
  --dtype auto \
  --max-model-len "$MAX_LEN" \
  --gpu-memory-utilization 0.90 \
  --max-num-seqs 64 \
  --enable-prefix-caching \
  --host 0.0.0.0 \
  --port "$PORT" \
  2>&1 | tee "vllm_${PORT}.log"

# 验证服务可用
echo "Waiting for vLLM server to be ready..."
until curl -s "http://localhost:${PORT}/health" > /dev/null 2>&1; do
  sleep 2
done

echo "vLLM server is ready at http://localhost:${PORT}"

# 快速测试
curl "http://localhost:${PORT}/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "default",
    "messages": [{"role": "user", "content": "你好，请解释什么是量化推理"}],
    "max_tokens": 256
  }' | python3 -m json.tool
```

---

## 10. 易混淆技术辨析

### 10.1 GPTQ vs AWQ vs GGUF

这是最常见的"三选一"困境。它们不是同一层面的东西：

```
┌──────────────┬──────────────────────┬──────────────────────┬──────────────────────────┐
│  维度         │  GPTQ                 │  AWQ                  │  GGUF                     │
├──────────────┼──────────────────────┼──────────────────────┼──────────────────────────┤
│  核心机制     │  基于 Hessian 的      │  基于激活幅度的        │  K-quant 混合精度         │
│              │  逐列量化 + 误差补偿   │  Per-Channel Scaling   │  不同层不同位宽           │
│  量化速度     │  慢（~几小时/33B）    │  快（~几十分钟/33B）   │  快（CPU 上跑）           │
│  精度         │  好（<1% PPL）        │  略好于 GPTQ           │  取决于 K-quant 级别      │
│  推理框架     │  vLLM, TGI, TRT-LLM  │  vLLM, TGI            │  llama.cpp, Ollama       │
│  最佳场景     │  GPU 服务器，追求极致  │  GPU 服务器，快速量化   │  CPU/Mac/边缘设备         │
│              │  推理性能              │  精度略优              │                          │
│  推理 Kernel  │  Marlin (INT4 专用)   │  AWQ-GEMM / Marlin    │  GGML (CPU 优化)          │
│  文件格式     │  HF 标准 (.safetensors)│  HF 标准 (.safetensors)│  GGUF 单体文件            │
└──────────────┴──────────────────────┴──────────────────────┴──────────────────────────┘

选型建议：
- GPU 服务器 + vLLM → GPTQ (Marlin kernel 加持，性能最强) 或 AWQ (如果官方已发布 AWQ 版)
- CPU 推理 / Mac / 边缘设备 → GGUF (没有其他选择)
- 不要纠结于 GPTQ 和 AWQ 的微小精度差异（通常 <0.03 PPL），选社区支持最好的即可
```

### 10.2 Per-Channel vs Per-Token vs Per-Group

这三个词描述的是量化 scale 的共享范围——也就是"同一个 scale 管多大一片权重"：

```
Per-Tensor (最粗):
  整个权重矩阵共用一个 scale。
  例: [d_out × d_in] 矩阵只存 1 个 float32 scale。
  精度最差，极少使用。

Per-Channel (标准):
  每个输出通道一个 scale (d_out 个 scale)。
  例: 矩阵有 5120 个输出通道 → 存 5120 个 float32 scale。
  是 GPTQ/AWQ 的基础粒度。同一通道内不同列的范围差异被忽略。

Per-Token (激活专用):
  每个输入 token 一个 scale。
  用于 SmoothQuant 等 W8A8 方案中的激活量化。
  因为不同 token 的激活值范围差异大（有的 token 激活值很大，有的很小）。

Per-Group (生产标准):
  每 128 列一组，每组一个 scale。
  scale 数量 = d_out × ceil(d_in / group_size)。
  例: 5120×5120, group_size=128 → 存 5120×40 = 204,800 个 scale (约 400KB)。
  ★ 这是 GPTQ/AWQ 实际部署时的默认配置，精度与存储的最佳平衡点。
```

一个直觉理解：Per-Tensor 就像全中国只用一个时区（极端粗糙）；Per-Channel 是每个省一个时区；Per-Group 是每个市一个时区；Per-Element 是每个人一个时区（太细，开销大）。

### 10.3 W4A16 vs W8A8

```
W4A16 (仅权重量化):
  Weight = INT4, Activation = FP16/BF16
  显存节省: 权重 4x 压缩 (FP16→INT4)
  硬件要求: Ampere+ (A100/A800) 的 INT4 Tensor Core
  精度影响: <1% (大模型更小)
  推理方式: 权重读取后反量化到 FP16，然后做 FP16 Matmul；或直接用 INT4 Tensor Core

W8A8 (权重和激活都量化):
  Weight = FP8/INT8, Activation = FP8/INT8
  显存节省: 权重 2x + 激活 2x + KV Cache 2x
  硬件要求: Hopper (H100/H800) 的 FP8 Tensor Core；或 Ampere 的 INT8 Tensor Core
  精度影响: <0.1% (几乎无损)
  推理方式: FP8/INT8 Tensor Core 直接做矩阵乘法，不需要反量化

一句话总结:
  W4A16 = 省钱优先（最小显存，任何 GPU）
  W8A8 = 速度优先（最快推理，需要 Hopper）
  
  国内最常见场景 (A800): 只能选 W4A16 (INT4)，因为 A800 不支持 FP8。
```

### 10.4 Dynamic vs Static Quantization

```
Static Quantization (静态量化):
  量化参数 (scale, zero_point) 在部署前用校准数据预先计算好。
  推理时直接使用，不再变化。
  优点: 推理时零开销，scale 已固化在模型文件中。
  缺点: 如果推理数据分布与校准数据差异大，精度可能下降。
  代表: GPTQ, AWQ, GGUF (都是静态量化)

Dynamic Quantization (动态量化):
  量化参数在每次推理时实时计算（根据当前输入激活值的实际范围）。
  优点: 自适应数据分布，不同输入用不同的 scale，精度更鲁棒。
  缺点: 每次推理有额外的 scale 计算开销（通常很小但非零）。
  代表: PyTorch 的动态 INT8 量化、bitsandbytes 的 NF4 量化

对于大模型推理部署，静态量化是绝对主流。因为：
  1. 大模型的权重分布相对稳定，不需要动态 scale。
  2. 静态量化可以配合 Marlin 等专用 kernel，获得极致性能。
  3. 动态 scale 的计算在 decode 阶段会变成额外的 memory-bound 瓶颈。
```

---

## 11. AI Infra 专家视角

### 11.1 性能瓶颈排查流程

线上量化模型出问题时，按以下决策树逐层排查：

```
第一层：显存是否够？
├── nvidia-smi 看 memory.used
│   如果 > 90% 且有 swap → 显存瓶颈
│   ├── 增大 swap-space (--swap-space 16)
│   ├── 减小 max_num_seqs
│   ├── 降低 max-model-len
│   └── 换更激进的量化（INT8 → INT4）
│
├── nvidia-smi 看 gpu_cache_usage_perc (从 /metrics 拿)
│   如果 > 95% 且报 OOM → KV Cache 不够
│   ├── 开启 prefix caching (--enable-prefix-caching)
│   ├── 增大 gpu-memory-utilization 但留 5-10% 余量
│   └── 减小 max_model_len 到 P99 实际值 × 1.2

第二层：算力还是带宽瓶颈？
├── nvidia-smi dmon -s pucv -d 1 -c 60
│   ├── sm > 80% 且 mem < 50% → Compute-Bound (Prefill 阶段)
│   │   ├── 增大 max-num-batched-tokens (更多 Prefill 并行)
│   │   ├── 用 FP8 (如果硬件支持)
│   │   └── 检查 Marlin kernel 是否启用 (VLLM_LOGGING_LEVEL=DEBUG)
│   │
│   ├── sm < 40% 且 mem > 70% → Memory-Bound (Decode 阶段，正常)
│   │   ├── 确认 Marlin kernel 已启用 (比 naive INT4 快 3-5x)
│   │   ├── 检查 group_size (128 是标准，不要用更小的)
│   │   └── 考虑 W8A8 如果硬件支持 (减少激活流量)
│   │
│   └── sm < 20% 且 mem < 40% → Scheduling-Bound (CPU 跟不上)
│       ├── 开启 CUDA Graphs（消除 kernel launch overhead）
│       ├── 检查 vLLM 日志是否有 "Graph captured" 成功的消息
│       └── nsys profile 查看 kernel launch gap

第三层：量化精度是否退化？
├── 用 lm-eval-harness 跑标准 benchmark
│   python -m lm_eval --model vllm --model_args pretrained=./my-quant-model \
│       --tasks mmlu,gsm8k --batch_size auto
│   ├── 如果与 FP16 baseline 差距 >2% → 量化有问题
│   │   ├── 检查校准数据是否与推理场景匹配
│   │   ├── 减小 group_size (128 → 64，提高精度)
│   │   ├── 换 AWQ（通常比 GPTQ 精度略好 0.01-0.03 PPL）
│   │   └── 回退到 INT8（如果精度是硬性要求）
│   │
│   └── 如果差距 <1% → 量化质量合格，继续排查其他问题

第四层：Marlin Kernel 是否生效？
├── 启动时查看 vLLM 日志
│   grep -i "marlin" vllm_server.log
│   ├── "Using MarlinLinearMethod" → Marlin 已启用 ✅
│   ├── "Marlin is not supported" → GPU 不支持或版本不兼容
│   │   └── 检查 CUDA compute capability (A800=8.0, 满足 Marlin 的 8.0+ 要求)
│   └── 如果 Marlin 未启用 → 性能下降 3-5x !!!
│       └── 确保模型是 desc_act=False (Marlin 不兼容 desc_act=True)
```

### 11.2 A800 部署实操：Qwen2.5-32B-Instruct on 2×A800

**场景**：两台 A800 80GB，需要部署 32B 模型，服务内部 Agent 工作流。

#### 方案 A：单卡 INT4 (推荐，性价比最高)

```bash
# 前提：下载 AWQ 量化版本
# huggingface-cli download Qwen/Qwen2.5-32B-Instruct-AWQ --local-dir /data/models/Qwen2.5-32B-AWQ

vllm serve /data/models/Qwen2.5-32B-AWQ \
    --host 0.0.0.0 \
    --port 8000 \
    --served-model-name qwen32b \
    --quantization awq \
    --max-model-len 8192 \
    --max-num-seqs 64 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.90 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    2>&1 | tee /var/log/vllm-qwen32b-awq.log

# 预期显存分布 (80GB):
#   模型权重:    ~16.5 GB (INT4)
#   KV Cache:    ~25 GB  (8192 context × 64 seqs)
#   框架开销:    ~5 GB
#   剩余缓冲:    ~33.5 GB → 可继续增大 max_num_seqs 或 max_model_len
#
# 预期性能:
#   Throughput: 600-900 tokens/s
#   TTFT P50:   ~200ms (512 token prompt)
#   TPOT P50:   ~18ms (per token)
```

#### 方案 B：双卡 FP16 Tensor Parallel (精度优先)

```bash
vllm serve /data/models/Qwen2.5-32B-Instruct \
    --host 0.0.0.0 \
    --port 8000 \
    --served-model-name qwen32b-fp16 \
    --tensor-parallel-size 2 \
    --max-model-len 8192 \
    --max-num-seqs 80 \
    --max-num-batched-tokens 16384 \
    --gpu-memory-utilization 0.90 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    2>&1 | tee /var/log/vllm-qwen32b-fp16-tp2.log

# 预期显存分布 (每卡 80GB):
#   模型权重:    ~33 GB
#   KV Cache:    ~25 GB
#   框架开销:    ~5 GB
#   每卡总计:    ~63 GB → 较紧，需谨慎监控
#
# 预期性能:
#   Throughput: 750-1000 tokens/s
#   TTFT P50:   ~150ms
#   TPOT P50:   ~16ms
```

#### 方案对比与选择

```
┌────────────────────┬─────────────────────┬──────────────────────┐
│  维度               │  方案 A: 单卡 INT4   │  方案 B: 双卡 FP16    │
├────────────────────┼─────────────────────┼──────────────────────┤
│  GPU 资源           │  1×A800             │  2×A800              │
│  成本               │  低（省一张卡）       │  高                   │
│  精度               │  <1% 损失            │  无损                 │
│  Decode 速度         │  略快 (权重读取减半) │  基准                 │
│  Prefill 速度        │  略慢 (需反量化)     │  基准                 │
│  最大并发            │  64+ (显存充裕)      │  80 (显存较紧)        │
│  推荐场景            │  通用、成本敏感        │  精度敏感（数学/代码） │
└────────────────────┴─────────────────────┴──────────────────────┘

国内 A800 部署 32B 的实战建议：
  ★ 首选方案 A (单卡 INT4)：省一张卡的资源可以跑其他服务，性价比极高
  ★ 方案 B 适用于对数值精度极端敏感的场景（如金融计算、代码生成）
  ★ 如果两张卡都想用满：方案 A 跑 32B + 另一张卡跑 7B（做投机解码的 draft model）
```

#### 部署后的验证清单

```bash
# 1. 快速功能验证
curl http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"qwen32b","messages":[{"role":"user","content":"23 × 47 = ? 只回答数字"}],"max_tokens":10}'
# 期望：1081 (如果答错说明量化精度有问题)

# 2. 显存监控
watch -n 2 "nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total,temperature.gpu --format=csv"

# 3. vLLM 内部指标
watch -n 5 "curl -s http://localhost:8000/metrics | grep -E 'vllm:(num_requests_waiting|num_requests_running|gpu_cache_usage_perc|prefix_cache)'"

# 4. 长时间稳定性测试（跑 1 小时）
python3 -m vllm.benchmarks.benchmark_serving \
    --backend vllm --model qwen32b \
    --dataset-name sharegpt \
    --dataset-path /data/benchmark/ShareGPT_V3_unfiltered_cleaned_split.json \
    --num-prompts 2000 --request-rate 8 \
    --save-result --result-dir ./stability_test

# 5. Marlin Kernel 确认
grep -i "marlin" /var/log/vllm-qwen32b-awq.log
# 应该看到: "Using Marlin kernel for AWQ"
```

---

## 12. 深入学习资源

### 10.1 必读论文

```
量化理论基石:
  • "Optimal Brain Damage" (LeCun et al., 1989)
    https://papers.nips.cc/paper_files/nips/1989
    最早的剪枝/量化理论, Hessian 重要性的起源

  • "Optimal Brain Surgeon" (Hassibi & Stork, 1992)
    https://proceedings.neurips.cc/paper/1992
    将 OBD 推广到一般 Hessian, GPTQ 的直接祖先

GPTQ 相关:
  • "GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers"
    (Frantar et al., 2023) — ICLR 2023
    https://arxiv.org/abs/2210.17323
    ★ 核心论文, 必读

  • "GPTVQ: The Blessing of Dimensionality for LLM Quantization"
    (van Baalen et al., 2024)
    https://arxiv.org/abs/2402.15319
    GPTQ 的向量量化版本 (不是逐标量而是逐向量量化)

AWQ 相关:
  • "AWQ: Activation-aware Weight Quantization for On-Device LLM Compression and Acceleration"
    (Lin et al., 2024) — MLSys 2024
    https://arxiv.org/abs/2306.00978
    ★ AWQ 论文, 解释了显著通道的发现和 per-channel scaling 方法

SmoothQuant:
  • "SmoothQuant: Accurate and Efficient Post-Training Quantization for LLMs"
    (Xiao et al., 2023) — ICML 2023
    https://arxiv.org/abs/2211.10438
    将激活量化的难度"平滑"转移到权重上, W8A8 的关键方法

FP8:
  • "FP8 Formats for Deep Learning" (Micikevicius et al., 2022)
    https://arxiv.org/abs/2209.05433
    NVIDIA 联合撰写的 FP8 格式规范, E4M3/E5M2 的由来

  • "Using FP8 with Transformer Engine" (NVIDIA, 2023)
    https://docs.nvidia.com/deeplearning/transformer-engine/user-guide/
    ★ Transformer Engine 官方文档

QLoRA:
  • "QLoRA: Efficient Finetuning of Quantized Language Models"
    (Dettmers et al., 2023) — NeurIPS 2023
    https://arxiv.org/abs/2305.14314
    NF4 + Double Quantization, 4-bit 微调的标杆

GGUF / llama.cpp:
  • llama.cpp GitHub: https://github.com/ggerganov/llama.cpp
  • K-quants 设计文档: https://github.com/ggerganov/llama.cpp/pull/1684

Marlin Kernel:
  • "Marlin: a Fast 4-bit Inference Kernel" (Frantar et al., 2024)
    https://github.com/IST-DASLab/marlin
    ★ Marlin kernel 的源码和论文

QuIP / QuIP#:
  • "QuIP: 2-Bit Quantization of Large Language Models With Guarantees"
    (Chee et al., 2023) — NeurIPS 2023
    https://arxiv.org/abs/2307.13304
    基于随机 Hadamard 变换的 2-bit 量化

  • "QuIP#: Even Better LLM Quantization with Hadamard Incoherence and Lattice Codebooks"
    (Tseng et al., 2024)
    https://arxiv.org/abs/2402.04396
    ★ 当前最强的 2-bit 量化方法

BitNet / 1-bit LLM:
  • "BitNet: Scaling 1-bit Transformers for Large Language Models"
    (Wang et al., 2023)
    https://arxiv.org/abs/2310.11453
    训练即量化, 1.58-bit 权重

  • "The Era of 1-bit LLMs: All Large Language Models are in 1.58 Bits"
    (Ma et al., 2024)
    https://arxiv.org/abs/2402.17764
    BitNet b1.58, 每个权重仅 {-1, 0, +1}

Survey / 综述:
  • "A Survey of Quantization Methods for Efficient Neural Network Inference"
    (Gholami et al., 2022)
    https://arxiv.org/abs/2103.13630
    全面的量化方法综述

  • "A Comprehensive Survey on Post-Training Quantization for LLMs"
    (Yao et al., 2024)
    https://arxiv.org/abs/2404.12345
    专注于 LLM 后训练量化的最新综述
```

### 10.2 关键开源项目

```
量化工具:
  ├── AutoGPTQ:      https://github.com/AutoGPTQ/AutoGPTQ
  │    GPTQ 量化的标准实现, 与 HuggingFace transformers 深度集成
  │
  ├── AutoAWQ:       https://github.com/casper-hansen/AutoAWQ
  │    AWQ 量化的标准实现, API 与 AutoGPTQ 类似
  │
  ├── llm-compressor: https://github.com/vllm-project/llm-compressor
  │    vLLM 生态的量化工具, 支持 GPTQ/AWQ/FP8/INT8
  │    与 vLLM 推理天然兼容
  │
  ├── bitsandbytes:  https://github.com/bitsandbytes-foundation/bitsandbytes
  │    QLoRA 的 NF4 量化, 支持 4-bit / 8-bit 即时量化
  │
  ├── llama.cpp:     https://github.com/ggerganov/llama.cpp
  │    GGUF/K-quant 生态, CPU/边缘推理
  │
  ├── exllamav2:     https://github.com/turboderp/exllamav2
  │    极致优化的 GPTQ 推理 kernel, 速度和显存效率极高
  │
  ├── TensorRT-LLM:  https://github.com/NVIDIA/TensorRT-LLM
  │    NVIDIA 官方推理框架, 包含 INT4/INT8/FP8 量化支持
  │
  └── QuIP#:         https://github.com/Cornell-RelaxML/quip-sharp
       最新的 2-bit 量化方法, 精度极高但推理 kernel 还在完善

推理框架:
  ├── vLLM:          https://github.com/vllm-project/vllm
  │    支持: AWQ, GPTQ, FP8, BitsAndBytes, GGUF (实验性)
  │    ★ 生产环境首选
  │
  ├── SGLang:        https://github.com/sgl-project/sglang
  │    兼容 vLLM 的量化模型格式, RadixAttention 优化
  │
  └── TGI:           https://github.com/huggingface/text-generation-inference
       HuggingFace 的推理服务, 支持 GPTQ/AWQ/BnB
```

### 10.3 博客与教程

```
★ 必读博客:
  • "A Visual Guide to Quantization" — Maarten Grootendorst
    https://newsletter.maartengrootendorst.com/p/a-visual-guide-to-quantization
    图文并茂的量化入门指南, 强烈推荐

  • "LLM Quantization: GPTQ, AWQ, GGUF, and FP8" — HuggingFace Blog
    https://huggingface.co/blog/quantization
    HuggingFace 官方的量化博文, 覆盖所有主要方法

  • "4-bit LLM Quantization with GPTQ" — HuggingFace Tutorial
    https://huggingface.co/docs/transformers/main/en/quantization/gptq

  • "Understanding Marlin: The Fast 4-bit Inference Kernel" — Neural Magic
    https://neuralmagic.com/blog/understanding-marlin/

  • "vLLM Quantization Guide" — vLLM 官方文档
    https://docs.vllm.ai/en/latest/features/quantization.html
    ★ vLLM 用户必须阅读

  • "FP8 Training and Inference with Transformer Engine" — NVIDIA
    https://developer.nvidia.com/blog/nvidia-transformer-engine-fp8/

  • "A Guide to using AWQ in vLLM" — vLLM Blog
    https://blog.vllm.ai/2024/06/01/awq.html

视频教程:
  • "Quantization in Deep Learning" — EfficientML.ai Lecture Series
    MIT HAN Lab 的量化课程, YouTube 上有完整系列

  • "LLM Quantization: Theory to Practice" — Umar Jamil
    YouTube 频道, 代码驱动的量化教程

Benchmark 与实测:
  • Open LLM Leaderboard (量化模型对比):
    https://huggingface.co/spaces/open-llm-leaderboard/open_llm_leaderboard

  • Artificial Analysis (推理延迟对比):
    https://artificialanalysis.ai/
    不同量化方法 + 不同 GPU 的推理延迟对比

  • vLLM Performance Benchmarks:
    https://github.com/vllm-project/vllm/tree/main/benchmarks
    官方 benchmark 脚本和结果
```

### 10.4 相关工具速查

```
常用命令速查:

# 查看 HuggingFace 模型的量化配置
python -c "
from transformers import AutoConfig
config = AutoConfig.from_pretrained('Qwen/Qwen2.5-32B-Instruct-AWQ')
print(config.quantization_config)
"

# 检查 vLLM 支持的量化方法
vllm serve --help | grep -A5 quantization

# 查看已安装的量化库版本
pip list | grep -E "auto-gptq|autoawq|bitsandbytes|llmcompressor"

# 用 nvidia-smi 实时看显存
watch -n 1 nvidia-smi

# 用 vLLM 的调试模式看量化 kernel 选择
VLLM_LOGGING_LEVEL=DEBUG vllm serve ... 2>&1 | grep -i "marlin\|gptq\|awq\|kernel"

# 转换 HuggingFace 模型为 GGUF
python llama.cpp/convert_hf_to_gguf.py ./my-model --outtype f16

# GGUF 量化
llama.cpp/build/bin/llama-quantize model-f16.gguf model-Q4_K_M.gguf Q4_K_M
```

---

## 附录 A：常见问题

### Q1: FP16 模型显存不够，选哪种量化？

```
优先级:
  1. 在 HuggingFace 搜索 "模型名-AWQ" 或 "模型名-GPTQ", 直接下载部署
  2. 如果没有, 用 AutoGPTQ 或 AutoAWQ 自己量化
  3. 用 vLLM + --quantization bitsandbytes 即时量化 (慢但不需要预处理)
  4. GGUF (如果需要 CPU 推理)
```

### Q2: INT4 量化的 33B 和原始 13B FP16，哪个更好？

```
答案: 33B INT4 几乎总是更好。

原因:
  大模型有更多参数冗余，INT4 量化 33B 的精度损失 (<1%) 远小于
  从 33B 降到 13B 的知识损失 (13B 只有 33B 的 ~40% 参数)。

  类比: 33B INT4 ≈ 有一本略有印刷瑕疵的百科全书
       13B FP16 ≈ 有一本印刷完美的小词典
       要回答复杂问题，你会选哪本?
```

### Q3: API 方式对接 Claude Code 时，量化模型够快吗？

```
Claude Code 对延迟的容忍度:
  • 代码补全: 需要 <500ms TTFT (Time To First Token)
  • 代码解释/问答: 可接受 1-3s TTFT
  • 长对话/RAG: 可接受 2-5s TTFT

33B INT4 on A800:
  • TTFT (512 token prompt): ~0.8s ✅ 满足代码补全
  • TPOT (decode): ~15 ms/tok ✅ 快速生成

结论: INT4 33B 的延迟对绝大多数 Claude Code 场景是足够了。
      瓶颈通常在网络延迟，而不是模型推理。
```

### Q4: 如何判断量化是否成功？（部署前检查清单）

```
□ 模型加载成功 (vLLM 日志无 error)
□ 显存占用符合预期 (nvidia-smi 验证)
□ 测试请求能正常返回 (curl 发一个请求)
□ PPL 在预期范围内 (用 lm-eval-harness 测)
□ 下游任务精度可接受 (跑几个业务相关的 case)
□ 长文本生成无退化 (2048+ tokens 输出质量)
□ 多轮对话连贯性正常 (5+ 轮对话不跑偏)
□ RAG 场景命中率不低于 FP16 baseline 的 95%
```

---

## 附录 B：量化格式互转

```bash
# ======================
# PyTorch → GGUF
# ======================
# 需要 llama.cpp
python llama.cpp/convert_hf_to_gguf.py ./my-model --outtype f16
llama.cpp/build/bin/llama-quantize model-f16.gguf model-Q4_K_M.gguf Q4_K_M

# ======================
# HF Transformers → AWQ
# ======================
from awq import AutoAWQForCausalLM
model = AutoAWQForCausalLM.from_pretrained("./my-model")
model.quantize(tokenizer, quant_config={...})
model.save_quantized("./my-model-awq")

# ======================
# HF Transformers → GPTQ
# ======================
from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
# ... (见 9.3 节的完整代码)

# ======================
# BF16/FP16 → FP8 (需要 H100/H800)
# ======================
# 用 llm-compressor
from llmcompressor.transformers import oneshot
oneshot(model="meta-llama/Llama-3.1-8B", recipe="fp8_recipe.yaml")

# ======================
# GGUF → vLLM 直接加载 (vLLM 0.6+)
# ======================
vllm serve ./model-Q4_K_M.gguf
```

---

> **作者声明**：本文中的所有 benchmark 数据基于公开论文和社区报告。实际结果可能因模型版本、GPU 型号、vLLM 版本、batch size、序列长度等因素而异。在做出部署决策前，请在你的具体硬件和业务场景下进行实际测试。
>
> **版本信息**：本文基于 vLLM 0.6.x+、AutoGPTQ 0.7.x+、AutoAWQ 0.2.x+ 的 API。API 可能随版本更新变化，请以官方文档为准。
>
> **下一步学习建议**：
> 1. 阅读 [KV Cache 优化文档](./kv-cache-optimization.md) — 理解量化如何释放显存给更长的上下文
> 2. 阅读 [PagedAttention 深度解析](./paged-attention-deep.md) — vLLM 核心技术的原理
> 3. 实践: 挑一个 7B 模型, 走通 "下载 → 量化 → 部署 → benchmark" 全流程
> 4. 深入: 阅读 GPTQ 和 AWQ 的源码实现
