# NVIDIA Triton Inference Server 深度指南

> 本文档为推理方向（Direction B）的核心学习材料，涵盖 NVIDIA Triton Inference Server 的完整架构、vLLM 后端集成、动态批处理、模型流水线、性能调优、多节点部署、监控与决策指南。
>
> 前置要求：已完成 vLLM 推理引擎、PagedAttention、KV Cache 优化和模型量化章节的学习。
>
> 适用版本：Triton 24.04+, vLLM 0.5.0+
>
> 最后更新：2026-07

---

## 目录

1. [NVIDIA Triton 概述](#1-nvidia-triton-概述)
2. [Triton 架构详解](#2-triton-架构详解)
3. [模型仓库 (Model Repository)](#3-模型仓库-model-repository)
4. [vLLM 后端集成](#4-vllm-后端集成)
5. [动态批处理深度剖析](#5-动态批处理深度剖析)
6. [模型流水线 (Model Ensembles)](#6-模型流水线-model-ensembles)
7. [性能分析与调优](#7-性能分析与调优)
8. [多节点部署](#8-多节点部署)
9. [监控与可观测性](#9-监控与可观测性)
10. [决策指南：何时引入 Triton](#10-决策指南何时引入-triton)
11. [深入学习资源](#11-深入学习资源)

---

## 1. NVIDIA Triton 概述

### 1.1 什么是 Triton Inference Server

NVIDIA Triton Inference Server 是一个**企业级、生产就绪的推理服务平台**，核心设计理念是 **模型与基础设施解耦**。它支持几乎所有的深度学习框架（PyTorch、TensorFlow、ONNX、TensorRT、vLLM、自定义框架），通过统一的 gRPC/HTTP API 对外暴露推理能力。

```
+-----------------------------------------------------------------------------+
|                     Triton 是什么 --- 一句话总结                                |
|                                                                             |
|   Triton = 统一推理网关 + 智能调度 + 模型管理 + 性能优化 + 企业特性                |
|                                                                             |
|   它解决的问题：                                                              |
|   "我的团队用 PyTorch 训了 LLM，用 ONNX 做 embedding，                          |
|    用 TensorRT 跑分类器，每个模型都是独立的服务，                                |
|    运维起来太痛苦了。能不能用一个统一的服务来管理所有模型？"                         |
|                                                                             |
|   答案：Triton Inference Server                                              |
+-----------------------------------------------------------------------------+
```

### 1.2 九大核心特性详解

#### (1) Multi-Model Serving --- 多模型同时服务

Triton 可以在同一张 GPU 上**同时加载和运行多个模型**。这是 Triton 区别于其他推理框架最重要的能力。

```
一张 A800-80GB GPU 上的多模型共存示例：

  +------------------------------------------------------------------+
  |                    NVIDIA A800 (80GB HBM2e)                       |
  |                                                                  |
  |  +------------------------------+  +---------------------------+  |
  |  |  Llama-2-7B (vLLM Backend)  |  |  BGE-Large-Zh (PyTorch)  |  |
  |  |  - 模型权重:      14.0 GB   |  |  - 模型权重:    0.35 GB  |  |
  |  |  - KV Cache 池:   8.0 GB   |  |  - 运行时缓存:  0.30 GB  |  |
  |  |  - CUDA 上下文:   1.5 GB   |  |  - CUDA 上下文: 0.15 GB  |  |
  |  |  小计:           23.5 GB   |  |  小计:          0.80 GB  |  |
  |  +------------------------------+  +---------------------------+  |
  |                                                                  |
  |  +------------------------------+  +---------------------------+  |
  |  |  Reranker (ONNX Runtime)    |  |  Token Counter (Python)   |  |
  |  |  - 模型权重:     0.30 GB    |  |  - 权重:         0.05 GB  |  |
  |  |  - 运行时:       0.20 GB    |  |  - 运行时:       0.10 GB  |  |
  |  |  小计:           0.50 GB    |  |  小计:           0.15 GB  |  |
  |  +------------------------------+  +---------------------------+  |
  |                                                                  |
  |  总计: 23.5 + 0.80 + 0.50 + 0.15 = 24.95 GB                      |
  |  剩余显存: 80 - 24.95 = 55.05 GB (可用于 KV Cache 动态增长)         |
  +------------------------------------------------------------------+
```

**实际价值**：在生产环境中，很少只部署一个模型。一个完整的 RAG 服务至少需要 embedding 模型 + LLM 模型。不用 Triton 的话，你需要维护两个独立的推理服务，各自的 GPU 资源也无法灵活共享。

#### (2) Dynamic Batching --- 动态批处理

Triton 的 Dynamic Batcher 会自动将到达的独立请求组合成批次（batch），然后在模型上执行：

```
没有 Dynamic Batching:
  请求 1 到达 --> 单独执行 (batch=1) --> 返回结果
  请求 2 到达 --> 单独执行 (batch=1) --> 返回结果
  请求 3 到达 --> 单独执行 (batch=1) --> 返回结果
  GPU 利用率低，吞吐量差

有 Dynamic Batching:
  请求 1 到达 -+
               |
  请求 2 到达 -+-> 等待窗口(100us) --> 组成 batch=3 --> 一次执行 --> 分别返回结果
               |
  请求 3 到达 -+
  GPU 利用率高，吞吐量显著提升
```

Triton 的 Dynamic Batching 支持延迟窗口配置、优先级队列、preserve ordering 等高级特性。

#### (3) Model Ensembles --- 模型流水线

将多个模型串联成一条**有向无环图 (DAG)**，数据在模型间自动流转，无需编写额外代码：

```
RAG Pipeline (Triton Ensemble):

  客户端请求: "什么是量子计算？"
      |
      v
  +------------------------------------------------------------------+
  |                       Ensemble Pipeline                          |
  |                                                                  |
  |  +----------------+     +------------------+    +-------------+  |
  |  | embedding      |---->| vector_search    |--->| llm_model   |  |
  |  | (BGE-Large)    |     | (FAISS/Milvus)   |    | (vLLM)      |  |
  |  |                |     |                  |    |             |  |
  |  | text -> vec    |     | vec -> docs      |    | docs -> ans |  |
  |  +----------------+     +------------------+    +-------------+  |
  |                                                                  |
  +------------------------------------------------------------------+
      |
      v
  响应: 基于检索文档生成的答案
```

#### (4) Backend-Agnostic --- 框架无关

Triton 通过标准化的 **Backend API** 接入任何推理框架。内置支持的 Backend 包括：

| Backend | 用途 | 常用场景 |
|---------|------|---------|
| **PyTorch** | LibTorch 原生推理 | 研究/原型模型 |
| **TensorFlow** | TF SavedModel | TF 生态模型 |
| **ONNX Runtime** | ONNX 模型推理 | 跨框架标准化部署 |
| **TensorRT** | NVIDIA 极致优化 | 对延迟极度敏感的场景 |
| **Python Backend** | 自定义 Python 逻辑 | vLLM 集成、BLS、任意 Python |
| **vLLM Backend** | LLM 专用 | 大语言模型高效推理 |
| **Filament Backend** | NVIDIA Filament | 推荐系统 |
| **OpenVINO** | Intel CPU/GPU 优化 | Intel 硬件 |
| **Custom C++** | 用户自定义 C++ | 特殊需求 |

#### (5) gRPC + HTTP 端点

Triton 同时暴露三个端口：

```
端口 8000 (HTTP/REST):   JSON 序列化，适合 Web 应用、curl 调试、SSE 流式
端口 8001 (gRPC):        Protobuf 二进制序列化，性能更优（延迟低约 20%，数据量小约 30%）
端口 8002 (Metrics):     Prometheus 格式指标，用于监控
```

#### (6) GPU Metrics 与自动配置

Triton 内置 GPU 指标收集（GPU 利用率、显存、功耗等）。Model Analyzer 工具可自动搜索最优配置（实例数、批大小、队列延迟等）。

#### (7) Concurrent Model Execution

多个模型可在同一 GPU 上**并发执行**。Triton 使用独立的 CUDA Stream 为每个模型实例调度计算。

#### (8) Model Versioning

支持三种版本策略：Latest(N) / Specific(versions) / All。支持**热加载**（运行时加载新版本，无需重启）。

#### (9) Request Priority 与 Rate Limiting

多级优先级队列 + 跨模型速率限制，保障 SLA。

---

## 2. Triton 架构详解

### 2.1 完整分层架构

Triton 的架构划分为 7 个明确的功能层，每一层职责清晰、互相解耦：

```
+=======================================================================+
||                      TRITON INFERENCE SERVER 分层架构                  ||
+=======================================================================+
||                                                                     ||
||  Layer 1: Request Ingress (请求入口层)                                ||
||  +-----------------------------------------------------------------+ ||
||  | HTTP/1.1 Server (port 8000)  |  gRPC Server (port 8001)         | ||
||  | - RESTful /v2/models/...     |  - Protobuf 高性能二进制协议       | ||
||  | - JSON 序列化                |  - 原生双向流式                    | ||
||  | - SSE 流式输出               |  - 统一 C API 绑定                | ||
||  +-----------------------------------------------------------------+ ||
||                              |                                       ||
||  Layer 2: Scheduling & Batching (调度与批处理层)                       ||
||  +-----------------------------------------------------------------+ ||
||  |  +------------------+  +------------------+  +----------------+  | ||
||  |  | Dynamic Batcher  |  | Sequence Batcher |  | Rate Limiter   |  | ||
||  |  | - 延迟窗口合并     |  | - 有状态序列管理  |  | - 跨模型限流    |  | ||
||  |  | - 优先级队列       |  | - 隐式状态维护   |  | - 优先级感知    |  | ||
||  |  | - 批大小优化       |  | - 超时回收       |  | - 资源预留      |  | ||
||  |  +------------------+  +------------------+  +----------------+  | ||
||  |  +------------------+  +------------------+  +----------------+  | ||
||  |  | Priority Queues  |  | Response Cache   |  | Request Router  |  | ||
||  |  | - 多级优先级       |  | - 请求哈希缓存    |  | - 模型选择       |  | ||
||  |  | - 抢占式调度       |  | - 确定性请求复用  |  | - 版本路由       |  | ||
||  |  +------------------+  +------------------+  +----------------+  | ||
||  +-----------------------------------------------------------------+ ||
||                              |                                       ||
||  Layer 3: Backend API (后端抽象层)                                     ||
||  +-----------------------------------------------------------------+ ||
||  |              标准化接口 (C API / TRITONBACKEND_*)                  | ||
||  |                                                                   | ||
||  |  +---------+ +---------+ +---------+ +---------+ +------------+  | ||
||  |  | PyTorch | |TensorFlow| |  ONNX   | |TensorRT | |  Python    |  | ||
||  |  | Backend | | Backend | | Runtime | | Backend | |  Backend   |  | ||
||  |  +---------+ +---------+ +---------+ +---------+ +------------+  | ||
||  |  +------------+ +------------+ +-----------------------------+  | ||
||  |  |   vLLM    | |  Filament  | |     Custom Backends          |  | ||
||  |  |  Backend  | |  Backend   | | (用户自定义 C++/Python 后端)   |  | ||
||  |  +------------+ +------------+ +-----------------------------+  | ||
||  +-----------------------------------------------------------------+ ||
||                              |                                       ||
||  Layer 4: Model Repository Manager (模型仓库管理器)                     ||
||  +-----------------------------------------------------------------+ ||
||  |  - 模型版本控制 (version_policy)                                   | ||
||  |  - 热加载 (Hot Reload) --- 无需重启即可加载新版本                   | ||
||  |  - 模型生命周期管理 (LOAD -> READY -> UNLOAD)                     | ||
||  |  - 模型预热 (model_warmup)                                        | ||
||  +-----------------------------------------------------------------+ ||
||                              |                                       ||
||  Layer 5: GPU Memory Manager (GPU 显存管理器)                          ||
||  +-----------------------------------------------------------------+ ||
||  |  - 显存分配/回收  |  CUDA Stream 管理  |  Pinned Memory  |  MIG/MPS ||
||  +-----------------------------------------------------------------+ ||
||                              |                                       ||
||  Layer 6: Execution Engine (执行引擎)                                  ||
||  +-----------------------------------------------------------------+ ||
||  |  CUDA Kernels  |  CPU Threads  |  I/O Multiplexing              | ||
||  +-----------------------------------------------------------------+ ||
||                              |                                       ||
||  Layer 7: Hardware (硬件层)                                           ||
||  +-----------------------------------------------------------------+ ||
||  |  GPU 0  |  GPU 1  |  GPU 2  |  GPU 3  |  CPU  |  RAM  |  NIC  | ||
||  +-----------------------------------------------------------------+ ||
+=======================================================================+
```

### 2.2 请求处理全流程

下面跟踪一个推理请求从客户端到达 GPU 执行的完整路径：

```
客户端                         Triton Server 内部处理

  |                                                                    
  |  1. 客户端发送请求                                                 
  |     POST /v2/models/llm_model/infer                                 
  |     {"inputs": [{"name": "text_input", "data": ["Hello"]}]}        
  |     =============================================>                 
  |                                                                    
  |                              2. HTTP/gRPC Server 接收              
  |                                 - 反序列化 JSON/Protobuf             
  |                                 - 验证请求格式                      
  |                                 - 构造内部 InferenceRequest         
  |                                                                    
  |                              3. Request Router 路由                
  |                                 - 根据 model_name 查找目标模型      
  |                                 - 确定模型版本                      
  |                                                                    
  |                              4. Scheduler 调度决策                 
  |                                 - 检查模型实例可用性                
  |                                 - 选择目标 GPU/CPU                  
  |                                 - 加入优先级队列                    
  |                                                                    
  |                              5. Dynamic Batcher 批处理             
  |                                 - 等待窗口内收集其他请求             
  |                                 - 合并成 optimal batch              
  |                                                                    
  |                              6. Backend API 调用                   
  |                                 - 调用 Backend 的 execute()         
  |                                 - Backend 内部调用模型推理          
  |                                                                    
  |                              7. Response Cache 检查/写入            
  |                                                                    
  |                              8. 构造响应并序列化                    
  |                                                                    
  |  9. 客户端收到响应                                                 
  |     HTTP 200 OK                   <=================================
  |                                                                    
```

### 2.3 各层职责详解

**Layer 1 --- Request Ingress (请求入口层)**

HTTP 和 gRPC 服务完全对等，共享同一套内部请求处理管线。所有协议最终将请求转换为统一的 Internal InferenceRequest 对象。

**Layer 2 --- Scheduling & Batching (调度与批处理层)**

这是 Triton 最核心的层。关键组件：

- **Dynamic Batcher**: 将独立请求动态组合成批次。核心参数包括 max_queue_delay_microseconds、preferred_batch_size、max_batch_size
- **Sequence Batcher**: 用于有状态模型（如对话系统），维护请求序列的状态
- **Rate Limiter**: 跨模型的速率限制，防止单客户端压垮服务
- **Priority Queues**: 多级优先级队列，高优先级请求可以插队
- **Response Cache**: 基于请求内容的确定性缓存

**Layer 3 --- Backend API (后端抽象层)**

Backend API 是 Triton 实现框架无关的关键设计。所有后端必须实现标准的 C 接口：

```c
// Backend API 核心接口
TRITONSERVER_Error* TRITONBACKEND_Initialize(TRITONBACKEND_Backend* backend);
TRITONSERVER_Error* TRITONBACKEND_Finalize(TRITONBACKEND_Backend* backend);
TRITONSERVER_Error* TRITONBACKEND_ModelInitialize(TRITONBACKEND_Model* model);
TRITONSERVER_Error* TRITONBACKEND_ModelFinalize(TRITONBACKEND_Model* model);
TRITONSERVER_Error* TRITONBACKEND_ModelInstanceInitialize(
    TRITONBACKEND_ModelInstance* instance);
TRITONSERVER_Error* TRITONBACKEND_ModelInstanceExecute(
    TRITONBACKEND_ModelInstance* instance, TRITONBACKEND_Request** requests,
    uint32_t request_count);
TRITONSERVER_Error* TRITONBACKEND_ModelInstanceFinalize(
    TRITONBACKEND_ModelInstance* instance);
```

**Python Backend** 是对 C API 的 Python 封装，提供三个生命周期方法：
- `initialize(args)` --- 模型加载时调用一次
- `execute(requests)` --- 每次推理调用
- `finalize()` --- 模型卸载时调用

**Layer 4 --- Model Repository Manager (模型仓库管理器)**

管理模型的版本和生命周期：

```
模型生命周期状态机：

      +---------+    load     +----------+    ready     +----------+
      |  UNLOAD | ----------> | LOADING  | -----------> |  READY   |
      +---------+             +----------+              +----------+
           ^                       |                         |
           |        error/unload   |       error/unload      |
           +-----------------------+-------------------------+
```

**Layer 5 --- GPU Memory Manager (GPU 显存管理器)**

提供 Pinned Memory 分配、CUDA Stream 管理、MIG/MPS 感知等功能。

**Layer 6 & 7 --- Execution Engine & Hardware**

将调度好的请求分发到 CUDA 核心或 CPU 线程执行。

### 2.4 架构设计的关键权衡

```
Triton 架构中的几个重要设计决策：

1. 统一调度 vs 各 Backend 自主调度
   Triton 在 Dynamic Batcher 层统一调度，适用于传统模型（固定延迟）。
   但对于 LLM（变长生成），vLLM 的 continuous batching 更高效。
   因此 vLLM Backend 绕过了 Triton 的 Dynamic Batcher。

2. 同步 API vs Decoupled API
   默认同步模式（一个请求 -> 一个响应）。
   Decoupled 模式支持流式输出（一个请求 -> 多个响应块）。
   LLM streaming 必须使用 Decoupled 模式。

3. C++ 核心 vs Python 灵活性
   Triton 核心用 C++ 实现（高性能热路径）。
   通过 Python Backend 提供灵活性（BLS 可调用其他模型）。
```

---

## 3. 模型仓库 (Model Repository)

### 3.1 完整目录结构

模型仓库是 Triton 管理模型的目录结构。每个模型是一个子目录，其中包含配置文件和版本子目录：

```
model_repository/                          <-- 仓库根目录
│
├── llm_model/                             <-- 模型 1: LLM 主模型
│   ├── config.pbtxt                       <-- 模型配置文件（核心）
│   └── 1/                                 <-- 版本 1
│       └── model.py                       <-- Python Backend 模型文件
│
├── embedding_model/                       <-- 模型 2: Embedding 模型
│   ├── config.pbtxt
│   └── 1/
│       └── model.pt                       <-- PyTorch 模型权重
│
├── reranker/                              <-- 模型 3: Reranker
│   ├── config.pbtxt
│   ├── 1/                                 <-- 版本 1 (旧版)
│   │   └── model.onnx
│   └── 2/                                 <-- 版本 2 (新版, 改进版)
│       └── model.onnx
│
├── vector_search/                         <-- 模型 4: 向量检索引擎
│   ├── config.pbtxt
│   └── 1/
│       └── model.py                       <-- Python Backend (FAISS 封装)
│
├── tokenizer/                             <-- 模型 5: 分词器
│   ├── config.pbtxt
│   └── 1/
│       └── model.py
│
└── rag_pipeline/                          <-- 模型 6: Ensemble 流水线
    ├── config.pbtxt                       <-- Ensemble 定义 (仅配置文件)
    └── 1/                                 <-- 版本目录 (通常为空)
```

### 3.2 config.pbtxt 完整参考

`config.pbtxt` 是 Triton 模型配置的核心文件，使用 Google Protobuf Text Format。以下是最完整的配置参考，包含所有重要字段：

```protobuf
# ============================================================================
#  config.pbtxt --- Triton 模型配置完整参考
#  适用于: Python Backend、PyTorch、ONNX、TensorRT 等所有后端
# ============================================================================

# --- 基本信息 ---
name: "llm_model"                        # 模型名称 (必填，用于 API 调用)
platform: "python"                       # 后端: python | pytorch_libtorch |
                                         #        tensorflow_savedmodel |
                                         #        onnxruntime_onnx |
                                         #        tensorrt_plan | ensemble

# --- 模型版本策略 (三选一) ---
version_policy: {
  # 策略 1: 只加载最新 N 个版本
  latest: { num_versions: 2 }

  # 策略 2: 只加载指定版本
  # specific: { versions: [1, 3] }

  # 策略 3: 加载所有版本
  # all: {}
}

# ============================================================================
#  输入/输出定义 (必填，除非使用 --strict-model-config=false)
# ============================================================================

# --- 最大批大小 ---
max_batch_size: 32                       # 0 表示不支持批处理

# --- 输入张量定义 ---
input [
  {
    name: "text_input"                   # 输入名称
    data_type: TYPE_STRING               # 数据类型
    dims: [1]                            # 张量维度 (不含 batch 维)
    optional: false                      # 是否可选 (默认 false)
    # allow_ragged_batch: false          # 是否允许不规则批 (默认 false)
    # reshape: { shape: [1, -1] }        # (已废弃) 通过 reshape 支持
  },
  {
    name: "max_tokens"
    data_type: TYPE_INT32
    dims: [1]
    optional: true                       # 可选输入
  },
  {
    name: "temperature"
    data_type: TYPE_FP32
    dims: [1]
    optional: true
  },
  {
    name: "images"                       # 图像输入示例
    data_type: TYPE_UINT8
    dims: [3, 224, 224]                  # C, H, W 格式
  }
]

# --- 输出张量定义 ---
output [
  {
    name: "text_output"
    data_type: TYPE_STRING
    dims: [1]
  },
  {
    name: "token_ids"                    # 输出 token IDs
    data_type: TYPE_INT32
    dims: [-1]                           # -1 表示可变长度
  }
]

# --- 支持的数据类型 ---
#   TYPE_BOOL, TYPE_UINT8, TYPE_UINT16, TYPE_UINT32, TYPE_UINT64,
#   TYPE_INT8, TYPE_INT16, TYPE_INT32, TYPE_INT64,
#   TYPE_FP16, TYPE_FP32, TYPE_FP64,
#   TYPE_STRING, TYPE_BF16

# ============================================================================
#  实例组定义 (决定模型如何部署到硬件上)
# ============================================================================

instance_group [
  {
    count: 2                             # 实例数量 (在指定 GPU 上的副本数)
    kind: KIND_GPU                       # KIND_GPU: GPU 上运行
                                         # KIND_CPU: CPU 上运行
                                         # KIND_MODEL: 模型文件指定
    gpus: [0, 1]                         # 使用的 GPU 编号
    # 如果 count=2 且 gpus=[0,1]：
    #   实例 0 在 GPU 0，实例 1 在 GPU 1
    # 如果 count=2 且 gpus=[0]：
    #   两个实例都在 GPU 0 上（共享显存）
  }
]

# 多 GPU 配置示例
# instance_group [
#   {
#     count: 1                           # GPU 0 上 1 个实例
#     kind: KIND_GPU
#     gpus: [0]
#   },
#   {
#     count: 2                           # GPU 1 上 2 个实例
#     kind: KIND_GPU
#     gpus: [1]
#   },
#   {
#     count: 4                           # CPU 上 4 个实例
#     kind: KIND_CPU                     # (适用于轻量级预处理模型)
#   }
# ]

# ============================================================================
#  动态批处理配置
# ============================================================================

dynamic_batching {
  # 优先的批大小 (Triton 会尽量组成这些大小)
  preferred_batch_size: [4, 8, 16, 32]

  # 最大排队延迟 (微秒)  --- 最重要的参数之一
  max_queue_delay_microseconds: 100

  # 保留请求顺序 (仅当不需要严格顺序时可设为 false 以获取更好性能)
  preserve_ordering: false

  # 优先级级别数
  priority_levels: 3
  default_priority_level: 2
  default_queue_policy {
    max_queue_delay_microseconds: 100
    timeout_action: REJECT
    default_timeout_microseconds: 10000  # 10ms
  }

  # 高优先级队列策略
  priority_queue_policy {
    key: 1                               # 优先级 1 (最高)
    value: {
      max_queue_delay_microseconds: 50
      timeout_action: DELAY
    }
  }

  # 低优先级队列策略
  priority_queue_policy {
    key: 3                               # 优先级 3 (最低)
    value: {
      max_queue_delay_microseconds: 500
      timeout_action: DELAY
    }
  }
}

# ============================================================================
#  序列批处理配置 (用于有状态模型，如对话系统)
# ============================================================================

# sequence_batching {
#   max_sequence_idle_microseconds: 1000000   # 序列空闲超时 (1s)
#   oldest {
#     max_candidate_sequences: 64             # 最大候选序列数
#   }
#   state [
#     {
#       input_name: "INPUT_STATE"             # 状态输入
#       output_name: "OUTPUT_STATE"           # 状态输出
#       data_type: TYPE_FP32
#       dims: [1024]                          # 状态向量维度
#     }
#   ]
# }

# ============================================================================
#  Ensemble 调度配置 (仅 ensemble 平台使用)
# ============================================================================

# ensemble_scheduling {
#   step [
#     {
#       model_name: "preprocess"
#       model_version: -1               # -1 表示使用最新版本
#       input_map {
#         key: "raw_input"              # preprocess 模型的输入名
#         value: "query"                # 映射到 ensemble 的输入
#       }
#       output_map {
#         key: "processed_output"       # preprocess 模型的输出名
#         value: "tokens"               # 映射到内部变量名
#       }
#     }
#   ]
# }

# ============================================================================
#  模型预热 (启动时预加载样本，避免冷启动延迟)
# ============================================================================

model_warmup [
  {
    name: "warmup_sample_1"
    batch_size: 1
    inputs {
      key: "text_input"
      value: "Hello, how are you today?"
    }
    inputs {
      key: "max_tokens"
      value: "100"
    }
  },
  {
    name: "warmup_sample_2"
    batch_size: 4
    inputs {
      key: "text_input"
      value: "Explain quantum computing in simple terms."
    }
  }
]

# ============================================================================
#  优化配置
# ============================================================================

optimization {
  # Pinned Memory 优化 (加速 CPU->GPU 数据传输)
  input_pinned_memory {
    enable: true
  }
  output_pinned_memory {
    enable: true
  }

  # CUDA Graph 捕获 (减少 kernel launch 开销)
  # cuda {
  #   graphs: true
  #   busy_wait_events: false
  #   output_copy_stream: false
  # }

  # 执行加速器数量
  # execution_accelerators {
  #   gpu_execution_accelerator [
  #     {
  #       name: "tensorrt"
  #       parameters {
  #         key: "precision_mode"
  #         value: "FP16"
  #       }
  #     }
  #   ]
  # }
}

# ============================================================================
#  响应缓存配置
# ============================================================================

# response_cache {
#   enable: true
#   # response_cache_byte_size: 1073741824    # 1GB 缓存大小
# }

# ============================================================================
#  模型参数字典 (key-value，传递给后端)
# ============================================================================

parameters {
  key: "model_path"
  value: {
    string_value: "/models/Llama-2-7b-hf"
  }
}
parameters {
  key: "max_model_len"
  value: {
    string_value: "4096"
  }
}
parameters {
  key: "tensor_parallel_size"
  value: {
    string_value: "2"
  }
}
parameters {
  key: "enable_prefix_caching"
  value: {
    string_value: "true"
  }
}
```

### 3.3 关键字段详解

#### 3.3.1 instance_group --- 实例组配置

```
实例组决定了模型在哪些硬件上以多少副本运行。

count * gpus 组合规则：
  - count=1, gpus=[0]           -> GPU 0 上 1 个实例
  - count=2, gpus=[0]           -> GPU 0 上 2 个实例 (共享显存!)
  - count=2, gpus=[0,1]         -> GPU 0 上 1 个, GPU 1 上 1 个
  - count=2, gpus=[0,1,2,3]     -> GPU 0 上 1 个, GPU 1 上 1 个 (round-robin)

重要概念：
  gpus 列表是每个实例可以使用的 GPU 集合。
  如果 count > len(gpus)，多出来的实例会循环分配。
  例如 count=3, gpus=[0,1] -> GPU0 上 2 个, GPU1 上 1 个。
```

#### 3.3.2 dynamic_batching --- 动态批处理

```
核心参数权衡：

  max_queue_delay_microseconds:
    0     -> 不等待，立即执行 (低延迟，低吞吐)
    50    -> 短等待   (延迟轻微增加，吞吐明显提升)
    100   -> 推荐值   (Sweet Spot)
    500   -> 长等待   (高延迟，高吞吐)
    10000 -> 极长等待 (极高延迟，吞吐边际收益递减)

  preferred_batch_size:
    [4, 8, 16, 32] -> Triton 会尽量将请求组合到这些大小
    这取决于实际到达的请求流，不是硬性保证

  preserve_ordering:
    true  -> 请求保持 FIFO 顺序返回 (增加少量延迟)
    false -> 不保证顺序 (更好性能，大多数场景推荐)
```

#### 3.3.3 version_policy --- 版本策略

```
版本策略决定了哪些模型版本被加载：

  latest { num_versions: 2 }
    -> 始终保持最新的 2 个版本处于 READY 状态
    -> 当版本 3 出现时，自动加载版本 3，卸载版本 1

  specific { versions: [1, 3] }
    -> 只加载版本 1 和 3，其他版本忽略
    -> 适合需要在特定版本间切换的场景

  all {}
    -> 加载所有版本
    -> 适合版本数量少且需要全部可用的场景
```

#### 3.3.4 model_warmup --- 模型预热

```
模型预热在 Triton 启动时执行，避免首次推理的冷启动：

  冷启动问题：
    首次推理需要分配 CUDA memory、初始化 cuBLAS handles、JIT 编译等。
    对于大模型，首次推理可能比后续慢 5-10 倍。

  预热机制：
    Triton 加载模型后，立即用 warmup 配置中的样本执行推理。
    这样可以 "预热" 所有 GPU kernel 和内存分配。
    预热请求的响应会被丢弃，不会返回给客户端。
```

#### 3.3.5 sequence_batching --- 序列批处理

```
sequence_batching 用于有状态模型（如 RNN、对话系统）：

  与 dynamic_batching 的区别：
    dynamic_batching 处理无状态请求
    sequence_batching 维护请求序列的状态张量

  使用场景：
    - 多轮对话系统：每轮对话需要上一轮的状态
    - 实时语音识别：流式音频输入，需要帧间状态
    - 强化学习推理：环境状态需要跨步骤维护
```

#### 3.3.6 optimization --- 优化设置

```
optimization 块配置推理优化：

  input_pinned_memory / output_pinned_memory:
    使用 CUDA pinned memory 作为输入/输出缓冲区。
    页锁定内存在物理内存中不可换出，GPU DMA 引擎可直接访问。
    加速 CPU<->GPU 数据传输约 30-50%。

  cuda.graphs:
    启用 CUDA Graph 捕获。将一系列 CUDA kernel 调用"录制"成一个图，
    后续可以一次 launch 执行。消除 kernel launch 开销。
    适用于 kernel 调用模式固定的模型。

  execution_accelerators:
    配置硬件加速器，如 TensorRT、OpenVINO。
    告诉 Triton 使用特定加速器来优化模型执行。
```

### 3.4 运行时模型加载命令

```bash
# 启动 Triton Server（最基本用法）
tritonserver --model-repository=/path/to/model_repository

# 完整启动命令
tritonserver \
    --model-repository=/models \
    --strict-model-config=false \
    --allow-metrics=true \
    --allow-gpu-metrics=true \
    --metrics-port=8002 \
    --model-load-thread-count=4 \
    --backend-config=python,shm-default-byte-size=16777216 \
    --log-verbose=1 \
    --exit-on-error=false

# 参数说明:
#   --strict-model-config:        false=允许缺少部分配置 (开发环境)
#   --model-load-thread-count:    并行加载模型的线程数
#   --backend-config:             传给特定后端的配置 (如 Python backend 的共享内存大小)
#   --log-verbose:                日志级别 0=ERROR, 1=WARNING, 2=INFO
#   --exit-on-error:              true=任何错误退出, false=容忍非致命错误
```

### 3.5 Model Control API (运行时模型管理)

```bash
# Triton 支持 REST API 进行运行时模型管理

# 查看所有模型状态
curl http://localhost:8000/v2/models

# 查看特定模型状态
curl http://localhost:8000/v2/models/llm_model

# 加载模型 (如果之前被卸载)
curl -X POST http://localhost:8000/v2/repository/models/llm_model/load

# 卸载模型 (释放显存)
curl -X POST http://localhost:8000/v2/repository/models/llm_model/unload

# 查看模型仓库索引 (有哪些模型可用)
curl http://localhost:8000/v2/repository/index
```

---


## 4. vLLM 后端集成

### 4.1 集成方式概述

vLLM 与 Triton 的集成有两种主流方式：

```
方式 A: Python Backend 封装 (简单灵活)

  Triton Server
  +------------------------------------------------------+
  |                                                      |
  |  +----------------------------------------------- +  |
  |  |          Python Backend                          |  |
  |  |  +------------------------------------------+   |  |
  |  |  |  model.py                                |   |  |
  |  |  |                                          |   |  |
  |  |  |  class TritonPythonModel:                |   |  |
  |  |  |      def initialize(self, args):         |   |  |
  |  |  |          self.llm = vllm.LLM(            |   |  |
  |  |  |              model="Llama-2-7b",         |   |  |
  |  |  |              tensor_parallel_size=2,     |   |  |
  |  |  |              gpu_memory_utilization=0.95 |   |  |
  |  |  |          )                               |   |  |
  |  |  |                                          |   |  |
  |  |  |      def execute(self, requests):        |   |  |
  |  |  |          outputs = self.llm.generate(    |   |  |
  |  |  |              prompts,                    |   |  |
  |  |  |              sampling_params             |   |  |
  |  |  |          )                               |   |  |
  |  |  |          return responses                |   |  |
  |  |  +------------------------------------------+   |  |
  |  +----------------------------------------------- +  |
  +------------------------------------------------------+

  优点: 开发简单，完全 Python，易于调试和定制
  缺点: Python GIL 可能限制并发，额外序列化开销


方式 B: 专用 vLLM C++ Backend (高性能)

  Triton Server
  +------------------------------------------------------+
  |                                                      |
  |  +----------------------------------------------- +  |
  |  |          vLLM C++ Backend (原生)                  |  |
  |  |  - 直接调用 vLLM C++ 引擎 (LLMEngine)             |  |
  |  |  - 原生 Continuous Batching 支持                  |  |
  |  |  - 共享 KV Cache 内存管理                         |  |
  |  |  - CUDA Stream 直接管理                           |  |
  |  |  - 零拷贝张量传递                                 |  |
  |  +----------------------------------------------- +  |
  +------------------------------------------------------+

  优点: 最高性能，完整的连续批处理支持
  缺点: C++ 编译复杂，版本兼容性约束严格
```

### 4.2 Python Backend 完整实现

以下是生产级别的 vLLM Python Backend 实现，包含完整的错误处理和参数解析：

```python
# model_repository/llm_model/1/model.py
# vLLM 在 Triton Python Backend 中的完整生产级实现

import json
import os
import traceback
import numpy as np
import triton_python_backend_utils as pb_utils
from vllm import LLM, SamplingParams
from vllm.utils import random_uuid


class TritonPythonModel:
    """
    Triton Python Backend 模型类

    生命周期:
      1. initialize()   -- Triton 启动时调用一次
      2. execute()      -- 每次推理请求调用
      3. finalize()     -- Triton 关闭时调用一次

    重要约定:
      - initialize/execute/finalize 是 Triton 的固定接口名
      - execute() 接收 List[InferenceRequest]，返回 List[InferenceResponse]
      - 所有错误都应通过 pb_utils.TritonError 返回，不要抛异常
    """

    def initialize(self, args):
        """
        模型初始化

        Args:
            args: dict, 包含:
                - model_config: JSON 字符串，模型配置
                - model_instance_name: 实例名称
                - model_instance_device_id: GPU ID
        """
        print(f"[Triton-vLLM] ====== 模型初始化开始 ======")

        # 1. 解析模型配置
        self.model_config = json.loads(args['model_config'])
        print(f"[Triton-vLLM] 模型配置已加载")

        # 2. 获取实例信息
        self.instance_name = args.get('model_instance_name', 'unknown')
        device_id = args.get('model_instance_device_id', '0')
        print(f"[Triton-vLLM] 实例: {self.instance_name}, 设备: cuda:{device_id}")

        # 3. 从 config.pbtxt 的 parameters 中读取自定义参数
        params = self.model_config.get('parameters', {})

        model_path = self._get_param(params, 'model_path',
                                      '/models/Llama-2-7b-hf')
        max_model_len = int(self._get_param(params, 'max_model_len', '4096'))
        tp_size = int(self._get_param(params, 'tensor_parallel_size', '1'))
        gpu_mem = float(self._get_param(params, 'gpu_memory_utilization', '0.95'))
        dtype = self._get_param(params, 'dtype', 'float16')
        enable_prefix_caching = self._get_param(params, 'enable_prefix_caching',
                                                 'true').lower() == 'true'

        print(f"[Triton-vLLM] 模型路径: {model_path}")
        print(f"[Triton-vLLM] max_model_len: {max_model_len}")
        print(f"[Triton-vLLM] tensor_parallel_size: {tp_size}")

        # 4. 初始化 vLLM LLM 引擎
        try:
            self.llm = LLM(
                model=model_path,
                max_model_len=max_model_len,
                tensor_parallel_size=tp_size,
                gpu_memory_utilization=gpu_mem,
                dtype=dtype,
                enable_prefix_caching=enable_prefix_caching,
                trust_remote_code=True,
                enforce_eager=False,  # 启用 CUDA Graph
            )
        except Exception as e:
            print(f"[Triton-vLLM] 模型加载失败: {e}")
            traceback.print_exc()
            raise

        # 5. 解析输入输出配置
        # 从 config.pbtxt 中读取 output 定义，用于 Decoupled 模式
        self.output_names = [
            output['name']
            for output in self.model_config.get('output', [])
        ]
        self.has_decoupled_output = any(
            output.get('allow_ragged_batch', False)
            for output in self.model_config.get('output', [])
        )

        # 6. 统计信息
        self.request_count = 0
        self.total_tokens = 0

        print(f"[Triton-vLLM] ====== 模型初始化完成 ======")

    def execute(self, requests):
        """
        处理推理请求

        Args:
            requests: List[pb_utils.InferenceRequest]

        Returns:
            List[pb_utils.InferenceResponse]
        """
        responses = []

        for request in requests:
            try:
                response = self._process_single_request(request)
                responses.append(response)
            except Exception as e:
                print(f"[Triton-vLLM] 处理请求失败: {e}")
                traceback.print_exc()
                # 返回错误响应而不是崩溃
                error_response = pb_utils.InferenceResponse(
                    error=pb_utils.TritonError(
                        f"推理失败: {str(e)}"
                    )
                )
                responses.append(error_response)

        return responses

    def _process_single_request(self, request):
        """处理单个推理请求"""

        # 1. 提取文本输入
        text_input_tensor = pb_utils.get_input_tensor_by_name(
            request, "text_input"
        )
        if text_input_tensor is None:
            raise ValueError("缺少 text_input 输入")
        prompt = text_input_tensor.as_numpy()[0]
        if isinstance(prompt, bytes):
            prompt = prompt.decode('utf-8')
        elif isinstance(prompt, np.ndarray):
            prompt = str(prompt)

        # 2. 提取可选参数
        max_tokens = self._get_optional_input(request, "max_tokens", 256)
        temperature = self._get_optional_input(request, "temperature", 0.7)
        top_p = self._get_optional_input(request, "top_p", 0.95)
        top_k = self._get_optional_input(request, "top_k", 50)
        repetition_penalty = self._get_optional_input(
            request, "repetition_penalty", 1.0
        )
        stop_strings = self._get_optional_input(
            request, "stop_strings", ""
        )

        # 3. 配置采样参数
        sampling_params = SamplingParams(
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            max_tokens=int(max_tokens),
            repetition_penalty=repetition_penalty,
            stop=stop_strings.split(',') if stop_strings else None,
        )

        # 4. 生成请求 ID (用于追踪)
        request_id = random_uuid()

        # 5. 调用 vLLM 生成
        try:
            outputs = self.llm.generate(
                [prompt],
                sampling_params=sampling_params,
                request_id=request_id,
            )
        except Exception as e:
            raise RuntimeError(f"vLLM generate 失败: {e}")

        # 6. 提取生成结果
        if not outputs or not outputs[0].outputs:
            generated_text = ""
        else:
            generated_text = outputs[0].outputs[0].text

        # 7. 统计
        self.request_count += 1
        if outputs and outputs[0].outputs:
            self.total_tokens += len(outputs[0].outputs[0].token_ids)

        # 8. 构造输出张量
        output_tensor = pb_utils.Tensor(
            "text_output",
            np.array([generated_text.encode('utf-8')], dtype=np.object_)
        )

        # 可选：输出 token 级别信息
        if outputs and outputs[0].outputs:
            token_ids_tensor = pb_utils.Tensor(
                "token_ids",
                np.array(outputs[0].outputs[0].token_ids, dtype=np.int32)
            )
            return pb_utils.InferenceResponse(
                output_tensors=[output_tensor, token_ids_tensor]
            )

        return pb_utils.InferenceResponse(
            output_tensors=[output_tensor]
        )

    def finalize(self):
        """模型卸载时的清理"""
        print(f"[Triton-vLLM] 模型卸载")
        print(f"[Triton-vLLM] 总请求数: {self.request_count}")
        print(f"[Triton-vLLM] 总 tokens: {self.total_tokens}")
        del self.llm

    # ===== 辅助方法 =====

    def _get_param(self, params, key, default):
        """从 parameters 字典中提取参数值"""
        param = params.get(key, {})
        return param.get('string_value', str(default))

    def _get_optional_input(self, request, name, default):
        """提取可选输入参数"""
        tensor = pb_utils.get_input_tensor_by_name(request, name)
        if tensor is None:
            return default
        value = tensor.as_numpy()[0]
        if isinstance(value, bytes):
            return value.decode('utf-8')
        if isinstance(value, np.floating):
            return float(value)
        if isinstance(value, np.integer):
            return int(value)
        return value
```

### 4.3 vLLM 后端的配置（config.pbtxt）

```protobuf
# model_repository/llm_model/config.pbtxt
# vLLM 后端模型的完整配置

name: "llm_model"
platform: "python"

# 最大批大小
# 注意: 使用 vLLM 的 continuous batching 时，
#       这里的 max_batch_size 应该设为 0 (不使用 Triton 的批处理)
#       因为 vLLM 内部已经做了更高效的 continuous batching
max_batch_size: 0

input [
  {
    name: "text_input"
    data_type: TYPE_STRING
    dims: [1]
  },
  {
    name: "max_tokens"
    data_type: TYPE_INT32
    dims: [1]
    optional: true
  },
  {
    name: "temperature"
    data_type: TYPE_FP32
    dims: [1]
    optional: true
  },
  {
    name: "top_p"
    data_type: TYPE_FP32
    dims: [1]
    optional: true
  },
  {
    name: "top_k"
    data_type: TYPE_INT32
    dims: [1]
    optional: true
  },
  {
    name: "repetition_penalty"
    data_type: TYPE_FP32
    dims: [1]
    optional: true
  },
  {
    name: "stop_strings"
    data_type: TYPE_STRING
    dims: [1]
    optional: true
  }
]

output [
  {
    name: "text_output"
    data_type: TYPE_STRING
    dims: [1]
  },
  {
    name: "token_ids"
    data_type: TYPE_INT32
    dims: [-1]
  }
]

# 实例组: 单实例，使用全部 4 张 GPU
# vLLM 内部会管理 tensor parallelism
instance_group [
  {
    count: 1
    kind: KIND_GPU
    gpus: [0, 1, 2, 3]    # 4 张 GPU 做 TP (tensor_parallel_size=4)
  }
]

# vLLM 不使用 Triton 的 dynamic batching
# 因为 vLLM 内部有更高效的 continuous batching
# dynamic_batching 块可以省略或设为保守值

# 模型参数 (传递给 Python Backend 的 initialize())
parameters {
  key: "model_path"
  value: { string_value: "/models/Llama-2-13b-hf" }
}
parameters {
  key: "max_model_len"
  value: { string_value: "8192" }
}
parameters {
  key: "tensor_parallel_size"
  value: { string_value: "4" }
}
parameters {
  key: "gpu_memory_utilization"
  value: { string_value: "0.95" }
}
parameters {
  key: "dtype"
  value: { string_value: "float16" }
}
parameters {
  key: "enable_prefix_caching"
  value: { string_value: "true" }
}

# 模型预热
model_warmup [
  {
    name: "warmup_1"
    batch_size: 1
    inputs {
      key: "text_input"
      value: "Hello, please introduce yourself."
    }
    inputs {
      key: "max_tokens"
      value: "50"
    }
  }
]
```

### 4.4 Triton Batching vs vLLM Continuous Batching 交互

这是一个非常关键的架构点：

```
Triton Dynamic Batching 与 vLLM Continuous Batching 的交互:

  方案 1: 关闭 Triton Batching (推荐)
  +------------------------------------------------------------------+
  |                                                                  |
  |  max_batch_size: 0  (config.pbtxt)                               |
  |                                                                  |
  |  Triton 不做批处理，每个请求直接到达 vLLM。                          |
  |  vLLM 内部使用自己的 Continuous Batching 引擎调度。                  |
  |                                                                  |
  |  请求流:                                                          |
  |    请求 → Triton(直接转发) → vLLM → Continuous Batching → GPU     |
  |                                                                  |
  |  优点: 完全利用 vLLM 的 CB 能力，无双重批处理冲突                    |
  |                                                                  |
  +------------------------------------------------------------------+

  方案 2: 使用 Triton Batching (不推荐)
  +------------------------------------------------------------------+
  |                                                                  |
  |  max_batch_size: 8, dynamic_batching { ... }                     |
  |                                                                  |
  |  Triton 先做一层批处理，将 8 个请求打包发送给 vLLM。                   |
  |  vLLM 内部再用 continuous batching 处理这 8 个请求。                 |
  |                                                                  |
  |  问题:                                                            |
  |    1. Triton 的 fixed batch 生命周期固定 (全部完成才释放)             |
  |    2. vLLM 的 dynamic batch 每步可变化 → 冲突!                      |
  |    3. 早完成的请求会被晚完成的拖累 (短板效应)                         |
  |                                                                  |
  +------------------------------------------------------------------+
```

**结论：使用 vLLM Backend 时，应设置 `max_batch_size: 0` 关闭 Triton 的 Dynamic Batching，让 vLLM 内部的 Continuous Batching 全权负责调度。**

### 4.5 启动命令

```bash
# 使用 Docker 启动 Triton + vLLM
docker run --gpus all --rm \
    -p 8000:8000 -p 8001:8001 -p 8002:8002 \
    -v $(pwd)/model_repository:/models \
    -v /mnt/models/Llama-2-13b-hf:/models/Llama-2-13b-hf \
    --shm-size=16g \
    nvcr.io/nvidia/tritonserver:24.04-py3 \
    tritonserver \
        --model-repository=/models \
        --strict-model-config=false \
        --allow-metrics=true \
        --allow-gpu-metrics=true \
        --metrics-port=8002 \
        --log-verbose=1

# 验证服务
curl http://localhost:8000/v2/health/ready
# 预期: 返回 HTTP 200

# 查看模型列表
curl http://localhost:8000/v2/models
# 预期: {"models":[{"name":"llm_model",...}]}
```

### 4.6 性能对比：Triton+vLLM vs 裸 vLLM

```
性能基准测试 (Llama-2-7B, A100-80GB, 256 output tokens, 32 并发):

+------------------+-------------+-------------+------------+----------+
| 方案              | 吞吐 (tok/s)| P50 延迟    | P99 延迟   | 额外开销  |
+------------------+-------------+-------------+------------+----------+
| 裸 vLLM (HTTP)   | 2450 tok/s  | 2800 ms     | 5200 ms    | 基准     |
| Triton+vLLM(HTTP)| 2420 tok/s  | 2830 ms     | 5350 ms    | ~1.2%    |
| Triton+vLLM(gRPC)| 2435 tok/s  | 2815 ms     | 5300 ms    | ~0.6%    |
+------------------+-------------+-------------+------------+----------+

关键发现:
  1. Triton 的额外开销在 LLM 场景中可以忽略 (~1-2%)
  2. gRPC 协议比 HTTP 略快
  3. 主要延迟 (>95%) 仍然在模型计算 (GPU Decode)
  4. Triton 带来的多模型管理、监控等收益远超这点开销
```

### 4.7 已知限制与 Workarounds

```
限制 1: Python GIL
  现象: 多个 Python Backend 实例共享 GIL，高并发时可能阻塞
  Workaround:
    a) 使用 C++ vLLM Backend（无 GIL 限制）
    b) 使用多个 Triton 进程（每个进程独立的 Python 解释器）
    c) 将计算密集部分下放到 C++ (vLLM 的 generate 调用本身释放 GIL)

限制 2: 大张量传输开销
  现象: 输入 prompt 很长时，JSON 序列化开销不可忽略
  Workaround:
    a) 使用 gRPC 代替 HTTP (Protobuf 序列化更高效)
    b) 使用 Shared Memory 传输 (支持 binary 数据直传)

限制 3: 版本兼容性
  现象: vLLM 版本升级可能导致 Backend 代码不兼容
  Workaround:
    a) 固定 vLLM 版本 (pip install vllm==X.Y.Z)
    b) 在 initialize() 中做版本检查
    c) 使用 Docker 镜像锁定环境
```

---

## 5. 动态批处理深度剖析

### 5.1 什么是 Dynamic Batching

Dynamic Batching 是 Triton 的核心调度策略。它的基本思想是：**延迟执行请求，等待收集更多请求组成更大的批次，用延迟换取吞吐量。**

```
Dynamic Batching 时间线 (max_queue_delay=100us):

  时间轴 -->
  0us    50us   100us   150us   200us   250us   300us
  |       |       |       |       |       |       |
  Req A --+---------------------------+  返回 A
          |                           |
  Req B --------+                     |  返回 B
          |     |                     |
  Req C ----------+                   |  返回 C
          |     |  |                  |
          |     |  +-- 等待窗口关闭 --+
          |     |
          |     +-- batch=[A,B,C] --> 推理执行 -->
          |
          +-- 窗口开始, timer=0
```

### 5.2 核心参数深入

```
max_queue_delay_microseconds 的影响（最重要的参数）:

  +-----------------------------------------------------------+
  |                                                            |
  |  delay=0us (无批处理):                                     |
  |    每个请求立即执行                                          |
  |    吞吐: 基准 (batch=1 的吞吐)                               |
  |    延迟: 最低                                                |
  |    适用: 对单个请求延迟极度敏感的场景                          |
  |                                                            |
  |  delay=100us (微批处理):                                    |
  |    短窗口等待，收集 2-3 个请求                                |
  |    吞吐: 基准的 2-5x                                         |
  |    延迟: 增加 100-200us                                      |
  |    适用: 在线推理，平衡延迟和吞吐                              |
  |                                                            |
  |  delay=1000us (批次处理):                                   |
  |    长窗口等待，收集 8-32 个请求                               |
  |    吞吐: 基准的 5-15x                                        |
  |    延迟: 增加 1-2ms                                          |
  |    适用: 离线批处理，最大化吞吐                                |
  |                                                            |
  |  delay=10000us (大批次处理):                                |
  |    极长窗口，几乎可以保证满 batch                              |
  |    吞吐: 接近理论上限                                        |
  |    延迟: 增加 10ms+                                          |
  |    适用: 纯离线场景，吞吐优先                                  |
  +-----------------------------------------------------------+

  经验法则 (传统视觉/NLP 模型):
    delay = P50 请求间隔 * 3-5
    如果请求间隔是 20us，delay 设为 60-100us

  对于 LLM 推理:
    不要在这一层使用 Dynamic Batching！
    vLLM 的 Continuous Batching 完全替代了 Triton 的 Dynamic Batching。
```

### 5.3 Dynamic Batching vs Continuous Batching (核心对比)

这是理解 Triton+vLLM 架构最重要的一节：

```
+=======================================================================+
||              Dynamic Batching (Triton) vs Continuous Batching (vLLM)   ||
+=======================================================================+
||                                                                     ||
||  Dynamic Batching (Triton):                                          ||
||                                                                     ||
||  时间线:                                                             ||
||  ==============|--batch [A,B,C] 执行中--|=============|--返回--|      ||
||       ^                                  ^                           ||
||       |                                  |                           ||
||    等待窗口关闭                        批内所有请求完成                  ||
||    形成固定 batch                      才一起返回                        ||
||                                                                     ||
||  特点:                                                               ||
||    - Batch 在窗口关闭时固定，整个推理期间不变                           ||
||    - 所有请求的推理时间必须相同 (否则快的等慢的)                          ||
||    - 适合: 固定延迟的模型 (ResNet, BERT, ...)                          ||
||    - batch 生命周期: 形成 -> 推理 -> 全部完成 -> 释放                    ||
||                                                                     ||
+=======================================================================+
||                                                                     ||
||  Continuous Batching (vLLM):                                         ||
||                                                                     ||
||  时间线:                                                             ||
||  ====[AB]===[ABC]===[BC]===[CD]===[D]===    (每个 '=' 是一个 step)      ||
||     ^  ^    ^       ^     ^     ^                                     ||
||     |  |    |       |     |     |                                    ||
||     A  B    C 加入   A完成  D加入  B,C,D...                            ||
||                                                                     ||
||  特点:                                                               ||
||    - Batch 组成在每个 decode step 都可能变化                            ||
||    - 新请求随时可以加入 (prefill 后)                                    ||
||    - 完成的请求立即移出，不阻塞其他请求                                  ||
||    - 适合: 变长生成的模型 (LLM)                                         ||
||    - batch 生命周期: 每个 step 都是一次新的批形成                        ||
||                                                                     ||
+=======================================================================+

核心区别图示:

  假设有请求 A(需要 2 步) 和 B(需要 4 步)，C 在 step 2 之后到达:

  Dynamic Batching:
    Step:  1       2       3       4
    Batch: [A,B]   [A,B]   [A,B]   [A,B]    <- A 在 step 2 就完成了，但还要等到 step 4!
                   A done
    问题: A 被 B 拖累，浪费了 2 个 step 的 GPU 资源

  Continuous Batching:
    Step:  1       2       3       4
    Batch: [A,B]   [B,C]   [B,C]   [B]       <- 每步动态调整
                   ^       A done  ^
                   |               C done
                   C 加入
    优势: GPU 资源不浪费，A 和 C 完成后立即释放
```

### 5.4 何时 Triton 的 Batching 足够，何时需要 Continuous Batching

```
+------------------------------------------------------------------+
| 场景判断                                                           |
+------------------------------------------------------------------+
|                                                                  |
|  模型是固定延迟模型 (BERT, ResNet, Whisper encoder):                |
|    -> Triton Dynamic Batching 完全足够且高效                       |
|    -> 无需 Continuous Batching                                    |
|                                                                  |
|  模型是 LLM (变长生成, 2-4096 tokens):                             |
|    -> 需要 Continuous Batching (vLLM 提供)                        |
|    -> Triton Dynamic Batching 不适合 LLM 的变长特性                |
|    -> 关闭 Triton 的 batching，让 vLLM 全权接管                    |
|                                                                  |
|  混合场景 (LLM + 传统模型):                                        |
|    -> LLM 用 vLLM CB，传统模型用 Triton DB                        |
|    -> 这是 Triton 多模型管理的价值所在                              |
|                                                                  |
+------------------------------------------------------------------+
```

### 5.5 Triton Dynamic Batching 的高级配置

```protobuf
# 完整的高级 Dynamic Batching 配置示例

dynamic_batching {
  # --- 基础参数 ---
  max_queue_delay_microseconds: 100
  preferred_batch_size: [4, 8, 16, 32]
  max_batch_size: 64
  preserve_ordering: false

  # --- 优先级队列 ---
  priority_levels: 3
  default_priority_level: 2

  # 高优先级队列 (优先级 1)
  priority_queue_policy {
    key: 1
    value: {
      max_queue_delay_microseconds: 50    # 高优先级只等 50us
      timeout_action: REJECT              # 超时直接拒绝
      default_timeout_microseconds: 5000
      allow_queue_limit: 10               # 最多排队 10 个请求
    }
  }

  # 默认优先级队列 (优先级 2)
  priority_queue_policy {
    key: 2
    value: {
      max_queue_delay_microseconds: 100
      timeout_action: DELAY               # 超时降级处理 (继续等待)
      default_timeout_microseconds: 10000
      allow_queue_limit: 50
    }
  }

  # 低优先级队列 (优先级 3)
  priority_queue_policy {
    key: 3
    value: {
      max_queue_delay_microseconds: 500   # 低优先级可以等更久
      timeout_action: DELAY
      default_timeout_microseconds: 30000
      allow_queue_limit: 200
    }
  }
}
```

---

## 6. 模型流水线 (Model Ensembles)

### 6.1 Ensemble 概念

Triton 的 Ensemble 允许将多个模型串联成一条**有向无环图 (DAG)**。这是一种**声明式**的流水线定义方式，不需要编写调度代码，Triton 自动管理数据流转。

```
Ensemble 的本质:

  传统的多模型调用 (手动编排):
    输入 -> 调用模型 A -> 提取结果 -> 调用模型 B -> 提取结果 -> 调用模型 C -> 输出
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
           需要写大量胶水代码

  Triton Ensemble (声明式):
    输入 -> [A -> B -> C] -> 输出
           ^^^^^^^^^^^^^^
           只需定义 config.pbtxt 中的数据流动规则
```

### 6.2 RAG Pipeline Ensemble 完整示例

```
目标: 构建一个完整的 RAG 服务
  Embedding Model -> Vector Search -> LLM

数据流:
  query (用户问题)
    |
    v
  +-------------+
  | embedding   | (BGE-Large-Zh-v1.5)
  | model       |
  | text->vec   |
  +------+------+
         | query_vector
         v
  +-------------+
  | vector      | (FAISS/Milvus 封装)
  | search      |
  | vec->docs   |
  +------+------+
         | retrieved_docs
         v
  +-------------+
  | llm_model   | (vLLM, Llama-2-13B)
  |             |
  | docs->ans   |
  +------+------+
         |
         v
  answer (LLM 回答)
```

#### Step 1: Embedding Model 配置

```protobuf
# model_repository/embedding_model/config.pbtxt

name: "embedding_model"
platform: "python"
max_batch_size: 32

input [
  {
    name: "text"
    data_type: TYPE_STRING
    dims: [1]
  }
]

output [
  {
    name: "embedding"
    data_type: TYPE_FP32
    dims: [1024]    # BGE-Large-Zh 输出 1024 维向量
  }
]

instance_group [
  {
    count: 1
    kind: KIND_GPU
    gpus: [0]
  }
]

dynamic_batching {
  max_queue_delay_microseconds: 50
  preferred_batch_size: [4, 8, 16]
}
```

```python
# model_repository/embedding_model/1/model.py

import numpy as np
import triton_python_backend_utils as pb_utils
from sentence_transformers import SentenceTransformer


class TritonPythonModel:
    def initialize(self, args):
        self.model = SentenceTransformer(
            'BAAI/bge-large-zh-v1.5',
            device='cuda'
        )

    def execute(self, requests):
        responses = []
        for request in requests:
            text = pb_utils.get_input_tensor_by_name(
                request, "text"
            ).as_numpy()[0]
            if isinstance(text, bytes):
                text = text.decode('utf-8')

            embedding = self.model.encode(
                text,
                normalize_embeddings=True,
                show_progress_bar=False
            )

            output = pb_utils.Tensor(
                "embedding",
                embedding.astype(np.float32).reshape(1, -1)
            )
            responses.append(
                pb_utils.InferenceResponse(output_tensors=[output])
            )

        return responses
```

#### Step 2: Vector Search Model 配置

```protobuf
# model_repository/vector_search/config.pbtxt

name: "vector_search"
platform: "python"
max_batch_size: 0          # 向量搜索暂不支持批处理

input [
  {
    name: "query_embedding"
    data_type: TYPE_FP32
    dims: [1024]
  }
]

output [
  {
    name: "documents"
    data_type: TYPE_STRING
    dims: [-1]              # 可变数量的文档
  },
  {
    name: "scores"
    data_type: TYPE_FP32
    dims: [-1]
  }
]

instance_group [
  {
    count: 1
    kind: KIND_CPU           # 向量搜索可以在 CPU 上运行
  }
]

parameters {
  key: "index_path"
  value: { string_value: "/data/faiss_index/zh_wiki.index" }
}

parameters {
  key: "top_k"
  value: { string_value: "5" }
}
```

```python
# model_repository/vector_search/1/model.py

import json
import faiss
import numpy as np
import triton_python_backend_utils as pb_utils


class TritonPythonModel:
    def initialize(self, args):
        model_config = json.loads(args['model_config'])
        params = model_config.get('parameters', {})

        index_path = params.get('index_path', {}).get(
            'string_value', '/data/faiss_index/index.faiss'
        )
        self.top_k = int(params.get('top_k', {}).get(
            'string_value', '5'
        ))

        # 加载 FAISS 索引
        self.index = faiss.read_index(index_path)

        # 加载文档文本 (索引只存向量，需要单独存文本)
        doc_path = index_path.replace('.index', '_docs.json')
        with open(doc_path, 'r') as f:
            self.documents = json.load(f)

    def execute(self, requests):
        responses = []
        for request in requests:
            embedding = pb_utils.get_input_tensor_by_name(
                request, "query_embedding"
            ).as_numpy().flatten().astype(np.float32)

            # FAISS 搜索
            distances, indices = self.index.search(
                embedding.reshape(1, -1), self.top_k
            )

            # 提取文档
            retrieved_docs = []
            scores = []
            for dist, idx in zip(distances[0], indices[0]):
                if idx >= 0 and idx < len(self.documents):
                    retrieved_docs.append(self.documents[idx])
                    scores.append(float(1.0 / (1.0 + dist)))

            doc_tensor = pb_utils.Tensor(
                "documents",
                np.array(retrieved_docs, dtype=np.object_)
            )
            score_tensor = pb_utils.Tensor(
                "scores",
                np.array(scores, dtype=np.float32)
            )

            responses.append(pb_utils.InferenceResponse(
                output_tensors=[doc_tensor, score_tensor]
            ))

        return responses
```

#### Step 3: LLM Model 配置

```protobuf
# model_repository/llm_model/config.pbtxt

name: "llm_model"
platform: "python"
max_batch_size: 0          # vLLM 使用自己的 continuous batching

input [
  {
    name: "text_input"
    data_type: TYPE_STRING
    dims: [1]
  },
  {
    name: "max_tokens"
    data_type: TYPE_INT32
    dims: [1]
    optional: true
  }
]

output [
  {
    name: "text_output"
    data_type: TYPE_STRING
    dims: [1]
  }
]

instance_group [
  {
    count: 1
    kind: KIND_GPU
    gpus: [0, 1]
  }
]

parameters {
  key: "model_path"
  value: { string_value: "/models/Llama-2-13b-hf" }
}
parameters {
  key: "tensor_parallel_size"
  value: { string_value: "2" }
}
```

#### Step 4: Ensemble 配置 (串联所有步骤)

```protobuf
# model_repository/rag_pipeline/config.pbtxt

name: "rag_pipeline"
platform: "ensemble"
max_batch_size: 8

# Ensemble 的对外输入 (客户端看到的接口)
input [
  {
    name: "query"
    data_type: TYPE_STRING
    dims: [1]
  },
  {
    name: "max_tokens"
    data_type: TYPE_INT32
    dims: [1]
    optional: true
  }
]

# Ensemble 的对外输出
output [
  {
    name: "answer"
    data_type: TYPE_STRING
    dims: [1]
  },
  {
    name: "retrieved_documents"
    data_type: TYPE_STRING
    dims: [-1]
  }
]

# 定义数据流图 (DAG)
ensemble_scheduling {

  # Step 1: Embedding
  step [
    {
      model_name: "embedding_model"
      model_version: 1
      input_map {
        key: "text"                # embedding_model 的输入名
        value: "query"             # ensemble 的输入 (query)
      }
      output_map {
        key: "embedding"           # embedding_model 的输出名
        value: "query_vector"      # 映射到内部变量 _query_vector
      }
    }
  ]

  # Step 2: Vector Search
  step [
    {
      model_name: "vector_search"
      model_version: 1
      input_map {
        key: "query_embedding"     # vector_search 的输入名
        value: "query_vector"      # 来自 Step 1 的输出
      }
      output_map {
        key: "documents"           # vector_search 的输出名
        value: "retrieved_docs"    # 映射到内部变量 _retrieved_docs
      }
    }
  ]

  # Step 3: LLM Generation
  step [
    {
      model_name: "llm_model"
      model_version: 1
      input_map {
        key: "text_input"          # llm_model 的输入名
        value: "retrieved_docs"    # 来自 Step 2 的输出
        # 注意: 这里的实际效果是
        # prompt = retrieved_docs 的内容 + query
        # 这需要在 llm_model 的 model.py 中构造完整 prompt
      }
      input_map {
        key: "max_tokens"
        value: "max_tokens"        # 透传 ensemble 的输入
      }
      output_map {
        key: "text_output"         # llm_model 的输出名
        value: "answer"            # 映射到 ensemble 的对外输出
      }
    }
  ]

  # 额外输出: 返回检索到的文档 (用于调试)
  step [
    {
      model_name: "vector_search"
      model_version: 1
      input_map {
        key: "query_embedding"
        value: "query_vector"
      }
      output_map {
        key: "documents"
        value: "retrieved_documents"  # 映射到 ensemble 输出
      }
    }
  ]
}
```

### 6.3 BLS (Business Logic Scripting) --- 灵活编排

当 Ensemble 的声明式配置不够灵活时（如需要条件分支、循环、外部 API 调用），可以使用 BLS：

```python
# model_repository/rag_bls/1/model.py
# BLS 方式实现 RAG，支持复杂业务逻辑

import json
import numpy as np
import triton_python_backend_utils as pb_utils


class TritonPythonModel:
    def initialize(self, args):
        self.model_config = json.loads(args['model_config'])

    def execute(self, requests):
        responses = []
        for request in requests:
            # 1. 解析输入
            query = pb_utils.get_input_tensor_by_name(
                request, "query"
            ).as_numpy()[0]
            if isinstance(query, bytes):
                query = query.decode('utf-8')
            max_tokens = self._get_optional(request, "max_tokens", 256)

            # 2. 调用 Embedding
            emb_response = self._call_model(
                "embedding_model",
                {"text": np.array([query.encode()], dtype=np.object_)},
                ["embedding"]
            )
            if emb_response is None:
                responses.append(self._error("Embedding 失败"))
                continue
            embedding = pb_utils.get_output_tensor_by_name(
                emb_response, "embedding"
            ).as_numpy()

            # 3. 调用向量搜索
            search_response = self._call_model(
                "vector_search",
                {"query_embedding": embedding.astype(np.float32)},
                ["documents", "scores"]
            )
            if search_response is None:
                responses.append(self._error("向量搜索失败"))
                continue

            docs = pb_utils.get_output_tensor_by_name(
                search_response, "documents"
            ).as_numpy()
            scores = pb_utils.get_output_tensor_by_name(
                search_response, "scores"
            ).as_numpy()

            # 4. 业务逻辑: 过滤低分文档
            high_quality = [
                d.decode() if isinstance(d, bytes) else d
                for d, s in zip(docs, scores)
                if s > 0.5
            ][:5]

            # 5. 业务逻辑: 构造 Prompt
            prompt = self._build_rag_prompt(query, high_quality)

            # 6. 调用 LLM
            llm_response = self._call_model(
                "llm_model",
                {
                    "text_input": np.array(
                        [prompt.encode()], dtype=np.object_
                    ),
                    "max_tokens": np.array([max_tokens], dtype=np.int32),
                },
                ["text_output"]
            )
            if llm_response is None:
                responses.append(self._error("LLM 生成失败"))
                continue

            answer = pb_utils.get_output_tensor_by_name(
                llm_response, "text_output"
            ).as_numpy()[0]
            if isinstance(answer, bytes):
                answer = answer.decode('utf-8')

            # 7. 返回结果
            output = pb_utils.Tensor(
                "answer",
                np.array([answer.encode()], dtype=np.object_)
            )
            responses.append(
                pb_utils.InferenceResponse(output_tensors=[output])
            )

        return responses

    def _call_model(self, model_name, inputs_dict, output_names):
        """在 BLS 中调用其他 Triton 模型"""
        tensors = [
            pb_utils.Tensor(name, data)
            for name, data in inputs_dict.items()
        ]
        infer_request = pb_utils.InferenceRequest(
            model_name=model_name,
            requested_output_names=output_names,
            inputs=tensors,
        )
        response = infer_request.exec()
        if response.has_error():
            print(f"模型 {model_name} 调用失败: {response.error().message()}")
            return None
        return response

    def _build_rag_prompt(self, query, docs):
        """构造 RAG prompt (关键业务逻辑)"""
        if not docs:
            return f"问题: {query}\n回答: "

        context = "\n\n".join(
            f"[参考文档 {i+1}]: {doc}"
            for i, doc in enumerate(docs)
        )
        return f"""请根据以下参考文档回答问题。

{context}

问题: {query}

请综合参考文档的内容，给出详细的回答。

回答: """

    def _get_optional(self, request, name, default):
        tensor = pb_utils.get_input_tensor_by_name(request, name)
        if tensor is None:
            return default
        val = tensor.as_numpy()[0]
        return int(val) if isinstance(val, (np.integer,)) else default

    def _error(self, msg):
        return pb_utils.InferenceResponse(
            error=pb_utils.TritonError(msg)
        )
```

### 6.4 Ensemble vs BLS 选择指南

```
+---------------------------------------------------------------+
|  Ensemble 还是 BLS? 决策指南                                    |
+---------------------------------------------------------------+
|                                                               |
|  选择 Ensemble (声明式):                                        |
|    - 流水线结构固定，DAG 不会动态改变                             |
|    - 不需要条件分支或循环                                        |
|    - 不需要调用外部 API (数据库、HTTP 服务)                       |
|    - 希望性能最优 (Triton 原生优化)                               |
|    - 流水线纯粹由 Triton 模型组成                                |
|    - 例子: Embedding -> Search -> LLM (标准 RAG)                |
|                                                               |
|  选择 BLS (编程式):                                             |
|    - 需要复杂的业务逻辑 (过滤、格式化、条件判断)                    |
|    - 需要调用外部服务 (Redis、数据库、HTTP API)                   |
|    - 需要循环或递归调用模型                                      |
|    - 需要动态决定调用哪个模型                                     |
|    - 需要在模型间做字符串处理或复杂数据变换                        |
|    - 例子: Agent 工具调用、多轮对话管理、结果后处理                |
|                                                               |
|  混合方案:                                                      |
|    - 外层用 BLS 做业务逻辑                                       |
|    - 内层用 Ensemble 做纯模型流水线                               |
|    - 这是生产环境中最常见的模式                                   |
+---------------------------------------------------------------+
```

### 6.5 Multi-Turn Agent with Tools Ensemble 示例

```
复杂 Agent 场景的 Triton 编排:

  +------------------------------------------------------------------+
  |                      Agent Pipeline (BLS)                         |
  |                                                                  |
  |  用户: "北京今天天气怎么样？"                                       |
  |       |                                                          |
  |       v                                                          |
  |  +------------------+                                            |
  |  | 1. 意图识别       |  (调用 classification_model)                |
  |  |   输出: weather   |                                            |
  |  +--------+---------+                                            |
  |           |                                                      |
  |           v                                                      |
  |  +------------------+                                            |
  |  | 2. 参数提取       |  (调用 NER model)                          |
  |  |   输出: 北京, 今天 |                                            |
  |  +--------+---------+                                            |
  |           |                                                      |
  |           v                                                      |
  |  +------------------+                                            |
  |  | 3. 工具调用       |  (外部 HTTP API: weather.com)               |
  |  |   输出: 晴, 25C   |                                            |
  |  +--------+---------+                                            |
  |           |                                                      |
  |           v                                                      |
  |  +------------------+                                            |
  |  | 4. LLM 生成回复   |  (调用 llm_model)                          |
  |  |   "北京今天天气    |                                            |
  |  |    晴朗，气温 25C" |                                            |
  |  +------------------+                                            |
  |                                                                  |
  +------------------------------------------------------------------+
```

这种复杂编排只能用 BLS 实现（不能纯 Ensemble），因为步骤 4 依赖步骤 3 的外部 API 结果。

### 6.6 错误处理

```python
# Ensemble 中的错误传播

def _call_model_safe(self, model_name, inputs_dict, output_names):
    """
    安全调用模型，优雅处理错误
    """
    try:
        tensors = [
            pb_utils.Tensor(name, data)
            for name, data in inputs_dict.items()
        ]
        infer_request = pb_utils.InferenceRequest(
            model_name=model_name,
            requested_output_names=output_names,
            inputs=tensors,
        )

        # 设置超时 (毫秒)
        infer_request.set_timeout(30000)  # 30 秒超时

        response = infer_request.exec()

        if response.has_error():
            error_msg = response.error().message()
            print(f"[ERROR] {model_name}: {error_msg}")

            # 根据错误类型采取不同策略：
            # - RETRY: 重试 (瞬时错误)
            # - FALLBACK: 降级 (使用默认值)
            # - FAIL: 直接返回错误
            return None, error_msg

        return response, None

    except Exception as e:
        print(f"[EXCEPTION] {model_name}: {e}")
        return None, str(e)


# 使用降级策略
def execute_with_fallback(self, requests):
    """带降级策略的 BLS 执行"""
    responses = []
    for request in requests:
        query = pb_utils.get_input_tensor_by_name(
            request, "query"
        ).as_numpy()[0].decode()

        # 尝试搜索
        search_response, error = self._call_model_safe(
            "vector_search",
            {"query_embedding": embedding},
            ["documents"]
        )

        if error:
            # 降级: 搜索失败时，不使用检索文档
            prompt = f"问题: {query}\n回答: "
        else:
            docs = pb_utils.get_output_tensor_by_name(
                search_response, "documents"
            ).as_numpy()
            prompt = self._build_rag_prompt(query, docs)

        # 继续 LLM 调用
        llm_response, _ = self._call_model_safe(
            "llm_model",
            {"text_input": np.array([prompt.encode()], dtype=np.object_)},
            ["text_output"]
        )

        # 构造响应 (包含错误信息)
        ...
```

---

## 7. 性能分析与调优

### 7.1 perf_analyzer --- 性能压测工具

`perf_analyzer` 是 NVIDIA 官方提供的 Triton 性能测试工具：

```bash
# 安装
pip install tritonclient[all]

# 基本用法: 对单个模型进行压测
perf_analyzer \
    -m llm_model \
    -u localhost:8001 \
    --concurrency-range 1:64:4 \
    --measurement-interval 10000 \
    --input-data random \
    --shape text_input:1 \
    --string-length 512

# 常用参数说明:
#   -m MODEL        : 模型名称
#   -u URL          : Triton 服务地址 (默认 localhost:8000)
#   -i GRPC         : 使用 gRPC 协议
#   --concurrency-range START:END:STEP  : 并发数扫描范围
#   --request-rate-range START:END:STEP : 请求速率扫描范围
#   --measurement-interval MS           : 测量间隔 (毫秒)
#   --input-data random|zero|FILE       : 输入数据类型
#   --shape NAME:SHAPE                  : 输入张量形状
#   --string-length N                   : 字符串输入长度
#   --percentile 95                     : 输出指定百分位延迟
#   -f OUTPUT.csv                      : 输出 CSV 格式结果
#   -v                                  : 详细输出

# 完整示例: LLM 模型压测
perf_analyzer \
    -m llm_model \
    -u localhost:8001 \
    -i gRPC \
    --concurrency-range 1,2,4,8,16,32,64 \
    --input-data zero \
    --shape text_input:1 \
    --string-length 256 \
    --measurement-mode count_windows \
    --measurement-request-count 100 \
    --percentile 95 \
    --collect-metrics \
    -f llm_benchmark_results.csv \
    --verbose
```

### 7.2 理解 perf_analyzer 输出

```
perf_analyzer 典型输出:

*** Measurement Settings ***
  Service kind: Triton
  Using synchronous calls for inference

Request concurrency: 16
  Client:
    Request count: 850
    Throughput: 170 infer/sec
    Avg latency: 93.2 msec (overhead 2 msec)
    p50 latency: 91.1 msec
    p90 latency: 98.5 msec
    p95 latency: 102.3 msec
    p99 latency: 115.7 msec
  Server:
    Inference count: 850
    Execution count: 850
    Successful request count: 850
    Avg request latency: 91.0 msec
      (queue 12.0 msec,
       compute input 1.5 msec,
       compute infer 75.0 msec,
       compute output 2.5 msec)

关键指标详解:

  1. Throughput (吞吐量): 系统每秒处理的请求数
     -> 这是综合性能指标，越高越好

  2. Avg request latency (平均请求延迟):
     -> queue: 请求在 Triton 内部排队的时间
        - 高 -> 实例不足，或 max_queue_delay 太大
        - 低 -> 请求能立即被处理
     -> compute infer: 实际模型计算时间
        - 高 -> 模型本身太慢 (考虑优化模型或升级 GPU)
        - 也是最大的可优化项
     -> compute input/output: 数据传输时间
        - 高 -> 启用 Pinned Memory，或减少数据量

  3. p95/p99 latency (尾部延迟):
     -> P95 = 95% 的请求延迟小于此值
     -> P99 = 99% 的请求延迟小于此值
     -> 尾部延迟对用户体验影响巨大
     -> 高尾部延迟通常由排队或资源竞争导致

瓶颈定位:
  queue 高 + compute 低 -> 增加实例数 (instance_group.count)
  queue 低 + compute 高 -> 优化模型 (量化/TensorRT/升级 GPU)
  input/output 高       -> 启用 Pinned Memory，减少序列化
  p99 >> p50            -> 存在资源竞争，调整调度策略
```

### 7.3 Model Analyzer --- 自动配置搜索

Model Analyzer 自动搜索最佳配置（实例数、批大小等）：

```bash
# 安装
pip install triton-model-analyzer

# 完整运行示例
model-analyzer profile \
    --model-repository /path/to/model_repository \
    --profile-models llm_model,embedding_model \
    --triton-launch-mode local \
    --output-model-repo-path /path/to/optimized_output \
    --override-output-model-repository \
    \
    # 搜索范围
    --run-config-search-mode optuna \
    --run-config-search-max-concurrency 128 \
    --run-config-search-max-instance-count 8 \
    --run-config-search-max-model-batch-size 64 \
    \
    # 测量配置
    --perf-analyzer-timeout 600 \
    --perf-analyzer-cpu-util 80 \
    --measurement-interval 10000 \
    \
    # 优化目标
    --constraint '{"perf_throughput": {"min": 100}}' \
    --objective '{"perf_latency_p99": 1.0}' \
    \
    # 并发范围
    --concurrency 1,4,8,16,32,64,128 \
    \
    # 输出
    --triton-output-path /tmp/triton_output

# 生成报告
model-analyzer report \
    --report-model-configs \
    --export-path ./analysis_results
```

```
Model Analyzer 分析结果示例:

+------------------------------------------------------------------+
| 配置排名  | 实例数 | 批大小 | 吞吐(rps) | P99延迟 | 得分    | 说明   |
+------------------------------------------------------------------+
| #1 (默认) | 1     | 8     | 125       | 220 ms  | 基准    | 默认   |
| #2        | 2     | 16    | 210       | 235 ms  | +68%    | 推荐   |
| #3        | 2     | 32    | 285       | 280 ms  | +128%   | 吞吐优 |
| #4        | 4     | 32    | 420       | 350 ms  | +236%   | 最大吞 |
| #5        | 1     | 4     | 95        | 145 ms  | -24%    | 低延迟 |
+------------------------------------------------------------------+

推荐: 配置 #2 是最佳性价比 (吞吐提升 68%，延迟只增加 7%)
```

### 7.4 优化工作流

```
性能优化闭环:

  +-------------------+
  | 1. 基准测试        |
  | perf_analyzer     |
  +--------+----------+
           |
           v
  +-------------------+
  | 2. 识别瓶颈        |
  | 看 queue/compute  |
  +--------+----------+
           |
           +---> queue 高? --> 增加实例/调整 batch
           |
           +---> compute 高? --> 优化模型/升级硬件
           |
           +---> I/O 高? --> Pinned Memory/减少数据
           |
           v
  +-------------------+
  | 3. 调整配置        |
  | 修改 config.pbtxt |
  +--------+----------+
           |
           v
  +-------------------+
  | 4. Model Analyzer |
  | 自动搜索最优配置    |
  +--------+----------+
           |
           v
  +-------------------+
  | 5. 验证            |
  | perf_analyzer     |
  | 对比基准数据        |
  +--------+----------+
           |
           +---> 达标? --> 完成
           |
           +---> 不达标? --> 回到步骤 2
```

---

## 8. 多节点部署

### 8.1 多节点 Triton 架构

```
多节点部署全景:

                          Internet
                             |
                    +--------+--------+
                    |   API Gateway    | (Kong/APISIX)
                    |   - 认证/鉴权     |
                    |   - 速率限制      |
                    +--------+--------+
                             |
                    +--------+--------+
                    |  Load Balancer   | (Nginx/HAProxy)
                    |  - 一致性哈希     |
                    |  - 健康检查       |
                    +----+---+---+----+
                         |   |   |
            +------------+   |   +------------+
            v                v                v
  +-------------------+ +-------------------+ +-------------------+
  |   Triton Node 1   | |   Triton Node 2   | |   Triton Node 3   |
  |   +------------+  | |   +------------+  | |   +------------+  |
  |   | LLM (vLLM) |  | |   | LLM (vLLM) |  | |   | LLM (vLLM) |  |
  |   +------------+  | |   +------------+  | |   +------------+  |
  |   +------------+  | |   +------------+  | |   +------------+  |
  |   | Embedding  |  | |   | Embedding  |  | |   | Embedding  |  |
  |   +------------+  | |   +------------+  | |   +------------+  |
  |   4x A800-80GB    | |   4x A800-80GB    | |   4x A800-80GB    |
  +-------------------+ +-------------------+ +-------------------+

关键注意事项:
  1. 每个节点的 KV Cache 独立管理，前缀缓存在节点间不共享
  2. 需要一致性哈希保证相同 prefix 的请求路由到同一节点
  3. 各节点的模型副本完全独立，不存在状态依赖
```

### 8.2 Nginx 负载均衡配置

```nginx
# nginx.conf --- Triton 多节点负载均衡

upstream triton_backend {
    # 一致性哈希 --- 相同 prefix 路由到同一节点
    hash $arg_prompt_prefix consistent;

    server 10.0.1.10:8000 weight=1 max_fails=3 fail_timeout=30s;
    server 10.0.1.11:8000 weight=1 max_fails=3 fail_timeout=30s;
    server 10.0.1.12:8000 weight=1 max_fails=3 fail_timeout=30s;

    # 备用节点 (其他节点都挂了才用)
    # server 10.0.1.20:8000 backup;
}

upstream triton_grpc {
    # gRPC 需要 HTTP/2 原生支持
    hash $arg_prompt_prefix consistent;

    server 10.0.1.10:8001 weight=1;
    server 10.0.1.11:8001 weight=1;
    server 10.0.1.12:8001 weight=1;
}

server {
    listen 80;
    server_name triton.example.com;

    # HTTP 推理端点
    location /v2/models/ {
        proxy_pass http://triton_backend;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;

        # Streaming 支持 (SSE)
        proxy_buffering off;
        proxy_read_timeout 600s;
        proxy_send_timeout 600s;

        # 速率限制
        limit_req zone=llm_limit burst=100 nodelay;
    }

    # gRPC 推理端点 (需要 HTTP/2)
    location /inference.GRPCInferenceService/ {
        grpc_pass grpc://triton_grpc;
        grpc_read_timeout 600s;
        grpc_send_timeout 600s;
    }

    # 健康检查端点
    location /v2/health/ {
        proxy_pass http://triton_backend;
    }
}

# 速率限制区域定义
limit_req_zone $binary_remote_addr zone=llm_limit:10m rate=100r/s;
```

### 8.3 一致性哈希客户端路由

```python
# 客户端侧一致性哈希路由 --- 保证前缀缓存命中

import hashlib
import struct
import numpy as np
import tritonclient.grpc as grpcclient


class TritonConsistentHashRouter:
    """
    多节点 Triton 客户端路由器

    使用一致性哈希确保相同 prompt prefix 的请求
    始终路由到同一节点，最大化前缀缓存命中率。

    这对于 33B/67B 模型至关重要：
    - 33B 模型: 每次 prefill ~500ms，前缀缓存可节省 2-3x
    - 67B 模型: 每次 prefill ~1s，前缀缓存可节省 3-5x
    """

    def __init__(self, node_addresses):
        self.clients = {}
        for addr in node_addresses:
            self.clients[addr] = grpcclient.InferenceServerClient(
                url=addr
            )
        self.nodes = node_addresses

    def _hash_prompt(self, prompt):
        """
        对 prompt 前缀做哈希，用于选择节点

        prompt 越长，不同 prompt 的分布越均匀。
        通常取前 200 个字符即可（大部分前缀缓存的命中区间）。
        """
        prefix = prompt[:200].encode('utf-8')
        hash_val = struct.unpack(
            '<I', hashlib.md5(prefix).digest()[:4]
        )[0]
        return hash_val

    def _select_node(self, prompt):
        """根据 prompt hash 选择目标节点"""
        hash_val = self._hash_prompt(prompt)
        index = hash_val % len(self.nodes)
        return self.nodes[index]

    def generate(self, prompt, max_tokens=256, temperature=0.7):
        """发送推理请求到选定的节点"""
        target_node = self._select_node(prompt)
        client = self.clients[target_node]

        inputs = [
            grpcclient.InferInput("text_input", [1], "BYTES"),
            grpcclient.InferInput("max_tokens", [1], "INT32"),
            grpcclient.InferInput("temperature", [1], "FP32"),
        ]
        inputs[0].set_data_from_numpy(
            np.array([prompt], dtype=np.object_)
        )
        inputs[1].set_data_from_numpy(
            np.array([max_tokens], dtype=np.int32)
        )
        inputs[2].set_data_from_numpy(
            np.array([temperature], dtype=np.float32)
        )

        result = client.infer(
            model_name="llm_model",
            inputs=inputs,
            outputs=[
                grpcclient.InferRequestedOutput("text_output")
            ]
        )

        output = result.as_numpy("text_output")[0]
        return output.decode('utf-8') if isinstance(output, bytes) else output
```

### 8.4 GPU 共享策略

```
三种 GPU 共享方式对比:

+--------------------------------------------------------------+
| 策略           | 隔离性  | 显存划分 | 适用场景                   |
+--------------------------------------------------------------+
| Time-slicing   | 无      | 共享     | 开发/测试，利用率低        |
| MPS            | 弱      | 共享     | 同用户多进程，CUDA 兼容     |
| MIG            | 强      | 物理隔离  | 多租户，严格隔离 (仅 A100/   |
|                |         |          | A30/H100)                 |
| Triton 多实例  | 软件级  | 共享     | 同 GPU 上多模型 (推荐)      |
+--------------------------------------------------------------+

Time-slicing (时间片轮转):
  - GPU 在多个进程间轮流使用
  - 适合低利用率的开发环境
  - 不适合生产环境 (延迟不可预测)

MPS (Multi-Process Service):
  - 多个 CUDA 进程共享 GPU 上下文
  - 减少上下文切换开销
  - 适合同一用户的多进程场景

MIG (Multi-Instance GPU):
  - 物理层面划分 GPU (仅 A100/A30/H100)
  - 每个 MIG 实例有独立的显存、缓存、计算单元
  - 适合多租户严格隔离场景
  - 配置示例:
    $ nvidia-smi mig -cgi 9,9,9,9  # 4 个 10GB 实例
    $ nvidia-smi mig -cci 0,1,2,3

Triton 多实例 (推荐):
  - 在 config.pbtxt 中配置 instance_group
  - Triton 自动管理实例间的显存和 CUDA Stream
  - 最简单、最灵活的方案
```

### 8.5 Kubernetes 部署

```yaml
# triton-deployment.yaml --- Kubernetes 部署

apiVersion: apps/v1
kind: Deployment
metadata:
  name: triton-vllm
  labels:
    app: triton-vllm
spec:
  replicas: 3
  selector:
    matchLabels:
      app: triton-vllm
  template:
    metadata:
      labels:
        app: triton-vllm
    spec:
      containers:
      - name: triton-server
        image: nvcr.io/nvidia/tritonserver:24.04-py3
        args:
        - tritonserver
        - --model-repository=/models
        - --strict-model-config=false
        - --allow-metrics=true
        - --allow-gpu-metrics=true
        - --metrics-port=8002
        - --log-verbose=1
        ports:
        - containerPort: 8000
          name: http
        - containerPort: 8001
          name: grpc
        - containerPort: 8002
          name: metrics
        resources:
          limits:
            nvidia.com/gpu: 4     # 每个 Pod 4 张 GPU
          requests:
            nvidia.com/gpu: 4
            memory: 256Gi
            cpu: 32
        volumeMounts:
        - name: model-repo
          mountPath: /models
        - name: model-weights
          mountPath: /model_weights
        env:
        - name: CUDA_VISIBLE_DEVICES
          value: "0,1,2,3"
        readinessProbe:
          httpGet:
            path: /v2/health/ready
            port: 8000
          initialDelaySeconds: 120
          periodSeconds: 10
        livenessProbe:
          httpGet:
            path: /v2/health/live
            port: 8000
          initialDelaySeconds: 120
          periodSeconds: 30
      volumes:
      - name: model-repo
        persistentVolumeClaim:
          claimName: model-repository-pvc
      - name: model-weights
        hostPath:
          path: /mnt/nfs/models
      nodeSelector:
        accelerator: nvidia-a800   # 指定 GPU 节点

---
# Service
apiVersion: v1
kind: Service
metadata:
  name: triton-service
spec:
  selector:
    app: triton-vllm
  ports:
  - port: 8000
    name: http
  - port: 8001
    name: grpc
  - port: 8002
    name: metrics
  type: ClusterIP
```

---

## 9. 监控与可观测性

### 9.1 Prometheus 指标收集

```bash
# 启动 Triton 时启用指标
tritonserver \
    --model-repository=/models \
    --allow-metrics=true \
    --allow-gpu-metrics=true \
    --metrics-port=8002 \
    --metrics-interval-ms=2000

# 查看所有指标
curl http://localhost:8002/metrics
```

```
核心 Prometheus 指标分类:

  [请求指标]
  nv_inference_request_success      - 成功请求数
  nv_inference_request_failure      - 失败请求数
  nv_inference_count                - 总推理次数
  nv_inference_exec_count           - 总执行次数

  [延迟指标]
  nv_inference_request_duration_us  - 请求端到端延迟 (微秒)
  nv_inference_queue_duration_us    - 排队时间
  nv_inference_compute_input_duration_us   - 输入处理时间
  nv_inference_compute_infer_duration_us   - 推理计算时间
  nv_inference_compute_output_duration_us  - 输出处理时间

  [GPU 指标]
  nv_gpu_utilization           - GPU 利用率 (%)
  nv_gpu_memory_used_bytes     - 已用显存
  nv_gpu_memory_total_bytes    - 总显存
  nv_gpu_power_usage           - 功耗 (W)
  nv_gpu_power_limit           - 功耗上限
  nv_gpu_temperature_celsius   - GPU 温度
  nv_energy_consumption        - 累计能耗 (mJ)
```

### 9.2 Prometheus 配置

```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'triton'
    static_configs:
      - targets:
        - 'triton-node-1:8002'
        - 'triton-node-2:8002'
        - 'triton-node-3:8002'
    metric_relabel_configs:
      - source_labels: [__name__]
        regex: 'nv_.*'
        action: keep

  - job_name: 'node-exporter'
    static_configs:
      - targets:
        - 'triton-node-1:9100'
        - 'triton-node-2:9100'
        - 'triton-node-3:9100'
```

### 9.3 Grafana Dashboard 关键面板

```
推荐的 Grafana Dashboard 面板布局:

+======================================================================+
||                   Triton vLLM 生产监控 Dashboard                       ||
+======================================================================+
||                                                                     ||
||  Row 1: 总览                                                        ||
||  +-----------+ +-----------+ +-----------+ +-------------------+    ||
||  | 总吞吐量   | | P50 延迟  | | P99 延迟  | | 平均每 Token 时间 |    ||
||  | 245 tok/s | | 2.8s     | | 5.2s     | | 21.4 ms/tok      |    ||
||  +-----------+ +-----------+ +-----------+ +-------------------+    ||
||                                                                     ||
||  Row 2: GPU 集群状态                                                 ||
||  +--------------------------------------------------------------+  ||
||  | GPU 利用率 (节点1) | GPU 利用率 (节点2) | GPU 利用率 (节点3)    |  ||
||  | [=========    ] 72% | [========== ] 85% | [=======    ] 58%  |  ||
||  +--------------------------------------------------------------+  ||
||  | GPU 显存 (节点1)   | GPU 显存 (节点2)   | GPU 显存 (节点3)     |  ||
||  | [=========== ] 55G | [========== ] 62G | [=========  ] 48G  |  ||
||  +--------------------------------------------------------------+  ||
||  | GPU 温度           | GPU 功耗                              |  ||
||  | 68C   72C   65C   | 280W  310W  250W                     |  ||
||  +--------------------------------------------------------------+  ||
||                                                                     ||
||  Row 3: 请求指标 (按模型)                                            ||
||  +--------------------------------------------------------------+  ||
||  | llm_model         | embedding_model  | vector_search        |  ||
||  | 请求数: 1.2K/min  | 请求数: 3.5K/min | 请求数: 3.5K/min     |  ||
||  | P99: 5.2s         | P99: 45ms        | P99: 120ms           |  ||
||  | 成功率: 99.8%     | 成功率: 99.9%    | 成功率: 99.7%        |  ||
||  +--------------------------------------------------------------+  ||
||                                                                     ||
||  Row 4: 系统资源                                                     ||
||  +--------------------------------------------------------------+  ||
||  | CPU 利用率 | 内存使用 | 磁盘 I/O | 网络流量                    |  ||
||  +--------------------------------------------------------------+  ||
||                                                                     ||
||  Row 5: 告警事件                                                     ||
||  +--------------------------------------------------------------+  ||
||  | [WARN] GPU 温度超过 80C - Node 2                    10:35    |  ||
||  | [INFO] 自动扩容触发 - replicas 3 -> 4                10:42    |  ||
||  +--------------------------------------------------------------+  ||
||                                                                     ||
+======================================================================+
```

### 9.4 告警规则

```yaml
# prometheus-rules.yml
groups:
  - name: triton_alerts
    rules:
      # 推理延迟告警
      - alert: HighP99Latency
        expr: |
          histogram_quantile(0.99,
            rate(nv_inference_request_duration_us[5m])
          ) / 1000000 > 10
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "P99 推理延迟超过 10 秒"
          description: "模型 {{ $labels.model }} 的 P99 延迟为 {{ $value }}s"

      # GPU 利用率过低 (可能存在资源浪费)
      - alert: LowGPUUtilization
        expr: avg(nv_gpu_utilization) < 20
        for: 15m
        labels:
          severity: info
        annotations:
          summary: "GPU 利用率低于 20%"

      # GPU 温度过高
      - alert: HighGPUTemperature
        expr: nv_gpu_temperature_celsius > 80
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "GPU 温度超过 80 摄氏度"

      # 错误率过高
      - alert: HighErrorRate
        expr: |
          rate(nv_inference_request_failure[5m]) /
          (rate(nv_inference_request_success[5m]) +
           rate(nv_inference_request_failure[5m])) > 0.01
        for: 3m
        labels:
          severity: critical
        annotations:
          summary: "推理错误率超过 1%"

      # 显存接近上限
      - alert: HighGPUMemoryUsage
        expr: |
          nv_gpu_memory_used_bytes /
          nv_gpu_memory_total_bytes > 0.95
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "GPU 显存使用率超过 95%，有 OOM 风险"
```

### 9.5 日志配置

```bash
# Triton 日志配置

# 日志详细级别
tritonserver \
    --log-verbose=1 \          # 0=ERROR, 1=WARNING, 2=INFO
    --log-file=/var/log/triton/triton.log \
    --log-format=json          # JSON 格式便于日志收集

# 日志聚合 (使用 Fluentd/Logstash 发送到 ELK/Loki)
# Fluentd 配置示例:
# <source>
#   @type tail
#   path /var/log/triton/triton.log
#   tag triton.logs
#   <parse>
#     @type json
#   </parse>
# </source>
```

### 9.6 Docker Compose 监控栈

```yaml
# docker-compose.yml --- 完整监控栈
version: '3.8'

services:
  triton:
    image: nvcr.io/nvidia/tritonserver:24.04-py3
    runtime: nvidia
    environment:
      - NVIDIA_VISIBLE_DEVICES=0,1,2,3
    ports:
      - "8000:8000"
      - "8001:8001"
      - "8002:8002"
    volumes:
      - ./model_repository:/models
    command: >
      tritonserver
        --model-repository=/models
        --allow-metrics=true
        --allow-gpu-metrics=true
        --metrics-port=8002

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
      - GF_INSTALL_PLUGINS=nvidia-gpu-dashboard
    volumes:
      - ./grafana/dashboards:/etc/grafana/provisioning/dashboards
      - ./grafana/datasources:/etc/grafana/provisioning/datasources
```

---

## 10. 决策指南：何时引入 Triton

### 10.1 添加 Triton 的信号 vs 跳过 Triton 的信号

```
+======================================================================+
||                    Triton 引入决策矩阵                                  ||
+======================================================================+
||                                                                     ||
||  添加 Triton 的信号:                                                  ||
||                                                                     ||
||  [YES] 你运行多个模型（LLM + Embedding + Reranker + Classifier）        ||
||         -> Triton 的多模型管理是核心价值                                ||
||                                                                     ||
||  [YES] 你需要模型流水线（RAG pipeline、Agent 工具链）                    ||
||         -> Ensemble + BLS 比手写胶水代码好太多                          ||
||                                                                     ||
||  [YES] 你需要框架混用（PyTorch + ONNX + TensorRT 共存）                  ||
||         -> Triton 的 Backend API 统一了这些框架                        ||
||                                                                     ||
||  [YES] 你需要企业级特性（优先级队列、速率限制、模型版本管理）               ||
||         -> 独立 vLLM 缺乏这些能力                                     ||
||                                                                     ||
||  [YES] 你需要自动性能调优 (Model Analyzer)                              ||
||         -> 自动搜索最优配置，节省大量手工调优时间                         ||
||                                                                     ||
||  [YES] 你需要 gRPC 端点和多协议支持                                    ||
||         -> Triton 原生支持 HTTP + gRPC + C API                        ||
||                                                                     ||
||  [YES] 你需要 GPU 利用率和显存的统一监控                                ||
||         -> Triton + Prometheus 开箱即用                               ||
||                                                                     ||
+======================================================================+
||                                                                     ||
||  跳过 Triton 的信号:                                                  ||
||                                                                     ||
||  [NO] 你只运行一个 LLM 模型（纯 vLLM 场景）                              ||
||         -> 独立 vLLM 更简单，性能更好                                  ||
||                                                                     ||
||  [NO] 你需要极简部署（一条 docker run 搞定）                            ||
||         -> Triton 的配置复杂度是独立 vLLM 的 3-5 倍                    ||
||                                                                     ||
||  [NO] 你的团队不想学习和维护 Triton                                    ||
||         -> Triton 的学习曲线有一定坡度                                 ||
||                                                                     ||
||  [NO] 你不需要多模型管理、不需要流水线、不需要企业特性                     ||
||         -> 没必要引入额外的复杂性                                      ||
||                                                                     ||
||  [NO] 你的模型已经打包成单一的独立服务并且运行良好                         ||
||         -> 不要修没坏的东西                                           ||
||                                                                     ||
+======================================================================+
```

### 10.2 决策流程图

```
                          开始
                           |
                    +------v-------+
                    | 你需要运行多个  |
                    | 模型吗？       |
                    +------+-------+
                           |
               +-----------+-----------+
               |                       |
           是 [YES]               否 [NO]
               |                       |
               v                       v
        +------v-------+       +------v-------+
        | 需要模型流水线  |       | 只需要一个     |
        | (RAG/Agent)?  |       | LLM 模型?     |
        +------+-------+       +------+-------+
               |                       |
        +------+------+         +------+------+
        |             |         |             |
     是 [YES]    否 [NO]     是 [YES]     否 [NO]
        |             |         |             |
        v             v         v             v
   +--------+   +--------+ +--------+   +--------+
   | 使用     |   | 使用     | | 使用     |   | 重新评估  |
   | Triton   |   | Triton   | | 独立     |   | 你的需求  |
   | (Ensemble|   | (多模型)  | | vLLM    |   |          |
   |  + BLS)  |   |          | |         |   |          |
   +--------+   +--------+ +--------+   +--------+

                    +--------v-------+
                    | 需要企业级特性?  |
                    | (优先级/限流/   |
                    |  版本管理)?     |
                    +--------+-------+
                             |
                    +--------+--------+
                    |                 |
                 是 [YES]         否 [NO]
                    |                 |
                    v                 v
              +--------+       +------------+
              | 使用     |       | 独立方案足够 |
              | Triton   |       | 不引入 Triton|
              +--------+       +------------+
```

### 10.3 渐进式引入策略

```
不要从零直接跳到全 Triton 架构。建议分阶段引入:

  Phase 1: 纯 vLLM (第 1 周)
    - 部署独立 vLLM 服务
    - 验证模型推理正确性
    - 建立性能 baseline
    - 工具: docker + vLLM + 简单 HTTP 客户端

  Phase 2: Triton + 单模型 (第 2 周)
    - 将 vLLM 模型迁移到 Triton
    - 只部署一个模型 (llm_model)
    - 使用 Python Backend 封装 vLLM
    - 验证: 性能对比 Phase 1

  Phase 3: 添加辅助模型 (第 3 周)
    - 添加 embedding_model (ONNX/PyTorch)
    - 配置 instance_group 和 GPU 分配
    - 验证: 多模型共存不 OOM

  Phase 4: 构建流水线 (第 4 周)
    - 添加 vector_search 模型
    - 构建 RAG Ensemble 或 BLS
    - 压力测试: perf_analyzer
    - 配置监控: Prometheus + Grafana

  Phase 5: 生产优化 (第 5 周)
    - Model Analyzer 自动调优
    - 多节点部署 + 负载均衡
    - 告警规则配置
    - 灰度上线

  关键原则: 每一步都要验证，和上一步的 baseline 对比。
```

---

## 12. 术语速查

| 术语 | 一句话类比 | 详见 glossary |
|------|-----------|-------------|
| Model Repository | 像"模型仓库的货架"一样，按版本号组织模型文件，Triton 自动识别和加载 | 本文第3章 |
| Dynamic Batching | 像"拼车出行"一样，等几微秒把多个请求拼成一车（批次），省 GPU 资源 | 本文第5章 |
| config.pbtxt | 像"模型的身份证+说明书"一样，定义输入输出格式、GPU 分配、调度策略 | 本文第3.2节 |
| Ensemble | 像"工厂流水线"一样，声明式地将多个模型串联成 DAG，数据自动流转 | 本文第6章 |
| BLS | 像"用 Python 写编排脚本"一样，在模型内写代码动态调用其他模型，比 Ensemble 更灵活 | 本文第6.3节 |

## 13. A800 部署场景举例

**场景1：A800 集群上 Triton + vLLM 部署 Qwen-33B + BGE-Embedding 多模型服务**

在 4×A800 服务器上通过 Triton 同时托管 LLM（Qwen-33B, TP=4）和 Embedding 模型（BGE-Large）：

```bash
# model_repository 目录结构:
# ├── llm_model/          # vLLM Backend, Qwen-33B
# │   ├── config.pbtxt    # max_batch_size: 0 (让 vLLM 自己调度)
# │   └── 1/model.py
# ├── embedding_model/    # Python Backend, BGE-Large
# │   ├── config.pbtxt    # max_batch_size: 32
# │   └── 1/model.py
# └── rag_pipeline/       # Ensemble (E+D→Search→L)
#     └── config.pbtxt

# 启动（单节点 4 卡）
tritonserver \
    --model-repository=/model_repo \
    --strict-model-config=false \
    --allow-gpu-metrics=true \
    --metrics-port=8002

# 验证: 两个模型同时在线
curl http://localhost:8000/v2/models
# {"models":[{"name":"llm_model","state":"READY"},
#            {"name":"embedding_model","state":"READY"}]}
```

关键配置（见本文第4.3节）：
- LLM 模型: `max_batch_size: 0`（关闭 Triton Batching，vLLM 内部 CB 接管）
- Embedding 模型: `instance_group [{count: 1, gpus: [0]}]`（共享 GPU 0，利用剩余显存）

**场景2：A800 上 perf_analyzer 压测 DeepSeek-67B 推理服务**

```bash
# 逐步增加并发，测量吞吐-延迟曲线
perf_analyzer -m llm_model -i gRPC \
    --concurrency-range 1,2,4,8,16,32,64 \
    --input-data zero \
    --shape text_input:1 --string-length 512 \
    --measurement-interval 10000 \
    --percentile 95 \
    -f deepseek67b_bench.csv

# 预期输出（A800×4, TP=4, DeepSeek-67B, INT8）:
# Concurrency | Throughput(tok/s) | P50(ms) | P95(ms) | P99(ms)
#   1         | 85               | 4500    | 5200    | 5800
#   16        | 620              | 8200    | 9600    | 10500
#  饱和 32     | 780              | 15000   | 17500   | 19500
```

## 14. 上下游串联

```
上游 ← 本文档 → 下游

上游：推理引擎（vLLM / TensorRT-LLM）
      本文档教你怎么把已经优化好的推理引擎（vLLM 的 AsyncLLMEngine /
      TRT-LLM 的 GptSession）通过 Python/C++ Backend 接入 Triton 的统一调度框架。

下游：API Gateway / 负载均衡 / 监控（生产运维层）
      Triton 对外暴露 HTTP/gRPC/Metrics 三个端口，可以被 Nginx
      负载均衡、Prometheus 监控、Kubernetes 编排等基础设施集成。

完整链路参考：end-to-end-inference-trace.md
  Client → API Gateway (Nginx/Kong) → Triton (Scheduler/Dynamic Batcher) →
  Backend (vLLM/TRT-LLM) → Inference Engine → GPU → Response
```

---
---
## 11. 深入学习资源

### 11.1 官方文档

| 资源 | URL | 说明 |
|------|-----|------|
| **Triton 官方文档** | docs.nvidia.com/deeplearning/triton-inference-server | 完整的架构、配置、API 参考 |
| **Triton GitHub** | github.com/triton-inference-server/server | 源代码、Issues、Release Notes |
| **Triton Client 库** | github.com/triton-inference-server/client | Python/C++/Java 客户端 |
| **Python Backend 文档** | github.com/triton-inference-server/python_backend | BLS、Python 模型开发 |
| **Model Analyzer** | github.com/triton-inference-server/model_analyzer | 自动性能调优工具 |
| **perf_analyzer** | github.com/triton-inference-server/client | 性能压测工具文档 |
| **NGC Triton 容器** | catalog.ngc.nvidia.com/containers | 预构建的 Docker 镜像 |

### 11.2 论文与文章

| 资源 | 说明 |
|------|------|
| **Triton Inference Server: An Optimized Cloud and Edge AI Solution** (NVIDIA, 2020) | NVIDIA 官方架构论文 |
| **vLLM: Easy, Fast, and Cheap LLM Serving with PagedAttention** (SOSP 2024) | vLLM 核心论文，理解其与 Triton 的集成基础 |
| **Orca: A Distributed Serving System for Transformer-Based Generative Models** (OSDI 2022) | 分布式 LLM 推理系统 |
| **Efficient Memory Management for Large Language Model Serving with PagedAttention** | PagedAttention 技术论文 |
| **NVIDIA Technical Blog: Deploying vLLM with Triton** | NVIDIA 官方博客，vLLM+Triton 集成实践 |

### 11.3 开源项目与代码示例

| 仓库 | 说明 |
|------|------|
| **github.com/vllm-project/production-stack** | vLLM 官方生产部署方案 |
| **github.com/triton-inference-server/tutorials** | Triton 官方教程集合 |
| **github.com/NVIDIA/DeepLearningExamples** | NVIDIA 深度学习示例（含 Triton 部署） |
| **github.com/triton-inference-server/model_navigator** | 模型导出和优化工具 |
| **github.com/kserve/kserve** | Kubernetes 上的无服务器推理（支持 Triton） |

### 11.4 实践建议

#### 对于 33B/67B 模型部署：

```
33B 模型 (如 Qwen-33B, Yi-34B):
  - 推荐: 2x A800 (TP=2) + Triton
  - 显存: ~20GB 权重 + ~10GB KV Cache = ~30GB
  - 剩余显存可部署 embedding 模型
  - 前缀缓存回报显著 (prefill ~300ms -> ~50ms)

67B 模型 (如 DeepSeek-67B, Llama-2-70B):
  - 推荐: 4x A800 (TP=4) + Triton
  - 显存: ~35GB 权重 + ~15GB KV Cache = ~50GB
  - 可能需要开启 INT4/INT8 量化以节省显存
  - 前缀缓存至关重要 (prefill ~600ms -> ~80ms)
  - 考虑多节点部署时的 KV Cache 路由策略
```

#### 对于 Claude Code 对接：

```
Triton 可以通过 OpenAI-compatible API 与 Claude Code 集成:

  1. 在 Triton 前部署一个轻量级 API 适配层 (如 vLLM 的 API Server)
  2. 或者使用 BLS 编写 OpenAI-compatible endpoint
  3. Claude Code 通过 OpenAI API 协议调用 Triton 托管的模型
  4. 利用 Triton 的多模型管理同时服务 code model + embedding model

  架构:
    Claude Code --> OpenAI API --> vLLM API Server --> Triton --> LLM
                                               |
                                               +--> Triton --> Embedding
```

#### 对于 RAG 场景：

```
完整 RAG 在 Triton 上的最佳实践:

  1. Embedding 模型: BGE-Large-Zh-v1.5, 部署为独立的 Triton 模型
  2. 向量检索引擎: FAISS/Milvus, 封装为 Triton Python Backend 模型
  3. Reranker: BGE-Reranker, 部署为 ONNX 模型 (低延迟)
  4. LLM: vLLM Backend, 主生成模型
  5. 编排: BLS (灵活的业务逻辑)
  6. 缓存: Redis (外部) 或 Triton Response Cache
```

---

> **文档版本**: v2.0 | **适用范围**: Triton 24.04+, vLLM 0.5.0+ | **最后更新**: 2026-07
>
> 本文档是推理方向（Direction B）的核心学习材料。通过本文档的学习，你应该：
>
> 1. 理解 Triton 的架构设计理念和核心特性
> 2. 能够编写完整的 config.pbtxt 配置文件
> 3. 掌握 vLLM 与 Triton 的集成方式
> 4. 理解 Dynamic Batching 和 Continuous Batching 的区别及适用场景
> 5. 能够使用 Ensemble 和 BLS 构建模型流水线
> 6. 会使用 perf_analyzer 和 Model Analyzer 进行性能测试和优化
> 7. 能够规划多节点 Triton 部署
> 8. 能够配置 Prometheus + Grafana 监控
> 9. 能够判断是否应该在自己的项目中引入 Triton
>
> ---
>
> **推理方向学习路径回顾**:
>
> 阶段 1: 推理引擎基础
>   - Transformer 推理原理
>   - KV Cache 机制
>
> 阶段 2: 推理优化
>   - PagedAttention 深度理解
>   - Continuous Batching
>   - 模型量化 (INT8/INT4)
>
> 阶段 3: 生产推理 (Direction B)
>   - vLLM 推理引擎
>   - TensorRT-LLM
>   - **Triton Inference Server (本文档)**
>   - 推理服务部署实践
>
