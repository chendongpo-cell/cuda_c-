# Continuous Batching 深入详解

## 白话引入

想象你经营一家餐厅。传统的「静态批处理」就像是"等整桌客人全部吃完才一起收拾翻台"：一张 4 人桌坐了 4 位客人，有人 10 分钟就吃完了，有人慢悠悠吃了一个小时。但服务员只能等最慢的那位吃完，才能清理桌面、迎接下一批客人。提前吃完的客人干坐着占位子，门外排队的客人饥肠辘辘——这就是 GPU 利用率只有 40-55% 的根本原因。

**Continuous Batching（连续批处理）**的做法完全不同：客人吃完一道菜，服务员立刻收走空盘；有人吃完离席，马上安排等位的客人入座。餐桌（GPU）永远不会因为等人而空转。翻译成技术语言：每次 forward pass 结束后，已生成 EOS 的请求立刻退出 batch，等待队列中的新请求立刻加入——不再需要等整个 batch 全部完成。这就是为什么连续批处理能把 GPU 利用率从 ~50% 拉到 ~90%+。

> 从静态批处理到连续批处理：理解 LLM 推理服务的核心调度技术。
> 目标读者：需要部署 33B/67B 模型、对接 Claude Code / RAG 流水线的系统工程师与后端开发者。

---

## 术语预检

在深入技术细节之前，先过一遍核心术语，每个都配有生活类比帮助你建立直觉。

| 术语 | 生活类比 | 技术定义 |
|------|---------|---------|
| **Prefill（预填充）** | 厨师备菜阶段：一次性把所有食材（prompt tokens）切好、分装 | 将用户输入的完整 prompt 一次性送入模型，并行计算所有 token 的 KV Cache，生成第一个输出 token。计算密集型（compute-bound）。 |
| **Decode（解码）** | 厨师炒菜阶段：每次只下一勺料，翻一下锅，盛一勺菜 | 每次只处理 1 个 token（上一轮生成的），与历史 KV Cache 做 attention 后生成下一个 token。内存密集型（memory-bound）。 |
| **Token Budget（令牌预算）** | 厨房每轮最多能同时处理的食材份数 | `max_num_batched_tokens`：单次迭代中 prefill token + decode token 的总数上限。这是连续批处理最关键的节流阀参数。 |
| **Chunked Prefill（分块预填充）** | 长菜单分多次备菜，中间穿插上菜，而不是一次性备完再上菜 | 将长 prompt 的 prefill 拆成多个 chunk，分散到多次迭代中执行，中间穿插 decode 请求，避免长 prefill 导致 TPOT 尖刺。 |
| **TTFT（首令牌时间）** | 客人下单后等到第一道菜上桌的时间 | Time To First Token：从请求到达到第一个输出 token 生成的时间。这是用户体验的核心指标，受 prefill 耗时和排队延迟影响。 |
| **TPOT（令牌间时间）** | 客人吃完一道菜到下一道菜上桌的间隔 | Time Per Output Token：相邻两个输出 token 之间的时间间隔。流式输出的平滑度取决于 TPOT 的稳定性。 |

---

## 目录

1. [问题：静态批处理为什么不够用](#1-问题静态批处理为什么不够用)
2. [算法：基于迭代的动态调度](#2-算法基于迭代的动态调度)
3. [Prefill 与 Decode 的协同调度](#3-prefill-与-decode-的协同调度)
4. [Chunked Prefill 深度解析](#4-chunked-prefill-深度解析)
5. [调度策略详解](#5-调度策略详解)
6. [抢占策略](#6-抢占策略)
7. [性能分析](#7-性能分析)
8. [实战调优指南](#8-实战调优指南)
9. [易混淆技术辨析](#9-易混淆技术辨析)
10. [AI Infra 专家视角](#10-ai-infra-专家视角)
11. [深入学习资源](#11-深入学习资源)

---

## 1. 问题：静态批处理为什么不够用

### 1.1 什么是 Static Batching

传统的深度学习推理服务中，批处理（batching）是最基础的优化手段。客户端发来请求，服务端把它们攒成一个 batch，一起送进 GPU 做一次 forward pass，然后把结果分别返回。

```
静态批处理流程：

时间轴 ──────────────────────────────────────────────────────────────>

Batch 1:
  Request A: [████████████████████████████████████]  完成 (40 tokens)
  Request B: [████████████████████████████████████]  完成 (40 tokens)
  Request C: [████████████████████████████████████]  完成 (40 tokens)
  Request D: [████████████████████████████████████]  完成 (40 tokens)
                                                      |
                                           GPU 空闲，等待下一批

Batch 2:
  Request E: [██████████████████]                    完成 (20 tokens)
  Request F: [████████████████████████████████████]  完成 (40 tokens)
  Request G: [██████████████████]                    完成 (20 tokens)
                                                      |
                                     GPU 在等候 F 的 20 个多余 token 时空转
```

### 1.2 两大核心问题

**问题一：提前完成者造成 GPU 空闲（Padding Waste）**

在自回归生成（autoregressive generation）中，每个请求生成的 token 数量不同。静态批处理必须等 batch 中**最长**的那个请求完成，才能一起返回。这导致早完成的请求所在的计算槽位被填充（padding），GPU 算力白白浪费。

```
Padding Waste 可视化：

请求 A (需要 10 tokens):  [1][2][3][4][5][6][7][8][9][10][PAD][PAD]...[PAD]
请求 B (需要 50 tokens):  [1][2][3][4][5][6][7][8][9][10][11][12]...[50]
                            ^                                ^
                            |___ A 完成后，该槽位全部浪费 ____|

浪费比例：对请求 A，(50 - 10) / 50 = 80% 的计算被浪费
```

**问题二：短请求被长请求阻塞（Head-of-Line Blocking）**

当一个短请求不幸与长请求在同一 batch 中时，它必须等待长请求全部生成完毕才能返回。这直接拉高了短请求的 TTFT（Time To First Token）和整体延迟。

```
HOL Blocking 场景：

请求到达顺序：Short1, Long1, Short2

静态批处理：
  Batch: [Short1, Long1, Short2]

  Short1: [███████]                          3ms 的 prefill，然后等...
  Short2: [███████]                          3ms 的 prefill，然后等...
  Long1:  [████████████████████████████████]  50ms 的 prefill + 500ms 的 decode
                                                        |
                                            Short1/Short2 白白等了 547ms
```

### 1.3 GPU 利用率对比

```
静态批处理下的 GPU 利用率：

Util%
100% ┤                                          ██████
 90% ┤              ██████              ██████  ██████
 80% ┤              ██████      ██████  ██████  ██████
 70% ┤      ██████  ██████  ██████████████████████████
 60% ┤      ██████  ██████████████████████████████████
 50% ┤      ██████████████████████████████████████████  ← 平均 ~50%
 40% ┤      ██████████████████████████████████████████
 30% ┤  ██████████████████████████████████████████████
 20% ┤  ██████████████████████████████████████████████████
 10% ┤  ██████████████████████████████████████████████████
  0% ┼──┴────┴────┴────┴────┴────┴────┴────┴────┴────┴──> 时间
        T1   T2   T3   T4   T5   T6   T7   T8   T9  T10

  锯齿形：每个 batch 开始时利用率上升，随着请求陆续完成而下降。


连续批处理下的 GPU 利用率：

Util%
100% ┤  ████████████████████████████████████████████████
 90% ┤  ████████████████████████████████████████████████  ← 平均 ~90%+
 80% ┤  ████████████████████████████████████████████████
 70% ┤  ████████████████████████████████████████████████
 60% ┤  ████████████████████████████████████████████████
 50% ┤  ████████████████████████████████████████████████
 40% ┤  ████████████████████████████████████████████████
 30% ┤  ████████████████████████████████████████████████
 20% ┤  ████████████████████████████████████████████████
 10% ┤  ████████████████████████████████████████████████
  0% ┼──┴────┴────┴────┴────┴────┴────┴────┴────┴────┴──> 时间
        T1   T2   T3   T4   T5   T6   T7   T8   T9  T10

  始终保持高位：请求动态进出，GPU 几乎不会空闲。
```

### 1.4 量化浪费

对于一个典型的 33B 模型部署，假设：

- 平均输出长度：256 tokens
- 输出长度标准差：128 tokens
- Batch size：32
- 每次 decode 耗时：50ms

在静态批处理中，每个 batch 的有效利用率可以估算为：

```
利用率 ≈ E[min(L_i)] / E[max(L_i)]  其中 L_i 是 batch 中每个请求的输出长度

假设 L_i ~ N(256, 128²)，batch_size = 32：
  E[max(L_i)] ≈ 256 + 128 × 2.07 ≈ 521 tokens  （32 个样本的最大值期望）
  E[min(L_i)] ≈ 256 - 128 × 2.07 ≈ -9 → 实际 clamp 到几个 token
  有效利用率 ≈ 256 / 521 ≈ 49%
```

这就是为什么静态批处理在实际生产中的 GPU 利用率普遍只有 40%-55%。

---

## 2. 算法：基于迭代的动态调度

### 2.1 核心思想

Continuous Batching（也称 In-flight Batching 或 Iteration-level Scheduling）的核心思想非常简单：

> **不要把 batch 当作"一批请求一起处理到完成"，而是把每次 forward pass 当作一个独立的"迭代"。在每次迭代之间，可以自由地往 batch 里添加新请求或移除已完成的请求。**

```
静态批处理 vs 连续批处理：

静态批处理（Batch-level）：
┌──────────────────────────────────────────────────────────────┐
│ Batch = {A, B, C, D}                                         │
│                                                              │
│  Iteration 1:  [A B C D] ──► forward ──► [a1 b1 c1 d1]      │
│  Iteration 2:  [A B C D] ──► forward ──► [a2 b2 c2 d2]      │
│  Iteration 3:  [A B C D] ──► forward ──► [a3 b3 c3 d3]      │
│     ...                                                      │
│  Iteration N:  [A B C D] ──► forward ──► [aN bN cN dN]      │
│                                                              │
│  全部完成后，才组建下一个 batch                               │
└──────────────────────────────────────────────────────────────┘

连续批处理（Iteration-level）：
┌──────────────────────────────────────────────────────────────┐
│                                                              │
│  Iteration 1:  [A B C D] ──► forward ──► [a1 b1 c1 d1]      │
│                        A 完成！移除 A                         │
│  Iteration 2:  [B C D E] ──► forward ──► [b2 c2 d2 e1]      │
│                        F 新到达，加入 F                       │
│  Iteration 3:  [B C D E F] ──► forward ──► [b3 c3 d3 e2 f1] │
│                         C, D 完成！移除 C, D                  │
│  Iteration 4:  [B E F G H] ──► forward ──► [b4 e3 f2 g1 h1] │
│     ...                                                      │
│                                                              │
│  每次迭代都是一个新 batch，请求动态进出                       │
└──────────────────────────────────────────────────────────────┘
```

### 2.2 迭代循环的完整时间线

下面是一个完整的真实例子，展示 prefill（首次推理）和 decode（逐 token 生成）的混合调度：

```
完整的迭代时间线（带真实时间标注）：

时间 (ms)   0    50   100   150   200   250   300   350   400   450   500
           │     │     │     │     │     │     │     │     │     │     │

请求到达：
  Req1 ────►│ (预填充 512 tokens)
  Req2 ──────────►│ (预填充 2048 tokens)
  Req3 ─────────────────►│ (预填充 128 tokens)
  Req4 ───────────────────────────►│ (预填充 4096 tokens)

迭代调度：
           │     │     │     │     │     │     │     │     │     │     │
  Iter1    [PF:Req1(512)]                                  batch_tokens=512
  Iter2    [D:Req1] [PF:Req2(512/2048)]                     batch_tokens=1+512=513
  Iter3    [D:Req1] [PF:Req2(512/2048)]                     batch_tokens=1+512=513
  Iter4    [D:Req1] [PF:Req2(512/2048)]                     batch_tokens=1+512=513
  Iter5    [D:Req1] [PF:Req2(512/2048)] [PF:Req3(128)]      batch_tokens=1+512+128=641
  Iter6    [D:Req1] [D:Req2] [D:Req3]                       batch_tokens=1+1+1=3
                                  Req1 完成！(EOS)
  Iter7             [D:Req2] [D:Req3] [PF:Req4(1024/4096)]  batch_tokens=1+1+1024=1026
  Iter8             [D:Req2] [D:Req3] [PF:Req4(1024/4096)]  batch_tokens=1+1+1024=1026
  Iter9             [D:Req2] [D:Req3] [PF:Req4(1024/4096)]  batch_tokens=1+1+1024=1026
                                  Req3 完成！(EOS)
  Iter10            [D:Req2] [PF:Req4(1024/4096)]            batch_tokens=1+1024=1025
  Iter11            [D:Req2] [D:Req4]                        batch_tokens=1+1=2
  ...
  Iter40            [D:Req2] [D:Req4]                        batch_tokens=1+1=2
                                  Req2 完成！(EOS)
  Iter41                     [D:Req4]                        batch_tokens=1
  ...
  Iter80                     [D:Req4]                        batch_tokens=1
                                  Req4 完成！(EOS)

图例：
  PF:ReqX(N)  = 请求 X 处于 Prefill 阶段，本迭代处理 N 个 token
  D:ReqX      = 请求 X 处于 Decode 阶段，本迭代生成 1 个新 token
  PF:ReqX(N/M) = 请求 X 的 Chunked Prefill，总 token 数 M，本 chunk 处理 N 个
```

### 2.3 算法伪代码

```python
# vLLM scheduler 核心循环（简化版）
# 源码位置: vllm/core/scheduler.py

class Scheduler:

    def schedule(self) -> SchedulerOutputs:
        """
        每次迭代被调用一次，返回本轮要执行的 batch。
        """
        # 第1步：收集已完成请求，释放资源
        finished_requests = self._get_finished_requests()
        for req in finished_requests:
            self.free(req)  # 释放 KV cache blocks

        # 第2步：从等待队列中取新请求，尝试分配 KV cache
        new_requests = []
        while self.waiting and self._can_allocate():
            req = self.waiting.popleft()
            if self.block_manager.can_allocate(req):
                self.block_manager.allocate(req)
                new_requests.append(req)
            else:
                # 无法分配：放回队首，停止尝试
                self.waiting.appendleft(req)
                break

        # 第3步：构建本轮 batch
        # 3a. 先调度 prefill 请求（优先保证 TTFT）
        scheduled_prefills = self._schedule_prefills(
            new_requests,
            token_budget=self.max_num_batched_tokens - self._decode_tokens
        )

        # 3b. 剩余 token budget 分配给 decode 请求
        scheduled_decodes = self._schedule_decodes(
            self.running,
            token_budget=self.max_num_batched_tokens - self._prefill_tokens(scheduled_prefills)
        )

        # 第4步：如果 GPU 显存不足，执行抢占
        if self.block_manager.free_blocks < self.watermark_blocks:
            self._preempt_requests()

        # 第5步：组建成 SchedulerOutput
        return SchedulerOutput(
            scheduled_requests=scheduled_prefills + scheduled_decodes,
            num_prefills=len(scheduled_prefills),
            num_decodes=len(scheduled_decodes),
        )
```

### 2.4 关键数据结构

```
调度器维护的核心数据结构：

┌─────────────────────────────────────────────────────────────────┐
│                        Scheduler State                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  waiting: Deque[SequenceGroup]   ← FIFO 等待队列               │
│  running: Deque[SequenceGroup]   ← 正在执行中的序列组           │
│  swapped: Deque[SequenceGroup]   ← 被抢占换出的序列组           │
│                                                                 │
│  block_manager: BlockSpaceManager                               │
│    ├── gpu_allocator: CachedBlockAllocator                      │
│    │     ├── free_blocks: int    ← GPU 空闲 block 数            │
│    │     └── total_blocks: int   ← GPU 总 block 数              │
│    └── cpu_allocator: CachedBlockAllocator  (optional)          │
│                                                                 │
│  max_num_seqs: int               ← 最多同时执行的序列数         │
│  max_num_batched_tokens: int     ← 每轮迭代最多处理 token 数    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Prefill 与 Decode 的协同调度

### 3.1 两个阶段，两种特性

LLM 推理天然分为两个阶段，它们的计算特征截然不同：

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Prefill vs Decode                               │
├──────────────────┬──────────────────────┬───────────────────────────────┤
│      特性         │       Prefill        │           Decode              │
├──────────────────┼──────────────────────┼───────────────────────────────┤
│  输入 token 数    │  N (prompt length)   │  1 (上一轮生成的 token)       │
│  输出 token 数    │  1 (first token)     │  1 (下一个 token)             │
│  计算瓶颈         │  Compute-bound       │  Memory-bound                 │
│  算术强度         │  高                  │  极低 (~1)                    │
│  延迟             │  高 (100-500ms+)     │  低 (10-50ms)                 │
│  GPU 利用率       │  高 (>80%)           │  低 (20-40%)                  │
│  适合批处理        │  中等                │  极好 (越大越好)              │
│  attention 模式    │  因果 (causal)       │  因果 (只算最后一个 token)    │
└──────────────────┴──────────────────────┴───────────────────────────────┘
```

**Prefill 的 Compute-Bound 特性分析：**

Prefill 阶段一次性处理 prompt 中的所有 token。每个 token 需要和其他所有 token（包括它自己之前的）做 attention。对于长度为 N 的 prompt：

```
计算量 = O(N²·d)   其中 d 是 hidden dimension
显存访问 = O(N·d)

算术强度 = 计算量 / 显存访问 = O(N)

当 N = 4096 时，算术强度 >> GPU 的 ops/byte 比值（FLOPS / 显存带宽）
→ compute-bound
```

**Decode 的 Memory-Bound 特性分析：**

Decode 阶段每次只生成 1 个 token。这个 token 需要和 KV cache 中的所有历史 token 做 attention：

```
计算量 = O(N·d)   只计算 1 个 query token
显存访问 = O(N·d) 需要读取全部 KV cache

算术强度 = 计算量 / 显存访问 = O(1) ≈ 1-2 FLOPS/byte

以 A100 (80GB) 为例：
  峰值 FLOPS: 312 TFLOPS (FP16)
  显存带宽:   2039 GB/s
  ops/byte 比值: 312e12 / 2039e9 ≈ 153 FLOPS/byte

Decode 的算术强度 (~2) << 153 → 严重 memory-bound
GPU 大部分时间在等待数据从 HBM 加载到 SRAM
```

### 3.2 Roofline 模型分析

```
GPU Roofline Model (A100-80GB SXM):

Performance (TFLOPS)
    ^
312 ┤                                    ● Prefill (512 tokens, ~80 TFLOPS)
    │                                    │ 位于 compute-bound 区域
    │                            ● Prefill (128 tokens, ~45 TFLOPS)
    │                   ● Prefill (32 tokens, ~20 TFLOPS)
    │
 20 ┤              ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄  Memory Bandwidth Ceiling
    │          ▄▄▄▄
    │      ▄▄▄▄
    │   ▄▄▄
  1 ┤▄▄▄  ● Decode (1 token, ~1 TFLOPS, severely BW-limited)
    │
    └────┴────┴────┴────┴────┴────┴────┴────┴────┴──> Arithmetic Intensity (FLOP/byte)
         1    2    4    8   16   32   64  128  256

Decode 被显存带宽严重限制 → 需要尽量大 batch 来提高吞吐
Prefill 位于 compute-bound 区域 → batch 大小对单个 prefill 延迟影响有限
```

### 3.3 max_num_batched_tokens：核心节流阀

`max_num_batched_tokens` 是 continuous batching 中最关键的调度参数。它限制了每次迭代最多能处理多少个 token（prefill token + decode token 的总和）。

```
max_num_batched_tokens = 8192 时的调度示例：

迭代中的 token 分配：
┌──────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  Budget = 8192 tokens/iteration                                      │
│                                                                      │
│  Iteration N:                                                        │
│    ├── Prefill: Req1(2048) + Req2(1024) + Req3(512)                  │
│    │   prefill_tokens = 3584                                         │
│    ├── Decode:  Req4 + Req5 + Req6 + ... + Req35 (32 requests)       │
│    │   decode_tokens = 32 × 1 = 32                                   │
│    ├── Total: 3584 + 32 = 3616 ≤ 8192 ✓                             │
│    └── Remaining budget: 8192 - 3616 = 4576 (unused this iteration)  │
│                                                                      │
│  Iteration N+1:                                                      │
│    ├── Prefill: Req7(4096) ← 使用了 4096 budget                      │
│    │   prefill_tokens = 4096                                         │
│    ├── Decode:  Req1 + Req2 + ... + Req35 (35 requests)              │
│    │   decode_tokens = 35 × 1 = 35                                   │
│    ├── Total: 4096 + 35 = 4131 ≤ 8192 ✓                             │
│    └── Remaining budget: 8192 - 4131 = 4061                          │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

**参数选择的影响：**

```
max_num_batched_tokens 调优对比：

┌─────────────────────┬──────────────────────┬────────────────────────┐
│    参数值            │        优点          │         缺点           │
├─────────────────────┼──────────────────────┼────────────────────────┤
│  小 (2048-4096)     │  每次迭代延迟低       │  长 prompt 需多次迭代  │
│                     │  TTFT 更可控          │  prefill 吞吐下降      │
│                     │  显存峰值低           │                        │
├─────────────────────┼──────────────────────┼────────────────────────┤
│  中 (8192)          │  平衡延迟与吞吐       │  大多数场景的推荐值    │
│                     │  长 prompt 2-4次迭代  │                        │
├─────────────────────┼──────────────────────┼────────────────────────┤
│  大 (16384-32768)   │  prefill 吞吐高       │  单次迭代延迟高        │
│                     │  长 prompt 一次完成   │  TTFT 抖动大           │
│                     │                      │  可能 OOM               │
└─────────────────────┴──────────────────────┴────────────────────────┘

建议：
  - 33B 模型 + A100 80GB: max_num_batched_tokens = 8192~16384
  - 67B 模型 + A100 80GB: max_num_batched_tokens = 4096~8192
  - 对接 RAG（prompt 较长时）: max_num_batched_tokens >= 4096
```

### 3.4 Prefill First, Decode Fill

调度优先级策略：每次迭代优先调度 prefill 请求，剩余 token budget 才分给 decode 请求。

```
调度优先级的原因：

┌─────────────────────────────────────────────────────────────────────┐
│  Prefill 优先级 > Decode 优先级                                     │
│                                                                     │
│  原因 1: TTFT 是用户体验的核心指标                                  │
│    用户提交 prompt 后，等待 first token 的时间直接影响体感。        │
│    尽早执行 prefill = 尽早返回 first token。                        │
│                                                                     │
│  原因 2: Decode 对延迟不敏感                                       │
│    Decode 只需要多等 1 个迭代周期就能继续，                         │
│    而 Prefill 如果被延迟，用户在等待 first token。                  │
│                                                                     │
│  原因 3: Decode token 永远是 1 个                                   │
│    把剩余的 budget 分给 decode 非常容易，                           │
│    因为每个 decode 请求只消耗 1 个 token budget。                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

详细分配流程：

def allocate_token_budget(waiting, running, budget):
    """
    waiting: 等待 prefill 的请求列表
    running: 正在 decode 的请求列表
    budget:  max_num_batched_tokens
    """
    scheduled = []
    remaining = budget

    # ===== 第 1 阶段：分配 Prefill =====
    for req in waiting:
        if req.can_be_prefill_chunked():
            # Chunked prefill: 只分配一个 chunk
            chunk_size = min(req.remaining_tokens, max_chunk_size(remaining))
        else:
            chunk_size = req.remaining_tokens

        if chunk_size <= remaining:
            scheduled.append(PrefillSlot(req, chunk_size))
            remaining -= chunk_size
        else:
            break  # budget 用完了

    # ===== 第 2 阶段：分配 Decode =====
    for req in running:
        if 1 <= remaining:  # decode 每个请求只需要 1 token budget
            scheduled.append(DecodeSlot(req))
            remaining -= 1
        else:
            break

    return scheduled, remaining
```

---

## 4. Chunked Prefill 深度解析

### 4.1 问题的根源

在没有 Chunked Prefill 的情况下，一个长 prompt 的 prefill 会在单次迭代中处理全部 token。这带来了严重的问题：

```
无 Chunked Prefill 的问题：

假设 max_num_batched_tokens = 8192

请求队列：
  ReqA: prompt=8192 tokens (长文档 RAG)
  ReqB: prompt=128 tokens  (简单问答)
  ReqC: prompt=256 tokens  (普通对话)
  ReqD: decode (已在运行中)

───────────────────────────────────────────────────────────────────
│ Iteration 1:                                                      │
│   Prefill ReqA(8192) → 8192/8192 budget 全部用光                  │
│   Decode 无法调度！→ 0 个 decode 请求                             │
│                                                                   │
│   耗时：~300ms（处理 8192 tokens 的 prefill）                     │
│   所有正在 decode 的请求在这 300ms 内全部暂停！                   │
│──────────────────────────────────────────────────────────────────│
│ Iteration 2:                                                      │
│   Prefill: ReqB(128) + ReqC(256)                                  │
│   Decode:  ReqA + 之前暂停的所有 decode 请求                      │
│                                                                   │
│   之前暂停的 decode 请求经历了 ~300ms 的 TPOT 尖刺！              │
│   用户看到的 TPOT 从正常的 30ms 突然跳到 330ms！                  │
└───────────────────────────────────────────────────────────────────┘
```

**TPOT 尖刺（Spike）的后果：**

- 用户体验：输出会突然"卡住"，然后继续。对于实时对话场景非常糟糕。
- Streaming 客户端：SSE 事件流出现明显间隙，Claude Code 等工具客户端可能误判为超时。
- 调度公平性：decode 请求被"饿死"，长 prompt 请求垄断 GPU。

### 4.2 Chunked Prefill 的解决方案

核心思想：**把一个长 prefill 拆成多个 chunk，分散到多次迭代中执行，中间穿插 decode 请求。**

```
Chunked Prefill 下的相同场景：

max_num_batched_tokens = 8192
max_prefill_chunk_size = 2048（折半或更小均可）

请求队列：
  ReqA: prompt=8192 tokens
  ReqB: prompt=128 tokens
  ReqC: prompt=256 tokens

───────────────────────────────────────────────────────────────────
│ Iteration 1:                                                      │
│   Prefill: ReqA(chunk1: 2048/8192) + ReqB(128) + ReqC(256)        │
│   Decode:  22 个正在运行的 decode 请求 (22×1=22)                   │
│   Total:   2048 + 128 + 256 + 22 = 2454 ≤ 8192 ✓                 │
│   耗时:    ~80ms                                                  │
│──────────────────────────────────────────────────────────────────│
│ Iteration 2:                                                      │
│   Prefill: ReqA(chunk2: 2048/8192)                                │
│   Decode:  ReqB + ReqC + 25 个其他 decode (27×1=27)               │
│   Total:   2048 + 27 = 2075 ≤ 8192 ✓                             │
│   耗时:    ~80ms                                                  │
│──────────────────────────────────────────────────────────────────│
│ Iteration 3:                                                      │
│   Prefill: ReqA(chunk3: 2048/8192)                                │
│   Decode:  ReqA + ReqB + ReqC + 24 个其他 (27×1=27)               │
│   Total:   2048 + 27 = 2075                                       │
│   耗时:    ~80ms                                                  │
│──────────────────────────────────────────────────────────────────│
│ Iteration 4:                                                      │
│   Prefill: ReqA(chunk4: 2048/8192) ← 最后一个 chunk              │
│   Decode:  ReqA + ReqB + ReqC + 24 个其他 (27×1=27)               │
│   Total:   2048 + 27 = 2075                                       │
│   耗时:    ~80ms                                                  │
│   → ReqA prefill 完成，开始正常 decode                           │
│                                                                   │
│   TPOT：全程稳定在 ~50-60ms，没有尖刺！                           │
└───────────────────────────────────────────────────────────────────┘
```

### 4.3 Chunk Size 的确定

Chunk size 的选择是 Chunked Prefill 的核心调优点：

```python
# vLLM 源码逻辑（vllm/core/scheduler.py 简化）
# 参考: https://github.com/vllm-project/vllm/blob/main/vllm/core/scheduler.py

def _calculate_chunk_size(
    self,
    remaining_tokens: int,      # 请求剩余需要 prefill 的 token 数
    remaining_budget: int,      # 本轮剩余 token budget
    num_running_decodes: int,   # 正在 decode 的请求数
) -> int:
    """
    计算本次迭代应该为此请求分配多少 prefill token。

    目标：
    1. 不要独占所有 budget（给 decode 留空间）
    2. 不要切得太碎（chunk 太小 → 迭代数太多 → 浪费 compute）
    3. 不要太大（失去 chunked prefill 的意义）
    """

    # 基础 chunk size：取预算的 1/2 或 1/4
    max_chunk = remaining_budget // 2

    # 至少给 decode 预留 (num_running_decodes × 1) 个 slot
    decode_reserve = min(num_running_decodes, remaining_budget // 4)
    max_chunk = min(max_chunk, remaining_budget - decode_reserve)

    # 确保 chunk 不会太小（至少 256 tokens，否则效率太低）
    if max_chunk < 256 and remaining_tokens > 256:
        # 太小的话直接不分 chunk 了，本轮全跳过，下轮用更多 budget
        return 0

    return min(remaining_tokens, max_chunk)
```

**Chunk Size 对性能的影响：**

```
Chunk Size 调优矩阵：

┌──────────────────┬───────────────────────┬───────────────────────┐
│   Chunk Size     │   TTFT (更长)         │   TPOT 稳定性 (更好)  │
├──────────────────┼───────────────────────┼───────────────────────┤
│  小 (512)        │  ReqA TTFT = 第4次    │  TPOT 最大 ~60ms     │
│                  │  迭代才有 first token  │  非常平滑             │
│                  │  = 4 × 80ms = 320ms   │                       │
├──────────────────┼───────────────────────┼───────────────────────┤
│  中 (2048)       │  ReqA TTFT = 第2次    │  TPOT 最大 ~120ms    │
│  (推荐)          │  迭代 = 2 × 80ms      │  略有波动             │
│                  │  = 160ms              │                       │
├──────────────────┼───────────────────────┼───────────────────────┤
│  大 (4096)       │  ReqA TTFT = 第1次    │  TPOT 最大 ~200ms    │
│                  │  迭代 = 80ms          │  有明显尖刺           │
│                  │  但挤占了所有 decode   │                       │
├──────────────────┼───────────────────────┼───────────────────────┤
│  无 chunk (8192) │  ReqA TTFT = 80ms     │  TPOT 最大 ~320ms    │
│                  │  最快但最不公平        │  严重尖刺             │
└──────────────────┴───────────────────────┴───────────────────────┘

关键取舍：
  TTFT ↑ (变差)  ↔  TPOT 公平性 ↑ (变好)

推荐策略：
  生产环境：始终启用 chunked prefill，chunk_size = max_num_batched_tokens / 4
  例如：max_num_batched_tokens=8192 → chunk_size=2048
```

### 4.4 Scheduler 中的 Chunked Prefill 实现

```python
# 完整的 Chunked Prefill 调度逻辑（伪代码，基于 vLLM 源码）

class Scheduler:

    def _schedule_prefills(
        self,
        waiting_requests: Deque[SequenceGroup],
        token_budget: int,
    ) -> List[SequenceGroup]:
        """
        调度 Prefill 请求，支持 Chunked Prefill。

        对每个等待的请求：
        1. 如果是新请求 → 计算本次分配的 chunk size
        2. 如果是 partially prefilled → 继续处理剩余 token
        3. 在 chunk 完成后，请求转入 decode 阶段（开始返回 token）
        """
        scheduled = []
        remaining_budget = token_budget

        while waiting_requests and remaining_budget > 0:
            seq_group = waiting_requests[0]  # peek 队首

            # 检查是否能分配 KV cache
            if not self.block_manager.can_allocate(seq_group):
                break

            # 计算本请求此次分配的 token 数
            num_new_tokens = seq_group.get_num_new_tokens()

            if num_new_tokens <= remaining_budget:
                # 可以直接完整 prefill
                allocated = num_new_tokens
            else:
                # 需要 chunked prefill
                allocated = self._get_chunk_size(remaining_budget)
                if allocated < 256:  # chunk 太小，不值得切
                    break

            if allocated == 0:
                break

            # 分配 KV cache blocks
            self.block_manager.allocate(seq_group, allocated)

            waiting_requests.popleft()  # 从等待队列移除
            seq_group.mark_as_running()

            scheduled.append(seq_group)
            remaining_budget -= allocated

            # 如果该请求没有完全 prefilled，
            # 它会被留在 running 状态，等待下次迭代继续 prefill
        return scheduled

    def _get_chunk_size(self, remaining_budget: int) -> int:
        """
        确定一个合理的 chunk size。
        基于以下因素：
        - 剩余 token budget
        - 等待中的其他请求数（公平性）
        - 最小 chunk 效率阈值
        """
        # 策略 1：取 budget 的一半，给其他请求留空间
        chunk = remaining_budget // 2

        # 策略 2：如果等待队列中有其他请求，分得更小
        if len(self.waiting) > 1:
            chunk = min(chunk, remaining_budget // max(len(self.waiting), 1))

        # 确保 chunk 不太小也不太大
        chunk = max(chunk, 256)  # 最小 256，保证 compute 效率
        chunk = min(chunk, 4096)  # 最大 4096，防止单次迭代过长

        return chunk
```

### 4.5 性能权衡的数值分析

```
Chunked Prefill 的代价-收益分析（33B 模型，A100 80GB）：

假设场景：
  - 1 个长 prompt (8192 tokens) 到达时，已有 32 个 decode 请求在运行
  - 每次迭代基准耗时：50ms（32 decode 请求）
  - Prefill 额外开销：~0.03ms/token (粗略估计)

┌──────────────────┬──────────────┬──────────────┬──────────────┐
│      方案         │  迭代次数    │  ReqA TTFT   │  最大 TPOT   │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│  无 chunk         │  1 次 prefill│  50+246=296ms│  296ms(尖刺) │
│  (8192 tokens)   │  (300ms)     │              │  其他: 50ms  │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│  chunk=4096      │  2 次        │  50+123=173ms│  173ms       │
│                  │  (各 173ms)  │              │              │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│  chunk=2048      │  4 次        │  50+61=111ms │  111ms       │
│  (推荐)          │  (各 111ms)  │              │              │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│  chunk=1024      │  8 次        │  50+31=81ms  │  81ms        │
│                  │  (各 81ms)   │              │              │
├──────────────────┼──────────────┼──────────────┼──────────────┤
│  chunk=512       │  16 次       │  50+15=65ms  │  65ms        │
│                  │  (各 65ms)   │  (最平滑)    │              │
└──────────────────┴──────────────┴──────────────┴──────────────┘

结论：
  - chunk=2048 是平衡点：TTFT 增加 222ms，但 TPOT 从 296ms 降到 111ms
  - 对于对接 Claude Code（需要流式输出稳定），chunk=1024~2048 是最佳选择
  - 对于批处理离线推理，可以适当增大 chunk
```

### 4.6 启用配置

```
vLLM 启动参数中启用 Chunked Prefill：

# 方式 1：显式配置（推荐）
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/your/33b-model \
    --max-num-batched-tokens 8192 \
    --max-num-seqs 64 \
    --enable-chunked-prefill \
    --max-num-batched-tokens 8192    # chunk size 会自动计算

# 方式 2：通过代码配置
from vllm import LLM, SamplingParams

llm = LLM(
    model="/path/to/your/33b-model",
    max_num_batched_tokens=8192,
    max_num_seqs=64,
    enable_chunked_prefill=True,
    # chunked prefill 相关参数（vLLM 0.4.0+）
    max_num_prefills=16,  # 每次迭代最多调度 16 个 prefill chunk
)
```

---

## 5. 调度策略详解

### 5.1 FCFS with Prefill Priority

vLLM 采用的核心调度策略是**带优先级的先到先服务（FCFS with Prefill Priority）**：

```
调度优先级层次：

┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│  第 1 优先级 (最高): Prefill → 保证 TTFT                         │
│  第 2 优先级 (次高): Decode  → 保证吞吐                          │
│  第 3 优先级 (最低): Swapped → 抢占后恢复（需要先 recompute）    │
│                                                                  │
│  在所有请求类别内部，使用 FCFS（First-Come, First-Served）       │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

### 5.2 请求状态与转换

```
请求状态机：

                              ┌─────────────────────────────────┐
                              │                                 │
                              ▼                                 │
              ┌──────────────────────────┐                      │
              │                          │                      │
    请求到达  │        WAITING           │                      │
    ────────►│  (等待被调度)              │                      │
              │                          │                      │
              └──────────┬───────────────┘                      │
                         │                                       │
                         │ 调度器分配了 KV cache + token budget  │
                         │ (进入 prefill)                        │
                         ▼                                       │
              ┌──────────────────────────┐                      │
              │                          │                      │
              │    RUNNING (PREFILL)     │                      │
              │  (正在处理 prompt tokens) │                      │
              │                          │                      │
              └──────────┬───────────────┘                      │
                         │                                       │
                         │ prefill 完成（所有 prompt token 处理完）│
                         │ first token 已生成                     │
                         ▼                                       │
              ┌──────────────────────────┐                      │
              │                          │                      │
              │    RUNNING (DECODE)      │                      │
              │  (逐 token 生成)          │──────────────────────┤
              │                          │    生成了 EOS token   │
              └──────────┬───────────────┘   或达到 max_tokens   │
                         │                        │              │
                         │                        ▼              │
                         │              ┌──────────────────────┐ │
              ┌──────────────────┐     │                      │ │
              │                  │     │      FINISHED        │ │
              │     SWAPPED      │     │  (请求完成，释放资源)  │ │
              │  (KV cache 被移到 │◄────│                      │ │
              │   CPU，等待恢复)   │     └──────────────────────┘ │
              │                  │                               │
              └────────┬─────────┘                               │
                       │                                         │
                       │ GPU 显存恢复充足                         │
                       │ (从 CPU 加载回 KV cache)                 │
                       └─────────────────────────────────────────┘

状态转换条件详解：

┌──────────────────────┬──────────────────────────────────────────────┐
│      转换             │              触发条件                        │
├──────────────────────┼──────────────────────────────────────────────┤
│ WAITING → PREFILL    │ 有足够 GPU block + 有 token budget            │
│ PREFILL → DECODE     │ 所有 prompt token 完成 prefill                │
│ DECODE → FINISHED    │ 生成 EOS token 或达到 max_tokens              │
│ DECODE → SWAPPED     │ GPU 显存不足，需要抢占                        │
│ PREFILL → SWAPPED    │ GPU 显存不足，需要抢占（少见）                 │
│ SWAPPED → WAITING    │ GPU 显存恢复，调度器决定重新调度              │
│ 任何状态 → FINISHED  │ 被用户 abort 或超时                          │
└──────────────────────┴──────────────────────────────────────────────┘
```

### 5.3 调度函数逐步详解

```python
# ============================================================
# vLLM Scheduler.schedule() 完整逻辑详解
# 源码位置: vllm/core/scheduler.py
# ============================================================

def schedule(self) -> Tuple[List[SequenceGroupMetadata], SchedulerOutputs]:
    """
    核心调度函数。每次模型 forward 前调用一次。
    返回：本迭代需要处理的序列列表 + 调度元数据
    """

    # ============================================================
    # 步骤 1: 收集已完成的请求，释放资源
    # ============================================================
    """
    上一轮迭代可能产生了 EOS token 的请求。
    这些请求的资源（KV cache blocks）必须在本轮调度前释放，
    才能给新请求腾出空间。
    """
    finished_seq_groups = []
    for seq_group in self.running:
        for seq in seq_group.get_seqs(status=SequenceStatus.RUNNING):
            if seq.is_finished():  # 生成了 EOS 或达到 max_tokens
                finished_seq_groups.append(seq_group)

    # 释放它们的资源
    for seq_group in finished_seq_groups:
        self.free_seq(seq_group)  # 释放 KV cache blocks
        self.running.remove(seq_group)

    # ============================================================
    # 步骤 2: 检查是否有等待请求需要加入
    # ============================================================
    """
    遍历 waiting 队列 (FIFO)，尽可能多地分配资源给新请求。
    如果资源不够，停止尝试并保留请求在队列中。
    """
    waiting_queue = self.waiting  # Deque[SequenceGroup], FIFO

    # 同时检查 swapped 队列（被抢占的请求可以恢复）
    # 当 GPU block 充足时，优先恢复 swapped 请求而不是新请求
    if self.swapped:
        # 恢复 swapped 请求：需要 CPU→GPU 拷贝 KV cache
        resumed = self._schedule_swapped()

    # ============================================================
    # 步骤 3: Token Budget 分配 - Prefill 请求
    # ============================================================
    """
    这是核心 token budget 分配逻辑。

    Budget = max_num_batched_tokens

    先给 prefill 分，剩余给 decode。
    """
    scheduled_prefills = []
    remaining_budget = self.max_num_batched_tokens

    # ----- 3a. 调度新请求的 prefill -----
    for seq_group in waiting_queue:
        num_tokens = seq_group.get_seqs()[0].get_len()  # prompt 长度

        if self.enable_chunked_prefill:
            # 计算 chunk size
            chunk = self._compute_chunk_size(
                seq_group, remaining_budget, len(self.running)
            )
            num_to_schedule = min(num_tokens, chunk)
        else:
            num_to_schedule = num_tokens

        # 检查 1: 是否有足够 token budget
        if num_to_schedule > remaining_budget:
            break

        # 检查 2: 是否有足够 KV cache blocks
        required_blocks = self._required_blocks(seq_group, num_to_schedule)
        if required_blocks > self.block_manager.get_num_free_gpu_blocks():
            break

        # 分配！
        self.block_manager.allocate(seq_group, num_to_schedule)
        waiting_queue.popleft()  # FIFO: 取出队首
        scheduled_prefills.append(seq_group)
        remaining_budget -= num_to_schedule

    # ============================================================
    # 步骤 4: Token Budget 分配 - Decode 请求
    # ============================================================
    """
    剩余 budget 分给 decode 请求。
    每个 decode 请求只需要 1 个 token budget。
    """
    scheduled_decodes = []

    for seq_group in self.running:
        if remaining_budget <= 0:
            # Budget 用完了，本迭代暂时跳过此请求
            # 注意：被跳过的请求不会"丢失"进度，
            # KV cache 完好无损，下轮继续
            continue

        # 检查该请求是否在 decode 阶段
        if seq_group.is_prefill():
            continue  # 还在 prefill，跳过

        scheduled_decodes.append(seq_group)
        remaining_budget -= 1

    # ============================================================
    # 步骤 5: 抢占检查
    # ============================================================
    """
    如果 GPU block 不足，需要抢占一些请求，
    将其 KV cache 换出到 CPU 或丢弃。
    """
    if self.block_manager.get_num_free_gpu_blocks() < self.block_watermark:
        to_preempt = self._select_requests_to_preempt()
        for seq_group in to_preempt:
            self._preempt(seq_group)  # swap 或 recompute

    # ============================================================
    # 步骤 6: 构建模型输入
    # ============================================================
    """
    将 scheduled 的请求转化为模型 forward pass 需要的 tensor。

    模型输入包括：
    - input_ids: [total_tokens] 所有请求的 token ids 拼接
    - positions: [total_tokens] 每个 token 在序列中的位置
    - block_tables: 每个序列的 KV cache block 表
    - query_lens / seq_lens: 用于 PagedAttention kernel
    """
    seq_group_metadata_list = self._build_input_metadata(
        scheduled_prefills + scheduled_decodes
    )

    # ============================================================
    # 步骤 7: 返回调度结果
    # ============================================================
    return (
        seq_group_metadata_list,
        SchedulerOutputs(
            num_prefills=len(scheduled_prefills),
            num_decodes=len(scheduled_decodes),
            num_preempted=len(to_preempt) if 'to_preempt' in locals() else 0,
            total_num_scheduled_tokens=(
                sum(p.num_tokens for p in scheduled_prefills) +
                len(scheduled_decodes)
            ),
        ),
    )
```

### 5.4 Token Budget 分配的具体示例

```
场景：max_num_batched_tokens = 8192, max_num_seqs = 64

当前状态：
  waiting: [ReqA(prompt=4096), ReqB(prompt=2048), ReqC(prompt=512), ReqD(prompt=256)]
  running (decode): [ReqE, ReqF, ReqG, ..., ReqZ] (22 个 decode 请求)

─────────────────────────────────────────────────────────────────────
步骤 3: Prefill 分配
─────────────────────────────────────────────────────────────────────

Budget = 8192

● 尝试分配 ReqA(4096):
  chunk_size = max(remaining_budget // 2, 4096//4 = 1024) = 4096
  4096 ≤ 8192 ✓  →  分配 4096 tokens
  remaining = 8192 - 4096 = 4096

● 尝试分配 ReqB(2048):
  chunk_size = max(4096 // 2, 2048) = 2048
  2048 ≤ 4096 ✓  →  分配 2048 tokens
  remaining = 4096 - 2048 = 2048

● 尝试分配 ReqC(512):
  512 ≤ 2048 ✓  →  分配 512 tokens
  remaining = 2048 - 512 = 1536

● 尝试分配 ReqD(256):
  256 ≤ 1536 ✓  →  分配 256 tokens
  remaining = 1536 - 256 = 1280

─────────────────────────────────────────────────────────────────────
步骤 4: Decode 分配
─────────────────────────────────────────────────────────────────────

Remaining budget = 1280

22 个 decode 请求，每个只需 1 token:
  22 ≤ 1280 ✓  →  全部 22 个都调度
  remaining = 1280 - 22 = 1258

─────────────────────────────────────────────────────────────────────
本轮结果:
  Prefill: 4 个请求，共 4096+2048+512+256 = 6912 tokens
  Decode:  22 个请求，共 22 tokens
  Total:   6912 + 22 = 6934 tokens (84.7% budget 利用率)
  Remaining: 1258 tokens (浪费)
─────────────────────────────────────────────────────────────────────

调度效率分析:
  - 剩余 1258 是因为所有可调度请求都已分配完毕
  - 这是一种"健康"的浪费 — 不是资源不足，是没有更多工作
  - 如果 waiting 队列不为空 → 说明显存不够或 max_num_seqs 限制
```

---

## 6. 抢占策略

### 6.1 什么时候需要抢占

```
触发抢占的场景：

┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  场景 1: 大量新请求到达                                          │
│    waiting 队列堆积，但 running 请求占满了 KV cache blocks       │
│    → GPU 显存中没有空闲 block                                    │
│    → 需要驱逐一些 running 请求，给新请求腾空间                   │
│                                                                 │
│  场景 2: KV Cache 碎片化                                         │
│    由于 PagedAttention 的 block 分配/释放，                      │
│    free blocks 分散在各处，无法分配给大 prompt 请求              │
│    → 虽然没有 OOM，但"可用 block"不足                           │
│                                                                 │
│  场景 3: 突发长 prompt                                           │
│    正常运行中突然来了一个 32768 tokens 的 prompt                 │
│    → 需要大量连续 block，现有碎片化的 free blocks 不够           │
│    → 需要腾出连续的 block 空间                                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 6.2 策略一：Swap（换出）

**原理：将被抢占请求的 KV cache blocks 从 GPU 显存拷贝到 CPU 内存，释放 GPU block。**

```
Swap 策略详解：

  GPU HBM (80GB)                           CPU RAM (512GB+)
┌──────────────────────┐               ┌──────────────────────┐
│                      │               │                      │
│  Req1 KV Cache       │               │                      │
│  [Block 0][Block 1]  │──────────────►│  Req1 KV Cache       │
│  [Block 2][Block 3]  │   拷贝到 CPU   │  (swapped out)      │
│                      │               │                      │
│  释放 GPU blocks ──► │               │                      │
│  → 可以分配给新请求   │               │                      │
│                      │               │                      │
│  新请求到来时：       │               │                      │
│  [新 Block 0][新 B1] │◄──────────────│  Req1 KV Cache       │
│                      │   拷贝回 GPU   │  (swapped in)       │
│                      │               │                      │
└──────────────────────┘               └──────────────────────┘

PCIe 带宽分析（A100 SXM + NVLink）：
  PCIe Gen4 x16 带宽: ~32 GB/s（双向各 16 GB/s）

  假设 Req1 的 KV cache 为 2GB:
    换出延迟: 2GB / 16 GB/s = 125ms
    换入延迟: 2GB / 16 GB/s = 125ms
    总延迟: 250ms

  这就是为什么 swap 不是"免费"的 — 250ms 的延迟可能让用户感觉到卡顿。
```

**Swap 的优缺点：**

```
┌─────────────────────────────────────────────────────────────────┐
│ Swap 策略                                                        │
├────────────────────────────┬────────────────────────────────────┤
│  优点                       │  缺点                              │
├────────────────────────────┼────────────────────────────────────┤
│ 1. 保留计算进度              │ 1. PCIe 带宽有限 → 延迟高          │
│    不需要重新 prefill       │    2GB KV cache 换出需 ~125ms       │
│                             │                                    │
│ 2. 适合长时间运行的请求      │ 2. 占用 CPU 内存                  │
│    已经 decode 了 500 token │    多个请求换出叠加 → 内存压力     │
│    重算代价高 → swap 更划算  │    33B 模型 32个请求≈64GB CPU RAM  │
│                             │                                    │
│ 3. 恢复快于 recompute       │ 3. 不适合频繁换出/换入             │
│    只需拷贝数据，无需计算   │    thrashing 会严重降低吞吐        │
│                             │                                    │
└────────────────────────────┴────────────────────────────────────┘
```

### 6.3 策略二：Recompute（重算）

**原理：直接丢弃被抢占请求的 KV cache blocks，释放 GPU block。当请求恢复时，从头执行 prefill 重新计算 KV cache。**

```
Recompute 策略详解：

  GPU HBM
┌──────────────────────┐
│                      │
│  Req1 KV Cache       │  ← 直接释放！数据丢失
│  [Block 0][Block 1]  │
│  [Block 2][Block 3]  │
│  ░░░░░░░░░░░░░░░░░░░ │  ← 可以分配给新请求
│                      │
└──────────────────────┘

恢复时：
  1. 从 prompt 开始重新 prefill
  2. 重新分配 KV cache blocks
  3. 重新生成已丢失的 decode tokens

代价分析（不同场景）：
┌──────────────────────────────────────────────────────────────┐
│                                                              │
│  场景 A: prompt=256, 已 decode=500 tokens, 被抢占            │
│    Recomupte 代价 = prefill(256) + decode(500)               │
│    = ~15ms + ~500ms = 515ms 全部重算                         │
│    Swap 代价 = 拷贝 KV cache(GB级) ≈ 100ms                   │
│    → Swap 更优                                                │
│                                                              │
│  场景 B: prompt=4096, 已 decode=5 tokens, 被抢占             │
│    Recomupte 代价 = prefill(4096) + decode(5)                │
│    = ~120ms + ~5ms = 125ms                                   │
│    Swap 代价 ≈ 拷贝 KV cache(GB级) ≈ 100ms                   │
│    → 差不多，但 recompute 不占 CPU 内存 → Recompute 更优      │
│                                                              │
│  场景 C: prompt=8192, 已 decode=0 tokens (刚开始就抢占了)    │
│    Recomupte 代价 = prefill(8192) = ~250ms                   │
│    Swap 代价 ≈ 拷贝 + 恢复 ≈ 200ms                           │
│    → Recompute 更简单，且不占用 CPU 内存                      │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**Recompute 的优缺点：**

```
┌─────────────────────────────────────────────────────────────────┐
│ Recompute 策略                                                   │
├────────────────────────────┬────────────────────────────────────┤
│  优点                       │  缺点                              │
├────────────────────────────┼────────────────────────────────────┤
│ 1. 不占用 CPU 内存          │ 1. 丢失计算进度 → 浪费已完成工作    │
│                             │    已 decode 的 tokens 前功尽弃     │
│ 2. 无 PCIe 拷贝开销         │ 2. 恢复时间长                      │
│    释放即完成               │    需要重新 prefill 整个 prompt     │
│                             │                                    │
│ 3. 简单可靠                  │ 3. 长 prompt + 大量 decode 时      │
│    没有状态一致性问题       │    代价极高                         │
│                             │                                    │
└────────────────────────────┴────────────────────────────────────┘
```

### 6.4 vLLM 的默认策略与选择逻辑

```
vLLM 的抢占决策树：

                          需要抢占？
                              │
                    ┌─────────┴─────────┐
                    │                   │
                    ▼                   ▼
             请求已 decode      请求刚 prefill
             很多 token?        或 decode 很少?
                    │                   │
              ┌─────┴─────┐       ┌─────┴─────┐
              │           │       │           │
              ▼           ▼       ▼           ▼
          decode >    decode ≤  prompt >   prompt ≤
          N tokens   N tokens   256?       256?
              │           │       │           │
              ▼           ▼       ▼           ▼
            SWAP     RECOMPUTE  RECOMPUTE   RECOMPUTE
            (保留      (丢弃      (重算       (重算
            进度)     进度)      代价低)     代价低)

N 的默认值：vLLM 中默认 N = 256（即 decode 超过 256 tokens 后用 swap）
```

vLLM 实际源码中的选择逻辑（简化）：

```python
# vllm/core/block_manager.py (简化逻辑)

def _should_swap_or_recompute(self, seq_group, num_free_blocks_needed):
    """
    决定是 swap 还是 recompute。
    """
    num_decoded_tokens = (
        seq_group.get_seqs()[0].get_output_len()  # 已生成的 token 数
    )

    # 阈值：已 decode 超过 256 个 token 就用 swap
    if num_decoded_tokens > 256:
        # Swap：保留计算进度
        # 检查 CPU 内存是否够
        if self.cpu_allocator.get_num_free_blocks() >= seq_group.num_blocks:
            return PreemptionMode.SWAP
        else:
            # CPU 也不够了，只能 recompute
            return PreemptionMode.RECOMPUTE
    else:
        # Recompute：丢弃便宜的计算
        return PreemptionMode.RECOMPUTE
```

### 6.5 数值分析：何时哪种策略更优

```
Swap vs Recompute 决策矩阵（33B 模型，A100 80GB + 512GB CPU RAM）：

场景参数：
  P = prompt 长度 (tokens)
  D = 已 decode token 数
  Prefill 延迟 ≈ P × 0.03ms  （33B 模型在 A100 上大约 0.03ms/token for prefill）
  Decode 延迟  ≈ 1 × 30ms    （每 token 30ms，与 batch size 高度相关）
  Swap 延迟    ≈ KV_size_GB / 16 GB/s（PCIe Gen4 x16 单向带宽）

┌─────────┬────────┬───────────────┬───────────────┬──────────┐
│   P     │   D    │ Recompute 代价│  Swap 代价     │  最优     │
├─────────┼────────┼───────────────┼───────────────┼──────────┤
│  128    │   10   │  4+300=304ms  │ 60ms          │  Swap    │
│  128    │  500   │  4+15000=15s  │ 60ms          │  Swap    │
│  4096   │    5   │  123+150=273ms│ 200ms         │  Recom.  │
│  4096   │  100   │  123+3000=3.1s│ 200ms         │  Swap    │
│  8192   │    0   │  246ms        │ 400ms         │  Recom.  │
│  8192   │   50   │  246+1500=1.7s│ 400ms         │  Swap    │
│ 16384   │    2   │  492+60=552ms │ 800ms         │  Recom.  │
│ 16384   │  200   │  492+6000=6.5s│ 800ms         │  Swap    │
└─────────┴────────┴───────────────┴───────────────┴──────────┘

经验法则：
  - decode 超过 50~100 tokens → 用 Swap（保留进度比重新计算便宜）
  - prompt 很长 + decode 很少 → 用 Recompute（prefill 重算也不贵）
  - CPU 内存不足时 → 强制 Recompute（没得选）
```

---

## 7. 性能分析

### 7.1 GPU 利用率随时间变化

```
Continuous Batching 下 GPU 利用率的时间序列：

Util%  ^
  100 ┤                    ███████████████████████████████████
   98 ┤                    ███████████████████████████████████
   96 ┤                    ███████████████████████████████████
   94 ┤  ██████████████████████████████████████████████████████
   92 ┤  ██████████████████████████████████████████████████████
   90 ┤  ██████████████████████████████████████████████████████  ← 最低点
   88 ┤  ██████████████████████████████████████████████████████
   86 ┤  ██████████████████████████████████████████████████████
   84 ┤  ██████████████████████████████████████████████████████
   80 ┤  ██████████████████████████████████████████████████████
       ├─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────> Time (s)
       0     5    10    15    20    25    30    35    40    45

  波动来源：
  - 波动幅度通常 < 10%（而静态批处理波动 > 40%）
  - 最低点出现在：所有请求都是 decode 阶段，batch size 虽大但每个只做 1 token
  - 最高点出现在：prefill 阶段，batch 中混合了 prefill（compute-bound）和 decode

为什么 decode 阶段利用率偏低？
  Decode 是 memory-bound：GPU 计算单元大部分时间空闲，等数据从 HBM 加载。
  在 Roofline 模型上，Decode 位于斜率上升段，远低于峰值 FLOPS。

  但这不代表"浪费"——在 memory-bound 情况下，增加 batch size
  不会增加每个请求的延迟（因为瓶颈在内存带宽，而非计算）。
  所以 memory-bound 的"低利用率"是正常的、高效的。
```

### 7.2 吞吐量随并发数的扩展

```
吞吐量 vs 并发请求数（33B 模型，A100 80GB，输出 256 tokens）：

Throughput (tokens/s)
    ^
3000┤                                    ●───────●  (饱和)
    │                              ●────┘
2500┤                        ●────┘
    │                  ●────┘
2000┤            ●────┘
    │      ●────┘
1500┤●────┘
    │
1000┤
    │
 500┤
    │
   0┼─────┬─────┬─────┬─────┬─────┬─────┬─────┬──> Concurrent Requests
    0     8    16    24    32    40    48    56

    A 区 (1-8):     近线性扩展，GPU 等待新请求
    B 区 (8-24):    次线性扩展，GPU 利用率提升
    C 区 (24-48):   接近饱和，增益递减
    D 区 (>48):     饱和/下降，显存压力导致抢占

为什么会出现收益递减？
  1. max_num_seqs 限制：超出后新请求排队
  2. GPU 显存限制：KV cache 总量有上限
  3. 抢占开销：请求被换出/重算消耗吞吐
  4. Batch 效率：极大的 batch 下，每个请求的 decode 延迟略有增加（kernel launch overhead）
```

### 7.3 TTFT 分布在负载下

```
TTFT (Time To First Token) 的 CDF 分布：

CDF%
100 ┤                                          ████████████████
    │                                    ██████
 90 ┤                              ██████
    │                        ██████
 80 ┤                  ██████
    │            ██████
 70 ┤      ██████
    │██████
 60 ┤
    │
 50 ┤                          ← P50 ≈ 150ms
    │
 40 ┤
    │
 30 ┤
    │
 20 ┤                          Queueing delay 主导的长尾
    │
 10 ┤
    │
  0 ┼─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────> TTFT (ms)
    0    100   200   300   400   500   600   700

TTFT 的三个组成部分：
┌───────────────────────────────────────────────────────────────┐
│                                                               │
│  TTFT = T_queue + T_schedule + T_prefill                      │
│                                                               │
│  T_queue: 请求在 waiting 队列中等待的时间                     │
│    取决于：前面的请求数、调度策略、KV cache 可用性            │
│    低负载：<10ms；高负载：可能 >500ms                         │
│                                                               │
│  T_schedule: 调度器处理时间                                   │
│    通常 < 1ms（纯 CPU 逻辑）                                  │
│                                                               │
│  T_prefill: 实际的 prefill 计算时间                           │
│    取决于：prompt 长度、chunk size、batch 中的其他请求        │
│    估算：prompt_tokens × per_token_latency × chunk_factor     │
│    512 tokens: ~15ms；4096 tokens: ~120ms                     │
│                                                               │
└───────────────────────────────────────────────────────────────┘

长尾分析：
  P99 TTFT 通常远高于 P50，原因是：
  1. 队列堆积：等待前面多个长 prompt 完成
  2. 显存竞争：需要等待其他请求释放 KV cache
  3. 抢占恢复：被抢占的请求恢复时需要额外时间

改善长尾的方法：
  - 减小 max_num_batched_tokens（更频繁轮转）
  - 启用 chunked prefill（更公平）
  - 提高 max_num_seqs（减少排队）
  - 使用 prefix caching（减少 prefill 量）
```

### 7.4 内存利用率追踪

```
KV Cache 显存使用追踪（33B 模型，A100 80GB，block_size=16）：

┌────────────────────────────────────────────────────────────────────┐
│                         GPU 显存布局 (80GB)                        │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ████████████████ 模型参数: ~66GB (33B × 2 bytes FP16)             │
│                                                                    │
│  ░░░░░░ KV Cache 已用: ~10GB (2560 blocks of 4MB each)            │
│    每个 block 存储 16 个 token 的 KV cache                        │
│    总 block 数: ~3584 (约 14GB 预留 KV cache)                     │
│    使用率: 2560 / 3584 = 71.4%                                    │
│                                                                    │
│  ░░░░░░ KV Cache 空闲: ~4GB (1024 blocks)                         │
│                                                                    │
│  ░░░░░░ 其他 (CUDA context, workspace): ~2GB                       │
│                                                                    │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  PagedAttention Block 分配示例:                                    │
│                                                                    │
│  ReqA (prompt=512, decode=200):                                   │
│    Blocks: [0,1,2,...,31] [100,101,...,112]                       │
│    512/16 + 200/16 = 32 + 13 = 45 blocks                          │
│    物理 blocks 可以不连续！（PagedAttention 核心优势）            │
│                                                                    │
│  ReqB (prompt=128, decode=50):                                    │
│    Blocks: [50,51,...,57] [200,201,202,203]                       │
│    128/16 + 50/16 = 8 + 4 = 12 blocks                             │
│                                                                    │
│  碎片情况:                                                        │
│    空洞: [45], [58], [62] → 3 个单 block 空洞                     │
│    碎片率: 3/2560 = 0.1%（PagedAttention 碎片率极低）             │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

关键内存指标：

  gpu_cache_usage_perc = (used_blocks / total_blocks) × 100%
    正常范围：60%-85%
    危险范围：>90%（即将触发抢占）

  num_requests_waiting：等待队列长度
    正常：0-10
    注意：>20（可能需要扩容或调参）

  num_requests_swapped：被抢占换出的请求数
    正常：0
    警告：>0（有请求被抢占，体验受影响）
```

---

## 8. 实战调优指南

### 8.1 核心参数一览

```
vLLM Continuous Batching 核心调优参数：

┌────────────────────────────┬──────────────┬─────────────────────────────────┐
│  参数                       │  默认值       │  调优建议                        │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  max_num_seqs              │  256         │  33B: 32-64; 67B: 16-32          │
│                            │              │  从保守值开始，监控 GPU 显存     │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  max_num_batched_tokens    │  2048-8192   │  RAG 长 prompt: 8192+           │
│                            │              │  对话场景短 prompt: 4096          │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  max_paddings              │  256         │  通常不需要改                     │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  enable_chunked_prefill    │  False       │  生产环境强烈建议 True            │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  max_num_prefills          │  max_num_seqs│  Chunked prefill 时限制 prefill   │
│                            │              │  chunk 数，防止 decode 饿死       │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  block_size                │  16          │  通常不需要改，大模型可尝试 32    │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  swap_space                │  4 (GB)      │  如果启用 swap 抢占，建议 16-32GB │
├────────────────────────────┼──────────────┼─────────────────────────────────┤
│  gpu_memory_utilization    │  0.90        │  留 10% buffer 防止 OOM          │
│                            │              │  激进可调至 0.95                 │
└────────────────────────────┴──────────────┴─────────────────────────────────┘
```

### 8.2 逐步调优流程

```
Continuous Batching 调优 SOP（标准操作流程）：

第 1 步：确定基线配置
─────────────────────────────────────────────────────────────
根据部署的模型大小确定初始参数：

  33B 模型 + A100 80GB:
    max_num_seqs = 32
    max_num_batched_tokens = 4096
    gpu_memory_utilization = 0.90
    enable_chunked_prefill = True

  67B 模型 + A100 80GB:
    max_num_seqs = 16
    max_num_batched_tokens = 4096
    gpu_memory_utilization = 0.85  ← 67B 需要更多显存余量
    enable_chunked_prefill = True

  67B 模型 + 双 A100 80GB (Tensor Parallel):
    max_num_seqs = 32
    max_num_batched_tokens = 8192
    gpu_memory_utilization = 0.90
    enable_chunked_prefill = True

第 2 步：加载测试（Benchmark）
─────────────────────────────────────────────────────────────
使用 vLLM 自带的 benchmark 工具或自己构建负载：

  # 使用 vLLM benchmark_serving.py
  python benchmarks/benchmark_serving.py \
      --backend vllm \
      --model /path/to/model \
      --dataset-name sharegpt \
      --dataset-path /path/to/ShareGPT_V3_unfiltered_cleaned_split.json \
      --num-prompts 1000 \
      --request-rate 4  # 从 4 req/s 开始，逐步增加

  观察指标：
    - TTFT (P50, P95, P99)
    - TPOT (P50, P95, P99)  ← inter-token latency
    - Throughput (tokens/s)
    - GPU 利用率 (nvidia-smi dmon)
    - vllm:num_requests_waiting

第 3 步：增大并发度
─────────────────────────────────────────────────────────────
逐步增加 max_num_seqs，观察吞吐提升和延迟变化：

  max_num_seqs = 32 → 吞吐观察 → 延迟 OK →
  max_num_seqs = 48 → 吞吐观察 → 延迟 OK →
  max_num_seqs = 64 → 吞吐观察 → 延迟恶化或 OOM → 回退到 48

  每次调整后跑一轮 benchmark，记录数据：

  ┌──────────────┬────────────┬──────────┬──────────┬──────────┐
  │ max_num_seqs │ Throughput │ TTFT P95 │ TPOT P95 │ GPU Mem% │
  ├──────────────┼────────────┼──────────┼──────────┼──────────┤
  │ 16           │ 1200 t/s   │ 180ms    │ 45ms     │ 62%      │
  │ 32           │ 2100 t/s   │ 220ms    │ 52ms     │ 78%      │
  │ 48           │ 2800 t/s   │ 350ms    │ 68ms     │ 89%      │
  │ 64           │ 2600 t/s   │ 800ms    │ 120ms    │ 94% (OOM风险)│
  │ → 最优: 48   │            │          │          │          │
  └──────────────┴────────────┴──────────┴──────────┴──────────┘

第 4 步：调整 Token Budget
─────────────────────────────────────────────────────────────
根据 prompt 长度分布调整 max_num_batched_tokens：

  如果大部分 prompt < 2048 tokens:
    max_num_batched_tokens = 4096  ← 覆盖大部分场景

  如果有 RAG 长 prompt (4096+ tokens):
    max_num_batched_tokens = 8192  ← 给长 prompt 空间
    同时确保 enable_chunked_prefill = True ← 防止长 prompt 垄断

  如果 prompt 极长 (>16384 tokens):
    max_num_batched_tokens = 16384
    enable_chunked_prefill = True

    但注意：过大的 max_num_batched_tokens 会导致单次迭代延迟过高
    这意味着 decode 请求的 TPOT 会增加（等待本次迭代完成）

第 5 步：Chunked Prefill 微调
─────────────────────────────────────────────────────────────
确认 chunked prefill 已启用，观察 TPOT 分布：

  如果 TPOT P99 仍然有尖刺（>200ms）：
    → 减小 chunk size（减小 max_num_batched_tokens）
    → 或减小 max_num_prefills（限制每轮 prefill chunk 数）

  如果 TTFT 过高（P95 > 500ms）：
    → 增大 chunk size（增大 max_num_batched_tokens）
    → 或增大 max_num_prefills

第 6 步：长期压测验证
─────────────────────────────────────────────────────────────
使用真实流量模型进行长期压测（>1小时）：

  关键检查点：
  □ GPU 显存是否持续增长（内存泄漏？）
  □ waiting 队列是否无限增长（无法处理负载？）
  □ swapped 请求数是否周期性增加（显存压力？）
  □ P99 延迟是否随时间恶化
```

### 8.3 监控指标

```python
# 在 vLLM 部署中收集关键 Continuous Batching 指标
# 可以用 vLLM 的 /metrics 端点 (Prometheus format)

关键 Prometheus 指标：

# 1. 请求队列状态
vllm:num_requests_running       # 当前正在执行的请求数
vllm:num_requests_waiting       # 等待调度的请求数
vllm:num_requests_swapped       # 被抢占换出的请求数
vllm:num_requests_finished      # 累计完成的请求数

# 2. GPU 显存状态
vllm:gpu_cache_usage_perc        # KV cache 使用率 (0-100)
vllm:gpu_prefix_cache_queries    # Prefix cache 命中/查询（可选）

# 3. 延迟
vllm:time_to_first_token_seconds  # TTFT 直方图
vllm:time_per_output_token_seconds # TPOT 直方图
vllm:e2e_request_latency_seconds  # 端到端延迟直方图

# 4. 吞吐
vllm:request_success_total       # 成功请求计数
vllm:generation_tokens_total     # 生成 token 总数
vllm:prompt_tokens_total         # prompt token 总数

# 5. 调度器详情
vllm:num_preemptions_total       # 抢占次数

# 告警规则示例（Prometheus alert rules）：
groups:
  - name: vllm_alerts
    rules:
      - alert: HighWaitingQueue
        expr: vllm:num_requests_waiting > 20
        for: 5m
        annotations:
          summary: "vLLM 等待队列过长 ({{ $value }} 个请求)"

      - alert: HighGPUCacheUsage
        expr: vllm:gpu_cache_usage_perc > 90
        for: 1m
        annotations:
          summary: "vLLM GPU KV cache 使用率过高 ({{ $value }}%)"

      - alert: RequestsSwapped
        expr: vllm:num_requests_swapped > 0
        for: 1m
        annotations:
          summary: "vLLM 有 {{ $value }} 个请求被抢占换出"
```

### 8.4 对接 Claude Code / RAG 的特殊考虑

```
对接 Claude Code 时的调优要点：

Claude Code 的工作流特点：
  1. 工具调用频繁：每个 tool call 触发新的推理请求
  2. 流式输出依赖：SSE 事件流必须稳定（TPOT 不能有尖刺）
  3. 上下文不断增长：对话历史累积 → prompt 越来越长
  4. 突发请求：用户操作可能同时触发多个 tool call

对应的 Continuous Batching 调优：
┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│  1. 启用 Chunked Prefill（必须！）                               │
│     → 防止长上下文请求导致 TPOT 尖刺                             │
│                                                                  │
│  2. 保守的 max_num_batched_tokens                                │
│     → 保证每次迭代延迟可控（50-100ms）                           │
│     → 对于 2000 tokens/秒的流式输出，100ms 迭代 = 200 token      │
│     → 足够流畅                                                     │
│                                                                  │
│  3. Prefix Caching（强烈建议）                                   │
│     → Claude Code 的系统提示词通常固定                           │
│     → 相同的 prefix 只需要 prefill 一次                         │
│     → 大幅降低 TTFT                                               │
│                                                                  │
│  4. 足够大的 max_num_seqs                                       │
│     → 支持 multiple concurrent tool calls                       │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

vLLM 配置示例（对接 Claude Code 的 33B 模型后端）：

  python -m vllm.entrypoints.openai.api_server \
      --model /models/33b-chat \
      --tensor-parallel-size 1 \
      --max-model-len 32768 \
      --max-num-seqs 48 \
      --max-num-batched-tokens 8192 \
      --enable-chunked-prefill \
      --enable-prefix-caching \
      --gpu-memory-utilization 0.90 \
      --host 0.0.0.0 \
      --port 8000

对接 RAG 时的调优要点：

  RAG 工作流特点：
    1. Prompt 长：检索到的文档 + 用户查询 → 通常 2K-8K tokens
    2. 请求间 prompt prefix 相似（系统提示 + 检索指令相同）
    3. 延迟敏感：RAG 一般在对话系统中，用户等待时间有限

  RAG 调优重点：
    - Prefix Caching：利用共享 prefix，配合 --enable-prefix-caching
    - 大 max_num_batched_tokens（8192-16384）：处理长 prompt
    - 启用 Chunked Prefill：防止长 RAG prompt 阻塞其他请求
    - 适当降低 max_num_seqs：长 prompt 占用更多 KV cache

  vLLM 配置示例（RAG 场景，67B 模型，双卡）：

    python -m vllm.entrypoints.openai.api_server \
        --model /models/67b-rag \
        --tensor-parallel-size 2 \
        --max-model-len 32768 \
        --max-num-seqs 24 \
        --max-num-batched-tokens 8192 \
        --enable-chunked-prefill \
        --enable-prefix-caching \
        --gpu-memory-utilization 0.85 \
        --swap-space 16 \
        --host 0.0.0.0 \
        --port 8000
```

### 8.5 常见问题排查

```
问题 1: TTFT 突然飙升
─────────────────────────────────────────────────────────────
症状：之前 P50 TTFT 150ms，突然变成 500ms+

排查步骤：
  1. 检查 vllm:num_requests_waiting → 是否堆积
     → 如果是：增加 max_num_seqs 或扩容
  2. 检查 vllm:gpu_cache_usage_perc → 是否 > 90%
     → 如果是：减少 max_num_seqs 或增大 swap_space
  3. 检查是否有异常长 prompt
     → vllm:prompt_tokens_total 的 histogram 看分布
  4. 是否关闭了 chunked prefill
     → 一个 8192 token 的 prompt 导致调度停顿

问题 2: TPOT 尖刺
─────────────────────────────────────────────────────────────
症状：P50 TPOT 30ms，P99 TPOT 300ms+

排查步骤：
  1. 检查 enable_chunked_prefill 是否启用
     → 未启用 → 长 prefill 导致 decode 等待
  2. 检查 max_num_batched_tokens 是否过大
     → 过大的 budget → 长 prefill chunk → decode 等待
  3. 检查是否有抢占发生（vllm:num_preemptions_total）
     → 抢占导致额外的 swap/recompute 延迟

问题 3: 吞吐下降
─────────────────────────────────────────────────────────────
症状：之前 2500 t/s，现在变成 1500 t/s

排查步骤：
  1. 检查 batch size（vllm:num_requests_running）
     → 是否所有请求都是小 batch 的 decode（利用率下降的正常现象）
  2. 检查 GPU 利用率
     → 如果 GPU 利用率低 → 请求到达率不足，不是 vLLM 的问题
  3. 检查是否有大量抢占
     → 减少 max_num_seqs 或增大 swap_space
  4. 检查 prompt 分布是否变化
     → 大量短 prompt 导致 decode 占比高 → memory-bound → 利用率"看似"低

问题 4: OOM
─────────────────────────────────────────────────────────────
症状：CUDA out of memory

排查步骤：
  1. 减少 max_num_seqs
  2. 减少 max_model_len
  3. 减少 gpu_memory_utilization（如 0.85）
  4. 检查是否有其他进程占用 GPU 显存（nvidia-smi）
  5. 如果启用了 prefix caching → 也需要显存 → 可能需要减少 gpu_memory_utilization
```

---

## 9. 易混淆技术辨析

在学习和实践中，以下技术概念经常被混淆。厘清它们的区别对于正确选型和调优至关重要。

### 9.1 Static Batching vs Dynamic Batching vs Continuous Batching

这是三个不同时代的批处理技术，层层递进。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        三种批处理技术对比                                      │
├────────────────┬──────────────────┬──────────────────┬───────────────────────┤
│      特性       │  Static Batching  │ Dynamic Batching  │ Continuous Batching  │
├────────────────┼──────────────────┼──────────────────┼───────────────────────┤
│  粒度           │  整批请求         │  整批请求          │  单次迭代             │
│  请求进出时机    │  整批一起进出     │  整批一起进出      │  每次迭代可进出       │
│  已完成请求      │  必须等全批完成   │  必须等全批完成    │  立即退出             │
│  GPU 利用率      │  40-55%          │  50-65%           │  85-95%              │
│  复杂度          │  低              │  中               │  高                   │
│  代表框架        │  TF Serving      │  Triton (动态组批) │  vLLM, SGLang        │
│  核心思想        │  攒够一批→一起跑  │  攒够一批→一起跑   │  每步都是一个新 batch │
│                 │                  │  (动态调整batch大小)│                       │
└────────────────┴──────────────────┴──────────────────┴───────────────────────┘
```

**关键区别**：
- **Static Batching**：batch 固定，请求数量固定，所有请求必须同时完成。最短板的请求拖慢整个 batch。
- **Dynamic Batching**：batch 大小可以动态变化，但依然是一批请求一起开始、一起结束。Triton Inference Server 支持这种模式，通过动态组批（dynamic batching）把相近时间到达的请求编组。比静态好，但依然有"等最慢请求"的问题。
- **Continuous Batching**：打破了"一批一起完成"的范式。每次迭代（forward pass）都是一个新的 batch，请求可以随时加入和退出。这是 vLLM 和 SGLang 的核心创新之一，也是目前生产环境的标准做法。

**误区**：有人把 Dynamic Batching 等同于 Continuous Batching。其实 Dynamic Batching 只是 Static Batching 的"batch 大小可调"版本，依然是 batch-level 调度；Continuous Batching 是 iteration-level 调度。两者有本质区别。

### 9.2 Chunked Prefill vs Full Prefill

这是 prefill 阶段的两种执行策略，直接影响 TPOT 的稳定性。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Chunked Prefill vs Full Prefill                            │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │      Full Prefill           │     Chunked Prefill        │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  执行方式           │  一次性处理全部 prompt tokens│  分多次迭代处理，每次一个 chunk│
│  单次迭代延迟        │  高（长prompt可能>300ms）    │  可控（通常50-100ms）        │
│  对Decode的影响      │  长prefill期间decode暂停     │  decode穿插执行，不中断      │
│  TPOT 稳定性        │  差：长prefill造成TPOT尖刺   │  好：TPOT保持平滑            │
│  TTFT               │  短（一次性完成）             │  长（需要等多次迭代）         │
│  适用场景           │  离线批处理、对延迟不敏感      │  在线服务、流式输出          │
│  配置方式           │  不启用chunked prefill       │  --enable-chunked-prefill   │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**核心权衡**：Chunked Prefill 用略微增加的 TTFT（长 prompt 需要等待多个 chunk 完成），换取大幅改善的 TPOT 稳定性（decode 请求不再被长 prefill 阻塞）。在生产环境中，TPOT 的稳定性通常比 TTFT 的绝对值更重要——用户能接受多等 100ms 拿到第一个 token，但不能接受输出过程中频繁卡顿。

**实践建议**：
- 在线对话/流式服务：**必须启用** Chunked Prefill，chunk_size = max_num_batched_tokens / 4。
- 离线批处理（如评测、数据合成）：可以关闭 Chunked Prefill 以最大化吞吐。
- RAG 场景：必须启用，因为检索到的文档长度不可控，一次长文档的 Full Prefill 可能让所有在线用户感知到卡顿。

### 9.3 Swap vs Recompute Preemption

当 GPU 显存不足时，调度器需要"抢占"一些正在运行的请求。两种策略各有适用场景。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Swap vs Recompute Preemption                             │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │     Swap（换出）             │   Recompute（重算）         │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  原理              │  将KV Cache从GPU拷贝到CPU     │  直接丢弃KV Cache            │
│  计算进度           │  保留（已生成的token不丢失）   │  丢弃（需要重新prefill）      │
│  恢复方式           │  从CPU拷贝回GPU（纯数据传输）  │  重新执行prefill（需计算）    │
│  GPU显存释放         │  释放GPU block              │  释放GPU block              │
│  CPU内存需求         │  需要（等量CPU pin memory）   │  不需要                     │
│  恢复延迟           │  取决于PCIe带宽（~125ms/2GB） │  取决于prefill速度            │
│  何时更优           │  已decode超过256 tokens时    │  decode很少、或prompt很短时   │
│  风险               │  CPU内存也可能不足            │  丢失已计算的decode tokens   │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**决策逻辑（vLLM 默认行为）**：
```
已 decode token 数 > 256  →  Swap（保留计算进度，避免重算浪费）
已 decode token 数 ≤ 256  →  Recompute（丢弃便宜的计算，重新 prefill 成本不高）
CPU 内存不足               →  强制 Recompute（没得选）
```

**实践案例**：
- 一个请求 prompt=4096 tokens、已 decode=500 tokens，需要抢占 → **Swap**（重算 500 tokens 的 decode 代价约 15 秒，而 swap 只需约 200ms 的数据传输）。
- 一个请求 prompt=128 tokens、已 decode=5 tokens，需要抢占 → **Recompute**（重算代价约 150ms，swap 反而多此一举且占用 CPU 内存）。
- 阈值 256 是经验值，可在长 prompt 场景下调低（如 128），在短 prompt 场景下可调高（如 512）。

---

## 10. AI Infra 专家视角

### 10.1 性能瓶颈排查：三层决策树

当 vLLM 推理服务出现性能问题时，按以下决策树逐层排查。

**第一层：显存瓶颈（最常见）**

```
症状：
  - CUDA out of memory
  - vllm:gpu_cache_usage_perc 持续 > 95%
  - vllm:num_requests_swapped > 0（发生抢占）

排查路径：
  1. nvidia-smi 确认 GPU 显存使用情况
     → 模型权重是否过大？检查 --tensor-parallel-size 是否正确
  2. curl localhost:8000/metrics | grep gpu_cache_usage_perc
     → 如果 > 90%，KV Cache 是瓶颈
  3. 确认 max-model-len 设置
     → 是否远大于实际请求的平均长度？如果是，降低到实际需求的 1.2-1.5 倍
  4. 确认 max_num_seqs 设置
     → 并发请求数是否超出了 KV Cache 容量？

解决方案（按优先级排序）：
  a) 降低 --gpu-memory-utilization（如 0.85→0.80）
  b) 降低 --max-model-len（如 32768→16384）
  c) 降低 --max-num-seqs（如 64→32）
  d) 启用 FP8 KV Cache：--kv-cache-dtype fp8（A800/H800 可用）
  e) 增加 --swap-space（如 4→16 GB）
  f) 增加 GPU 数量（Tensor Parallel）
```

**第二层：调度瓶颈（显存充足但延迟高）**

```
症状：
  - TTFT P95 远高于 P50（如 P50=150ms, P95=800ms）
  - TPOT P99 有明显尖刺（>200ms）
  - vllm:num_requests_waiting 持续 > 10

排查路径：
  1. 检查是否启用了 --enable-chunked-prefill
     → 如果未启用，长 prompt 会导致 decode 暂停，造成 TPOT 尖刺
  2. 检查 max_num_batched_tokens 是否过大
     → 过大导致单次迭代耗时过长，decode 请求等待时间增加
  3. 检查 max_num_seqs 是否足够
     → 如果 waiting 队列长期非空，说明并发上限太低
  4. 检查是否有大量请求同时到达
     → prefill 瞬间爆发，临时超出 token budget

解决方案：
  a) 启用 --enable-chunked-prefill（必须！）
  b) 降低 max_num_batched_tokens（如 8192→4096）
  c) 增大 max_num_seqs（需确认显存充足）
  d) 设置请求速率限制（在网关层限流）
```

**第三层：计算瓶颈（显存和调度都正常但吞吐不够）**

```
症状：
  - GPU 利用率（nvidia-smi）持续 < 70%
  - 吞吐量（tokens/s）低于预期
  - vllm:num_requests_running 始终较低

排查路径：
  1. 确认请求到达率是否足够
     → 如果请求本身就不多，GPU 低利用率是正常的
  2. 检查是否都是 decode 阶段（memory-bound）
     → memory-bound 下 GPU 利用率"看似"低是正常的
     → 这是 Roofline 模型的限制，不表示浪费
  3. 检查 prompt 长度分布
     → 如果大量短 prompt，batch 中的有效计算占比低

解决方案：
  a) 增大 max_num_seqs（更多并发请求 → 更大 decode batch → 更高吞吐）
  b) 启用 Prefix Caching（--enable-prefix-caching）减少重复 prefill
  c) 考虑 Speculative Decoding（投机解码）降低 decode 延迟
  d) 对于 compute-bound 场景，考虑 Prefill-Decode Disaggregation
```

### 10.2 A800 部署实操：Qwen-33B 双卡方案

以下是一个完整的生产级部署案例，基于 2xA800-80G NVLink 运行 Qwen-33B（或同类 33B 模型，如 Yi-34B、DeepSeek-Coder-33B）。

**硬件环境**：
- GPU: 2x A800-80G SXM（NVLink 互联，400 GB/s）
- CPU: 512 GB RAM
- PCIe: Gen4 x16

**部署配置**：

```bash
# ==============================================================
# Qwen-33B on 2xA800-80G 生产级部署配置
# ==============================================================

python -m vllm.entrypoints.openai.api_server \
    --model /models/Qwen-33B-Chat \
    --tensor-parallel-size 2 \
    --dtype bfloat16 \
    \
    # ---- 连续批处理核心参数 ---- \
    --max-num-seqs 64 \
    --max-num-batched-tokens 8192 \
    --enable-chunked-prefill \
    --max-num-prefills 16 \
    \
    # ---- 显存管理 ---- \
    --max-model-len 32768 \
    --gpu-memory-utilization 0.90 \
    --swap-space 16 \
    \
    # ---- KV Cache 优化 ---- \
    --enable-prefix-caching \
    --block-size 16 \
    \
    # ---- 服务配置 ---- \
    --host 0.0.0.0 \
    --port 8000 \
    --enable-metrics
```

**显存预算（每卡）**：

```
┌──────────────────────────────────────────────────────────────┐
│              2xA800-80G 部署 Qwen-33B 显存预算                 │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  每卡总显存:      80 GB                                       │
│  TP=2 后模型权重:  33B × 2 bytes / 2 = 33 GB/卡               │
│  CUDA Context:    ~2 GB                                       │
│  KV Cache 可用:   80 × 0.90 - 33 - 2 = 37 GB/卡              │
│                                                              │
│  block_size=16 下单个 block = 16 × 8(KV头) × 128 × 2(bytes)  │
│                              × 2(K+V) × 60(layers)           │
│                            ≈ 0.98 MB ≈ 1 MB                  │
│                                                              │
│  总 block 数 (每卡): 37 GB / 1 MB ≈ 37,000 blocks            │
│                                                              │
│  每请求 4096 tokens: ceil(4096/16)=256 blocks ≈ 256 MB        │
│  最大并发请求数（理论）: 37,000/256 ≈ 144 个                   │
│  max_num_seqs=64（实际保守设置，留有余量）                      │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**预期性能指标**：

```
┌──────────────────────────────────────────────────────────────┐
│            Qwen-33B on 2xA800-80G 预期性能                     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  基准场景：请求 prompt 平均 2048 tokens, 输出 256 tokens       │
│  并发请求数: 32                                               │
│                                                              │
│  Prefill 吞吐:   ~8000 tokens/s                               │
│  Decode 延迟:    ~25-35 ms/token                              │
│  TTFT P50:       ~120ms (prompt=2048)                         │
│  TTFT P95:       ~250ms                                       │
│  TPOT P50:       ~30ms                                        │
│  TPOT P99:       ~60ms (chunked prefill 控制尖刺)              │
│  总吞吐:          ~2500-3000 tokens/s                         │
│                                                              │
│  GPU 利用率:     85-95%                                       │
│  KV Cache 使用率: 60-80%（常规负载）                            │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**调优过程中的关键决策记录**：

1. **为什么 TP=2 而不是 TP=1**？Qwen-33B 的 FP16 权重约 66GB，单张 A800-80G 可以放下，但几乎没有空间留给 KV Cache。TP=2 后每卡约 33GB 权重，剩余约 37GB 给 KV Cache。如果坚持单卡部署，需使用 INT4 量化权重。

2. **为什么 max_num_seqs=64 而不是默认的 256**？33B 模型在 2xA800 上的 KV Cache 预算约为 74GB（两张卡合计），每个请求（prompt=2048+output=256）约需 256MB × 2 = 512MB，理论最大并发约 144。设为 64 是保守值，防止在长 prompt 场景下 OOM。如果你的 prompt 分布以短请求为主（平均 < 1024 tokens），可以增大到 96-128。

3. **为什么 max_num_batched_tokens=8192**？这是 2xA800 下的平衡值。4096 太保守（长 prompt 需要太多 chunk），16384 风险大（单次迭代延迟高）。8192 保证了 4096 token 的 prompt 在 2 次 chunk 内完成，同时 64 个 decode 请求仅消耗 64/8192=0.8% budget。

4. **为什么 block_size=16（默认）不调整**？block_size=16 是经过大量实验验证的 sweet spot。改为 32 虽然减少了 block table 查找开销（性能提升约 3-5%），但增大了内部碎片（每个请求平均多浪费 8 个 token slot）。对于生产环境的混合负载，16 是更安全的选择。

**启动后的验证步骤**：

```bash
# 1. 确认服务正常启动
curl http://localhost:8000/health

# 2. 发一个简单请求测试
curl http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen-33B-Chat",
    "prompt": "请用一句话介绍你自己",
    "max_tokens": 50
  }'

# 3. 检查 KV Cache 预分配情况
curl http://localhost:8000/metrics | grep -E "gpu_cache_usage_perc|gpu_blocks"

# 4. 使用 benchmark 工具做压测
python benchmarks/benchmark_serving.py \
    --backend vllm \
    --model /models/Qwen-33B-Chat \
    --dataset-name sharegpt \
    --dataset-path ./ShareGPT_V3_unfiltered_cleaned_split.json \
    --num-prompts 500 \
    --request-rate 8

# 5. 监控 GPU 状态（另一个终端）
watch -n 1 nvidia-smi

# 6. 监控 vLLM 指标
watch -n 1 'curl -s localhost:8000/metrics | grep -E "num_requests|cache_usage"'
```

**常见问题及解决方案**：

```
问题: OOM 在启动时就发生
  → 降低 --gpu-memory-utilization 到 0.85
  → 降低 --max-model-len 到 16384
  → 确认没有其他进程占用 GPU 显存

问题: 启动成功但并发上不去
  → 检查 --max-num-seqs 是否太小
  → 检查 client 端的连接数限制

问题: TPOT 有明显尖刺（>200ms）
  → 确认 --enable-chunked-prefill 已启用
  → 降低 --max-num-batched-tokens 到 4096
  → 降低 --max-num-prefills 到 8

问题: 吞吐量低于预期
  → 增加并发请求数（压力不够）
  → 检查 prompt 长度分布（如果都是短 prompt，decode 占比高，memory-bound 限制吞吐）
  → 考虑启用 --enable-prefix-caching
```

---

## 11. 深入学习资源

### 11.1 核心论文

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           必读论文                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ 1. Orca: A Distributed Serving System for Transformer-Based                 │
│    Generative Models                                                        │
│    (OSDI 2022) - 连续批处理的原创论文                                       │
│    作者: Yu et al., Seoul National University                               │
│    https://www.usenix.org/conference/osdi22/presentation/yu                 │
│    要点: 首次提出 iteration-level scheduling，展示了从 50% → 90%+ 的       │
│          利用率提升。FCFS + prefill priority 策略。                         │
│                                                                             │
│ 2. Efficient Memory Management for Large Language Model                     │
│    Serving with PagedAttention                                               │
│    (SOSP 2023) - vLLM 论文                                                  │
│    作者: Kwon et al., UC Berkeley                                           │
│    https://arxiv.org/abs/2309.06180                                        │
│    要点: PagedAttention 如何使能高效的 continuous batching。                │
│          虚拟内存启发的 KV cache 管理。                                     │
│                                                                             │
│ 3. Splitwise: Efficient Generative LLM Inference Using Phase                │
│    Splitting                                                                 │
│    (ISCA 2024)                                                               │
│    作者: Patel et al., Harvard / Georgia Tech                                │
│    要点: 将 prefill 和 decode 分离到不同的 GPU 上执行。                    │
│          解决 prefill compute-bound 和 decode memory-bound 的矛盾。        │
│                                                                             │
│ 4. Sarathi-Serve: A Serving Framework Leveraging Prefill-Decode             │
│    Disaggregation for LLM Inference                                         │
│    (2024)                                                                    │
│    作者: Agrawal et al., Microsoft Research                                  │
│    要点: chunked prefill 的正式分析与系统化实现。                           │
│          提出了 stall-free scheduling 的概念。                             │
│                                                                             │
│ 5. Taming Throughput-Latency Tradeoff in LLM Inference with                 │
│    Sarathi-Serve                                                             │
│    (OSDI 2024)                                                               │
│    要点: 深入分析 prefill-decode interference，以及 chunked prefill         │
│          如何消除 TPOT 尖刺。                                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 11.2 开源项目与代码参考

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      关键源码参考                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ vLLM Scheduler                                                              │
│ https://github.com/vllm-project/vllm/blob/main/vllm/core/scheduler.py      │
│ 这是 continuous batching 调度器的核心实现。重点阅读：                       │
│   - Scheduler.schedule() 方法（主调度循环）                                 │
│   - _schedule_prefills() 方法（prefill 调度 + chunked prefill）             │
│   - _schedule_decodes() 方法（decode 调度）                                 │
│   - _preempt() 方法（抢占逻辑）                                             │
│                                                                             │
│ vLLM Block Manager                                                          │
│ https://github.com/vllm-project/vllm/blob/main/vllm/core/block_manager.py  │
│ PagedAttention 的 KV cache block 管理。                                     │
│   - BlockSpaceManager.can_allocate()（调度前检查）                          │
│   - BlockSpaceManager.allocate()（分配 blocks）                             │
│   - BlockSpaceManager.free()（释放 blocks）                                 │
│   - BlockSpaceManager.swap_out() / swap_in()（抢占相关）                    │
│                                                                             │
│ vLLM Sequence Management                                                    │
│ https://github.com/vllm-project/vllm/blob/main/vllm/core/block_manager_v1.py│
│ https://github.com/vllm-project/vllm/blob/main/vllm/core/block_manager_v2.py│
│ 两个版本的 block manager：v1（基础）和 v2（支持 prefix caching）。         │
│                                                                             │
│ SGLang                                                                      │
│ https://github.com/sgl-project/sglang                                       │
│ 另一个支持 continuous batching 的推理框架，与 vLLM 有不同设计选择：        │
│   - RadixAttention（基于前缀树的注意力管理）                                │
│   - 不同调度策略的性能对比                                                  │
│                                                                             │
│ TensorRT-LLM                                                                │
│ https://github.com/NVIDIA/TensorRT-LLM                                      │
│ NVIDIA 的官方推理框架，有 in-flight batching（连续批处理）实现。           │
│ 源码位置: cpp/include/tensorrt_llm/batch_manager/                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 11.3 博客文章与视频

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    推荐阅读 / 观看                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ 博客:                                                                       │
│ ● "How continuous batching enables 23x throughput in LLM inference          │
│    while reducing p50 latency"                                              │
│    https://www.anyscale.com/blog/continuous-batching-llm-inference          │
│    通俗易懂的入门，有生动的动画和对比图。                                   │
│                                                                             │
│ ● "vLLM: PagedAttention for Efficient LLM Serving"                          │
│    https://blog.vllm.ai/2023/06/20/vllm.html                               │
│    vLLM 官方博客，讲 PagedAttention 和 continuous batching 如何配合。       │
│                                                                             │
│ ● "Mastering LLM Inference Performance: Batching, Scheduling, and Memory"   │
│    https://www.databricks.com/blog/llm-inference-performance-engineering   │
│    Databricks 的实践文章，涵盖 GPU 利用率分析和调优经验。                   │
│                                                                             │
│ ● "Chunked Prefill in LLM Serving: Why and How"                             │
│    (vLLM 文档中的说明)                                                       │
│    https://docs.vllm.ai/en/latest/features/chunked_prefill.html            │
│                                                                             │
│ 视频:                                                                       │
│ ● "Efficient LLM Serving with vLLM" (vLLM 团队在 MLSys 上的 talk)          │
│    https://www.youtube.com/watch?v=MSUxq5d7YHo                             │
│                                                                             │
│ ● "Deep Dive into LLM Inference Optimization" (Anyscale)                   │
│    涵盖 batching, KV cache, quantization, scheduling 等全栈优化             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 11.4 性能基准参考

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    典型性能基准（供参考）                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ 配置: 33B 模型, A100 80GB, vLLM 0.4.0+                                     │
│                                                                             │
│ ┌──────────────────────────────┬──────────┬──────────┬──────────┐           │
│ │  场景                         │  Throughput│ TTFT P50 │ TPOT P50 │           │
│ ├──────────────────────────────┼──────────┼──────────┼──────────┤           │
│ │  静态批处理 (baseline)        │  800 t/s  │  350ms   │  80ms    │           │
│ │  连续批处理 (无 chunk)        │ 2100 t/s  │  120ms   │  45ms    │           │
│ │  连续批处理 (chunked prefill) │ 2050 t/s  │  150ms   │  40ms    │           │
│ │  连续批处理 + prefix caching  │ 2600 t/s  │   80ms   │  35ms    │           │
│ └──────────────────────────────┴──────────┴──────────┴──────────┘           │
│                                                                             │
│ 配置: 67B 模型, 2×A100 80GB (TP=2), vLLM 0.4.0+                            │
│                                                                             │
│ ┌──────────────────────────────┬──────────┬──────────┬──────────┐           │
│ │  场景                         │  Throughput│ TTFT P50 │ TPOT P50 │           │
│ ├──────────────────────────────┼──────────┼──────────┼──────────┤           │
│ │  静态批处理 (baseline)        │  400 t/s  │  600ms   │  150ms   │           │
│ │  连续批处理 (无 chunk)        │ 1200 t/s  │  200ms   │   80ms   │           │
│ │  连续批处理 (chunked prefill) │ 1150 t/s  │  250ms   │   70ms   │           │
│ │  连续批处理 + prefix caching  │ 1500 t/s  │  130ms   │   65ms   │           │
│ └──────────────────────────────┴──────────┴──────────┴──────────┘           │
│                                                                             │
│ 注意: 实际数值取决于 prompt 分布、输出长度分布、硬件配置等因素。           │
│       以上为代表性数据，用于说明相对改进量级。                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 11.5 相关概念延伸阅读

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    进一步探索                                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ● Prefix Caching（前缀缓存）                                                │
│   当多个请求共享相同前缀时（如 system prompt、few-shot examples），         │
│   只需 prefill 一次。vLLM 的 Automatic Prefix Caching (APC) 可自动检测     │
│   并复用已计算的 KV cache。搭配 continuous batching 效果倍增。             │
│                                                                             │
│ ● Speculative Decoding（投机解码）                                          │
│   使用 draft model 快速生成候选 token，target model 并行验证。              │
│   与 continuous batching 结合可在 decode 阶段大幅突破 memory-bound 限制。  │
│                                                                             │
│ ● Prefill-Decode Disaggregation（预填-解码分离）                            │
│   将 prefill 和 decode 分配到不同的 GPU：                                  │
│     - Prefill GPU: 高 compute 利用率（大 HBM 带宽）                         │
│     - Decode GPU: 高 memory 带宽利用率（大 batch size）                     │
│   这是下一代 LLM serving 架构方向。                                         │
│                                                                             │
│ ● KV Cache Quantization（KV 缓存量化）                                      │
│   对 KV cache 进行 INT8/FP8 量化，减小显存占用，                             │
│   从而在 continuous batching 中支持更大的 max_num_seqs。                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

> 文档版本: v1.0 | 适用 vLLM 版本: 0.4.0 - 0.5.x | 最后更新: 2026-07
