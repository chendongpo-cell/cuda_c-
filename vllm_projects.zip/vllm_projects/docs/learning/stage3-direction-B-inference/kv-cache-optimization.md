# KV Cache 优化深度指南

## 白话引入

想象你在解一道复杂的数学题。每做一步推理，你都会在草稿纸上记下中间结果——"第 3 步算出来 x=5"、"第 7 步得出 y=12"。当你做到第 20 步时，你不需要从头重新算 x 和 y，只需瞥一眼草稿纸上的记录就行。这个草稿纸就是 **KV Cache**——大模型在自回归生成过程中，把每一层的 Key 和 Value 缓存下来，生成下一个 token 时就不用重新计算所有历史 token 了。

但这个草稿纸有个致命问题：它会随着推理的进行越写越多。一个 33B 模型，生成 4096 个 token 时，光是草稿纸（KV Cache）就要占约 1GB 显存。如果你的 GPU 上有 32 个请求同时在做推理，草稿纸就占了 32GB——比模型权重本身还多。更糟的是，大多数请求生成的 token 数并不均匀：有些很快结束（只写了几行），有些写了几十页。传统做法是给每道题一开始就预留一整本草稿纸（max_model_len），导致大部分纸张空白——利用率只有 6%。

**KV Cache 优化**的目标就是让这张草稿纸更省空间、更高效：用压缩技巧（量化）把笔记写得更紧凑，用共享机制（前缀缓存）让做同一道题的人合用一本草稿纸，用卸载策略把暂时不用的草稿纸挪到"抽屉"（CPU 内存）里。

> 本文档为推理方向（Direction B）的核心学习材料，聚焦于 KV Cache 的工作原理、内存分析、量化压缩、前缀缓存、卸载策略以及生产环境中的监控与调试。
> 阅读本文档前，建议已完成 stage1/stage2 中关于 Transformer 架构和推理引擎基础的学习。

---

## 术语预检

KV Cache 优化涉及的概念较多，以下是核心术语速览。

| 术语 | 生活类比 | 技术定义 |
|------|---------|---------|
| **GQA（分组查询注意力）** | 一个老师（K/V）带一组学生（Q），而不是每个学生配一个老师 | Grouped Query Attention：多个 Query head 共享同一组 Key/Value head。相比 MHA（每个 Q 头独立 K/V），KV Cache 减少 group_size 倍。Llama-2-70B 用 group_size=8，KV Cache 减少到 MHA 的 1/8。 |
| **MQA（多查询注意力）** | 所有学生共用一个老师（极致的节省） | Multi-Query Attention：所有 Query head 共享唯一一组 K/V。KV Cache 最小，但模型容量有损失。PaLM 和早期 Gemini 使用 MQA。 |
| **MLA（多头潜在注意力）** | 老师不亲自上课，录了个精华短视频（压缩表示），学生看视频就行 | Multi-head Latent Attention：DeepSeek-V2 的创新。不缓存完整的 K 和 V，而是缓存压缩后的低秩潜在表示 c_KV（如 512 维），解码时再解压。压缩比约 10x。 |
| **FP8 KV Cache** | 用更细的铅笔写字（每个数只占半个格子） | 对 KV Cache 使用 FP8（8-bit 浮点）存储，每个元素仅占 1 字节（vs FP16 的 2 字节）。H100/H800 有硬件加速，精度损失 <0.1%。 |
| **Prefix Caching（前缀缓存）** | 同一份菜谱的备菜步骤只做一次，后面的人直接用 | 当多个请求共享相同前缀（如 system prompt）时，其 KV Cache 只计算和存储一次，后续请求直接复用。vLLM 通过 Radix Tree + block 哈希实现自动检测。 |
| **Attention Sink** | 解题时最初的"已知条件"必须一直留在草稿纸上，不能擦掉 | StreamingLLM 发现的注意力现象：序列开头的 4 个 token 对所有后续 token 的注意力分布影响极大，必须保留。利用这个现象可以只保留 sink token + 滑动窗口，大幅减少 KV Cache。 |

---

## 目录

1. [KV Cache 基础知识回顾](#1-kv-cache-基础知识回顾)
2. [真实模型的内存计算](#2-真实模型的内存计算)
3. [KV Cache 量化](#3-kv-cache-量化)
4. [KV Cache 压缩技术](#4-kv-cache-压缩技术)
5. [前缀缓存 (Prefix Caching)](#5-前缀缓存-prefix-caching)
6. [KV Cache 卸载](#6-kv-cache-卸载)
7. [KV Cache 感知调度](#7-kv-cache-感知调度)
8. [监控 KV Cache](#8-监控-kv-cache)
9. [调试 KV Cache 问题](#9-调试-kv-cache-问题)
10. [实践案例：33B 模型优化](#10-实践案例33b-模型优化)
11. [易混淆技术辨析](#11-易混淆技术辨析)
12. [AI Infra 专家视角](#12-ai-infra-专家视角)
13. [深入学习资源](#13-深入学习资源)

---

## 1. KV Cache 基础知识回顾

### 1.1 KV Cache 是什么？

在自回归生成（autoregressive generation）中，模型每次只生成一个 token。对于第 t 步生成，模型需要基于所有前序 token（1 到 t-1）计算 attention。如果没有 KV Cache，每一步都需要重新计算所有历史 token 的 Key 和 Value，导致计算量呈 O(n^2) 增长。

KV Cache 的核心思想是：**缓存已经计算过的 Key 和 Value，新 token 生成时只需要计算新 token 的 K/V，然后与缓存的 K/V 拼接即可。**

```
时间步 t=1（prefill 阶段）:
  Input:  [tok1, tok2, tok3, ..., tokN]
  计算:   K_all = [K1, K2, K3, ..., KN]  ← 全部计算，存入缓存
          V_all = [V1, V2, V3, ..., VN]  ← 全部计算，存入缓存

时间步 t=2（decode 阶段）:
  Input:  [tok_N+1]  (单个 token)
  计算:   K_new = [K_N+1]                      ← 只计算新 token 的 K
  拼接:   K_all = Concat([K1...KN], [K_N+1])   ← 从缓存读取历史 K
          V_all = Concat([V1...VN], [V_N+1])

时间步 t=3:
  Input:  [tok_N+2]
  K_new = [K_N+2]
  K_all = Concat([K1...KN, K_N+1], [K_N+2])
```

### 1.2 内存公式推导

对于单个 Transformer 层，KV Cache 的内存占用为：

```
KV_Cache_Size (bytes) = 2 × batch_size × num_kv_heads × head_dim × seq_len × num_layers × dtype_bytes
```

其中：
- `2`：Key + Value 各一份
- `batch_size`：同时处理的请求数
- `num_kv_heads`：KV head 的数量（GQA/MQA 下可能小于 query head 数）
- `head_dim`：每个 head 的维度
- `seq_len`：序列长度（总 token 数）
- `num_layers`：Transformer 层数
- `dtype_bytes`：数据类型字节数（FP16=2，FP32=4，INT8=1）

```
┌─────────────────────────────────────────────────────────────────┐
│                    KV Cache 内存布局（单层）                       │
│                                                                 │
│   Key Cache:   [batch, num_kv_heads, seq_len, head_dim]         │
│                 ↑                                                │
│                 随着生成过程，seq_len 维度持续增长                   │
│                                                                 │
│   Value Cache: [batch, num_kv_heads, seq_len, head_dim]         │
│                 ↑                                                │
│                 同样随着生成过程增长                               │
│                                                                 │
│   总内存 = 2 × batch × num_kv_heads × seq_len × head_dim × bytes │
└─────────────────────────────────────────────────────────────────┘
```

### 1.3 GQA（Grouped Query Attention）对 KV Cache 的影响

GQA 是减少 KV Cache 内存的关键技术。在标准 MHA 中，每个 query head 都有独立的 KV head；GQA 中多个 query head 共享一组 KV head。

```
MHA (Multi-Head Attention):        GQA (Grouped Query Attention):
                                    
  Q: ■ ■ ■ ■ ■ ■ ■ ■               Q: ■ ■ ■ ■ ■ ■ ■ ■
       │ │ │ │ │ │ │ │                  │  │  │  │
  K: ■ ■ ■ ■ ■ ■ ■ ■               K: ■  ■  ■  ■     ← KV heads 减少！
       │ │ │ │ │ │ │ │                  │  │  │  │
  V: ■ ■ ■ ■ ■ ■ ■ ■               V: ■  ■  ■  ■
                                    
  num_kv_heads = num_q_heads       num_kv_heads = num_q_heads / group_size
  KV Cache 最大                    KV Cache 减少 group_size 倍
```

以 Llama-2-70B 为例：
- 使用 GQA，num_q_heads=64, num_kv_heads=8, group_size=8
- 相比 MHA，KV Cache 减少到原来的 8/64 = 1/8

### 1.4 Prefill vs Decode 阶段的 KV Cache 行为

```
┌──────────────────────────────────────────────────────────────────┐
│                    阶段对比                                       │
├────────────────┬─────────────────────┬────────────────────────────┤
│    特性         │   Prefill 阶段       │   Decode 阶段              │
├────────────────┼─────────────────────┼────────────────────────────┤
│ 输入            │ 全部 prompt tokens   │ 单个 token                 │
│ 计算特征         │ 计算密集型           │ 内存密集型                 │
│ KV Cache 操作    │ 写入（分配+填充）     │ 追加（append 1 token）     │
│ 瓶颈            │ GPU 算力             │ GPU 显存带宽               │
│ 典型延迟         │ 100-500ms (1K tokens)│ 10-50ms / token           │
│ 批处理效率        │ 高（可并行）          │ 低（每步只有1个token）     │
└────────────────┴─────────────────────┴────────────────────────────┘
```

**关键洞察**：Decode 阶段的瓶颈不在计算，而在从显存读取 KV Cache。这解释了为什么 KV Cache 量化（减少内存带宽需求）能显著加速 decode。

---

## 2. 真实模型的内存计算

### 2.1 Qwen-7B 的 KV Cache 计算

模型参数：
- 层数 (num_layers): 32
- Query heads: 32
- KV heads: 4 (GQA, group_size=8)
- Head dim: 128
- 精度: FP16 (2 bytes)

```
单 token 单层的 KV 大小:
  = 2 (K+V) × 4 (KV heads) × 128 (head_dim) × 2 (FP16 bytes)
  = 2 × 4 × 128 × 2
  = 2048 bytes = 2 KB

全部 32 层，单 token:
  = 32 × 2048 bytes
  = 65,536 bytes = 64 KB

对于单个请求 (batch=1), 2048 token 序列:
  = 2048 × 64 KB
  = 128 MB

对于 32 个并发请求 (batch=32), 每个平均 2048 token:
  = 32 × 128 MB
  = 4096 MB = 4 GB (仅 KV Cache!)
```

```
┌───────────────────────────────────────────────────────────────┐
│         Qwen-7B 显存分解（FP16, batch=32, seq_len=2048）       │
├───────────────────────────────────────────────────────────────┤
│ 模型权重:      ~14 GB    (7B × 2 bytes)                        │
│ KV Cache:      ~4 GB     (计算如上)                            │
│ 激活值:        ~2 GB     (中间计算结果)                         │
│ 其他:          ~1 GB     (CUDA context, 内核等)                │
├───────────────────────────────────────────────────────────────┤
│ 总计:          ~21 GB                                         │
│ 单张 A800-80G: ✓ 绰绰有余                                      │
└───────────────────────────────────────────────────────────────┘
```

### 2.2 Qwen-72B 的 KV Cache 计算

模型参数：
- 层数 (num_layers): 80
- Query heads: 64
- KV heads: 8 (GQA, group_size=8)
- Head dim: 128
- 精度: FP16

```
单 token 单层的 KV 大小:
  = 2 × 8 × 128 × 2
  = 4096 bytes = 4 KB

全部 80 层，单 token:
  = 80 × 4 KB = 320 KB

单请求 4096 token:
  = 4096 × 320 KB = 1280 MB ≈ 1.25 GB
```

```
┌──────────────────────────────────────────────────────────────┐
│      Qwen-72B 显存需求分析（FP16, batch=8, seq_len=4096）      │
├──────────────────────────────────────────────────────────────┤
│ 模型权重:      ~144 GB   (72B × 2 bytes)                      │
│ KV Cache:      ~10 GB    (8 × 1.25 GB)                        │
│ 激活值:        ~5 GB                                          │
├──────────────────────────────────────────────────────────────┤
│ 总计:          ~159 GB                                        │
│ 单张 A800-80G: ✗ 放不下                                       │
│ 2×A800 (TP=2): ~79.5 GB/卡 ✗ 依然紧张                         │
│ 4×A800 (TP=4): ~39.75 GB/卡 ✓ 可行                            │
└──────────────────────────────────────────────────────────────┘
```

**结论**: Qwen-72B 至少需要 4 卡 Tensor Parallel 才能容纳模型权重 + KV Cache。这也是大模型推理必须使用分布式策略的根本原因。

### 2.3 DeepSeek-V2 的 MLA（Multi-head Latent Attention）

DeepSeek-V2 的 MLA 是对 KV Cache 的革命性优化。传统 attention 中，每层的 KV 大小为：

```
传统: KV_per_layer = 2 × num_kv_heads × head_dim × dtype_bytes
```

MLA 将 KV 压缩到一个低秩潜在空间（latent space）：

```
MLA 架构:
                                       
  h_t ──→ W_DKV ──→ c_KV (latent) ──┬──→ W_UK ──→ K (解压)
                压缩维度 d_c          │
                                     └──→ W_UV ──→ V (解压)
                 
  缓存的是 c_KV（压缩后的潜在表示），
  而不是完整的 K 和 V！
```

```
DeepSeek-V2 具体参数:
- d_model = 5120
- d_c (压缩维度) = 512
- num_heads = 128
- head_dim = 128

传统 KV 每层:
  K: 1 × 128 × 128 = 16384 元素
  V: 1 × 128 × 128 = 16384 元素
  总计: 32768 元素

MLA 每层 (只缓存 c_KV):
  c_KV: 1 × 512 = 512 元素

压缩比: 32768 / 512 = 64× (理论上)
实际压缩比: ~10× (考虑到解压投影矩阵也需要存储)
```

**MLA 的完整流程**：

```
┌──────────────────────────────────────────────────────────────────┐
│                MLA 推理流程（单层）                                │
│                                                                  │
│  Prefill 阶段:                                                   │
│    h → W_DKV × h → c_KV  [压缩, 512维]                           │
│    缓存 c_KV 到 KV Cache                                         │
│    K = W_UK × c_KV  [解压, 得到完整 K]                            │
│    V = W_UV × c_KV  [解压, 得到完整 V]                            │
│    Attention(Q, K, V)                                            │
│                                                                  │
│  Decode 阶段:                                                    │
│    从缓存读取历史 c_KV                                            │
│    新 token: h_new → c_KV_new                                    │
│    拼接: c_KV_all = [c_KV_hist, c_KV_new]                        │
│    解压: K = W_UK × c_KV_all, V = W_UV × c_KV_all                 │
│    Attention(Q, K, V)                                            │
│                                                                  │
│  关键权衡: 节省了 KV Cache 内存，但增加了每次 decode 的解压计算     │
└──────────────────────────────────────────────────────────────────┘
```

---

## 3. KV Cache 量化

### 3.1 FP8 KV Cache

FP8 是 Hopper 架构（H100/H800）原生支持的数据格式，有两种变体：

```
FP8 格式:
┌────────────────────────────────────────────────────────────┐
│  E4M3 (FP8 E4M3):  1-bit sign + 4-bit exponent + 3-bit mantissa │
│  范围: ±448, 精度: 适合前向传播                                    │
│                                                             │
│  E5M2 (FP8 E5M2):  1-bit sign + 5-bit exponent + 2-bit mantissa │
│  范围: ±57344, 精度: 适合梯度（范围更大）                           │
└────────────────────────────────────────────────────────────┘
```

**vLLM 中的 FP8 KV Cache 配置**：

```bash
# 启用 FP8 KV Cache
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --kv-cache-dtype fp8 \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.95
```

**vLLM 源码中的 FP8 KV Cache 实现**（关键代码路径）：

```python
# vllm/v1/attention/backends/flashinfer.py (简化示意)

class FlashInferBackend:
    def __init__(self, kv_cache_dtype: str):
        if kv_cache_dtype == "fp8":
            # FP8 下 KV Cache 每个元素只占 1 字节
            self.kv_cache_dtype = torch.float8_e4m3fn
            self.kv_element_size = 1  # 相比 FP16 节省 50%
```

**FP8 KV Cache 的精度影响**：

```
┌─────────────────────────────────────────────────────────────┐
│           FP16 vs FP8 KV Cache 精度对比                      │
├──────────────────┬──────────┬──────────┬────────────────────┤
│ 模型              │ FP16 PPL │ FP8 PPL  │ PPL 退化            │
├──────────────────┼──────────┼──────────┼────────────────────┤
│ Llama-2-7B       │ 5.47     │ 5.48     │ +0.01 (可忽略)      │
│ Llama-2-13B      │ 4.88     │ 4.89     │ +0.01 (可忽略)      │
│ Llama-2-70B      │ 3.32     │ 3.34     │ +0.02 (可忽略)      │
│ Qwen-72B         │ --       │ --       │ <0.1% 退化          │
└──────────────────┴──────────┴──────────┴────────────────────┘

数据来源: NVIDIA TensorRT-LLM & vLLM 社区测试
```

**何时使用 FP8 KV Cache**：

- H100/H800 集群：强烈推荐，硬件原生支持，精度损失极小
- A100/A800：可以使用，但没有硬件加速，收益主要体现在内存节省
- 长序列场景（>8K）：FP8 可翻倍最大支持的序列长度
- 高并发场景：FP8 可翻倍支持的并发请求数

### 3.2 INT8 KV Cache

INT8 量化将 KV Cache 从 16-bit 压缩到 8-bit，内存减半。

**两种 INT8 量化策略**：

```
1) Per-Tensor 量化（最粗糙）:
   整个 tensor 共用一个 scale
   KV_int8 = round(KV_fp16 / scale)
   scale = max(|KV|) / 127

2) Per-Channel 量化（中等）:
   每个 channel（head_dim 维度）独立的 scale
   scale[c] = max(|KV[:,:,:,c]|) / 127

3) Per-Token 量化（最细）:
   每个 token 独立的 scale
   scale[t] = max(|KV[:,:,t,:]|) / 127
```

```
┌──────────────────────────────────────────────────────────┐
│            量化粒度示意（以 Key Cache 为例）                │
│                                                          │
│  Key shape: [batch, num_heads, seq_len, head_dim]         │
│                                                          │
│  Per-Tensor:  一个 scale 值，全部共享                       │
│  ┌─────────────────────────┐                             │
│  │ 整个 K 矩阵              │ ← 1 个 scale                │
│  └─────────────────────────┘                             │
│                                                          │
│  Per-Channel: 每个 head_dim 通道独立 scale                  │
│  ┌──┬──┬──┬──┬──┬──┬──┬──┐                               │
│  │c0│c1│c2│c3│c4│c5│c6│c7│ ← head_dim 个 scale           │
│  └──┴──┴──┴──┴──┴──┴──┴──┘                               │
│                                                          │
│  Per-Token: 每个 token 独立 scale                          │
│  ┌─────────────────────────┐ ← token 0: scale_0          │
│  ├─────────────────────────┤ ← token 1: scale_1          │
│  ├─────────────────────────┤ ← token 2: scale_2          │
│  │         ...             │                             │
│  └─────────────────────────┘ ← token N: scale_N          │
└──────────────────────────────────────────────────────────┘
```

**INT8 KV Cache 的挑战**：

- Key 的 channel 间差异很大（某些 channel 的数值范围远超其他 channel）
- Value 的 token 间差异很大（某些 token 的 value 异常大）
- 简单的 per-tensor 量化会导致显著的精度损失

### 3.3 KIVI: Per-Channel Key + Per-Token Value 量化

KIVI (2024) 是当前最先进的 KV Cache 量化方法之一，核心洞察是 **Key 和 Value 需要不同的量化策略**：

```
KIVI 核心设计:
                                   
  Key: Per-Channel 量化             Value: Per-Token 量化
  ┌────────────────────┐           ┌────────────────────┐
  │ K[ch0]: scale_0    │           │ V[tok0]: scale_0   │
  │ K[ch1]: scale_1    │           │ V[tok1]: scale_1   │
  │ K[ch2]: scale_2    │           │ V[tok2]: scale_2   │
  │ ...                │           │ ...                │
  │ K[ch127]: scale_127│           │ V[tokN]: scale_N   │
  └────────────────────┘           └────────────────────┘

为什么这样设计？
- Key 矩阵 (seq_len × head_dim)：不同 channel 的值域差异大，
  因为 RoPE 对不同 channel 施加了不同频率的旋转
- Value 矩阵 (seq_len × head_dim)：不同 token 的值域差异大，
  因为某些 token（如分隔符、特殊词）的 value 异常大
```

**KIVI 的量化/dequant 流程**：

```python
# KIVI 量化核心逻辑（伪代码）

def kivi_quantize_key(K_fp16):
    # Per-channel 量化 Key
    # K_fp16 形状: [num_heads, seq_len, head_dim]
    scales = []
    K_int8 = []
    for c in range(head_dim):
        channel_data = K_fp16[:, :, c]
        scale = channel_data.abs().max() / 127.0
        K_int8.append(torch.round(channel_data / scale).to(torch.int8))
        scales.append(scale.item())
    return torch.stack(K_int8, dim=-1), scales

def kivi_quantize_value(V_fp16):
    # Per-token 量化 Value
    # V_fp16 形状: [num_heads, seq_len, head_dim]
    scales = []
    V_int8 = []
    for t in range(seq_len):
        token_data = V_fp16[:, t, :]
        scale = token_data.abs().max() / 127.0
        V_int8.append(torch.round(token_data / scale).to(torch.int8))
        scales.append(scale.item())
    return torch.stack(V_int8, dim=1), scales
```

**KIVI 精度表现**（LongBench 评测）：

```
┌──────────────────────────────────────────────────────────────┐
│              不同 KV Cache 量化方法的精度对比                    │
├────────────────┬──────────┬──────────┬──────────┬────────────┤
│ 方法 / 模型     │ Llama2-7B│ Llama2-13B│ Mistral-7B│ 平均退化   │
├────────────────┼──────────┼──────────┼──────────┼────────────┤
│ FP16 (baseline)│ 100%     │ 100%     │ 100%     │ 0%         │
│ INT8 per-tensor │ 95.2%   │ 94.8%   │ 96.1%   │ -4.6%      │
│ INT8 per-channel│ 98.1%   │ 97.5%   │ 98.3%   │ -2.0%      │
│ KIVI 2-bit     │ 96.8%   │ 96.2%   │ 97.0%   │ -3.3%      │
│ KIVI 4-bit     │ 99.5%   │ 99.2%   │ 99.4%   │ -0.6%      │
└────────────────┴──────────┴──────────┴──────────┴────────────┘
```

---

## 4. KV Cache 压缩技术

### 4.1 Multi-Query Attention (MQA)

MQA 是最极端的 KV Cache 压缩方案：所有 query head 共享同一组 KV。

```
MHA (标准多头注意力):              MQA (多查询注意力):
                                  
  Q₁ Q₂ Q₃ ... Qₙ                 Q₁ Q₂ Q₃ ... Qₙ
  │  │  │      │                   ↘  ↓  ↙
  K₁ K₂ K₃ ... Kₙ       ──→        K_shared (只有 1 组!)
  │  │  │      │                     │
  V₁ V₂ V₃ ... Vₙ                   V_shared (只有 1 组!)
                                  
  KV heads: n                      KV heads: 1
  KV Cache: 基准                    KV Cache: 1/n 基准

使用 MQA 的模型: PaLM (Google), Gemini 早期版本
```

**MQA 的权衡**：

```
优点:
  ✓ KV Cache 减少到 1/num_heads（例如 32 heads → 减少 32×）
  ✓ Decode 阶段内存带宽需求大幅降低
  ✓ 推理速度显著提升（尤其是 decode）

缺点:
  ✗ 模型容量（capacity）降低
  ✗ 长上下文任务有轻微质量下降
  ✗ 训练时可能出现注意力崩溃（需要更仔细的优化）
```

### 4.2 Grouped Query Attention (GQA)

GQA 是 MHA 和 MQA 的折中方案，将 query heads 分成若干组，每组共享一组 KV。

```
GQA（以 group_size=4, 8 个 query heads 为例）:

  Q₁ Q₂ Q₃ Q₄ │ Q₅ Q₆ Q₇ Q₈                Q₁ Q₂ Q₃ Q₄ │ Q₅ Q₆ Q₇ Q₈
     Group 1   │    Group 2                     Group 1   │    Group 2
       │       │      │                            │       │      │
    K_grp1    K_grp2                          V_grp1    V_grp2
    2 个 KV heads                             2 个 KV heads

  num_kv_heads = num_q_heads / group_size = 8 / 4 = 2
  KV Cache 减少到 MHA 的 1/4
```

**不同 group_size 的权衡分析**：

```
┌──────────────────────────────────────────────────────────────┐
│        GQA group_size 对模型质量和推理效率的影响                │
├────────────┬──────────┬──────────┬───────────┬───────────────┤
│ group_size │ KV 大小   │ 推理速度  │ 模型质量   │ 代表模型       │
├────────────┼──────────┼──────────┼───────────┼───────────────┤
│ 1 (MHA)    │ 100%     │ 基准     │ 最佳       │ Llama-1, GPT-3│
│ 4          │ 25%      │ +30%     │ 几乎无损    │ Llama-3-8B   │
│ 8          │ 12.5%    │ +50%     │ 极小损失    │ Llama-2-70B  │
│ 16         │ 6.25%    │ +65%     │ 微小编差    │ --           │
│ ∞ (MQA)    │ 3.125%   │ +80%     │ 有一定损失   │ PaLM         │
└────────────┴──────────┴──────────┴───────────┴───────────────┘
```

**工业界的最佳实践**：
- 7B-13B 规模：group_size=4，质量几乎无损，速度显著提升
- 34B-70B 规模：group_size=8，在质量与效率间的 sweet spot
- 100B+：group_size=8 或更大，显存节省更为关键

### 4.3 Multi-head Latent Attention (MLA) 深入

前文已介绍 MLA 的基本原理，这里深入其数学细节和工程实现。

**MLA 的完整数学公式**：

```
给定输入 h ∈ R^{d_model}:

压缩:
  c_KV = W_DKV × h         其中 W_DKV ∈ R^{d_c × d_model}, d_c << d_model

解压:
  K = W_UK × c_KV          其中 W_UK ∈ R^{(num_heads × head_dim) × d_c}
  V = W_UV × c_KV          其中 W_UV ∈ R^{(num_heads × head_dim) × d_c}

Attention:
  Q = W_Q × h              其中 W_Q ∈ R^{(num_heads × head_dim) × d_model}
  RoPE 应用于 Q 和 K
  Output = softmax(Q × K^T / √head_dim) × V
```

```
MLA 内存分析:

传统 attention 单层 KV Cache:
  = 2 × num_heads × head_dim × seq_len × 2 bytes (FP16)
  = 2 × 128 × 128 × seq_len × 2
  = 65536 × seq_len bytes

MLA 单层缓存 (只存 c_KV + 解压时需的 RoPE 分量):
  = (d_c + d_RoPE) × seq_len × 2 bytes (FP16)
  ≈ 576 × seq_len × 2 bytes (DeepSeek-V2: d_c=512, d_RoPE=64)
  = 1152 × seq_len bytes

压缩比: 65536 / 1152 ≈ 56.9×

实际综合压缩比（考虑额外存储的解压矩阵等）: ~10×
```

**MLA 在 vLLM 中的实现要点**：

```python
# vLLM 中 DeepSeek-V2 MLA 的简化实现逻辑

class DeepSeekV2MLAAttention:
    def forward(self, hidden_states, positions, kv_cache):
        # Step 1: 压缩到潜在空间
        kv_latent = self.kv_compress(hidden_states)  # [tokens, d_c]
        
        # Step 2: 写入 KV Cache（只存压缩表示）
        kv_cache.write(kv_latent, positions)
        
        # Step 3: 读取完整历史 KV Cache
        full_kv_latent = kv_cache.read_all()  # [total_seq_len, d_c]
        
        # Step 4: 解压得到 K 和 V
        K = self.uk_proj(full_kv_latent)  # [total_seq_len, num_heads*head_dim]
        V = self.uv_proj(full_kv_latent)
        
        # Step 5: Query 投影
        Q = self.q_proj(hidden_states)
        
        # Step 6: 应用 RoPE
        Q, K = self.apply_rope(Q, K, positions)
        
        # Step 7: 标准 Attention
        output = self.attention(Q, K, V)
        return output
```

### 4.4 Sliding Window Attention

Sliding Window Attention 限制每个 token 只能 attend 到最近的 W 个 token，将 KV Cache 从 O(n) 降为 O(W)。

```
Sliding Window Attention（窗口大小 W=4）:

Token 序列:  [t0] [t1] [t2] [t3] [t4] [t5] [t6] [t7] [t8]
              │    │    │    │    │    │    │    │    │
t8 可以 attend:           ◄──────── 窗口 W=4 ────────►
                         [t5] [t6] [t7] [t8]
                 
t4 可以 attend: ◄── W=4 ──►
              [t1] [t2] [t3] [t4]

KV Cache 只需保留最近 W 个 token 的 KV → 内存上限 O(W)，而非 O(n)
```

```
使用 Sliding Window Attention 的模型:

┌─────────────────────────────────────────────────────────────┐
│ 模型              │ 窗口大小 W  │ 全局 attention 层  │ 备注     │
├───────────────────┼────────────┼───────────────────┼─────────┤
│ Mistral-7B        │ 4096       │ 无                │ 纯滑动窗口│
│ Mixtral-8×7B      │ 4096       │ 无                │ 纯滑动窗口│
│ Gemma-2           │ 4096/8192  │ 每 6 层一次        │ 混合     │
│ Jamba (Mamba+Attn)│ 4096       │ 仅 attention 层   │ 混合架构 │
└───────────────────┴────────────┴───────────────────┴─────────┘
```

**StreamingLLM**：一种利用 attention sink 现象的 KV Cache 压缩方法。研究发现，初始几个 token（称为 attention sink）对所有后续 token 的注意力分布影响极大，必须保留。StreamingLLM 保留开头的 4 个 sink token + 滑动窗口内的 token。

```
StreamingLLM 的 KV Cache 结构:

┌────────────────────────────────────────────────────────────┐
│ [sink0][sink1][sink2][sink3] │ [滑动窗口 W 个 token]        │
│  ←── 始终保留 ──→│           │ ←── 动态更新 ──→             │
│                            │                               │
│  总 KV Cache = 4 + W 个 token（相比完整序列大幅减少）        │
└────────────────────────────────────────────────────────────┘
```

### 4.5 层稀疏化 / 稀疏注意力

并非所有层都需要全局注意力。稀疏化的思路是只在部分层使用全局注意力，其他层使用局部注意力或完全跳过。

```
层稀疏化策略示意（32 层 Transformer）:

Layer 0:  ■ 全局注意力 (full attention)
Layer 1:  │ 局部注意力 (sliding window)      ← 节省 KV Cache
Layer 2:  │ 局部注意力
Layer 3:  │ 局部注意力
Layer 4:  ■ 全局注意力 (每 4 层一个全局层)
Layer 5:  │ 局部注意力
  ...
Layer 31: ■ 全局注意力

KV Cache 节省: 25% 的层是全局注意力，75% 是局部注意力
→ 局部注意力层的 KV Cache ≈ O(W) 而非 O(n)，大幅节省内存
```

实际实现方案（如 Longformer、BigBird）常使用模式：

```
T1: 全局+局部混合（Longformer）

  [CLS]  tok1  tok2  tok3  tok4  tok5  tok6  tok7  tok8
  [CLS]   ■     ■     ■     ■     ■     ■     ■     ■    ← 全局 token
  tok1    ■     ■     ■                                  ← 局部窗口
  tok2    ■     ■     ■     ■
  tok3          ■     ■     ■     ■
  tok4                ■     ■     ■     ■
  ...

T2: 随机+局部混合（BigBird）

  除了局部窗口和全局 token，还加入随机 attention 连接
  用于捕获远距离依赖
```

---

## 5. 前缀缓存 (Prefix Caching)

### 5.1 基本原理

在 LLM 服务中，大量请求共享相同的前缀（如 system prompt、few-shot examples）。前缀缓存通过复用已计算的 KV Cache 来避免重复计算。

```
场景：3 个请求共享相同的 system prompt

Request 1: [System Prompt (500 tokens) | User Query A | ...]
Request 2: [System Prompt (500 tokens) | User Query B | ...]
Request 3: [System Prompt (500 tokens) | User Query C | ...]

没有前缀缓存:
├─ Req1: prefill 500 tokens → 计算 500 个 KV
├─ Req2: prefill 500 tokens → 重新计算 500 个 KV  ← 重复!
└─ Req3: prefill 500 tokens → 再次计算 500 个 KV  ← 重复!

有前缀缓存:
├─ Req1: prefill 500 tokens → 计算并缓存 500 个 KV
├─ Req2: prefill 500 tokens → 命中缓存! 直接复用 ← 节省计算
└─ Req3: prefill 500 tokens → 命中缓存! 直接复用 ← 节省计算
```

### 5.2 Radix Tree 匹配

vLLM 使用 Radix Tree（基数树，又称 Patricia Trie）来高效地进行前缀匹配。

```
Radix Tree 结构示意:

                     root
                      │
                 "You are a"
                      │
              ┌───────┴───────┐
         "helpful"        "math"
              │               │
          "assistant"     "tutor"
              │               │
         [KV Block A]    [KV Block B]

新请求: "You are a helpful assistant. What is AI?"
匹配路径: root → "You are a" → "helpful" → "assistant"
命中: KV Block A → 可直接复用
```

```
┌──────────────────────────────────────────────────────────────┐
│              Radix Tree 节点结构（vLLM 内部）                  │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  class TreeNode:                                             │
│      token_ids: List[int]       # 该节点对应的 token 序列       │
│      children: Dict[int, TreeNode]  # 子节点（按 token 索引）   │
│      kv_block_ids: List[int]    # 对应的 KV Cache block IDs   │
│      last_access_time: float    # 最后访问时间（用于 LRU 淘汰） │
│                                                              │
│  特点:                                                       │
│  - 路径压缩: 连续的单子节点被压缩为一个节点                      │
│  - O(L) 查找: L 为 token 序列长度                              │
│  - 内存高效: 共享前缀只需存储一次                               │
└──────────────────────────────────────────────────────────────┘
```

### 5.3 vLLM 的自动前缀缓存 (Automatic Prefix Caching, APC)

```bash
# 启用自动前缀缓存
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --enable-prefix-caching \
    --max-model-len 8192
```

**APC 的工作机制**：

```python
# vLLM APC 的核心逻辑（简化版）

class BlockSpaceManager:
    def allocate_blocks_for_request(self, request):
        token_ids = request.prompt_token_ids
        
        # 从 Radix Tree 中查找前缀匹配
        matched_blocks, matched_tokens = self.prefix_caching_trie.match(token_ids)
        
        if matched_blocks:
            # 命中前缀缓存！
            request.block_ids = matched_blocks  # 复用已有 blocks
            
            remaining_tokens = token_ids[matched_tokens:]
            # 只需计算剩余 token 的 KV
            new_blocks = self.allocate_new_blocks(len(remaining_tokens))
            request.block_ids.extend(new_blocks)
        else:
            # 未命中，全部分配新 blocks
            request.block_ids = self.allocate_new_blocks(len(token_ids))
        
        # 将新计算的 blocks 插入 Radix Tree
        self.prefix_caching_trie.insert(token_ids, request.block_ids)
```

**APC 的性能收益**：

```
场景: 100 个请求，每个都带 500 token 的 system prompt

┌────────────────────────────────────────────────────────────────┐
│ 指标              │ 无前缀缓存  │ 有前缀缓存   │ 改善           │
├───────────────────┼────────────┼─────────────┼───────────────┤
│ Prefill 时间（首个）│ 50ms       │ 50ms        │ --            │
│ Prefill 时间（后续）│ 50ms       │ 5ms         │ 10× 加速       │
│ KV Cache 内存       │ 5000 块    │ 525 块      │ ~10× 节省      │
│ 总吞吐量            │ 100 req/s  │ 500 req/s   │ 5× 提升        │
└───────────────────┴────────────┴─────────────┴───────────────┘
```

**APC 的局限**：

1. **必须 token 级别精确匹配**：即使是相同语义的不同措辞也无法命中
2. **格式敏感**：空格、换行符的差异会导致失效
3. **只在前缀匹配**：中间的公共子串不会被复用

---

## 6. KV Cache 卸载

### 6.1 CPU 卸载

当 GPU 显存不足时，可以将部分 KV Cache 卸载到 CPU 内存。

```
分层存储架构:

  ┌──────────────────────────────────┐
  │           GPU HBM (80GB)         │ ← 热数据：当前活跃的 KV Cache
  │   速度: ~2 TB/s                  │
  │   延迟: ~1 μs                    │
  ├──────────────────────────────────┤
  │         CPU DRAM (512GB)         │ ← 温数据：非活跃的 KV Cache
  │   速度: ~100 GB/s (PCIe 4.0)    │
  │   延迟: ~10 μs                   │
  ├──────────────────────────────────┤
  │          SSD / NVMe (2TB)        │ ← 冷数据：已完成请求的 KV Cache
  │   速度: ~7 GB/s (PCIe 4.0 NVMe) │
  │   延迟: ~100 μs                  │
  └──────────────────────────────────┘
```

**vLLM 中的 CPU 卸载配置**：

```bash
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --max-model-len 32768 \
    --cpu-offload-gb 64 \         # 允许卸载 64GB 到 CPU
    --gpu-memory-utilization 0.90
```

**卸载策略**：

```
LRU 淘汰 + 卸载:

1. GPU Cache 满 → 选择最久未使用的 blocks
2. 将这些 blocks 拷贝到 CPU 内存
3. 释放 GPU blocks，供新请求使用
4. 当请求需要访问被卸载的 blocks 时：
   → 从 CPU 拷贝回 GPU（有一定延迟惩罚）

交换开销分析:
  单 block 大小: 16 tokens × 单层 KV 大小
  Qwen-7B: 16 × 32 × 2KB = 1MB / block
  PCIe 4.0 x16: ~32 GB/s
  1MB transfer: ~30 μs（可接受）
  但如果大量 blocks 需要换入换出 → 会成为瓶颈
```

### 6.2 FlexGen: SSD 卸载 + 之字形调度

FlexGen 是一种将 KV Cache 和模型权重卸载到 SSD 的极端方案，使单 GPU 也能运行大模型。

```
FlexGen 的核心技术:

1) 之字形块调度（Zigzag Block Scheduling）:
   将计算划分为 "块"，按之字形顺序计算，
   最大化数据复用，减少 SSD 读写

   
   GPU 显存
   ┌────┐      ┌────┐      ┌────┐
   │块1 │ →   │块2 │ →   │块3 │ ...
   └────┘      └────┘      └────┘
      ↑           │           │
      │  (预取)    │ (卸载)     │
      │           ↓           ↓
   ┌──────────────────────────────────┐
   │            SSD 存储               │
   │  W1, W2, ..., KV1, KV2, ...     │
   └──────────────────────────────────┘

2) 量化权重 + 量化 KV Cache:
   进一步压缩数据量

3) 重叠计算与 I/O:
   GPU 计算块 N 时，CPU 预取块 N+1 的数据
```

```
FlexGen 在 OPT-175B 上的性能（单张 16GB GPU）:

┌───────────────────────────────────────────────────────┐
│ 配置                          │ 延迟 (秒/token)         │
├──────────────────────────────┼───────────────────────┤
│ GPU-only (放不下)              │ N/A                   │
│ CPU offload                    │ ~120                  │
│ FlexGen (SSD offload)          │ ~40-60               │
│ FlexGen + 量化                 │ ~20-30               │
└──────────────────────────────┴───────────────────────┘

虽然延迟很高，但证明了单 GPU 运行 175B 模型的可行性
```

### 6.3 分层缓存架构

在生产环境中，可以构建三层 KV Cache 缓存：

```
┌─────────────────────────────────────────────────────────────┐
│                   三层 KV Cache 架构                          │
│                                                             │
│  Layer 1: GPU KV Cache (HBM)                                │
│  ├─ 大小: GPU 显存的 80-90%                                  │
│  ├─ 存储: 当前活跃请求的 KV Cache                             │
│  ├─ 访问延迟: ~1 μs                                          │
│  └─ 淘汰策略: LRU → 迁移到 Layer 2                            │
│                                                             │
│  Layer 2: CPU KV Cache (DRAM)                               │
│  ├─ 大小: CPU 内存（可配置，如 128GB）                         │
│  ├─ 存储: 近期可能被复用的 KV Cache                           │
│  ├─ 访问延迟: ~10 μs (PCIe 传输)                              │
│  └─ 淘汰策略: LRU → 可丢弃或迁移到 Layer 3                     │
│                                                             │
│  Layer 3: SSD Persistent Cache (NVMe)                       │
│  ├─ 大小: TB 级别                                            │
│  ├─ 存储: 高频 system prompt / 模板的 KV Cache                │
│  ├─ 访问延迟: ~100-200 μs                                     │
│  └─ 持久化: 服务重启后仍然可用                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## 7. KV Cache 感知调度

### 7.1 问题描述

在 vLLM 的连续批处理（continuous batching）中，调度器决定哪些请求进入下一个 decode 步。KV Cache 感知调度的目标是：**将共享前缀的请求调度到同一 GPU 上**。

```
无感知调度:
  GPU 0: [Req1: system_A + query1]
  GPU 1: [Req2: system_B + query2]
  GPU 2: [Req3: system_A + query3]  ← system_A 在 GPU 0 上已经缓存了!
  GPU 3: [Req4: system_C + query4]
  
  → GPU 2 上的 system_A 无法复用 GPU 0 上的缓存

KV Cache 感知调度:
  GPU 0: [Req1: system_A + query1]
         [Req3: system_A + query3]  ← 同 GPU, 可复用!
  GPU 1: [Req2: system_B + query2]
         [Req5: system_B + query5]  ← 同 GPU, 可复用!
  
  → 前缀缓存的命中率显著提升
```

### 7.2 实现策略

```python
# KV Cache 感知调度的核心逻辑（简化）

class KVCacheAwareScheduler:
    def __init__(self):
        # 维护每个 GPU 上的前缀缓存状态
        self.gpu_prefix_state = {}  # gpu_id -> RadixTree
    
    def schedule_request(self, request):
        prompt_tokens = request.prompt_token_ids
        
        # 1. 检查各 GPU 的前缀缓存命中情况
        best_gpu = None
        best_match_len = 0
        for gpu_id, trie in self.gpu_prefix_state.items():
            match_len = trie.match_length(prompt_tokens)
            if match_len > best_match_len:
                best_match_len = match_len
                best_gpu = gpu_id
        
        # 2. 优先调度到缓存命中最多的 GPU
        if best_match_len > MIN_PREFIX_MATCH_TOKENS:  # e.g., 64 tokens
            target_gpu = best_gpu
        else:
            target_gpu = self.select_gpu_by_load()  # 负载均衡
        
        # 3. 分配请求
        self.dispatch(request, target_gpu)
    
    def select_gpu_by_load(self):
        # 选择 KV Cache 使用率最低的 GPU
        return min(self.gpus, key=lambda g: g.kv_cache_usage_perc)
```

### 7.3 调度哈希策略

```python
# 基于前缀哈希的调度

def route_by_prefix_hash(request, num_gpus):
    """
    使用一致性哈希将具有相同前缀的请求路由到同一 GPU
    """
    prompt = request.prompt
    # 取前 N 个字符作为哈希键（或使用局部敏感哈希）
    prefix_key = prompt[:200]
    hash_value = hash(prefix_key)
    target_gpu = hash_value % num_gpus
    return target_gpu

# 更优方案：对 prompt 的前 K 个 token 做哈希
# 因为 token 级别的匹配比字符串匹配更精确
def route_by_token_prefix(request, num_gpus):
    first_n_tokens = request.prompt_token_ids[:64]
    hash_value = hash(tuple(first_n_tokens))
    return hash_value % num_gpus
```

---

## 8. 监控 KV Cache

### 8.1 vLLM 的关键指标

vLLM 暴露了丰富的 Prometheus 指标用于监控 KV Cache 状态：

```
vLLM KV Cache 相关指标:

# KV Cache 使用率
vllm:gpu_cache_usage_perc         # GPU KV Cache 使用百分比 (0-100)
vllm:cpu_cache_usage_perc         # CPU KV Cache 使用百分比 (0-100, 仅当启用 CPU 卸载)

# 前缀缓存
vllm:prefix_cache_hit_rate        # 前缀缓存命中率
vllm:prefix_cache_queries_total   # 总查询次数
vllm:prefix_cache_hits_total      # 总命中次数

# 请求状态
vllm:num_requests_running         # 当前运行的请求数
vllm:num_requests_waiting         # 等待队列中的请求数
vllm:num_requests_swapped         # 被换出到 CPU 的请求数

# Block 管理
vllm:gpu_blocks_total             # GPU block 总数
vllm:gpu_blocks_free              # 空闲 GPU block 数
vllm:cpu_blocks_total             # CPU block 总数（如启用）
vllm:cpu_blocks_free              # 空闲 CPU block 数
```

**Prometheus 配置示例**：

```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'vllm'
    static_configs:
      - targets: ['localhost:8000']
    scrape_interval: 15s
```

```bash
# 启动 vLLM 时启用 metrics
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --enable-metrics \
    --host 0.0.0.0 \
    --port 8000

# 查看指标
curl http://localhost:8000/metrics | grep cache
```

### 8.2 自定义监控脚本

```python
# monitor_kv_cache.py — 实时监控 KV Cache 使用情况

import requests
import time
from collections import deque

class KVCacheMonitor:
    def __init__(self, metrics_url="http://localhost:8000/metrics"):
        self.metrics_url = metrics_url
        self.history = deque(maxlen=100)  # 保留最近 100 个数据点
    
    def parse_metrics(self):
        resp = requests.get(self.metrics_url).text
        metrics = {}
        for line in resp.split('\n'):
            if line.startswith('vllm:'):
                if 'gpu_cache_usage_perc' in line:
                    metrics['gpu_cache_usage'] = float(line.split()[-1])
                elif 'prefix_cache_hit_rate' in line:
                    metrics['prefix_hit_rate'] = float(line.split()[-1])
                elif 'num_requests_running' in line:
                    metrics['running_requests'] = int(line.split()[-1])
                elif 'num_requests_swapped' in line:
                    metrics['swapped_requests'] = int(line.split()[-1])
        return metrics
    
    def monitor_loop(self, interval=1.0):
        while True:
            metrics = self.parse_metrics()
            self.history.append(metrics)
            
            # 告警条件
            if metrics.get('gpu_cache_usage', 0) > 95:
                print(f"[WARN] GPU Cache 使用率过高: {metrics['gpu_cache_usage']:.1f}%")
            if metrics.get('swapped_requests', 0) > 10:
                print(f"[WARN] 大量请求被换出: {metrics['swapped_requests']}")
            
            # 打印状态
            print(f"[{time.strftime('%H:%M:%S')}] "
                  f"GPU Cache: {metrics.get('gpu_cache_usage', 0):.1f}% | "
                  f"Running: {metrics.get('running_requests', 0)} | "
                  f"Swapped: {metrics.get('swapped_requests', 0)} | "
                  f"Prefix Hit: {metrics.get('prefix_hit_rate', 0):.2f}")
            
            time.sleep(interval)

if __name__ == "__main__":
    monitor = KVCacheMonitor()
    monitor.monitor_loop()
```

### 8.3 Grafana 仪表盘

关键监控面板：

```
┌───────────────────────────────────────────────────────────────┐
│                       Grafana 仪表盘                           │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  Panel 1: GPU KV Cache Usage Gauge                           │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  ████████████████░░░░░  78%                             │ │
│  │  阈值线: 90% (黄色), 95% (红色)                            │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                               │
│  Panel 2: KV Cache Usage Timeline                            │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  100% │                                    ╭─            │ │
│  │   75% │     ╭──╮    ╭───╮   ╭──╮   ╭──────╯             │ │
│  │   50% │  ╭──╯  ╰────╯   ╰───╯  ╰───╯                   │ │
│  │   25% ├──╯                                              │ │
│  │    0% └────┬────┬────┬────┬────┬────┬────                │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                               │
│  Panel 3: Prefix Cache Hit Rate                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  1.0  │  ▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁               │ │
│  │  0.5  │  ████████████████████████████                   │ │
│  │  0.0  └──┬────┬────┬────┬────┬────┬────                  │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                               │
│  Panel 4: Requests State Breakdown                           │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  Running: 32  │  Waiting: 8  │  Swapped: 2               │ │
│  └─────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────┘
```

---

## 9. 调试 KV Cache 问题

### 9.1 "为什么我的服务 OOM 了？" — 诊断流程

```
诊断流程图:

  服务 OOM
     │
     ▼
  ┌─────────────────────────────────┐
  │ Step 1: 查看当前 KV Cache 使用率  │
  │ curl localhost:8000/metrics     │
  │ grep gpu_cache_usage_perc       │
  └───────────────┬─────────────────┘
                  │
       ┌──────────┴──────────┐
       │ 使用率 >95%?          │
       │ 使用率正常但 OOM?      │
       └──────────┬──────────┘
                  │
    ┌─────────────┴─────────────┐
    │                            │
    ▼                            ▼
  KV Cache 不足              模型权重/激活值 OOM
    │                            │
    ▼                            ▼
  检查:                       检查:
  - max_model_len 是否过大?   - 是否加载了未量化的模型?
  - 并发请求数是否过高?        - gpu_memory_utilization 是否过高?
  - 是否启用了前缀缓存?        - 是否有内存碎片?
```

### 9.2 常见 KV Cache 问题及解决方案

**问题 1: 序列长度溢出**

```
症状:
  CUDA out of memory. Tried to allocate XXX MiB.
  vllm:gpu_cache_usage_perc 迅速从 80% 跳到 100%

原因: 某个请求的生成长度超出了预留的 KV Cache

解决:
  1) 减小 --max-model-len
  2) 设置合理的 --max-num-seqs 限制并发
  3) 对比请求日志与配置的 max_tokens
```

**问题 2: Block 碎片化**

```
症状:
  free blocks 显示有空间，但新请求无法分配

原因: Block 分配使用 buddy allocator 或 slab allocator，
      碎片化导致没有连续的大块

示意:
  
  [████░░████░░░░██████░░░░██░░]
   █ = 已分配    ░ = 空闲
   
  总空闲: 12 blocks，但最大连续空闲: 4 blocks
  需要 6 blocks 的请求 → 分配失败!

解决:
  1) 减小 block_size (默认 16)，减少碎片
  2) 重启服务（重建内存池）
  3) 升级 vLLM 版本（持续改进内存管理）
```

**问题 3: 前缀缓存未命中**

```
诊断:
  curl localhost:8000/metrics | grep prefix_cache_hit_rate
  
  如果 hit_rate < 0.3 (30%)，说明前缀缓存效果不佳

原因排查:
  1) System prompt 中是否包含动态内容（时间戳、随机数等）
  2) 不同请求的 prompt 格式是否一致（空格、换行）
  3) 请求之间是否有足够的共享前缀

改进:
  1) 移除 system prompt 中的动态内容
  2) 标准化 prompt 格式
  3) 使用 chat template 确保一致性
```

**问题 4: CPU 卸载导致延迟飙升**

```
症状:
  decode 延迟从 20ms 突然跳到 200ms+

原因:
  被换出的 blocks 需要从 CPU 拷回 GPU，增加了 PCIe 延迟

诊断:
  vllm:num_requests_swapped > 0 → 有请求被换出
  
  每次 swap-in 的延迟 = block_size × num_blocks × PCIe 带宽
  例如: 16 tokens × 100 blocks × 3 GB/s (有效带宽) ≈ 5ms

解决:
  1) 增大 --gpu-memory-utilization (e.g., 0.95)
  2) 减小 --max-model-len 释放更多 GPU 空间
  3) 添加更多 GPU
  4) 启用 KV Cache 量化 (FP8/INT8)
```

### 9.3 调试工具和命令

```bash
# 1. 查看 GPU 显存使用
nvidia-smi --query-gpu=memory.used,memory.total --format=csv

# 2. 查看 vLLM 进程的详细显存分布
# (需要 vLLM >= 0.4.0)
curl http://localhost:8000/metrics | grep -E "vllm:(gpu|cpu)_"

# 3. 记录 KV Cache 使用的时间线
python -c "
import time
import requests
while True:
    m = requests.get('http://localhost:8000/metrics').text
    for line in m.split('\n'):
        if 'gpu_cache_usage_perc' in line:
            print(f'{time.time()},{line.split()[-1]}')
    time.sleep(1)
" > kv_cache_timeline.csv

# 4. 分析内存分配热点
# 设置环境变量
export VLLM_LOGGING_LEVEL=DEBUG
export VLLM_TRACE_FUNCTION=1
```

---

## 10. 实践案例：33B 模型优化

### 10.1 模型配置

假设你在 A800-80G 上运行一个 33B 参数的模型（类似 Yi-34B、DeepSeek-Coder-33B）：

```
模型规格:
- 参数量: 33B
- 层数: 60
- Query heads: 56
- KV heads: 8 (GQA, group_size=7)
- Head dim: 128
- 最大序列长度: 32768
- 精度: FP16

单 token 单层 KV:
  = 2 × 8 × 128 × 2 (FP16 bytes) = 4096 bytes

全部 60 层单 token:
  = 60 × 4096 = 245,760 bytes ≈ 240 KB

单请求 max_seq_len=32768:
  = 32768 × 240 KB = 7,864,320 KB ≈ 7.5 GB  (仅是 KV Cache!)
```

### 10.2 显存预算分析

```
单张 A800-80G 的显存预算:
┌─────────────────────────────────────────────────────┐
│ 项目                  │ 大小        │ 占比          │
├──────────────────────┼────────────┼──────────────┤
│ 模型权重 (FP16)       │ ~66 GB     │ 82.5%        │
│ CUDA Context 等       │ ~2 GB      │ 2.5%         │
│ 剩余用于 KV + 激活     │ ~12 GB     │ 15%          │
├──────────────────────┼────────────┼──────────────┤
│ 总计                  │ 80 GB      │ 100%         │
└──────────────────────┴────────────┴──────────────┘

如果不开任何优化:
  12 GB / 7.5 GB ≈ 1.6 个并发请求（max seq_len）
  
  实际场景（平均 seq_len=4096）:
  单请求 KV = 4096 × 240 KB ≈ 0.94 GB
  12 GB / 0.94 GB ≈ 12 个并发请求
```

### 10.3 优化方案对比

```
┌────────────────────────────────────────────────────────────────────┐
│              33B 模型在 A800-80G 上的优化方案                        │
├─────────────────────┬────────────┬────────────┬────────────────────┤
│ 方案                 │ KV 大小     │ 最大并发    │ 备注               │
│                     │ (单请求4K) │ (12GB预算)│                    │
├─────────────────────┼────────────┼────────────┼────────────────────┤
│ 基准 (FP16)          │ 0.94 GB    │ ~12        │ 基线               │
│ FP8 KV Cache        │ 0.47 GB    │ ~25        │ 精度损失 <0.1%     │
│ INT8 KV Cache       │ 0.47 GB    │ ~25        │ 精度损失 <>>> 精度损失 <1%      │
│ INT8 + 前缀缓存      │ 0.47 GB    │ ~30-60     │ 取决于前缀重复率     │
│ 4-bit KIVI          │ 0.235 GB   │ ~50        │ 精度损失 <>>> 精度损失 <1%      │
│ 4-bit KIVI + FP8   │ 0.235 GB   │ ~50        │ 需要硬件支持        │
│ GPTQ-INT4 权重       │ ~16.5 GB   │ 额外 49.5GB │ 大幅增加 KV 空间   │
│ GPTQ-INT4 + FP8 KV │ 0.47 GB    │ ~105       │ 推荐组合!          │
└─────────────────────┴────────────┴────────────┴────────────────────┘
```

### 10.4 推荐配置

```bash
# 配置 1: 高吞吐（A800 单卡，INT4 权重 + FP8 KV Cache）
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/33b-model-GPTQ-int4 \
    --quantization gptq \
    --kv-cache-dtype fp8 \
    --max-model-len 32768 \
    --enable-prefix-caching \
    --gpu-memory-utilization 0.95 \
    --max-num-seqs 128 \
    --max-num-batched-tokens 16384

# 预期性能:
# - 并发: 100+ 请求
# - Prefill 吞吐: ~5000 tokens/s
# - Decode 延迟: ~30ms/token (batch=32)

# 配置 2: 极致精度（A800 单卡，FP16 权重 + FP8 KV Cache）
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/33b-model-fp16 \
    --kv-cache-dtype fp8 \
    --max-model-len 32768 \
    --enable-prefix-caching \
    --gpu-memory-utilization 0.90 \
    --max-num-seqs 32

# 预期性能:
# - 并发: 20-30 请求
# - 精度: 无损
# - Decode 延迟: ~25ms/token (batch=16)
```

### 10.5 压测脚本

```python
# benchmark_kv_cache.py — 测试不同配置下的 KV Cache 表现
import asyncio
import aiohttp
import time
import json
import matplotlib.pyplot as plt

async def send_request(session, url, prompt, max_tokens=256):
    payload = {
        "model": "model",
        "prompt": prompt,
        "max_tokens": max_tokens,
        "temperature": 0.0,
    }
    start = time.time()
    async with session.post(f"{url}/v1/completions", json=payload) as resp:
        result = await resp.json()
    latency = time.time() - start
    tokens = result["usage"]["completion_tokens"]
    return tokens, latency

async def benchmark(url, prompt, num_requests, concurrency):
    """并发压测 KV Cache 表现"""
    connector = aiohttp.TCPConnector(limit=concurrency)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [send_request(session, url, prompt) for _ in range(num_requests)]
        results = await asyncio.gather(*tasks)
    
    total_tokens = sum(r[0] for r in results)
    total_time = sum(r[1] for r in results)
    avg_latency = total_time / num_requests
    throughput = total_tokens / (time.time() - start_time)  # tokens/s
    
    print(f"并发={concurrency}, 请求数={num_requests}")
    print(f"  平均延迟: {avg_latency:.2f}s")
    print(f"  吞吐量: {throughput:.1f} tokens/s")
    print(f"  总 tokens: {total_tokens}")
    
    return concurrency, throughput, avg_latency

# 固定长度的 system prompt（用于测试前缀缓存）
SYSTEM_PROMPT = "You are a helpful assistant. " * 100  # ~500 tokens

if __name__ == "__main__":
    url = "http://localhost:8000"
    
    # 测试不同并发度
    for concurrency in [1, 4, 8, 16, 32, 64]:
        start_time = time.time()
        asyncio.run(benchmark(url, SYSTEM_PROMPT + "Explain quantum computing.", 
                               num_requests=100, concurrency=concurrency))
        time.sleep(5)  # 冷却
```

---

## 11. 易混淆技术辨析

KV Cache 优化领域技术繁多，以下几组概念最容易被混淆。厘清它们的区别对于技术选型和方案设计至关重要。

### 11.1 GQA vs MQA vs MLA

这三种注意力变体代表了 KV Cache 压缩的三种不同哲学：从"分组共享"到"全部共享"再到"压缩表示"。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         GQA vs MQA vs MLA 全面对比                             │
├──────────────────┬──────────────────┬──────────────────┬──────────────────────┤
│      特性         │  GQA              │  MQA               │  MLA                 │
│                  │ (Grouped Query)   │ (Multi-Query)      │ (Multi-head Latent)  │
├──────────────────┼──────────────────┼──────────────────┼──────────────────────┤
│  Q:K/V 关系       │  N个Q : N/g个K/V  │  N个Q : 1个K/V     │  独立子空间压缩       │
│  KV Cache 大小    │  MHA的1/g         │  MHA的1/N          │  传统MHA的~1/10      │
│  压缩原理         │  分组共享          │  全部共享           │  低秩压缩+解压        │
│  模型质量         │  几乎无损(g≤8)     │  有轻微损失         │  几乎无损             │
│  Decode加速       │  显著(g倍带宽节省) │  极大(N倍带宽节省)  │  极大(压缩表示更小)    │
│  额外计算         │  无               │  无                │  有(解压投影)         │
│  代表模型         │  Llama-2/3,       │  PaLM,             │  DeepSeek-V2,         │
│                  │  Qwen, Mistral    │  早期Gemini        │  DeepSeek-V3         │
│  是否需要特殊训练  │  是               │  是                │  是                   │
│  硬件要求         │  通用             │  通用              │  需高效矩阵乘法       │
└──────────────────┴──────────────────┴──────────────────┴──────────────────────┘
```

**选择决策树**：

```
你的场景:
  │
  ├── 自己训练模型?
  │     ├── 追求极致decode速度 + 可接受轻微质量损失 → MQA
  │     ├── 质量优先 + 较大KV Cache节省 → GQA (group_size=8)
  │     └── 质量优先 + 极致KV Cache节省 → MLA (需额外工程投入)
  │
  └── 使用开源模型?
        └── 模型已经定好了，无需选择
            Llama系列 = GQA, DeepSeek-V2/V3 = MLA
            你能做的是: FP8量化 + 前缀缓存等模型无关优化
```

**一个具体的数值对比（以 70B 规模模型为例）**：

```
假设: num_q_heads=64, head_dim=128, seq_len=4096, num_layers=80, FP16

MHA (num_kv_heads=64):
  KV Cache = 2 × 64 × 128 × 4096 × 80 × 2 = 10.7 GB

GQA (num_kv_heads=8, group_size=8):
  KV Cache = 2 × 8 × 128 × 4096 × 80 × 2 = 1.34 GB  (减少 8×)

MQA (num_kv_heads=1):
  KV Cache = 2 × 1 × 128 × 4096 × 80 × 2 = 167 MB   (减少 64×)

MLA (d_c=512, 缓存压缩表示):
  KV Cache = 512 × 4096 × 80 × 2 = 335 MB            (减少 ~32×)
  但需额外存储 RoPE 分量 (~64维) 和解压矩阵
```

### 11.2 FP8 KV Cache vs INT8 KV Cache

两者都是将 KV Cache 从 16-bit 压缩到 8-bit，但数值表示方式和适用场景不同。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        FP8 vs INT8 KV Cache                                    │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │    FP8 KV Cache             │   INT8 KV Cache           │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  数值格式           │  浮点数（E4M3/E5M2）         │  定点整数                  │
│  动态范围           │  大（指数位提供）             │  小（需 scale 映射）        │
│  精度分布           │  非均匀（靠近0精度高）        │  均匀                      │
│  硬件加速           │  H100/H800 (Hopper)          │  A100/A800 (Ampere)       │
│                   │  原生 FP8 Tensor Core         │  无原生 INT8 矩阵乘法      │
│  量化方式           │  直接截断/舍入               │  需要 scale + zero-point   │
│  离群值处理          │  天然支持                    │  离群值会导致精度崩溃       │
│  精度损失           │  <0.1% (几乎无损)             │  1-5% (取决于量化粒度)     │
│  实现复杂度          │  低（格式转换）              │  中高（需管理 scale）       │
│  推荐场景           │  H100/H800 集群              │  A100/A800 集群            │
│                   │  长序列 + 高并发              │  对精度有一定容忍度的场景    │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**核心区别**：FP8 是"缩略版浮点数"——保留了指数位，动态范围大，对离群值天然友好。INT8 是"整数定点"——只有 256 个均匀离散值，需要 scale 来映射，离群值会导致 scale 过大、大部分数据被量化到 0。这就是为什么 INT8 KV Cache 通常需要 per-channel 或 per-token 的细粒度量化（如 KIVI），而 FP8 可以直接做 per-tensor 量化。

**实践建议**：
- 在 **H100/H800** 上：无脑选 FP8 KV Cache（`--kv-cache-dtype fp8`），硬件原生加速，精度无损。
- 在 **A100/A800** 上：FP8 没有硬件加速，但仍可节省 50% 显存。如果精度敏感，选用 FP8（精度高）；如果显存是第一优先，可尝试 KIVI 4-bit 量化（节省 75%）。
- 无论哪种方案，部署前务必用你的真实数据做精度验证（PPL 或下游任务评测），不要只看论文数据。

**GB 级别的节省计算**：

```
场景: Qwen-72B, 2×A800-80G (TP=2), seq_len=4096, 并发=8

FP16 KV Cache: 10 GB × 2 卡 = 20 GB
FP8  KV Cache: 5 GB × 2 卡 = 10 GB  → 节省 10 GB (50%)
INT8 KV Cache: 5 GB × 2 卡 = 10 GB  → 节省 10 GB (50%)

节省的 10 GB 可以:
  - 将并发从 8 提升到 ~16 (+100%)
  - 或将 max_model_len 从 4096 提升到 8192
  - 或留作 buffer 避免 OOM
```

### 11.3 Prefix Cache vs KV Cache

这是最容易混淆的一对概念——名字相似但含义完全不同。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Prefix Cache vs KV Cache                               │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │   Prefix Cache（前缀缓存）   │  KV Cache（KV 缓存）       │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  本质               │  一种优化技术（跨请求复用）    │  推理基础设施（必需组件）    │
│  是否存在            │  可选（需显式启用）           │  必然存在（自回归推理必需）  │
│  作用范围            │  跨请求                     │  单请求内部                 │
│  数据来源            │  之前其他请求计算的 KV        │  当前请求自己计算的 KV       │
│  存储               │  在 GPU 显存中共用 block      │  在 GPU 显存中独占或共享     │
│  配置               │  --enable-prefix-caching    │  无需配置，自动存在          │
│  失效条件            │  前缀 token 不完全匹配        │  请求完成后释放             │
│  典型案例            │  100个请求复用同一system prompt│  1个请求的每次decode都读取   │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**关键理解**：KV Cache 是大模型推理的"基础设施"——只要做自回归生成就必然存在。Prefix Caching 是建立在 KV Cache 之上的"优化层"——让不同请求之间可以复用彼此的 KV Cache。两者是层次关系，不是替代关系。启用 Prefix Caching 不会替代 KV Cache，而是让 KV Cache 的利用率更高。

**实践验证**：一个简单的方法判断 Prefix Caching 是否在你的场景中有价值——观察 `vllm:prefix_cache_hit_rate` 指标。如果 < 0.1，说明你的请求之间共享前缀很少（如每次 prompt 都是独特的），Prefix Caching 带来的收益有限。

### 11.4 Sliding Window Attention vs Full Attention

这是注意力机制在"看到多远"上的两种策略。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   Sliding Window Attention vs Full Attention                   │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │   Sliding Window            │  Full Attention            │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  注意力范围          │  仅最近 W 个 token           │  所有历史 token             │
│  KV Cache 大小       │  O(W)，固定上限              │  O(N)，随序列增长           │
│  长序列推理          │  天然支持                    │  需要大量显存               │
│  信息完整性          │  可能丢失远距离依赖           │  完整保留                   │
│  典型 W             │  4096 (Mistral, Mixtral)    │  N/A                       │
│  StreamingLLM       │  窗口 + 4个sink token       │  不需要额外处理             │
│  是否需要特殊训练    │  是（窗口内位置编码可能不同）  │  否（标准做法）             │
│  代表模型           │  Mistral-7B, Mixtral         │  Llama-2, Llama-3, Qwen    │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**混合方案**：越来越多的模型（如 Gemma-2）在大部分层使用 Sliding Window Attention（节省 KV Cache），每隔 4-6 层插入一个 Full Attention 层（保留长距离依赖能力）。这种混合策略在长序列场景下，可以节省 50-70% 的 KV Cache 显存，同时保持模型质量。

**StreamingLLM 的独特价值**：即使是使用 Full Attention 训练的模型（如 Llama），也可以通过 StreamingLLM 在推理时动态转换为"sliding window + attention sink"模式。这意味着你不必重新训练模型，就能用 StreamingLLM 来降低长序列推理时的 KV Cache 压力——代价是 PPL 有约 1-2 个点的上升。

---

## 12. AI Infra 专家视角

### 12.1 性能瓶颈排查：三层决策树

当 KV Cache 相关的性能问题出现时，按以下决策树逐层排查。

**第一层：KV Cache 容量不足（最常见，占问题 70%）**

```
症状：
  - CUDA OOM，错误信息指向 KV Cache 分配
  - vllm:gpu_cache_usage_perc 持续 > 95%
  - 并发请求数无法达到预期值

排查路径（从快到慢）：
  1. 计算理论 KV Cache 大小
     = 2 × batch × num_kv_heads × head_dim × avg_seq_len × num_layers × dtype_bytes
     对比 vllm:gpu_cache_usage_perc 看是否合理

  2. 检查 max_model_len 是否过大
     → 如果实际平均请求长度仅 1024，但 max_model_len=32768
     → 每条序列被预留的 block 表空间过大（但不一定占满）
     → 降低 max_model_len 到实际需求的 1.5 倍

  3. 检查是否有"超级长"的个别请求
     → 一个 32K token 的请求可能占满整个 KV Cache
     → 查看日志中的 prompt token count 分布
     → 对客户端限制 max_input_tokens

解决方案（按性价比排序）：
  a) 启用 FP8/INT8 KV Cache → 立即节省 50% 显存
  b) 启用 Prefix Caching → 系统 prompt 共享可节省 30-70%
  c) 降低 max_model_len → 释放预留空间
  d) 降低 max_num_seqs → 减少并发
  e) 增加 swap_space → 换出不活跃请求到 CPU
  f) 增加 GPU 或使用 Tensor Parallel
```

**第二层：KV Cache 带宽瓶颈（Decode 延迟高）**

```
症状：
  - Decode 阶段的 TPOT 显著高于预期
  - GPU 利用率（SM 利用率）偏低，但显存带宽利用率接近 100%
  - 增大 batch size 后 decode 延迟线性增长

根本原因：Decode 阶段是 memory-bound
  → 每生成一个 token 需要从 HBM 读取全部历史 KV Cache
  → KV Cache 越大（长序列 + 大 batch），读取量越大
  → 在 A100 的 ~2 TB/s 带宽下，读取 1 GB KV Cache 约需 0.5ms

排查路径：
  1. 计算 KV Cache 读取带宽需求
     KV 读取量 = batch × seq_len × num_kv_heads × head_dim × 2(K+V) × num_layers × dtype_bytes
     例如: 32 × 4096 × 8 × 128 × 2 × 60 × 2 = 32 GB per decode step
     在 2 TB/s 带宽下: 32 GB / 2 TB/s = 16 ms (decode 延迟的理论下限)

  2. 检查是否启用了 GQA
     → 如果模型使用 MHA（num_kv_heads = num_q_heads），带宽需求远大于 GQA
     → GQA 将 KV Cache 读取量减少了 group_size 倍

  3. 是否可以进一步量化 KV Cache
     → FP8: 读取量减半，解码延迟降低约 40-50%
     → KIVI 4-bit: 读取量减少 75%

解决方案：
  a) 启用 FP8 KV Cache → 带宽需求减半
  b) 如果模型支持，使用 GQA 训练的变体（无法在推理时改变）
  c) 使用 FlashInfer 后端（更优的 kernel 实现）
  d) 考虑 Prefill-Decode Disaggregation（将 decode 分摊到独立 GPU）
```

**第三层：前缀缓存效果不佳（命中率低）**

```
症状：
  - --enable-prefix-caching 已启用但 hit_rate < 0.3
  - TTFT 没有明显改善
  - KV Cache 使用率下降不明显

排查路径：
  1. 检查 system prompt 内容是否一致
     → 是否包含了时间戳、随机数、request_id 等动态内容？
     → 动态内容每请求不同 → 前缀无法匹配
     → 将动态内容移到 prompt 末尾（用户消息部分）

  2. 检查 prompt 格式
     → 不同请求的 system prompt 中是否有不可见字符差异？
     → 空格、换行符（\n vs \r\n）的差异会导致哈希不匹配
     → 使用统一的 chat template 格式化所有请求

  3. 检查 block 大小是否合适
     → block_size=16 意味着前缀至少需要 16 个连续匹配 token 才能命中
     → 如果共享前缀很短（<16 tokens），命中率为 0

解决方案：
  a) 标准化 prompt 格式（移除动态内容、统一换行符）
  b) 使用 tokenizer 编码后再比对（而非字符串比对）
  c) 减小 block_size（如 16→8）来匹配更短的前缀
  d) 在网关层对请求做路由（相同前缀→同一 vLLM 实例）
```

### 12.2 A800 部署实操：Qwen-33B 双卡 KV Cache 优化方案

以下是在 2xA800-80G 上部署 Qwen-33B 时，KV Cache 优化的完整方案和计算。

**Qwen-33B KV Cache 参数速算**：

```
模型 KV 结构:
  num_layers = 60
  num_kv_heads = 8 (GQA, 假设同 Qwen 架构)
  head_dim = 128
  dtype = FP16

单 token 全层 KV = 2 × 8 × 128 × 60 × 2 = 245,760 bytes ≈ 240 KB

不同序列长度的 KV Cache:
  1024 tokens:  1024 × 240 KB = 240 MB
  4096 tokens:  4096 × 240 KB = 960 MB ≈ 0.94 GB
  8192 tokens:  8192 × 240 KB = 1.92 GB
  16384 tokens: 16384 × 240 KB = 3.84 GB
  32768 tokens: 32768 × 240 KB = 7.68 GB
```

**显存预算与优化策略矩阵**：

```
┌──────────────────────────────────────────────────────────────────────────┐
│        Qwen-33B on 2xA800-80G — KV Cache 优化策略对比                      │
├──────────────┬──────────────┬──────────────┬──────────────┬──────────────┤
│ 策略          │ 单请求KV(4K) │ 可用KV(74GB) │ 最大并发      │ 推荐场景      │
├──────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ FP16 (基准)   │ 0.94 GB      │ 74 GB        │ ~78          │ 精度敏感       │
│ FP8          │ 0.47 GB      │ 74 GB        │ ~157         │ 推荐(H800+)   │
│ INT8         │ 0.47 GB      │ 74 GB        │ ~157         │ A800通用      │
│ KIVI 4-bit   │ 0.235 GB     │ 74 GB        │ ~314         │ 极致并发       │
│ FP16+PrefixC │ 0.94→0.5 GB* │ 74 GB        │ ~100-150*    │ 有共享前缀     │
│ FP8+PrefixC  │ 0.47→0.3 GB* │ 74 GB        │ ~200-250*    │ 最佳组合       │
│ FP8+GPTQ-W4  │ 0.47 GB      │ 74+49** GB   │ ~260         │ 单卡极致       │
└──────────────┴──────────────┴──────────────┴──────────────┴──────────────┘

* 假设 50% 前缀共享率（典型 RAG/对话场景）
** GPTQ INT4 权重节省约 49.5 GB (33B×2×0.75)，更多空间给 KV Cache
```

**推荐生产配置**：

```bash
# ==============================================================
# Qwen-33B 2xA800 生产级 KV Cache 优化配置
# ==============================================================

# 方案 A: 精度优先（FP16 权重 + FP8 KV Cache）
python -m vllm.entrypoints.openai.api_server \
    --model /models/Qwen-33B-Chat \
    --tensor-parallel-size 2 \
    --dtype bfloat16 \
    --kv-cache-dtype fp8 \
    --max-model-len 32768 \
    --gpu-memory-utilization 0.90 \
    --max-num-seqs 64 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-num-batched-tokens 8192 \
    --swap-space 16 \
    --host 0.0.0.0 --port 8000 --enable-metrics

# 方案 B: 吞吐优先（INT4 权重 + FP8 KV Cache，单卡也可尝试）
python -m vllm.entrypoints.openai.api_server \
    --model /models/Qwen-33B-Chat-GPTQ-INT4 \
    --quantization gptq \
    --kv-cache-dtype fp8 \
    --max-model-len 32768 \
    --gpu-memory-utilization 0.95 \
    --max-num-seqs 128 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-num-batched-tokens 16384 \
    --host 0.0.0.0 --port 8000 --enable-metrics
```

**KV Cache 使用率监控与告警**：

```bash
# 实时监控 KV Cache（在部署机器上运行）
watch -n 2 'curl -s localhost:8000/metrics | grep -E "
gpu_cache_usage_perc
|num_requests_running
|num_requests_swapped
|gpu_blocks_free
|prefix_cache_hit_rate
"'

# Prometheus 告警规则
# 如果 gpu_cache_usage_perc > 90%，说明 KV Cache 接近饱和
# 如果 num_requests_swapped > 0，说明有请求被换出（延迟会飙升）
# 如果 prefix_cache_hit_rate < 0.2，说明前缀缓存效果不佳
```

**启动验证清单**：

```bash
# 1. 确认服务正常启动
curl http://localhost:8000/health

# 2. 确认 KV Cache 数据类型正确
curl http://localhost:8000/metrics | grep kv_cache_dtype
# 应该显示 fp8 或 auto

# 3. 发测试请求验证精度
curl http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen-33B-Chat",
    "prompt": "法国的首都是什么？",
    "max_tokens": 10
  }'
# 检查输出是否正确（如有明显乱码 → 量化精度不足）

# 4. 查看 KV Cache 分配情况
curl http://localhost:8000/metrics | grep blocks
# gpu_blocks_total 应该接近预期值
# gpu_blocks_free 应该 > 10% 的 total

# 5. 逐步加压测试
# 从低并发开始，逐步增加到目标值的 80%
# 观察 gpu_cache_usage_perc 的上升曲线是否平滑
# 如果突然跳变 → 可能有单个长请求占满空间
```

**常见坑与解决方案**：

```
坑1: --kv-cache-dtype fp8 在 A800 上启动报错
  原因: A800 不支持 FP8（需要 H800/H100）
  解决: 使用 INT8 量化方案或升级硬件
  变通: 仍可设置 fp8 来节省显存，但没有硬件加速

坑2: 启用 FP8 后模型输出乱码
  原因: 模型权重本身也是 FP8 格式或量化校准数据不匹配
  解决: 确认 --dtype 为 bfloat16（权重），仅 --kv-cache-dtype fp8

坑3: Prefix Caching 命中率始终为 0
  原因: 请求之间共享前缀长度 < block_size (16 tokens)
  解决: 确认 system prompt 长度 > 16 tokens
        或在代码中统一使用 chat template

坑4: swap 延迟导致 P99 飙升
  原因: swap_space 太小或 PCIe 带宽不足
  解决: 增大 swap_space (至 32GB)
        或降低 max_num_seqs 减少并发避免触发 swap
```

---

## 13. 深入学习资源

### 13.1 必读论文

| 论文 | 关键贡献 | 链接 |
|------|---------|------|
| **GQA: Training Generalized Multi-Query Transformer** (Ainslie et al., 2023) | GQA 的原论文，详细分析了 MHA/MQA/GQA 的 trade-off | arxiv.org/abs/2305.13245 |
| **DeepSeek-V2: A Strong, Economical, and Efficient Mixture-of-Experts Language Model** (2024) | MLA 的完整设计和消融实验 | arxiv.org/abs/2405.04434 |
| **KIVI: A Tuning-Free Asymmetric 2bit Quantization for KV Cache** (Liu et al., 2024) | Per-channel Key + Per-token Value 量化 | arxiv.org/abs/2402.02750 |
| **FlexGen: High-Throughput Generative Inference of Large Language Models with a Single GPU** (Sheng et al., 2023) | 之字形调度和 SSD 卸载 | arxiv.org/abs/2303.06865 |
| **Efficient Memory Management for Large Language Model Serving with PagedAttention** (Kwon et al., 2023) | vLLM 的 PagedAttention 和 block 管理 | arxiv.org/abs/2309.06180 |
| **StreamingLLM: Efficient Streaming Language Models with Attention Sinks** (Xiao et al., 2023) | Attention sink 现象和 StreamingLLM | arxiv.org/abs/2309.17453 |
| **SGLang: Efficient Execution of Structured Language Model Programs** (Zheng et al., 2024) | RadixAttention 和前缀缓存优化 | arxiv.org/abs/2312.07104 |

### 13.2 代码仓库

| 仓库 | 说明 |
|------|------|
| **github.com/vllm-project/vllm** | vLLM 主仓库，PagedAttention 的工业级实现 |
| **github.com/FMInference/FlexGen** | FlexGen 官方实现，含之字形调度算法 |
| **github.com/mit-han-lab/streaming-llm** | StreamingLLM 官方实现 |
| **github.com/ModelTC/KIVI** | KIVI KV Cache 量化实现 |
| **github.com/sgl-project/sglang** | SGLang 的 RadixAttention 实现 |

### 13.3 博文和教程

- "vLLM PagedAttention 源码解读" 系列 — 深入理解 block 管理和 KV Cache 分配
- "How Continuous Batching Works" — Anyscale 官方博客
- "KV Cache Quantization" — HuggingFace 博客，对比各种量化方案的精度和速度
- NVIDIA 官方文档：TensorRT-LLM 中的 KV Cache 配置指南

### 13.4 实践检查清单

```
┌──────────────────────────────────────────────────────────────┐
│               KV Cache 优化检查清单                             │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  □ 确认模型的 GQA 配置（num_kv_heads, head_dim）               │
│  □ 计算预期的 KV Cache 大小（考虑 max_seq_len 和并发）          │
│  □ 预留 80-90% GPU 显存给模型权重 + KV Cache                   │
│  □ 评估是否需要 FP8/INT8 KV Cache 量化                         │
│  □ 检查请求的 system prompt 是否可被前缀缓存复用                 │
│  □ 启用 vLLM 的 --enable-prefix-caching                       │
│  □ 配置 Prometheus + Grafana 监控 KV Cache 使用率              │
│  □ 设置 KV Cache 使用率告警阈值（建议 90%）                      │
│  □ 压测验证：逐步增加并发，观察 KV Cache 使用率和延迟             │
│  □ 对比不同配置的吞吐量和 P99 延迟                              │
│  □ 记录生产环境的 KV Cache 指标用于容量规划                      │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

> **文档版本**: v1.0 | **适用范围**: vLLM 0.5.0+ | **最后更新**: 2026-07
> 
> 本文档是推理方向（Direction B）学习材料的第四篇。下一篇将深入介绍 **量化推理（Quantization Inference）**，涵盖 GPTQ、AWQ、GGUF 等主流量化方案及其在 vLLM 中的部署实践。
