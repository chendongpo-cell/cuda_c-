# LLM 推理调度策略：从排队论到工程实践

> **目标读者**：具备基础深度学习知识，正在部署生产级 LLM 服务的工程师。
> **前置知识**：理解 Transformer 自回归生成、KV Cache、vLLM 基本架构。
> **学习方式**：慢速精读，每个公式动手推导，每段伪代码尝试手写实现。
> **适用场景**：部署 33B/67B 模型、对接 Claude Code Agent 工作流、构建 RAG 服务。

---

## 白话引入：急诊室分诊的故事

深夜，三辆救护车同时冲进急诊室大门。

第一辆车推下来一位心梗患者——黄金抢救时间只有 90 分钟，必须立刻进手术室。第二辆车是一位手臂骨折的建筑工人——疼痛难忍，应该尽快处理。第三辆车是一位持续低烧三天的感冒患者——不舒服，但没有生命危险。

你如果是急诊室唯一的护士（调度器），你怎么安排？显然不是"先到先看"——感冒患者先到，但如果他占着医生，心梗患者可能在排队中去世。你需要的是一套**分诊（Triage）**策略：根据病情的严重程度（优先级）来决定谁先得到医生的时间，而不是单纯按挂号顺序。

**LLM 推理调度就是 GPU 的"分诊台"。**

每个推理请求带着不同长度的 prompt（系统提示词 + 上下文 + 用户输入）涌入 GPU。有的请求 prompt 只有 50 个 token（像感冒，轻量快捷），有的携带着 8000 个 token 的长文档（像骨折，需要较多处理时间）。如果使用最简单的 FCFS（先来先服务），一个长 prompt 请求可能把后面所有的短请求都堵死——这就是"头阻塞"（Head-of-Line Blocking）。

更重要的是，推理请求有心梗 vs 感冒的本质区别：

- **Prefill 阶段**（并行处理所有 prompt token）：Compute-Bound，像心脏手术——需要 GPU 算力全开，但一般很快完成。
- **Decode 阶段**（逐个 token 生成）：Memory-Bound，像术后观察——持续占用 GPU 的显存带宽，可能持续数分钟。

好的调度器要同时应对这两种需求：让新请求尽快"入院"（低 TTFT），同时让已在"住院"的请求平稳生成（低 TPOT）——还要确保 GPU 这位"医生"始终在忙，不空等。

本文从排队论的数学基础出发，深入剖析 vLLM 调度器的每一个设计决策——Prefill-First 调度、Chunked Prefill、抢占机制（Swap / Recompute）、前缀缓存优化——让读者能从第一性原理理解 LLM 推理服务的性能行为。

---

## 术语预检

在深入学习前，确保你理解以下核心术语：

| 术语 | 英文 | 一句话解释 |
|------|------|-----------|
| **TTFT** | Time To First Token | 用户发送请求到收到第一个 token 的延迟。相当于急诊室"从挂号到见到医生"的时间 |
| **TPOT** | Time Per Output Token | 第一个 token 之后，每个后续 token 的平均生成间隔。相当于"医生每写一个字的时间" |
| **Continuous Batching** | Continuous Batching | 每次迭代动态调整 batch 内容，有请求完成立即踢出、有新请求立即加入，而非等整批一起完成 |
| **Chunked Prefill** | Chunked Prefill | 将长 prompt 的 Prefill 拆成多个小块，穿插在 Decode 之间执行，避免一个长 prompt 阻塞所有请求 |
| **Preemption（抢占）** | Preemption | 当 GPU 显存不足时，强制暂停某些正在处理的请求，释放其 KV Cache 来接收新请求 |
| **Prefix Caching** | Prefix Caching (APC) | 自动检测多个请求的公共前缀 prompt（如 system prompt），第一个请求计算后缓存 KV，后续直接复用，跳过重复 Prefill |
| **PagedAttention** | PagedAttention | 将 KV Cache 划分为固定大小的"页"（Block），类似操作系统虚拟内存，解决显存碎片和浪费问题 |
| **KV Cache** | Key-Value Cache | Transformer 推理中缓存的 Key 和 Value 张量，避免每个 Decode 步都重新计算历史 token 的注意力 |
| **Roofline Model** | Roofline Model | 分析计算任务瓶颈在算力（FLOPS）还是带宽（Memory BW）的模型，用于判断 Prefill/Decode 的优化方向 |
| **MLFQ** | Multi-Level Feedback Queue | 多级反馈队列：多个优先级队列，请求在用完时间片后降级，定期提升以防止饥饿 |

---

## 目录

1. [排队论基础与推理系统](#1-排队论基础与推理系统)
2. [调度目标的严格定义](#2-调度目标的严格定义)
3. [调度算法全景对比](#3-调度算法全景对比)
4. [Prefill-Decode 平衡的艺术](#4-prefill-decode-平衡的艺术)
5. [抢占机制深度剖析](#5-抢占机制深度剖析)
6. [前缀缓存对调度的影响](#6-前缀缓存对调度的影响)
7. [真实工作负载模式](#7-真实工作负载模式)
8. [实战调优指南](#8-实战调优指南)
9. [易混淆技术辨析](#9-易混淆技术辨析)
10. [AI Infra 专家视角](#10-ai-infra-专家视角)
11. [深入学习资源](#11-深入学习资源)

---

## 1. 排队论基础与推理系统

### 1.1 为什么推理调度需要排队论？

LLM 推理服务本质上是一个**排队系统**。将抽象问题建模为排队系统，我们才能用数学语言精确描述延迟、吞吐和容量规划之间的关系。

```
    请求到达                    排队等待                    开始服务                    服务完成
   (lambda req/s)              (队列 Q)                    (GPU 计算)                 (返回结果)
       │                                                      │
       ▼                                                      ▼
   ┌───────┐     ┌───────┐     ┌───────┐     ┌───────┐     ┌───────┐
   │ 用户A │────▶│       │────▶│       │────▶│       │────▶│ 响应A │
   └───────┘     │       │     │       │     │       │     └───────┘
   ┌───────┐     │ 等待  │     │ GPU0  │     │ 输出  │     ┌───────┐
   │ 用户B │────▶│ 队列  │────▶│ GPU1  │────▶│ 队列  │────▶│ 响应B │
   └───────┘     │       │     │ GPU2  │     │       │     └───────┘
   ┌───────┐     │       │     │ GPU3  │     │       │     ┌───────┐
   │ 用户C │────▶│       │────▶│       │────▶│       │────▶│ 响应C │
   └───────┘     └───────┘     └───────┘     └───────┘     └───────┘
       │            │               │               │            │
       └──── 到达过程 ────┘    └─── 服务过程 ───┘    └──── 离开过程 ────┘
```

请求以某种速率 lambda 到达，系统以某种速率 mu 服务它们。当 lambda > mu 时，队列无限增长；当 lambda < mu 时，系统稳定但存在等待时间。

### 1.2 M/M/1 排队模型

**M/M/1 是最基础的排队模型**，每个字母的含义：
- **M** (Markovian/Memoryless)：到达过程是泊松过程——间隔时间服从指数分布
- **M** (Markovian/Memoryless)：服务时间服从指数分布
- **1**：单个服务器

#### 核心符号定义

| 符号 | 含义 | 推理系统中的对应 |
|------|------|-----------------|
| lambda | 平均到达率 (req/s) | 用户请求 QPS |
| mu    | 平均服务率 (req/s) | GPU 每秒能完成的请求数 |
| rho   | 利用率 = lambda/mu | GPU 使用率 |
| L     | 系统中平均请求数（队列+服务中） | 排队的请求 + 正在生成的请求 |
| Lq    | 队列中平均请求数 | 等待被调度的请求 |
| W     | 系统中平均等待时间 | 端到端延迟 |
| Wq    | 队列中平均等待时间 | 排队延迟 |

#### 核心公式推导

对于 M/M/1 系统，稳态下的关键公式：

```
利用率：                  rho = lambda / mu

系统中平均请求数：        L = rho / (1 - rho)

队列中平均请求数：        Lq = rho^2 / (1 - rho)

系统中平均时间：          W = 1 / (mu - lambda)

队列中平均时间：          Wq = rho / (mu - lambda)
```

**手工推导 L = rho/(1-rho)**：

```
稳态概率：Pn = (1-rho) * rho^n     （系统中有 n 个请求的概率）

L = sum(n=0 to inf) n * Pn
  = sum(n=0 to inf) n * (1-rho) * rho^n
  = (1-rho) * sum(n=0 to inf) n * rho^n
  = (1-rho) * rho/(1-rho)^2           （几何级数求和公式）
  = rho / (1-rho)
```

### 1.3 "冰球棍"效应 (Hockey Stick)

这是生产系统中最危险的曲线。当 rho 趋近于 1，L 和 W 都趋向无穷大：

```
      L (平均队列长度)
      │
  100 │                                                          *
      │                                                      *
   90 │                                                   *
      │                                                *
   80 │                                             *
      │                                          *
   70 │                                      *
      │                                   *
   60 │                                *
      │                             *
   50 │                          *
      │                       *
   40 │                    *
      │                 *
   30 │              *
      │           *
   20 │        *
      │     *
   10 │  *
      │*
    0 ├────┬────┬────┬────┬────┬────┬────┬────┬────┬────► rho
      0   0.1  0.2  0.3  0.4  0.5  0.6  0.7  0.8  0.9  1.0

      ┌──────────────────────────────────────────────────────┐
      │  rho=0.5  ->  L=1       (1个请求在系统中)            │
      │  rho=0.7  ->  L=2.33    (可接受)                    │
      │  rho=0.8  ->  L=4       (开始恶化)                   │
      │  rho=0.9  ->  L=9       (明显排队)                   │
      │  rho=0.95 ->  L=19      (严重拥堵)                   │
      │  rho=0.99 ->  L=99      (灾难性)                     │
      └──────────────────────────────────────────────────────┘
```

**关键工程启示**：

```
对于 LLM 推理服务：
  - rho < 0.5  ：过度配置，成本浪费
  - 0.5 < rho < 0.7 ：健康运行区间
  - 0.7 < rho < 0.8 ：可接受，但需要监控 P99
  - 0.8 < rho < 0.9 ：危险区间，P99 开始指数增长
  - rho > 0.9  ：不可接受，随机一个流量尖峰就会击穿系统
```

**为什么 rho=0.8 是"魔法数字"？**

```
rho=0.8 时：
  L  = 0.8/0.2 = 4              （平均4个请求在系统中）
  W  = 1/(mu-lambda) = 1/(mu-0.8mu) = 5/mu  （5倍服务时间的延迟）

rho=0.9 时：
  L  = 0.9/0.1 = 9              （平均9个请求，翻倍多）
  W  = 1/(mu-lambda) = 10/mu     （10倍服务时间的延迟，翻倍）

rho=0.95 时：
  L  = 0.95/0.05 = 19
  W  = 1/(mu-lambda) = 20/mu     （20倍！）
```

### 1.4 M/M/c 多服务器模型

在多 GPU 部署中，系统退化为 M/M/c：

```
        ┌─────────┐
   lambda ──▶│ 调度器  │
        └────┬────┘
             │
      ┌──────┼──────┬──────┐
      ▼      ▼      ▼      ▼
   ┌────┐ ┌────┐ ┌────┐ ┌────┐
   │GPU0│ │GPU1│ │GPU2│ │GPU3│   c = 4 个服务器
   └────┘ └────┘ └────┘ └────┘
      │      │      │      │
      └──────┴──────┴──────┘
                 │
                 ▼
              输出汇总
```

**M/M/c 关键公式**：

```
单服务器利用率：  rho = lambda / (c * mu)

所有服务器都忙的概率（Erlang-C 公式）：

                                   (c*rho)^c    1
    P(queueing) = ────────────────────────── * ───
                                (c*rho)^c       c!   1-rho
                  (1-rho)*sum(k=0 to c-1) ───── + ──────
                                   k!         (1-rho)

平均队列长度：
                  rho * P(queueing)
    Lq = ──────────────────────
                   1 - rho

平均等待时间：
                 P(queueing)
    Wq = ──────────────────────
                c * mu * (1-rho)
```

**多 GPU 部署的关键洞察**：

```
┌──────────────────────────────────────────────────────────────────┐
│  场景对比 (lambda=10 req/s, mu=2 req/s per GPU)                 │
│                                                                  │
│  单 GPU (c=1):  需要 mu_total=10 -> 需要5倍算力，不可能          │
│  4 GPU (c=4):   rho=10/(4*2)=1.25 > 1，系统不稳定                │
│  6 GPU (c=6):   rho=10/(6*2)=0.833，正常运行                     │
│  8 GPU (c=8):   rho=10/(8*2)=0.625，有余量                      │
│                                                                  │
│  结论：多 GPU 不仅增加吞吐，还降低每 GPU 的利用率要求，           │
│        从而大幅降低排队延迟                                       │
└──────────────────────────────────────────────────────────────────┘
```

### 1.5 真实场景的 lambda 估算

不同业务场景的请求到达率：

```
场景                    典型 lambda      峰值 lambda       lambda/mu 关系
─────────────────────────────────────────────────────────────────
内部开发工具             0.1-1 req/s      2-5 req/s        宽松
客服 ChatBot             1-10 req/s       20-50 req/s      需关注峰值
代码助手 (IDE)           5-20 req/s       50-100 req/s     高并发
对外 API 服务            10-100 req/s     200-500 req/s    必须多 GPU
批处理任务               N/A (自定节奏)   N/A              吞吐优先
Agent 工作流             0.5-5 req/s      10-20 req/s      长尾延迟敏感
```

**用 Python 模拟 M/M/1 队列以建立直觉**：

```python
import numpy as np

def simulate_mm1(lambda_rate, mu_rate, sim_time=10000):
    """
    模拟 M/M/1 队列
    lambda_rate: 到达率 (req/s)
    mu_rate: 服务率 (req/s)
    """
    t = 0.0
    queue = []  # 到达时间的队列
    in_service = False
    service_start = 0.0
    wait_times = []

    while t < sim_time:
        # 泊松到达：下一个到达时间 ~ Exp(1/lambda)
        next_arrival = t + np.random.exponential(1.0 / lambda_rate)
        service_time = np.random.exponential(1.0 / mu_rate)

        if not in_service:
            if len(queue) == 0:
                # 直接服务
                in_service = True
                service_start = next_arrival
                service_end = service_start + service_time
                wait_times.append(0.0)
            t = next_arrival
        else:
            if next_arrival < service_end:
                # 到达时正在服务，加入队列
                queue.append(next_arrival)
                t = next_arrival
            else:
                # 服务完成
                in_service = False
                t = service_end

    return np.mean(wait_times), len(wait_times)

# 测试不同利用率
for rho in [0.3, 0.5, 0.7, 0.8, 0.9, 0.95]:
    mu = 1.0
    lam = rho * mu
    avg_wait, n_reqs = simulate_mm1(lam, mu, sim_time=50000)
    theoretical_w = rho / (mu - lam)
    print(f"rho={rho:.2f}: 模拟等待={avg_wait:.3f}s, 理论等待={theoretical_w:.3f}s")
```

输出示例：

```
rho=0.30: 模拟等待=0.422s, 理论等待=0.429s
rho=0.50: 模拟等待=0.987s, 理论等待=1.000s
rho=0.70: 模拟等待=2.310s, 理论等待=2.333s
rho=0.80: 模拟等待=3.950s, 理论等待=4.000s
rho=0.90: 模拟等待=8.920s, 理论等待=9.000s
rho=0.95: 模拟等待=18.761s, 理论等待=19.000s
```

**警告**：rho=0.95 时平均等待已达 19 秒，这是均值——P99 可能超过 60 秒。

---

## 2. 调度目标的严格定义

### 2.1 TTFT (Time To First Token)

```
                     TTFT
        │◄──────────────────────────►│
        │                            │
   ┌────┴────┐                  ┌────┴────┐
   │ 请求到达 │                  │ 首 token │
   │  t_arr  │                  │  t_first │
   └─────────┘                  └─────────┘
        │                            │
        │  ┌─────────────────────┐   │
        │  │  排队等待 + Prefill  │   │
        │  │  (计算所有 prompt    │   │
        │  │   token 的 KV cache) │   │
        │  └─────────────────────┘   │
        ▼                            ▼
   ─────●────────────────────────────●───────────────────▶ 时间轴
        t_arr                       t_first
```

**严格定义**：

```
TTFT = t_first_token - t_arrival

其中：
  t_arrival      : 请求到达调度器的时间戳
  t_first_token  : 第一个生成的 token 返回给客户端的时间戳

TTFT = 排队时间 + Prefill 时间 + 调度开销
     = Wq        + T_prefill   + epsilon

T_prefill ≈ (num_prompt_tokens * time_per_prefill_token)
          ≈ (num_prompt_tokens * 2 * num_layers * hidden_dim^2) / GPU_FLOPS
```

**TTFT 为什么重要**：

```
用户体验的心理学阈值：
  TTFT < 100ms   ：感觉即时，如本地应用
  TTFT < 500ms   ：可接受，如优质网页加载
  TTFT < 1s      ：勉强可用，流式输出必须有
  TTFT < 3s      ：明显延迟，用户可能不耐烦
  TTFT > 5s      ：不可接受，用户会怀疑系统卡死
```

**测量代码**：

```python
import time
from dataclasses import dataclass, field
from typing import List

@dataclass
class RequestMetrics:
    request_id: str
    arrival_time: float = field(default_factory=time.time)
    first_token_time: float = 0.0
    completion_time: float = 0.0
    prompt_tokens: int = 0
    output_tokens: List[float] = field(default_factory=list)  # 每个 token 的生成时间戳

    @property
    def ttft(self) -> float:
        """Time To First Token in seconds"""
        return self.first_token_time - self.arrival_time

    @property
    def tpot(self) -> float:
        """Time Per Output Token (average) in ms"""
        if len(self.output_tokens) < 2:
            return 0.0
        intervals = [self.output_tokens[i] - self.output_tokens[i-1]
                     for i in range(1, len(self.output_tokens))]
        return 1000 * sum(intervals) / len(intervals)  # 转换为 ms

    @property
    def total_latency(self) -> float:
        return self.completion_time - self.arrival_time

# 在推理循环中记录：
def record_metrics(request_id: str, metrics_store: dict):
    """在每个 token 生成时调用"""
    now = time.time()
    m = metrics_store[request_id]
    if len(m.output_tokens) == 0:
        m.first_token_time = now  # 记录 TTFT
    m.output_tokens.append(now)
```

### 2.2 TPOT (Time Per Output Token)

```
                                          TPOT
              │◄─────────────────────────────────────────────────►│
              │ 每个 decode step 的间隔时间（理想情况下恒定）      │
              │                                                   │
   ┌──────────┴──────────┐     ┌──────────┐     ┌──────────┐     │
   │   生成 Token #1     │────▶│ Token #2 │────▶│ Token #3 │ ... │
   │   (TTFT 结束点)     │     └──────────┘     └──────────┘     │
   └─────────────────────┘     ▲                              ▲   │
              │                │                              │   │
              ▼                │◄──── TPOT ────►│            │   │
   ───────────●────────────────●───────────────●─────────────●───▶ 时间
            t_first          t_tok2          t_tok3        t_tok4

   TPOT = (t_completion - t_first_token) / (num_output_tokens - 1)
```

**严格定义**：

```
TPOT = sum(i=1 to n-1) (t_token_{i+1} - t_token_i) / (n-1)

在连续批处理 (Continuous Batching) 中，TPOT 波动来自：
  - 同一批次中其他请求的 prefill 抢占
  - 批次大小的变化
  - GPU 内存带宽争用

理想 TPOT (无干扰)：
  TPOT_ideal = time_per_decode_step / batch_size_effective

实际 TPOT：
  TPOT_actual = TPOT_ideal + scheduling_overhead + prefill_interference
```

**TPOT 为什么重要**：

```
场景分析：
  短输出 (50 tokens)：TTFT 占主导，TPOT 次要
  长输出 (2000+ tokens)：TPOT 成为用户体验的核心

  举例：生成 2000 tokens
    TPOT = 20ms -> 总 decode 时间 = 40s
    TPOT = 40ms -> 总 decode 时间 = 80s   <-- 不可接受
    TPOT = 50ms -> 总 decode 时间 = 100s  <-- 用户放弃

  代码生成、长文写作场景下，TPOT 是核心指标。
```

### 2.3 吞吐量 (Throughput)

**两种吞吐量指标**：

```
Token 吞吐量：
  Throughput_tokens = total_tokens_generated / time_window
  单位：tokens/s

  例：10分钟内生成 600,000 tokens -> 1000 tokens/s

请求吞吐量：
  Throughput_requests = total_requests_completed / time_window
  单位：req/s

  注意：token 吞吐量更有意义，因为不同请求的 token 数差异大
```

**吞吐量和延迟的关系——Little 定律**：

```
Little 定律： L = lambda * W

在推理系统中：
  平均并发请求数 = 到达率 * 平均延迟

  例：lambda = 10 req/s, W = 5s -> L = 50 个并发请求
  这意味着系统平均有 50 个请求同时在处理/排队中

推论：要支持更高的到达率，要么降低 W（更快完成），
      要么增加并发能力（更多 GPU / 更大批次）。
```

### 2.4 公平性指标

**Jain 公平指数**：

```
                         (sum_{i=1 to n} x_i)^2
    J(x_1, x_2, ..., x_n) = ─────────────────
                         n * sum_{i=1 to n} x_i^2

其中 x_i 是分配给请求 i 的资源比例。

J = 1.0  ：完全公平（所有请求获得相同资源）
J = 1/n  ：完全不公平（一个请求独占所有资源）
J = k/n  ：k 个请求平等分享，其余饥饿
```

**示例计算**：

```python
def jain_fairness_index(allocations):
    """
    allocations: list of resource shares per request
    返回: Jain 公平指数 [1/n, 1.0]
    """
    n = len(allocations)
    sum_x = sum(allocations)
    sum_x2 = sum(x**2 for x in allocations)
    return (sum_x ** 2) / (n * sum_x2)

# 4个请求，资源分配
print(jain_fairness_index([0.25, 0.25, 0.25, 0.25]))  # 1.000 完全公平
print(jain_fairness_index([0.50, 0.30, 0.15, 0.05]))  # 0.778 不公平
print(jain_fairness_index([1.00, 0.00, 0.00, 0.00]))  # 0.250 极端不公平
```

**Max-Min 公平性**：

```
算法：
1. 将所有请求的资源分配初始化为 0
2. 按需求从小到大排序
3. 将可用资源均分给所有未满足的请求
4. 如果某个请求的需求被满足，将其移出池子
5. 重复 3-4，直到所有资源分配完毕

直觉：小需求优先满足，剩余资源均分给大需求。
```

### 2.5 延迟 SLA (Service Level Agreement)

```
典型 LLM 推理 SLA 设定：

┌───────────────┬────────────┬────────────┬────────────┐
│    场景       │  P50 TTFT  │  P95 TTFT  │  P99 TTFT  │
├───────────────┼────────────┼────────────┼────────────┤
│ 实时对话      │  < 200ms   │  < 500ms   │  < 1s      │
│ 代码补全      │  < 100ms   │  < 300ms   │  < 500ms   │
│ 文档摘要      │  < 1s      │  < 3s      │  < 5s      │
│ 批量处理      │  无要求    │  < 30s     │  < 60s     │
│ Agent 工具调用 │  < 500ms   │  < 2s      │  < 5s      │
└───────────────┴────────────┴────────────┴────────────┘

┌───────────────┬────────────┬────────────┬────────────┐
│    场景       │  P50 TPOT  │  P95 TPOT  │  P99 TPOT  │
├───────────────┼────────────┼────────────┼────────────┤
│ 实时对话      │  < 20ms    │  < 40ms    │  < 60ms    │
│ 代码补全      │  < 15ms    │  < 30ms    │  < 50ms    │
│ 长文生成      │  < 30ms    │  < 50ms    │  < 80ms    │
└───────────────┴────────────┴────────────┴────────────┘
```

### 2.6 加权公平队列 (Weighted Fair Queueing)

在需要区分优先级的系统中（付费用户 vs 免费用户，紧急请求 vs 普通请求），使用 WFQ：

```
                     ┌──────────────────────────────┐
         请求到达 ──▶│         分类器               │
                     └──────────┬───────────────────┘
                                │
              ┌─────────────────┼─────────────────┐
              ▼                 ▼                  ▼
        ┌──────────┐     ┌──────────────┐   ┌──────────────┐
        │ 优先级 1  │     │  优先级 2    │   │  优先级 3    │
        │ weight=4  │     │  weight=2    │   │  weight=1    │
        │ (VIP用户) │     │ (普通付费)   │   │ (免费用户)   │
        └─────┬─────┘     └──────┬───────┘   └──────┬───────┘
              │                  │                    │
              └──────────────────┼────────────────────┘
                                 │
                                 ▼
                     ┌──────────────────────┐
                     │  WFQ 调度器           │
                     │  虚拟时间戳调度       │
                     └──────────────────────┘

每个请求获得的服务速率：
  r_i = (weight_i / sum of weights) * mu_total

在推理系统中：
  r_i 转化为"该优先级每秒可用的 token 预算"
  高优先级请求的 prefill 和 decode 都获得更多 GPU 时间片
```

---

## 3. 调度算法全景对比

### 3.1 核心算法对比表

```
┌────────────────┬──────────────┬──────────────┬──────────────┬────────────────────────┐
│    算法        │    TTFT      │   吞吐量     │   公平性     │   实现复杂度            │
├────────────────┼──────────────┼──────────────┼──────────────┼────────────────────────┤
│ FCFS           │ 差（头阻塞） │ 好           │ 公平         │ 极简单（队列）          │
│ (先来先服务)   │ 长请求阻塞   │ 无调度开销   │ 按到达顺序   │                        │
│                │ 后面所有请求 │              │              │                        │
├────────────────┼──────────────┼──────────────┼──────────────┼────────────────────────┤
│ Prefill-First  │ 好           │ 好           │ 偏向短 prompt│ 中等                    │
│ (vLLM 默认)    │ 新请求不等待 │ 保持 GPU 忙  │ 长 prompt 等 │ 需区分 prefill/decode   │
│                │ 长 decode    │              │ 待更久      │                        │
├────────────────┼──────────────┼──────────────┼──────────────┼────────────────────────┤
│ Shortest-First │ 最好         │ 好           │ 差（饥饿）   │ 需估计服务时间          │
│ (最短优先)     │ 短请求快速   │ 短请求周转快 │ 长请求可能   │ prompt 长度作代理        │
│                │ 完成         │              │ 永远等待     │                        │
├────────────────┼──────────────┼──────────────┼──────────────┼────────────────────────┤
│ Round-Robin    │ 差           │ 差           │ 完美         │ 简单                    │
│ (轮转)         │ 频繁上下文   │ 频繁切换     │ 每请求等量   │ 需维护时间片            │
│                │ 切换开销大   │ 开销大       │ 时间片       │                        │
├────────────────┼──────────────┼──────────────┼──────────────┼────────────────────────┤
│ Priority Queue │ 可配置       │ 好           │ 可配置       │ 中等                    │
│ (优先级队列)   │ 高优快低优慢 │ 有调度开销   │ 按权重分配   │ 需维护多队列            │
├────────────────┼──────────────┼──────────────┼──────────────┼────────────────────────┤
│ MLFQ           │ 好           │ 好           │ 较好         │ 高                      │
│ (多级反馈队列) │ 自适应优先级│ 自适应       │ 防止饥饿     │ 需跟踪请求历史          │
└────────────────┴──────────────┴──────────────┴──────────────┴────────────────────────┘
```

### 3.2 FCFS (First Come First Served) —— 最基础

**ASCII 时间线示例**：

```
请求A (长prompt 5000 tok, 短输出 100 tok)
请求B (短prompt 100 tok,  短输出 50 tok)
请求C (短prompt 200 tok,  短输出 80 tok)

到达顺序: A -> B -> C (几乎同时)

FCFS 时间线：
═══════════════════════════════════════════════════════════════════
时间 >  0s        2s        4s        6s        8s       10s
        │         │         │         │         │         │
请求A:  │███████████████████│░░░░░░░░░░░░░░░░░░░░░░░░░░░░│
        │   Prefill 2.5s   │    Decode 100 tok * 30ms    │
        │                  │         = 3.0s              │
        └──────────────────┴─────────────────────────────┘
                                      完成 @ 5.5s
请求B:  [──────────────── 等待 5.5s ─────────────────]│██│░░░░░│
                                                      Prefill  Decode
                                                      0.05s    1.5s
                                      完成 @ 7.05s

请求C:  [────────────── 等待 7.05s ──────────────────────]│███│░░░░│
                                                          Prefill Decode
                                                          0.1s   2.4s
                                      完成 @ 9.55s
═══════════════════════════════════════════════════════════════════

平均 TTFT：
  A: 2.5s (prefill)
  B: 5.55s <-- 被 A 阻塞，不可接受
  C: 7.15s <-- 更差

关键问题：头阻塞 (Head-of-Line Blocking)
  - 一个长请求阻塞了后面所有短请求
  - 没有利用 GPU 并行处理的能力
```

### 3.3 Prefill-First (vLLM 默认策略)

核心思想：在每轮调度中，优先调度 prefill 阶段的请求，使其尽快进入 decode 阶段。

```
┌──────────────────────────────────────────────────────────────┐
│                  vLLM Scheduler 每轮决策逻辑                   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  1. 检查等待队列中是否有新请求                                │
│  2. 如果有可用 KV Cache 块 + token 预算：                     │
│     -> 调度新请求的 prefill（直到达到 max_num_batched_tokens） │
│  3. 对已在 decode 阶段的请求：                                │
│     -> 每个请求生成 1 个 token（或达到 max_num_seqs）          │
│  4. 如果有请求完成 -> 释放 KV cache 块                        │
│  5. 如果 KV cache 不足 -> 触发抢占                            │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**ASCII 时间线（与 FCFS 相同的请求）**：

```
Prefill-First 时间线：
═══════════════════════════════════════════════════════════════════
时间 >  0s        1s        2s        3s        4s        5s

Step 0: 所有请求在等待队列
  [A(5000tok), B(100tok), C(200tok)]

Step 1: 调度 prefill — 全部三个一次调起 (max_num_batched_tokens=8192)
  请求A: │████████████████████│  prefill 5000 tok
  请求B: │██│                      prefill 100 tok  <-- 很快完成
  请求C: │████│                    prefill 200 tok  <-- 也很快完成

Step 1.5: Prefill 完成，所有进入 decode
  请求A: │████████████████████│░░░░░░░░░░░░░░░░░░░░░░░░░░│
  请求B: │██│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│
  请求C: │████│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│

  注意：B 和 C 的 prefill 很快完成，不需要等待 A 的 prefill 完成
        （因为在同一个 prefill batch 中并行处理）

平均 TTFT：
  A: ~2.5s (prefill 5000 tok)
  B: ~0.05s <-- 极快！
  C: ~0.1s  <-- 极快！
═══════════════════════════════════════════════════════════════════

对比：
  FCFS:          TTFT_B = 5.55s,  TTFT_C = 7.15s
  Prefill-First: TTFT_B = 0.05s,  TTFT_C = 0.1s
  改进: 100x+
```

**Prefill-First 的问题**：

```
当 decode 阶段有很多请求时，新请求的 prefill 会与 decode 竞争资源：

┌─────────────────────────────────────────────────────────┐
│  场景：已有 32 个请求在 decode，新来 1 个 prefill 请求   │
│                                                         │
│  Prefill batch: 新请求 (1000 tok) + 32 decode tok        │
│  -> GPU 需要同时处理 1032 个 token                        │
│  -> Prefill 是 compute-bound，受益于大 batch              │
│  -> Decode 是 memory-bandwidth-bound，批次增大会降低 TPOT │
│                                                         │
│  折中：                                                 │
│  - 如果 max_num_batched_tokens=4096, 可以全调度          │
│  - 但 decode 的 TPOT 会暂时上升                          │
│  - 不影响最终延迟，但会有"卡顿感"                        │
└─────────────────────────────────────────────────────────┘
```

### 3.4 Shortest-First (最短作业优先)

**在推理中的独特挑战**：我们不知道"服务时间"——但我们知道 prompt 长度。

```
服务时间估计（代理变量）：
  T_service ≈ T_prefill + T_decode
  T_prefill 正比于 num_prompt_tokens     （近似线性）
  T_decode   正比于 num_output_tokens     （未知！）

  -> 只知道 prompt 长度，不知道输出长度
  -> 但通常 long prompt 不等于 long output（例如摘要任务）
  -> 所以 prompt 长度是一个"还行"的代理变量
```

**饥饿问题与解决方案**：

```
Shortest-First 的问题：长 prompt 请求可能永远得不到服务

解决方案 — 老化 (Aging)：
  ┌─────────────────────────────────────────────┐
  │  每个请求有一个"虚拟服务时间"               │
  │  virtual_time = estimated_service_time     │
  │               - aging_factor * wait_time    │
  │                                             │
  │  等待时间越长，virtual_time 越小            │
  │  最终长请求也会被调度                        │
  └─────────────────────────────────────────────┘

伪代码：
  for req in waiting_queue:
      req.priority_score = req.num_prompt_tokens - AGING_FACTOR * req.wait_time
  schedule = sorted(waiting_queue, key=lambda r: r.priority_score)[:max_batch]
```

### 3.5 MLFQ (Multi-Level Feedback Queue) 在推理中的应用

```
                        ┌──────────────────────┐
           新请求 ─────▶│  Q0: Prefill 队列     │
                        │  时间片: 1000 tok     │
                        │  最高优先级           │
                        └──────────┬───────────┘
                                   │ 完成 prefill 后降级
                                   ▼
                        ┌──────────────────────┐
                        │  Q1: Decode 队列      │
                        │  时间片: 50 tok       │
                        │  中等优先级           │
                        └──────────┬───────────┘
                                   │ 长时间运行后降级
                                   ▼
                        ┌──────────────────────┐
                        │  Q2: 长解码队列       │
                        │  时间片: 200 tok      │
                        │  最低优先级           │
                        │  (有老化机制防饥饿)   │
                        └──────────────────────┘

MLFQ 规则：
  规则1: 如果 Priority(A) > Priority(B)，调度 A
  规则2: 如果 Priority(A) == Priority(B)，轮转调度
  规则3: 新请求进入最高优先级队列
  规则4: 用完时间片后，降级到下一优先级队列
  规则5: 定期将所有请求提升到最高优先级（防止饥饿）
```

**MLFQ 对推理的意义**：

```
优势：
  - 新请求（prefill）获得高优先级 -> 低 TTFT
  - decode 请求自然降级，但不饥饿
  - 自适应：不需要预先知道哪个请求"短"
  - 天然区分 compute-bound (prefill) 和 memory-bound (decode)

挑战：
  - 实现复杂，需要维护多级队列
  - 时间片大小需要根据模型和硬件调优
  - 对 KV cache 管理有额外要求
```

### 3.6 各算法的实验对比

**典型基准测试结果**（A100-80G, Llama-2-70B, 混合 prompt 长度 100-4000 tok）：

```
┌────────────────────┬──────────┬──────────┬──────────┬──────────┐
│      算法          │ 平均TTFT │ P95 TTFT │ 吞吐量   │ 公平指数 │
│                    │   (s)    │   (s)    │(tok/s)   │  (Jain)  │
├────────────────────┼──────────┼──────────┼──────────┼──────────┤
│ FCFS               │   4.2    │  15.3    │  1840    │  0.95    │
│ Prefill-First      │   1.8    │   4.2    │  1920    │  0.88    │
│ Shortest-First     │   1.2    │   2.8    │  1950    │  0.62    │
│ (w/ aging)         │   1.5    │   3.1    │  1930    │  0.82    │
│ Round-Robin        │   5.8    │  12.1    │  1450    │  0.99    │
│ Priority (3级)     │   1.6    │   3.5    │  1900    │  0.85    │
│ MLFQ (3级)         │   1.4    │   2.9    │  1910    │  0.90    │
└────────────────────┴──────────┴──────────┴──────────┴──────────┘
```

---

## 4. Prefill-Decode 平衡的艺术

### 4.1 根本矛盾

```
┌─────────────────────────────────────────────────────────────────┐
│                     PREFILL vs DECODE                           │
├────────────────────────────────┬────────────────────────────────┤
│          PREFILL               │           DECODE               │
├────────────────────────────────┼────────────────────────────────┤
│ 处理所有 prompt token（并行）  │ 逐个生成 token（串行）         │
│ Compute-bound（矩阵乘法密集）  │ Memory-bandwidth-bound          │
│                                │ （读取 KV Cache 和权重）        │
│ FLOPs 正比于 O(L^2)            │ FLOPs 正比于 O(L) per token     │
│ 大batch效率高                  │ 小batch延迟好                   │
│ 需要大量临时显存               │ 显存由 KV Cache 主导            │
│ 可并行处理多个 prompt          │ 每个 decode 独立但共享权重      │
└────────────────────────────────┴────────────────────────────────┘
```

**Roofline 模型视角**（ASCII 图示）：

```
                             Roofline Model
   可达到的 FLOPs
        ▲
        │
  Peak  │  ╔══════════════════════════════════════════════╗
  FLOPS │  ║          Compute Bound 区域                   ║
        │  ║  ┌───┐                                        ║
        │  ║  │   │  <-- Prefill 在此 (高算术强度)          ║
        │  ║  │ P │    Arithmetic Intensity ≈ O(batch*seq)  ║
        │  ║  │   │    -> 接近 Peak FLOPS                   ║
        │  ║  └───┘                                        ║
        │  ╠═══════════════════════════════════════════════╣
        │  ║          Memory Bandwidth Bound 区域           ║
        │  ║                                ┌───┐          ║
        │  ║                                │   │ <-- Decode║
        │  ║                                │ D │   在此    ║
        │  ║                                │   │   (低    ║
        │  ║                                └───┘   算术   ║
        │  ║                                        强度)  ║
        │  ╚══════════════════════════════════════════════╝
        │
        └──────────────────────────────────────────────────────►
                           Arithmetic Intensity (FLOPs/Byte)

  转折点 (Ridge Point) = Peak_FLOPS / Peak_Memory_BW

  A100-80G:
    Peak FLOPS (FP16):   312 TFLOPS
    Peak Memory BW:      2039 GB/s (HBM2e)
    Ridge Point:         312e12 / 2039e9 ≈ 153 FLOPs/Byte

  Prefill:  AI ≈ batch_size * seq_len * 2 * hidden_dim / model_size
            -> 大 batch + 长 seq 时远超 153，compute-bound [check]
  Decode:   AI ≈ batch_size * 2 * hidden_dim / model_size
            -> 即使 batch=64，AI 也只有 ~20，memory-bound [check]
```

### 4.2 请求生命周期中的计算/访存变化

```
一个请求的计算/访存特征随时间变化：

   计算强度
     ▲
     │
     │  ┌──┐
     │  │  │  Prefill 阶段：计算密集
     │  │  │  处理 1000+ token 的 attention
     │  │  │
     │  │  │
     │  └──┘
     │
     │        ┌─┐  ┌─┐  ┌─┐  ┌─┐  ┌─┐
     │        │ │  │ │  │ │  │ │  │ │   Decode 阶段：访存密集
     │        │ │  │ │  │ │  │ │  │ │   每步只处理 1 token
     │        └─┘  └─┘  └─┘  └─┘  └─┘
     │
     └──────────────────────────────────────► 时间
         Prefill (0.1-5s)    Decode (5s-100s+)
```

**这给调度器带来了核心挑战**：

```
每个迭代，调度器必须决定：
  "多少 GPU 资源给 prefill，多少给 decode？"

如果偏向 prefill：
  [check] 新请求 TTFT 降低
  [cross] 正在 decode 的请求 TPOT 升高（因为 decode 获得的批次时间变少）
  [cross] 显存峰值上升（prefill 需要更多中间激活值）

如果偏向 decode：
  [check] TPOT 稳定（decode 获得更多 GPU 时间）
  [cross] 新请求 TTFT 升高（prefill 被推迟）
  [cross] 整体吞吐可能下降（GPU 在 decode 上的效率低于 prefill）
```

### 4.3 Chunked Prefill —— 核心机制详解

**问题根源**：一个长 prompt（例如 8000 token）的 prefill 会独占大量 token budget，阻塞其他请求。

**Chunked Prefill 的解决方案**：将长 prefill 切成多个小块，在多个迭代中逐步完成。

```
                    Chunked Prefill 时间线

  请求 X (8000 token prompt)，max_num_batched_tokens = 4096
  已有请求 A, B, C 在 decode

  Iteration 1:
  ┌────────────────────────────────────────────┐
  │  Prefill Chunk:  X[0:2048]    (2048 tok)   │
  │  Decode:          A, B, C     (3 tok)      │
  │  Total:           2051 tokens              │
  ├────────────────────────────────────────────┤
  │  X 状态: chunk[0] done, KV cache partial   │
  └────────────────────────────────────────────┘

  Iteration 2:
  ┌────────────────────────────────────────────┐
  │  Prefill Chunk:  X[2048:4096] (2048 tok)   │
  │  Decode:          A, B, C, X  (4 tok)      │
  │  Total:           2052 tokens              │
  ├────────────────────────────────────────────┤
  │  X 状态: chunk[1] done, 开始 decode 1 tok  │
  └────────────────────────────────────────────┘

  Iteration 3:
  ┌────────────────────────────────────────────┐
  │  Prefill Chunk:  X[4096:6144] (2048 tok)   │
  │  Decode:          A, B, C, X  (4 tok)      │
  │  Total:           2052 tokens              │
  └────────────────────────────────────────────┘

  Iteration 4:
  ┌────────────────────────────────────────────┐
  │  Prefill Chunk:  X[6144:8000] (1856 tok)   │
  │  Decode:          A, B, C, X  (4 tok)      │
  │  Total:           1860 tokens              │
  ├────────────────────────────────────────────┤
  │  X 状态: prefill 完成                      │
  └────────────────────────────────────────────┘
```

**核心洞察**：通过 chunked prefill，即使 X 的 prompt 很长，也不会阻塞 A、B、C 的 decode —— X 只在每轮占用部分 token budget。

### 4.4 Chunk Size 的数学建模

```
符号定义：
  B_max     : max_num_batched_tokens (总 token 预算)
  n_decode  : 平均并发 decode 请求数
  B_prefill : 分配给 prefill 的 token 预算
  B_decode  : 分配给 decode 的 token 预算 (= n_decode * 1)

约束:
  B_prefill + n_decode <= B_max

  -> B_prefill <= B_max - n_decode

若 chunk_size = B_prefill：
  chunk_size <= B_max - n_decode

但考虑效率：chunk 太小 -> 需要更多迭代 -> 调度开销更大
            chunk 太大 -> decode 受影响更大 -> TPOT 恶化

经验公式:
  chunk_size_optimal ≈ B_max / (1 + alpha * n_decode)

  其中 alpha 是"decode 相对重要性"超参数
  alpha = 1  : 均分 token budget（默认推荐）
  alpha < 1  : 偏向 prefill（更快完成 prefill）
  alpha > 1  : 偏向 decode（更稳定 TPOT）

典型值:
  B_max = 8192, n_decode = 32, alpha = 1
  -> chunk_size ≈ 8192 / 33 ≈ 248 tokens/chunk
```

**chunk size 对性能影响的实验数据**：

```
实验: Llama-2-13B, A100, 混合请求 (300-3000 tok prompt)
B_max = 4096

┌──────────────┬──────────┬──────────┬──────────┬──────────┐
│ chunk_size   │ 平均TTFT │ P95 TPOT │ 吞吐量   │ GPU 利用率│
├──────────────┼──────────┼──────────┼──────────┼──────────┤
│ 256          │  1.8s    │  22ms    │  2150    │  78%     │
│ 512          │  1.2s    │  24ms    │  2280    │  82%     │
│ 1024         │  0.8s    │  28ms    │  2410    │  85%     │
│ 2048         │  0.5s    │  35ms    │  2520    │  89%     │
│ 4096 (无chunk)│ 0.3s    │  52ms    │  2580    │  91%     │
│              │          │  <-- P95 TPOT 翻倍！              │
└──────────────┴──────────┴──────────┴──────────┴──────────┘

解读:
  chunk_size=256: TTFT 较高但 TPOT 极稳（用户体验流畅）
  chunk_size=4096: 最高吞吐但 TPOT 抖动大（用户感知卡顿）
  chunk_size=1024: 通常是最佳平衡点
```

### 4.5 Chunked Prefill 实现伪代码

```python
class ChunkedPrefillScheduler:
    """实现了分块预填充的调度器"""

    def __init__(self, max_num_batched_tokens: int, max_num_seqs: int):
        self.max_num_batched_tokens = max_num_batched_tokens
        self.max_num_seqs = max_num_seqs
        self.waiting: List[SequenceGroup] = []   # 等待 prefill 的请求
        self.running: List[SequenceGroup] = []   # 已在 decode 的请求

    def schedule(self):
        """
        返回: (prefill_batch, decode_batch)
        每轮调度的核心逻辑
        """
        scheduled_prefill = []
        scheduled_decode = []
        token_budget = self.max_num_batched_tokens

        # 阶段 1: 所有 running 请求必须走一步 decode
        for seq_group in self.running:
            if not seq_group.is_finished():
                scheduled_decode.append(seq_group)
                token_budget -= 1  # 每个 decode 消耗 1 个 token budget

        # 阶段 2: 用剩余 token budget 做 prefill
        # 2a: 先处理有未完成 chunk 的请求（已经在 decode 但 prefill 未完成）
        for seq_group in self.running:
            if seq_group.has_remaining_prefill():
                remaining_tokens = seq_group.remaining_prefill_tokens()
                chunk = min(remaining_tokens, token_budget)
                if chunk > 0:
                    seq_group.prefill_chunk(chunk)
                    scheduled_prefill.append(seq_group)
                    token_budget -= chunk

        # 2b: 从等待队列中取新请求
        self.waiting.sort(key=lambda sg: sg.priority_score())

        for seq_group in self.waiting:
            if token_budget <= 0:
                break
            if len(scheduled_prefill) + len(scheduled_decode) >= self.max_num_seqs:
                break

            prompt_tokens = seq_group.num_prompt_tokens()
            chunk = min(prompt_tokens, token_budget)

            if chunk > 0:
                if self.block_manager.can_allocate(chunk):
                    seq_group.prefill_chunk(chunk)
                    scheduled_prefill.append(seq_group)
                    token_budget -= chunk

                    if seq_group.prefill_complete():
                        self.waiting.remove(seq_group)
                        self.running.append(seq_group)

        return scheduled_prefill, scheduled_decode
```

### 4.6 边界情况处理

```
情况1: KV cache 不足
  ┌─────────────────────────────────────────────────────┐
  │ 即使 token budget 足够，没有可用 KV cache 块        │
  │ -> 需要抢占 (preemption) 或等待                     │
  │ -> 优先选择 swap（如果 swap 空间足够）              │
  │ -> 或 recompute（default）                          │
  └─────────────────────────────────────────────────────┘

情况2: 所有请求都需要 prefill
  ┌─────────────────────────────────────────────────────┐
  │ 系统刚启动，没有任何 running 请求                   │
  │ -> 用全部 token budget 做 prefill                    │
  │ -> 第一个 batch 全 prefill，然后进入混合模式         │
  └─────────────────────────────────────────────────────┘

情况3: Prefill 完成时的 KV cache 一致性
  ┌─────────────────────────────────────────────────────┐
  │ Chunked prefill 在中间迭代留下了不完整的 KV cache   │
  │ -> 需要跟踪每个请求的 prefill 进度                   │
  │ -> KV cache 块需要标记为 "partial"                  │
  │ -> 下一块 prefill 需要知道从哪个位置继续             │
  └─────────────────────────────────────────────────────┘

情况4: 请求在 prefill 过程中被取消
  ┌─────────────────────────────────────────────────────┐
  │ 用户断开连接，请求取消                              │
  │ -> 释放已分配的 KV cache 块                          │
  │ -> 部分 prefill 的结果丢弃（无法恢复）               │
  │ -> 不需要特殊处理，标记为 finished 即可              │
  └─────────────────────────────────────────────────────┘
```

---

## 5. 抢占机制深度剖析

### 5.1 为什么需要抢占？

```
场景：系统满载运行时，新请求到达但 KV cache 已满

  显存布局示意：

  ┌────────────────────────────────────────────────────┐
  │  模型权重         │  30 GB  (固定)                  │
  │  激活值缓冲       │   2 GB  (prefill 时增大)        │
  │  KV Cache 池      │  48 GB  (动态分配)              │
  │  ┌──┬──┬──┬──┬──┐│                                  │
  │  │A1│A2│B1│C1│C2││ <-- 每个块 2MB (以 token 为单位) │
  │  │A3│B2│B3│C3│D1││                                  │
  │  │A4│  │B4│C4│D2││                                  │
  │  │A5│  │  │  │D3││                                  │
  │  └──┴──┴──┴──┴──┘│                                  │
  │  可用: ░░ 2 块 ░░ │                                  │
  └────────────────────────────────────────────────────┘

  问题: 新请求 E 需要 5 个 KV cache 块，但只有 2 块可用
  -> 必须"抢占"某些现有请求的 KV cache 块，腾出空间
```

### 5.2 存储层次与性能特征

```
    ┌─────────────────────────────────────────────────────────┐
    │                    存储层次结构                           │
    │                                                         │
    │   ┌──────────────────┐                                  │
    │   │   GPU HBM (80GB) │ <-- 最快，最贵，最稀缺            │
    │   │   带宽: ~2TB/s   │    所有计算的核心工作区            │
    │   │   延迟: ~1us     │                                  │
    │   └────────┬─────────┘                                  │
    │            │ PCIe 4.0 x16: ~32 GB/s (单向)              │
    │            │ PCIe 5.0 x16: ~64 GB/s                     │
    │            │ NVLink: ~600 GB/s (仅 GPU-GPU)              │
    │            ▼                                            │
    │   ┌──────────────────┐                                  │
    │   │   CPU RAM (512GB)│ <-- 中等速度，相对充裕            │
    │   │   带宽: ~100GB/s │    用作 swap 空间                 │
    │   │   延迟: ~100ns   │                                  │
    │   └────────┬─────────┘                                  │
    │            │                                            │
    │            ▼                                            │
    │   ┌──────────────────┐                                  │
    │   │   NVMe SSD (2TB) │ <-- 最慢，最充裕                  │
    │   │   带宽: ~7GB/s   │    极少用于推理调度               │
    │   │   延迟: ~10us    │    仅用于离线场景                 │
    │   └──────────────────┘                                  │
    └─────────────────────────────────────────────────────────┘
```

**KV Cache 块传输时间估算**：

```
假设：
  KV Cache 块大小 = 16 tokens * 2 layers * hidden_dim * 2 (K+V) * 2 bytes (FP16)

  Llama-2-13B:
    1 块 ≈ 16 * 40 * 5120 * 2 * 2 = 13.1 MB
    GPU->CPU 传输: 13.1MB / 32GB/s ≈ 0.41ms  (PCIe 4.0)
    CPU->GPU 传输: 13.1MB / 32GB/s ≈ 0.41ms
    往返总延迟: ~0.82ms

  Llama-2-70B:
    1 块 ≈ 16 * 80 * 8192 * 2 * 2 = 41.9 MB
    GPU->CPU 传输: 41.9MB / 32GB/s ≈ 1.31ms
    往返总延迟: ~2.6ms

  完整请求 swap（假设 1000 token，每个块 16 token）：
    块数: 1000/16 ≈ 63 块
    数据量: 63 * 13.1MB ≈ 825 MB (13B) 或 63 * 41.9MB ≈ 2.6 GB (70B)
    总传输时间: 825MB / 32GB/s ≈ 26ms (13B) 或 81ms (70B)
```

### 5.3 Swap 策略详解

```
Swap 策略流程：

  1. 选择 victim 请求
     │  策略: LRU (Least Recently Used)
     │  选择最久没有生成新 token 的请求
     │  等价于选择"距离上次 decode 最久"的请求
     │
     ▼
  2. 拷贝 KV cache 到 CPU
     │  GPU HBM -> CPU RAM (via PCIe)
     │  ┌────────┐         ┌────────┐
     │  │GPU HBM │ ─PCIe─> │CPU RAM │
     │  │ KV块:  │  32GB/s │ swap   │
     │  │ A1-A8  │         │ 空间   │
     │  └────────┘         └────────┘
     │
     ▼
  3. 释放 GPU KV cache 块
     │  块返回空闲池
     │  新请求可以分配这些块
     │
     ▼
  4. 恢复被 swap 的请求
     │  当 GPU 有空闲 KV cache 块时
     │  CPU RAM -> GPU HBM
     │  恢复后继续 decode
     │  不需要重新 prefill！
```

**vLLM Swap 配置**：

```bash
# 启用 swap 空间（CPU 内存用作 swap）
vllm serve meta-llama/Llama-2-70b-chat-hf \
    --swap-space 16 \              # 16 GB CPU 内存用于 swap
    --gpu-memory-utilization 0.95  # GPU 显存利用率（留 5% 余量）
    --max-num-seqs 64              # 最大并发序列数
```

**Swap 的代价模型**：

```
总 swap 延迟 = 选择 victim 延迟 + 传输延迟 + 调度延迟

T_swap = T_select + (KV_size / PCIe_BW) + T_schedule

其中：
  T_select    ≈ O(log n) 使用堆选择 LRU victim ≈ 1-5us
  KV_size     ≈ num_blocks_to_swap * block_size
  PCIe_BW     ≈ 32 GB/s (PCIe 4.0 x16)
  T_schedule  ≈ 10-100us (vLLM 调度循环开销)

对于 70B 模型、1000 token 的请求：
  T_swap ≈ 5us + 2.6GB/32GBs + 50us ≈ 81ms + 55us ≈ 81ms
```

### 5.4 Recompute 策略详解（vLLM 默认）

```
Recompute 策略流程：

  1. 选择 victim 请求
     │  同样策略: LRU
     │
     ▼
  2. 直接释放 GPU KV cache 块
     │  不拷贝到 CPU！
     │  块直接返回空闲池
     │  速度快，立即可用
     │
     ▼
  3. 恢复时重新 prefill
     │  请求被"重新调度"
     │  从头开始做 prefill
     │  重新计算所有 KV cache
     │  （利用 GPU 的强大计算能力）
     │
     ▼
  4. 继续 decode
     │  从断点继续生成
```

**为什么 Recompute 通常更好？**

```
关键洞察：Prefill 是 Compute-Bound，GPU 算力远超 PCIe 带宽

对比分析 — 需要恢复一个 1000 token 被抢占的 70B 请求：

  Swap 方案：
    Save:    2.6GB / 32GB/s  ≈ 81ms  (GPU->CPU)
    Restore: 2.6GB / 32GB/s  ≈ 81ms  (CPU->GPU)
    总计:    ≈ 162ms

  Recompute 方案：
    Prefill 时间 ≈ 1000 tok * 2 * 80层 * (8192^2 * 2) / 312e12 FLOPS
                 ≈ 1000 * 2 * 80 * 1.34e8 / 3.12e14
                 ≈ 68ms
    总计:    ≈ 68ms

  Recompute 更快！

┌──────────────────────────────────────────────────────────────┐
│  但这不是绝对的——取决于 prefix 长度：                        │
│                                                              │
│  短 prefix (100 tok):  recompute ≈ 7ms,  swap ≈ 16ms        │
│                        -> recompute 更快 [check]             │
│                                                              │
│  中等 prefix (1000 tok): recompute ≈ 68ms, swap ≈ 162ms     │
│                          -> recompute 仍然更快 [check]        │
│                                                              │
│  长 prefix (5000 tok):  recompute ≈ 340ms, swap ≈ 810ms     │
│                         -> recompute 仍然更快 [check]         │
│                                                              │
│  超长 prefix (20000 tok): recompute ≈ 1.36s, swap ≈ 3.24s   │
│                           -> recompute 更快，但绝对时间都长了  │
└──────────────────────────────────────────────────────────────┘

实际上 Swap 的"额外"成本来自 PCIe 带宽的竞争：
  - Prefill 时 GPU 也在用 PCIe（如果需要从 CPU 加载数据）
  - Swap 独占 PCIe 带宽，可能影响其他操作
```

### 5.5 决策边界分析

```
应该在什么条件下选择 Swap 而非 Recompute？

决策函数：

    decision = {
        SWAP,       if recompute_cost > swap_cost AND swap_space_available
        RECOMPUTE,  otherwise
    }

    recompute_cost ≈ T_prefill(prompt_tokens)
    swap_cost      ≈ 2 * KV_size / PCIe_BW

    临界条件 (break-even)：
    T_prefill(prompt_tokens) = 2 * KV_size / PCIe_BW

    prompt_tokens * FLOPs_per_token / GPU_FLOPS = 2 * (KV_bytes_per_token * prompt_tokens) / PCIe_BW

    -> prompt_tokens 抵消！（两边都有 prompt_tokens）
    -> FLOPs_per_token / GPU_FLOPS = 2 * KV_bytes_per_token / PCIe_BW

    -> 这个等式与 prompt_tokens 无关！
    -> 决定因素是硬件参数比

代入 A100-80G + 70B 模型：
  FLOPs_per_token (prefill) ≈ 2*80*(8192^2*2) ≈ 2.15e10 FLOPs
  GPU_FLOPS ≈ 3.12e14
  KV_bytes_per_token ≈ 2*80*8192*2*2 ≈ 5.24 MB

  左侧: 2.15e10 / 3.12e14 ≈ 6.9e-5
  右侧: 2 * 5.24e6 / 32e9 ≈ 3.28e-4

  右侧 > 左侧！-> recompute 更快（对于这个硬件+模型组合）

这意味着对于大多数 GPU + 模型组合，recompute 都优于 swap。
Swap 的优势场景：
  - 模型小、显存带宽极端受限（如消费级 GPU）
  - 请求的 output token 已经生成了很多，丢掉可惜
  - 多轮对话中后续请求可以复用 swap 出去的 KV cache
```

**决策树**：

```
                      请求需要被抢占
                           │
                           ▼
                  ┌────────────────────┐
                  │ output_tokens >    │
                  │ THRESHOLD?         │
                  │ (e.g., > 500 tok)  │
                  └──────┬──────┬──────┘
                     YES │      │ NO
                         ▼      ▼
              ┌─────────────┐  ┌─────────────┐
              │ 考虑 Swap   │  │  Recompute   │
              │ (已生成很多 │  │  (生成不多，  │
              │  丢了可惜)  │  │  重算代价小) │
              └──────┬──────┘  └─────────────┘
                     │
                     ▼
              ┌────────────────────┐
              │ swap_space 可用?   │
              └──────┬──────┬──────┘
                 YES │      │ NO
                     ▼      ▼
              ┌──────────┐ ┌──────────┐
              │  SWAP    │ │RECOMPUTE │
              └──────────┘ └──────────┘
```

---

## 6. 前缀缓存对调度的影响

### 6.1 自动前缀缓存 (APC) 原理回顾

```
APC (Automatic Prefix Caching) — vLLM 的核心优化：

        请求A: "You are a helpful assistant. Translate to French: Hello"
        请求B: "You are a helpful assistant. Translate to French: Goodbye"

        ┌──────────────────────────────────────┐
        │ "You are a helpful assistant.        │ <- System prompt (公共前缀)
        │  Translate to French: "              │
        ├──────────────────────────────────────┤
        │ A: "Hello"                           │ <- 请求特定部分
        │ B: "Goodbye"                         │
        └──────────────────────────────────────┘

        APC 通过 hash(prompt_tokens) 识别相同前缀
        -> 请求B 可以复用请求A 已计算的 KV cache
        -> 避免重复 prefill
```

### 6.2 调度亲和性 (Scheduling Affinity)

```
问题：在多实例部署中，如何最大化前缀缓存命中率？

                    负载均衡器
                        │
            ┌───────────┼───────────┐
            ▼           ▼           ▼
        ┌──────┐   ┌──────┐   ┌──────┐
        │实例1 │   │实例2 │   │实例3 │
        │系统A │   │系统B │   │系统A │
        │prompt│   │prompt│   │prompt│
        │缓存  │   │缓存  │   │缓存  │
        └──────┘   └──────┘   └──────┘

无亲和性：
  请求1 (system_prompt_A) -> 实例1 -> prefill -> 缓存 system_prompt_A
  请求2 (system_prompt_A) -> 实例2 -> prefill -> 重新 prefill！（浪费）
  请求3 (system_prompt_A) -> 实例3 -> prefill -> 重新 prefill！（浪费）

有亲和性（前缀感知路由）：
  请求1 (system_prompt_A) -> 实例1 -> prefill -> 缓存 system_prompt_A
  请求2 (system_prompt_A) -> 实例1 -> HIT! -> 跳过 prefill [check]
  请求3 (system_prompt_A) -> 实例1 -> HIT! -> 跳过 prefill [check]
```

**前缀感知负载均衡伪代码**：

```python
import hashlib
from collections import defaultdict

class PrefixAwareLoadBalancer:
    """前缀感知的负载均衡器"""

    def __init__(self, instances):
        self.instances = instances
        # 跟踪每个实例上缓存了哪些前缀
        self.instance_prefixes = defaultdict(set)
        # 每个实例的当前负载
        self.instance_load = defaultdict(int)

    def extract_prefix_hash(self, prompt, prefix_len=256):
        """提取 prompt 前 N 个 token 的 hash 作为前缀标识"""
        tokens = tokenize(prompt)[:prefix_len]
        return hashlib.md5(str(tokens).encode()).hexdigest()

    def route(self, prompt):
        """将请求路由到最优实例"""
        prefix_hash = self.extract_prefix_hash(prompt)

        # 1. 检查是否有实例缓存了该前缀
        candidates = []
        for inst in self.instances:
            if prefix_hash in self.instance_prefixes[inst]:
                candidates.append(inst)

        if candidates:
            # 有缓存 -> 选择负载最低的
            return min(candidates, key=lambda i: self.instance_load[i])

        # 2. 没有缓存 -> 选择负载最低的实例
        target = min(self.instances, key=lambda i: self.instance_load[i])
        self.instance_prefixes[target].add(prefix_hash)
        return target
```

### 6.3 前缀缓存对调度指标的影响

```
场景：客服 ChatBot，system prompt 固定 500 token

                    无前缀缓存              有前缀缓存
                    ───────────            ───────────
TTFT:
  P50:              0.25s                  0.05s  (-80%)
  P95:              0.80s                  0.12s  (-85%)
  P99:              1.50s                  0.25s  (-83%)

原因：500 token system prompt 的 prefill 被完全跳过

吞吐量提升：
  无缓存:  prefill 占总计算 40%
  有缓存:  prefill 占 ~0%（仅处理新 token）
  -> 相同硬件，吞吐提升 ~50-70%

KV Cache 效率：
  无缓存:  每请求独立分配 KV cache 块
  有缓存:  公共前缀共享 KV cache 块
  -> 可并发更多请求（节省显存 30-50%）
```

### 6.4 RAG 场景下的前缀缓存策略

```
RAG (Retrieval-Augmented Generation) 的特殊挑战：

  RAG 请求构成：
    System Prompt     : "You are a helpful assistant..." (固定, 200 tok)
    Retrieved Context : "Document: ..."                    (可变, 500-2000 tok)
    User Query        : "What is ...?"                     (可变, 20-100 tok)
                        │            │             │
                        └────┬───────┴──────┬──────┘
                             │              │
                      可以缓存 [check]      不可以缓存 [cross]
                             前缀边界
```

```
            RAG 请求前缀缓存示意

  请求1: [System Prompt (200)] [Doc A (1000)] [Query "X" (20)]
  请求2: [System Prompt (200)] [Doc B (800)]  [Query "Y" (30)]
  请求3: [System Prompt (200)] [Doc A (1000)] [Query "Z" (15)]
           │                    │
           ▼                    ▼
       ┌────────┐         ┌──────────────┐
       │ 缓存!  │         │ 请求1 和 请求3 │
       │ 所有请求│         │ 共享 Doc A    │
       │ 命中 [check]│     │ 的 KV cache  [check]│
       └────────┘         └──────────────┘
```

**实践代码**（vLLM 启用 APC）：

```bash
# 启用自动前缀缓存
vllm serve meta-llama/Llama-2-70b-chat-hf \
    --enable-prefix-caching \
    --max-num-batched-tokens 8192 \
    --max-num-seqs 64

# 验证缓存命中率（通过 Prometheus 指标）
# vllm:gpu_prefix_cache_hit_rate
# vllm:gpu_prefix_cache_queries_total
# vllm:gpu_prefix_cache_hits_total
```

---

## 7. 真实工作负载模式

### 7.1 对话/Chat 场景

```
Chat 工作负载特征：

  请求长度分布 (prompt tokens):
     │
  40%│  ████
     │  ████
  30%│  ████  ██
     │  ████  ██
  20%│  ████  ██  ██
     │  ████  ██  ██  █
  10%│  ████  ██  ██  █   ░
     │  ████  ██  ██  █   ░   ░
   0%└──████──██──██──█───░───░──►
        100  300  500 800 1200 2000+  tokens

  典型值: prompt 100-500 tok, output 50-300 tok
  到达模式: 随机，高峰时段突发 (lambda=5-50 req/s)
  延迟敏感度: 高 (TTFT < 500ms, TPOT < 30ms)
  前缀缓存收益: 大（system prompt 重复）

  推荐配置:
    max_num_seqs: 32-64
    chunked_prefill: enabled
    prefix_caching: enabled
    prefill-first: 默认即可
```

### 7.2 代码生成场景

```
代码生成工作负载特征：

  请求长度: prompt 200-2000 tok, output 100-2000+ tok
  到达模式: IDE 触发，可能瞬间大量请求 (lambda burst=50-200)
  延迟敏感度: 极高 (TTFT < 200ms 用于补全)
  TPOT 重要: 生成 2000 行代码，TPOT 必须稳定

  请求长度分布 (output tokens):
     │
  30%│  ███
     │  ███
  20%│  ███  ██
     │  ███  ██  ██
  10%│  ███  ██  ██  █   █   █
     │  ███  ██  ██  █   █   █
   0%└──███──██──██──█───█───█──►
        50  200  500 1000 1500 2000+  tokens

  挑战: 长输出请求可能占用 GPU 数分钟
  -> 需要抢占长请求为新请求腾空间
  -> chunked prefill 至关重要
```

### 7.3 摘要/长文档场景

```
摘要工作负载：

  prompt: 2000-8000+ tok (整篇文章)
  output:  100-300 tok  (简短摘要)
  prefill/decode 比例: 极端不对称

  ┌────────────────────────────────────────────────┐
  │  Prefill:  ████████████████████████████████████ │ 8000 tok  95%
  │  Decode:   ███                                 │  300 tok   5%
  └────────────────────────────────────────────────┘

  挑战:
  - Prefill 极其昂贵（8000 tok 可能需要 1-3 秒）
  - Decode 很快完成（~6 秒 for 300 tok @ 20ms TPOT）
  - Chunked prefill 会进一步延长 prefill 时间
  - 但 decode 阶段极短，GPU 很快空闲

  推荐: chunked prefill + prefix caching
  如果同一个文档被多次提问 -> APC 极大加速
```

### 7.4 RAG 工作负载

```
RAG 请求结构:

  ┌──────────────────────────────────────┐
  │ System Prompt (固定, 200 tok)        │ <- 缓存 [check]
  ├──────────────────────────────────────┤
  │ Retrieved Doc 1 (可变, 400 tok)      │
  │ Retrieved Doc 2 (可变, 500 tok)      │ <- 可变 [cross]
  │ Retrieved Doc 3 (可变, 350 tok)      │
  ├──────────────────────────────────────┤
  │ User Query (可变, 30 tok)            │ <- 可变 [cross]
  └──────────────────────────────────────┘
  总 prompt: ~1480 tok

  到达模式: 用户提问驱动，间隔不均匀
  TTFT 关键: 检索本身已有延迟，推理延迟必须最小化
  APC 收益: system prompt 固定部分

  特殊优化:
  - 如果多次查询同一文档集 -> 文档前缀也可缓存
  - 使用 prefix-aware LB 将同文档请求路由到同实例
```

### 7.5 Agent/多轮对话场景（对接 Claude Code）

```
Agent 工作负载（以 Claude Code 对接为例）:

  对话历史 token 累积:
  Turn 1: [System(200)] [User: "分析代码"(100)] [Assistant: ...  (500)]
  Turn 2: [System(200)] [User: "分析代码"(100)] [Asst(500)] [User: "改bug"(50)] [Asst: ... (800)]
  Turn 3: [...累计到 2000+ tok prefix ...]

  ┌────────────────────────────────────────────────────────────────┐
  │                    对话轮次 vs 前缀长度                         │
  │                                                                │
  │  轮次:  Turn 1  Turn 2  Turn 3  Turn 4  Turn 5  Turn 6        │
  │  Prompt:  300    950    1800    2800    4000    5500   (tokens)│
  │  Prefill: 15ms   48ms   90ms   140ms   200ms   275ms  (A100)   │
  │                                                                │
  │  APC 收益:                                                     │
  │  Turn N+1 复用 Turn N 的全部 prefix -> prefill 仅需新 token     │
  │                                                                │
  └────────────────────────────────────────────────────────────────┘

  Think Time (思考时间):
  用户在两次请求之间有 5-30 秒的间隔
  -> KV cache 需要在 GPU 中保留（或 swap 到 CPU）
  -> LRU 抢占可能在 think time 中触发
  -> 保留策略：较长的 TTL 用于活跃对话
```

### 7.6 混合工作负载下的调度策略

```
生产环境中常见混合工作负载：

  ┌──────────────────────────────────────────────────────────┐
  │ 同一 GPU 集群同时服务：                                   │
  │   - Chat API (60% 流量, 严格 SLA)                        │
  │   - Code completion (25% 流量, 低延迟)                   │
  │   - Document summary (10% 流量, 高吞吐)                  │
  │   - Batch evaluation (5% 流量, 无 SLA)                   │
  └──────────────────────────────────────────────────────────┘

  采用优先级队列：
    Q1 (高优): Chat API, Code completion  -> weight=4
    Q2 (中优): Document summary           -> weight=2
    Q3 (低优): Batch evaluation           -> weight=1

  每轮调度时：
   - Q1 获得 4/7 的 token budget
   - Q2 获得 2/7
   - Q3 获得 1/7
   - 当 Q1 为空时，budget 向下传递

  监控指标：
   - 各优先级队列的长度和等待时间
   - 服务降级是否触发（低优请求超时）
```

---

## 8. 实战调优指南

### 8.0 环境确认

在开始调优之前，确认以下信息：

```bash
# 1. 确认 GPU 型号和显存
nvidia-smi --query-gpu=name,memory.total --format=csv

# 2. 确认 vLLM 版本
pip show vllm | grep Version

# 3. 确认模型大小
# 33B: ~66 GB (FP16)
# 67B: ~134 GB (FP16) — 需要多 GPU (tensor parallelism >= 2)
ls -lh /path/to/model/*.safetensors
```

### 8.1 Step 1: 理解你的工作负载

```bash
#!/bin/bash
# 收集工作负载数据 30 分钟

# 指标 1: 请求速率
curl -s http://localhost:8000/metrics | grep "vllm:request_success_total"

# 指标 2: 平均 prompt/output 长度
curl -s http://localhost:8000/metrics | grep "vllm:prompt_tokens"

# 指标 3: 当前排队请求数
curl -s http://localhost:8000/metrics | grep "vllm:num_requests_waiting"

# 指标 4: GPU 缓存使用率
curl -s http://localhost:8000/metrics | grep "vllm:gpu_cache_usage_perc"

# 指标 5: TTFT / TPOT 分位数
curl -s http://localhost:8000/metrics | grep "vllm:time_to_first_token_seconds"
curl -s http://localhost:8000/metrics | grep "vllm:time_per_output_token_seconds"
```

**负载分析脚本**：

```python
import numpy as np
from collections import defaultdict

def analyze_workload(metrics_log_path):
    """分析推理工作负载特征"""
    with open(metrics_log_path) as f:
        data = [line.strip() for line in f]

    prompt_lens = []
    output_lens = []

    for line in data:
        if 'prompt_tokens_sum' in line:
            prompt_lens.append(float(line.split()[-1]))
        if 'generation_tokens_sum' in line:
            output_lens.append(float(line.split()[-1]))

    print(f"=== 工作负载分析 ===")
    print(f"平均 prompt 长度:    {np.mean(prompt_lens):.0f} tokens")
    print(f"P95 prompt 长度:     {np.percentile(prompt_lens, 95):.0f} tokens")
    print(f"P99 prompt 长度:     {np.percentile(prompt_lens, 99):.0f} tokens")
    print(f"平均 output 长度:    {np.mean(output_lens):.0f} tokens")
    print(f"P95 output 长度:     {np.percentile(output_lens, 95):.0f} tokens")
    print(f"prefill/output 比:   {np.mean(prompt_lens)/np.mean(output_lens):.1f}")

    # 判断工作负载类型
    avg_prompt = np.mean(prompt_lens)
    avg_output = np.mean(output_lens)

    if avg_prompt < 500 and avg_output < 300:
        print("分类: Chat/对话型工作负载")
    elif avg_prompt > 2000 and avg_output < 500:
        print("分类: 摘要/长文档型工作负载")
    elif avg_output > 500:
        print("分类: 代码/长文生成型工作负载")
    else:
        print("分类: 混合型工作负载")
```

### 8.2 Step 2: 设置 max_num_seqs

```bash
# max_num_seqs 控制最大并发序列数
# 每个 seq 在 decode 中消耗约 1 tokens/iteration 的 budget

# 经验法则：
# max_num_seqs ≈ GPU 显存 (GB) / 每请求 KV cache 大小 (GB)
#
# 每请求 KV cache 估算 (FP16):
# Llama-2-13B: ~0.5 GB per 1000 tokens
# Llama-2-33B: ~2.0 GB per 1000 tokens  (80 layers * 6656 dim)
# Llama-2-70B: ~4.5 GB per 1000 tokens  (80 layers * 8192 dim)

# 对于 33B 模型 + A100-80G:
# 模型权重: 66 GB (FP16)
# 可用 KV cache: 80 - 66 - 2(overhead) ≈ 12 GB
# 假设平均 500 token/请求: 每请求 ~1 GB
# max_num_seqs ≈ 12 / 1 ≈ 12

vllm serve /path/to/33b-model \
    --max-num-seqs 16 \
    --gpu-memory-utilization 0.95

# 监控：
# 观察 gpu_cache_usage_perc，目标 80-90%
# 如果 < 70%，增加 max_num_seqs
# 如果 > 95%，减少 max_num_seqs 或启用 swap
```

**内存预算计算表**：

```
模型大小          权重显存     可用 KV Cache (A100-80G)   推荐 max_num_seqs
                             (gpu_mem_util=0.95)         (假设500tok/请求)
─────────────────────────────────────────────────────────────────
33B (FP16)        66 GB       80*0.95-66-2 ≈ 8 GB         4-8
33B (INT4)        18 GB       80*0.95-18-2 ≈ 56 GB       28-56
67B (FP16)        134 GB      需要 >=2*A100                 8-16 (双卡)
67B (INT4)        36 GB       80*0.95-36-2 ≈ 38 GB       19-38
70B-FP8           70 GB       80*0.95-70-2 ≈ 4 GB         2-4  <-- 很紧！
```

### 8.3 Step 3: 设置 max_num_batched_tokens

```bash
# max_num_batched_tokens 控制每轮迭代处理的总 token 数
# 包括 prefill tokens + decode tokens

# 经验法则：
# Prefill 为主: 8K-16K  (摘要、RAG)
# 混合均衡:    4K-8K    (Chat、Agent)
# Decode 为主:  2K-4K    (代码生成、长文)

# 调优方法：
# 1. 从 4096 开始
# 2. 逐步增加，直到 TPOT 开始明显恶化
# 3. 回退 20%

# 示例（chat 工作负载）：
vllm serve /path/to/model \
    --max-num-batched-tokens 4096 \
    --max-num-seqs 32 \
    --enable-chunked-prefill
```

### 8.4 Step 4: 启用关键特性

```bash
#!/bin/bash
# 生产级 33B/67B 部署完整命令

# ===== 33B 模型 (单卡 A100-80G) =====
vllm serve /data/models/Llama-2-33b-chat-hf \
    --host 0.0.0.0 \
    --port 8000 \
    --max-num-seqs 16 \
    --max-num-batched-tokens 4096 \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.95 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-num-on-the-fly 8 \
    --swap-space 8 \
    --dtype float16

# ===== 67B 模型 (双卡 A100-80G, tensor parallelism=2) =====
vllm serve /data/models/Llama-2-70b-chat-hf \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 2 \
    --max-num-seqs 32 \
    --max-num-batched-tokens 8192 \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.92 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-num-on-the-fly 12 \
    --swap-space 16 \
    --dtype float16

# 关键参数解释：
# --enable-prefix-caching    : 自动前缀缓存（必须开！）
# --enable-chunked-prefill   : 分块预填充（必须开！）
# --max-num-on-the-fly       : 同时进行 prefill 的请求上限
# --swap-space               : CPU 内存用作 swap (GB)
```

### 8.5 Step 5: 基准测试与迭代

**完整的基准测试流程**：

```python
#!/usr/bin/env python3
"""
LLM 推理调度基准测试工具
用法: python benchmark_scheduler.py --url http://localhost:8000 --duration 300
"""

import asyncio
import aiohttp
import time
import numpy as np
from dataclasses import dataclass, field
from typing import List

@dataclass
class BenchmarkResults:
    """基准测试结果"""
    total_requests: int = 0
    total_tokens: int = 0
    total_time: float = 0.0
    ttfts: List[float] = field(default_factory=list)
    tpots: List[float] = field(default_factory=list)
    errors: int = 0

    def print_summary(self):
        ttfts = np.array(self.ttfts)
        tpots = np.array(self.tpots)
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                    基准测试结果摘要                           ║
╠══════════════════════════════════════════════════════════════╣
║  总请求数:          {self.total_requests:>8d}                              ║
║  总 token 数:       {self.total_tokens:>8d}                              ║
║  吞吐量:            {self.total_tokens/self.total_time:>8.1f} tok/s                      ║
║  请求吞吐:          {self.total_requests/self.total_time:>8.1f} req/s                      ║
║  错误数:            {self.errors:>8d}                              ║
╠══════════════════════════════════════════════════════════════╣
║  TTFT (s):                                                   ║
║    P50:             {np.percentile(ttfts, 50):>8.3f}                              ║
║    P95:             {np.percentile(ttfts, 95):>8.3f}                              ║
║    P99:             {np.percentile(ttfts, 99):>8.3f}                              ║
║    Mean:            {np.mean(ttfts):>8.3f}                              ║
╠══════════════════════════════════════════════════════════════╣
║  TPOT (ms):                                                  ║
║    P50:             {np.percentile(tpots, 50)*1000:>8.1f}                              ║
║    P95:             {np.percentile(tpots, 95)*1000:>8.1f}                              ║
║    P99:             {np.percentile(tpots, 99)*1000:>8.1f}                              ║
║    Mean:            {np.mean(tpots)*1000:>8.1f}                              ║
╚══════════════════════════════════════════════════════════════╝
        """)

async def run_benchmark(url, model, prompts, request_rate, duration):
    """
    运行基准测试

    Args:
        url: API 地址
        model: 模型名称
        prompts: 测试用的 prompt 列表
        request_rate: 请求速率 (req/s)
        duration: 测试时长 (s)
    """
    results = BenchmarkResults()
    start_time = time.time()
    prompt_idx = 0

    async def send_request(session, prompt):
        nonlocal prompt_idx
        payload = {
            "model": model,
            "prompt": prompt,
            "max_tokens": 256,
            "temperature": 0.0,
            "stream": True,  # 流式以测量 TTFT
        }

        req_start = time.time()
        first_token_time = None
        token_times = []

        try:
            async with session.post(
                f"{url}/v1/completions",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=300)
            ) as resp:
                async for line in resp.content:
                    if line.startswith(b"data: ") and line[6:].strip() != b"[DONE]":
                        now = time.time()
                        if first_token_time is None:
                            first_token_time = now
                        token_times.append(now)

            results.ttfts.append(first_token_time - req_start if first_token_time else 0)
            if len(token_times) > 1:
                intervals = [token_times[i] - token_times[i-1]
                           for i in range(1, len(token_times))]
                results.tpots.append(np.mean(intervals))
            results.total_requests += 1
            results.total_tokens += len(token_times)

        except Exception as e:
            results.errors += 1

    async with aiohttp.ClientSession() as session:
        tasks = []
        elapsed = 0
        while elapsed < duration:
            prompt = prompts[prompt_idx % len(prompts)]
            prompt_idx += 1
            tasks.append(asyncio.create_task(send_request(session, prompt)))

            # 控制请求速率
            await asyncio.sleep(1.0 / request_rate)
            elapsed = time.time() - start_time

        # 等待所有请求完成
        await asyncio.gather(*tasks, return_exceptions=True)

    results.total_time = time.time() - start_time
    return results

async def main():
    """主函数"""
    prompts = [
        "Hello, how are you?",                              # 短
        "Explain quantum computing in detail.",             # 中短
        "Write a Python function to " * 50,                 # 长
        "The following is a conversation " * 100,           # 很长
    ]

    results = await run_benchmark(
        url="http://localhost:8000",
        model="Llama-2-33b-chat-hf",
        prompts=prompts,
        request_rate=10.0,   # 10 req/s
        duration=300,        # 5 分钟
    )
    results.print_summary()

if __name__ == "__main__":
    asyncio.run(main())
```

### 8.6 实时监控

```bash
# GPU 监控
watch -n 1 nvidia-smi

# vLLM Prometheus 指标（关键指标）
curl -s http://localhost:8000/metrics | grep -E \
  "vllm:(num_requests_waiting|num_requests_running|gpu_cache_usage_perc|request_success_total)"

# 输出示例：
# vllm:num_requests_waiting{model="model"} 5.0       <- 5个请求在排队
# vllm:num_requests_running{model="model"} 28.0      <- 28个请求正在运行
# vllm:gpu_cache_usage_perc{model="model"} 87.5       <- KV cache 使用率 87.5%
# vllm:request_success_total{model="model"} 125483.0  <- 累计完成请求数

# TTFT 分布
curl -s http://localhost:8000/metrics | grep "time_to_first_token_seconds"

# TPOT 分布
curl -s http://localhost:8000/metrics | grep "time_per_output_token_seconds"

# 前缀缓存命中率
curl -s http://localhost:8000/metrics | grep "prefix_cache"
```

### 8.7 调优决策树

```
                        开始调优
                           │
                           ▼
                  ┌────────────────────┐
                  │ 了解工作负载特征    │
                  │ (prompt/output长度, │
                  │  到达模式, SLA)     │
                  └────────┬───────────┘
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
        ┌──────────┐ ┌──────────┐ ┌──────────┐
        │prompt短  │ │混合      │ │prompt长  │
        │output短  │ │中等长度  │ │output短  │
        │(Chat)    │ │(Agent)   │ │(摘要)    │
        └────┬─────┘ └────┬─────┘ └────┬─────┘
             │            │            │
             ▼            ▼            ▼
        max_num_     max_num_     max_num_
        seqs: 32-64  seqs: 16-32  seqs: 8-16
        batched:     batched:     batched:
        4096        8192        16384
             │            │            │
             └────────────┼────────────┘
                          │
                          ▼
                 ┌──────────────────┐
                 │ 启用:             │
                 │ prefix-caching   │
                 │ chunked-prefill  │
                 └────────┬─────────┘
                          │
                          ▼
                 ┌──────────────────┐
                 │ 运行基准测试      │
                 │ 收集 P50/P95/P99 │
                 └────────┬─────────┘
                          │
              ┌───────────┼───────────┐
              ▼           ▼           ▼
        ┌──────────┐ ┌──────────┐ ┌──────────┐
        │TTFT太高  │ │TPOT太高  │ │GPU利用率 │
        │          │ │          │ │太低      │
        └────┬─────┘ └────┬─────┘ └────┬─────┘
             │            │            │
             ▼            ▼            ▼
        增大batched   减小batched   增大max_
        tokens或       tokens或     num_seqs
        减小max_      增大chunk   或减小
        num_seqs      size         chunk size
             │            │            │
             └────────────┼────────────┘
                          │
                          ▼
                 ┌──────────────────┐
                 │ 重新基准测试      │
                 │ 达标？            │
                 └────────┬─────────┘
                    YES   │   NO
                     ▼    │    │
              ┌──────────┐│    └── 回到上一步
              │ 部署上线! ││
              │ 持续监控  ││
              └──────────┘│
                          │
                          └── 检查是否达到了硬件极限
                              -> 考虑多 GPU / 量化 / 升级硬件
```

### 8.8 常见问题排查

```
问题 1: P99 TTFT 突然飙升
┌──────────────────────────────────────────────────────────┐
│ 现象: P50 TTFT 正常 (0.2s), P99 TTFT 飙升到 5s+         │
│ 原因: 长 prompt 请求的 prefill 阻塞了后续请求            │
│ 解决:                                                    │
│   1. 确认 --enable-chunked-prefill 已开启                │
│   2. 减小 max_num_batched_tokens                         │
│   3. 检查是否有异常长的 prompt (P99 prompt len)          │
│   4. 考虑设置 max_model_len 限制                          │
└──────────────────────────────────────────────────────────┘

问题 2: TPOT 波动大（"卡顿感"）
┌──────────────────────────────────────────────────────────┐
│ 现象: TPOT 在 20ms-200ms 之间剧烈波动                    │
│ 原因: prefill batch 过大，抢占了 decode 的资源            │
│ 解决:                                                    │
│   1. 减小 max_num_batched_tokens                         │
│   2. 减小 chunk size（通过 max_num_batched_tokens 间接）  │
│   3. 限制同时 prefill 数: --max-num-on-the-fly           │
└──────────────────────────────────────────────────────────┘

问题 3: OOM (Out of Memory)
┌──────────────────────────────────────────────────────────┐
│ 现象: CUDA out of memory                                 │
│ 原因: KV cache 超限                                      │
│ 解决:                                                    │
│   1. 减小 max_num_seqs                                   │
│   2. 减小 max_model_len                                  │
│   3. 降低 gpu-memory-utilization                         │
│   4. 考虑量化 (INT4/INT8/FP8)                            │
│   5. 增加 swap-space，让部分 KV cache swap 到 CPU        │
└──────────────────────────────────────────────────────────┘

问题 4: 前缀缓存命中率低
┌──────────────────────────────────────────────────────────┐
│ 现象: prefix_cache_hit_rate < 10%                        │
│ 原因: 请求间的 prompt 前缀很少重叠                        │
│ 解决:                                                    │
│   1. 检查是否系统 prompt 格式不一致                       │
│   2. 考虑标准化 system prompt（去空格、统一格式）         │
│   3. 如果是多实例部署，检查负载均衡策略                    │
│   4. 如果确实是高度异构的 prompt，缓存收益有限             │
└──────────────────────────────────────────────────────────┘
```

### 8.9 33B/67B 部署的具体配置

```bash
#!/bin/bash
# ============================================================
# 生产环境部署脚本
# 场景: 部署 33B 和 67B 模型，对接 Claude Code 和 RAG 服务
# ============================================================

# ---- 33B 实例：用于代码补全和 RAG ----
# 配置策略: 低延迟优先
vllm serve /data/models/code-llama-33b-instruct \
    --host 0.0.0.0 \
    --port 8001 \
    --served-model-name code-33b \
    --max-num-seqs 12 \
    --max-num-batched-tokens 3072 \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.93 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-num-on-the-fly 4 \
    --swap-space 8 \
    --dtype float16 \
    2>&1 | tee /var/log/vllm-code33b.log

# ---- 67B 实例：用于复杂推理和长文任务 ----
# 配置策略: 平衡吞吐和延迟，双卡 TP
vllm serve /data/models/Llama-2-70b-chat-hf \
    --host 0.0.0.0 \
    --port 8002 \
    --served-model-name chat-70b \
    --tensor-parallel-size 2 \
    --max-num-seqs 28 \
    --max-num-batched-tokens 6144 \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.90 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-num-on-the-fly 8 \
    --swap-space 16 \
    --dtype float16 \
    2>&1 | tee /var/log/vllm-chat70b.log
```

---

## 9. 易混淆技术辨析

在实际工作中，以下几个概念常被混淆。厘清它们的区别，是深入理解调度系统的关键一步。

### 9.1 Continuous Batching $\neq$ Dynamic Batching $\neq$ Static Batching

```
┌────────────────────┬─────────────────────┬─────────────────────┐
│   Static Batching  │  Dynamic Batching   │ Continuous Batching │
│   (静态批处理)      │  (动态批处理)        │  (连续批处理)        │
├────────────────────┼─────────────────────┼─────────────────────┤
│ 等一批凑满再推理    │ 每轮结束后加入新请求  │ 每个迭代都可增删请求  │
│ 整批同进同退        │ 仍需等整批一起完成    │ 完成的立即踢出       │
│ HuggingFace         │ NVIDIA Triton        │ vLLM, SGLang        │
│ pipeline (旧)       │ (旧版 dynamic batch) │ TensorRT-LLM         │
│ (inflight batching) │                     │                      │
├────────────────────┼─────────────────────┼─────────────────────┤
│ 批处理效率: 高      │ 批处理效率: 中       │ 批处理效率: 中-高     │
│ 延迟: 极差          │ 延迟: 较好           │ 延迟: 最好           │
│ GPU 利用率: 高      │ GPU 利用率: 中       │ GPU 利用率: 高        │
│ 适用: 离线批处理    │ 适用: 低频在线服务    │ 适用: 生产级在线服务  │
└────────────────────┴─────────────────────┴─────────────────────┘
```

**核心区别**：Static Batching 必须等一整批请求全部完成后才能开始下一批——这意味着最快的请求也要等最慢的请求一起结束。Dynamic Batching 允许批处理结束后立即换入新请求，但仍存在"批次边界"——请求只能在两批之间加入。Continuous Batching 消除了批次边界，每次 GPU 迭代都可以添加等待中的新请求或移除已完成的请求，这是 vLLM 吞吐量提升数十倍的根本原因。

### 9.2 Chunked Prefill $\neq$ Disaggregated Prefill

```
┌─────────────────────────────────────────────────────────────────┐
│                    两种"拆分 Prefill"的路径                       │
├─────────────────────────────┬───────────────────────────────────┤
│     Chunked Prefill         │     Disaggregated Prefill          │
│     (分块预填充)            │     (分离式预填充)                 │
├─────────────────────────────┼───────────────────────────────────┤
│ Prefill 和 Decode 在同一 GPU│ Prefill 和 Decode 跑在不同 GPU 上 │
│ 将长 Prefill 切为多个小块   │ Prefill GPU 专门跑 Prefill        │
│ 穿插在 Decode 迭代之间      │ Decode GPU 专门跑 Decode          │
│ 单 GPU 内的时间复用         │ 多 GPU 间的空间解耦               │
├─────────────────────────────┼───────────────────────────────────┤
│ 优点: 部署简单，vLLM 原生   │ 优点: Prefill 突刺不干扰 Decode   │
│ 缺点: Prefill/Decode 仍竞争 │ 缺点: KV Cache 需跨 GPU 传输       │
│ 同一 GPU 的算力和带宽       │ 架构复杂，部署成本高              │
├─────────────────────────────┼───────────────────────────────────┤
│ 代表: vLLM 默认策略         │ 代表: Splitwise, Prefill-Decode   │
│                             │      Disaggregation (PDD)          │
└─────────────────────────────┴───────────────────────────────────┘
```

**不是替代关系，是互补关系**：Chunked Prefill 解决的是单 GPU 内的时间调度问题，Disaggregated Prefill 解决的是 GPU 集群的空间解耦问题。两者可以共存——即使 Prefill 和 Decode 分离到不同 GPU，Prefill GPU 内部仍可以使用 Chunked Prefill 来平滑多个长 prompt 的处理。

### 9.3 Swap vs Recompute vs Eviction

很多工程师认为 Swap 一定比 Recompute 慢，但实际情况取决于具体场景。我们已在第 5 章详细分析，这里用一张决策矩阵总结：

```
                     output_tokens 已生成数量
                         少 (< 200)              多 (> 500)
         ┌─────────────────────────────────────────────────┐
  prompt │                                           │
  长度   │  短  │  Recompute (< 10ms)  │  Recompute 或 Swap │
         │      │  重算代价极小         │  (看 swap 空间)    │
         ├──────┼──────────────────────┼───────────────────┤
         │  长  │  Recompute (< 100ms) │  Swap 优先          │
         │      │  重算仍比换入快       │  保护已生成的 token  │
         └─────────────────────────────────────────────────┘

  Eviction: 请求已完成，直接释放 KV Cache 块，不存在"恢复"的需求。
```

**关键误解澄清**：Swap 不是"把请求保存到磁盘"，而是"把 KV Cache 从 GPU HBM 复制到 CPU RAM（通过 PCIe）"。这个操作比磁盘 I/O 快 100 倍以上，但仍可能比直接 Recompute 慢——因为现代 GPU 的算力远超 PCIe 带宽。

### 9.4 Prefill-First $\neq$ "让 Prefill 永远优先"

这是最常见的误解之一。Prefill-First 策略的正确理解是：

```
正确理解：
  "在每轮调度中，尽量将新请求的 prefill 和当前 decode 请求打包在一起执行，
   利用 decode 迭代中'空余'的 token budget 来逐步完成 prefill。"

错误理解：
  "只要队列中有 prefill 请求，就暂停所有 decode，先完成所有 prefill。"
  -> 这将导致 decode 请求的 TPOT 剧烈波动，用户体验极差。
```

Chunked Prefill 正是为了避免这种误解带来的问题——通过限制每次 prefill 的 chunk 大小，确保 decode 请求总能获得足够的迭代资源。

### 9.5 TTFT 优化 vs TPOT 优化——不可能同时最优化

```
                      TTFT                        TPOT
                       │                           │
        优化方向:       ▼                           ▼
              ┌──────────────────┐       ┌──────────────────┐
              │  增大 prefill    │       │  减小 prefill    │
              │  token budget    │       │  token budget    │
              │  让新请求快速    │       │  减少对 decode   │
              │  完成 prefill    │       │  的资源争抢      │
              └────────┬─────────┘       └────────┬─────────┘
                       │                           │
              ┌────────┴───────────┐   ┌───────────┴─────────┐
              │ TTFT ↓  TPOT ↑    │   │ TTFT ↑  TPOT ↓     │
              │ (新请求快，        │   │ (新请求慢，          │
              │  老请求卡)        │   │  老请求流畅)        │
              └───────────────────┘   └─────────────────────┘
                       │                           │
                       └───────────┬───────────────┘
                                   │
                                   ▼
                    ┌──────────────────────────────┐
                    │  不存在同时最小化的解         │
                    │  只能根据 SLA 找 Pareto 最优  │
                    │  Chunked Prefill 是在两个     │
                    │  维度间做"时间片轮转"折中     │
                    └──────────────────────────────┘
```

**实践中的选择**：

```
场景                            优先级               max_num_batched_tokens 方向
──────────────────────────────────────────────────────────────────────
实时对话 (Chat)                  TPOT > TTFT        减小 (4096)
代码补全 (IDE)                   TTFT > TPOT        增大 (8192-16384)
Agent 工作流                     TTFT > TPOT        适中 (4096-8192)
长文生成                         TPOT >> TTFT       减小 (2048-4096)
批量评估                         吞吐 > 一切         按硬件上限
```

### 9.6 PagedAttention $\neq$ FlashAttention

这两个技术名称相似，但解决的是完全不同层次的问题：

```
┌──────────────────────────────────────────────────────────────────┐
│                      推理优化的技术栈分层                          │
├────────────────────┬─────────────────────────────────────────────┤
│ 层次               │ 代表技术                                    │
├────────────────────┼─────────────────────────────────────────────┤
│ 内存管理           │ PagedAttention (vLLM)                       │
│ (Memory Mgmt)      │ 解决: KV Cache 如何分配和回收               │
│                    │ 类比: 操作系统的虚拟内存/分页               │
├────────────────────┼─────────────────────────────────────────────┤
│ 算子优化           │ FlashAttention (Dao et al.)                 │
│ (Kernel/Ops)       │ 解决: Attention 计算如何更高效               │
│                    │ 类比: BLAS 库对矩阵乘法的优化               │
├────────────────────┼─────────────────────────────────────────────┤
│ 分布式             │ Ring Attention, Tree Attention              │
│ (Distribution)     │ 解决: 长序列如何跨多 GPU 并行               │
│                    │ 类比: 分布式矩阵乘法的通信模式               │
├────────────────────┼─────────────────────────────────────────────┤
│ 量化               │ GPTQ, AWQ, FP8, INT4                        │
│ (Quantization)     │ 解决: 权重和 KV Cache 如何压缩              │
│                    │ 类比: 图片/视频的有损压缩                   │
└────────────────────┴─────────────────────────────────────────────┘

vLLM 同时使用了 FlashAttention（算子层）+ PagedAttention（内存管理层），
两者不存在相互替代关系——它们在同一推理引擎的不同层次协作。
```

### 9.7 Tensor Parallelism (TP) vs Pipeline Parallelism (PP) for Inference

```
                     TP (推理场景)                  PP (推理场景)
                     ──────────                   ──────────
  原理:         将单层权重切分到多 GPU       将不同层放到不同 GPU
                每层计算在所有 GPU 上并行      GPU0 算 Layer 0-20
                All-Reduce 同步               GPU1 算 Layer 21-40
                                              GPU2 算 Layer 41-60
                                              GPU3 算 Layer 61-80

  通信:         频繁的 All-Reduce            层间传递激活值
                每层都要同步                  仅前向传递
                延迟敏感                      带宽敏感

  推理使用频率: 常用                          不常用
                模型太大放不进单卡             推理不需要反向传播
                用 TP 切分                    流水线气泡不划算

  适用场景:     70B+ 模型需要多卡             极少，多为训练场景
                2-4 卡 TP 最常见              (Pipeline 并行在推理
                                              中不如 TP 高效)

  实际部署:     67B 模型: TP=2               vLLM 主要支持 TP
                405B 模型: TP=8               不推荐 PP 做推理
```

**训练 vs 推理的关键差异**：训练时 PP 常见（因为需要存储优化器状态和梯度），但推理时不需要这些——推理的主要瓶颈是模型权重超过单卡显存，TP 的通信模式更适合推理的实时性要求。

---

## 10. AI Infra 专家视角

如果说前 9 章是从"书本知识"角度讲解调度策略，那么这一章是从"战场经验"角度整理 AI Infra 工程师在实际工作中养成的思维习惯和判断框架。

### 10.1 第一个问题：你是在做服务，还是在做推理？

这是接手任何 LLM 部署任务时必须先回答的问题。答案决定了整个调度策略的方向。

```
┌──────────────────────────────────────────────────────────────────┐
│              服务 (Online Serving) vs 推理 (Offline Inference)      │
├────────────────────┬─────────────────────────────────────────────┤
│                    │                                             │
│  维度              │  在线服务               离线推理              │
│                    │                                             │
├────────────────────┼──────────────────────┬──────────────────────┤
│  用户等待          │  是（用户盯着屏幕）   │  否（非交互）         │
│  核心指标          │  TTFT < SLA, TPOT 稳  │  吞吐 (tokens/s)     │
│  延迟敏感度        │  极高（毫秒级）        │  低（秒级可接受）     │
│  Batch 策略        │  Continuous + 小 batch │  Static/大 batch    │
│  显存策略          │  KV Cache 共享为主     │  可全部用于推理      │
│  优先级            │  必须支持（付费/免费）  │  无优先级            │
│  弹性扩缩          │  需要（应对流量峰值）  │  固定规模             │
│  容错              │  快速恢复（秒级）       │  可接受更长恢复时间   │
└────────────────────┴──────────────────────┴──────────────────────┘
```

**两者的混合是常态**：大多数生产环境中两者并存——例如白天跑在线 Chat 服务，夜间跑文档批量向量化。关键是**两类任务不要混在同一 GPU 实例上**——离线批处理的高吞吐策略会破坏在线服务的延迟 SLA。

### 10.2 容量规划的正确打开方式

很多团队做容量规划的流程是"先买卡，再看能跑多少 QPS"，这是把因果关系搞反了。正确流程是：

```
正确流程：SLA -> 单请求资源需求 -> 硬件容量 -> 集群规模

错误流程：买了 8 张 A100 -> 能跑什么模型？-> 能支撑多少 QPS？（本末倒置）
```

**步骤 1：定义 SLA**

```
选定场景，写下具体数字：
  "Chat 服务：P95 TTFT < 500ms, P95 TPOT < 30ms, P99 TPOT < 60ms"
  而不是 "延迟要低，体验要好"
```

**步骤 2：测量单请求资源消耗**

```bash
# 用代表性 prompt（P50、P95、P99 长度各一）压测单请求
# 记录：prefill 时间、per-token decode 时间、KV Cache 大小

# 例如单张 A100-80G + 33B 模型：
#   P50 prompt (200 tok): prefill=10ms, per-token=18ms, KV=0.4GB
#   P95 prompt (800 tok): prefill=40ms, per-token=20ms, KV=1.6GB
#   P99 prompt (2000 tok): prefill=100ms, per-token=25ms, KV=4.0GB
```

**步骤 3：从排队论推算容量**

```
给定 SLA (P95 TTFT < 500ms) 和 P95 请求的 prefill 时间 (40ms)：

最大可接受的排队时间 = 500ms - 40ms = 460ms

M/M/1 排队模型下：
  Wq = rho / (mu - lambda) < 0.46s

  假设 mu ≈ 1/avg_service_time ≈ 1/5s ≈ 0.2 req/s (per GPU, 长请求)

  rho / (0.2 - lambda) < 0.46
  -> lambda < 0.2 - rho/0.46

  取 rho=0.7 (安全水位线)：
    lambda < 0.2 - 0.7/0.46 ≈ 0.2 - 1.52 (负数！意味着单 GPU 不够)

  增大 mu 或增加 GPU (M/M/c)：
    4 GPU: mu_total ≈ 0.8 req/s
    rho=0.7 时: lambda < 0.8 - 0.7/0.46 ≈ 0.8 - 1.52 (仍不够)

  说明：对于 P95 是长 prompt 的场景，需要更多 GPU 并行
        或者降低 SLA 预期（接受更长的 TTFT）
```

### 10.3 生产监控——不是所有指标都等价

```
┌──────────────────────────────────────────────────────────────────┐
│           LLM 推理监控指标的四层金字塔（从必须到可选）              │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│                        ┌─────────┐                               │
│  L4: 业务指标          │ 会话数   │  季度/年度汇报用               │
│                        │ 用户数   │  对实时排障无直接帮助           │
│                        └─────────┘                               │
│                      ┌───────────────┐                            │
│  L3: 系统容量         │ GPU 利用率    │  容量规划用                  │
│                      │ KV Cache 使用率│  不是实时排障的第一指标    │
│                      └───────────────┘                            │
│                  ┌──────────────────────────┐                     │
│  L2: 服务健康      │ 排队长度 (waiting seqs)  │  最早预警信号        │
│                  │ 错误率 / OOM 次数        │  直接反映健康状态    │
│                  └──────────────────────────┘                     │
│              ┌──────────────────────────────────┐                 │
│  L1: 用户体验  │ P50/P95/P99 TTFT               │  最诚实的指标     │
│              │ P50/P95/P99 TPOT               │  最终用户感知的    │
│              │ TPOT 抖动 (std/mean 比值)       │  卡顿感的量化     │
│              └──────────────────────────────────┘                 │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

**L1 的三个关键洞察**：

```
1. P99 TTFT 是"最诚实"的指标
   一个 10 req/s 的服务，P99 意味着每 10 秒就有 0.1 个请求的 TTFT 超过这个值。
   如果你的 P99 TTFT 是 5 秒——每小时就有 36 个用户体验到 5 秒以上的等待。
   这 36 个用户中有相当数量会认为"服务挂了"。

2. TPOT 的抖动比绝对值更重要
   两种场景，哪个体验更好？
     A: TPOT 恒定为 35ms（慢但稳定）
     B: TPOT 在 15ms-80ms 之间波动（平均 20ms，但不稳定）
   答案：A 更好。用户对稳定的节奏有预期，抖动带来的"卡顿感"比均匀的慢更难接受。

3. 排队长度是最早的预警信号
   P99 TTFT 飙升时，往往已经晚了——因为 P99 是一个"滞后指标"。
   排队长度 (num_requests_waiting) 是一个"先行指标"——当它从 0 变为 3 时，
   你还有几秒钟的时间窗口来响应（如触发弹性扩容或降级策略）。
```

**推荐的告警阈值**：

```
指标                     告警阈值               说明
──────────────────────────────────────────────────────────
num_requests_waiting     > 5 持续 10s          早期预警，可能队列堆积
P95 TTFT                 > SLA_bound * 1.5     需立即关注
P99 TTFT                 > SLA_bound * 2       严重告警
gpu_cache_usage_perc     > 93%                 即将触发抢占或 OOM
request_error_rate       > 0.1%                可能有异常请求类型
tpot_std / tpot_mean     > 0.5                 抖动过大，调度可能失衡
```

### 10.4 生产环境六大踩坑

**坑 1：Prefix Caching 的"虚假命中率"**

```
现象：监控显示 prefix_cache_hit_rate = 85%，但 TTFT 没有明显下降。

原因：缓存命中了，但命中的是极短的前缀（如 "You are" 的 3 个 token），
      主要的 prefill 计算（文档内容、用户查询）仍需从头计算。

解决：
  - 不要只看 hit rate，要看 hit_tokens / total_prompt_tokens
  - 设计固定且足够长的 system prompt（200+ tokens）
  - 多轮对话尽量保持前缀一致性（避免在中间插入不同的指令）
```

**坑 2：Chunked Prefill 导致的内存碎片**

```
现象：运行 2 小时后，尽管 KV Cache 使用率只有 75%，
      新请求却无法分配 KV Cache 块。

原因：Chunked Prefill 的中间状态——一个请求分配了前 3 个 chunk (共 48 个 block)，
      但 chunk 之间可能跨越了不连续的 block 区域，产生碎片。

解决：
  - vLLM 的 PagedAttention 已经通过 block table 解决了逻辑碎片
  - 物理碎片需要监控 block_manager 的 free_blocks 连续性
  - 严重的碎片可通过周期性 GC 或降低 gpu_memory_utilization 缓解
```

**坑 3：梯度累积的请求（Tokenization 不一致）**

```
现象：两个请求的原始文本前缀完全一致，
     但 prefix caching 没有命中。

原因：tokenizer 的状态可能不同——
      例如 BOS token 的有无、padding 方式、特殊 token 处理差异。

解决：
  - 统一 tokenizer 调用方式（使用同一个 tokenizer 实例）
  - 使用 add_special_tokens=True 保持一致性
  - 在负载均衡层提取前缀 hash 时使用 token IDs 而非原始文本
```

**坑 4：Max-Model-Len 设置不当**

```
现象：某些合法请求被拒绝，返回 400 错误。

原因：max_model_len 设置得太小，而实际请求的 prompt_tokens + max_tokens 超出限制。

正确设置：
  max_model_len >= P99(prompt_length) + P99(max_output_tokens) * 1.2

  预留 20% 余量以应对 KV Cache padding 和 alignment 开销。
  但也不要无限放大 max_model_len——它会直接影响显存预算。
```

**坑 5：Garbage Collection (Python GC) 引发延迟抖动**

```
现象：TPOT 每隔几秒出现一个 100ms+ 的尖峰，与请求模式无关。

原因：Python 的 GC（特别是引用计数清理大量小对象时）占用了 CPU 时间，
      导致 CUDA kernel launch 延迟。在高 QPS 场景下尤其明显。

解决：
  - 使用 gc.disable() + 手动 gc.collect() 定时回收
  - 监控 Python 进程的 CPU 使用率抖动
  - vLLM 最新版本已做优化，但仍需关注
```

**坑 6：多实例部署时的负载不均**

```
现象：3 个实例，实例 A 的 GPU 利用率 92%，实例 B 和 C 只有 40%。

原因：简单的 round-robin 或 random 负载均衡不考虑请求特征。
      实例 A 可能分到了多个长 prompt 请求，而 B 和 C 都是短请求。

解决：
  - 使用最少连接数 (least_connections) 而非 round-robin
  - 或使用 prefix-aware LB（同时解决缓存亲和性）
  - 监控各实例的排队长度差异 (max_waiting - min_waiting) < 3
```

### 10.5 成本视角：GPU 时间片的价值和账本

```
一个常见误区：用 "tokens/s/dollar" 作为唯一优化目标。

正确视角：
  ┌─────────────────────────────────────────────────────────────┐
  │  总成本 = GPU 租用成本 + 机会成本 + SLA 违约成本            │
  │                                                             │
  │  tokens/s/dollar 只覆盖了 GPU 租用成本。                    │
  │                                                             │
  │  机会成本：                                                │
  │    高峰期 GPU 不足 -> 队列堆积 -> 用户流失                  │
  │    (每流失一个付费用户，价值远超几张 GPU 的月租)             │
  │                                                             │
  │  SLA 违约成本：                                             │
  │    P99 TTFT 突破 SLA -> 用户投诉 / 客户赔偿                │
  │    对于 B2B API 服务，SLA 违约可能有合同罚款               │
  └─────────────────────────────────────────────────────────────┘
```

**弹性扩缩容的经济学**：

```
GPU 集群规模的决策矩阵：

场景 A: 恒定 50 req/s，不需要弹性 -> 固定 4 GPU 全天运行
场景 B: 白天 100 req/s，夜间 5 req/s -> 白天 8 GPU，夜间 2 GPU

场景 B 看似需要弹性，但冷启动成本必须计算：
  - 模型加载到 GPU: 30-120 秒（取决于模型大小和磁盘 I/O）
  - 这 30-120 秒内，剩余 GPU 需要承担全部负载 -> 可能触发雪崩

建议：
  - 如果峰谷比 < 3:1，维持固定容量（硬件成本 < 弹性复杂度成本）
  - 如果峰谷比 > 5:1，考虑弹性但保留"基座容量"（30% 的峰值容量）
  - 使用预测性扩容（基于历史流量模式）而非被动扩容（队列堆积后触发）
```

### 10.6 架构演进方向

当前 LLM 推理架构的三个主要演进方向：

```
1. Prefill-Decode Disaggregation (PDD)
   ────────────────────────────────────
   将 Prefill 和 Decode 部署在不同的 GPU 组上。
   Prefill GPU 组：大显存、高算力、专门跑 prefill（compute-bound 优化）
   Decode GPU 组： 高带宽、专门跑 decode（memory-bandwidth 优化）

   代表工作：Splitwise (ISCA'24), TetriServe (OSDI'24)
   挑战：KV Cache 在 Prefill/Decode GPU 组之间传输的延迟

2. KV Cache 分层存储
   ──────────────────
   GPU HBM (热) -> CPU RAM (温) -> NVMe SSD (冷)
   类似 CPU 的 L1/L2/L3/内存 缓存层次。

   长对话的早期轮次 KV Cache 可以卸载到 CPU RAM，
   当前轮次保留在 GPU HBM，需要时再换入。

   挑战：交换策略（LRU? LFU? 基于对话轮次？）的选择

3. 多模型共享前缀缓存池
   ────────────────────
   同一集群内多个模型共享一个前缀缓存池（Redis/分布式 KV Store）。
   例如：部署了 33B 和 67B 两个模型，但它们的 system prompt 前缀
   可能不同（tokenizer 不同导致 tokenization 不同），
   所以前缀缓存通常是模型级别的，不是集群级别的。

   真正可行的场景：同一模型的多实例共享前缀缓存
   -> 通过 prefix-aware LB 将相同前缀路由到同一实例
   -> 实例间通过 KV Cache 迁移实现负载再平衡
```

---

## 11. 深入学习资源

### 9.1 必读论文

```
基础理论：
┌──────────────────────────────────────────────────────────────────┐
│ [Paper] "Efficient Memory Management for Large Language Model     │
│     Serving with PagedAttention" (vLLM, SOSP 2023)               │
│   - KV cache 的虚拟内存管理，PagedAttention 机制                  │
│   - 链接: https://arxiv.org/abs/2309.06180                       │
├──────────────────────────────────────────────────────────────────┤
│ [Paper] "Orca: A Distributed Serving System for Transformer-Based │
│     Generative Models" (OSDI 2022)                               │
│   - 首个提出 iteration-level scheduling 的系统                    │
│   - 链接: https://www.usenix.org/conference/osdi22/              │
├──────────────────────────────────────────────────────────────────┤
│ [Paper] "Sarathi-Serve: A Low-Lag Scheduling and Memory           │
│     Optimization for LLM Inference" (2024)                        │
│   - Chunked prefill 的深入分析和 stall-free scheduling           │
│   - 链接: https://arxiv.org/abs/2403.02310                       │
├──────────────────────────────────────────────────────────────────┤
│ [Paper] "Splitwise: Efficient Generative LLM Inference Using      │
│     Phase Splitting" (ISCA 2024)                                  │
│   - Prefill 和 Decode 分离到不同 GPU                             │
│   - 链接: https://arxiv.org/abs/2311.18677                       │
├──────────────────────────────────────────────────────────────────┤
│ [Paper] "Taming Throughput-Latency Tradeoff in LLM Inference      │
│     with Sarathi-Serve" (OSDI 2024)                               │
│   - 系统性分析 chunked prefill 对 TTFT/TPOT 的影响               │
│   - 链接: https://arxiv.org/abs/2403.02310                       │
└──────────────────────────────────────────────────────────────────┘

排队论与性能：
┌──────────────────────────────────────────────────────────────────┐
│ [Paper] "Llama: A Heterogeneous & Serverless Framework for        │
│     Auto-Tuning LLM Serving" (2024)                              │
│   - LLM 推理的排队模型和自适应调优                                │
│   - 链接: https://arxiv.org/abs/2402.08851                       │
├──────────────────────────────────────────────────────────────────┤
│ [Paper] "Infinite-LLM: Efficient LLM Inference Serving with       │
│     Distributed Long-Context via Disaggregated Prefill            │
│     and Decoding" (2024)                                         │
│   - Prefill 和 Decode 分离部署的架构                              │
│   - 链接: https://arxiv.org/abs/2401.02669                       │
└──────────────────────────────────────────────────────────────────┘

前缀缓存：
┌──────────────────────────────────────────────────────────────────┐
│ [Paper] "SGLang: Efficient Execution of Structured Language       │
│     Model Programs" (2024)                                       │
│   - RadixAttention：基于 radix tree 的自动前缀缓存                │
│   - 链接: https://arxiv.org/abs/2312.07104                       │
├──────────────────────────────────────────────────────────────────┤
│ [Paper] "CacheGen: KV Cache Compression and Streaming for Fast    │
│     Large Language Model Serving" (2024)                         │
│   - KV cache 压缩以加速传输                                       │
│   - 链接: https://arxiv.org/abs/2310.07240                       │
└──────────────────────────────────────────────────────────────────┘

抢占与内存管理：
┌──────────────────────────────────────────────────────────────────┐
│ [Paper] "FlexGen: High-Throughput Generative Inference of Large   │
│     Language Models with a Single GPU" (ICML 2023)              │
│   - 单 GPU 上的显存-计算交换策略                                  │
│   - 链接: https://arxiv.org/abs/2303.06865                       │
├──────────────────────────────────────────────────────────────────┤
│ [Paper] "DeepSpeed Inference: Enabling Efficient Inference of     │
│     Transformer Models" (2022)                                   │
│   - ZeRO-Inference 的显存优化                                     │
│   - 链接: https://arxiv.org/abs/2207.00032                       │
└──────────────────────────────────────────────────────────────────┘
```

### 9.2 开源项目与代码库

```
核心推理框架：
┌──────────────────────────────────────────────────────────────────┐
│ [Repo] vLLM:     https://github.com/vllm-project/vllm           │
│    - 生产级 LLM 推理引擎，PagedAttention + Continuous Batching   │
│    - 重点阅读: vllm/core/scheduler.py                           │
│              vllm/worker/model_runner.py                        │
│              vllm/core/block_manager.py                         │
├──────────────────────────────────────────────────────────────────┤
│ [Repo] SGLang:   https://github.com/sgl-project/sglang          │
│    - RadixAttention 前缀缓存，structured generation              │
│    - 重点阅读: python/sglang/srt/managers/scheduler.py           │
├──────────────────────────────────────────────────────────────────┤
│ [Repo] TensorRT-LLM: https://github.com/NVIDIA/TensorRT-LLM     │
│    - NVIDIA 官方推理引擎，in-flight batching                     │
│    - 重点阅读: cpp/tensorrt_llm/batch_manager/                  │
├──────────────────────────────────────────────────────────────────┤
│ [Repo] lmdeploy: https://github.com/InternLM/lmdeploy           │
│    - TurboMind 引擎，persistent batch                           │
│    - 重点阅读: lmdeploy/pytorch/engine/                         │
└──────────────────────────────────────────────────────────────────┘

基准测试工具：
┌──────────────────────────────────────────────────────────────────┐
│ [Repo] vLLM benchmarks: https://github.com/vllm-project/vllm/   │
│    tree/main/benchmarks                                          │
│    - 官方基准测试脚本（throughput, latency, serving）            │
├──────────────────────────────────────────────────────────────────┤
│ [Repo] LLMPerf:  https://github.com/ray-project/llmperf         │
│    - LLM 推理性能基准测试框架                                    │
├──────────────────────────────────────────────────────────────────┤
│ [Repo] GenAI-Perf: https://github.com/triton-inference-server/   │
│    perf_analyzer                                                 │
│    - NVIDIA Triton 的性能分析工具                                │
└──────────────────────────────────────────────────────────────────┘
```

### 9.3 博客文章与技术报告

```
┌──────────────────────────────────────────────────────────────────┐
│ [Blog] "How continuous batching enables 23x throughput"         │
│    by Anyscale (2023)                                           │
│    https://www.anyscale.com/blog/continuous-batching-llm-       │
│    inference                                                     │
│    - Continuous batching 的直观解释和基准测试                    │
├──────────────────────────────────────────────────────────────────┤
│ [Blog] "vLLM: 23x Higher Throughput than HuggingFace             │
│    Transformers" by vLLM Team                                   │
│    https://blog.vllm.ai/2023/06/20/vllm.html                    │
│    - PagedAttention 设计动机和实现详解                           │
├──────────────────────────────────────────────────────────────────┤
│ [Blog] "Mastering LLM Serving Performance"                      │
│    by BentoML (2024)                                            │
│    https://www.bentoml.com/blog/mastering-llm-serving-          │
│    performance                                                    │
│    - 端到端的 LLM 服务性能优化指南                               │
├──────────────────────────────────────────────────────────────────┤
│ [Blog] "How to make LLM inference faster"                       │
│    by Hugging Face (2024)                                       │
│    https://huggingface.co/docs/text-generation-inference/       │
│    - Flash Attention, quantization 等各种加速技术               │
├──────────────────────────────────────────────────────────────────┤
│ [Blog] "Chunked Prefill in Practice"                            │
│    by Neural Magic (2024)                                       │
│    https://neuralmagic.com/blog/chunked-prefill/                │
│    - Chunked prefill 的实现细节和效果评估                        │
├──────────────────────────────────────────────────────────────────┤
│ [Blog] "Prefix Caching Deep Dive"                               │
│    vLLM 官方文档                                                 │
│    https://docs.vllm.ai/en/latest/features/automatic_prefix_    │
│    caching.html                                                  │
│    - APC 的完整文档、使用方法和限制                              │
└──────────────────────────────────────────────────────────────────┘
```

### 9.4 进阶学习路径

```
初学者（2周）：
  1. 阅读 vLLM 论文（SOSP'23），理解 PagedAttention
  2. 运行 vLLM 官方 benchmark 脚本，理解各指标含义
  3. 手写一个简单的 token-level scheduler（200行代码）
  4. 阅读 vllm/core/scheduler.py 源码

进阶（1个月）：
  1. 阅读 Orca、Sarathi-Serve 论文
  2. 实现自己的 chunked prefill 逻辑
  3. 在真实负载下测试不同调度策略
  4. 研究 prefix caching 的 radix tree 实现

专家方向（持续）：
  1. 研究 disaggregated prefill/decode 架构
  2. 探索 multi-instance 下的调度协同
  3. 研究 adaptive scheduling（强化学习/启发式）
  4. 贡献开源推理框架的调度器模块

推荐动手项目：
  1. 写一个 LLM 推理基准测试工具（含 TTFT/TPOT 测量）
  2. 实现 MLFQ 调度器作为 vLLM 的 scheduler 插件
  3. 搭建 prefix-aware 负载均衡器
  4. 对比不同 chunk size 对真实负载的影响并绘制图表
```

### 9.5 术语速查表

```
┌────────────────────┬──────────────────────────────────────────────┐
│ 术语               │ 定义                                         │
├────────────────────┼──────────────────────────────────────────────┤
│ TTFT               │ Time To First Token，首个 token 的延迟       │
│ TPOT               │ Time Per Output Token，每个输出 token 的间隔 │
│ Continuous Batching│ 在每次迭代动态调整批次内容，而非等一批全完成  │
│ PagedAttention     │ 将 KV cache 分成固定大小的块，类似虚拟内存    │
│ Prefill            │ 并行处理 prompt 中所有 token 的阶段           │
│ Decode             │ 逐 token 生成输出的阶段                       │
│ Chunked Prefill    │ 将长 prefill 切成多块在多次迭代中完成         │
│ Preemption         │ 释放当前请求的显存以服务新请求                │
│ Swap               │ 将 KV cache 从 GPU 拷贝到 CPU 以释放显存     │
│ Recompute          │ 丢弃 KV cache，恢复时重新 prefill            │
│ APC                │ Automatic Prefix Caching，自动前缀缓存        │
│ MLFQ               │ Multi-Level Feedback Queue，多级反馈队列     │
│ WFQ                │ Weighted Fair Queueing，加权公平队列          │
│ SLA                │ Service Level Agreement，服务等级协议         │
│ Jain's Index       │ 公平性指标，[1/n, 1.0]                       │
│ KV Cache           │ Key-Value 缓存，避免重复计算 attention         │
│ Tensor Parallelism │ 将模型层的权重切分到多个 GPU 并行计算         │
│ Roofline Model     │ 分析计算瓶颈在算力还是带宽的模型              │
│ HBM                │ High Bandwidth Memory，GPU 的高速显存        │
│ LRU                │ Least Recently Used，最近最少使用淘汰策略     │
└────────────────────┴──────────────────────────────────────────────┘
```

---

> **本文档适用于以下部署场景的深入学习：**
> - 部署 33B/67B 大规模语言模型
> - 对接 Claude Code 等 Agent 工作流
> - 构建 RAG (Retrieval-Augmented Generation) 服务
> - 优化生产级 LLM API 的延迟和吞吐
>
> **最后更新**: 2026-07
>
> **贡献**: 欢迎提交 PR 补充实战经验和最新研究成果。
