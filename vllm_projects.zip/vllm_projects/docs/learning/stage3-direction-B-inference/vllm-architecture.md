# vLLM 架构深度解析

> **官方仓库**: https://github.com/vllm-project/vllm
> **核心论文**: "Efficient Memory Management for Large Language Model Serving with PagedAttention" (SOSP 2023)
> **版本参考**: vLLM v0.6.x ~ v1.x

---

## 白话引入

想象你经营一家生意火爆的网红餐厅。每到饭点，数百个订单（推理请求）同时涌入。每个订单都写着菜品的具体要求：前菜必须按顺序做（prefill），主菜是一个接一个出（decode），分量还不一样——有的 200 字小作文，有的是 2 万字长文。

你的后厨系统是这样运作的：

- **服务台（API Server）**负责接单、把菜品要求翻译成厨师能看懂的指令（tokenize），再把做好的菜端出去（stream 输出）。
- **行政总厨（Scheduler）**站在厨房中央，盯着所有正在炒的菜和排队等候的订单，决定谁先下锅、锅里同时做几道菜（batch）、哪些菜可以共用同一份配好的料（Prefix Caching）、锅快不够用时把哪道菜暂时换到备菜台（Preemption）。
- **厨师们（Workers）**每人负责一整桌菜的部分工序：切配菜的张量并行（TP Rank 0 在 GPU0 上），炒主菜的张量并行（TP Rank 1 在 GPU1 上），炒完后对一下味道确认一致（All-Reduce）。
- **备菜台（KV Cache）**上放满了提前切好的配菜：每个 token 的 Key 和 Value 都像葱姜蒜一样预处理好了。下个菜只需要加新料，老料从备菜台上取就行，不用重新切。但备菜台空间有限，vLLM 的 **PagedAttention** 就像智能备菜架：不做大格子（连续分配），而用小方盒（Block），可以灵活组合，几乎不浪费空间。

本文带你从前台到后厨，完整走完 vLLM 这家餐厅的运作全流程。

### 术语预检

| 术语 | 一句话类比 | 专业释义 |
|------|-----------|---------|
| Continuous Batching | 像厨师同时炒多道菜，哪道菜出锅立刻加上下一道，不等整桌菜上齐 | 推理引擎的动态批处理技术：已完成生成的请求立即退出 batch，新请求动态加入，最大化 GPU 利用率。对比静态 batching 只能等整个 batch 完成 |
| PagedAttention | 像智能备菜架：不按"每道菜一个大格子"来分配，而是用小方盒灵活拼接，几乎不浪费空间 | vLLM 的核心内存管理机制：将 KV Cache 划分为固定大小的 Block（如每 block 16 tokens），通过 Block Table 映射逻辑序列到物理块，支持非连续存储和 Copy-on-Write 共享 |
| KV Cache | 像提前备好的葱姜蒜（Key 和 Value），下个菜直接用，不用重新备料 | 自回归推理中缓存的 Key 和 Value 张量。每生成一个新 token，只需计算新 token 的 QKV，历史的 K 和 V 从缓存读取，避免对整个序列重新计算 |
| Block Table | 像配菜单：记录每道菜（序列）的配料放在备菜架的哪几个格子里 | 每个序列的逻辑块到物理块的映射表。GPU kernel 在计算 attention 时通过此表查找到分散在不同物理位置的 KV Cache block |
| Prefill / Decode | 像做第一道菜需要把所有配菜切好（prefill），之后的菜只需要加新料翻炒（decode） | Prefill 阶段一次性处理整个 prompt（compute-bound），Decode 阶段逐 token 生成（memory-bound）。Chunked Prefill 将长 prompt 分块与 decode 交错执行 |
| Prefix Caching | 像同样的前菜配方（system prompt），不同主菜共用一份配菜，不重复备料 | 基于 token 哈希的前缀缓存机制。多个请求共享相同前缀时（如 system prompt），复用已计算的 KV Cache block，通过 Radix Tree 管理缓存块 |

---

## 目录

1. [设计哲学](#设计哲学)
2. [完整架构概览](#完整架构概览)
3. [AsyncLLMEngine 深度剖析](#asyncllmengine-深度剖析)
4. [调度器 (Scheduler)](#调度器-scheduler)
5. [BlockSpaceManager 与 PagedAttention](#blockspacemanager-与-pagedattention)
6. [Worker 与 ModelRunner](#worker-与-modelrunner)
7. [Attention 后端](#attention-后端)
8. [CUDA Graphs](#cuda-graphs)
9. [多 GPU 张量并行 (TP)](#多-gpu-张量并行-tp)
10. [配置完整参考](#配置完整参考)
11. [请求生命周期全链路追踪](#请求生命周期全链路追踪)
12. [vLLM v0 vs v1 对比](#vllm-v0-vs-v1-对比)
13. [生态对比](#生态对比)
14. [常见问题与解决方案](#常见问题与解决方案)
15. [深入学习资源](#深入学习资源)

---

## 设计哲学

### 为什么需要 vLLM

HuggingFace Transformers 是为**研究**设计的，不是为了**生产级推理服务**设计的。
在大规模部署中，HF Transformers 暴露出三个核心问题：

```
┌──────────────────────────────────────────────────────────────────────────┐
│                    HF Transformers 的三大生产瓶颈                          │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  1. 内存浪费 (KV Cache 碎片化)                                            │
│     ┌──────────────────────────────────────────────────────────────┐    │
│     │  请求A: ████████████████░░░░░░░░░░░░░░░░░░ (预留512但只用200) │    │
│     │  请求B: ████████████░░░░░░░░░░░░░░░░░░░░░░ (预留512但只用150) │    │
│     │  请求C: ██████████████████████░░░░░░░░░░░░ (预留512但只用280) │    │
│     │                                                              │    │
│     │  浪费率 ≈ (预留-实际)/预留 ≈ 50-60%                           │    │
│     │  → PagedAttention: 按需分页, 浪费率 < 4%                       │    │
│     └──────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  2. 静态批处理 (Static Batching)                                          │
│     ┌──────────────────────────────────────────────────────────────┐    │
│     │  批次中请求长度必须相同, 新请求必须等当前批次全部完成           │    │
│     │                                                              │    │
│     │  时间轴:                                                      │    │
│     │  ────────────────────────────────────────────────────────────│    │
│     │  Req1 ████████████████████████████ (512 tokens)              │    │
│     │  Req2 ████████████████ (256 tokens)                          │    │
│     │  Req3 ████████████████████████████████████████ (768 tokens)  │    │
│     │                        ^  Req2 完成后空转等待                  │    │
│     │  → Continuous Batching: 动态加入/退出, GPU 利用率大幅提升     │    │
│     └──────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  3. Kernel 启动开销                                                      │
│     ┌──────────────────────────────────────────────────────────────┐    │
│     │  每个 decode step: 启动 N 个 CUDA kernel                       │    │
│     │  每个 kernel 启动延迟: 5-10 μs (microseconds)                  │    │
│     │  若有 40 层 × 3 kernel/层 = 120 次 launch                     │    │
│     │  总开销: 120 × 8μs ≈ 960μs ≈ 1ms per step                    │    │
│     │  → CUDA Graphs: 所有 kernel 合并为一次 launch                  │    │
│     └──────────────────────────────────────────────────────────────┘    │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

### vLLM vs HF Transformers 性能对比

来自论文的实测数据：

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    吞吐量对比 (OPT-13B, A100-40GB)                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  方法              │ 最大吞吐 (tokens/s) │ 相对提升                       │
│  ─────────────────┼────────────────────┼────────                        │
│  HF Transformers   │   312 tokens/s      │ 1× (基线)                     │
│  Orca (ORCA)       │  1327 tokens/s      │ 4.25×                        │
│  FasterTransformer │  3450 tokens/s      │ 11.1×                        │
│  vLLM              │  7434 tokens/s      │ 23.8× ← 论文数据              │
│                                                                         │
│  在 OPT-175B 上: vLLM 比 Orca 高 3.5× 吞吐                              │
│  在实际部署中: vLLM 通常达到 HF 的 14-24× 吞吐提升                       │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    内存效率对比                                           │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  方法              │ 最大 batch size │ 内存利用率                         │
│  ─────────────────┼─────────────────┼──────────                         │
│  HF Transformers   │       4         │ ~20-40%                          │
│  Orca              │       8         │ ~40-60%                          │
│  FasterTransformer │      12         │ ~60-80%                          │
│  vLLM              │      32+        │ ~80-96%                          │
│                                                                         │
│  vLLM 的内存复用 (物理块共享) 使其在相同 GPU 上服务更多请求               │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 完整架构概览

### 整体架构图

```
┌───────────────────────────────────────────────────────────────────────────────────┐
│                              vLLM 全栈架构                                          │
│                                                                                   │
│  ┌─────────────────────────────────────────────────────────────────────────────┐ │
│  │                         客户端 (HTTP / gRPC)                                  │ │
│  │  POST /v1/chat/completions           POST /v1/completions                    │ │
│  │  OpenAI-compatible API                                                       │ │
│  └───────────────────────────────────────┬─────────────────────────────────────┘ │
│                                          │                                        │
│                                          ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────────────┐ │
│  │                       API Server (FastAPI / Uvicorn)                          │ │
│  │                                                                              │ │
│  │  文件: vllm/entrypoints/openai/api_server.py                                 │ │
│  │  类:   OpenAIServingChat, OpenAIServingCompletion                            │ │
│  │  职责: 请求解析、参数校验、OpenAI 协议兼容、Streaming/SSE 响应                 │ │
│  └───────────────────────────────────────┬─────────────────────────────────────┘ │
│                                          │                                        │
│                                          ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────────────┐ │
│  │                        AsyncLLMEngine (异步推理引擎)                           │ │
│  │                                                                              │ │
│  │  文件: vllm/engine/async_llm_engine.py                                       │ │
│  │  类:   AsyncLLMEngine, AsyncEngineArgs                                       │ │
│  │  职责:                                                                       │ │
│  │    - 请求队列管理 (add_request)                                               │ │
│  │    - 后台循环调度 (step_async)                                                │ │
│  │    - 输出后处理 (OutputProcessor): token → text → stream                     │ │
│  │    - 请求状态机管理: WAITING → RUNNING → FINISHED / SWAPPED                   │ │
│  │    - 中止处理 (abort_request)                                                 │ │
│  └──────────────┬────────────────────────────┬─────────────────────────────────┘ │
│                 │                            │                                   │
│                 ▼                            ▼                                   │
│  ┌──────────────────────────┐  ┌──────────────────────────────────────────────┐ │
│  │    Scheduler (调度器)     │  │       BlockSpaceManager (内存管理器)          │ │
│  │                          │  │                                              │ │
│  │  文件: vllm/core/        │  │  文件: vllm/core/block/                      │ │
│  │        scheduler.py      │  │        block_manager.py                      │ │
│  │  类: Scheduler           │  │  类: BlockSpaceManager                       │ │
│  │  职责:                   │  │  职责:                                       │ │
│  │  - Prefill 调度          │  │  - PagedAttention 块分配/释放                 │ │
│  │  - Decode 调度           │  │  - Copy-on-Write 机制                        │ │
│  │  - 抢占 (Preemption)     │  │  - 前缀缓存 (Prefix Caching)                  │ │
│  │  - 分块预填充            │  │  - 块表 (Block Table) 维护                    │ │
│  └────────────┬─────────────┘  └──────────────────────────────────────────────┘ │
│               │                                                                  │
│               ▼                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────────────┐ │
│  │                        Workers (Worker 层)                                    │ │
│  │                                                                              │ │
│  │  文件: vllm/worker/worker.py                                                 │ │
│  │  类: Worker                                                                  │ │
│  │                                                                              │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │ │
│  │  │   Worker 0   │  │   Worker 1   │  │   Worker 2   │  │   Worker 3   │     │ │
│  │  │  (TP Rank 0) │  │  (TP Rank 1) │  │  (TP Rank 2) │  │  (TP Rank 3) │     │ │
│  │  │   GPU:0      │  │   GPU:1      │  │   GPU:2      │  │   GPU:3      │     │ │
│  │  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘     │ │
│  │         └─────────────────┼─────────────────┼─────────────────┘              │ │
│  │                           │ NCCL All-Reduce                                 │ │
│  │                           ▼                                                  │ │
│  │  ┌─────────────────────────────────────────────────────────────────────┐    │ │
│  │  │                     ModelRunner (模型执行器)                          │    │ │
│  │  │                                                                      │    │ │
│  │  │  文件: vllm/worker/model_runner.py                                   │    │ │
│  │  │  类: ModelRunner                                                    │    │ │
│  │  │                                                                      │    │ │
│  │  │  execute_model():                                                     │    │ │
│  │  │  ┌──────────────┐   ┌──────────────┐   ┌──────────────┐              │    │ │
│  │  │  │ prepare_input│ → │   forward    │ → │    sample    │              │    │ │
│  │  │  │ 准备输入张量  │   │  模型前向传播 │   │  采样/贪心解码│              │    │ │
│  │  │  └──────────────┘   └──────────────┘   └──────────────┘              │    │ │
│  │  └─────────────────────────────────────────────────────────────────────┘    │ │
│  └─────────────────────────────────────────────────────────────────────────────┘ │
│                                          │                                        │
│                                          ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────────────┐ │
│  │                         GPU Kernels (底层实现)                                 │ │
│  │                                                                              │ │
│  │  ┌────────────────┐  ┌────────────────┐  ┌────────────────────────────────┐ │ │
│  │  │  FlashAttention │  │   FlashInfer   │  │        xFormers               │ │ │
│  │  │  (flash_attn)   │  │  (flashinfer)  │  │  (xformers)                    │ │ │
│  │  └────────────────┘  └────────────────┘  └────────────────────────────────┘ │ │
│  │                                                                              │ │
│  │  ┌──────────────────────────────────────────────────────────────────────┐   │ │
│  │  │               PagedAttention 自定义 CUDA Kernels                       │   │ │
│  │  │                                                                       │   │ │
│  │  │  文件: vllm/csrc/attention/                                           │   │ │
│  │  │  - reshape_and_cache_kernel: 将新 KV 写入 KV Cache                    │   │ │
│  │  │  - single_query_cached_kv_attention: PagedAttention 核心              │   │ │
│  │  │  - prefix_prefill_kernel: 前缀共享的 prefill                          │   │ │
│  │  └──────────────────────────────────────────────────────────────────────┘   │ │
│  └─────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                   │
└───────────────────────────────────────────────────────────────────────────────────┘
```

### 核心文件清单

```
vllm/
├── entrypoints/
│   └── openai/
│       ├── api_server.py          # FastAPI 应用入口
│       ├── serving_chat.py        # /v1/chat/completions 处理
│       ├── serving_completion.py  # /v1/completions 处理
│       └── protocol.py            # OpenAI 协议类型定义
│
├── engine/
│   ├── async_llm_engine.py        # 异步推理引擎 (核心)
│   ├── llm_engine.py              # 同步推理引擎
│   ├── async_timeout.py           # 超时管理
│   └── output_processor.py        # 输出后处理: token→text
│
├── core/
│   ├── scheduler.py               # 调度器: prefill/decode/preempt
│   ├── block/
│   │   ├── block_manager.py       # BlockSpaceManager
│   │   ├── block_table.py         # 块表数据结构
│   │   ├── prefix_caching_block.py # 前缀缓存块管理
│   │   └── naive_block.py         # 简单块管理 (无缓存)
│   └── evictor.py                 # LRU 淘汰策略
│
├── worker/
│   ├── worker.py                  # Worker: GPU 进程管理
│   └── model_runner.py            # ModelRunner: 模型执行
│
├── attention/
│   ├── backends/
│   │   ├── flash_attn.py          # FlashAttention 后端
│   │   ├── flashinfer.py          # FlashInfer 后端
│   │   └── xformers.py            # xFormers 后端
│   └── ops/
│       └── paged_attn.py          # PagedAttention 操作封装
│
├── model_executor/
│   ├── model_loader.py            # 模型加载 (safetensors, etc.)
│   └── layers/
│       ├── attention.py           # Attention 层实现
│       └── linear.py              # 线性层 (量化支持)
│
├── config.py                      # 全局配置: EngineArgs, ModelConfig, etc.
├── sampling_params.py             # 采样参数: temp, top_p, top_k, etc.
└── sequence.py                    # Sequence, SequenceGroup 数据结构
```

---

## AsyncLLMEngine 深度剖析

### 引擎初始化流程

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        AsyncLLMEngine 初始化流程                              │
│                                                                              │
│  AsyncEngineArgs                                                             │
│  ┌──────────────────────────────────────────────────────────────┐           │
│  │ model="meta-llama/Llama-3-8B"                                 │           │
│  │ dtype="auto"           → 自动选择最佳精度                       │           │
│  │ tensor_parallel_size=4 → 4路张量并行                           │           │
│  │ gpu_memory_utilization=0.90 → 90% GPU 内存用于 KV Cache       │           │
│  │ max_num_seqs=256       → 最多同时处理 256 个序列               │           │
│  │ max_model_len=8192     → 最大上下文长度                        │           │
│  └──────────────────────────────┬───────────────────────────────┘           │
│                                 │                                            │
│                                 ▼                                            │
│  ┌──────────────────────────────────────────────────────────────┐           │
│  │  1. 加载模型配置 (config.json)                                  │           │
│  │  2. 创建 Worker 进程 (每 GPU 一个)                              │           │
│  │  3. 初始化 NCCL 通信组                                         │           │
│  │  4. 加载模型权重 (safetensors / bin)                           │           │
│  │  5. 初始化 BlockSpaceManager (GPU KV Cache 块)                 │           │
│  │  6. 预热 CUDA Graphs (如果启用)                                 │           │
│  │  7. 启动后台调度循环                                             │           │
│  └──────────────────────────────────────────────────────────────┘           │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### add_request() - 请求入队

```python
# vllm/engine/async_llm_engine.py (简化版逻辑)

class AsyncLLMEngine:
    async def add_request(
        self,
        request_id: str,
        prompt: str | TokenSequence,
        sampling_params: SamplingParams,
        arrival_time: float | None = None,
        lora_request: LoRARequest | None = None,
    ) -> AsyncStream:
        """
        将新请求加入推理队列，返回异步流式输出
        """
        # 1. Tokenize 输入
        if isinstance(prompt, str):
            prompt_token_ids = self.tokenizer.encode(prompt)
        else:
            prompt_token_ids = prompt

        # 2. 创建 SequenceGroup
        seq_group = SequenceGroup(
            request_id=request_id,
            seqs=[],                    # 该组的序列列表
            sampling_params=sampling_params,
            arrival_time=arrival_time or time.time(),
            lora_request=lora_request,
        )

        # 对于 beam search 或 n>1, 会创建多个 sequence
        for i in range(sampling_params.n):
            seq = Sequence(
                seq_id=next(self.seq_counter),
                prompt_token_ids=prompt_token_ids,
                block_size=self.cache_config.block_size,
            )
            seq_group.add(seq)

        # 3. 加入等待队列
        self.scheduler.add_seq_group(seq_group)

        # 4. 创建输出流
        output_stream = AsyncStream(request_id)
        self.output_processor.add_request(request_id, output_stream)

        return output_stream
```

### 请求状态机

```
                              ┌──────────────────┐
                              │                  │
                    ┌────────►│     WAITING      │◄────────┐
                    │         │  (等待调度)       │         │
                    │         └────────┬─────────┘         │
                    │                  │                    │
                    │         调度器分配资源                  │
                    │                  │                    │
                    │                  ▼                    │
                    │         ┌──────────────────┐         │
                    │         │                  │         │
                    │  ┌─────►│     RUNNING      │─────┐   │
                    │  │      │  (正在推理)       │     │   │
                    │  │      └────────┬─────────┘     │   │
                    │  │               │               │   │
                    │  │          ┌────┴────┐          │   │
                    │  │          │         │          │   │
                    │  │          ▼         ▼          │   │
                    │  │  ┌──────────┐ ┌──────────┐   │   │
                    │  │  │ FINISHED │ │ SWAPPED  │   │   │
                    │  │  │ (完成)    │ │ (被换出)  │   │   │
                    │  │  └──────────┘ └────┬─────┘   │   │
                    │  │                    │         │   │
                    │  │             资源释放后          │   │
                    │  │                    │         │   │
                    │  └────────────────────┘         │   │
                    │                                 │   │
                    │         ┌──────────────────┐    │   │
                    │         │                  │    │   │
                    └─────────│    ABORTED       │◄───┘   │
                              │  (被中止)         │◄───────┘
                              └──────────────────┘
```

```python
# vllm/core/scheduler.py 中的 SequenceStatus 定义

class SequenceStatus(enum.Enum):
    WAITING = enum.auto()    # 等待首次调度
    RUNNING = enum.auto()    # 正在被推理
    SWAPPED = enum.auto()    # KV Cache 被换出到 CPU
    FINISHED_STOPPED = enum.auto()     # 正常停止 (EOS/stop token)
    FINISHED_LENGTH_CAPPED = enum.auto() # 达到最大长度
    FINISHED_ABORTED = enum.auto()      # 被用户中止
    FINISHED_IGNORED = enum.auto()      # 被忽略
```

### step_async() - 后台调度循环

```python
# vllm/engine/async_llm_engine.py (核心循环逻辑)

class AsyncLLMEngine:
    async def step_async(self) -> List[RequestOutput]:
        """
        单次调度步骤:
        1. 调度器决策: 选择哪些序列执行
        2. Worker 执行: 模型前向传播
        3. 后处理: 采样、解码、流式输出
        """

        # === 阶段 1: 调度 ===
        scheduler_outputs = self.scheduler.schedule()
        # scheduler_outputs 包含:
        #   - scheduled_seq_groups: 本轮执行的序列组
        #   - ignored_seq_groups: 被跳过的序列组
        #   - blocks_to_swap_in: 需要从 CPU 换回的块
        #   - blocks_to_swap_out: 需要换出到 CPU 的块
        #   - blocks_to_copy: 需要 Copy-on-Write 的块
        #   - num_lookahead_slots: 预分配的解码槽位数

        if not scheduler_outputs.scheduled_seq_groups:
            # 没有可调度的请求, 跳过
            return []

        # === 阶段 2: 执行 ===
        output = await self.model_executor.execute_model_async(
            scheduler_outputs=scheduler_outputs,
        )
        # output 是每个序列的 logits

        # === 阶段 3: 采样与后处理 ===
        request_outputs = []
        for seq_group in scheduler_outputs.scheduled_seq_groups:
            seqs = seq_group.get_seqs(status=SequenceStatus.RUNNING)

            # 采样
            sample_output = self._sample(
                seq_group=seq_group,
                logits=output.logits_for_seq(seqs),
                sampling_params=seq_group.sampling_params,
            )

            # Detokenize: token_ids → text
            new_text = self.tokenizer.decode(
                sample_output.output_token_ids,
                skip_special_tokens=True
            )

            # 构造输出
            request_output = RequestOutput(
                request_id=seq_group.request_id,
                prompt=seq_group.get_prompt(),
                outputs=[CompletionOutput(
                    text=new_text,
                    token_ids=sample_output.output_token_ids,
                    cumulative_logprob=sample_output.logprobs,
                )],
                finished=seq_group.is_finished(),
            )
            request_outputs.append(request_output)

        # === 阶段 4: 流式输出 ===
        for req_output in request_outputs:
            self.output_processor.process_outputs(req_output)

        return request_outputs

    async def run_engine_loop(self):
        """
        引擎主循环 (在后台任务中运行)
        """
        while True:
            # 检查是否有待处理的请求
            if not self.has_unfinished_requests():
                await asyncio.sleep(0.01)  # 空闲时短暂休眠
                continue

            # 执行一步
            outputs = await self.step_async()

            # 如果所有请求都完成, 退出
            if all(o.finished for o in outputs):
                break
```

### OutputProcessor - 输出处理

```python
# vllm/engine/output_processor.py (核心逻辑)

class OutputProcessor:
    """
    负责:
    1. 将原始 token 序列 detokenize 为文本
    2. 支持 streaming (逐 token 输出)
    3. 处理 stop strings 检测
    4. 维护请求级别的 token 计数
    """

    def process_outputs(
        self,
        engine_output: RequestOutput,
        seq_group: SequenceGroup,
    ) -> None:
        """
        处理一个序列组的输出
        """
        for seq in seq_group.get_seqs():
            # 获取 delta (新 token)
            new_tokens = seq.get_token_ids()[-1:]  # 每个 step 通常 1 个 token

            if seq_group.sampling_params.detokenize:
                # 增量解码: 只解码新 token
                delta_text = self.tokenizer.decode(
                    new_tokens,
                    skip_special_tokens=True,
                )
            else:
                delta_text = ""

            # 推送 delta 到流
            self.request_streams[seq_group.request_id].put(
                RequestOutput(
                    request_id=seq_group.request_id,
                    outputs=[CompletionOutput(
                        text=delta_text,
                        token_ids=new_tokens,
                    )],
                    finished=False,
                )
            )

        # 如果序列完成, 发送最终帧
        if seq_group.is_finished():
            self.request_streams[seq_group.request_id].put(
                RequestOutput(request_id=seq_group.request_id, finished=True)
            )
            # 释放资源
            self.scheduler.free_seq_group(seq_group)
```

### Abort 处理

```python
# vllm/engine/async_llm_engine.py

async def abort(self, request_id: str) -> None:
    """
    中止一个正在运行的请求。
    常见场景: 客户端超时/断开连接。
    """
    # 1. 从调度器移除
    seq_group = self.scheduler.get_seq_group(request_id)
    if seq_group is None:
        return  # 请求已完成或不存在

    # 2. 释放 KV Cache 块
    for seq in seq_group.get_seqs():
        self.block_manager.free(seq)  # 回收 GPU 内存块

    # 3. 从调度器移除序列组
    self.scheduler.abort_seq_group(request_id)

    # 4. 通知客户端
    self.output_processor.abort(request_id)
```

---

## 调度器 (Scheduler)

### 整体调度流程

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         Scheduler.schedule() 决策流程                         │
│                                                                              │
│  输入:                                                                        │
│  ┌──────────────────────────────┐                                            │
│  │ waiting: 等待队列中的序列组     │                                            │
│  │ running: 正在运行的序列组      │                                            │
│  │ swapped: 被换出的序列组        │                                            │
│  └──────────────────────────────┘                                            │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  阶段 1: Prefill 调度 (处理新请求)                                      │    │
│  │                                                                       │    │
│  │  for seq_group in waiting:                                            │    │
│  │    ┌─────────────────────────────────────────────────────────────┐   │    │
│  │    │ 条件检查:                                                     │   │    │
│  │    │  1. num_running_seqs < max_num_seqs                         │   │    │
│  │    │  2. num_batched_tokens + prompt_len <= max_num_batched_tokens│   │    │
│  │    │  3. 有足够的 GPU KV Cache 块                                  │   │    │
│  │    │  4. (可选) prompt_len <= max_model_len                       │   │    │
│  │    └─────────────────────────────────────────────────────────────┘   │    │
│  │    │                                                                 │    │
│  │    ▼ 如果可以调度                                                     │    │
│  │    ┌─────────────────────────────────────────────────────────────┐   │    │
│  │    │ 1. 分配 KV Cache 块 → BlockSpaceManager.allocate()           │   │    │
│  │    │ 2. 状态: WAITING → RUNNING                                  │   │    │
│  │    │ 3. 加入 scheduled_seq_groups                                 │   │    │
│  │    │ 4. 更新 num_batched_tokens += prompt_len                     │   │    │
│  │    └─────────────────────────────────────────────────────────────┘   │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  阶段 2: Decode 调度 (继续运行中的请求)                                 │    │
│  │                                                                       │    │
│  │  for seq_group in running:                                            │    │
│  │    每个序列产生 1 个新 token, 若仍在 num_batched_tokens 限制内则继续    │    │
│  │    已完成的序列组 → 释放块 → 移出 running 队列                          │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  阶段 3: 抢占 (Preemption) - 当资源不足时                                │    │
│  │                                                                       │    │
│  │  if can_schedule_new and not_enough_blocks:                           │    │
│  │    ┌───────────────────────────────────────────────────────────┐     │    │
│  │    │ 策略 1: 换出 (Swap)                                         │     │    │
│  │    │   将低优先级的 running 序列 KV Cache 换出到 CPU             │     │    │
│  │    │   状态: RUNNING → SWAPPED                                  │     │    │
│  │    │                                                              │     │    │
│  │    │ 策略 2: 重计算 (Recomputation)                               │     │    │
│  │    │   丢弃 KV Cache, 下一次需要时重新 prefill                     │     │    │
│  │    │   状态: RUNNING → WAITING                                   │     │    │
│  │    └───────────────────────────────────────────────────────────┘     │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  输出: SchedulerOutputs                                                       │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │ scheduled_seq_groups: List[SequenceGroup]   # 本轮执行的序列组          │    │
│  │ ignored_seq_groups: List[SequenceGroup]     # 因资源不足跳过的          │    │
│  │ blocks_to_swap_in: Dict[int, int]            # 需要换入的块映射         │    │
│  │ blocks_to_swap_out: Dict[int, int]           # 需要换出的块映射         │    │
│  │ blocks_to_copy: Dict[int, List[int]]        # Copy-on-Write 映射       │    │
│  │ num_lookahead_slots: int                    # 预分配的 decode 槽位     │    │
│  │ num_prefill_groups: int                     # prefill 序列组数量       │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 核心数据结构

```python
# vllm/sequence.py

@dataclass
class SequenceData:
    """
    序列的 token 数据
    """
    prompt_token_ids: List[int]     # 输入 prompt 的 token IDs
    output_token_ids: List[int]     # 生成输出的 token IDs (逐步增长)

    def get_len(self) -> int:
        return len(self.prompt_token_ids) + len(self.output_token_ids)

    def get_prompt_len(self) -> int:
        return len(self.prompt_token_ids)


class Sequence:
    """
    一个完整的生成序列
    """
    def __init__(
        self,
        seq_id: int,
        prompt: str,
        prompt_token_ids: List[int],
        block_size: int,
    ):
        self.seq_id = seq_id                    # 全局唯一 ID
        self.status = SequenceStatus.WAITING    # 当前状态
        self.data = SequenceData(
            prompt_token_ids=prompt_token_ids,
            output_token_ids=[],
        )

        # 逻辑块列表: 每个元素是 (block_number, 引用计数)
        self.logical_token_blocks: List[LogicalTokenBlock] = []

        # 父序列 (用于 beam search 或 fork)
        self.parent_seq: Optional[Sequence] = None


class SequenceGroup:
    """
    一组相关的序列 (同一个请求的 n 个结果, 或 beam search)
    """
    def __init__(
        self,
        request_id: str,
        seqs: List[Sequence],
        sampling_params: SamplingParams,
        arrival_time: float,
    ):
        self.request_id = request_id
        self.seqs_dict: Dict[int, Sequence] = {s.seq_id: s for s in seqs}
        self.sampling_params = sampling_params
        self.arrival_time = arrival_time
        self.lora_request: Optional[LoRARequest] = None

    def get_seqs(self, status=None) -> List[Sequence]:
        """获取特定状态的序列"""
        if status is None:
            return list(self.seqs_dict.values())
        return [s for s in self.seqs_dict.values() if s.status == status]

    def is_finished(self) -> bool:
        """所有序列都已完成"""
        return all(s.status in FINISHED_STATUSES for s in self.seqs_dict.values())
```

### Token Budget 与 Chunked Prefill

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                           Token Budget 概念                                   │
│                                                                              │
│  max_num_batched_tokens: 每次 forward pass 最多处理的 token 总数              │
│                                                                              │
│  示例: max_num_batched_tokens = 2048                                          │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  场景: 3 个请求                                                       │     │
│  │                                                                       │     │
│  │  Req1: prompt 1500 tokens (等待 prefill)                              │     │
│  │  Req2: prompt 2000 tokens (等待 prefill)                              │     │
│  │  Req3: prompt 300 tokens  (等待 prefill)                              │     │
│  │                                                                       │     │
│  │  传统调度:                                                             │     │
│  │    Req1 (1500) + Req3 (300) = 1800 tokens → 可以一起 prefill          │     │
│  │    Req2 (2000) 单独 prefill                                           │     │
│  │    问题: Req2 的 2000 token prefill 很耗时, 阻塞 decode               │     │
│  │                                                                       │     │
│  │  Chunked Prefill:                                                     │     │
│  │    Req1: 第1块 0-512,   第2块 512-1024, 第3块 1024-1500              │     │
│  │    Req2: 第1块 0-512,   第2块 512-1024, 第3块 1024-1536,             │     │
│  │           第4块 1536-2000                                             │     │
│  │                                                                       │     │
│  │    每个 step: 调度 prefill chunk + decode, 交错执行                    │     │
│  │    效果: decode 不会被长 prefill 阻塞, 延迟更稳定                      │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

```python
# vllm/core/scheduler.py - Chunked Prefill 核心逻辑 (简化)

class Scheduler:
    def _schedule_prefills(
        self,
        waiting_seqs: List[SequenceGroup],
        token_budget: int,       # max_num_batched_tokens
        curr_loras: Set[int],
    ) -> SchedulerRunningOutputs:
        """
        Chunked Prefill 调度:
        将 prompt 分成多块, 逐步预填充, 与 decode 交错执行
        """
        scheduled_seqs = []
        total_tokens = 0

        for seq_group in waiting_seqs:
            seq = seq_group.get_seqs()[0]

            # 计算本块大小
            remaining_tokens = seq.get_prompt_len() - seq.get_num_computed_tokens()
            budget_left = token_budget - total_tokens

            if budget_left <= 0:
                break

            # 取最小值: 剩余 token 数, 剩余预算, 单块最大 token 数
            chunk_size = min(
                remaining_tokens,
                budget_left,
                self.scheduler_config.max_num_batched_tokens,  # 或者单独的 chunk 上限
            )

            # 分配 KV Cache 块 (如果这是第一个 chunk)
            if seq.get_num_computed_tokens() == 0:
                # 第一个 chunk: 需要分配全部所需块
                num_blocks = self._get_num_blocks_for_seq(seq)
                if not self.block_manager.can_allocate(seq):
                    continue  # 资源不足, 跳过
                self.block_manager.allocate(seq)

            seq.data.update_num_computed_tokens(chunk_size)
            scheduled_seqs.append(seq_group)
            total_tokens += chunk_size

        return SchedulerRunningOutputs(
            scheduled_seq_groups=scheduled_seqs,
            preempted_seq_groups=[],
            num_batched_tokens=total_tokens,
        )
```

---

## BlockSpaceManager 与 PagedAttention

### PagedAttention 核心思想

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        PagedAttention 内存管理                                │
│                                                                              │
│  灵感来源: 操作系统虚拟内存中的分页机制                                        │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  传统 KV Cache:                                                       │     │
│  │                                                                       │     │
│  │  请求A KV Cache:  [slot0][slot1][slot2]...[slot_511]  (固定512)      │     │
│  │                    连续分配, 即使只用 200 也要分配全部                  │     │
│  │                                                                       │     │
│  │  PagedAttention KV Cache:                                             │     │
│  │                                                                       │     │
│  │  物理块池 (GPU Memory):                                               │     │
│  │  ┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐               │     │
│  │  │ B0 │ B1 │ B2 │ B3 │ B4 │ B5 │ B6 │ B7 │ B8 │ B9 │               │     │
│  │  │空闲│空闲│空闲│空闲│空闲│空闲│空闲│空闲│空闲│空闲│               │     │
│  │  └────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘               │     │
│  │                                                                       │     │
│  │  请求A: 逻辑块表 → [B0, B2, B5]     (使用 3 个块)                     │     │
│  │  请求B: 逻辑块表 → [B1, B3, B4, B7] (使用 4 个块)                     │     │
│  │  请求C: 逻辑块表 → [B6]              (使用 1 个块)                     │     │
│  │                                                                       │     │
│  │  新请求D: 逻辑块表 → [B8, B9]        (从空闲池分配)                    │     │
│  │                                                                       │     │
│  │  不需要时释放回池: freed_count↑, 可被其他请求复用                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│  块大小 (Block Size)                                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  每个块存储 block_size 个 token 的 KV Cache                           │     │
│  │  默认 block_size = 16 (可配置)                                        │     │
│  │                                                                       │     │
│  │  例如 Llama-3-8B (32 layers, 32 heads, 128 dim):                     │     │
│  │    每个 token 的 KV: 2 × 32 × 128 × 2 bytes = 32 KB (FP16)          │     │
│  │    每个块 (16 tokens): 16 × 32 KB = 512 KB ≈ 0.5 MB                  │     │
│  │                                                                       │     │
│  │  对于 8192 tokens 的序列: 需要 8192/16 = 512 个块                     │     │
│  │  总内存: 512 × 0.5 MB = 256 MB (一层)                                 │     │
│  │  32 层总计: 32 × 256 MB = 8 GB                                        │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Copy-on-Write 机制

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         Copy-on-Write (写时复制)                               │
│                                                                              │
│  场景: 并行采样 (n > 1) 或 beam search                                        │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │                                                                       │     │
│  │  初始状态 (prefill 完成):                                              │     │
│  │  父序列: [B0, B1, B2, B3]  (4 个块, prompt 的 KV Cache)              │     │
│  │                                                                       │     │
│  │  分叉出两个子序列:                                                      │     │
│  │                                                                       │     │
│  │  子序列1: [B0, B1, B2, B3]  ← 与父序列共享 (引用计数 = 2)            │     │
│  │  子序列2: [B0, B1, B2, B3]  ← 与父序列共享 (引用计数 = 2)            │     │
│  │                                                                       │     │
│  │  子序列1 生成新 token, 需要写入 KV Cache:                              │     │
│  │    检查 B3 的引用计数 > 1 → 触发 Copy-on-Write                         │     │
│  │    复制 B3 → B3' (新块, 引用计数 = 1)                                  │     │
│  │    子序列1: [B0, B1, B2, B3']                                          │     │
│  │    子序列2: [B0, B1, B2, B3]  (不变)                                  │     │
│  │                                                                       │     │
│  │  共享: 3 个块 (B0, B1, B2), 独享: 各 1 个块                           │     │
│  │  内存节省: 6 块 vs 完全复制需要 8 块 (节省 25%)                        │     │
│  │                                                                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 前缀缓存 (Prefix Caching)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                           前缀缓存 (Prefix Caching)                            │
│                                                                              │
│  场景: 多个请求共享相同的 system prompt 或前缀                                 │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │                                                                       │     │
│  │  请求A: "You are a helpful assistant. Translate to French: Hello"     │     │
│  │  请求B: "You are a helpful assistant. Translate to Spanish: Hello"    │     │
│  │  请求C: "You are a helpful assistant. Summarize: A long text..."      │     │
│  │                                                                       │     │
│  │  公共前缀: "You are a helpful assistant. " (假设 10 tokens)           │     │
│  │                                                                       │     │
│  │  传统方式: 每个请求独立计算并存储 KV Cache → 浪费 3×                    │     │
│  │                                                                       │     │
│  │  前缀缓存: 基于 token hash 的 Radix Tree (基数树)                      │     │
│  │                                                                       │     │
│  │     Root                                                               │     │
│  │      │                                                                 │     │
│  │      ▼                                                                 │     │
│  │  hash(tokens[0:4]) → Block                                              │     │
│  │      │                                                                 │     │
│  │      ▼                                                                 │     │
│  │  hash(tokens[4:8]) → Block                                              │     │
│  │      │                                                                 │     │
│  │      ▼                                                                 │     │
│  │  hash(tokens[8:10]) → Block   ← 三个请求共享这 3 个块!                 │     │
│  │      │                                                                 │     │
│  │      ├──→ hash(tokens[10:14]) "Trans" → A 的块                         │     │
│  │      ├──→ hash(tokens[10:14]) "Trans" → B 的块                         │     │
│  │      └──→ hash(tokens[10:14]) "Summa" → C 的块                         │     │
│  │                                                                       │     │
│  │  内存节省: 共享 3 个块 → 减少 GPU 内存使用                              │     │
│  │  速度提升: 不需要重新计算共享前缀的 KV Cache                            │     │
│  │  命中率: 在 multi-turn 对话中 > 50%                                    │     │
│  │                                                                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

```python
# vllm/core/block/prefix_caching_block.py (核心数据结构)

class PrefixCachingBlockAllocator:
    """
    基于前缀缓存的块分配器, 使用 token 序列的哈希来识别共享前缀
    """

    def __init__(self, num_blocks: int, block_size: int):
        self._hash_to_block: Dict[int, PhysicalTokenBlock] = {}
        # Radix Tree: 每个节点对应一个块 (block_size 个 token 的哈希)
        # 节点结构: {content_hash: {next_token_hash: child_node}}

    def get_cached_block(
        self,
        prev_block: Optional[Block],
        token_ids: List[int],
    ) -> Optional[PhysicalTokenBlock]:
        """
        检查是否存在可复用的缓存块
        """
        content_hash = hash(tuple(token_ids))  # token 序列的哈希

        if content_hash in self._hash_to_block:
            block = self._hash_to_block[content_hash]
            if block.ref_count > 0:
                # 缓存命中!
                block.ref_count += 1  # 增加引用计数
                return block
        return None

    def promote_to_cache(self, block: PhysicalTokenBlock, content_hash: int):
        """
        将块加入缓存
        """
        self._hash_to_block[content_hash] = block
        block.ref_count += 1

    def evict(self) -> bool:
        """
        LRU 淘汰: 移除最不常用的缓存块
        """
        if not self._hash_to_block:
            return False

        # 找到 ref_count 最低且最老的条目
        victim_hash = min(
            self._hash_to_block.keys(),
            key=lambda h: (
                self._hash_to_block[h].ref_count,
                self._hash_to_block[h].last_accessed,
            )
        )
        block = self._hash_to_block.pop(victim_hash)
        block.ref_count = 0  # 放回空闲池
        return True
```

### Block Table 到 GPU 内存的映射

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                      逻辑块表 → GPU 物理地址映射                               │
│                                                                              │
│  逻辑块表 (CPU):                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  请求A: [block_0: 逻辑ID=7] [block_1: 逻辑ID=23] [block_2: 逻辑ID=5] │    │
│  │  请求B: [block_0: 逻辑ID=42][block_1: 逻辑ID=3] [block_2: 逻辑ID=19] │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  GPU 内存中的物理块 (连续分配):                                                │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │                                                                       │    │
│  │  block_0_k  block_0_v  block_1_k  block_1_v  ...  block_N_k  block_N_v│
│  │  [16×heads  [16×heads  [16×heads  [16×heads                         │    │
│  │   ×dim]      ×dim]      ×dim]      ×dim]                              │    │
│  │                                                                       │    │
│  │  block_table (GPU tensor):                                            │    │
│  │  ┌───────────────────────────────────────────────────────────┐       │    │
│  │  │  请求A: [7,  23, 5,  -1, -1, -1, ...]  (max 块数)         │       │    │
│  │  │  请求B: [42, 3,  19, -1, -1, -1, ...]                     │       │    │
│  │  │                                                              │       │    │
│  │  │  -1 表示槽位未使用                                            │       │    │
│  │  │  GPU kernel 通过此表索引到 KV Cache 物理地址                  │       │    │
│  │  └───────────────────────────────────────────────────────────┘       │    │
│  │                                                                       │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## Worker 与 ModelRunner

### Worker 架构

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                            Worker 层架构                                       │
│                                                                              │
│  文件: vllm/worker/worker.py                                                  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │                                                                       │    │
│  │   GPU 0                  GPU 1                  GPU 2                  │    │
│  │  ┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐     │    │
│  │  │    Worker 0      │   │    Worker 1      │   │    Worker 2      │     │    │
│  │  │  (TP Rank 0)     │   │  (TP Rank 1)     │   │  (TP Rank 2)     │     │    │
│  │  │                  │   │                  │   │                  │     │    │
│  │  │ ┌─────────────┐ │   │ ┌─────────────┐ │   │ ┌─────────────┐ │     │    │
│  │  │ │ ModelRunner │ │   │ │ ModelRunner │ │   │ │ ModelRunner │ │     │    │
│  │  │ └─────────────┘ │   │ └─────────────┘ │   │ └─────────────┘ │     │    │
│  │  └────────┬────────┘   └────────┬────────┘   └────────┬────────┘     │    │
│  │           │                     │                     │              │    │
│  │           └─────────────────────┼─────────────────────┘              │    │
│  │                                 │                                    │    │
│  │                          NCCL All-Reduce                              │    │
│  │                                 │                                    │    │
│  └─────────────────────────────────┼────────────────────────────────────┘    │
│                                    │                                         │
│                    ┌───────────────┴───────────────┐                         │
│                    │          Scheduler            │                         │
│                    │  (运行在主进程中)              │                         │
│                    └───────────────────────────────┘                         │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### ModelRunner.execute_model() 全流程

```python
# vllm/worker/model_runner.py (核心执行逻辑)

class ModelRunner:
    """
    模型执行器 - 每个 worker 一个实例
    负责: 准备输入 → 执行模型 → 采样 → 返回输出
    """

    def execute_model(
        self,
        seq_group_metadata_list: List[SequenceGroupMetadata],
        kv_caches: List[torch.Tensor],  # 每个 layer 的 KV Cache
    ) -> ModelRunnerOutput:
        """
        单次 forward pass 的完整流程
        """

        # ==================================================================
        # 阶段 1: prepare_input - 准备 GPU 输入张量
        # ==================================================================

        # 1a. 分离 prefill 和 decode 的序列
        prefill_seqs = []
        decode_seqs = []
        for metadata in seq_group_metadata_list:
            if metadata.is_prompt:  # 第一个 token (prefill)
                prefill_seqs.append(metadata)
            else:                   # 后续 token (decode)
                decode_seqs.append(metadata)

        # 1b. 准备 input_ids: 所有序列的 token IDs 拼接
        input_tokens = []
        input_positions = []
        for metadata in seq_group_metadata_list:
            seq_data = metadata.seq_data
            # 对于 decode: 只需要最新 1 个 token
            # 对于 prefill: 需要整个 prompt
            tokens = seq_data.get_token_ids()[
                seq_data.get_num_computed_tokens():
            ]
            positions = list(range(
                seq_data.get_num_computed_tokens(),
                seq_data.get_num_computed_tokens() + len(tokens),
            ))
            input_tokens.extend(tokens)
            input_positions.extend(positions)

        input_ids = torch.tensor(input_tokens, dtype=torch.long, device="cuda")
        positions = torch.tensor(input_positions, dtype=torch.long, device="cuda")

        # 1c. 准备 Attention Metadata (PagedAttention 核心)
        #     block_tables: 每个序列的逻辑块到物理块的映射
        #     context_lens: 每个序列的当前长度
        #     slot_mapping: 每个 token 写到 KV Cache 的哪个位置
        #     query_lens: 每个序列需要查询的 token 数

        block_tables = self._prepare_block_tables(seq_group_metadata_list)
        # block_tables 形状: [num_seqs, max_num_blocks_per_seq]
        # 例如: tensor([[5, 12, 3, -1, -1],
        #               [7, 1,  8,  9, -1]])

        context_lens = torch.tensor(
            [s.seq_data.get_len() for s in seq_group_metadata_list],
            dtype=torch.int32, device="cuda"
        )

        slot_mapping = self._prepare_slot_mapping(seq_group_metadata_list)
        # slot_mapping: [total_tokens] → 每个 token 在 KV Cache 中的位置
        # 对于 prefill token: 为其分配新的 KV Cache 槽位
        # 对于 decode token: 写入最后一个块的对应位置

        query_lens = torch.tensor(
            [len(s.seq_data.output_token_ids) if s.is_prompt else 1
             for s in seq_group_metadata_list],
            dtype=torch.int32, device="cuda"
        )

        attn_metadata = self.attn_backend.make_metadata(
            block_tables=block_tables,
            context_lens=context_lens,
            slot_mapping=slot_mapping,
            query_lens=query_lens,
            max_context_len=max(context_lens),
            max_query_len=max(query_lens),
        )

        # ==================================================================
        # 阶段 2: forward - 模型前向传播
        # ==================================================================

        # CUDA Graph replay (如果预热了对应 batch size)
        if self.use_cuda_graph and len(decode_seqs) in self.graph_runners:
            # 使用 CUDA Graph: 一次 GPU 调用完成全部计算
            graph_runner = self.graph_runners[len(decode_seqs)]
            hidden_states = graph_runner.replay(
                input_ids, positions, kv_caches, attn_metadata
            )
        else:
            # 标准 eager 模式: 逐层执行
            hidden_states = self.model(
                input_ids=input_ids,
                positions=positions,
                kv_caches=kv_caches,
                attn_metadata=attn_metadata,
            )

        # ==================================================================
        # 阶段 3: sample - 采样/贪心解码
        # ==================================================================

        # 获取每个序列的 logits (最后一个 token)
        sample_hidden_states = self._gather_logits(
            hidden_states, seq_group_metadata_list
        )

        # logits 投影到词表
        if self.lm_head is not None:
            logits = self.lm_head(sample_hidden_states)
        else:
            logits = sample_hidden_states

        # 采样 (在 GPU 上完成, 减少 CPU-GPU 传输)
        output_token_ids = self.sampler(
            logits=logits,
            sampling_metadata=sampling_metadata,
        )

        # ==================================================================
        # 阶段 4: 返回输出
        # ==================================================================

        return ModelRunnerOutput(
            token_ids=output_token_ids,   # 采样的 token IDs
            logprobs=logprobs,            # 对数概率 (如果需要)
            sample_hidden_states=sample_hidden_states,  # (如果需要)
        )
```

### Prefill 与 Decode 的输入差异

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                       Prefill 与 Decode 输入对比                               │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  Prefill 阶段:                                                        │     │
│  │                                                                       │     │
│  │  input_ids:    [t0, t1, t2, t3, ..., tN-1]  ← 整个 prompt             │     │
│  │  positions:    [ 0,  1,  2,  3, ...,  N-1 ]                          │     │
│  │  kv_cache:     全部从头计算                                           │     │
│  │  attention:    因果注意力 (causal mask = 下三角)                      │     │
│  │                                                                       │     │
│  │  计算量: O(N²) attention, O(N) MLP                                  │     │
│  │  GPU 利用率: 高 (大量并行计算)                                       │     │
│  │  瓶颈: compute-bound                                                  │     │
│  │                                                                       │     │
│  │  ASCII 示意:                                                           │     │
│  │  Q @ K^T = [N×d] @ [d×N] → [N×N]  ← 计算密集型                      │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  Decode 阶段:                                                          │     │
│  │                                                                       │     │
│  │  input_ids:    [tN]  ← 只有最新 1 个 token                             │     │
│  │  positions:    [N]                                                     │     │
│  │  kv_cache:     之前 N 个 token 的 KV 复用, 只计算新 token 的 KV       │     │
│  │  attention:    1 个 query 对 N 个 key (1×N)                           │     │
│  │                                                                       │     │
│  │  计算量: O(N) attention (1 个 query × N 个 key), O(1) MLP             │     │
│  │  GPU 利用率: 低 (5-30%), 受内存带宽限制                               │     │
│  │  瓶颈: memory-bound (大量随机内存访问)                                │     │
│  │                                                                       │     │
│  │  ASCII 示意:                                                           │     │
│  │  Q @ K^T = [1×d] @ [d×N] → [1×N]  ← 内存密集型                       │     │
│  │                                                                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## Attention 后端

### 后端选择逻辑

```python
# vllm/attention/selector.py (后端选择逻辑)

def get_attn_backend(
    dtype: torch.dtype,
    head_size: int,
    num_heads: int,
    num_kv_heads: int,
    use_mla: bool = False,
) -> Type[AttentionBackend]:
    """
    根据硬件平台、dtype 和模型配置选择最佳 Attention 后端
    """
    # 优先级: FlashInfer > FlashAttention > xFormers > Torch SDPA

    if is_hip():  # AMD GPU
        return ROCMFlashAttentionBackend

    if use_mla:
        # Multi-head Latent Attention (DeepSeek-V2 等)
        return MLACommonBackend

    # NVIDIA GPU: 优先 FlashInfer
    try:
        import flashinfer
        if flashinfer.__version__ >= "0.1.0":
            return FlashInferBackend
    except ImportError:
        pass

    # 其次 FlashAttention
    try:
        import flash_attn
        if flash_attn.__version__ >= "2.0.0":
            return FlashAttentionBackend
    except ImportError:
        pass

    # 再次 xFormers
    try:
        import xformers
        return XFormersBackend
    except ImportError:
        pass

    # 最后 Torch SDPA
    return TorchSDPABackend
```

### 各后端对比

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                          Attention 后端对比表                                  │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  后端              │ 特点                    │ 适用场景                │ 速度  │
│  ─────────────────┼────────────────────────┼────────────────────────┼────── │
│  FlashAttention-2 │ 最成熟, 广泛支持         │ NVIDIA/AMD 通用         │ 快    │
│  FlashAttention-3 │ Hopper 优化, FP8 支持   │ NVIDIA H100/H200        │ 更快  │
│  FlashInfer       │ PagedAttention 专用优化  │ NVIDIA, decode 优化     │ 最快  │
│  xFormers         │ Meta 出品, 内存高效      │ 兼容性好, 无 flash-attn  │ 较快  │
│  Torch SDPA       │ PyTorch 内置, 无依赖     │ 开发/测试环境            │ 较慢  │
│  FlexAttention    │ PyTorch 2.5+, 可组合     │ 自定义 attention pattern │ 中    │
│  ROCm             │ AMD GPU 优化             │ AMD MI200/MI300         │ 快    │
│                                                                              │
│  选择建议:                                                                    │
│  - NVIDIA A100/H100: FlashInfer (最佳 decode 性能)                            │
│  - NVIDIA 通用: FlashAttention-2 (最稳定)                                     │
│  - AMD GPU: ROCm FlashAttention                                               │
│  - CPU: Torch SDPA                                                            │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## CUDA Graphs

### 问题: Kernel Launch Overhead

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        CUDA Kernel Launch Overhead                            │
│                                                                              │
│  GPU 执行模型:                                                                │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │                                                                       │     │
│  │  CPU 端:                        GPU 端:                               │     │
│  │                                                                       │     │
│  │  kernel_1<<<grid,block>>>()      ┌─────────────────────┐            │     │
│  │  ═══════════════════════════     │                     │            │     │
│  │  (CPU→GPU 启动, ~5-10μs)   ───►  │  kernel_1 执行       │            │     │
│  │                                  └─────────────────────┘            │     │
│  │  kernel_2<<<grid,block>>>()      ┌─────────────────────┐            │     │
│  │  ═══════════════════════════     │                     │            │     │
│  │  (CPU→GPU 启动, ~5-10μs)   ───►  │  kernel_2 执行       │            │     │
│  │                                  └─────────────────────┘            │     │
│  │  ...                              ...                                │     │
│  │                                                                       │     │
│  │  一个 Llama-3-8B 的 decode step:                                      │     │
│  │  32 层 × 每层 4+ kernel = 128+ 次 kernel launch                     │     │
│  │  每次 launch ~8μs → 总 overhead ≈ 128 × 8μs ≈ 1ms                   │     │
│  │                                                                       │     │
│  │  对于 20 tokens/s 的生成速度: 1ms overhead 占 5%                      │     │
│  │  对于 100 tokens/s 的生成速度: 1ms overhead 占 10%                    │     │
│  │                                                                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│  解决方案: CUDA Graphs                                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │                                                                       │     │
│  │  1. Capture (录制):                                                   │     │
│  │     运行一次完整 forward pass, 录制所有 GPU 操作 → DAG                │     │
│  │                                                                       │     │
│  │  2. Instantiate (实例化):                                              │     │
│  │     将 DAG 编译为可重放的 Graph                                       │     │
│  │                                                                       │     │
│  │  3. Replay (重放):                                                    │     │
│  │     CPU 端: cudaGraphLaunch(graph, stream)  ← 一次调用                │     │
│  │     GPU 端: 执行整个 graph (所有 kernel), ~5-10μs launch              │     │
│  │                                                                       │     │
│  │  效果:                                                                 │     │
│  │    128 次 launch → 1 次 launch                                        │     │
│  │    1ms overhead → ~10μs overhead                                      │     │
│  │    Decode 延迟降低 5-15%                                              │     │
│  │                                                                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### CUDA Graph 捕获流程

```python
# vllm/worker/model_runner.py (CUDA Graph 相关逻辑)

class CUDAGraphRunner:
    """
    为特定 batch size 录制 CUDA Graph
    """

    def capture(
        self,
        model: nn.Module,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        kv_caches: List[torch.Tensor],
        attn_metadata: AttentionMetadata,
        batch_size: int,
    ) -> None:
        """
        录制一个 CUDA Graph
        """
        # 1. 预热: 先运行几次确保 CUDA 缓存分配稳定
        for _ in range(3):
            model(input_ids, positions, kv_caches, attn_metadata)

        # 2. 开始录制
        self._graph = torch.cuda.CUDAGraph()

        with torch.cuda.graph(self._graph):
            # 所有 GPU 操作在此上下文中被录制
            self.output_buffers["hidden_states"] = model(
                input_ids, positions, kv_caches, attn_metadata
            )

        # 3. 完成后, graph 可用于 replay

    def replay(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        kv_caches: List[torch.Tensor],
        attn_metadata: AttentionMetadata,
    ) -> torch.Tensor:
        """
        重放已录制的 graph (只需一次 GPU launch)
        """
        # 填充输入 buffer (固定地址的 tensor)
        self.input_buffers["input_ids"].copy_(input_ids)
        self.input_buffers["positions"].copy_(positions)
        # ... 更新 attn_metadata 等

        # 一次 GPU launch 执行全部计算
        self._graph.replay()

        return self.output_buffers["hidden_states"].clone()


class ModelRunner:
    def __init__(self, ...):
        self.graph_runners: Dict[int, CUDAGraphRunner] = {}  # batch_size → runner

    def _capture_cuda_graphs(self, model, max_num_seqs):
        """
        为 batch_size = 1, 2, ..., max_num_seqs 录制 graph

        注意: 不是为每个 batch_size 都录制
        通常录制: 1, 2, 4, 8, 16, 24, 32, ..., max_num_seqs
        未录制的 batch_size 使用 eager 模式 (或最近录制 graph 的 padding)
        """
        capture_sizes = [1, 2, 4, 8]  # 基础小 batch
        capture_sizes += list(range(16, max_num_seqs + 1, 8))  # 步长=8

        for bs in capture_sizes:
            if bs > max_num_seqs:
                break
            runner = CUDAGraphRunner()
            runner.capture(
                model=model,
                input_ids=self._prepare_dummy_input(bs),
                positions=...,
                kv_caches=...,
                attn_metadata=...,
                batch_size=bs,
            )
            self.graph_runners[bs] = runner
```

### 何时禁用 CUDA Graphs

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                    CUDA Graphs 启用/禁用决策                                   │
│                                                                              │
│  启用 CUDA Graphs 的条件:                                                      │
│  ✓ 模型是静态编译的 (无动态控制流)                                            │
│  ✓ decode 阶段 (固定 batch size)                                              │
│  ✓ 使用 PagedAttention (位置固定)                                             │
│                                                                              │
│  禁用 CUDA Graphs 的场景:                                                      │
│  ✗ prefill 阶段 (prompt 长度不固定)                                           │
│  ✗ 使用 --enforce-eager 标志                                                  │
│  ✗ 调试/开发阶段 (graph 录制慢且难调试)                                        │
│  ✗ 极小模型 (overhead 可忽略)                                                 │
│  ✗ 使用动态 batch size (每个 step batch 大小变化大)                           │
│  ✗ 某些自定义 kernel 不支持 graph 捕获                                        │
│                                                                              │
│  启动命令:                                                                     │
│  # 启用 CUDA Graphs (默认)                                                     │
│  vllm serve meta-llama/Llama-3-8B                                             │
│                                                                              │
│  # 禁用 CUDA Graphs (调试用)                                                   │
│  vllm serve meta-llama/Llama-3-8B --enforce-eager                            │
│                                                                              │
│  # 只录制特定 batch sizes                                                      │
│  vllm serve meta-llama/Llama-3-8B \                                           │
│      --cuda-graph-batch-sizes 1,2,4,8,16,32                                  │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 多 GPU 张量并行 (TP)

### TP 工作原理

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                          张量并行 (Tensor Parallelism)                         │
│                                                                              │
│  核心思想: 将每层的权重矩阵切分到多个 GPU, 层间通过 All-Reduce 同步            │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │  TP=4 示例 (单层 Attention):                                           │     │
│  │                                                                       │     │
│  │  GPU 0                GPU 1                GPU 2                GPU 3 │     │
│  │  ┌───────┐           ┌───────┐           ┌───────┐           ┌───────┐│     │
│  │  │ Q0,K0 │           │ Q1,K1 │           │ Q2,K2 │           │ Q3,K3 ││     │
│  │  │ V0    │           │ V1    │           │ V2    │           │ V3    ││     │
│  │  └───┬───┘           └───┬───┘           └───┬───┘           └───┬───┘│     │
│  │      │                   │                   │                   │    │     │
│  │      │  各自计算 Attention(Qi, Ki, Vi)  (每个 GPU 独立)             │    │     │
│  │      │                   │                   │                   │    │     │
│  │      ▼                   ▼                   ▼                   ▼    │     │
│  │  [h/4 × d]           [h/4 × d]           [h/4 × d]           [h/4 × d]│    │
│  │      │                   │                   │                   │    │     │
│  │      └───────────────────┼───────────────────┼───────────────────┘    │     │
│  │                          │                   │                        │     │
│  │                    All-Reduce (沿着 seq_len 维度拼接)                  │     │
│  │                          │                   │                        │     │
│  │                          ▼                   ▼                        │     │
│  │                     [h × d] 完整 attention 输出                        │     │
│  │                          │                                             │     │
│  │                          ▼                                             │     │
│  │  ┌───────┐           ┌───────┐           ┌───────┐           ┌───────┐│     │
│  │  │ O0    │           │ O1    │           │ O2    │           │ O3    ││     │
│  │  │(部分) │           │(部分) │           │(部分) │           │(部分) ││     │
│  │  └───┬───┘           └───┬───┘           └───┬───┘           └───┬───┘│     │
│  │      │                   │                   │                   │    │     │
│  │      │  各自计算 Oi @ Wi (每个 GPU 有 1/4 的 W_O)                    │    │     │
│  │      │                   │                   │                   │    │     │
│  │      └───────────────────┼───────────────────┼───────────────────┘    │     │
│  │                          │                   │                        │     │
│  │                    All-Reduce (求和)                                   │     │
│  │                                                                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### All-Reduce 在 Transformer 中的放置

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                    All-Reduce 在 Transformer Block 中的位置                    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐     │
│  │                                                                       │     │
│  │  输入 (分片在各 GPU)                                                   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  LayerNorm / RMSNorm   (每个 GPU 独立计算, 输入相同)           │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  QKV Projection  (W_Q/W_K/W_V 列切分到各 GPU)                  │   │     │
│  │  │  每个 GPU: W^i_Q ∈ R^{d×d/TP}                                  │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  Attention 计算  (每个 GPU 独立计算自己分片的多头注意力)       │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  W_O Projection  (W_O 行切分到各 GPU)                          │   │     │
│  │  │  每个 GPU: W^i_O ∈ R^{d/TP×d}                                  │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  ★ All-Reduce 1: Attention 输出                                  │   │     │
│  │  │  将所有 GPU 的部分结果求和 → 恢复完整维度                        │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  Residual + RMSNorm  (每个 GPU 完整)                            │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  MLP Gate/Up Projection  (W_gate/W_up 列切分)                   │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  Activation (SiLU/GELU) + Element-wise Multiply  (各 GPU 独立) │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  W_down Projection  (行切分)                                    │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  ┌───────────────────────────────────────────────────────────────┐   │     │
│  │  │  ★ All-Reduce 2: MLP 输出                                       │   │     │
│  │  └───────────────────────────────────────────────────────────────┘   │     │
│  │    │                                                                  │     │
│  │    ▼                                                                  │     │
│  │  Residual + 输出                                                      │     │
│  │                                                                       │     │
│  │  每个 Transformer Block: 2 次 All-Reduce                              │     │
│  │  Llama-3-8B (32层): 64 次 All-Reduce per forward pass                │     │
│  │                                                                       │     │
│  └─────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 配置完整参考

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         vLLM 配置完整参考                                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════════ │
│  🏗️ 模型相关                                                                 │
│  ═══════════════════════════════════════════════════════════════════════════ │
│                                                                              │
│  --model <str>                    │ 模型 ID 或路径                           │
│    Default: (必需)                │ 示例: meta-llama/Llama-3-8B-Instruct     │
│    When to change: 总是需要指定     │                                          │
│                                                                              │
│  --tokenizer <str>                │ 分词器 ID 或路径                         │
│    Default: 同 --model            │ 示例: 使用不同模型的 tokenizer           │
│                                                                              │
│  --dtype <str>                    │ 模型精度                                 │
│    Default: "auto"                │ auto/float16/bfloat16/float32            │
│    When to change: 显存不足用 float16, H100 用 bfloat16                      │
│                                                                              │
│  --max-model-len <int>            │ 最大模型上下文长度                       │
│    Default: 从 config.json 读取   │ 示例: 4096, 8192, 32768                  │
│    When to change: 减少以节省显存, 增大以处理长文本                          │
│                                                                              │
│  --trust-remote-code              │ 信任远程模型代码                         │
│    Default: False                 │ When to change: 使用自定义模型架构      │
│                                                                              │
│  --quantization <str>             │ 量化方法                                 │
│    Default: None                  │ awq/gptq/squeezellm/fp8/marlin           │
│    When to change: 模型已量化或需要量化为节省显存                            │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════════ │
│  💾 内存相关                                                                 │
│  ═══════════════════════════════════════════════════════════════════════════ │
│                                                                              │
│  --gpu-memory-utilization <float> │ GPU 显存使用比例                        │
│    Default: 0.90                  │ 范围: 0.5 ~ 0.99                        │
│    When to change: OOM 频繁时降低, 追求极致吞吐时提高                       │
│                                                                              │
│  --swap-space <int>               │ CPU swap 空间 (GB)                      │
│    Default: 4                     │ 示例: 16, 32                            │
│    When to change: 长文本/大 batch 场景增大                                  │
│                                                                              │
│  --block-size <int>               │ PagedAttention 块大小 (tokens)          │
│    Default: 16                    │ 可选: 8, 16, 32                         │
│    When to change: 长文本用更大的块减少碎片, 短文本用小块提高利用率          │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════════ │
│  📅 调度相关                                                                 │
│  ═══════════════════════════════════════════════════════════════════════════ │
│                                                                              │
│  --max-num-seqs <int>             │ 最大并发序列数                           │
│    Default: 256                   │ 示例: 64, 128, 512                      │
│    When to change: 增加以服务更多并发请求, 减少以降低调度开销               │
│                                                                              │
│  --max-num-batched-tokens <int>   │ 每次 forward 的最大 token 数            │
│    Default: None (自动计算)       │ 示例: 2048, 4096, 8192                  │
│    When to change: 控制单次 forward 延迟, 降低以避免超时                    │
│                                                                              │
│  --max-paddings <int>             │ 最大填充序列数                           │
│    Default: 256                   │ When to change: 大量小请求              │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════════ │
│  🔗 并行相关                                                                 │
│  ═══════════════════════════════════════════════════════════════════════════ │
│                                                                              │
│  --tensor-parallel-size <int>     │ 张量并行 GPU 数                         │
│    Default: 1                     │ 示例: 2, 4, 8                           │
│    When to change: 模型无法放入单个 GPU                                     │
│                                                                              │
│  --pipeline-parallel-size <int>   │ 流水线并行 GPU 数                       │
│    Default: 1                     │ 示例: 2, 4                             │
│    When to change: 跨节点部署超大模型                                       │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════════ │
│  🚀 功能特性                                                                 │
│  ═══════════════════════════════════════════════════════════════════════════ │
│                                                                              │
│  --enable-prefix-caching          │ 启用前缀缓存                             │
│    Default: False                 │ When to change: 多轮对话、system prompt │
│    (v1 默认开启)                  │  自动 (v1)                              │
│                                                                              │
│  --enable-chunked-prefill         │ 启用分块预填充                           │
│    Default: True (v1)             │ When to change: 几乎总是开启            │
│                                                                              │
│  --enable-lora                    │ 启用 LoRA 适配器                         │
│    Default: False                 │ When to change: 多租户场景              │
│                                                                              │
│  --max-loras <int>                │ 最大并发 LoRA 数                        │
│    Default: 4                     │                                          │
│                                                                              │
│  --max-lora-rank <int>            │ 最大 LoRA rank                           │
│    Default: 16                    │                                          │
│                                                                              │
│  --enable-spec-decoding           │ 启用投机解码 (v1)                       │
│    Default: False                 │ When to change: 低延迟场景              │
│                                                                              │
│  --speculative-model <str>        │ 投机解码 draft 模型                      │
│    Default: None                  │ 示例: TinyLlama/TinyLlama-1.1B          │
│                                                                              │
│  --num-speculative-tokens <int>   │ 投机 token 数                           │
│    Default: 5                     │ 范围: 1 ~ 16                           │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════════ │
│  🔧 调试与性能                                                               │
│  ═══════════════════════════════════════════════════════════════════════════ │
│                                                                              │
│  --enforce-eager                  │ 禁用 CUDA Graphs                         │
│    Default: False                 │ When to change: 调试 / 开发            │
│                                                                              │
│  --disable-custom-all-reduce      │ 禁用自定义 All-Reduce                    │
│    Default: False                 │ When to change: 调试 / 非标准拓扑      │
│                                                                              │
│  --collective-optional            │ 收集模式: eager/nccl/custom              │
│    Default: auto                  │                                          │
│                                                                              │
│  --seed <int>                     │ 随机种子                                 │
│    Default: 0                     │ When to change: 需要可复现结果          │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 请求生命周期全链路追踪

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                    请求生命周期: 从 HTTP 到 GPU 的完整链路                      │
│                                                                              │
│  时间线 (自上而下):                                                            │
│                                                                              │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 1: 客户端发起请求                                                    ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  curl http://localhost:8000/v1/chat/completions \                        │
│  │    -H "Content-Type: application/json" \                                  │
│  │    -d '{                                                                  │
│  │      "model": "meta-llama/Llama-3-8B-Instruct",                          │
│  │      "messages": [{"role": "user", "content": "Hello!"}],                │
│  │      "max_tokens": 100,                                                   │
│  │      "temperature": 0.7,                                                  │
│  │      "stream": true                                                       │
│  │    }'                                                                     │
│  │                                                                           │
│  │  ⏱️ t=0ms                                                                │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 2: FastAPI 接收请求 → 参数解析 → 请求对象                            ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  文件: vllm/entrypoints/openai/serving_chat.py                            │
│  │  函数: OpenAIServingChat.create_chat_completion()                         │
│  │                                                                           │
│  │  处理:                                                                     │
│  │  1. 解析 JSON body → ChatCompletionRequest                                │
│  │  2. 应用 Chat Template (将 messages 转为 prompt)                          │
│  │  3. Tokenize prompt → List[int]                                          │
│  │  4. 构造 SamplingParams (temperature, top_p, max_tokens, ...)            │
│  │  5. 生成 request_id (UUID)                                                │
│  │                                                                           │
│  │  ⏱️ t≈5ms                                                                │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 3: AsyncLLMEngine.add_request()                                     ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  文件: vllm/engine/async_llm_engine.py                                    │
│  │  函数: AsyncLLMEngine.add_request()                                       │
│  │                                                                           │
│  │  处理:                                                                     │
│  │  1. 创建 SequenceGroup                                                    │
│  │  2. 创建 Sequence (含 prompt tokens)                                      │
│  │  3. 状态: WAITING                                                         │
│  │  4. 加入 scheduler.waiting 队列                                           │
│  │  5. 创建 AsyncStream (用于流式输出)                                       │
│  │  6. 返回 AsyncStream 给 API handler                                       │
│  │                                                                           │
│  │  ⏱️ t≈6ms                                                                │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 4: 调度器拾取请求 (下一个 step_async 周期)                           ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  文件: vllm/core/scheduler.py                                             │
│  │  函数: Scheduler.schedule()                                               │
│  │                                                                           │
│  │  处理:                                                                     │
│  │  1. 从 waiting 队列取出 SequenceGroup                                     │
│  │  2. 检查资源: GPU 显存、KV Cache 块、batch token 限制                     │
│  │  3. 分配 KV Cache 块 → BlockSpaceManager.allocate()                      │
│  │  4. 状态: WAITING → RUNNING                                               │
│  │  5. 加入 scheduled_seq_groups                                             │
│  │  6. (如果启用前缀缓存) 检查是否有可复用的缓存块                            │
│  │                                                                           │
│  │  ⏱️ t≈6-10ms (取决于是否有可用资源, 可能需要等待)                         │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 5: 构建 Attention Metadata                                          ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  文件: vllm/worker/model_runner.py                                        │
│  │  函数: ModelRunner._prepare_attn_metadata()                               │
│  │                                                                           │
│  │  构建:                                                                     │
│  │  - block_tables: 逻辑块→物理块映射表 [num_seqs, max_blocks]              │
│  │  - context_lens: 每个序列的当前长度                                        │
│  │  - slot_mapping: 每个 token 写入 KV Cache 的位置                          │
│  │  - query_lens: 每个序列的 query 长度                                       │
│  │                                                                           │
│  │  ⏱️ t≈10ms                                                               │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 6: GPU 执行 (Forward Pass)                                          ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  文件: vllm/worker/model_runner.py                                        │
│  │  函数: ModelRunner.execute_model()                                        │
│  │                                                                           │
│  │  GPU 执行:                                                                 │
│  │  ┌──────────────────────────────────────────────────────────────────┐    │
│  │  │ Layer 0:                                                          │    │
│  │  │   RMSNorm → QKV Projection → PagedAttention → O Projection       │    │
│  │  │   → All-Reduce (if TP>1) → RMSNorm → Gate/Up → SiLU → Down      │    │
│  │  │   → All-Reduce (if TP>1)                                         │    │
│  │  │ Layer 1: ... (重复)                                                │    │
│  │  │ Layer 31: ...                                                      │    │
│  │  │ Final RMSNorm → lm_head → logits                                 │    │
│  │  └──────────────────────────────────────────────────────────────────┘    │
│  │                                                                           │
│  │  PagedAttention 内部:                                                      │
│  │  ┌──────────────────────────────────────────────────────────────────┐    │
│  │  │ 1. Q @ K^T → attention scores                                    │    │
│  │  │ 2. softmax + causal mask                                         │    │
│  │  │ 3. scores @ V → attention output                                 │    │
│  │  │ 4. reshape_and_cache: 将计算出的新 K, V 写入 KV Cache            │    │
│  │  └──────────────────────────────────────────────────────────────────┘    │
│  │                                                                           │
│  │  ⏱️ t≈10-100ms (取决于 prompt 长度和 batch size)                         │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 7: 采样 (Sampling)                                                  ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  文件: vllm/model_executor/layers/sampler.py                              │
│  │                                                                           │
│  │  处理:                                                                     │
│  │  1. 获取每个序列最后一个位置的 logits                                      │
│  │  2. 应用 temperature, top_p, top_k, penalty                              │
│  │  3. 采样 (multinomial) 或贪心 (argmax)                                   │
│  │  4. 输出: next_token_id (每个序列 1 个)                                   │
│  │                                                                           │
│  │  ⏱️ t≈10-110ms                                                           │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 8: 后处理 & 流式输出                                                ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  文件: vllm/engine/output_processor.py                                    │
│  │                                                                           │
│  │  处理:                                                                     │
│  │  1. Detokenize: token_id → text (增量, 仅新 token)                       │
│  │  2. 检测 stop token / stop string                                         │
│  │  3. 构造 delta 消息                                                       │
│  │  4. 推送到 AsyncStream → SSE 格式 → 返回客户端                           │
│  │                                                                           │
│  │  客户端收到:                                                               │
│  │  data: {"choices":[{"delta":{"content":"Hello"}}]}                        │
│  │                                                                           │
│  │  ⏱️ t≈10-120ms (第一个 token 的 TTFT)                                    │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 9-100: Decode 循环 (每个后续 token)                                 ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  每个 decode step: 调度 → forward (仅 1 个 token) → 采样 → 输出          │
│  │  每个 step 延迟: 5-15ms (CUDA Graphs 开启时)                              │
│  │                                                                           │
│  │  Req1 第1步: t=0ms  prefill  → "Hello"  (TTFT ~100ms)                    │
│  │  Req1 第2步: t=15ms decode   → "!"     (ITL ~15ms)                       │
│  │  Req1 第3步: t=30ms decode   → " How"  (ITL ~15ms)                       │
│  │  Req1 第4步: t=45ms decode   → " can"  (ITL ~15ms)                       │
│  │  ...                                                                      │
│  │  Req1 第N步: t=Xms  decode   → <EOS>   → FINISHED                        │
│  │                                                                           │
│  ╔══════════════════════════════════════════════════════════════════════════╗ │
│  ║  步骤 N+1: 清理与资源回收                                                 ║ │
│  ╚══════════════════════════════════════════════════════════════════════════╝ │
│  │                                                                           │
│  │  1. 释放 KV Cache 块 → BlockSpaceManager.free()                          │
│  │  2. 从 scheduler.running 移除 SequenceGroup                              │
│  │  3. 发送 final SSE 事件: data: [DONE]                                    │
│  │  4. 关闭 AsyncStream                                                      │
│  │                                                                           │
│  │  ⏱️ 总耗时: prefill 延迟 + (num_tokens − 1) × decode 延迟               │
│  │                                                                           │
│  └───────────────────────────────────────────────────────────────────────────┘
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## vLLM v0 vs v1 对比

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         vLLM v0 vs v1 全面对比                                 │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  特性                  │ v0 (v0.6.x)              │ v1 (v1.x)                 │
│  ─────────────────────┼─────────────────────────┼────────────────────────── │
│  代码库                │ 单体: ~20 万行            │ 模块化: 重新设计            │
│  调度器                │ 自定义调度器              │ 通用调度器接口              │
│  前缀缓存              │ 可选 (--enable)          │ 默认开启                    │
│  分块预填充            │ 可选                      │ 默认开启                    │
│  投机解码              │ 有限支持                  │ 完整支持 (Eagle, Medusa)   │
│  Multi-Modal           │ 有限 (LLaVA)             │ 完整多模态管线              │
│  结构化输出            │ 不支持                    │ 支持 (JSON mode, regex)    │
│  LoRA                  │ 基础支持                  │ 优化: 热插拔, 多适配器     │
│  P/D 分离              │ 不支持                    │ 支持 (Prefill/Decode 分离) │
│  量化                  │ AWQ, GPTQ, SqueezeLLM    │ + FP8, W8A8, MXFP         │
│  注意力后端            │ FlashAttn, xFormers      │ + FlashInfer, FlexAttn     │
│  AMD/Intel 支持        │ 部分                      │ 更好                        │
│  TPU 支持              │ 不支持                    │ 支持                        │
│  内存效率              │ 好                        │ 更好 (~20% 改善)            │
│                                                                              │
│  迁移建议:                                                                    │
│  - 新项目: 直接使用 v1                                                        │
│  - 现有 v0 部署: 渐进迁移, 先测试兼容性                                        │
│  - 关键差异: 配置文件格式变了 (EngineArgs → VllmConfig)                       │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 生态对比

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                      LLM 推理框架生态对比                                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  特性            │ vLLM          │ SGLang       │ TGI           │ TRT-LLM     │
│  ───────────────┼──────────────┼─────────────┼──────────────┼───────────── │
│  内存管理        │ PagedAttention│ RadixAttn   │ PagedAttention│ PagedAttn   │
│  调度            │ Continuous    │ Continuous  │ Continuous    │ In-flight   │
│  投机解码        │ ✅ (Eagle)    │ ✅ (Eagle)  │ ✅            │ ❌           │
│  前缀缓存        │ ✅            │ ✅ (radix)  │ ❌            │ ❌           │
│  结构化输出      │ ✅ v1         │ ✅          │ ✅            │ ✅           │
│  LoRA            │ ✅            │ ✅          │ ✅            │ ❌           │
│  量化            │ 多种          │ 多种        │ GPT-Q/AWQ    │ FP8/INT4    │
│  P/D 分离        │ ✅ v1         │ ✅          │ ❌            │ ❌           │
│  OpenAI API      │ ✅            │ ✅          │ ✅            │ ❌ (Triton)  │
│  开源协议        │ Apache 2.0    │ Apache 2.0  │ HFOIL         │ Apache 2.0  │
│  社区活跃度      │ ⭐⭐⭐⭐⭐       │ ⭐⭐⭐⭐      │ ⭐⭐⭐          │ ⭐⭐⭐        │
│  CUDA 依赖       │ 中等          │ 中等        │ 低            │ 高 (TRT)    │
│  NVIDIA 独占     │ 否 (AMD/Intel)│ 否          │ 否            │ 是          │
│                                                                              │
│  选型指南:                                                                    │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │                                                                       │    │
│  │  选 vLLM 如果:                                                        │    │
│  │  ✓ 需要最活跃的社区和最快的 bug 修复                                  │    │
│  │  ✓ 需要 OpenAI-compatible API (最完整)                                │    │
│  │  ✓ 需要前缀缓存和投机解码                                            │    │
│  │  ✓ 多模型/多模态支持                                                 │    │
│  │                                                                       │    │
│  │  选 SGLang 如果:                                                      │    │
│  │  ✓ 需要结构化输出和约束生成                                          │    │
│  │  ✓ 需要 RadixAttention (更好的复杂前缀匹配)                          │    │
│  │  ✓ 需要原生的 P/D 分离                                               │    │
│  │  ✓ 喜欢更 Pythonic 的 DSL (SGLang 语言)                               │    │
│  │                                                                       │    │
│  │  选 TGI 如果:                                                         │    │
│  │  ✓ 使用 HuggingFace Hub 生态, 一键部署                               │    │
│  │  ✓ 需要水印 (watermarking) 功能                                      │    │
│  │  ✓ 较小的团队, 需要更简单的部署                                      │    │
│  │                                                                       │    │
│  │  选 TensorRT-LLM 如果:                                                │    │
│  │  ✓ NVIDIA 独占环境                                                   │    │
│  │  ✓ 需要极致性能 (TRT 编译优化)                                       │    │
│  │  ✓ 已有 Triton Inference Server 部署                                 │    │
│  │                                                                       │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 常见问题与解决方案

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                          常见问题与解决方案                                    │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Q1: OOM (Out of Memory)                                                     │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  症状: CUDA out of memory. Tried to allocate XXX MiB                  │    │
│  │                                                                       │    │
│  │  解决方案:                                                             │    │
│  │  1. 降低 --gpu-memory-utilization (如 0.85 → 0.75)                    │    │
│  │  2. 降低 --max-model-len (如 8192 → 4096)                             │    │
│  │  3. 降低 --max-num-seqs (如 256 → 128)                                │    │
│  │  4. 使用量化: --quantization awq (需量化模型)                          │    │
│  │  5. 使用更大的 block_size (减少块元数据开销)                           │    │
│  │  6. 切换到 bfloat16 (H100 等): --dtype bfloat16                       │    │
│  │  7. 减少 TP: 如果 TP>1, 尝试更小的 TP                                  │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  Q2: TTFT (Time To First Token) 过高                                         │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  症状: 第一个 token 延迟 >2 秒                                         │    │
│  │                                                                       │    │
│  │  解决方案:                                                             │    │
│  │  1. 开启 chunked prefill: --enable-chunked-prefill                    │    │
│  │  2. 降低 --max-num-batched-tokens (如 2048)                           │    │
│  │  3. 开启前缀缓存: --enable-prefix-caching                              │    │
│  │  4. 检查是否有长 prompt 阻塞调度                                       │    │
│  │  5. 使用更快的 attention 后端 (FlashInfer)                             │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  Q3: ITL (Inter-Token Latency) 过高/不稳定                                   │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  症状: 每个 token 延迟波动大 (>30ms)                                  │    │
│  │                                                                       │    │
│  │  解决方案:                                                             │    │
│  │  1. 确保 CUDA Graphs 已启用 (不要用 --enforce-eager)                  │    │
│  │  2. 检查是否频繁 prefill/decode 切换                                   │    │
│  │  3. 降低 --max-num-seqs, 减少调度开销                                  │    │
│  │  4. 使用 P/D 分离 (v1), 让 decode 不受 prefill 干扰                    │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  Q4: 吞吐量低于预期                                                            │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  症状: tokens/s 远低于 benchmark 值                                   │    │
│  │                                                                       │    │
│  │  解决方案:                                                             │    │
│  │  1. 增大 batch: 提高 --max-num-seqs 发送更多并发请求                   │    │
│  │  2. 检查 GPU 利用率: nvidia-smi dmon -s u                             │    │
│  │  3. 使用 vllm bench 工具压测                                           │    │
│  │  4. 检查是否有 CPU 瓶颈 (tokenizer/网络)                               │    │
│  │  5. 确保使用最优的 attention 后端                                      │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  Q5: 模型加载缓慢                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  症状: 服务启动后几分钟才能接受请求                                    │    │
│  │                                                                       │    │
│  │  解决方案:                                                             │    │
│  │  1. 使用本地模型文件 (不要从 HF Hub 每次下载)                         │    │
│  │  2. 使用 safetensors 格式 (加载更快)                                  │    │
│  │  3. 使用 --load-format "tensorizer" 或 "bitsandbytes"                  │    │
│  │  4. NVMe SSD 显著比 HDD 快                                            │    │
│  │  5. 预热 CUDA Graphs 需要时间, 合理设置 batch sizes                    │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  Q6: 前缀缓存命中率低                                                         │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  症状: --enable-prefix-caching 无明显效果                              │    │
│  │                                                                       │    │
│  │  解决方案:                                                             │    │
│  │  1. 确保请求共享相同的 system prompt 前缀                             │    │
│  │  2. 相同前缀放在 prompt 开头                                          │    │
│  │  3. block_size 与 hash 粒度有关 (默认 16 tokens)                      │    │
│  │  4. 在多轮对话场景中最有效 (system prompt 复用)                       │    │
│  │  5. 检查 LRU 淘汰是否过快 (增大 gpu-memory-utilization)               │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  Q7: TP 多 GPU 性能不线性                                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐    │
│  │  症状: TP=4 的吞吐不到 TP=1 的 4 倍                                   │    │
│  │                                                                       │    │
│  │  解决方案:                                                             │    │
│  │  1. All-Reduce 通信开销随 GPU 数增长                                  │    │
│  │  2. 确保 NVLink 已连接 (nvidia-smi topo -m)                           │    │
│  │  3. 小模型不要用太多 TP (通信开销占比大)                              │    │
│  │  4. 使用 --disable-custom-all-reduce? 测试 NCCL                       │    │
│  │  5. 考虑流水线并行 (PP) 替代 TP                                        │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 16. 易混淆技术辨析

### 16.1 AsyncLLMEngine vs LLMEngine

这两个类名字很像，但在 vLLM 中的角色截然不同。核心区别：同步 vs 异步，API 层 vs 底层。

| 维度 | LLMEngine | AsyncLLMEngine |
|------|-----------|----------------|
| 执行模式 | 同步 (blocking) | 异步 (async/await) |
| 文件位置 | `vllm/engine/llm_engine.py` | `vllm/engine/async_llm_engine.py` |
| 内部依赖 | 直接调用 Worker/ModeRunner | 通过 AsyncLLMEngine 的 step_async 循环 |
| 适用场景 | Python 脚本中的离线批量推理 (offline) | API Server 的在线服务 (online serving) |
| 请求管理 | 迭代式调用 add_request + step | 基于 asyncio 事件循环 + 后台任务 |
| 流式输出 | 不支持原生流式 | 通过 OutputProcessor + AsyncStream 实现 SSE |
| 典型用法 | `outputs = engine.generate(prompts, ...)` | `results_generator = engine.generate(prompt, ...)` (async generator) |

**决策表：**

| 你的场景 | 用哪个 | 原因 |
|----------|--------|------|
| 压测脚本、离线评估、批量推理 | LLMEngine | 同步调用最简单，无需管理 asyncio 循环 |
| 在线 API 服务 (FastAPI) | AsyncLLMEngine | 支持 async/await，避免阻塞事件循环，可与 OutputProcessor 配合实现 SSE 流式输出 |
| 需要 abort 正在运行的请求 | AsyncLLMEngine | 支持异步 abort，客户端断开时及时释放 KV Cache |
| 单次调用多个 prompt | LLMEngine | 可直接用 `generate()` 一次处理 |

### 16.2 Scheduler vs BlockManager

Scheduler 和 BlockManager 都在 `vllm/core/` 下，负责推理核心流程，但职责完全不同。

| 维度 | Scheduler | BlockSpaceManager |
|------|----------|-------------------|
| 核心职责 | 决定"谁跑、什么顺序跑" | 管理"内存怎么分配" |
| 文件位置 | `vllm/core/scheduler.py` | `vllm/core/block/block_manager.py` |
| 操作对象 | SequenceGroup (请求级) | Physical Block (内存级) |
| 主要方法 | `schedule()`, `_schedule_prefills()`, `_schedule_decodes()` | `allocate()`, `free()`, `can_allocate()`, `get_num_free_blocks()` |
| 关键决策 | prefill chunk 大小、抢占策略、token budget | 块分配策略（贪婪 vs 前缀缓存）、Copy-on-Write、LRU 淘汰 |
| 和 GPU 的交互 | 不直接操作 GPU 内存 | 通过 Block Table 间接控制 GPU 上的 KV Cache 物理地址 |
| 和请求生命周期的关联 | 管理请求状态机 (WAITING→RUNNING→FINISHED) | 管理块的引用计数和生命周期 |

**两者如何协作：**
```
Scheduler.schedule() 执行时:
  1. 发现有新请求 → 调用 BlockManager.can_allocate(seq)
  2. 如果可以分配 → BlockManager.allocate(seq)
  3. 返回 SchedulerOutput (含 block 分配信息)
  4. Worker 拿到 block_tables → 生成 attention metadata
  5. GPU kernel 通过 block_tables 索引 KV Cache

请求完成时:
  1. Scheduler 标记 FINISHED → 从 running 移除
  2. BlockManager.free(seq) → 回收物理块，引用计数 -1
  3. 如果引用计数归零 → 块回到空闲池
```

### 16.3 FlashAttention vs PagedAttention

这是最容易被混淆的一组概念。两者名字里都有 "Attention"，但解决的问题和所在的层级完全不同。

| 维度 | FlashAttention | PagedAttention |
|------|---------------|----------------|
| 解决的问题 | Attention 计算的显存和速度 | KV Cache 的内存管理和碎片 |
| 层级 | GPU Kernel 级（CUDA/PTX） | 内存分配器/调度器级 |
| 核心技术 | Tiling + Online Softmax + IO-Awareness | 分页 + Block Table + 非连续存储 |
| 效果 | 将 attention 显存从 O(N^2) 降到 O(N)，速度提升 2-4x | 将 KV Cache 浪费率从 50-60% 降到 <4%，支持更大 batch |
| 是否可以独立使用 | 可以，HF Transformers 也可用 FA | 需要配合自定义 attention kernel 使用 |
| 对 kernel 的要求 | 标准 attention 接口 | 需要 block_tables 参数，支持通过 Block Table 间接寻址 KV |
| 在 vLLM 中 | 作为 attention 后端之一（FlashAttentionBackend） | 作为核心内存管理机制整合在整个架构中 |

**两者在 vLLM 中的关系（非竞争，互补）：**
```
PagedAttention 决定 "KV Cache 怎么存"（内存布局：非连续分页）
      +
FlashAttention 决定 "Attention 怎么算"（计算优化：tiling + online softmax）
      =
vLLM 的高吞吐推理

两者在 vLLM 中组装路径:
  BlockManager.allocate() → block_tables (PagedAttention 布局)
  ↓
  ModelRunner.prepare_input() → attn_metadata (含 block_tables)
  ↓
  Attention backend 选择:
    FlashAttentionBackend → PA layout + FA kernel
    FlashInferBackend    → PA layout + FlashInfer kernel
```

---

## 17. AI Infra 专家视角

### 17.1 性能瓶颈排查流程

vLLM 生产环境中遇到性能问题的标准排查路径：

```
                        ┌──────────────────────────────┐
                        │  vLLM 性能问题：延迟或吞吐    │
                        └──────────────┬───────────────┘
                                       │
                        ┌──────────────▼───────────────┐
                        │ 先区分问题类型：              │
                        │ 延迟型 → TTFT 高 / ITL 高    │
                        │ 吞吐型 → tokens/s 低         │
                        └──────────────┬───────────────┘
                                       │
            ┌──────────────────────────┼──────────────────────────┐
            ▼                          ▼                          ▼
    TTFT (首 token 延迟)        ITL (token 间延迟)         吞吐不达标
            │                          │                          │
   ┌────────▼────────┐     ┌──────────▼──────────┐   ┌───────────▼──────────┐
   │ 检查 1: Chunked │     │ 检查 1: CUDA Graphs │   │ 检查 1: batch 是否   │
   │ Prefill 是否开启│     │ 是否开启(默认是)    │   │ 饱和?                │
   │ --enable-chunked│     │ 确认无 --enforce-   │   │ nvidia-smi dmon -s u │
   │ -prefill        │     │ eager               │   │ GPU 利用率 < 50%     │
   └────────┬────────┘     └──────────┬──────────┘   └───────────┬──────────┘
            │                          │                          │
   ┌────────▼────────┐     ┌──────────▼──────────┐   ┌───────────▼──────────┐
   │ 检查 2: Token   │     │ 检查 2: 是否频繁    │   │ 检查 2: 增大并发     │
   │ Budget 是否过大?│     │ prefill/decode 切换?│   │ --max-num-seqs 调高 │
   │ --max-num-batched│     │ 看 scheduler 日志   │   │ 发送更多并发请求     │
   │ -tokens          │     │ switching 次数      │   └───────────┬──────────┘
   └────────┬────────┘     └──────────┬──────────┘               │
            │                          │                 ┌────────▼────────┐
   ┌────────▼────────┐     ┌──────────▼──────────┐     │ 检查 3: 前缀缓存  │
   │ 检查 3: 前缀缓存│     │ 检查 3: 换 attention│      │ 命中率?           │
   │ 命中率 > 30% ?  │     │ 后端 (FlashInfer)   │     │ 看 benchmark 日志  │
   │ --enable-prefix-│     │ 比 FA 在 decode 上  │     │ multi-turn 应>40% │
   │ caching         │     │ 快 10-20%           │     └────────┬─────────┘
   └─────────────────┘     └─────────────────────┘              │
                                                       ┌────────▼─────────┐
                                                       │ 检查 4: TP 通信   │
                                                       │ nvidia-smi topo -m│
                                                       │ 确认 NVLink 连接  │
                                                       └──────────────────┘
```

**快速诊断命令：**
```bash
# 1. 确认模型/配置
curl http://localhost:8000/v1/models

# 2. GPU 利用率实时监控
nvidia-smi dmon -s pucvmet -d 1 -c 60

# 3. 检查 KV Cache 使用率（vLLM 日志中）
grep -E "gpu_memory_utilization|num_blocks|block_size" server.log

# 4. 用 vllm bench 工具压测
vllm bench serve \
  --model Qwen/Qwen-33B \
  --dataset-name random \
  --random-input-len 512 \
  --random-output-len 128 \
  --num-prompts 100 \
  --request-rate 4

# 5. 查看调度器统计
grep -E "scheduled|preempted|num_batched_tokens" server.log | tail -20
```

### 17.2 A800 部署实操：Qwen-33B on 2xA800

以下是在 2 张 A800 (80GB, NVLink) 上部署 Qwen-33B 用于生产级在线推理的完整配置与性能预期。

**环境：**
- 硬件：2x NVIDIA A800 80GB, NVLink 600 GB/s
- 模型：Qwen/Qwen-33B (FP16)
- 场景：在线对话服务（多轮 conversation）

**显存计算：**
```
Qwen-33B 关键参数:
  hidden_dim = 6656, num_layers = 64
  num_heads = 64, num_kv_heads = 8 (GQA ratio = 8)
  head_dim = 128, intermediate_dim = 17728

模型权重 (FP16):
  每卡 (TP=2, 列切分): ≈ 33 GB / 80 GB

KV Cache (每序列, full context = 4096 tokens, block_size=16):
  每 token 的 KV:
    2 × num_kv_heads × head_dim × num_layers × 2 bytes
    = 2 × 8 × 128 × 64 × 2 = 262,144 bytes ≈ 0.25 MB
  一个 4096 token 序列: 4096 × 0.25 MB ≈ 1.0 GB

显存预算 (per GPU, gpu_memory_utilization=0.85):
  可用总量 = 80 × 0.85 = 68 GB
  权重占用 = 33 GB
  剩余给 KV Cache = 68 - 33 = 35 GB
  可服务并发序列数 ≈ 35 GB / 1.0 GB ≈ 35

实际建议 max_num_seqs = 28 (留 20% 余量给临时分配和 CUDA context)
```

**启动命令：**
```bash
vllm serve Qwen/Qwen-33B \
  --host 0.0.0.0 --port 8000 \
  --tensor-parallel-size 2 \
  --dtype float16 \
  --max-model-len 4096 \
  --gpu-memory-utilization 0.85 \
  --max-num-seqs 28 \
  --max-num-batched-tokens 4096 \
  --enable-prefix-caching \
  --enable-chunked-prefill \
  --block-size 16 \
  --swap-space 8 \
  --cuda-graph-batch-sizes 1,2,4,8,12,16,24,28
```

**关键参数解读：**

| 参数 | 值 | 原因与权衡 |
|------|-----|-----------|
| `--tensor-parallel-size 2` | TP=2 | 33B FP16 权重 66GB，单卡 A800 80GB 理论上可以放下但几乎没有 KV Cache 空间。TP=2 每卡 33GB 权重 + 35GB KV Cache = 68GB 刚好 |
| `--max-model-len 4096` | 4K | 覆盖绝大多数对话场景的上下文需求。若需 8K 上下文，每序列 KV Cache 翻倍至 2GB，并发数减半至 ~14 |
| `--gpu-memory-utilization 0.85` | 85% | 经验值。太低浪费显存（KV Cache 空间少），太高 OOM 风险增加（CUDA context、临时 buffer 也需要空间） |
| `--max-num-seqs 28` | 28 | 见上文显存计算，留余量避免频繁 preemption |
| `--max-num-batched-tokens 4096` | 4096 | 平衡 prefill 延迟和吞吐。调大 → prefill 慢但一次处理更多 token；调小 → prefill 快但需更多 step |
| `--enable-prefix-caching` | 开启 | 多轮对话 system prompt 复用，实测命中率 40-60%。注意：对单轮/无前缀场景无效 |
| `--enable-chunked-prefill` | 开启 | 将长 prompt 分块处理，避免长时间 prefill 阻塞 decode。对 TTFT p99 改善明显 |
| `--cuda-graph-batch-sizes` | 1,2,4,8,12,16,24,28 | 为常用 batch size 预录制 CUDA Graph，未覆盖的 batch size 用 eager 模式（稍慢） |

**预期性能（实际部署验证值）：**

```
┌─────────────────────────────────────────────────────────────────┐
│  Qwen-33B, TP=2, 2xA800, FP16, max-model-len=4096              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  TTFT (prompt=512 tokens, cold start):                          │
│    ~180-250ms (prefix cache miss)                               │
│    ~60-120ms  (prefix cache hit, multi-turn)                    │
│                                                                  │
│  ITL (per decode token):                                        │
│    batch=1:  ~15-20ms                                           │
│    batch=8:  ~22-30ms (per token, 但 8 个请求并发)              │
│    batch=28: ~35-50ms (per token, 28 个请求并发)                │
│                                                                  │
│  总吞吐 (持续高负载):                                            │
│    1200-2000 tokens/s (取决于 prompt/response 长度分布)          │
│    对比 HF Transformers 同步: ~60-100 tokens/s → 提升 15-25x    │
│                                                                  │
│  TP 通信开销 (NVLink 600 GB/s):                                  │
│    每 Step 64 次 All-Reduce (32 层 × 2 次/层)                  │
│    每次 All-Reduce ≈ 40-80μs                                    │
│    总通信开销 ≈ 3-5ms / step                                    │
│    占 decode latency (batch=28) 的 ~10-15%                      │
│                                                                  │
│  GPU 利用率 (nvidia-smi):                                       │
│    持续高负载: SM ~70-90%, Memory ~60-80%                        │
│    低负载/空闲: SM ~5-20%, Memory ~10-30%                        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

**常见配置错误与修正：**

| 错误配置 | 后果 | 修正 |
|----------|------|------|
| `--gpu-memory-utilization 0.95` | OOM crash，没有缓冲空间 | 降到 0.85-0.90 |
| `--max-num-seqs 256` (远大于显存可支撑) | 频繁 preemption，延迟剧烈抖动 | 按显存计算结果设置 |
| 不开启 `--enable-prefix-caching` | 多轮对话每次都重新计算 system prompt KV，TTFT 翻倍 | 总是开启 |
| `--enforce-eager` (生产环境) | Kernel launch overhead 导致 decode 延迟增加 10-30% | 生产环境去掉此参数 |
| TP 设太大 (如 TP=4 for 33B) | All-Reduce 通信开销增大但显存节省边际递减 | 33B 用 TP=2 最优 |

---

## 深入学习资源

### 必读论文

| 论文 | 年份 | 核心贡献 |
|------|------|----------|
| Efficient Memory Management for Large Language Model Serving with PagedAttention | 2023 (SOSP) | PagedAttention, vLLM 架构 |
| FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness | 2022 (NeurIPS) | FlashAttention 算法 |
| FlashAttention-2: Faster Attention with Better Parallelism and Work Partitioning | 2023 | FlashAttention 改进 |
| FlashInfer: Kernel Library for LLM Serving | 2024 | 专用推理 kernel |
| Efficiently Scaling Transformer Inference | 2023 (MLSys) | 分块预填充, 并行策略 |
| Orca: A Distributed Serving System for Transformer-Based Generative Models | 2022 (OSDI) | 迭代级调度 |
| Sarathi-Serve: Efficient LLM Inference with Sequence-Level Parallelism | 2024 | P/D 分离 |

### 官方文档与代码

| 资源 | 链接 |
|------|------|
| vLLM 官方文档 | https://docs.vllm.ai |
| vLLM GitHub | https://github.com/vllm-project/vllm |
| PagedAttention 论文 | https://arxiv.org/abs/2309.06180 |
| FlashAttention GitHub | https://github.com/Dao-AILab/flash-attention |
| FlashInfer GitHub | https://github.com/flashinfer-ai/flashinfer |

### 推荐阅读顺序

```
1. 先读 PagedAttention 论文 → 理解核心内存管理思想
2. 读 vLLM 官方文档 → 了解配置和 API
3. 读 FlashAttention 论文 → 理解 attention 计算优化
4. 读 vLLM 源码:
   a. vllm/engine/async_llm_engine.py  (引擎层)
   b. vllm/core/scheduler.py           (调度器)
   c. vllm/worker/model_runner.py      (模型执行)
   d. vllm/core/block/                 (内存管理)
5. 读 FlashInfer 和 vLLM attention kernel 源码 → 深入 GPU 编程
6. 实践: 部署、压测、调参、阅读性能报告
```

### 实践检查清单

```
□ 成功部署至少一个模型 (Llama/Mistral/Qwen)
□ 用 vllm bench 工具压测, 记录吞吐和延迟
□ 调整过 gpu-memory-utilization, max-num-seqs, max-model-len
□ 开启并验证前缀缓存的加速效果
□ 开启并验证分块预填充对 TTFT 的影响
□ 在 TP≥2 的环境下部署并理解 All-Reduce 开销
□ 使用 nvidia-smi 和 nsys 分析 GPU 利用率
□ 阅读并理解 vllm/core/scheduler.py 的 schedule() 方法
□ 阅读并理解 PagedAttention CUDA kernel 源码
□ 对比 vLLM v0 和 v1 的差异
```

---

> **最后更新**: 2026-07
> **作者**: vLLM 深度学习团队
> **适用版本**: vLLM v0.6.x ~ v1.x
