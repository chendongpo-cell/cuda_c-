# PagedAttention 源码级深度解析

## 白话引入

想象你去图书馆借书。传统的做法是：管理员根据你报的书名，在书库里预留一整排书架给你——哪怕你只需要其中的 3 本书，那一整排书架在你还书之前都不能给别人用。更糟的是，如果你的书越借越多（就像 LLM 生成越来越长的输出），管理员必须从一开始就给你预留足够长的书架（max_model_len），否则后面书多了放不下。这就是传统 KV Cache 预分配方案：为每条序列分配一块连续的最大长度内存，利用率只有 ~6%。

**PagedAttention** 的做法完全不同：图书馆把书架统一做成固定大小的格子（每格装 16 本书，这就是 block_size=16）。你需要几本就给你分配几个格子，而且这些格子在物理上不必相邻——你手里拿着一张"索书号小纸条"（Block Table），上面写着"第 1 个逻辑格子对应物理书架 3 号，第 2 个对应物理书架 7 号..."。管理员（CUDA kernel）根据这张小纸条去取书，完全不在乎格子是不是物理连续的。这就是分页（paging）的核心思想——从操作系统虚拟内存借来的智慧，在 GPU 上重新实现了一遍。

> **阅读前提**：本文假设你已理解 Transformer 自注意力机制的基本原理（Q、K、V、softmax(QK^T/sqrt(d))V），以及 KV Cache 的基本概念（推理时将历史 Key/Value 缓存起来，避免重复计算）。如果你对这些还不熟悉，请先阅读本系列的前置文档。
>
> **本文目标**：从源码层面逐行拆解 PagedAttention 的设计哲学、数据结构、内存管理算法、CUDA 内核逻辑，以及它在 vLLM 中的完整实现链路。读完本文后，你将能够：
> - 理解虚拟内存与 PagedAttention 之间的精确映射关系
> - 手算任意配置下的 KV 缓存利用率和内存浪费
> - 独立实现一个简化版的 Block Table 管理算法
> - 读懂 vLLM 中 BlockSpaceManager 的核心逻辑
> - 向同事解释为什么 block_size=16 是工业界的 sweet spot

---

## 术语预检

以下术语是理解 PagedAttention 的基石，每个都配有生活类比帮助你建立直觉。

| 术语 | 生活类比 | 技术定义 |
|------|---------|---------|
| **Block（物理块）** | 图书馆书架上的一个固定大小格子（每格放 16 本书） | GPU 显存中一块固定大小的连续内存区域，存储 block_size 个 token 的 Key 和 Value。vLLM 默认 block_size=16。一个 33B 模型的单 block 大小约为 1-2 MB（跨所有层）。 |
| **Block Table（块表）** | 索书号小纸条：记录每本"逻辑书"对应哪个"物理格子" | 每序列一张的映射表（GPU Tensor，int32），将逻辑 block 索引映射到物理 block ID。形状为 [num_seqs, max_blocks_per_seq]，-1 表示未分配。这是 PagedAttention kernel 中唯一必须放在 GPU 上的元数据。 |
| **Logical Block（逻辑块）** | 书单上的第 N 本书（按顺序编号） | 序列中按 token 位置编号的虚拟 block，通过 `token_position // block_size` 计算。对上层代码透明，表示"这个序列的第几个 block"。 |
| **Physical Block（物理块）** | 书库里实际存放书的第 M 号格子 | GPU 显存中实际分配的物理 block，有一个唯一的 block_id。不同序列的逻辑 block 可以指向同一个物理 block（共享）。 |
| **Copy-on-Write（写时复制）** | 两位同学合用一份笔记，有人要修改时先复印一份再改 | 当多个序列（如 beam search 中的子序列）共享相同的物理 block 时，fork 操作只做浅拷贝（共享 block table 指针+增加引用计数）。仅当某个序列需要修改该 block 时才触发实际的 GPU 显存复制。 |
| **Internal Fragmentation（内部碎片）** | 一个格子放了 12 本书还空 4 个位置 | 最后一个 block 中未被完全使用的 slot。对于 block_size=16，每个序列最多浪费 15 个 token slot。长序列（>512 tokens）下利用率 >97%，远优于预分配方案的 ~6%。 |

---

## 目录

1. [虚拟内存类比：OS 虚拟内存如何启发了 LLM 推理](#1-虚拟内存类比)
2. [内存碎片问题：预分配 KV 缓存的灾难性浪费](#2-内存碎片问题)
3. [基于 Block 的 KV 缓存：分块管理](#3-基于-block-的-kv-缓存)
4. [内存效率：理论分析](#4-内存效率理论分析)
5. [Block Table 实现](#5-block-table-实现)
6. [内存共享：Beam Search 与 Parallel Sampling](#6-内存共享)
7. [写时复制 Copy-on-Write](#7-写时复制-copy-on-write)
8. [Block Manager 内部机制](#8-block-manager-内部机制)
9. [CPU Offloading：块交换机制](#9-cpu-offloading块交换机制)
10. [PagedAttention CUDA 内核](#10-pagedattention-cuda-内核)
11. [Block Size 权衡](#11-block-size-权衡)
12. [前缀缓存 Prefix Caching 交互](#12-前缀缓存-prefix-caching-交互)
13. [vLLM v1 的改进](#13-vllm-v1-的改进)
14. [代码走读：BlockSpaceManager 全流程](#14-代码走读blockspacemanager-全流程)
15. [易混淆技术辨析](#15-易混淆技术辨析)
16. [AI Infra 专家视角](#16-ai-infra-专家视角)
17. [深入学习资源](#17-深入学习资源)

---

## 1. 虚拟内存类比

### 1.1 OS 虚拟内存的核心思想

在操作系统中，虚拟内存解决了一个根本问题：**如何让多个进程认为它们各自拥有一大块连续的内存，实际上这些内存可能物理上分散在 RAM 的各个角落，甚至部分被交换到了磁盘上。**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         OS 虚拟内存系统                                       │
│                                                                              │
│   进程 A 的虚拟地址空间              物理内存 (Physical RAM)                   │
│  ┌──────────────────────┐         ┌──────────────────────────────┐          │
│  │ 0x0000  [page 0] ───┼────┐    │ Frame 7  │ A page 0 数据    │          │
│  │ 0x1000  [page 1] ───┼──┐ │    │ Frame 3  │ A page 1 数据    │          │
│  │ 0x2000  [page 2] ───┼┐ │ │    │ Frame 12 │ A page 2 数据    │          │
│  │ 0x3000  [page 3] ───┼┼┐│ │    │ Frame 0  │ B page 0 数据    │          │
│  └──────────────────────┘││││ │    │ Frame 5  │ B page 1 数据    │          │
│                           ││││ │    │ Frame 9  │ (free)          │          │
│   进程 B 的虚拟地址空间     ││││ │    │ Frame 11 │ (free)          │          │
│  ┌──────────────────────┐ ││││ │    │  ...                        │          │
│  │ 0x0000  [page 0] ───┼─┘│││ │    └──────────────────────────────┘          │
│  │ 0x1000  [page 1] ───┼──┘││ │                                               │
│  └──────────────────────┘   ││ │   页表 (Page Table)                           │
│                              ││ │  ┌──────────────────────┐                   │
│  关键数据结构：               ││ │  │ 进程A:               │                   │
│  虚拟地址的高位 → 页表索引    ││ │  │   page0 → frame7    │                   │
│  虚拟地址的低位 → 页内偏移    ││ │  │   page1 → frame3    │                   │
│                              ││ │  │   page2 → frame12   │                   │
│  页大小：通常 4KB             ││ │  │   page3 → frame0    │                   │
│                              ││ │  │ 进程B:               │                   │
│                              ││ │  │   page0 → frame0    │                   │
│                              ││ │  │   page1 → frame5    │                   │
│                              ││ │  └──────────────────────┘                   │
│                              ││ │                                              │
│  核心洞察：                   ││ │  注意：物理页可以不连续！                      │
│  虚拟地址 → 连续               ││ │  Frame0 同时被 A 和 B 共享                   │
│  物理地址 → 不连续             ││ │                                              │
│  页表 → 映射关系               ││ │  这就是「分页」的核心价值                      │
└─────────────────────────────────────────────────────────────────────────────┘
```

OS 虚拟内存的三个关键机制：

1. **地址转换**：CPU 发出的虚拟地址被 MMU（Memory Management Unit）通过页表转换为物理地址。
2. **按需分配**：物理页帧只在真正被访问时才分配，而非预先分配全部地址空间。
3. **共享与保护**：多个进程可以共享同一个物理页帧（例如共享库），通过页表项中的权限位控制读写。

### 1.2 PagedAttention 的直接类比

将上述概念逐项映射到 LLM 推理场景：

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       PagedAttention 虚拟内存类比                              │
│                                                                              │
│  OS 虚拟内存                            PagedAttention                        │
│  ────────────                          ──────────────                        │
│  虚拟地址 (Virtual Address)     ←→     逻辑 KV 位置 (logical token position)  │
│  页表 (Page Table)              ←→     块表 (Block Table)                     │
│  物理页帧 (Physical Frame)      ←→     物理 KV Block                         │
│  页大小 (Page Size, 4KB)        ←→     块大小 (Block Size, 16 tokens)         │
│  MMU (地址转换硬件)              ←→     PagedAttention CUDA Kernel             │
│  缺页中断 (Page Fault)          ←→     块分配 (Block Allocation)               │
│  交换空间 (Swap Space)          ←→     CPU 内存 (作为 GPU 的交换空间)          │
│  共享内存 (Shared Memory)       ←→     前缀缓存 (Prefix Caching)               │
│  写时复制 (Copy-on-Write)       ←→     Beam Search 中的块复制                  │
│  引用计数 (Reference Count)     ←→     块引用计数 (Block Reference Count)      │
└─────────────────────────────────────────────────────────────────────────────┘
```

**并行对比的 ASCII 图**：

```
   ┌─ OS 虚拟内存 ─────────────────────┐    ┌─ PagedAttention ───────────────────┐
   │                                    │    │                                    │
   │  虚拟地址: 0x7FFF_1234             │    │  Token 位置: seq_id=3, pos=100     │
   │       │                            │    │       │                            │
   │       ▼                            │    │       ▼                            │
   │  ┌──────────┐                      │    │  ┌──────────────┐                  │
   │  │  页表     │   page_number =     │    │  │  Block Table  │  logical_block  │
   │  │  (Page   │   addr >> 12         │    │  │  (per seq)   │  = pos / 16     │
   │  │  Table)  │   (4KB = 2^12)      │    │  │              │  = 100 / 16     │
   │  │          │                      │    │  │              │  = 6            │
   │  │ page 6 ──┼──► frame 42          │    │  │ block_idx 6 ──┼──► phys_blk 42  │
   │  └──────────┘                      │    │  └──────────────┘                  │
   │       │                            │    │       │                            │
   │       ▼                            │    │       ▼                            │
   │  ┌──────────────┐                  │    │  ┌──────────────┐                  │
   │  │  物理内存     │                  │    │  │  GPU 显存     │                  │
   │  │  frame 42     │  offset =       │    │  │  phys_blk 42  │  offset =       │
   │  │  + offset     │  addr & 0xFFF   │    │  │  + offset     │  pos % 16      │
   │  │  = 最终数据   │                  │    │  │  = K[100]     │  = 100 % 16    │
   │  └──────────────┘                  │    │  └──────────────┘  = 4             │
   └────────────────────────────────────┘    └────────────────────────────────────┘
```

### 1.3 为什么这个类比如此强大

这不仅仅是巧合或者表面的相似。PagedAttention 的设计者（vLLM 团队，UC Berkeley）**刻意借用了操作系统领域积累了数十年的研究成果**：

| OS 研究课题 | 对应 LLM 推理问题 | 解决方案迁移 |
|------------|------------------|-------------|
| 外部碎片 (External Fragmentation) | KV Cache 整体利用率低 | 分页 / 分块消除外部碎片 |
| 内部碎片 (Internal Fragmentation) | 最后一个 block 的部分浪费 | 可接受 (< 1 block) |
| 页替换策略 (LRU, Clock, etc.) | GPU 显存不足时的块驱逐 | LRU 驱逐 + CPU swap |
| 写时复制 (COW) | Beam Search 多条序列共享 prompt | COW 推迟拷贝直到真正分歧 |
| 共享内存 (Shared Memory) | 多请求共享相同 system prompt | 块级引用计数共享 |
| TLB (Translation Lookaside Buffer) | Block Table 的缓存优化 | 无直接对应（kernel 内联） |
| 大页 (Huge Pages) | 更大的 block_size 减少索引开销 | block_size 的权衡研究 |

**核心价值**：OS 研究者用 50 年时间解决的那些问题（碎片、共享、替换、保护），在 LLM 推理中几乎原样重现。PagedAttention 相当于把操作系统的「分页」机制搬到了 GPU 上，只是粒度从 4KB 变成了 16 个 token（约 0.5MB-2MB 一个 block）。

> **实践要点**：理解这个类比后，你在调试 vLLM 的 OOM 问题时，可以直接套用 OS 内存管理的诊断思路——先看碎片率，再看引用计数，最后检查是否有「内存泄漏」（未释放的 block）。


---

## 2. 内存碎片问题

### 2.1 传统 KV Cache 的预分配困境

在 PagedAttention 出现之前，几乎所有 LLM 推理框架都采用一种简单粗暴的策略：**为每条序列预先分配最大长度的连续 KV Cache 空间**。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    传统 KV Cache：预分配 = 巨大的浪费                            │
│                                                                              │
│  假设: max_model_len = 8192 tokens                                           │
│        num_layers = 32, num_kv_heads = 8, head_dim = 128, dtype = float16    │
│                                                                              │
│  每条序列的 KV Cache 大小:                                                    │
│    2 (K+V) * 32 layers * 8 heads * 8192 tokens * 128 dim * 2 bytes          │
│    = 2 * 32 * 8 * 8192 * 128 * 2 = 1,073,741,824 bytes ≈ 1 GB per sequence  │
│                                                                              │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │  预分配的 KV Cache 空间 (max_model_len = 8192)                         │  │
│  │  ┌─────────────────────────────────────────────────────────────────┐  │  │
│  │  │█████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│  │  │
│  │  │ 实际使用 (500 tokens) │        浪费 (7692 tokens, 93.9%)         │  │  │
│  │  └─────────────────────────────────────────────────────────────────┘  │  │
│  │  Token 0 ────────────────────────────────────────── Token 8191       │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  浪费公式:                                                                    │
│    waste_ratio = 1 - (actual_tokens / max_model_len)                         │
│                = 1 - (500 / 8192) = 0.939 = 93.9%                            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 真实负载的数据

在一次典型的 Chat 推理服务中，用户行为的不确定性会导致极端的利用率波动：

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   真实 Chat 负载的 Token 长度分布                              │
│                                                                              │
│  Token 数    │  请求占比   │  max_model_len=8192 时的利用率   │  浪费比例      │
│  ────────────┼────────────┼──────────────────────────────┼──────────────│
│   50-200     │    45%      │         0.6% - 2.4%           │  97.6%-99.4%  │
│  200-500     │    30%      │         2.4% - 6.1%           │  93.9%-97.6%  │
│  500-1024    │    15%      │        6.1% - 12.5%           │  87.5%-93.9%  │
│  1024-2048   │     7%      │       12.5% - 25.0%           │  75.0%-87.5%  │
│  2048-4096   │     2%      │       25.0% - 50.0%           │  50.0%-75.0%  │
│  4096-8192   │     1%      │       50.0% - 100%            │   0.0%-50.0%  │
│                                                                              │
│  加权平均利用率:                                                              │
│    = 0.45*0.015 + 0.30*0.043 + 0.15*0.093 + 0.07*0.188 + 0.02*0.375 + 0.01*0.75│
│    ≈ 6.2%                                                                    │
│                                                                              │
│  结论: 典型 Chat 负载下, 传统预分配策略的 KV Cache 利用率仅约 6%！              │
│        超过 93% 的显存分配被浪费了。                                            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.3 连续分配导致的级联问题

预分配不仅浪费空间，还会导致**外部碎片**，即虽然总空闲空间足够，但没有一块足够大的**连续**空间来满足新请求。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         外部碎片 (External Fragmentation)                     │
│                                                                              │
│  显存状态 (总容量: 40GB, 每条序列预分配 1GB)                                   │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐           │
│  │ seq0 │ seq1 │ seq2 │ seq3 │  空闲  │ seq4 │ seq5 │  空闲   │           │
│  │ 1GB  │ 1GB  │ 1GB  │ 1GB  │  0.5GB │ 1GB  │ 1GB  │  1.5GB  │           │
│  └──────────────────────────────────────────────────────────────┘           │
│                                                                              │
│  总空闲空间: 0.5GB + 1.5GB = 2GB                                             │
│  但新请求 seq6 需要 1GB 连续空间 → 无法分配！                                  │
│                                                                              │
│  解决方案需要「压缩」(compaction)，移动已分配的内存块。                          │
│  这在 GPU 上代价极高：移动 1GB 数据在 H100 上需约 1.1ms。                       │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.4 实际 GPU 显存的浪费计算

以 A100-80GB 为例，对于 Llama2-7B 单卡部署：

```
设备: A100-80GB, 可用显存 (PyTorch 开销后): ~78 GB
模型权重 (Llama2-7B, FP16): ~13 GB
剩余显存: 78 - 13 - 2 (其他) = 63 GB
每条序列预分配 KV Cache: 1 GB (max_model_len=8192)
最大并发序列数: 63 / 1 = 63 条

如果使用 PagedAttention (利用率 6.2% → 95%+):
每条序列实际 KV Cache: 1 * 6.2% / 95% ≈ 0.065 GB
最大并发序列数: 63 / 0.065 ≈ 969 条
吞吐提升倍数: 969 / 63 ≈ 15.4x
```

> **实践要点**：如果你在生产环境中观察到 OOM 但实际的 token 数远小于 max_model_len，检查你的推理框架是否支持 PagedAttention。对于 vLLM，确认 --max-model-len 设置和 --gpu-memory-utilization (默认 0.9)。


---

## 3. 基于 Block 的 KV 缓存

### 3.1 核心概念：将 KV Cache 切分成固定大小的 Block

PagedAttention 的核心想法极其简洁：**不再为每条序列分配一整块连续内存，而是将 KV Cache 切分为固定大小的 Block，按需分配。**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    基于 Block 的 KV Cache 管理                                │
│                                                                              │
│  参数定义:                                                                   │
│    block_size = 16 tokens (vLLM 默认)                                        │
│    每个 block 存储 16 个连续 token 的 Key 和 Value                            │
│                                                                              │
│  一个 Block 的物理结构:                                                       │
│  ┌───────────────────────────────────────────────────────────────┐          │
│  │                     Physical Block #k                           │          │
│  │  K[0]  K[1]  K[2]  ...  K[15]   ← 16 tokens 的 Key 向量      │          │
│  │  V[0]  V[1]  V[2]  ...  V[15]   ← 16 tokens 的 Value 向量    │          │
│  │                                                                │          │
│  │  维度: [block_size, num_kv_heads, head_dim] (float16)         │          │
│  │  大小: 16 * 8 * 128 * 2B * 2(K+V) * 32(layers)                │          │
│  │       = 2,097,152 bytes ≈ 2 MB per logical block              │          │
│  └───────────────────────────────────────────────────────────────┘          │
│                                                                              │
│  Token 到 Block 的映射规则:                                                   │
│    logical_block_idx = token_position / block_size   (整数除法)               │
│    block_offset      = token_position % block_size   (取余)                  │
│                                                                              │
│  例如: token_position = 100, block_size = 16                                 │
│    logical_block_idx = 100 / 16 = 6    → 第 6 个逻辑 block                    │
│    block_offset      = 100 % 16 = 4    → 该 block 的第 4 个位置               │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Block Table：每序列一张

每个序列维护一张 **Block Table**，将逻辑 block 位置映射到物理 block ID：

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                Block Table 示意图: 三个序列的 KV Cache 布局                     │
│                                                                              │
│  Seq 0: 10 tokens → ceil(10/16) = 1 block                                   │
│  Seq 1: 55 tokens → ceil(55/16) = 4 blocks                                  │
│  Seq 2: 8 tokens  → ceil(8/16)  = 1 block                                   │
│                                                                              │
│  物理 Block 池 (Block Size = 16 tokens):                                     │
│  ┌──────┬──────┬──────┬──────┬──────┬──────┬──────┬──────┬──────┐          │
│  │ Blk0 │ Blk1 │ Blk2 │ Blk3 │ Blk4 │ Blk5 │ Blk6 │ Blk7 │ ...  │          │
│  │ free │ free │ S0   │ S1   │ S1   │ S2   │ S1   │ S1   │ free │          │
│  └──────┴──────┴──────┴──────┴──────┴──────┴──────┴──────┴──────┘          │
│                                                                              │
│  Seq 0 的 Block Table:       Seq 1 的 Block Table:       Seq 2 的 BT:        │
│  ┌──────┬──────┐            ┌──────┬──────┐              ┌──────┐           │
│  │ log0 │→ Blk2│            │ log0 │→ Blk3│              │ log0 │→ Blk5│    │
│  └──────┴──────┘            │ log1 │→ Blk4│              └──────┘           │
│                              │ log2 │→ Blk6│                                │
│                              │ log3 │→ Blk7│                                │
│                              └──────┴──────┘                                │
│                                                                              │
│  注意：物理 block 的分配顺序完全与序列无关！                                    │
│  Seq1 使用了 Blk3, Blk4, Blk6, Blk7 —— 不连续且穿插在其他序列之间。            │
│  这就是「分页」的精髓：物理上的不连续对 attention kernel 完全透明。              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Block Table 存储在 GPU 显存中

Block Table 必须放在 **GPU 显存**中，因为 attention kernel 在 GPU 上执行时需要实时查询它：

```python
# Block Table 在 GPU 上的数据结构 (简化版)
class BlockTable:
    """
    形状: [num_sequences, max_num_blocks_per_seq]
    类型: torch.int32 (physical block IDs)
    位置: GPU 显存
    
    max_num_blocks_per_seq = ceil(max_model_len / block_size)
    例如: max_model_len=8192, block_size=16 → max_num_blocks_per_seq = 512
    """
    def __init__(self, num_sequences: int, max_num_blocks: int, device: str):
        self.table = torch.full(
            (num_sequences, max_num_blocks),
            fill_value=-1,  # INVALID
            dtype=torch.int32, device=device
        )

    def set_block(self, seq_id: int, logical_idx: int, physical_id: int):
        self.table[seq_id, logical_idx] = physical_id

    def get_physical_block(self, seq_id: int, logical_idx: int) -> int:
        return self.table[seq_id, logical_idx].item()
```

Block Table 本身也占用显存。对于 batch_size=256, max_num_blocks=512:
256 * 512 * 4 bytes = 512 KB。相对于 GB 级别的 KV Cache，这个开销完全可以忽略不计。

> **实践要点**：Block Table 是 PagedAttention 中唯一必须放在 GPU 上的"元数据"。它的随机访问模式意味着索引开销极低——每个 warp 中的所有线程读取同一个 block_table 条目，通过 GPU 的 broadcast 机制完成。



---

## 5. 写时复制 (Copy-on-Write) Block 共享

### 5.1 问题场景：并行采样与 Beam Search

在 LLM 推理中，以下场景会同时产生多个共享大部分前缀的序列：

**场景 1: 并行采样 (Parallel Sampling)**

```
同一个 prompt，同时采样 N 个不同的生成结果:

  Prompt: "请写一首关于春天的诗"
  
  采样 1: "春风吹绿了大地，万物复苏，生机勃勃..."
  采样 2: "春风拂面，桃花盛开，柳絮飞扬..."
  采样 3: "春天来了，冰雪消融，鸟儿歌唱..."
  
  所有采样共享相同的 prompt token 序列。
```

**场景 2: Beam Search**

```
在 beam search 中，每一步保留 k 个最优候选:

  Step 0:   [prompt tokens] (1 个序列)
  Step 1:   [prompt, tok_a] (保留 top-k)
            [prompt, tok_b]
  Step 2:   从 Step 1 的每个候选扩展，再保留 top-k...
  
  序列之间的公共前缀可能长达数千个 token。
```

**场景 3: 多轮对话前缀**

```
系统 prompt + 对话历史 + 新用户问题 → 多个候选回复

  系统 prompt: "你是一个有帮助的助手..."  (500 tokens)
  对话历史: ...                           (500 tokens)
  用户问题: "帮我写代码"                   (50 tokens)
  
  → 1050 个共享 token，仅最后部分不同
```

### 5.2 无 CoW 的内存开销

假设 beam_width=5，共享前缀 1000 tokens，block_size=16：

```
+----------------------------------------------------------------------+
|                    无 CoW 的内存开销                                   |
+----------------------------------------------------------------------+
|                                                                      |
|  共享前缀: 1000 tokens → ceil(1000/16) = 63 blocks                   |
|                                                                      |
|  无共享方案: 每个 beam copy 一份完整的 KV Cache                       |
|                                                                      |
|  序列 1: |------- 63 blocks (prompt KV) -------|                    |
|  序列 2: |------- 63 blocks (prompt KV) -------|                    |
|  序列 3: |------- 63 blocks (prompt KV) -------|                    |
|  序列 4: |------- 63 blocks (prompt KV) -------|                    |
|  序列 5: |------- 63 blocks (prompt KV) -------|                    |
|                                                                      |
|  总 block 数: 5 x 63 = 315 blocks                                    |
|  存储的 KV Cache: 5 x 63 x 1 MB = 315 MB (浪费!)                     |
|                                                                      |
|  实际上这 63 个 block 的内容完全相同，但被存储了 5 份!                 |
|                                                                      |
+----------------------------------------------------------------------+
```

### 5.3 CoW 方案

```
+----------------------------------------------------------------------+
|                    有 CoW 的内存开销                                   |
+----------------------------------------------------------------------+
|                                                                      |
|  共享前缀: 1000 tokens → 63 blocks                                   |
|                                                                      |
|  CoW 方案: 所有 beam 共享相同的 63 个物理 block                       |
|                                                                      |
|        物理 Block 0..62 (共享前缀, ref_count = 5)                     |
|  +------------------------------------------------------------------+|
|  | B0 | B1 | B2 |  ...  | B61 | B62 | (63 个 block, 每块 1 MB)     ||
|  +------------------------------------------------------------------+|
|      ^     ^     ^              ^      ^                             |
|      |     |     |              |      |                             |
|  +---+-----+-----+--------------+------+----+                        |
|  |   |     |     |              |      |    |                        |
|  | Seq1  Seq2  Seq3  Seq4  Seq5  (Block Table 指向相同物理 block)     |
|                                                                      |
|  每个序列只在自己发散后需要额外的 block:                                |
|                                                                      |
|  Seq1: [B0..B62] + [B63_s1, B64_s1, ...]  (发散部分)                 |
|  Seq2: [B0..B62] + [B63_s2, B64_s2, ...]                             |
|  ...                                                                 |
|                                                                      |
|  总 block 数: 63 (共享) + N (各序列发散部分)                          |
|  如果每个序列生成 200 tokens (~13 blocks):                            |
|    总 block = 63 + 5 x 13 = 63 + 65 = 128 blocks                     |
|                                                                      |
|  节省: 315 - 128 = 187 blocks (~59% 节省!)                            |
|                                                                      |
+----------------------------------------------------------------------+
```

### 5.4 CoW 的完整工作机制

CoW 围绕三个核心操作：Fork、Read、Write。

```
+======================================================================+
|                    CoW 三步操作                                       |
+======================================================================+
|                                                                      |
|  1. FORK: 创建子序列的浅拷贝                                          |
|  =================================================================== |
|                                                                      |
|  def fork(parent_seq_id) -> child_seq_id:                            |
|      child_seq_id = new_sequence_id()                                |
|                                                                      |
|      # 浅拷贝 Block Table                                            |
|      for i in range(sequence_num_blocks[parent_seq_id]):             |
|          block_table[child_seq_id, i] = block_table[parent_seq_id, i]|
|                                                                      |
|      # 增加所有共享 block 的引用计数                                   |
|      for i in range(sequence_num_blocks[parent_seq_id]):             |
|          block_id = block_table[parent_seq_id, i]                    |
|          physical_blocks[block_id].ref_count += 1                    |
|                                                                      |
|      # 复制其他状态                                                  |
|      sequence_num_blocks[child_seq_id] = \                           |
|          sequence_num_blocks[parent_seq_id]                          |
|      sequence_lengths[child_seq_id] = sequence_lengths[parent_seq_id]|
|                                                                      |
|      return child_seq_id                                             |
|                                                                      |
|                                                                      |
|  2. READ: 无需特殊处理                                                |
|  =================================================================== |
|                                                                      |
|  读取 block 不需要任何特殊处理。                                       |
|  所有共享同一物理 block 的序列都可以正常读取其内容。                    |
|  这就是 "Copy-on-Write" 中 "不需要 Copy" 的部分。                      |
|                                                                      |
|                                                                      |
|  3. WRITE: 写入时触发复制                                              |
|  =================================================================== |
|                                                                      |
|  当子序列需要修改 (写入) 一个共享 block 时:                            |
|                                                                      |
|  场景: 子序列发散，需要在新 token 位置写入 K/V                        |
|                                                                      |
|  def write_to_block(seq_id, logical_block_idx, data):                |
|      physical_block_id = block_table[seq_id, logical_block_idx]     |
|      block = physical_blocks[physical_block_id]                      |
|                                                                      |
|      if block.ref_count > 1:                                         |
|          # 此 block 被多个序列共享，需要 CoW                           |
|          # 1. 分配新的物理 block                                      |
|          new_block = free_list.pop()                                 |
|          new_block.ref_count = 1                                     |
|                                                                      |
|          # 2. 复制旧 block 的内容到新 block                           |
|          copy_block_gpu_to_gpu(                                      |
|              src=physical_block_id,                                  |
|              dst=new_block.block_id                                  |
|          )                                                           |
|                                                                      |
|          # 3. 更新子序列的 Block Table                                |
|          block_table[seq_id, logical_block_idx] = new_block.block_id|
|                                                                      |
|          # 4. 减少旧 block 的引用计数                                 |
|          block.ref_count -= 1                                        |
|                                                                      |
|          # 5. 如果旧 block 不再被引用，归还 free list                  |
|          if block.ref_count == 0:                                    |
|              free_list.push(block)                                   |
|                                                                      |
|          # 更新本地引用                                               |
|          physical_block_id = new_block.block_id                      |
|                                                                      |
|      # 现在 block.ref_count == 1，安全写入                            |
|      write_kv_to_block(physical_block_id, data)                      |
|                                                                      |
+======================================================================+
```

### 5.5 CoW 的图解过程

```
+======================================================================+
|              CoW 完整图解过程                                          |
+======================================================================+
|                                                                      |
|  初始状态: 父序列 P 有 3 个 block                                     |
|                                                                      |
|  物理 Block:                                                         |
|  +--------+  +--------+  +--------+                                 |
|  | B0     |  | B1     |  | B2     |                                 |
|  | ref=1  |  | ref=1  |  | ref=1  |                                 |
|  | K[0..15]|  | K[16..31]| | K[32..47]|                               |
|  +--------+  +--------+  +--------+                                 |
|                                                                      |
|  Block Table (P):                                                    |
|  P: [0, 1, 2]                                                       |
|                                                                      |
+======================================================================+
|                                                                      |
|  Step 1: FORK - 创建子序列 C                                         |
|                                                                      |
|  fork(P) → C                                                         |
|                                                                      |
|  物理 Block:                                                         |
|  +--------+  +--------+  +--------+                                 |
|  | B0     |  | B1     |  | B2     |                                 |
|  | ref=2  |  | ref=2  |  | ref=2  |  (ref_count 增加了)             |
|  +--------+  +--------+  +--------+                                 |
|                                                                      |
|  Block Table:                                                        |
|  P: [0, 1, 2]                                                       |
|  C: [0, 1, 2]  (相同的物理 block)                                    |
|                                                                      |
+======================================================================+
|                                                                      |
|  Step 2: 子序列 C 生成新 token (append_slots)                         |
|                                                                      |
|  C 需要新 block → 正常分配 B3                                        |
|                                                                      |
|  +--------+  +--------+  +--------+  +--------+                     |
|  | B0     |  | B1     |  | B2     |  | B3     |                     |
|  | ref=2  |  | ref=2  |  | ref=2  |  | ref=1  | (新, 仅 C 使用)    |
|  +--------+  +--------+  +--------+  +--------+                     |
|                                                                      |
|  Block Table:                                                        |
|  P: [0, 1, 2]                                                       |
|  C: [0, 1, 2, 3]                                                    |
|                                                                      |
+======================================================================+
|                                                                      |
|  Step 3: CoW 触发 - C 需要写入 block 2 (token 32..47 区域)           |
|          (实际中较少发生，因为 decode 阶段通常只追加。                |
|           但某些场景如 KV 压缩、Attention 修改等可能触发)              |
|                                                                      |
|  write_to_block(C, logical_block=2, data)                            |
|                                                                      |
|  block_table[C][2] = 2 (ref_count=2 → 需要 CoW)                     |
|                                                                      |
|  1. 分配 B4, 复制 B2 内容 → B4                                       |
|  2. C 的 block_table 更新为 [0, 1, 4, 3]                             |
|  3. B2.ref_count: 2 → 1                                             |
|                                                                      |
|  +--------+  +--------+  +--------+  +--------+  +--------+         |
|  | B0     |  | B1     |  | B2     |  | B3     |  | B4     |         |
|  | ref=2  |  | ref=2  |  | ref=1  |  | ref=1  |  | ref=1  |         |
|  +--------+  +--------+  +--------+  +--------+  +--------+         |
|                                                                      |
|  Block Table:                                                        |
|  P: [0, 1, 2, -1]    (P 继续使用 B2)                                 |
|  C: [0, 1, 4, 3]    (C 使用新的 B4)                                  |
|                                                                      |
+======================================================================+
|                                                                      |
|  Step 4: P 也生成了新 token                                           |
|                                                                      |
|  +--------+  +--------+  +--------+  +--------+  +--------+         |
|  | B0     |  | B1     |  | B2     |  | B4     |  | B3     |         |
|  | ref=2  |  | ref=2  |  | ref=1  |  | ref=1  |  | ref=1  |         |
|  +--------+  +--------+  +--------+  +--------+  +--------+         |
|                                        +--------+                    |
|                                        | B5     |                    |
|                                        | ref=1  |                    |
|                                        +--------+                    |
|                                                                      |
|  Block Table:                                                        |
|  P: [0, 1, 2, 5, -1]                                                |
|  C: [0, 1, 4, 3, -1]                                                |
|                                                                      |
+======================================================================+
|                                                                      |
|  Step 5: P 结束，释放                                                 |
|                                                                      |
|  free(P)                                                             |
|                                                                      |
|  B0: ref_count 2→1 (C 仍在使用)                                      |
|  B1: ref_count 2→1                                                   |
|  B2: ref_count 1→0 → 归还 free_list                                  |
|  B5: ref_count 1→0 → 归还 free_list                                  |
|                                                                      |
|  +--------+  +--------+  +--------+  +--------+                     |
|  | B0     |  | B1     |  | B4     |  | B3     |                     |
|  | ref=1  |  | ref=1  |  | ref=1  |  | ref=1  |                     |
|  +--------+  +--------+  +--------+  +--------+                     |
|                                                                      |
|  Block Table:                                                        |
|  C: [0, 1, 4, 3, -1]                                                |
|                                                                      |
+======================================================================+
```

### 5.6 在 vLLM 源码中的实现要点

vLLM 中 CoW 的核心实现在 `BlockSpaceManager` 中：

```python
# vllm/core/block_manager.py (概念性代码)
class BlockSpaceManager:
    
    def fork(self, parent_seq_id: int, child_seq_id: int) -> None:
        """
        创建子序列的 CoW 拷贝。
        子序列的 block_table 初始化为父序列的浅拷贝。
        """
        parent_block_table = self.block_tables[parent_seq_id]
        num_blocks = self.num_blocks[parent_seq_id]
        
        # 浅拷贝 block table
        self.block_tables[child_seq_id][:num_blocks] = \
            parent_block_table[:num_blocks]
        self.num_blocks[child_seq_id] = num_blocks
        
        # 增加所有共享 block 的引用计数
        for i in range(num_blocks):
            block_id = parent_block_table[i]
            self.allocator.block_pool[block_id].ref_count += 1
    
    def append_slots(
        self, seq_id: int, num_new_tokens: int
    ) -> List[Tuple[int, int]]:
        """
        追加 token slot。这是 CoW 写操作的主要触发点。
        当序列需要写入新 block 时，该 block 的 ref_count 必为 1
        (因为刚分配)，所以不会触发 CoW。
        
        只有修改已存在的共享 block 时才会触发 CoW ——
        这种情况在标准 decode 中很少见。
        """
        # ... 见第 4 节的实现
    
    def free(self, seq_id: int) -> None:
        """
        释放序列。由于 CoW, 只有 ref_count 降至 0 的 block
        才会归还到 free list。
        """
        for block_id in self.block_tables[seq_id]:
            block = self.allocator.block_pool[block_id]
            block.ref_count -= 1
            if block.ref_count == 0:
                self.allocator.free(block)
```

### 5.7 CoW 的边界和限制

```
+----------------------------------------------------------------------+
|                CoW 的限制和注意事项                                    |
+----------------------------------------------------------------------+
|                                                                      |
|  1. GPU 内存复制开销:                                                 |
|     CoW 触发时需要做 GPU 到 GPU 的内存复制 (cudaMemcpy D2D)。          |
|     对于 1 MB 的 block (32 层合计)，在 A100 上约需 5-10 微秒。        |
|     如果频繁触发 CoW，累积开销可能显著。                                |
|                                                                      |
|  2. 碎片化:                                                           |
|     CoW 会创建多个部分共享 block 的序列，导致 block pool 碎片化。       |
|                                                                      |
|  3. 仅在 decode 开始时有意义:                                         |
|     CoW 最大的收益来自共享 prompt (prefill) 阶段的 block。             |
|     在 decode 阶段，每个序列生成不同的 token，自然不需要 CoW。          |
|                                                                      |
|  4. 与前缀缓存的交互:                                                 |
|     前缀缓存和 CoW 都利用 block 共享，但机制不同:                       |
|     - 前缀缓存: 跨请求共享相同前缀的 block (跨时间)                      |
|     - CoW: 同一时刻 fork 出的序列共享 block (跨序列)                    |
|     两者可以组合使用以达到最大效率。                                    |
|                                                                      |
+----------------------------------------------------------------------+
```

---

## 6. PagedAttention CUDA Kernel 深度解析

### 6.1 Kernel 签名与参数

PagedAttention 的 CUDA kernel 是整个系统的性能核心。它在每个注意力计算步骤中被调用，负责从分页存储中读取 K/V 并计算注意力分数。

```cuda
/*
 * PagedAttention CUDA Kernel 完整签名
 *
 * 文件: csrc/attention/paged_attention.cu (vLLM 源码)
 */

template <typename scalar_t, int HEAD_SIZE, int BLOCK_SIZE, int NUM_THREADS>
__global__ void paged_attention_kernel(
    // ========== 输出 ==========
    scalar_t* __restrict__ out,            // [num_seqs, num_heads, head_dim]
                                           // 注意力输出: 对每个序列的每个头,
                                           // 累积了所有历史 token 的加权 V
                                           // shape: [num_seqs, num_heads, head_size]
    
    // ========== 输入 ==========
    const scalar_t* __restrict__ query,    // [num_seqs, num_heads, head_dim]
                                           // 当前 token 的 Query 向量
                                           // 每个序列的每个头一个查询向量
    
    // ========== KV Cache ==========
    const scalar_t* __restrict__ key_cache,    // 所有物理 block 的 K cache
                                               // layout: [num_blocks, num_kv_heads,
                                               //           block_size, head_dim]
                                               // 这是分页存储的底层数据
    
    const scalar_t* __restrict__ value_cache,  // 所有物理 block 的 V cache
                                               // layout: 与 key_cache 相同
    
    // ========== 页表 ==========
    const int* __restrict__ block_tables,      // Block Table (页表)
                                               // shape: [num_seqs, max_blocks_per_seq]
                                               // block_tables[s, i] = 序列 s 的
                                               //   第 i 个逻辑 block 对应的物理 block ID
                                               // -1 表示未使用
    
    // ========== 元数据 ==========
    const int* __restrict__ context_lens,      // 每个序列的有效上下文长度
                                               // shape: [num_seqs]
                                               // 因为最后一个 block 可能未满,
                                               // 需要知道哪些 token 是有效的
    
    // ========== 超参数 ==========
    const float scale,                         // 注意力缩放因子
                                               // 通常 = 1.0 / sqrt(head_dim)
    
    const int max_context_len                  // 所有序列中的最大上下文长度
                                               // 用于确定循环边界
);
```

### 6.2 Kernel 的核心逻辑 (伪代码)

```
=======================================================================
  PagedAttention Kernel 核心计算流程
=======================================================================

对于每个线程块 (处理一个序列的一个注意力头):

// =================================================================
// Phase 1: 初始化
// =================================================================
seq_id = blockIdx.x           // 当前处理的序列
head_id = blockIdx.y          // 当前处理的注意力头
kv_head_id = head_id / num_queries_per_kv  // GQA 映射

// 从 global memory 加载 Query
float q[HEAD_DIM];
for (i = 0; i < HEAD_DIM; i += NUM_THREADS):
    q[threadIdx.x + i] = query[seq_id * num_heads * HEAD_DIM
                                + head_id * HEAD_DIM
                                + threadIdx.x + i]

// 初始化软最大值的累加器
float max_logit = -INFINITY  // 在线 softmax 需要追踪最大值
float sum_exp = 0.0          // 在线 softmax 需要追踪指数和
float output[HEAD_DIM] = {0} // 最终输出的累加器

// =================================================================
// Phase 2: 遍历 Block Table, 逐个 block 处理
// =================================================================
num_valid_blocks = ceil(context_lens[seq_id] / BLOCK_SIZE)

for (block_idx = 0; block_idx < num_valid_blocks; block_idx++):
    
    // -----------------------------------------------------------
    // Step 2.1: 地址转换 (通过 Block Table)
    // -----------------------------------------------------------
    physical_block_id = block_tables[seq_id * max_blocks_per_seq + block_idx]
    
    if (physical_block_id == -1):
        break  // 未分配, 序列结束
    
    // -----------------------------------------------------------
    // Step 2.2: 计算当前 block 的有效 token 数
    // -----------------------------------------------------------
    block_start_token = block_idx * BLOCK_SIZE
    tokens_in_block = min(BLOCK_SIZE,
                          context_lens[seq_id] - block_start_token)
    
    // -----------------------------------------------------------
    // Step 2.3: 遍历 block 内的每个 token
    // -----------------------------------------------------------
    for (tok_offset = 0; tok_offset < tokens_in_block; tok_offset++):
        
        // -------------------------------------------------------
        // 从分页存储中加载 K 和 V
        // -------------------------------------------------------
        // 内存地址计算:
        // K_addr = key_cache + physical_block_id * BLOCK_SIZE 
        //                        * NUM_KV_HEADS * HEAD_DIM
        //        + kv_head_id * BLOCK_SIZE * HEAD_DIM
        //        + tok_offset * HEAD_DIM
        //
        // 使用向量化加载 (float4) 以最大化内存带宽
        
        float k[HEAD_DIM];
        float v[HEAD_DIM];
        
        for (i = 0; i < HEAD_DIM; i += NUM_THREADS):
            idx = threadIdx.x + i
            k[idx] = key_cache[物理地址 + idx]
            v[idx] = value_cache[物理地址 + idx]
        
        // -------------------------------------------------------
        // 计算注意力分数: score = Q * K^T / sqrt(d_k)
        // -------------------------------------------------------
        float score = 0.0
        for (i = 0; i < HEAD_DIM; i++):
            score += q[i] * k[i]
        score *= scale  // scale = 1/sqrt(head_dim)
        
        // -------------------------------------------------------
        // 在线 Softmax (Online Softmax)
        // -------------------------------------------------------
        // 标准 softmax 需要两遍: 先求 max, 再求 exp sum
        // 在线 softmax 可以在单遍中完成:
        
        if (score > max_logit):
            // 发现新的最大值, 需要对已累积的输出做 rescale
            float rescale = exp(max_logit - score)
            sum_exp *= rescale
            for (i = 0; i < HEAD_DIM; i++):
                output[i] *= rescale
            max_logit = score
        
        float exp_score = exp(score - max_logit)
        sum_exp += exp_score
        
        // -------------------------------------------------------
        // 累加输出: output += score * V
        // -------------------------------------------------------
        for (i = 0; i < HEAD_DIM; i++):
            output[i] += exp_score * v[i]

// =================================================================
// Phase 3: 最终归一化
// =================================================================
float inv_sum = 1.0 / sum_exp
for (i = 0; i < HEAD_DIM; i += NUM_THREADS):
    idx = threadIdx.x + i
    out[seq_id * num_heads * HEAD_DIM + head_id * HEAD_DIM + idx]
        = output[idx] * inv_sum
```

### 6.3 内存访问模式分析

PagedAttention 的内存访问模式是其性能特征的核心：

```
+======================================================================+
|              内存访问模式分析                                          |
+======================================================================+
|                                                                      |
|  Block 内部的访问 (连续访问):                                         |
|  +------------------------------------------------------------------+|
|  | 在一个 block 内部, K 和 V 的存储是连续的:                          ||
|  |                                                                  ||
|  | K_cache for block[k], head[h]:                                   ||
|  | +--------+--------+--------+-----+--------+                      ||
|  | | tok[0] | tok[1] | tok[2] | ... | tok[15]|                     ||
|  | +--------+--------+--------+-----+--------+                      ||
|  | ^^^^^^^^ ^^^^^^^^ ^^^^^^^^       ^^^^^^^^                        ||
|  | 连续读取, L1/L2 cache hits 良好, 内存带宽利用率高                   ||
|  |                                                                  ||
|  | 合并访问 (Coalesced Access): 相邻线程访问相邻内存地址,              ||
|  |   GPU 可以将多次小的读取合并为一次大的内存事务.                     ||
|  |   block 内部的 K/V 布局确保了这种合并访问模式.                      ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  Block 之间的访问 (随机访问):                                         |
|  +------------------------------------------------------------------+|
|  | 不同 block 在物理内存中是不连续的:                                  ||
|  |                                                                  ||
|  | Block Table: [物理 block 7, 物理 block 3, 物理 block 15, ...]     ||
|  |                                                                  ||
|  | 从 block 0 跳到 block 1 需要访问:                                  ||
|  |   1. 读取 block_tables[seq_id][1] = 3                             ||
|  |   2. 计算 block 3 的内存地址                                       ||
|  |   3. 跳到该地址 (完全不同的 GPU HBM 区域)                           ||
|  |                                                                  ||
|  | 这是一个随机访问, cache 局部性差.                                  ||
|  | 但 block 大小为 16/32 → 块间距足够大,                               ||
|  |   使得 block 内访问足以摊销 block 间跳转的开销.                      ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  访问模式总结:                                                        |
|  +------------------------------------------------------------------+|
|  |                                                                  ||
|  |  [Block 0 访问]     [Block 1 访问]     [Block 2 访问]             ||
|  |  +------------+    +------------+    +------------+               ||
|  |  | 连续 连续  |    | 连续 连续  |    | 连续 连续  |               ||
|  |  | 连续 连续  |    | 连续 连续  |    | 连续 连续  |               ||
|  |  | 连续 连续  |    | 连续 连续  |    | 连续 连续  |               ||
|  |  +------------+    +------------+    +------------+               ||
|  |        |                 |                 |                      ||
|  |        +---- 跳转 ----->+---- 跳转 ------>+                       ||
|  |       (随机访问)       (随机访问)       (随机访问)                  ||
|  |                                                                  ||
|  |  连续访问: 内存带宽利用率高 (接近峰值带宽的 70-90%)                 ||
|  |  跳转访问: 内存带宽利用率低 (约 10-30%)                            ||
|  |  总效率: 取决于 block 大小, block 越大则跳转占比越低, 效率越高       ||
|  |                                                                  ||
|  +------------------------------------------------------------------+|
|                                                                      |
+======================================================================+
```

### 6.4 Block Size 的选择：一个精巧的权衡

```
+======================================================================+
|              Block Size 的权衡分析                                     |
+======================================================================+
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                    小 block (e.g., 8)                             ||
|  |                                                                  ||
|  |  优点:                                                            ||
|  |    - 减少内部碎片: 每请求浪费 < 8 个 slot                          ||
|  |    - 更细粒度的共享: 前缀缓存命中粒度更细                           ||
|  |    - 更灵活的内存分配                                               ||
|  |                                                                  ||
|  |  缺点:                                                            ||
|  |    - Block 间跳转更频繁: 4096/8=512 次跳转 vs 4096/16=256 次跳转  ||
|  |    - Block Table 更大: 更多条目需要存储和读取                       ||
|  |    - 内存访问效率更低: 连续段更短                                    ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                    大 block (e.g., 32)                            ||
|  |                                                                  ||
|  |  优点:                                                            ||
|  |    - 更好的内存合并访问: 更长的连续读取段                           ||
|  |    - 更少的 Block Table 查找: 减少全局内存读取                     ||
|  |    - 更少的跳转开销: 更少的内存地址重算                             ||
|  |                                                                  ||
|  |  缺点:                                                            ||
|  |    - 更大的内部碎片: 每请求浪费 < 32 个 slot                       ||
|  |    - 更粗粒度的共享: 前缀缓存命中粒度更粗                           ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  vLLM 默认使用 block_size=16:                                         ||
|                                                                      |
|  随机跳转开销 vs 连续访问收益的平衡点大约在 block_size=16 附近。       ||
|  对于大多数 GPU 架构 (A100, H100, 等), 128-256 字节的连续访问          ||
|  足以利用 L2 cache 和内存合并访问.                                     ||
|                                                                      |
|  block_size=16 时每个 block 内 K 的连续访问量:                         ||
|    head_dim=128, dtype=FP16 → 16 x 128 x 2 = 4,096 bytes            ||
|  这远大于 GPU L2 cache line (128 bytes), 足以实现高效的合并访问.       ||
|                                                                      |
+======================================================================+
```

### 6.5 GQA 处理的优化

对于 GQA (Grouped Query Attention)，多个 Q 头共享同一组 K/V 头。PagedAttention kernel 对此做了优化：

```
+======================================================================+
|              GQA 在 PagedAttention 中的处理                            |
+======================================================================+
|                                                                      |
|  以 Qwen-7B 为例: num_q_heads=32, num_kv_heads=4, ratio=8:1         |
|                                                                      |
|  线程块分配策略:                                                      |
|                                                                      |
|  Grid: (num_seqs, num_q_heads)  共 num_seqs x 32 个线程块           |
|                                                                      |
|  Q head 0..7   → KV head 0                                          |
|  Q head 8..15  → KV head 1                                          |
|  Q head 16..23 → KV head 2                                          |
|  Q head 24..31 → KV head 3                                          |
|                                                                      |
|  优化: K 和 V 的复用                                                 |
|  +------------------------------------------------------------------+|
|  |                                                                  ||
|  |  处理序列 s 时:                                                    ||
|  |                                                                  ||
|  |  +--------+--------+--------+--------+--------+                  ||
|  |  | Q_h0   | Q_h1   | ...    | Q_h7   |        |                  ||
|  |  | 使用   | 使用   |        | 使用   |        |                  ||
|  |  | KV_h0  | KV_h0  |        | KV_h0  |        |                  ||
|  |  +--------+--------+--------+--------+--------+                  ||
|  |       ^         ^             ^                                   ||
|  |       |         |             |                                   ||
|  |       +---------+-------------+---- 所有 8 个 Q 头共享同一份 K/V   ||
|  |                                                                  ||
|  |  理论上可以让这 8 个线程块协作加载 K/V, 放入共享内存后共同使用.      ||
|  |  但实际上, 由于 CUDA 线程块间无法直接通信 (无全局栅栏),              ||
|  |  通常的做法是每个线程块独立加载自己需要的 K/V.                       ||
|  |                                                                  ||
|  |  但有一个关键优化:                                                 ||
|  |  GQA 减少了 num_kv_heads, 使得 key_cache 和 value_cache            ||
|  |  的总大小缩小, 增大了 L2 cache 的有效命中率.                        ||
|  |  即使每个 Q 头独立加载 K/V, 较小的 K/V footprint 也意味着           ||
|  |  在遍历 block 时更容易命中 L2 cache.                                ||
|  |                                                                  ||
|  +------------------------------------------------------------------+|
|                                                                      |
+======================================================================+
```

### 6.6 Kernel 的性能特征数据

```
+======================================================================+
|        PagedAttention Kernel 性能特征 (A100-80GB, FP16)               |
+======================================================================+
|                                                                      |
|  模型: OPT-13B (40层, num_heads=40, head_dim=128)                     |
|                                                                      |
|  Context Length | Block Size | Latency (us) | Memory BW Utilization |
|  --------------|-----------|-------------|----------------------|
|  512           | 16        | ~45         | ~65%                 |
|  1024          | 16        | ~85         | ~70%                 |
|  2048          | 16        | ~165        | ~72%                 |
|  4096          | 16        | ~320        | ~68%                 |
|  512           | 32        | ~43         | ~68%                 |
|  1024          | 32        | ~80         | ~73%                 |
|  2048          | 32        | ~155        | ~74%                 |
|                                                                      |
|  观察:                                                               |
|  - Latency 随 context length 线性增长 (O(n) 注意力计算)               |
|  - Block size=32 比 block size=16 略快 (更长的连续访问)               |
|  - 内存带宽利用率在短上下文中较低 (固定开销占比大)                      |
|                                                                      |
+======================================================================+
```

### 6.7 与标准 Attention Kernel 的对比

```
+======================================================================+
|         PagedAttention Kernel vs 标准 Attention Kernel               |
+======================================================================+
|                                                                      |
|  标准 Attention Kernel (连续 KV Cache):                               |
|  ========================================                            |
|                                                                      |
|  输入: Q [num_seqs, num_heads, head_dim]                             |
|        K [num_seqs, num_heads, max_seq_len, head_dim]  ← 连续张量    |
|        V [num_seqs, num_heads, max_seq_len, head_dim]                |
|                                                                      |
|  // 简单的矩阵乘法:                                                   |
|  scores = Q @ K^T    // [num_seqs, num_heads, 1, max_seq_len]        |
|  scores = softmax(scores * scale)                                    |
|  output = scores @ V  // [num_seqs, num_heads, 1, head_dim]          |
|                                                                      |
|  优点: 高度优化的 GEMM kernel, 极高吞吐                               |
|  缺点: 内存在序列长度维度上浪费严重 (大部分 token 位置为空)            |
|                                                                      |
|                                                                      |
|  PagedAttention Kernel (分页 KV Cache):                               |
|  ========================================                            |
|                                                                      |
|  输入: Q, key_cache[blocks], value_cache[blocks], block_table        |
|                                                                      |
|  // 遍历 block:                                                       |
|  for each block:                                                     |
|    K_block = load from key_cache[block_table[i]]                      |
|    V_block = load from value_cache[block_table[i]]                    |
|    scores = Q @ K_block^T                                            |
|    output += softmax(scores) @ V_block                                |
|                                                                      |
|  优点: 极高的内存利用率, 支持任意长度的动态分配                         |
|  缺点: 额外的 block table 查找和 block 间跳转开销                     |
|                                                                      |
|                                                                      |
|  性能差异:                                                            |
|  =========                                                           |
|                                                                      |
|  对于短上下文 (< 256 tokens), 标准 Attention 的矩阵乘法更高效          |
|  对于长上下文 (> 2048 tokens), 差异缩小                                |
|  PagedAttention 的额外开销通常在 5-10% 以内                           |
|  但这 5-10% 的开销换来了 2-3x 的内存利用率提升和吞吐提升                |
|                                                                      |
+======================================================================+
```

---

## 7. 基于 Block Table 的前缀缓存

### 7.1 前缀缓存的动机

在 LLM 服务中，大量请求共享相同的前缀：

```
+----------------------------------------------------------------------+
|                    前缀共享的常见场景                                  |
+----------------------------------------------------------------------+
|                                                                      |
|  场景 1: 系统提示词 (System Prompt)                                   |
|  =================================                                    |
|                                                                      |
|  所有请求都以相同的 system prompt 开始:                                |
|                                                                      |
|  请求 1: [system_prompt (500t)] + "翻译: Hello"                       |
|  请求 2: [system_prompt (500t)] + "翻译: Goodbye"                     |
|  请求 3: [system_prompt (500t)] + "翻译: Thank you"                   |
|  ...                                                                 |
|                                                                      |
|  system_prompt 的 KV Cache 可以跨所有请求复用!                         |
|                                                                      |
|                                                                      |
|  场景 2: 多轮对话                                                     |
|  =================================                                    |
|                                                                      |
|  请求 1: [sys] + [msg1] + [resp1] + [msg2] + "生成回复..."           |
|  请求 2: [sys] + [msg1] + [resp1] + [msg2] + "改写回复..."           |
|                                                                      |
|  两个请求共享到 msg2 为止的全部前缀。                                  |
|                                                                      |
|                                                                      |
|  场景 3: 少样本学习 (Few-shot Prompt)                                  |
|  =================================                                    |
|                                                                      |
|  few_shot_examples (1000 tokens): "示例1: ... 示例2: ... 示例3: ..."  |
|                                                                      |
|  请求 1: [few_shot] + "问题A"                                        |
|  请求 2: [few_shot] + "问题B"                                        |
|  请求 3: [few_shot] + "问题C"                                        |
|                                                                      |
+----------------------------------------------------------------------+
```

### 7.2 Block 内容哈希

为了实现前缀缓存，需要一种快速的方法来判断两个 block 是否包含相同的 token 内容：

```
+======================================================================+
|              Block 内容哈希方案                                       |
+======================================================================+
|                                                                      |
|  方案 1: 基于首尾 Token                                               |
|  ==========================================                           |
|                                                                      |
|  hash(block) = hash(token[0] || token[block_size-1])                 |
|                                                                      |
|  简单但容易冲突。                                                     |
|  block_size=16, 仅用首尾 token 无法区分中间不同的序列。               |
|                                                                      |
|                                                                      |
|  方案 2: 滑动哈希 (Rolling Hash)                                      |
|  ==========================================                           |
|                                                                      |
|  block_hash = 0                                                      |
|  for each token in block:                                            |
|      block_hash = (block_hash * BASE + token_id) % MOD               |
|                                                                      |
|  更好的方案，但仍有冲突概率。                                         |
|  在 vLLM 中, MOD 通常取 2^64 左右的大质数, BASE 取 257 或其他大素数。 |
|                                                                      |
|                                                                      |
|  方案 3: 全内容哈希 (vLLM v1 使用的方案)                              |
|  ==========================================                           |
|                                                                      |
|  使用 xxHash 或类似算法对 block 内所有 token 的内容做哈希。            |
|                                                                      |
|  hash = xxhash64([token_0, token_1, ..., token_{block_size-1}])     |
|                                                                      |
|  在实践中，加上 block 中最后一个 token 的 position 作为 salt,          |
|  以区分相同内容但不同位置的 block。                                    |
|                                                                      |
+======================================================================+
```

### 7.3 前缀缓存的 Radix Tree 结构

vLLM v1 使用 Radix Tree (压缩前缀树) 来组织缓存的 block：

```
+======================================================================+
|              前缀缓存 Radix Tree                                      |
+======================================================================+
|                                                                      |
|  Radix Tree 每个节点代表一个 Block 哈希值,                             |
|  路径从根到叶对应一个 token 序列的前缀。                               |
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                                                                  ||
|  |                          [Root]                                   ||
|  |                         /      \                                 ||
|  |                  hash=H1        hash=H6                           ||
|  |                   /                \                              ||
|  |              hash=H2              hash=H7                          ||
|  |             /       \                \                           ||
|  |         hash=H3   hash=H4          hash=H8                         ||
|  |            |          |               |                            ||
|  |         hash=H5   hash=H5          hash=H9                         ||
|  |                    (分叉点)                                        ||
|  |                                                                  ||
|  |  解读:                                                            ||
|  |  路径 Root→H1→H2→H3→H5 对应一个完整的 token 前缀                  ||
|  |  路径 Root→H1→H2→H4→H5 对应另一个前缀 (与上面在 H2 后分叉)        ||
|  |  路径 Root→H6→H7→H8→H9 对应第三个前缀                              ||
|  |                                                                  ||
|  |  叶子节点存储物理 block ID，内部节点可能也存储。                     ||
|  |                                                                  ||
|  +------------------------------------------------------------------+|
|                                                                      |
+======================================================================+
```

### 7.4 前缀缓存的分配逻辑

```
=======================================================================
  带前缀缓存的 allocate 函数
=======================================================================

def allocate_with_prefix_cache(seq_id, num_new_tokens, token_ids):
    """
    带前缀缓存查找的分配函数。
    如果新 token 序列的前缀已存在于缓存中，复用对应的物理 block。
    """
    # token_ids 是需要处理的新 token 列表
    new_tokens = token_ids[sequence_lengths[seq_id]:]
    
    block_idx = sequence_num_blocks[seq_id]
    token_pos = sequence_lengths[seq_id]
    
    while token_pos < len(token_ids):
        # 提取一个 block 的 token
        block_tokens = token_ids[token_pos:token_pos + block_size]
        
        # 计算哈希
        block_hash = compute_hash(block_tokens)
        
        # 在前缀缓存中查找
        cached_block = prefix_cache.lookup(block_hash)
        
        if cached_block is not None:
            # 缓存命中! 复用物理 block  (不需要重新计算 K/V)
            block_table[seq_id, block_idx] = cached_block.block_id
            cached_block.ref_count += 1
            
            # 标记 block 中包含的有效 token 数
            # 注意最后一个 block 可能不满
            block_token_count[seq_id, block_idx] = len(block_tokens)
        else:
            # 缓存未命中, 分配新 block
            block = free_list.pop()
            block.ref_count = 1
            
            block_table[seq_id, block_idx] = block.block_id
            
            # 将新 block 加入前缀缓存
            prefix_cache.insert(block_hash, block)
            
            # 标记此 block 需要计算 K/V (因为缓存未命中)
            mark_for_computation(seq_id, block_idx)
        
        block_idx += 1
        token_pos += block_size
```

### 7.5 缓存淘汰策略

当 free block pool 耗尽时，需要淘汰前缀缓存中的 block：

```
+----------------------------------------------------------------------+
|                    前缀缓存淘汰策略                                    |
+----------------------------------------------------------------------+
|                                                                      |
|  LRU (Least Recently Used) 淘汰:                                      |
|  ==========================================                           |
|                                                                      |
|  每个缓存的 block 维护一个 last_access_time。                         |
|  当需要释放 block 时，选择 last_access_time 最早的 block。            |
|                                                                      |
|  但有一个关键约束:                                                     |
|  只有 ref_count == 1 的 block 才能被淘汰。                            |
|  (ref_count > 1 表示仍有活跃请求在使用该 block)                       |
|                                                                      |
|  def evict_lru():                                                    |
|      candidates = [b for b in prefix_cache                         |
|                     if b.ref_count == 1]                            |
|      if not candidates:                                             |
|          return False  # 所有缓存 block 都在使用中                    |
|                                                                      |
|      victim = min(candidates, key=lambda b: b.last_access_time)      |
|      prefix_cache.remove(victim.hash)                                |
|      victim.ref_count = 0                                           |
|      free_list.push(victim)                                         |
|      return True                                                     |
|                                                                      |
|                                                                      |
|  淘汰策略的变体:                                                      |
|                                                                      |
|  1. LRU: 淘汰最久未使用的 (经典选择)                                   |
|  2. LFU: 淘汰最少使用的 (对热门 system prompt 更友好)                 |
|  3. FIFO: 淘汰最早加入的 (最简单)                                     |
|  4. Size-based: 优先淘汰大 block (如果支持多 block size)              |
|                                                                      |
|  vLLM 默认使用 LRU 策略。                                             |
|                                                                      |
+----------------------------------------------------------------------+
```

### 7.6 自动前缀缓存 (Automatic Prefix Caching, APC)

vLLM v1 引入了 APC，无需用户显式指定哪些是前缀，系统自动检测并缓存：

```
+======================================================================+
|              自动前缀缓存 (APC) 的工作原理                             |
+======================================================================+
|                                                                      |
|  核心思想:                                                            |
|  1. 每个 block 计算内容哈希                                           |
|  2. 哈希相同的 block 自动共享                                        |
|  3. LRU 淘汰不活跃的缓存 block                                       |
|                                                                      |
|  优点:                                                                |
|  - 零配置: 用户无需知道前缀缓存的存在                                  |
|  - 通用性: 适用于任何前缀共享场景                                      |
|  - 透明性: 不影响任何 API 接口                                        |
|                                                                      |
|  工作流程:                                                            |
|                                                                      |
|  Request 到达 (token_ids = [t0, t1, ..., tN])                        |
|      |                                                               |
|      v                                                               |
|  将 token_ids 划分为 block (每 block_size 个 token)                   |
|      |                                                               |
|      v                                                               |
|  对每个 block: 计算哈希 → 查找前缀缓存                                 |
|      |                                                               |
|      +---- 命中 → 复用物理 block, ref_count++                        |
|      |                                                               |
|      +---- 未命中 → 分配新 block, 插入前缀缓存                        |
|      |                                                               |
|      v                                                               |
|  对于未命中的 block: 需要计算 K/V (prefill)                            |
|  对于命中的 block: 跳过 K/V 计算 (直接使用缓存的值)                    |
|      |                                                               |
|      v                                                               |
|  Decode 阶段: 生成的 token 也按 block 粒度缓存                        |
|      |                                                               |
|      v                                                               |
|  请求结束时: 共享的 block (ref_count>1) 保留在缓存中                   |
|             独占的 block (ref_count==1) 可选择保留或淘汰               |
|                                                                      |
+======================================================================+
```

### 7.7 前缀缓存的效率分析

```
+----------------------------------------------------------------------+
|              前缀缓存的节省效果                                        |
+----------------------------------------------------------------------+
|                                                                      |
|  场景: 100 个请求, 每个有 500 token 的相同 system prompt              |
|        每个请求额外有 200 token 的不同用户输入                          |
|                                                                      |
|  system_prompt: 500 tokens → ceil(500/16) = 32 blocks                |
|  user_input: 200 tokens → ceil(200/16) = 13 blocks                  |
|                                                                      |
|  无前缀缓存:                                                          |
|    总 block = 100 × (32 + 13) = 4,500 blocks                         |
|    KV Cache = 4,500 × 1 MB = 4.5 GB (32层每block, 仅供参考)         |
|                                                                      |
|  有前缀缓存:                                                          |
|    共享 block = 32 blocks (system prompt)                            |
|    独有 block = 100 × 13 = 1,300 blocks                              |
|    总 block = 1,332 blocks                                           |
|                                                                      |
|  节省: (4,500 - 1,332) / 4,500 = 70.4%                              |
|                                                                      |
|  更重要的是: system prompt 的 32 个 block 只需计算一次 K/V (prefill),  |
|  后续 99 个请求直接跳过 prefill, 大幅降低计算开销。                     |
|                                                                      |
+----------------------------------------------------------------------+
```

---

## 4. 内存效率：理论分析

### 4.1 内部碎片的精确分析

PagedAttention 将**外部碎片**完全消除（因为不需要连续分配），但引入了**内部碎片**：最后一个 block 中未被完全使用的 slot。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      内部碎片 (Internal Fragmentation)                        │
│                                                                              │
│  sequence_length = 100 tokens, block_size = 16                              │
│                                                                              │
│  ┌────────┬────────┬────────┬────────┬────────┬────────┬──────┐            │
│  │ Block0 │ Block1 │ Block2 │ Block3 │ Block4 │ Block5 │ Blk6 │            │
│  │ 16/16  │ 16/16  │ 16/16  │ 16/16  │ 16/16  │ 16/16  │████░░│            │
│  │   ✓    │   ✓    │   ✓    │   ✓    │   ✓    │   ✓    │4/12  │            │
│  └────────┴────────┴────────┴────────┴────────┴────────┴──────┘            │
│                                                                              │
│  num_blocks = ceil(100 / 16) = 7    allocated_tokens = 7*16 = 112            │
│  actual_tokens = 100                wasted = 112 - 100 = 12                  │
│  利用率 = 100/112 = 89.3%           最大浪费 = 15 tokens                      │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 严格数学证明：最大浪费有界

**定理**：对于任意序列长度 L，使用 block_size=B 的 PagedAttention，内部碎片浪费的 token 数不超过 B-1。

**证明**：num_blocks = ceil(L/B) <= (L+B-1)/B，因此：
- allocated = num_blocks * B <= L + B - 1
- wasted = allocated - L <= B - 1
- U = L/allocated >= L/(L+B-1)

当 L → ∞ 时，lim(L→∞) U >= 1，即利用率趋近于 100%。

### 4.3 利用率对比表

```
  不同序列长度和 Block Size 下的理论利用率对比:

  Sequence    │  B=8          │  B=16         │  B=32         │  B=64
  Length      │  blocks │ U%  │  blocks │ U%  │  blocks │ U%  │  blocks │ U%
  ────────────┼─────────┼─────┼─────────┼─────┼─────────┼─────┼─────────┼────
   50         │   7     │89.3%│   4     │78.1%│   2     │78.1%│   1     │78.1%
  100         │  13     │96.2%│   7     │89.3%│   4     │78.1%│   2     │78.1%
  200         │  25     │100% │  13     │96.2%│   7     │89.3%│   4     │78.1%
  500         │  63     │99.2%│  32     │97.7%│  16     │97.7%│   8     │97.7%
  1024        │ 128     │100% │  64     │100% │  32     │100% │  16     │100%
  2048        │ 256     │100% │ 128     │100% │  64     │100% │  32     │100%
  4096        │ 512     │100% │ 256     │100% │ 128     │100% │  64     │100%
  8192        │1024     │100% │ 512     │100% │ 256     │100% │ 128     │100%

  关键观察:
  1. 对于短序列 (<200 tokens), B=8 利用率最高
  2. 对于长序列 (>512 tokens), B=16/32/64 利用率差异极小
  3. B=16 在所有长度下利用率 >= 78%, >=200 时 >= 89%, >=500 时 >= 98%
  4. 与预分配 (利用率 ~6.2%) 的对比: B=16 平均提升 15-20 倍
```

> **实践要点**：如果你的请求以短序列为主（如 chatbot），可以减小 block_size 到 8 以提高利用率。如果以长序列为主（如文档摘要），block_size=16 或 32 都可以获得 >95% 的利用率。

---

## 5. Block Table 实现

### 5.1 数据结构总览

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Block Table 完整数据结构                                 │
│                                                                              │
│  Block Table (GPU Tensor):                                                   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │ shape: [num_sequences, max_num_blocks_per_seq]  |  dtype: int32      │   │
│  │                                                                      │   │
│  │  row i = 序列 i 的映射表,  col j = 第 j 个逻辑 block → 物理 block ID  │   │
│  │  -1 = INVALID / 未分配                                                │   │
│  │                                                                      │   │
│  │         log0  log1  log2  log3  log4  log5  log6  log7              │   │
│  │  seq0: [  2,   -1,   -1,   -1,   -1,   -1,   -1,   -1]            │   │
│  │  seq1: [  3,    4,    6,    7,   -1,   -1,   -1,   -1]            │   │
│  │  seq2: [  5,   -1,   -1,   -1,   -1,   -1,   -1,   -1]            │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  物理 KV Cache Blocks (GPU Tensor):                                          │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │ shape: [num_physical_blocks, 2, block_size, num_kv_heads, head_dim]  │   │
│  │ dtype: float16/bfloat16  |  device: cuda                             │   │
│  │ 每个物理 block 存储: K:[block_size, num_kv_heads, head_dim]          │   │
│  │                     V:[block_size, num_kv_heads, head_dim]          │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  每个 Block 的引用计数 (CPU 端):                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  block_ref_count: List[int] (长度 = num_physical_blocks)              │   │
│  │  示例: [0, 0, 1, 1, 1, 1, 1, 1, 0, ...]  block 2-7 各被引用 1 次    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Block Table 索引的三个关键操作

```
操作 1: Token Position → Logical Block Index
  logical_block_idx = token_position // block_size
  block_offset      = token_position % block_size

操作 2: Logical Block Index → Physical Block ID
  physical_block_id = block_table[seq_id][logical_block_idx]

操作 3: Physical Block ID → GPU Memory Address
  K_offset = physical_block_id * block_size * num_kv_heads * head_dim
           + block_offset * num_kv_heads * head_dim
           + kv_head_id * head_dim

完整索引链:
  token_position → logical_block_idx → physical_block_id → memory address

示例: seq_id=1, token_position=100, block_size=16
  logical_block_idx = 100 // 16 = 6
  block_offset      = 100 % 16 = 4
  physical_block_id = block_table[1][6]  → 假设返回 42
  → K[42 * 16 * 8 * 128 + 4 * 8 * 128 + head_idx * 128]
```

### 5.3 Attention Kernel 中 Block Table 的核心循环

```cuda
// PagedAttention Kernel 中的核心循环 (伪代码)
__global__ void paged_attention_kernel(
    const float16* Q, const float16* K_cache, const float16* V_cache,
    const int32* block_table, const int32* seq_lengths,
    float16* output, int max_num_blocks, int block_size, float scale
) {
    int seq_id = blockIdx.x, head_id = threadIdx.y;
    int seq_len = seq_lengths[seq_id];
    int num_blocks = (seq_len + block_size - 1) / block_size;
    
    float max_logit = -INFINITY, sum_exp = 0.0f;
    
    // ═══ 遍历该序列的所有 KV blocks ═══
    for (int block_idx = 0; block_idx < num_blocks; block_idx++) {
        
        // ─── PagedAttention 最核心的一行：间接索引 ───
        int physical_block_id = block_table[seq_id * max_num_blocks + block_idx];
        // ─────────────────────────────────────────────
        
        const float16* K_block = K_cache + physical_block_id * block_size
                                          * num_kv_heads * head_dim;
        
        int tokens_in_block = min(block_size, seq_len - block_idx * block_size);
        
        for (int t = 0; t < tokens_in_block; t++) {
            // 计算 Q · K[t] 点积
            float dot = 0.0;
            for (int d = 0; d < head_dim; d++)
                dot += (float)Q[head_id * head_dim + d]
                     * (float)K_block[t * num_kv_heads * head_dim
                                     + (head_id % num_kv_heads) * head_dim + d];
            dot *= scale;
            // 在线 softmax 更新
            float new_max = max(max_logit, dot);
            sum_exp = sum_exp * expf(max_logit - new_max) + expf(dot - new_max);
            max_logit = new_max;
        }
    }
    // ... softmax 归一化 + PV 加权求和 ...
}
```

> **实践要点**：block table 的索引操作在 kernel 的热循环中每 token 每 head 每 block 都会执行。好在 block_table 非常小（通常 < 1MB），可以放入 L2 cache，因此索引开销极低。



---

## 8. GPU-CPU 交换机制

### 8.1 交换的动机与架构

当 GPU 显存不足时，PagedAttention 可以将不活跃序列的 block 换出到 CPU 内存，在需要时再换入：

```
+======================================================================+
|              GPU-CPU 交换架构                                         |
+======================================================================+
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                        GPU HBM (80 GB)                           ||
|  |                                                                  ||
|  |  +----------------+  +----------------+  +----------------+       ||
|  |  | Active Seq A   |  | Active Seq B   |  | Free Blocks    |       ||
|  |  | Blocks         |  | Blocks         |  |                |       ||
|  |  +----------------+  +----------------+  +----------------+       ||
|  |                                                                  ||
|  |                              ||                                   ||
|  |                         PCIe 4.0 x16                             ||
|  |                         ~32 GB/s                                  ||
|  |                              ||                                   ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                        CPU DRAM (512 GB)                          ||
|  |                                                                  ||
|  |  +----------------+  +----------------+  +----------------+       ||
|  |  | Swapped Seq C  |  | Swapped Seq D  |  | Free CPU       |       ||
|  |  | Blocks         |  | Blocks         |  | Blocks         |       ||
|  |  +----------------+  +----------------+  +----------------+       ||
|  |                                                                  ||
|  +------------------------------------------------------------------+|
|                                                                      |
+======================================================================+
```

### 8.2 CPU Block Allocator

CPU 端镜像了 GPU 的 block 分配结构：

```
+----------------------------------------------------------------------+
|              CPU Block Allocator 结构                                 |
+----------------------------------------------------------------------+
|                                                                      |
|  class CPUBlockAllocator:                                            |
|      """                                                             |
|      CPU 端的 block 分配器。                                         |
|      镜像 GPU block allocator 的结构, 但内存分配在 CPU 端。           |
|      """                                                             |
|                                                                      |
|      def __init__(self, num_blocks, block_size, num_layers,          |
|                   num_kv_heads, head_dim, dtype):                    |
|          self.num_blocks = num_blocks                                |
|          self.block_size = block_size                                |
|                                                                      |
|          # 在 CPU 端分配 pin memory 以提高传输效率                    |
|          block_bytes = (block_size * num_kv_heads * head_dim         |
|                          * dtype.itemsize * 2 * num_layers)          |
|          self.total_size = num_blocks * block_bytes                  |
|                                                                      |
|          # 使用 CUDA pin memory (页锁定内存) 实现高速传输             |
|          self.data = torch.empty(                                    |
|              num_blocks * block_bytes,                               |
|              dtype=torch.uint8,                                      |
|              pin_memory=True  # 关键: 加速 CPU<->GPU 传输            |
|          )                                                           |
|                                                                      |
|          self.free_blocks = list(range(num_blocks))                  |
|          self.used_blocks = {}                                       |
|                                                                      |
+----------------------------------------------------------------------+
```

### 8.3 Swap Out 和 Swap In

```
=======================================================================
  swap_out: 将 GPU block 复制到 CPU
=======================================================================

def swap_out(seq_id):
    """
    将指定序列的所有 GPU block 复制到 CPU, 然后释放 GPU block。
    """
    num_blocks = sequence_num_blocks[seq_id]
    
    cpu_blocks = []
    for i in range(num_blocks):
        gpu_block_id = block_table[seq_id, i]
        
        if gpu_block_id == -1:
            continue
        
        # 1. 在 CPU 端分配 block
        cpu_block_id = cpu_allocator.allocate()
        cpu_blocks.append(cpu_block_id)
        
        # 2. GPU → CPU 数据传输
        for layer in range(num_layers):
            gpu_ptr = gpu_block_address(gpu_block_id, layer)
            cpu_ptr = cpu_block_address(cpu_block_id, layer)
            
            # cudaMemcpy Device to Host
            cudaMemcpy(cpu_ptr, gpu_ptr, block_size_bytes,
                       cudaMemcpyDeviceToHost)
        
        # 3. 释放 GPU block
        gpu_block = physical_blocks[gpu_block_id]
        gpu_block.ref_count -= 1
        if gpu_block.ref_count == 0:
            free_list.push(gpu_block)
    
    # 4. 更新序列状态, 指向 CPU block
    swap_mapping[seq_id] = {
        'cpu_blocks': cpu_blocks,
        'num_blocks': num_blocks,
        'length': sequence_lengths[seq_id]
    }
    
    # 5. 清除 GPU block table 条目
    block_table[seq_id, :] = -1
    sequence_num_blocks[seq_id] = 0


=======================================================================
  swap_in: 将 CPU block 复制回 GPU
=======================================================================

def swap_in(seq_id):
    """
    将被换出的序列恢复到 GPU。
    """
    if seq_id not in swap_mapping:
        return  # 序列不在 swap 状态
    
    mapping = swap_mapping[seq_id]
    
    # 1. 在 GPU 端重新分配 block
    gpu_blocks = []
    for i in range(mapping['num_blocks']):
        gpu_block = free_list.pop()
        gpu_block.ref_count = 1
        gpu_blocks.append(gpu_block.block_id)
        
        # 2. CPU → GPU 数据传输
        cpu_block_id = mapping['cpu_blocks'][i]
        for layer in range(num_layers):
            cpu_ptr = cpu_block_address(cpu_block_id, layer)
            gpu_ptr = gpu_block_address(gpu_block.block_id, layer)
            
            # cudaMemcpy Host to Device
            cudaMemcpy(gpu_ptr, cpu_ptr, block_size_bytes,
                       cudaMemcpyHostToDevice)
    
    # 3. 恢复 block table
    block_table[seq_id, :len(gpu_blocks)] = gpu_blocks
    sequence_num_blocks[seq_id] = len(gpu_blocks)
    sequence_lengths[seq_id] = mapping['length']
    
    # 4. 释放 CPU block
    for cpu_block_id in mapping['cpu_blocks']:
        cpu_allocator.free(cpu_block_id)
    
    # 5. 清除 swap mapping
    del swap_mapping[seq_id]
```

### 8.4 交换的性能特性

```
+----------------------------------------------------------------------+
|              交换的性能分析                                            |
+----------------------------------------------------------------------+
|                                                                      |
|  带宽:                                                                |
|  ==========================================                           |
|                                                                      |
|  PCIe 4.0 x16: 理论 ~32 GB/s, 实践 ~25 GB/s                         |
|  PCIe 5.0 x16: 理论 ~64 GB/s, 实践 ~50 GB/s                         |
|  NVLink (A100): ~600 GB/s (GPU-to-GPU, 不用于 CPU 交换)              |
|                                                                      |
|  交换时间估算:                                                        |
|  ==========================================                           |
|                                                                      |
|  单个 block (1 MB, Qwen-7B, 32层):                                    |
|    传输时间 = 1 MB / 25 GB/s = 40 微秒                                |
|                                                                      |
|  一个序列的 63 个 block (1008 tokens):                                 |
|    传输时间 = 63 x 40 = 2,520 微秒 = 2.5 毫秒                         |
|                                                                      |
|  100 个序列同时 swap out:                                             |
|    传输时间 = 100 x 2.5 = 250 毫秒                                    |
|    这在推理的延迟预算中是可接受的 (p99 latency 通常在秒级)              |
|                                                                      |
|  何时使用交换:                                                        |
|  ==========================================                           |
|                                                                      |
|  适用场景:                                                            |
|  - 请求优先级变化: 高优先级请求到达, 换出低优先级请求                   |
|  - 批量处理: 积累一批请求后一起处理, 中间可能换出                       |
|  - 内存压力缓解: GPU 内存不足时, 换出空闲序列                          |
|                                                                      |
|  不适用场景:                                                          |
|  - 延迟敏感: swap in/out 的延迟可能影响用户体验                        |
|  - 频繁交换: 频繁交换的传输开销可能超过计算开销                         |
|                                                                      |
+----------------------------------------------------------------------+
```

### 8.5 重计算 vs 交换的权衡

```
+======================================================================+
|           重计算 (Recomputation) vs 交换 (Swapping)                    |
+======================================================================+
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                     重计算                                        ||
|  |                                                                  ||
|  |  当需要已换出序列的 KV Cache 时, 不进行 swap in,                    ||
|  |  而是重新执行 prefill (重新计算 K/V)。                             ||
|  |                                                                  ||
|  |  成本:                                                            ||
|  |  - 计算: O(n^2) 注意力重新计算 (prefill 的 FLOPs)                   ||
|  |  - 内存: 只需存储原始 token                                       ||
|  |  - 延迟: 取决于 prefill 速度 (A100 上 ~1000 tokens/ms)            ||
|  |                                                                  ||
|  |  优势: 不占用 PCIe 带宽, 不需要 CPU 内存                            ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                     交换                                          ||
|  |                                                                  ||
|  |  将 KV Cache 传输到 CPU, 需要时再传回。                            ||
|  |                                                                  ||
|  |  成本:                                                            ||
|  |  - 传输: PCIe 带宽 (~25 GB/s)                                    ||
|  |  - 内存: 需要等量的 CPU pin memory                                ||
|  |  - 延迟: ~40us/block (1 MB)                                      ||
|  |                                                                  ||
|  |  优势: 不需要重新计算, swap in 后立即可用                           ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  决策逻辑:                                                            |
|  ==========================================                           |
|                                                                      |
|  if 序列长度 < prefill_swap_breakeven_point:                         |
|      重计算更优 (短序列重计算很快)                                     |
|  else:                                                               |
|      交换更优 (长序列重计算开销大)                                     |
|                                                                      |
|  对于 Qwen-7B (prefill ~1000 tok/ms, swap ~25 GB/s):                 |
|    break-even ≈ 500-800 tokens                                       |
|                                                                      |
+======================================================================+
```

---

## 9. vLLM 源码中的代码架构

### 9.1 文件地图

```
+======================================================================+
|              vLLM 源码中 PagedAttention 相关的文件地图                 |
+======================================================================+
|                                                                      |
|  vllm/                                                               |
|  |                                                                   |
|  ├── core/                                                           |
|  |   ├── block/                                                      |
|  |   │   ├── interfaces.py           ← Block, BlockTable,            |
|  |   │   │                              BlockAllocator 的 ABC 接口   |
|  |   │   ├── naive_block.py          ← NaiveBlockAllocator (v0)     |
|  |   │   │                              简单的无前缀缓存实现          |
|  |   │   ├── prefix_caching_block.py ← PrefixCachingBlockAllocator   |
|  |   │   │                              (v1) 带自动前缀缓存的实现     |
|  |   │   └── cpu_offloading_block.py ← CPU 交换相关的 block 管理     |
|  |   │                                                               |
|  |   ├── block_manager.py            ← BlockSpaceManager             |
|  |   │                                  高层接口: fork, allocate,    |
|  |   │                                  append_slots, free, swap     |
|  |   │                                                               |
|  |   └── scheduler.py                ← 调度器: 协调 block 分配       |
|  |                                       与计算资源                   |
|  |                                                                   |
|  ├── attention/                                                      |
|  |   ├── ops/                                                        |
|  |   │   ├── paged_attn.py           ← Python 端 dispatch            |
|  |   │   │                              根据不同 GPU 架构选择       |
|  |   │   │                              最优的 kernel 实现            |
|  |   │   └── common.py               ← 共享工具函数                  |
|  |   │                                                               |
|  |   └── layers/                                                     |
|  |       └── attention.py            ← Attention 层实现              |
|  |                                       调用 paged_attn             |
|  |                                                                   |
|  ├── worker/                                                         |
|  |   └── model_runner.py             ← 模型执行器                    |
|  |                                       协调 prefill/decode         |
|  |                                                                   |
|  └── csrc/                           ← CUDA/C++ 扩展                 |
|      ├── attention/                                                  |
|      │   ├── paged_attention_v1.cu   ← PagedAttention kernel v1     |
|      │   ├── paged_attention_v2.cu   ← PagedAttention kernel v2     |
|      │   │                              (优化版本, 更好的流水线)     |
|      │   └── attention_kernels.cuh   ← 共享的头文件/宏               |
|      │                                                               |
|      ├── cache_kernels.cu            ← KV cache 读写 kernel          |
|      │                                  reshape_and_cache, etc.      |
|      │                                                               |
|      └── activation_kernels.cu       ← 激活函数 kernel               |
|                                                                      |
+======================================================================+
```

### 9.2 类层次结构

```
+======================================================================+
|              PagedAttention 类层次结构                                 |
+======================================================================+
|                                                                      |
|                                                                      |
|  ABC (抽象基类)                                                       |
|  ========================================                            |
|                                                                      |
|  Block (ABC)                                                         |
|  ├── block_id: int                                                   |
|  ├── ref_count: int                                                  |
|  ├── block_size: int                                                 |
|  └── is_allocated: bool                                              |
|                                                                      |
|  BlockAllocator (ABC)                                                |
|  ├── allocate() -> Block                                             |
|  ├── free(Block)                                                     |
|  ├── get_num_free_blocks() -> int                                    |
|  └── all_blocks: List[Block]                                         |
|                                                                      |
|  BlockTable (ABC)                                                    |
|  ├── block_table: Tensor  # [max_seqs, max_blocks]                   |
|  └── num_blocks_per_seq: List[int]                                   |
|                                                                      |
|                                                                      |
|  具体实现                                                            |
|  ========================================                            |
|                                                                      |
|  NaiveBlockAllocator (BlockAllocator)                                |
|  ├── 简单的 free list 管理                                           |
|  ├── 无前缀缓存                                                      |
|  └── 适用于 v0 版本                                                  |
|                                                                      |
|  PrefixCachingBlockAllocator (BlockAllocator)                        |
|  ├── 继承 NaiveBlockAllocator                                        |
|  ├── 增加: prefix_cache (基于哈希的缓存)                              |
|  ├── 增加: LRU 淘汰策略                                              |
|  └── 适用于 v1 版本                                                  |
|                                                                      |
|  CpuGpuBlockAllocator                                                |
|  ├── GPU 端: 标准 BlockAllocator                                     |
|  ├── CPU 端: 镜像的 block pool                                       |
|  └── swap_in / swap_out 方法                                        |
|                                                                      |
|                                                                      |
|  高层管理器                                                          |
|  ========================================                            |
|                                                                      |
|  BlockSpaceManager                                                  |
|  ├── block_allocator: BlockAllocator                                 |
|  ├── block_tables: Dict[int, BlockTable]                             |
|  ├── cross_seq_blocks: Dict[int, Block]  # 跨序列共享的 block       |
|  │                                                                   |
|  ├── allocate(seq, num_tokens)                                       |
|  ├── append_slots(seq, num_tokens) -> List[Tuple[int, int]]          |
|  ├── fork(parent_seq, child_seq)                                     |
|  ├── free(seq)                                                       |
|  ├── can_allocate(num_tokens) -> bool                                |
|  ├── swap_in(seq)                                                    |
|  ├── swap_out(seq)                                                   |
|  └── get_num_free_blocks() -> int                                    |
|                                                                      |
+======================================================================+
```

### 9.3 组件交互流程

```
+======================================================================+
|              请求处理完整流程中的组件交互                               |
+======================================================================+
|                                                                      |
|                                                                      |
|  1. 请求到达 Scheduler                                               |
|  ========================================                            |
|                                                                      |
|  Scheduler.add_request(request)                                      |
|      |                                                               |
|      +--> BlockSpaceManager.can_allocate(num_prompt_tokens)          |
|      |        |                                                      |
|      |        +--> BlockAllocator.get_num_free_blocks()              |
|      |                                                               |
|      +--> [if can_allocate] Scheduler.schedule()                     |
|                                                                      |
|                                                                      |
|  2. Prefill 阶段 (处理 prompt tokens)                                 |
|  ========================================                            |
|                                                                      |
|  ModelRunner.execute_model(seqs)                                     |
|      |                                                               |
|      +--> BlockSpaceManager.allocate(seq_id, num_prompt_tokens)      |
|      |        |                                                      |
|      |        +--> PrefixCachingBlockAllocator.allocate()            |
|      |        |        |                                             |
|      |        |        +--> hash(token_ids) → lookup cache           |
|      |        |        |        |                                    |
|      |        |        |        +--> [hit] reuse block               |
|      |        |        |        +--> [miss] allocate new block       |
|      |        |        |                                             |
|      |        |        +--> update block_table                       |
|      |        |                                                      |
|      |        +--> 返回已分配/已命中的 block 列表                     |
|      |                                                               |
|      +--> 对于 miss 的 block: 执行 prefill (计算 K/V)                 |
|      +--> 对于 hit 的 block: 跳过 prefill                            |
|      |                                                               |
|      +--> reshape_and_cache(k, v, block_table)                       |
|              将计算的 K/V 写入对应的物理 block                        |
|                                                                      |
|                                                                      |
|  3. Decode 阶段 (逐 token 生成)                                       |
|  ========================================                            |
|                                                                      |
|  for step in range(max_tokens):                                      |
|      |                                                               |
|      +--> BlockSpaceManager.append_slots(seq_id, 1)                  |
|      |        |                                                      |
|      |        +--> [最后一个 block 未满] 无需分配                     |
|      |        +--> [最后一个 block 已满] allocate new block           |
|      |        |                                                      |
|      |        +--> 返回 (physical_block_id, slot_offset)             |
|      |                                                               |
|      +--> ModelRunner 计算 attention                                 |
|      |        |                                                      |
|      |        +--> PagedAttention.forward(                           |
|      |        |        query, key_cache, value_cache,                |
|      |        |        block_table, context_lens)                    |
|      |        |        |                                             |
|      |        |        +--> paged_attention_kernel()  # CUDA        |
|      |        |                                                      |
|      +--> 写入新生成的 K/V 到对应的 block/slot                       |
|      |                                                               |
|      +--> [if EOS token] break                                      |
|                                                                      |
|                                                                      |
|  4. 序列完成, 释放资源                                                |
|  ========================================                            |
|                                                                      |
|  Scheduler.free_request(request)                                     |
|      |                                                               |
|      +--> BlockSpaceManager.free(seq_id)                             |
|               |                                                      |
|               +--> for each block: block.ref_count -= 1              |
|               +--> if ref_count == 0: BlockAllocator.free(block)     |
|                                                                      |
+======================================================================+
```

### 9.4 从 Python 到 CUDA 的调用链

```
+======================================================================+
|          Python → C++ → CUDA 调用链 (PagedAttention)                  |
+======================================================================+
|                                                                      |
|  vllm/attention/layers/attention.py                                  |
|  ========================================                            |
|  class Attention(nn.Module):                                         |
|      def forward(self, query, key, value, ...):                      |
|          ...                                                         |
|          output = torch.ops._C.paged_attention(                      |
|              query, key_cache, value_cache,                          |
|              block_tables, context_lens, ...)                        |
|          ...                                                         |
|          |                                                           |
|          v                                                           |
|  vllm/attention/ops/paged_attn.py                                    |
|  ========================================                            |
|  def paged_attention_v1(...):                                        |
|      # 选择最优的 kernel 配置                                         |
|      # 根据 head_size 和 block_size 选择模板参数                     |
|      ...                                                             |
|      torch.ops._C.paged_attention_v1(                                |
|          out, query, key_cache, value_cache,                         |
|          block_tables, context_lens,                                 |
|          num_kv_heads, scale, ...)                                   |
|      |                                                               |
|      v                                                               |
|  csrc/attention/paged_attention_v1.cu                                |
|  ========================================                            |
|  // Python binding (pybind11)                                        |
|  void paged_attention_v1(                                            |
|      torch::Tensor& out,                                             |
|      torch::Tensor& query,                                           |
|      torch::Tensor& key_cache, ...) {                                |
|                                                                      |
|      // 根据 head_size 和 dtype 选择模板实例化                       |
|      LAUNCH_KERNEL(                                                  |
|          paged_attention_kernel,                                     |
|          num_seqs, num_heads,                                        |
|          query, key_cache, value_cache,                              |
|          block_tables, context_lens,                                 |
|          scale, block_size, head_size)                               |
|  }                                                                   |
|      |                                                               |
|      v                                                               |
|  __global__ void paged_attention_kernel(...) {                       |
|      // 第 6 节详细分析的核心 CUDA kernel                             |
|  }                                                                   |
|                                                                      |
+======================================================================+
```

---

## 10. 内存效率分析

### 10.1 理论最大内存利用率

PagedAttention 的内存利用率取决于 block_size 和序列长度。最理想情况下，除最后一个 block 外所有 block 都被完全填满：

```
+======================================================================+
|            理论内存利用率分析                                           |
+======================================================================+
|                                                                      |
|  假设:                                                                |
|    block_size = 16                                                   |
|    序列长度 = L tokens                                               |
|    num_blocks = ceil(L / block_size)                                  |
|                                                                      |
|  最后 block 的利用率:                                                  |
|    最后一个 block 中的有效 token 数 = L % block_size                  |
|    如果 L 恰好是 block_size 的倍数，则利用率 = 1                      |
|    一般情况下，假设 L % block_size 在 [1, block_size] 上均匀分布       |
|    则最后一个 block 的平均利用率为 (block_size+1)/(2*block_size)       |
|    当 block_size=16: 平均利用率 = 17/32 = 53.125%                    |
|                                                                      |
|  所有 block 的总利用率:                                                |
|    total_utilization = (L - wasted_tokens) / (num_blocks * block_size)|
|                                                                      |
|    对于长序列 (L >> block_size):                                      |
|      num_blocks ≈ L / block_size                                     |
|      浪费 ≈ block_size / 2 (最后一个 block 平均浪费一半)               |
|      total_utilization ≈ (L - block_size/2) / L                      |
|                       = 1 - block_size / (2L)                        |
|                                                                      |
|    例如 L=2048, block_size=16:                                        |
|      total_utilization = 1 - 16/(2*2048) = 1 - 0.0039 = 99.61%     |
|                                                                      |
|    例如 L=256, block_size=16:                                         |
|      total_utilization = 1 - 16/(2*256) = 1 - 0.0313 = 96.88%      |
|                                                                      |
+======================================================================+
```

### 10.2 与预分配方案的对比

```
+======================================================================+
|          PagedAttention vs 预分配: 内存利用率对比                       |
+======================================================================+
|                                                                      |
|  场景: 200-token 的请求, max_model_len=8192                           |
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                                                                  ||
|  |  预分配方案:                                                      ||
|  |  ==========================================                       ||
|  |                                                                  ||
|  |  分配空间: 8192 token slots                                       ||
|  |  实际使用: 200 token slots                                        ||
|  |  利用率:   200 / 8192 = 2.44%                                     ||
|  |  浪费:     97.56%                                                 ||
|  |                                                                  ||
|  |  |实际 200|################################## 未使用 7992 #####|  ||
|  |                                                                  ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                                                                  ||
|  |  PagedAttention 方案 (block_size=16):                             ||
|  |  ==========================================                       ||
|  |                                                                  ||
|  |  分配 block: ceil(200/16) = 13 blocks                            ||
|  |  分配空间: 13 x 16 = 208 token slots                              ||
|  |  实际使用: 200 token slots                                        ||
|  |  利用率:   200 / 208 = 96.15%                                     ||
|  |  浪费:     3.85%                                                  ||
|  |                                                                  ||
|  |  |实际 200|## 8 slots 浪费|                                       ||
|  |                                                                  ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  效率提升: 96.15% / 2.44% = 39.4x                                   |
|                                                                      |
+======================================================================+
```

### 10.3 不同序列长度的利用率曲线

```
+======================================================================+
|          不同序列长度下的内存利用率                                    |
+======================================================================+
|                                                                      |
|  利用率 (%)                                                           |
|  100 |                          ******  PagedAttention                |
|      |                     ******                                    |
|   80 |                *****                                          |
|      |           *****                                               |
|   60 |      *****                                                    |
|      | *****                                                         |
|   40 |*                                                              |
|      |*                                                              |
|   20 |*    ######################################  预分配 (固定)      |
|      |*                                                              |
|    0 +----*----*----*----*----*----*----*----*--> 序列长度            |
|      0   1024 2048 3072 4096 5120 6144 7168 8192                     |
|                                                                      |
|  预分配方案在所有长度下利用率相同 (固定分配 max_seq_len),               |
|  利用率随序列长度线性增长 (因为固定分母 8192)。                        |
|                                                                      |
|  PagedAttention 在所有长度下都 > 93% (block_size=16),                  |
|  长序列接近 100%。                                                    |
|                                                                      |
+======================================================================+
```

### 10.4 实际并发吞吐量的提升

```
+======================================================================+
|          实际并发吞吐量对比 (来自 vLLM 论文的实证数据)                  |
+======================================================================+
|                                                                      |
|  实验设置:                                                            |
|    GPU: A100-80GB                                                    |
|    模型: OPT-13B (FP16, ~26 GB 权重)                                  |
|    请求混合: ShareGPT 对话数据集                                       |
|                                                                      |
|  +------------------------------------------------------------------+|
|  |                                                                  ||
|  |  指标                 | 预分配 (FasterTransformer) | PagedAttention||
|  |  --------------------|------------------------|-----------------|||
|  |  最大并发请求数        | ~40                    | ~140            |||
|  |  有效吞吐 (token/s)    | ~800                   | ~2500           |||
|  |  KV Cache 利用率      | ~35%                   | ~92%            |||
|  |  平均每请求 KV 空间    | ~1.2 GB                | ~0.3 GB         |||
|  |                                                                  ||
|  +------------------------------------------------------------------+|
|                                                                      |
|  PagedAttention 将吞吐量提升了约 3.1 倍 (2500/800)。                    |
|  这个提升几乎完全来自 KV Cache 内存利用率的提高。                       |
|                                                                      |
+======================================================================+
```

### 10.5 Block Size 对利用率的影响

```
+----------------------------------------------------------------------+
|        Block Size 对内存利用率的量化影响                                |
+----------------------------------------------------------------------+
|                                                                      |
|  block_size | 最后 block 平均浪费 | 短序列利用率 | 长序列利用率         |
|  -----------|-------------------|------------|--------------------|
|  8          | 4 slots           | 最高        | ~99.8%             |
|  16         | 8 slots           | 高          | ~99.6%             |
|  32         | 16 slots          | 中          | ~99.2%             |
|  64         | 32 slots          | 较低        | ~98.4%             |
|  128        | 64 slots          | 低          | ~96.9%             |
|                                                                      |
|  对于 L=200 的短序列:                                                 |
|                                                                      |
|  block_size=8:  ceil(200/8)x8=200, 利用率=100.0%                     |
|  block_size=16: ceil(200/16)x16=208, 利用率=96.2%                    |
|  block_size=32: ceil(200/32)x32=224, 利用率=89.3%                    |
|  block_size=64: ceil(200/64)x64=256, 利用率=78.1%                    |
|                                                                      |
|  选择 block_size=16 是在碎片和访问效率之间的最佳平衡点。               |
|                                                                      |
+----------------------------------------------------------------------+
```

### 10.6 前缀缓存对内存效率的额外提升

```
+----------------------------------------------------------------------+
|        前缀缓存带来的额外内存节省                                      |
+----------------------------------------------------------------------+
|                                                                      |
|  场景分析:                                                            |
|    100 个并发请求, 80% 共享 500 token 的 system prompt                |
|    每个请求额外有 200 token 的用户特定内容                              |
|                                                                      |
|  PagedAttention (无前缀缓存):                                        |
|    每请求: ceil(700/16) = 44 blocks = 44 MB                          |
|    总: 100 x 44 = 4,400 MB                                           |
|                                                                      |
|  PagedAttention (有前缀缓存):                                        |
|    共享 block: ceil(500/16) = 32 blocks = 32 MB (共享)                |
|    每请求独有: ceil(200/16) = 13 blocks = 13 MB                       |
|    总: 32 + 100 x 13 = 1,332 MB                                      |
|                                                                      |
|  额外节省: (4,400 - 1,332) / 4,400 = 69.7%                           |
|                                                                      |
|  这还不包括跳过 prefill 计算带来的计算节省。                            |
|  在 80% 请求共享相同系统提示词的场景中,                                  |
|  80% 的请求可以完全跳过 prefill 的 KV 计算。                            |
|                                                                      |
+----------------------------------------------------------------------+
```

### 10.7 CoW 的内存效率贡献

```
+----------------------------------------------------------------------+
|        CoW 在并行解码中的内存节省                                      |
+----------------------------------------------------------------------+
|                                                                      |
|  场景: beam search, beam_width=5, prompt=1024 tokens                  |
|        每个 beam 生成 256 个输出 token                                 |
|        block_size=16                                                  |
|                                                                      |
|  无 CoW:                                                              |
|    每 beam: ceil((1024+256)/16) = 80 blocks                          |
|    总: 5 x 80 = 400 blocks                                           |
|                                                                      |
|  有 CoW:                                                              |
|    共享前缀: ceil(1024/16) = 64 blocks                               |
|    每 beam 独有: ceil(256/16) = 16 blocks                            |
|    总: 64 + 5 x 16 = 144 blocks                                      |
|                                                                      |
|  节省: (400 - 144) / 400 = 64%                                       |
|                                                                      |
+----------------------------------------------------------------------+
```

### 10.8 综合收益总结

```
+======================================================================+
|          PagedAttention 综合收益总结                                   |
+======================================================================+
|                                                                      |
|  +------------------------------------------------------------------+|
|  |  优化手段          | 节省 (vs 预分配) | 机制                        ||
|  |  -----------------|------------------|---------------------------|||
|  |  按需分页           | 20x-40x          | 消除内部碎片               |||
|  |  前缀缓存           | 2x-5x            | 跨请求共享 KV Cache        |||
|  |  CoW Block 共享    | 2x-4x            | 并行采样/beam search 共享   |||
|  |  GPU-CPU 交换       | 允许超量订阅     | 扩展有效容量                |||
|  |  -----------------|------------------|---------------------------|||
|  |  综合               | 2x-5x 吞吐提升   | 多种机制协同作用            |||
|  +------------------------------------------------------------------+|
|                                                                      |
|  核心洞见:                                                            |
|                                                                      |
|  GPU 推理的瓶颈已从计算转移到内存。                                     |
|  PagedAttention 通过引入操作系统的分页思想,                             |
|  在几乎不增加计算开销的前提下,                                          |
|  将 KV Cache 的内存利用率从 ~30-40% 提升到 >90%。                       |
|                                                                      |
|  这使得:                                                              |
|  - 相同的 GPU 可以服务 2-5 倍多的并发请求                               |
|  - 相同数量的请求可以用更少的 GPU 服务                                  |
|  - 更大的 batch size 意味着更高的 GPU 利用率                           |
|  - 长上下文推理从"几乎不可能"变为"实际可行"                             |
|                                                                      |
+======================================================================+
```

---

## 15. 易混淆技术辨析

在 PagedAttention 的学习和实践中，以下几组概念经常被混淆。理清它们对于正确理解源码和排查问题至关重要。

### 15.1 Block Table vs Page Table

这两个概念名字相似，但作用域和存储位置不同。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Block Table vs Page Table                                │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │    Block Table（块表）       │   Page Table（页表，OS概念） │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  作用域             │  单条序列                   │  单个进程                   │
│  存储位置           │  GPU 显存（Tensor int32）    │  CPU MMU / 主存             │
│  条目含义           │  逻辑 block → 物理 block ID  │  虚拟页号 → 物理页帧号       │
│  条目数量           │  ceil(seq_len/block_size)   │  虚拟地址空间大小/页大小     │
│  未分配标记          │  -1（INVALID）              │  缺页（Page Fault 触发中断） │
│  共享方式           │  多个 Block Table 指向同一物理│  多进程页表指向同一物理页帧   │
│                    │  block（引用计数管理）         │  （Copy-on-Write）          │
│  容量               │  很小（通常 <1MB，可放入 L2） │  可能很大（多级页表）        │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**核心区别**：Block Table 是 GPU 上的一张 Tensor，在 CUDA kernel 的热循环中通过间接索引访问。Page Table 是操作系统维护的数据结构，由 CPU 的 MMU 硬件自动完成地址转换。PagedAttention 的 Block Table 本质上是在 GPU 上重新实现了一个简化的页表——没有多级页表、没有 TLB、没有缺页中断，但核心的"虚拟→物理映射"思想完全一致。

**实践要点**：Block Table 的随机访问模式决定了它在 PagedAttention kernel 中是一个潜在的瓶颈。好在 Block Table 非常小（256 序列 × 512 条目 × 4 字节 = 512 KB），完全可以放入 L2 cache。如果你在调试中发现 attention 延迟异常，可以检查 block_table 是否因为某些原因变得过大（如极端长的 max_model_len + 大量并发序列）。

### 15.2 Physical Block vs Logical Block

这是 PagedAttention 中最基础也最容易搞混的一对概念。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Physical Block vs Logical Block                            │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │   Physical Block（物理块）  │  Logical Block（逻辑块）    │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  标识               │  全局唯一的 block_id（整数） │  序列内的索引（整数）       │
│  计算方式           │  由分配器从 free list 分配   │  token_pos // block_size   │
│  物理连续性          │  不连续（分页的核心优势）     │  概念上连续（在地址空间内）  │
│  跨序列             │  可被多个序列共享             │  每序列独立                 │
│  生命周期           │  从分配到 ref_count 归零释放  │  随序列的推进而增长          │
│  类比               │  物理书架号 "3 号书架"        │  书单序号 "第 5 本书"       │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**一个具体例子**：

```
序列 A 有 100 个 token（block_size=16）:
  Logical Block 0 → Physical Block 7   (tokens 0-15)
  Logical Block 1 → Physical Block 3   (tokens 16-31)
  Logical Block 2 → Physical Block 15  (tokens 32-47)
  Logical Block 3 → Physical Block 2   (tokens 48-63)
  Logical Block 4 → Physical Block 9   (tokens 64-79)
  Logical Block 5 → Physical Block 22  (tokens 80-95)
  Logical Block 6 → Physical Block 8   (tokens 96-99, 最后4个slot)

序列 B 的 Logical Block 0 也可能指向 Physical Block 7（共享前缀）:
  Logical Block 0 → Physical Block 7   (与序列A的log0共享!)
  Logical Block 1 → Physical Block 41  (新分配的物理块)
```

**核心洞察**：logical block 是"我需要什么"，physical block 是"它实际在哪里"。这种分离使得内存分配变得极其灵活——只要 free list 里还有空闲的物理 block，就可以继续分配，不需要担心碎片问题。

### 15.3 Prefix Caching vs KV Cache Sharing (CoW)

两者都利用 block 共享减少显存占用，但机制和适用场景完全不同。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                 Prefix Caching vs KV Cache Sharing (CoW)                      │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │   Prefix Caching             │  KV Cache Sharing (CoW)  │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  共享范围           │  跨请求（跨时间）             │  同一时刻的 fork 序列间    │
│  触发时机           │  新请求的 prompt 前缀匹配      │  fork() 创建子序列时       │
│  检测方式           │  对 block 内容做哈希+Radix Tree│  浅拷贝 Block Table        │
│  典型场景           │  System prompt 复用           │  Beam search / 并行采样    │
│  生命周期           │  缓存在 Radix Tree 中         │  随父序列结束而释放        │
│                   │  LRU 淘汰不活跃的 block        │  （ref_count 管理）         │
│  是否需要相同请求    │  不需要（先后到达即可）        │  需要（必须是同时活跃的序列）│
│  配置               │  --enable-prefix-caching     │  自动生效（无需配置）       │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**可以同时使用**：一个请求的 system prompt 部分通过 Prefix Caching 命中缓存（节省 prefill 计算），而 beam search 中的多个 beam 通过 CoW 共享这些已经缓存的 block。两者是互补关系，而非替代关系。

**误区**：有人以为启用了 Prefix Caching 就等于做了 CoW。实际上 Prefix Caching 负责"之前算过的 prompt 不要再算一遍"，CoW 负责"fork 出来的序列不要复制一整份 KV Cache"。两者解决的问题不同，代码路径也不同。

### 15.4 CoW Fork vs Deep Copy

当需要创建序列的副本时，有两种策略。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       CoW Fork vs Deep Copy                                   │
├────────────────────┬────────────────────────────┬────────────────────────────┤
│      特性           │   CoW Fork（写时复制分支）   │  Deep Copy（深拷贝）        │
├────────────────────┼────────────────────────────┼────────────────────────────┤
│  内存分配           │  0（初始不分配新 block）      │  分配全新的物理 block       │
│  数据复制           │  0（初始不复制数据）          │  cudaMemcpy GPU→GPU        │
│  Block Table        │  浅拷贝（指向相同物理 block）  │  指向全新分配的物理 block   │
│  引用计数           │  共享 block 的 ref_count +1   │  新 block ref_count = 1    │
│  写入时             │  触发实际复制（CoW 开销）     │  无额外开销（已经独立）     │
│  内存效率           │  极高（共享的部分不入副本）     │  低（全部复制）             │
│  适用场景           │  Beam search, 并行采样       │  需要完全独立的序列         │
│  实现复杂度          │  较高（需要引用计数+COW逻辑） │  低（直接分配+复制）        │
└────────────────────┴────────────────────────────┴────────────────────────────┘
```

**何时 CoW Fork 不如 Deep Copy**：如果 fork 后子序列几乎立刻就要修改大部分 block（如 prompt 很短、divergence 很快），那么 CoW 的延迟触发复制反而不如一次性 Deep Copy 来得高效。但在 LLM 推理的典型场景中（beam search 有长共享前缀），CoW 几乎总是更优。

**vLLM 的实现**：`BlockSpaceManager.fork()` 只做浅拷贝 + 增加引用计数。真正的复制延迟到某个序列尝试写入被共享的 block 时才发生。在标准 decode 流程中，CoW 实际上极少触发——因为 decode 阶段只追加新 block，不会修改已有 block。

---

## 16. AI Infra 专家视角

### 16.1 性能瓶颈排查：四层决策树

PagedAttention 相关的性能问题通常表现为以下几种，按以下决策树逐层排查。

**第一层：KV Cache 碎片化（显存充足但分配失败）**

```
症状：
  - free blocks > 0，但新请求无法分配
  - vllm:gpu_cache_usage_perc 不高但报 OOM
  - 日志中出现 "Cannot allocate" 但空闲 block 计数正常

排查路径：
  1. 检查 block_size 是否过大
     → block_size=16 通常碎片率 < 1%
     → block_size=32/64 可能增加碎片
  2. 检查是否有大量短序列（< block_size）
     → 短序列的最后一个 block 利用率低
     → 如果短序列占比 > 50%，可考虑减小 block_size 到 8
  3. 检查 Prefix Caching 是否导致大量 block 被"锁住"
     → 缓存的 block ref_count > 1，无法被淘汰
     → 查看 vllm:prefix_cache_hit_rate，如果很高且碎片多：
       可能需要增大 --gpu-memory-utilization 或在低负载时重启

解决方案：
  a) 减小 block_size（如 16→8）
  b) 增大 --gpu-memory-utilization
  c) 重启服务（清空碎片化的内存池）
  d) 升级到 vLLM v1（改进了内存分配器）
```

**第二层：Block Table 索引开销（Attention 延迟异常）**

```
症状：
  - Attention kernel 耗时超出预期
  - 序列特别长（>32K tokens）时延迟非线性增长
  - nvprof/Nsight 显示 block_table 相关的 global memory load 占比高

排查路径：
  1. 检查 block size
     → block_size 越小，block_table 条目越多
     → 512K tokens / 16 = 32K 条目 vs 512K / 32 = 16K 条目
     → 但增大的 block_size 会增加内部碎片
  2. 检查是否使用了 GQA（Grouped Query Attention）
     → GQA 减小了 K/V 的 head 数
     → 较小的 K/V 更容易放入 L2 cache
     → 如果模型不支持 GQA，block 间的跳转开销更大
  3. 检查 context_lens 分布
     → 如果大多数请求都很长，可以考虑增大 block_size

解决方案：
  a) 对于极长序列场景（>32K），考虑 block_size=32
  b) 确保使用 FlashInfer 或 FlashAttention 后端
  c) 启用 FP8 KV Cache（减少 block 数据大小 → 更快加载）
```

**第三层：CoW/共享引发的引用计数问题（内存泄漏式增长）**

```
症状：
  - GPU 显存使用随时间持续增长但不释放
  - 大量请求完成后 KV Cache 使用率不下降
  - 重启后恢复正常

排查路径：
  1. 检查是否有 beam search 或 parallel sampling 的长时间运行请求
     → 子序列未正常释放导致 ref_count 不归零
  2. 检查 Prefix Caching 的 LRU 淘汰是否正常工作
     → 如果所有缓存 block 的 ref_count 都 > 1，无法淘汰
  3. 查看 vllm:gpu_blocks_free 的时序变化
     → 如果持续下降且不恢复，可能有 block 泄露

解决方案：
  a) 确认请求正常结束（客户端是否正确关闭连接）
  b) 设置合理的请求超时（--request-timeout）
  c) 升级 vLLM 版本（早期版本有已知的 block 泄露 bug）
  d) 定期重启服务（临时方案）
```

**第四层：GPU-CPU 交换瓶颈（Swap 导致延迟飙升）**

```
症状：
  - decode 延迟从 30ms 突跳到 200ms+
  - vllm:num_requests_swapped > 0
  - nvidia-smi 显示 PCIe 带宽利用率异常高

排查路径：
  1. 检查 swap 触发频率
     → 频繁 swap in/out 说明 GPU 显存长期不足
     → 不是 swap 机制的问题，是容量规划的问题
  2. 确认 --swap-space 配置是否足够
     → 默认 4GB 可能不够，建议 16-32GB
  3. 检查 PCIe 带宽是否被其他进程占用
     → NCCL 通信、其他 GPU 应用可能共享 PCIe 总线

解决方案：
  a) 增大 --swap-space
  b) 启用 KV Cache 量化（减少换出数据量）
  c) 增加 GPU 数量（根本解决显存不足）
  d) 降低 --max-num-seqs（减少并发，避免触发 swap）
```

### 16.2 A800 部署实操：Qwen-33B 双卡方案中的 PagedAttention 配置

以下是在 2xA800-80G 上部署 Qwen-33B 时，与 PagedAttention 直接相关的配置决策和数值计算。

**Qwen-33B 的 KV 结构参数**：

```
Qwen-33B 的 KV 相关参数（假设同 Qwen 系列架构）:
  num_layers:      60
  num_q_heads:     56
  num_kv_heads:    8   (GQA, group_size=7)
  head_dim:        128
  dtype:           FP16 (2 bytes)

单 token 单层的 KV 大小:
  = 2 (K+V) × 8 (KV heads) × 128 (head_dim) × 2 (bytes)
  = 4096 bytes = 4 KB

全部 60 层单 token:
  = 60 × 4 KB = 240 KB

block_size=16 的单 block 大小 (所有层):
  = 16 × 240 KB = 3,840 KB ≈ 3.75 MB
```

**显存预算（2xA800-80G, TP=2）**：

```
┌──────────────────────────────────────────────────────────────┐
│        Qwen-33B on 2xA800-80G — KV Cache 显存预算             │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  每卡总显存:      80 GB                                       │
│  模型权重 (TP=2):  33B × 2 / 2 = 33 GB/卡                     │
│  CUDA Context:    ~2 GB                                       │
│  KV Cache 可用:   80 × 0.90 - 33 - 2 = 37 GB/卡              │
│                                                              │
│  总计 KV Cache (两卡): 37 × 2 = 74 GB                         │
│                                                              │
│  每 block ≈ 3.75 MB（所有层）                                  │
│  总可用 blocks: 74 GB / 3.75 MB ≈ 19,700 blocks               │
│                                                              │
│  场景1：prompt=2048, output=256                               │
│    每请求 blocks: ceil(2304/16) = 144 blocks                  │
│    每请求 KV: 144 × 3.75 MB ≈ 540 MB                          │
│    最大并发: 19,700 / 144 ≈ 136 个请求                        │
│                                                              │
│  场景2：prompt=4096, output=512                               │
│    每请求 blocks: ceil(4608/16) = 288 blocks                  │
│    每请求 KV: 288 × 3.75 MB ≈ 1.08 GB                        │
│    最大并发: 19,700 / 288 ≈ 68 个请求                         │
│                                                              │
│  场景3：prompt=16384, output=1024（RAG 长文档）                │
│    每请求 blocks: ceil(17408/16) = 1088 blocks               │
│    每请求 KV: 1088 × 3.75 MB ≈ 4.08 GB                       │
│    最大并发: 19,700 / 1088 ≈ 18 个请求                        │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

**PagedAttention 专属配置**：

```bash
python -m vllm.entrypoints.openai.api_server \
    --model /models/Qwen-33B-Chat \
    --tensor-parallel-size 2 \
    --dtype bfloat16 \
    \
    # ---- PagedAttention 核心参数 ---- \
    --block-size 16 \
    --max-model-len 32768 \
    --max-num-seqs 64 \
    --gpu-memory-utilization 0.90 \
    \
    # ---- 前缀缓存 ---- \
    --enable-prefix-caching \
    \
    # ---- Swap 空间 ---- \
    --swap-space 16 \
    \
    # ---- 连续批处理（配套） ---- \
    --max-num-batched-tokens 8192 \
    --enable-chunked-prefill \
    \
    --host 0.0.0.0 --port 8000 --enable-metrics
```

**block_size 选择的计算依据**：

```
block_size 对 Qwen-33B 的影响量化:

┌────────────┬──────────────┬──────────────┬──────────────┬──────────────┐
│ block_size │ 内部碎片(最坏)│ block数/4K req│ BlockTable   │ Attention    │
│            │              │              │ 大小(64seq)  │ 效率(相对)   │
├────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ 8          │ 7 slots      │ 288          │ 256 KB       │ ~95%         │
│ 16 (默认)   │ 15 slots     │ 144          │ 128 KB       │ 100% (基准)  │
│ 32         │ 31 slots     │ 72           │ 64 KB        │ ~105%        │
│ 64         │ 63 slots     │ 36           │ 32 KB        │ ~108%        │
└────────────┴──────────────┴──────────────┴──────────────┴──────────────┘

结论: block_size=16 在碎片控制、BlockTable 大小和 kernel 效率之间达到最佳平衡。
      对于 Qwen-33B 在 A800 上的部署，无需调整此参数。
      仅在两种情况下考虑调整:
        - 绝大多数请求 < 50 tokens → block_size=8 减少碎片
        - 绝大多数请求 > 32K tokens → block_size=32 减少 block 跳转开销
```

**Prefix Caching 命中率预估**：

```
典型场景：Claude Code 工具调用 + RAG

假设 100 个请求共享相同的 system prompt (500 tokens):
  system_prompt: ceil(500/16) = 32 blocks

无前缀缓存:
  总 blocks = 100 × (32 + 13) = 4,500 blocks (假设用户部分 200 tokens ≈ 13 blocks)

有前缀缓存:
  共享 blocks = 32 (只存一份)
  独有 blocks = 100 × 13 = 1,300
  总 blocks = 1,332
  节省: (4500 - 1332) / 4500 = 70.4%

不仅如此，32 个共享 block 的 prefill 计算只需做一次!
prefill 节省: 500 tokens × 0.03ms/token × 99 = 1,485ms ≈ 1.5 秒 (累积)
```

**验证命令**：

```bash
# 1. 查看 block 分配情况
curl http://localhost:8000/metrics | grep -E "gpu_blocks|gpu_cache"

# 2. 查看前缀缓存命中率
curl http://localhost:8000/metrics | grep prefix_cache

# 3. 查看是否有请求被 swap
curl http://localhost:8000/metrics | grep swapped

# 4. 查看 block 级别的内存使用
# 在 vLLM 日志中设置 VLLM_LOGGING_LEVEL=DEBUG 可以看到详细分配日志
VLLM_LOGGING_LEVEL=DEBUG python -m vllm.entrypoints.openai.api_server ...
# 观察日志中 "allocated block" 和 "freed block" 的记录
```

---

## 附录 A: 关键公式速查

```
=======================================================================
                      关键公式速查
=======================================================================

1. KV Cache 空间公式:
   Size = 2 x seq_len x num_layers x num_kv_heads x head_dim x dtype_bytes

2. 单 Block 大小 (所有层):
   BlockSize = block_size x num_kv_heads x head_dim x dtype_bytes x 2 x num_layers

3. Block Table 大小:
   TableSize = max_num_seqs x ceil(max_model_len / block_size) x sizeof(int32)

4. 最大 Block 数 per 序列:
   max_blocks = ceil(max_model_len / block_size)

5. 内存利用率 (PagedAttention):
   Utilization = L / (ceil(L / block_size) x block_size)
   对于 L >> block_size: ≈ 1 - block_size / (2L)

6. 内存利用率 (预分配):
   Utilization = L / max_model_len

7. 缩放因子:
   scale = 1.0 / sqrt(head_dim)

8. 在线 Softmax:
   m_new = max(m_old, s_new)
   w_new = w_old x exp(m_old - m_new) + exp(s_new - m_new)
   o_new = (o_old x w_old x exp(m_old - m_new) + exp(s_new - m_new) x v_new) / w_new

9. CoW 节省比例:
   Saving = 1 - (shared_blocks + n_beams x unique_blocks_per_beam)
                / (n_beams x total_blocks_per_beam)

10. 前缀缓存命中节省:
    Saving = (num_hit_blocks x BlockSize) / total_kv_cache
=======================================================================
```

---

## 附录 B: 扩展阅读与引用

```
=======================================================================
                      扩展阅读与引用
=======================================================================

1. vLLM 原始论文:
   "Efficient Memory Management for Large Language Model Serving with PagedAttention"
   Kwon et al., SOSP 2023
   arXiv: https://arxiv.org/abs/2309.06180

2. vLLM GitHub 仓库:
   https://github.com/vllm-project/vllm

3. FlashAttention 论文 (PagedAttention kernel 的灵感来源之一):
   "FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness"
   Dao et al., NeurIPS 2022
   arXiv: https://arxiv.org/abs/2205.14135

4. 在线 Softmax 算法:
   "Online normalizer calculation for softmax"
   Milakov & Gimelshein, 2018
   arXiv: https://arxiv.org/abs/1805.02867

5. GQA (Grouped Query Attention):
   "GQA: Training Generalized Multi-Query Transformer Models from Multi-Head Checkpoints"
   Ainslie et al., EMNLP 2023
   arXiv: https://arxiv.org/abs/2305.13245

6. 操作系统虚拟内存经典:
   "Operating Systems: Three Easy Pieces"
   Arpaci-Dusseau & Arpaci-Dusseau
   Chapter 13-22: Address Spaces, Paging, Swapping
   https://pages.cs.wisc.edu/~remzi/OSTEP/

7. Prefix Caching 相关工作:
   "SGLang: Efficient Execution of Structured Language Model Programs"
   Zheng et al., NeurIPS 2024
   (RadixAttention and prefix caching in SGLang)

8. Splitwise (GPU-CPU 分离的 KV Cache):
   "Splitwise: Efficient Generative LLM Inference Using Phase Splitting"
   Patel et al., ISCA 2024
   arXiv: https://arxiv.org/abs/2311.18677
=======================================================================
```

---

*本文档基于 vLLM v0.x 和 v1.x 的源码分析，以及原始 PagedAttention 论文 (SOSP 2023) 的详细解读。所有代码片段均为概念性伪代码或经过简化的源码摘录，具体实现细节请参考 vLLM 官方仓库。*
