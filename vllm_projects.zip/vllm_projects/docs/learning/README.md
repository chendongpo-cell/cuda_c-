# AI Infra 全链路学习文档

> **学习目标**：吃透 AI Infra 全链路原理，适配曙光本地大模型开发工作。
> **策略**：按需取舍，优先掌握能直接落地干活的内容。
> **环境**：8×A800 80GB | Python 3.10 | PyTorch 2.5.1+cu124 | CUDA 12.4

---

## 一、AI Infra 是什么

AI Infra（AI Infrastructure，AI 基础设施）是支撑大模型训练、推理、部署全生命周期的底层技术栈。它不等于运维，也不等于写模型代码，而是连接**硬件算力**和**上层应用**之间的中间层。

```
┌─────────────────────────────────────────────────────┐
│                    上层应用层                         │
│    ChatBot / RAG / Agent / Code Assistant / ...     │
├─────────────────────────────────────────────────────┤
│                    模型层                            │
│    DeepSeek / Qwen / LLaMA / GPT / Claude / ...     │
├─────────────────────────────────────────────────────┤
│              ★ AI Infra（你在学的）                   │
│  ┌──────────┬──────────┬──────────┬──────────────┐  │
│  │ 方向 A   │ 方向 B   │ 方向 C   │   方向 D     │  │
│  │Kernel开发│推理引擎  │分布式训练│  算力集群    │  │
│  │CUDA/Triton│vLLM/TRT │Megatron │ K8s/Slurm    │  │
│  │算子优化  │批调度/KV │DeepSpeed │ 监控/存储    │  │
│  └──────────┴──────────┴──────────┴──────────────┘  │
├─────────────────────────────────────────────────────┤
│                    硬件层                            │
│   GPU (A800/H100/DCU) / NVLink / InfiniBand / ...   │
└─────────────────────────────────────────────────────┘
```

AI Infra 工程师的核心价值：让模型在有限的硬件上**跑得快、跑得稳、跑得省**。

---

## 二、四个方向全景图

### 方向 A：算子 Kernel 开发

**做什么**：写 CUDA/Triton 代码，优化单个算子的性能（矩阵乘法、Attention、LayerNorm 等）。

**典型工作**：
- 手写 CUDA kernel 让 GEMM 在 A800 上跑满 Tensor Core
- 用 Triton 给公司内部的 MoE 模型写自定义 routing 算子
- 把 CUDA 算子移植到 DCU（国产加速卡）的 HIP 平台

**核心技能**：CUDA C++、PTX/SASS 汇编阅读、Triton DSL、CUTLASS、GPU 微架构、rocBLAS/hipCUB

**难度**：⭐⭐⭐⭐⭐（最高，需要同时懂硬件和数学）

**产出**：高性能算子库、模型推理加速 20%-200%

---

### 方向 B：推理引擎开发 ★ 你的核心方向

**做什么**：构建/定制/优化大模型推理服务，让模型部署高效稳定。

**典型工作**：
- 用 vLLM 部署 DeepSeek-67B，调参优化吞吐和延迟
- 读 vLLM 源码理解 Continuous Batching + PagedAttention
- 对接 Claude Code 搭建本地 RAG 推理服务
- 量化模型（GPTQ/AWQ）减少显存占用

**核心技能**：vLLM、SGLang、TensorRT-LLM、Triton Inference Server、量化、KV Cache、批调度

**难度**：⭐⭐⭐⭐（需要懂模型结构 + 系统优化 + GPU 显存管理）

**产出**：高性能推理服务、RAG 管线、模型部署方案

---

### 方向 C：分布式训练框架

**做什么**：构建大规模分布式训练系统，让千卡集群高效训练千亿参数模型。

**典型工作**：
- 用 Megatron-LM + DeepSpeed 在 1000 张 A800 上训练 175B 模型
- 调优 ZeRO-3 分片策略解决 OOM 问题
- 排查 3D 并行（TP+PP+DP）的通信瓶颈

**核心技能**：Megatron-LM、DeepSpeed ZeRO、FSDP、NCCL、梯度累积、混合精度

**难度**：⭐⭐⭐⭐⭐（需要分布式系统 + 并行算法 + 通信优化）

**产出**：大规模训练方案、分布式训练加速

---

### 方向 D：算力集群 MLOps

**做什么**：管理 GPU 集群的调度、监控、存储、网络，让算力资源高效利用。

**典型工作**：
- 搭建 K8s + GPU Operator 管理 100+ 节点集群
- 配置 Slurm 队列策略实现多团队算力隔离
- 调优 InfiniBand RDMA 网络，降低多机通信延迟

**核心技能**：Kubernetes、Slurm、Docker、Prometheus+Grafana、InfiniBand、NFS/Lustre

**难度**：⭐⭐⭐（运维向，但规模大时复杂度急剧上升）

**产出**：集群管理方案、监控告警系统、资源调度策略

---

## 三、四阶段学习路线图

```
阶段 1：通用计算机基础（按需选择性学）
  ├── C++ 基础（看懂 vLLM/CUDA 源码）
  ├── 操作系统（内存、进程、IO）
  ├── 网络基础（TCP/IP、RDMA）
  └── Python 基础（脚本、模型调用）
        ↓
阶段 2：AI Infra 通用底层技术（全部必学）
  ├── 深度学习基础 + PyTorch 实操
  ├── Transformer 完整结构
  ├── 训练基础概念（梯度、反向传播）
  ├── CUDA 基础编程
  └── SIMT 并行硬件模型
        ↓
阶段 3：四大方向按需深入
  ├── 方向 A：算子 Kernel 开发
  ├── 方向 B：推理引擎开发 ★ 主攻
  ├── 方向 C：分布式训练框架
  └── 方向 D：算力集群 MLOps
        ↓
阶段 4：实战项目
  ├── vLLM 源码精读系列（必学）
  └── 动手实验（部署、RAG、自定义算子）
```

---

## 四、文档阅读指南

### 标注说明

| 标注 | 含义 |
|------|------|
| 🔴 **必学** | 与日常工作直接相关，必须深入掌握 |
| 🟡 **了解** | 看懂原理和代码即可，不用动手实现 |
| ⚪ **选读** | 扩展视野，有兴趣再看 |

### 不同角色的推荐路径

**推理部署工程师（你）**：
```
阶段1（必学部分）→ 阶段2（全量）→ 阶段3方向B（深入）→ 阶段4（vLLM源码+动手实验）
                                    → 阶段3方向A/C/D（了解即可）
```

**算子开发工程师**：
```
阶段1（必学部分）→ 阶段2（全量）→ 阶段3方向A（深入）→ 阶段4动手实验
                                    → 阶段3方向B（了解）
```

**分布式训练工程师**：
```
阶段1（必学部分）→ 阶段2（全量）→ 阶段3方向C（深入）→ 阶段4动手实验
```

**MLOps 工程师**：
```
阶段1（必学部分）→ 阶段2（全量）→ 阶段3方向D（深入）
```

---

## 五、学习建议

### 原则

1. **不求速成**：AI Infra 的深度决定了它不可能 3 个月速成，给自己 1-2 年持续积累
2. **先广后深**：先建立全景图，知道每个方向做什么、解决什么问题，再按需深入
3. **以教代学**：学完一个主题试着写文档或给别人讲一遍，暴露理解盲区
4. **源码驱动**：文档+原理为辅，源码为主。vLLM、DeepSpeed、Megatron 的源码是最好的教材
5. **工作中验证**：学到一个优化技巧，立刻在你本地的 33B/67B 模型上试，看指标变化

### 工具清单

| 类别 | 工具 | 用途 |
|------|------|------|
| 推理引擎 | vLLM, SGLang | 核心推理框架，源码必读 |
| 推理优化 | TensorRT-LLM | NVIDIA 官方推理优化 |
| 量化 | GPTQ, AWQ, bitsandbytes | 模型量化压缩 |
| 微调 | LLaMA-Factory, Axolotl | 高效的微调框架 |
| 分布式 | DeepSpeed, Megatron-LM | 分布式训练 |
| Benchmark | lm-eval, vLLM benchmark | 模型评估和压测 |
| 容器 | Docker, nvidia-container-toolkit | 环境标准化 |
| 监控 | DCGM, Prometheus, Grafana | GPU 和服务监控 |
| CUDA 开发 | Nsight Systems, Nsight Compute | GPU profiling |
| 算子开发 | Triton, CUTLASS | 高性能算子编写 |

---

## 六、目录结构

```
docs/learning/
│
├── README.md                            ← 本文件
│
├── stage1-cs-basics/                    ← 阶段 1：通用计算机基础
│   ├── cpp-for-source-reading.md
│   ├── os-memory-process.md
│   ├── networking.md
│   └── python-essentials.md
│
├── stage2-ai-infra-foundations/         ← 阶段 2：AI Infra 底层技术
│   ├── deep-learning-basics.md
│   ├── pytorch-transformer.md
│   ├── cuda-programming.md
│   └── simt-parallel-model.md
│
├── stage3-direction-A-kernel/           ← 方向 A：算子 Kernel 开发
│   ├── cuda-kernel-deep-dive.md
│   ├── cutlass-triton-kernel.md
│   ├── attention-kernel-optimize.md
│   └── dcu-hip-kernel.md
│
├── stage3-direction-B-inference/        ← 方向 B：推理引擎开发 ★
│   ├── vllm-architecture.md
│   ├── continuous-batching.md
│   ├── paged-attention-deep.md
│   ├── kv-cache-optimization.md
│   ├── quantization-inference.md
│   ├── triton-inference-server.md
│   ├── tensorrt-llm.md
│   ├── scheduling-strategies.md
│   └── speculative-decoding.md
│
├── stage3-direction-C-training/         ← 方向 C：分布式训练框架
│   ├── distributed-training-basics.md
│   ├── megatron-lm-deep-dive.md
│   ├── deepspeed-zero.md
│   ├── fsdp-torch-distributed.md
│   └── pipeline-parallelism.md
│
├── stage3-direction-D-mlops/            ← 方向 D：算力集群 MLOps
│   ├── k8s-gpu-orchestration.md
│   ├── slurm-hpc-scheduling.md
│   ├── monitoring-observability.md
│   ├── storage-model-distribution.md
│   └── multi-tenancy-networking.md
│
└── stage4-projects/                     ← 阶段 4：实战项目
    ├── vllm-source-reading/
    │   ├── 01-entrypoint-startup.md
    │   ├── 02-scheduler-core.md
    │   ├── 03-block-manager.md
    │   ├── 04-model-loader.md
    │   ├── 05-worker-execution.md
    │   └── 06-practical-tuning.md
    │
    └── hands-on-labs/
        ├── lab01-deploy-33b-optimize.md
        ├── lab02-rag-claude-code.md
        └── lab03-writing-custom-kernel.md
```

---

## 七、学习进度跟踪

| 阶段 | 文档 | 状态 | 完成日期 |
|------|------|------|----------|
| 阶段1 | cpp-for-source-reading.md | 📝 待写 | |
| 阶段1 | os-memory-process.md | 📝 待写 | |
| 阶段1 | networking.md | 📝 待写 | |
| 阶段1 | python-essentials.md | 📝 待写 | |
| 阶段2 | deep-learning-basics.md | 📝 待写 | |
| 阶段2 | pytorch-transformer.md | 📝 待写 | |
| 阶段2 | cuda-programming.md | 📝 待写 | |
| 阶段2 | simt-parallel-model.md | 📝 待写 | |
| 方向A | ... | 📝 待写 | |
| 方向B | ... | 📝 待写 | |
| 方向C | ... | 📝 待写 | |
| 方向D | ... | 📝 待写 | |
| **阶段4** | **vllm-source-reading/** | | |
| 阶段4 | 01-entrypoint-startup.md | ✅ 已完成 | 2026-07-20 |
| 阶段4 | 02-scheduler-core.md | ✅ 已完成 | 2026-07-20 |
| 阶段4 | 03-block-manager.md | ✅ 已完成 | 2026-07-20 |
| 阶段4 | 04-model-loader.md | ✅ 已完成 | 2026-07-20 |
| 阶段4 | 05-worker-execution.md | ✅ 已完成 | 2026-07-20 |
| 阶段4 | 06-practical-tuning.md | ✅ 已完成 | 2026-07-20 |
| **阶段4** | **hands-on-labs/** | | |
| 阶段4 | lab01-deploy-33b-optimize.md | ✅ 已完成 | 2026-07-20 |
| 阶段4 | lab02-rag-claude-code.md | ✅ 已完成 | 2026-07-20 |
| 阶段4 | lab03-writing-custom-kernel.md | ✅ 已完成 | 2026-07-20 |

---

## 八、辅助文档

| 文档 | 说明 |
|------|------|
| [术语速查表](../terminology-glossary.md) | AI Infra 全链路术语速查，涵盖所有核心概念的中文类比解释 |
| [端到端推理链路追踪](../end-to-end-inference-trace.md) | 从用户请求到 token 返回的全链路时间线，串联所有阶段学习内容 |
