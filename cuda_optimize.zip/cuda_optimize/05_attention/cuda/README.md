﻿# 05_attention/cuda/ — Attention 相关算子的 C++/CUDA 实现

> **对应 Python 版**：[05_attention/python/](../05_attention/python/) + [06_flash_attention/](../06_flash_attention/)
>
> **定位**：用 CUDA C++ 重写 Python 教学版里的 attention 相关代码，让你有机会练 C++/CUDA，对比两种实现的差异。
>
> **前置**：学完 [docs/02_cuda_basics.md](../docs/02_cuda_basics.md) + [03_cuda_kernels/](../03_cuda_kernels/)。

---

## 文件对应关系

| C++/CUDA 文件 | 对应 Python 脚本 | 教学重点 |
|--------------|----------------|---------|
| [attention.cu](attention.cu) | [05_attention/python/standard_attention.py](../05_attention/python/standard_attention.py) | 标准 attention 的 CUDA 实现：QK^T、softmax、AV |
| [kv_cache.cu](kv_cache.cu) | [05_attention/python/kv_cache_demo.py](../05_attention/python/kv_cache_demo.py) | KV Cache 的 GPU 内存管理与 append/read |
| [flash_attention.cu](flash_attention.cu) | [06_flash_attention/flash_attention_triton.py](../06_flash_attention/flash_attention_triton.py) | FlashAttention：IO-aware tiling + online softmax |

---

## 编译运行

```bash
cd 05_attention/cuda
mkdir build && cd build
cmake .. -DCMAKE_CUDA_ARCHITECTURES="80"   # A100=80, H100=90, 按你的 GPU 调
make -j4

./attention_demo
./kv_cache_demo
./flash_attention_demo
```

---

## Python vs C++ 实现对比要点

| 维度 | Python (PyTorch) | C++/CUDA |
|------|-----------------|----------|
| attention | `torch.matmul(Q, K.T)` 一行 | 手写 kernel，要管 shared memory、warp |
| KV Cache | `torch.cat([k_cache, new_k])` | 手动管理 GPU 显存，append kernel |
| 调试 | `print(tensor)` | `cudaMemcpy` 到 CPU 再 print |
| 性能 | PyTorch 已优化 | 你写的可能更慢（除非用 TensorCore） |
| 代码量 | 几十行 | 几百行 |

**核心收获**：理解"PyTorch 一行代码底下到底发生了什么"。
