﻿/*
 * attention.cu — 标准 Attention 的 CUDA 实现
 *
 * 对应 Python 版: 05_attention/python/standard_attention.py
 *
 * Python 里一行搞定:
 *     scores = Q @ K.transpose(-2, -1) / sqrt(d)
 *     attn = softmax(scores)
 *     out  = attn @ V
 *
 * C++/CUDA 里要手写:
 *     1. QK^T 的 matmul kernel (带 scale)
 *     2. row-wise softmax kernel (数值稳定版)
 *     3. attn @ V 的 matmul kernel
 *
 * 教学重点:
 *     - grid/block 怎么映射到 attention 的二维结构
 *     - shared memory tiling (但本文件用简化版, 不分块)
 *     - softmax 的数值稳定 (减最大值)
 *
 * 编译: nvcc -std=c++17 -O2 attention.cu -o attention_demo
 * 运行: ./attention_demo
 *
 * 配套文档: docs/04_attention_kv_cache.md
 */

#include <cuda_runtime.h>
#include <cstdio>
#include <cmath>
#include <cstdlib>

// ============================================================
// CUDA 错误检查宏 (每个 CUDA API 调用后都检查)
// ============================================================
// Python 程序员注意: C++ 没有 try/except 自动捕获, 要手动检查
// 这个宏的作用: 如果 CUDA 调用失败, 打印错误并退出
#define CUDA_CHECK(call)                                                \
    do {                                                                \
        cudaError_t err = (call);                                       \
        if (err != cudaSuccess) {                                       \
            fprintf(stderr, "CUDA error %s:%d: %s\n",                   \
                    __FILE__, __LINE__, cudaGetErrorString(err));       \
            exit(EXIT_FAILURE);                                         \
        }                                                               \
    } while (0)


// ============================================================
// Kernel 1: QK^T (计算 attention scores)
// ============================================================
// 数学: scores[i][j] = sum_d Q[i][d] * K[j][d] / sqrt(d)
//
// 线程映射: 一个线程算 scores[i][j] 的一个元素
//   grid: (batch, num_heads, ceil(M/BM) * ceil(N/BN))
//   block: (BM, BN)  -- 比如 16x16
//
// 简化: 不用 shared memory tiling (真实生产会用)
//       每个线程直接从 global memory 读 Q 和 K
//       代价: 重复读, 性能差, 但逻辑清晰
//
// 参数:
//   Q, K: [batch, num_heads, seq_len, head_dim] 的 GPU 指针
//   scores: [batch, num_heads, seq_len, seq_len] 输出
//   scale: 1/sqrt(head_dim)
__global__ void qk_kernel(
    const float* __restrict__ Q,    // __restrict__ 告诉编译器: 这个指针指向的内存不会被其他指针修改, 可以优化
    const float* __restrict__ K,
    float* __restrict__ scores,
    int batch, int num_heads, int seq_len, int head_dim,
    float scale)
{
    // 1. 算当前线程对应 scores 矩阵的哪个元素 (i, j)
    int i = blockIdx.x * blockDim.x + threadIdx.x;  // 行索引 (query 维度)
    int j = blockIdx.y * blockDim.y + threadIdx.y;  // 列索引 (key 维度)

    // 2. 越界检查 (Python 里 numpy 自动检查, C++ 要手动)
    if (i >= seq_len || j >= seq_len) return;

    // 3. 算 batch/head 偏移
    //    Q 在内存里是 [batch, num_heads, seq_len, head_dim] 连续存储
    //    所以 Q[batch][head][i][d] 的地址偏移 = ((batch * num_heads + head) * seq_len + i) * head_dim + d
    int batch_idx = blockIdx.z / num_heads;
    int head_idx  = blockIdx.z % num_heads;
    int base = (batch_idx * num_heads + head_idx) * seq_len;

    // 4. 点积: scores[i][j] = sum_d Q[i][d] * K[j][d]
    float sum = 0.0f;
    for (int d = 0; d < head_dim; ++d) {
        float q = Q[(base + i) * head_dim + d];
        float k = K[(base + j) * head_dim + d];
        sum += q * k;
    }

    // 5. scale (除以 sqrt(head_dim))
    scores[(base + i) * seq_len + j] = sum * scale;
}


// ============================================================
// Kernel 2: Row-wise Softmax (数值稳定版)
// ============================================================
// 数学: softmax(x)[i] = exp(x[i] - max(x)) / sum(exp(x[j] - max(x)))
//
// 为什么减最大值: 防止 exp 溢出. 比如 x=[1000, 1001], 不减 max 直接 exp(1000)=inf
//
// 线程映射: 一个 block 处理一行 (seq_len 个元素)
//   用 shared memory 做线程间通信 (求 max 和 sum)
//
// 简化: 用单线程处理一行 (性能差但清晰). 真实实现会用 warp shuffle
__global__ void softmax_kernel(
    float* __restrict__ scores,     // in-place 修改
    int batch, int num_heads, int seq_len)
{
    int row = blockIdx.x;   // 哪一行 (对应 scores 的某一行)
    if (row >= batch * num_heads * seq_len) return;

    // 1. 求 row 这一行的最大值
    float max_val = -1e30f;
    for (int j = 0; j < seq_len; ++j) {
        float v = scores[row * seq_len + j];
        if (v > max_val) max_val = v;
    }

    // 2. exp(x - max) 并求和
    float sum = 0.0f;
    for (int j = 0; j < seq_len; ++j) {
        float e = expf(scores[row * seq_len + j] - max_val);
        scores[row * seq_len + j] = e;   // 暂存 exp 值
        sum += e;
    }

    // 3. 归一化
    float inv_sum = 1.0f / sum;
    for (int j = 0; j < seq_len; ++j) {
        scores[row * seq_len + j] *= inv_sum;
    }
}


// ============================================================
// Kernel 3: Attn @ V (计算最终输出)
// ============================================================
// 数学: out[i][d] = sum_j attn[i][j] * V[j][d]
//
// 线程映射: 一个线程算 out[i][d] 的一个元素
__global__ void av_kernel(
    const float* __restrict__ attn,
    const float* __restrict__ V,
    float* __restrict__ out,
    int batch, int num_heads, int seq_len, int head_dim)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;  // seq 维度
    int d = blockIdx.y * blockDim.y + threadIdx.y;  // head_dim 维度

    if (i >= seq_len || d >= head_dim) return;

    int batch_idx = blockIdx.z / num_heads;
    int head_idx  = blockIdx.z % num_heads;
    int base = (batch_idx * num_heads + head_idx) * seq_len;

    // out[i][d] = sum_j attn[i][j] * V[j][d]
    float sum = 0.0f;
    for (int j = 0; j < seq_len; ++j) {
        float a = attn[(base + i) * seq_len + j];
        float v = V[(base + j) * head_dim + d];
        sum += a * v;
    }

    out[(base + i) * head_dim + d] = sum;
}


// ============================================================
// 主函数: 串联三个 kernel
// ============================================================
int main()
{
    // ===== 1. 设置参数 =====
    const int batch = 2;
    const int num_heads = 4;
    const int seq_len = 16;
    const int head_dim = 32;
    const float scale = 1.0f / sqrtf((float)head_dim);

    printf("=== Attention CUDA Demo ===\n");
    printf("batch=%d, num_heads=%d, seq_len=%d, head_dim=%d\n",
           batch, num_heads, seq_len, head_dim);

    // ===== 2. 分配 host 内存并初始化 =====
    // Python 类比: Q = torch.randn(batch, num_heads, seq_len, head_dim)
    size_t qkv_size = batch * num_heads * seq_len * head_dim * sizeof(float);
    size_t scores_size = batch * num_heads * seq_len * seq_len * sizeof(float);

    float* h_Q = (float*)malloc(qkv_size);
    float* h_K = (float*)malloc(qkv_size);
    float* h_V = (float*)malloc(qkv_size);
    float* h_out = (float*)malloc(qkv_size);

    // 用随机值初始化 (简化: 不用真随机, 用固定模式方便验证)
    for (int i = 0; i < batch * num_heads * seq_len * head_dim; ++i) {
        h_Q[i] = 0.01f * (i % 7);
        h_K[i] = 0.01f * (i % 5);
        h_V[i] = 0.01f * (i % 3);
    }

    // ===== 3. 分配 device 内存 =====
    // Python 类比: Q = Q.cuda()
    float *d_Q, *d_K, *d_V, *d_scores, *d_out;
    CUDA_CHECK(cudaMalloc(&d_Q, qkv_size));
    CUDA_CHECK(cudaMalloc(&d_K, qkv_size));
    CUDA_CHECK(cudaMalloc(&d_V, qkv_size));
    CUDA_CHECK(cudaMalloc(&d_scores, scores_size));
    CUDA_CHECK(cudaMalloc(&d_out, qkv_size));

    // ===== 4. 拷贝数据到 GPU =====
    // Python 类比: 隐式发生在 .cuda() 调用时
    CUDA_CHECK(cudaMemcpy(d_Q, h_Q, qkv_size, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_K, h_K, qkv_size, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_V, h_V, qkv_size, cudaMemcpyHostToDevice));

    // ===== 5. 启动 kernel =====
    // block 维度: 16x16 = 256 个线程 (CUDA 经验值, GPU 喜欢这个数)
    dim3 block(16, 16, 1);
    // grid 维度: 覆盖所有 (seq, head_dim) + batch*heads
    dim3 qk_grid((seq_len + 15) / 16, (seq_len + 15) / 16, batch * num_heads);
    dim3 av_grid((seq_len + 15) / 16, (head_dim + 15) / 16, batch * num_heads);

    // Kernel 1: QK^T
    qk_kernel<<<qk_grid, block>>>(d_Q, d_K, d_scores,
                                   batch, num_heads, seq_len, head_dim, scale);
    CUDA_CHECK(cudaGetLastError());

    // Kernel 2: Softmax (一行一个 block)
    softmax_kernel<<<batch * num_heads * seq_len, 1>>>(
        d_scores, batch, num_heads, seq_len);
    CUDA_CHECK(cudaGetLastError());

    // Kernel 3: Attn @ V
    av_kernel<<<av_grid, block>>>(d_scores, d_V, d_out,
                                   batch, num_heads, seq_len, head_dim);
    CUDA_CHECK(cudaGetLastError());

    // ===== 6. 等待 GPU 完成 + 拷回结果 =====
    // Python 类比: torch.cuda.synchronize() + out.cpu()
    CUDA_CHECK(cudaDeviceSynchronize());
    CUDA_CHECK(cudaMemcpy(h_out, d_out, qkv_size, cudaMemcpyDeviceToHost));

    // ===== 7. 打印部分结果验证 =====
    printf("\nOutput[0][0][0][:8] = ");
    for (int d = 0; d < 8; ++d) {
        printf("%.4f ", h_out[d]);
    }
    printf("\n");

    // ===== 8. 清理 (C++ 没有垃圾回收, 必须手动) =====
    cudaFree(d_Q);
    cudaFree(d_K);
    cudaFree(d_V);
    cudaFree(d_scores);
    cudaFree(d_out);
    free(h_Q);
    free(h_K);
    free(h_V);
    free(h_out);

    printf("\nAttention kernel 完成.\n");
    printf("对比 Python 版: 05_attention/python/standard_attention.py\n");
    return 0;
}

/*
 * 编译运行:
 *   nvcc -std=c++17 -O2 attention.cu -o attention_demo
 *   ./attention_demo
 *
 * 学习建议:
 *   1. 先读懂 Python 版 standard_attention.py
 *   2. 对照本文件, 理解每个 kernel 对应 Python 的哪一步
 *   3. 改 block 大小 (比如 32x32), 观察性能变化
 *   4. 加 shared memory tiling (参考 03_cuda_kernels/matmul.cu)
 *
 * 性能对比 (粗略):
 *   这个简化版 ~比 PyTorch 慢 5-10x (没用 shared memory)
 *   优化后 (tiling + TensorCore) 能接近 cuBLAS
 */
