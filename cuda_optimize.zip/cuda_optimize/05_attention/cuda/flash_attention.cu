﻿/*
 * flash_attention.cu — FlashAttention 前向 (简化教学版)
 *
 * 对应 Python 版: 06_flash_attention/flash_attention_triton.py
 *
 * FlashAttention 的核心思想:
 *     朴素 attention: 先算完整 QK^T [M,N], softmax, 再 @ V
 *     问题: QK^T 占内存大 (M*N), 要反复读写 HBM
 *
 *     FlashAttention: 分块算, 用 shared memory 中间结果
 *     - Q, K, V 切成块
 *     - 每块算部分 scores, 在 shared memory 里做 softmax
 *     - 用 "online softmax" 数学技巧, 不需要看全部 scores 就能归一化
 *
 * Online softmax 数学:
 *     传统: softmax(x)[i] = exp(x[i] - max(x)) / sum(exp(x[j] - max(x)))
 *     问题: 要先看完所有 x 才知道 max 和 sum
 *
 *     Online: 分批处理, 维护 running max m 和 running sum l
 *     看到新的一批 x_new:
 *       m_new = max(m_old, max(x_new))
 *       l_new = l_old * exp(m_old - m_new) + sum(exp(x_new - m_new))
 *       已存的 exp 值要 rescale: e_old *= exp(m_old - m_new)
 *
 * 教学重点:
 *     - 分块 (tiling) 思想
 *     - online softmax 数学
 *     - shared memory 中间结果
 *     - 减少 HBM 访问 = 加速
 *
 * 注意: 这是极简版, 只处理单头单 batch, head_dim 小
 *       真实 FlashAttention (Tri Dao 的实现) 复杂得多
 *
 * 编译: nvcc -std=c++17 -O2 flash_attention.cu -o flash_attention_demo
 * 运行: ./flash_attention_demo
 *
 * 配套文档: docs/09_flash_attention.md
 */

#include <cuda_runtime.h>
#include <cstdio>
#include <cmath>
#include <cstdlib>

#define CUDA_CHECK(call)                                                \
    do {                                                                \
        cudaError_t err = (call);                                       \
        if (err != cudaSuccess) {                                       \
            fprintf(stderr, "CUDA error %s:%d: %s\n",                   \
                    __FILE__, __LINE__, cudaGetErrorString(err));       \
            exit(EXIT_FAILURE);                                         \
        }                                                               \
    } while (0)


// ============================================================
// 朴素 attention (对照用, 算 ground truth)
// ============================================================
// 在 CPU 上算, 作为验证标准
void naive_attention_cpu(
    const float* Q, const float* K, const float* V,
    float* out, int M, int N, int d, float scale)
{
    // scores = Q @ K^T * scale  [M, N]
    float* scores = (float*)malloc(M * N * sizeof(float));
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float s = 0.0f;
            for (int k = 0; k < d; ++k) s += Q[i*d+k] * K[j*d+k];
            scores[i*N+j] = s * scale;
        }
        // softmax (数值稳定)
        float maxv = scores[i*N];
        for (int j = 1; j < N; ++j) if (scores[i*N+j] > maxv) maxv = scores[i*N+j];
        float sum = 0.0f;
        for (int j = 0; j < N; ++j) {
            scores[i*N+j] = expf(scores[i*N+j] - maxv);
            sum += scores[i*N+j];
        }
        for (int j = 0; j < N; ++j) scores[i*N+j] /= sum;

        // out = scores @ V
        for (int k = 0; k < d; ++k) {
            float o = 0.0f;
            for (int j = 0; j < N; ++j) o += scores[i*N+j] * V[j*d+k];
            out[i*d+k] = o;
        }
    }
    free(scores);
}


// ============================================================
// FlashAttention Kernel (简化版)
// ============================================================
// 简化: 一个 block 处理一行 Q (M 个 query 中的一个)
//       在 shared memory 里累积 online softmax 状态
//
// 线程映射:
//   grid: (M,)  -- 一个 block 处理一个 query
//   block: (N,) -- N 个线程协作处理一个 query 对所有 N 个 key
//
// 状态 (存在 shared memory, 同 block 线程共享):
//   m: running max (标量)
//   l: running sum (标量)
//   acc: output accumulator [head_dim] (每个线程持有一部分)
//
// 数学流程 (block 内):
//   for each key j:
//     score_j = Q[i] · K[j] * scale
//     m_new = max(m, score_j)
//     l = l * exp(m - m_new) + exp(score_j - m_new)
//     acc = acc * exp(m - m_new) + exp(score_j - m_new) * V[j]
//     m = m_new
//   out[i] = acc / l
__global__ void flash_attention_kernel(
    const float* __restrict__ Q,    // [M, d]
    const float* __restrict__ K,    // [N, d]
    const float* __restrict__ V,    // [N, d]
    float* __restrict__ out,        // [M, d]
    int M, int N, int d,
    float scale)
{
    int q_idx = blockIdx.x;          // 哪个 query
    int tid = threadIdx.x;           // 线程 id (0..N-1, 对应一个 key)

    // shared memory: 同 block 线程共享
    // Python 程序员注意: __shared__ 是 CUDA 关键字, 表示这块内存同 block 所有线程可见
    //   比 global memory 快 ~10x
    __shared__ float s_m;            // running max (整个 block 共享一个)
    __shared__ float s_l;            // running sum
    __shared__ float s_q[64];        // Q[q_idx][:], 假设 d <= 64
    __shared__ float s_kj;           // 当前 key 的 score (每个线程算一个)

    // 每个 thread 维护自己的 acc (对应 head_dim 的一部分)
    // 简化: 假设 head_dim <= N, 一个 thread 负责 acc 的一个维度
    float acc = 0.0f;
    if (tid < d) {
        // 1. 加载 Q[q_idx][tid] 到 shared memory
        s_q[tid] = Q[q_idx * d + tid];
    }

    // 2. 初始化 running max/sum
    if (tid == 0) {
        s_m = -1e30f;
        s_l = 0.0f;
    }
    __syncthreads();   // 等待所有线程完成初始化 (CUDA 同步原语)

    // 3. 遍历所有 key (N 个), 每次 tid 处理 key[tid]
    //    简化: 一次循环处理所有 key (真实实现会分块)
    for (int j_block_start = 0; j_block_start < N; j_block_start += blockDim.x) {
        int j = j_block_start + tid;
        if (j >= N) break;

        // 3.1 算 score_j = Q[q_idx] · K[j] * scale
        //     注意: 每个 thread 都算同一个 score (重复计算)
        //     简化: 真实实现会用 reduction, 这里为了清晰
        float score = 0.0f;
        for (int k = 0; k < d; ++k) {
            score += s_q[k] * K[j * d + k];
        }
        score *= scale;
        s_kj = score;   // 简化: 只用 tid=0 的 s_kj
        __syncthreads();

        // 3.2 online softmax 更新
        //     m_new = max(m_old, score)
        //     l_new = l_old * exp(m_old - m_new) + exp(score - m_new)
        //     acc_new = acc_old * exp(m_old - m_new) + exp(score - m_new) * V[j][tid]
        if (tid == 0) {
            float m_old = s_m;
            float m_new = fmaxf(m_old, s_kj);
            float alpha = expf(m_old - m_new);    // 旧 acc/l 的缩放因子
            float pj = expf(s_kj - m_new);        // 新 score 的 exp 值

            s_l = s_l * alpha + pj;
            s_m = m_new;
            // 把 alpha 和 pj 存回 shared memory 给其他线程用
            s_kj = alpha;   // 复用 s_kj 存 alpha
            s_q[d] = pj;    // 复用 s_q[d] 存 pj (注意别和 Q 冲突)
        }
        __syncthreads();

        // 3.3 所有 thread 更新自己的 acc (对应 head_dim 的一维)
        if (tid < d) {
            float alpha = s_kj;       // 旧 acc 的缩放因子
            float pj = s_q[d];        // 新 score 的 exp 值
            acc = acc * alpha + pj * V[j * d + tid];
        }
        __syncthreads();
    }

    // 4. 最后: out[i][tid] = acc / l
    if (tid < d) {
        out[q_idx * d + tid] = acc / s_l;
    }
}


// ============================================================
// 主函数
// ============================================================
int main()
{
    printf("=== FlashAttention CUDA Demo (简化教学版) ===\n");

    // 参数 (故意用小值, 方便验证)
    const int M = 8;      // query 数
    const int N = 8;      // key 数
    const int d = 16;     // head_dim
    const float scale = 1.0f / sqrtf((float)d);

    printf("M=%d, N=%d, d=%d\n", M, N, d);

    // 分配 host 内存
    size_t size = M * d * sizeof(float);
    size_t kv_size = N * d * sizeof(float);
    float *h_Q = (float*)malloc(size);
    float *h_K = (float*)malloc(kv_size);
    float *h_V = (float*)malloc(kv_size);
    float *h_out_flash = (float*)malloc(size);
    float *h_out_naive = (float*)malloc(size);

    // 初始化 (用简单值方便验证)
    for (int i = 0; i < M * d; ++i) h_Q[i] = 0.1f * (i % 5);
    for (int i = 0; i < N * d; ++i) h_K[i] = 0.1f * (i % 3);
    for (int i = 0; i < N * d; ++i) h_V[i] = 0.1f * (i % 7);

    // CPU 朴素版 (ground truth)
    naive_attention_cpu(h_Q, h_K, h_V, h_out_naive, M, N, d, scale);

    // GPU FlashAttention
    float *d_Q, *d_K, *d_V, *d_out;
    CUDA_CHECK(cudaMalloc(&d_Q, size));
    CUDA_CHECK(cudaMalloc(&d_K, kv_size));
    CUDA_CHECK(cudaMalloc(&d_V, kv_size));
    CUDA_CHECK(cudaMalloc(&d_out, size));
    CUDA_CHECK(cudaMemcpy(d_Q, h_Q, size, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_K, h_K, kv_size, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_V, h_V, kv_size, cudaMemcpyHostToDevice));

    // 启动 kernel: 一个 block 处理一个 query
    // block 大小: N (一个线程一个 key)
    flash_attention_kernel<<<M, N>>>(
        d_Q, d_K, d_V, d_out, M, N, d, scale);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    CUDA_CHECK(cudaMemcpy(h_out_flash, d_out, size, cudaMemcpyDeviceToHost));

    // 验证: 对比 flash 和 naive 的输出
    printf("\n验证 FlashAttention vs 朴素 attention:\n");
    float max_diff = 0.0f;
    for (int i = 0; i < M; ++i) {
        for (int k = 0; k < d; ++k) {
            float diff = fabsf(h_out_flash[i*d+k] - h_out_naive[i*d+k]);
            if (diff > max_diff) max_diff = diff;
        }
    }
    printf("  最大绝对误差: %e\n", max_diff);
    printf("  (应该 < 1e-5, 因为都是 FP32 精度)\n");

    printf("\n  out_flash[0][:4] = ");
    for (int k = 0; k < 4; ++k) printf("%.4f ", h_out_flash[k]);
    printf("\n  out_naive[0][:4] = ");
    for (int k = 0; k < 4; ++k) printf("%.4f ", h_out_naive[k]);
    printf("\n");

    // 清理
    cudaFree(d_Q); cudaFree(d_K); cudaFree(d_V); cudaFree(d_out);
    free(h_Q); free(h_K); free(h_V);
    free(h_out_flash); free(h_out_naive);

    printf("\nFlashAttention demo 完成.\n");
    printf("对比 Python 版: 06_flash_attention/flash_attention_triton.py\n");
    return 0;
}

/*
 * 学习建议:
 *   1. 先读 Python 版 (Triton 实现更易读)
 *   2. 理解 online softmax 的数学 (是核心)
 *   3. 对照本文件, 看 C++/CUDA 怎么用 shared memory 实现
 *   4. 这个版本极简, 真实 FlashAttention 还要做:
 *      - 分块处理 K/V (不只一次循环)
 *      - 用 warp shuffle 做 reduction
 *      - 支持 causal mask
 *      - 支持 multi-head / batch
 *   5. 性能: 真实 FlashAttention 比朴素快 2-4x (主要省 HBM 访问)
 *
 * 关键收获:
 *   - online softmax 让你不用一次性加载所有 scores
 *   - shared memory 是减少 HBM 访问的关键
 *   - 数学技巧能直接转化为性能
 */
