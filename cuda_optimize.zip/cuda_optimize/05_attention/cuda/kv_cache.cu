﻿/*
 * kv_cache.cu — KV Cache 的 CUDA 实现
 *
 * 对应 Python 版: 05_attention/python/kv_cache_demo.py
 *
 * Python 里 KV Cache 很简单:
 *     k_cache = torch.cat([k_cache, new_k], dim=seq_dim)  # append
 *     scores = Q @ k_cache.transpose(-2, -1)              # read
 *
 * C++/CUDA 里要手动管理 GPU 显存:
 *     1. 预分配固定大小的 KV Cache buffer
 *     2. append kernel: 把新 token 的 K/V 写到 cache 末尾
 *     3. read kernel: 用 cache 算 attention (复用 attention.cu 的逻辑)
 *
 * 教学重点:
 *     - GPU 显存预分配 (不能像 Python 那样动态 cat)
 *     - append 操作的 kernel 写法
 *     - 用指针偏移代替 torch.cat
 *
 * 编译: nvcc -std=c++17 -O2 kv_cache.cu -o kv_cache_demo
 * 运行: ./kv_cache_demo
 *
 * 配套文档: docs/04_attention_kv_cache.md, docs/11_kv_cache_optimization.md
 */

#include <cuda_runtime.h>
#include <cstdio>
#include <cmath>
#include <cstdlib>

#define CUDA_CHECK(call)                                                \
    do {                                                                \
        cudaError_t err = (call);                                       \
        if (err != cudaSuccess) {                                       \
            fprintf(stderr, "CUDA error %s:%d: %s\n",                   \
                    __FILE__, __LINE__, cudaGetErrorString(err));       \
            exit(EXIT_FAILURE);                                         \
        }                                                               \
    } while (0)


// ============================================================
// KV Cache 数据结构
// ============================================================
// Python 类比:
//   class KVCache:
//       def __init__(self, num_layers, max_seq, num_heads, head_dim):
//           self.k = torch.zeros(num_layers, max_seq, num_heads, head_dim).cuda()
//           self.v = torch.zeros(num_layers, max_seq, num_heads, head_dim).cuda()
//           self.len = 0
//
// C++ 里我们用一个 struct 管理这些字段
struct KVCache {
    float* k_cache;    // [num_layers, max_seq, num_heads, head_dim]
    float* v_cache;    // 同上
    int num_layers;
    int max_seq;
    int num_heads;
    int head_dim;
    int current_len;   // 当前已填充的 seq 长度

    // 算每层的大小 (字节)
    size_t layer_size() const {
        return (size_t)max_seq * num_heads * head_dim * sizeof(float);
    }
};


// ============================================================
// Kernel 1: append — 把新 token 的 K/V 追加到 cache 末尾
// ============================================================
// Python 类比:
//   k_cache[layer, current_len:current_len+1, :, :] = new_k
//
// 线程映射: 一个线程写一个元素
//   grid: (num_layers, num_heads * head_dim)
//   block: (num_heads * head_dim,)  -- 但太大了, 改成 block 处理一个 head 的所有 dim
//
// 参数:
//   cache: KVCache 的 k 或 v 指针
//   new_kv: [num_layers, 1, num_heads, head_dim] 新 token 的 K/V
//   current_len: 当前 cache 长度 (新 token 写到这个位置)
__global__ void append_kv_kernel(
    float* __restrict__ cache,           // [num_layers, max_seq, num_heads, head_dim]
    const float* __restrict__ new_kv,    // [num_layers, 1, num_heads, head_dim]
    int max_seq, int num_heads, int head_dim,
    int current_len)
{
    // 1. 算当前线程写哪个位置
    //    cache[layer, current_len, head, dim] = new_kv[layer, 0, head, dim]
    int layer = blockIdx.x;
    int hd = blockIdx.y * blockDim.x + threadIdx.x;  // head * head_dim + dim

    int num_heads_dim = num_heads * head_dim;
    if (hd >= num_heads_dim) return;

    // 2. 算地址偏移
    //    cache 是 [num_layers, max_seq, num_heads, head_dim] 连续存储
    //    cache[layer][current_len][head][dim] 的偏移:
    //      layer * (max_seq * num_heads_dim) + current_len * num_heads_dim + hd
    size_t cache_offset = (size_t)layer * max_seq * num_heads_dim
                        + (size_t)current_len * num_heads_dim
                        + hd;
    //    new_kv[layer][0][head][dim] 的偏移:
    //      layer * num_heads_dim + hd
    size_t new_offset = (size_t)layer * num_heads_dim + hd;

    // 3. 写入
    cache[cache_offset] = new_kv[new_offset];
}


// ============================================================
// Kernel 2: 用 Q 和 cache 算 attention scores (简化版)
// ============================================================
// 数学: scores[q_idx] = sum_d Q[q_idx][d] * K_cache[0:current_len][d] / sqrt(d)
//       返回 [current_len] 的 scores 向量 (一个 query 对所有 keys)
//
// 线程映射: 一个线程算一个 score 元素
__global__ void qk_cache_kernel(
    const float* __restrict__ Q,         // [1, head_dim] 单个 query
    const float* __restrict__ k_cache,   // [num_layers, max_seq, num_heads, head_dim]
    float* __restrict__ scores,          // [current_len] 输出
    int max_seq, int num_heads, int head_dim,
    int current_len, int layer, int head,
    float scale)
{
    int kv_idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (kv_idx >= current_len) return;

    // K_cache[layer][kv_idx][head][:] 的偏移
    size_t offset = (size_t)layer * max_seq * num_heads * head_dim
                  + (size_t)kv_idx * num_heads * head_dim
                  + (size_t)head * head_dim;

    // 点积
    float sum = 0.0f;
    for (int d = 0; d < head_dim; ++d) {
        sum += Q[d] * k_cache[offset + d];
    }
    scores[kv_idx] = sum * scale;
}


// ============================================================
// 辅助: 打印 cache 的一部分 (拷到 CPU 再打印)
// ============================================================
void print_cache_head(const KVCache& cache, int layer, int n_print) {
    int total = n_print * cache.num_heads * cache.head_dim;
    float* tmp = (float*)malloc(total * sizeof(float));
    size_t offset = (size_t)layer * cache.max_seq * cache.num_heads * cache.head_dim;
    CUDA_CHECK(cudaMemcpy(tmp, cache.k_cache + offset,
                          total * sizeof(float), cudaMemcpyDeviceToHost));
    printf("  K_cache[layer=%d, first %d tokens, head 0, dim 0-3]:\n    ", layer, n_print);
    for (int i = 0; i < n_print; ++i) {
        printf("[");
        for (int d = 0; d < 4; ++d) {
            printf("%.3f ", tmp[i * cache.num_heads * cache.head_dim + d]);
        }
        printf("] ");
    }
    printf("\n");
    free(tmp);
}


// ============================================================
// 主函数: 演示 KV Cache 的 append 和 read
// ============================================================
int main()
{
    printf("=== KV Cache CUDA Demo ===\n");

    // ===== 1. 初始化 KV Cache =====
    KVCache cache;
    cache.num_layers = 2;
    cache.max_seq = 64;          // 最多缓存 64 个 token
    cache.num_heads = 4;
    cache.head_dim = 16;
    cache.current_len = 0;

    printf("配置: layers=%d, max_seq=%d, heads=%d, head_dim=%d\n",
           cache.num_layers, cache.max_seq, cache.num_heads, cache.head_dim);

    // 预分配 GPU 显存 (一次性, 不像 Python 每次 cat 都要重新分配)
    size_t total_bytes = cache.num_layers * cache.layer_size();
    CUDA_CHECK(cudaMalloc(&cache.k_cache, total_bytes));
    CUDA_CHECK(cudaMalloc(&cache.v_cache, total_bytes));
    CUDA_CHECK(cudaMemset(cache.k_cache, 0, total_bytes));
    CUDA_CHECK(cudaMemset(cache.v_cache, 0, total_bytes));

    // ===== 2. 模拟 decode: 每步 append 一个 token =====
    int new_kv_size = cache.num_layers * cache.num_heads * cache.head_dim;
    float* h_new_k = (float*)malloc(new_kv_size * sizeof(float));
    float* d_new_k;
    CUDA_CHECK(cudaMalloc(&d_new_k, new_kv_size * sizeof(float)));

    for (int step = 0; step < 5; ++step) {
        // 2.1 生成"新 token 的 K" (实际场景里这是模型算出来的)
        for (int i = 0; i < new_kv_size; ++i) {
            h_new_k[i] = 0.1f * (step + 1) + 0.01f * (i % 7);
        }
        CUDA_CHECK(cudaMemcpy(d_new_k, h_new_k,
                              new_kv_size * sizeof(float),
                              cudaMemcpyHostToDevice));

        // 2.2 启动 append kernel
        dim3 grid(cache.num_layers, (cache.num_heads * cache.head_dim + 255) / 256);
        dim3 block(min(cache.num_heads * cache.head_dim, 256));

        append_kv_kernel<<<grid, block>>>(
            cache.k_cache, d_new_k,
            cache.max_seq, cache.num_heads, cache.head_dim,
            cache.current_len);
        CUDA_CHECK(cudaGetLastError());

        append_kv_kernel<<<grid, block>>>(
            cache.v_cache, d_new_k,  // 简化: V 用同样的数据
            cache.max_seq, cache.num_heads, cache.head_dim,
            cache.current_len);
        CUDA_CHECK(cudaGetLastError());

        cache.current_len++;
        printf("\n[Step %d] append 完成, current_len = %d\n",
               step, cache.current_len);
    }

    // ===== 3. 打印 cache 内容验证 =====
    printf("\nKV Cache 内容:\n");
    print_cache_head(cache, 0, 5);

    // ===== 4. 用 cache 算 attention scores (演示 read) =====
    printf("\n用 Q 查询 cache:\n");
    float* h_Q = (float*)malloc(cache.head_dim * sizeof(float));
    for (int d = 0; d < cache.head_dim; ++d) {
        h_Q[d] = 0.5f;  // 简化: Q 用全 0.5
    }
    float* d_Q;
    CUDA_CHECK(cudaMalloc(&d_Q, cache.head_dim * sizeof(float)));
    CUDA_CHECK(cudaMemcpy(d_Q, h_Q, cache.head_dim * sizeof(float),
                          cudaMemcpyHostToDevice));

    float* d_scores;
    CUDA_CHECK(cudaMalloc(&d_scores, cache.current_len * sizeof(float)));
    float scale = 1.0f / sqrtf((float)cache.head_dim);

    qk_cache_kernel<<<(cache.current_len + 255) / 256, 256>>>(
        d_Q, cache.k_cache, d_scores,
        cache.max_seq, cache.num_heads, cache.head_dim,
        cache.current_len, /*layer=*/0, /*head=*/0, scale);
    CUDA_CHECK(cudaGetLastError());

    // 拷回 scores 打印
    float* h_scores = (float*)malloc(cache.current_len * sizeof(float));
    CUDA_CHECK(cudaDeviceSynchronize());
    CUDA_CHECK(cudaMemcpy(h_scores, d_scores,
                          cache.current_len * sizeof(float),
                          cudaMemcpyDeviceToHost));
    printf("  Q vs K_cache[0:5] scores: ");
    for (int i = 0; i < cache.current_len; ++i) {
        printf("%.4f ", h_scores[i]);
    }
    printf("\n");

    // ===== 5. 清理 =====
    cudaFree(cache.k_cache);
    cudaFree(cache.v_cache);
    cudaFree(d_new_k);
    cudaFree(d_Q);
    cudaFree(d_scores);
    free(h_new_k);
    free(h_Q);
    free(h_scores);

    printf("\nKV Cache demo 完成.\n");
    printf("对比 Python 版: 05_attention/python/kv_cache_demo.py\n");
    printf("关键差异:\n");
    printf("  Python: torch.cat 动态扩展, 自动管理显存\n");
    printf("  C++:    预分配固定 buffer, 手动 append, 手动释放\n");
    return 0;
}

/*
 * 学习建议:
 *   1. 跑 Python 版 kv_cache_demo.py, 对照理解
 *   2. 改 cache.current_len 看输出变化
 *   3. 思考: 为什么不能像 Python 那样 dynamic resize?
 *      答: GPU 显存分配慢 (cudaMalloc ~10us), 频繁分配会拖慢推理
 *          预分配 + 写入是推理引擎的标准做法
 *   4. 进阶: 把 append 改成支持 batch (同时 append 多个 token)
 */
