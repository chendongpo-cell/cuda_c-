﻿"""
eagle_speculative_demo.py — EAGLE 投机解码简化教学版

配合 [docs/23_eagle_practice.md](../docs/23_eagle_practice.md) 使用。

演示 EAGLE 的核心流程:
    1. Target 模型提供 hidden state
    2. Draft head 基于 hidden state + token embedding 自回归生成草稿
    3. Target 一次前向验证所有草稿
    4. 逐个采样接受/拒绝

这是教学版, 省略了 Tree Attention (用线性草稿简化), KV Cache 等工程细节。
真实实现见 vllm/spec_decode/eagle.py。

学习目标:
    1. 理解 EAGLE 的 draft head 输入输出
    2. 理解 draft 自回归生成
    3. 理解 target 一次前向验证
    4. 理解采样接受/拒绝的数学

运行:
    cd 05_attention/python
    python eagle_speculative_demo.py
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Optional
from dataclasses import dataclass


# ============================================================
# 简化 Target 模型 (代替真实 LLM)
# ============================================================

class TinyTargetModel(nn.Module):
    """
    简化的 target 模型

    和真实 LLM 的对应关系:
        embedding   → token embedding
        transformer → 多层 transformer block (这里简化为 1 层)
        lm_head     → LM head (输出 logits)
        hidden_state → 倒数第二层的输出 (EAGLE 需要)
    """

    def __init__(self, vocab_size: int = 100, hidden: int = 32):
        super().__init__()
        self.hidden = hidden
        self.embedding = nn.Embedding(vocab_size, hidden)
        # 简化为 1 层 transformer
        self.attn = nn.MultiheadAttention(hidden, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(hidden)
        self.ffn = nn.Sequential(
            nn.Linear(hidden, hidden * 4),
            nn.GELU(),
            nn.Linear(hidden * 4, hidden),
        )
        self.norm2 = nn.LayerNorm(hidden)
        self.lm_head = nn.Linear(hidden, vocab_size, bias=False)

    def forward(self, input_ids, output_hidden=False):
        """
        返回:
            - logits: [batch, seq, vocab]
            - hidden: [batch, seq, hidden] (倒数第二层, 给 EAGLE 用)
        """
        x = self.embedding(input_ids)  # [batch, seq, hidden]

        # Transformer 层
        attn_out, _ = self.attn(x, x, x)
        h = self.norm(x + attn_out)  # 这是 hidden state (EAGLE 用)

        ffn_out = self.ffn(h)
        h2 = self.norm2(h + ffn_out)

        logits = self.lm_head(h2)

        if output_hidden:
            return logits, h  # 返回 hidden state
        return logits


# ============================================================
# EAGLE Draft Head
# ============================================================

class EagleDraftHead(nn.Module):
    """
    EAGLE Draft Head 简化版

    输入: [hidden_state, token_embedding] 拼接
    输出: 下一个 hidden_state (再过 lm_head 得到 logits)

    真实 EAGLE 用 1-2 层 transformer, 这里用 1 层简化
    """

    def __init__(self, hidden: int, vocab_size: int):
        super().__init__()
        # 输入投影: 把 [hidden, embedding] (2*hidden) 降回 hidden
        self.input_proj = nn.Linear(2 * hidden, hidden, bias=False)

        # 简化的 1 层 transformer
        self.attn = nn.MultiheadAttention(hidden, num_heads=4, batch_first=True)
        self.norm1 = nn.LayerNorm(hidden)
        self.ffn = nn.Sequential(
            nn.Linear(hidden, hidden * 4),
            nn.GELU(),
            nn.Linear(hidden * 4, hidden),
        )
        self.norm2 = nn.LayerNorm(hidden)

        # LM head: 训练时从 target 复制
        self.lm_head = nn.Linear(hidden, vocab_size, bias=False)

    def forward(
        self,
        hidden_states: torch.Tensor,     # [batch, seq, hidden]
        token_embeddings: torch.Tensor,  # [batch, seq, hidden]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        返回:
            draft_hidden: [batch, seq, hidden]
            draft_logits: [batch, seq, vocab]
        """
        # 1. 拼接 hidden 和 token embedding
        x = torch.cat([hidden_states, token_embeddings], dim=-1)  # [batch, seq, 2*hidden]
        x = self.input_proj(x)  # [batch, seq, hidden]

        # 2. Transformer 层 (简化, 真实用 causal mask)
        attn_out, _ = self.attn(x, x, x)
        x = self.norm1(x + attn_out)

        ffn_out = self.ffn(x)
        x = self.norm2(x + ffn_out)

        # 3. 输出 hidden + logits
        draft_hidden = x
        draft_logits = self.lm_head(draft_hidden)
        return draft_hidden, draft_logits


# ============================================================
# EAGLE 投机解码核心
# ============================================================

def eagle_speculative_step(
    target_model: TinyTargetModel,
    draft_head: EagleDraftHead,
    input_ids: torch.Tensor,           # [1, seq_len] 当前已生成
    draft_length: int = 4,
) -> Tuple[torch.Tensor, dict]:
    """
    执行一轮 EAGLE 投机解码

    返回:
        new_tokens: [1, n] 这轮生成的 token (1 <= n <= draft_length + 1)
        stats: 统计信息 (接受数等)
    """
    device = input_ids.device

    # ===== Step 1: Target 模型算一次, 拿到最后的 hidden state =====
    with torch.no_grad():
        target_logits, target_hidden = target_model(
            input_ids, output_hidden=True
        )
    # target_hidden: [1, seq_len, hidden]
    # 取最后一个位置的 hidden state 作为 draft 输入
    last_hidden = target_hidden[:, -1:, :]  # [1, 1, hidden]
    last_token_emb = target_model.embedding(input_ids[:, -1:])  # [1, 1, hidden]

    # ===== Step 2: Draft head 自回归生成 draft_length 个草稿 =====
    draft_tokens = []
    draft_hidden_list = []
    draft_logits_list = []

    cur_hidden = last_hidden
    cur_token_emb = last_token_emb

    for step in range(draft_length):
        with torch.no_grad():
            draft_h, draft_logits = draft_head(cur_hidden, cur_token_emb)
        # draft_h: [1, 1, hidden]
        # draft_logits: [1, 1, vocab]

        # Greedy 采样 (简化, 真实用 top-k + tree)
        next_token = draft_logits[0, -1].argmax().view(1, 1)
        draft_tokens.append(next_token)
        draft_hidden_list.append(draft_h)
        draft_logits_list.append(draft_logits)

        # 更新输入
        cur_hidden = draft_h
        cur_token_emb = target_model.embedding(next_token)

    draft_tokens_tensor = torch.cat(draft_tokens, dim=1)  # [1, draft_length]
    draft_logits_all = torch.cat(draft_logits_list, dim=1)  # [1, draft_length, vocab]
    draft_probs = F.softmax(draft_logits_all, dim=-1)

    # ===== Step 3: Target 一次前向验证所有草稿 =====
    verify_input = torch.cat([input_ids, draft_tokens_tensor], dim=1)  # [1, seq + draft_length]
    with torch.no_grad():
        verify_logits = target_model(verify_input)
    # 验证位置: 从 seq_len-1 开始 (预测 draft_tokens[0])
    # verify_logits[:, seq_len-1, :] 预测 draft_tokens[0]
    # verify_logits[:, seq_len, :] 预测 draft_tokens[1]
    # ...
    seq_len = input_ids.size(1)
    target_verify_logits = verify_logits[:, seq_len-1:seq_len-1+draft_length, :]  # [1, draft_length, vocab]
    target_probs = F.softmax(target_verify_logits, dim=-1)

    # ===== Step 4: 逐个采样接受/拒绝 =====
    accepted = []
    for i in range(draft_length):
        d_token = draft_tokens_tensor[0, i].item()
        p = target_probs[0, i, d_token].item()  # target 真实概率
        q = draft_probs[0, i, d_token].item()   # draft 预测概率

        # 接受概率 = min(1, p/q)
        # 这保证最终采样分布等价于直接从 target 采样
        accept_prob = min(1.0, p / max(q, 1e-10))

        if torch.rand(1).item() < accept_prob:
            # 接受
            accepted.append(d_token)
        else:
            # 拒绝, 从 (target - draft) 归一化分布重新采样
            corrected = torch.clamp(target_probs[0, i] - draft_probs[0, i], min=0)
            corrected = corrected / corrected.sum()
            new_token = torch.multinomial(corrected, 1).item()
            accepted.append(new_token)
            break  # 遇到第一个拒绝就停止

    # 如果所有 draft 都被接受, bonus 一个 token (target 在最后位置的预测)
    if len(accepted) == draft_length:
        bonus_token = target_verify_logits[0, -1].argmax().item()
        accepted.append(bonus_token)

    stats = {
        "draft_length": draft_length,
        "accepted_count": len(accepted),
        "acceptance_rate": len(accepted) / draft_length,
        "draft_tokens": draft_tokens_tensor[0].tolist(),
        "accepted_tokens": accepted,
    }

    return torch.tensor(accepted, device=device).view(1, -1), stats


# ============================================================
# 对比测试: EAGLE vs 普通 decode
# ============================================================

def demo_eagle_vs_normal():
    """对比 EAGLE 投机解码和普通 decode 的速度"""
    print("\n" + "=" * 60)
    print("EAGLE 投机解码 vs 普通 decode 对比")
    print("=" * 60)

    torch.manual_seed(42)

    # 初始化模型
    vocab_size = 100
    hidden = 32
    target_model = TinyTargetModel(vocab_size, hidden).cuda()
    draft_head = EagleDraftHead(hidden, vocab_size).cuda()

    # 让 draft_head 的 lm_head 和 target 共享权重 (EAGLE 关键)
    with torch.no_grad():
        draft_head.lm_head.weight.copy_(target_model.lm_head.weight)

    # 起始 prompt
    input_ids = torch.tensor([[1, 5, 10, 15, 20]], device="cuda")

    # ===== 普通 decode =====
    print("\n--- 普通 decode (生成 8 个 token) ---")
    cur_ids = input_ids.clone()
    normal_start = torch.cuda.Event(enable_timing=True)
    normal_end = torch.cuda.Event(enable_timing=True)

    normal_start.record()
    for _ in range(8):
        with torch.no_grad():
            logits = target_model(cur_ids)
        next_token = logits[0, -1].argmax().view(1, 1)
        cur_ids = torch.cat([cur_ids, next_token], dim=1)
    normal_end.record()
    torch.cuda.synchronize()
    normal_time = normal_start.elapsed_time(normal_end)

    print(f"  生成 8 token, 8 次 target forward")
    print(f"  耗时: {normal_time:.2f}ms")
    print(f"  输出: {cur_ids[0].tolist()}")

    # ===== EAGLE 投机解码 =====
    print("\n--- EAGLE 投机解码 (target 4 步) ---")
    cur_ids = input_ids.clone()
    eagle_start = torch.cuda.Event(enable_timing=True)
    eagle_end = torch.cuda.Event(enable_timing=True)

    eagle_start.record()
    generated = 0
    target_forward_count = 0
    total_accepted = 0
    total_draft = 0

    while generated < 8:
        # 一轮 EAGLE
        new_tokens, stats = eagle_speculative_step(
            target_model, draft_head, cur_ids, draft_length=4
        )
        cur_ids = torch.cat([cur_ids, new_tokens], dim=1)
        generated += new_tokens.size(1)
        target_forward_count += 1
        total_accepted += stats["accepted_count"]
        total_draft += stats["draft_length"]

        print(f"  Round {target_forward_count}: "
              f"draft={stats['draft_tokens']}, "
              f"accepted={stats['accepted_tokens']}")

        if generated >= 8:
            break

    eagle_end.record()
    torch.cuda.synchronize()
    eagle_time = eagle_start.elapsed_time(eagle_end)

    print(f"  生成 {generated} token, {target_forward_count} 次 target forward")
    print(f"  总接受率: {total_accepted}/{total_draft} = {total_accepted/total_draft:.1%}")
    print(f"  耗时: {eagle_time:.2f}ms")
    print(f"  输出: {cur_ids[0].tolist()}")

    # ===== 对比 =====
    print("\n--- 对比 ---")
    print(f"  普通 decode: {normal_time:.2f}ms (8 次 target forward)")
    print(f"  EAGLE:       {eagle_time:.2f}ms ({target_forward_count} 次 target forward)")
    if eagle_time > 0:
        speedup = normal_time / eagle_time
        print(f"  加速比:      {speedup:.2f}x")
    print(f"  target forward 次数减少: {8 - target_forward_count} / 8 = "
          f"{(8 - target_forward_count) / 8:.1%}")

    print("\n  注意: 这个 demo 用随机初始化的模型, 接受率低, 加速不明显")
    print("  真实 EAGLE 训练过的 draft head 接受率 70-90%, 加速 3-5x")


# ============================================================
# 单步演示
# ============================================================

def demo_single_step():
    """演示单轮 EAGLE 的流程细节"""
    print("\n" + "=" * 60)
    print("EAGLE 单轮流程详解")
    print("=" * 60)

    torch.manual_seed(0)
    target_model = TinyTargetModel(100, 32).cuda()
    draft_head = EagleDraftHead(32, 100).cuda()
    with torch.no_grad():
        draft_head.lm_head.weight.copy_(target_model.lm_head.weight)

    input_ids = torch.tensor([[1, 2, 3, 4, 5]], device="cuda")
    print(f"\n输入 prompt: {input_ids[0].tolist()}")

    # ===== Step 1: Target forward =====
    print("\n[Step 1] Target 模型 forward, 取最后 hidden state")
    with torch.no_grad():
        target_logits, target_hidden = target_model(input_ids, output_hidden=True)
    print(f"  target hidden shape: {target_hidden.shape}")
    print(f"  最后位置 hidden: {target_hidden[0, -1, :4].tolist()} (前4维)")

    # ===== Step 2: Draft 自回归生成 =====
    print("\n[Step 2] Draft head 自回归生成 4 个草稿 token")
    cur_hidden = target_hidden[:, -1:, :]
    cur_token_emb = target_model.embedding(input_ids[:, -1:])
    draft_tokens = []

    for step in range(4):
        with torch.no_grad():
            draft_h, draft_logits = draft_head(cur_hidden, cur_token_emb)
        next_token = draft_logits[0, -1].argmax().view(1, 1)
        draft_tokens.append(next_token.item())
        print(f"  step {step+1}: draft 预测 token = {next_token.item()}")
        cur_hidden = draft_h
        cur_token_emb = target_model.embedding(next_token)

    print(f"  草稿 tokens: {draft_tokens}")

    # ===== Step 3: Target 验证 =====
    print("\n[Step 3] Target 一次前向验证所有草稿")
    draft_tensor = torch.tensor([draft_tokens], device="cuda")
    verify_input = torch.cat([input_ids, draft_tensor], dim=1)
    with torch.no_grad():
        verify_logits = target_model(verify_input)

    seq_len = input_ids.size(1)
    print(f"  verify 输入: {verify_input[0].tolist()}")
    print(f"  verify 在位置 {seq_len-1}~{seq_len+2} 预测:")
    for i, dt in enumerate(draft_tokens):
        target_pred = verify_logits[0, seq_len-1+i].argmax().item()
        print(f"    位置 {seq_len-1+i}: draft={dt}, target_top1={target_pred}, "
              f"{'✓' if dt == target_pred else '✗'}")

    # ===== Step 4: 接受统计 =====
    print("\n[Step 4] 接受/拒绝统计 (greedy 模式: target_top1 == draft 才接受)")
    accepted = []
    for i, dt in enumerate(draft_tokens):
        target_pred = verify_logits[0, seq_len-1+i].argmax().item()
        if dt == target_pred:
            accepted.append(dt)
        else:
            accepted.append(target_pred)  # 拒绝时用 target 的预测
            break

    # bonus token
    if len(accepted) == len(draft_tokens):
        bonus = verify_logits[0, seq_len-1+len(draft_tokens)].argmax().item()
        accepted.append(bonus)

    print(f"  最终接受: {accepted}")
    print(f"  接受率: {min(len(accepted), len(draft_tokens))}/{len(draft_tokens)}")


# ============================================================
# 主入口
# ============================================================

if __name__ == "__main__":
    print("╔" + "═" * 60 + "╗")
    print("║" + " EAGLE 投机解码教学版 ".center(54) + "║")
    print("╚" + "═" * 60 + "╝")

    demo_single_step()
    demo_eagle_vs_normal()

    print("\n" + "=" * 60)
    print("结论:")
    print("  1. EAGLE 用 target 的 hidden state 作为 draft 输入, 接受率高")
    print("  2. Draft head 自回归生成多个草稿")
    print("  3. Target 一次前向验证所有草稿")
    print("  4. 数学上保证采样分布等价于直接从 target 采样")
    print("  5. 训练过的 EAGLE 加速 3-5x")
    print("=" * 60)
