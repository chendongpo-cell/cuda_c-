"""
kv_cache_demo.py — KV Cache 推理循环演示

知识点覆盖：
  ✅ Prefill 阶段处理 prompt
  ✅ Decode 阶段逐 token 生成
  ✅ KV Cache 的 update 机制
  ✅ 因果 mask 的作用
  ✅ 不 cache 和 cache 版本的计算量对比
  ✅ 推理吞吐计算

运行：python kv_cache_demo.py
"""

import torch
import torch.nn.functional as F
import math
import time


# ================================================================
# 简化的 Transformer Layer（只含 Attention）
# ================================================================

class SimpleAttentionLayer(torch.nn.Module):
    """
    包含 QKV 投影 + Attention + Output 投影的简化层

    推理场景：
      每个 decoder layer 包含：
        1. Q = input @ W_Q
        2. K = input @ W_K
        3. V = input @ W_V
        4. Attention(Q, K, V)
        5. output = attn_output @ W_O
    """

    def __init__(self, hidden_dim, num_heads):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads

        # QKV 投影矩阵（推理中最常见的 GEMM 之一）
        # 在真实模型中，这些是 nn.Linear
        self.wq = torch.nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.wk = torch.nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.wv = torch.nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.wo = torch.nn.Linear(hidden_dim, hidden_dim, bias=False)

    def forward(self, x, past_kv=None, use_cache=False):
        """
        Args:
            x: [batch, seq_len, hidden_dim] — 输入
            past_kv: tuple(K, V) 或 None — 之前缓存的 KV
            use_cache: bool — 是否返回 KV cache
        Returns:
            output: [batch, seq_len, hidden_dim]
            present_kv: tuple(K, V) 或 None
        """
        batch, seq_len, _ = x.shape

        # =============================
        # Step 1: QKV 投影
        # =============================
        q = self.wq(x)
        k = self.wk(x)
        v = self.wv(x)

        # =============================
        # Step 2: Reshape 为多头
        # [B, S, H*D] → [B, H, S, D]
        # =============================
        q = q.view(batch, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(batch, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(batch, seq_len, self.num_heads, self.head_dim).transpose(1, 2)

        # =============================
        # Step 3: KV Cache 拼接
        # =============================

        if past_kv is not None:
            # 如果有 cache，拼接到已有的 K/V 后面
            # past_kv[0]: [B, H, past_len, D]
            # k:         [B, H, 1, D]
            # result:    [B, H, past_len+1, D]
            k = torch.cat([past_kv[0], k], dim=2)
            v = torch.cat([past_kv[1], v], dim=2)

        # 保存当前的 K/V（如果 use_cache=True 且是 decode 单步）
        present_kv = (k, v) if use_cache else None

        # =============================
        # Step 4: Attention
        # =============================

        # Q@K^T: [B, H, Sq, D] @ [B, H, D, Sk]
        score = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)

        # Causal mask (只在 prefill 需要，decode 时 K/V 已经只有前面 token)
        # 注意：如果 past_kv 不为空，说明是 decode 模式
        #   k 中已经包含过去所有 token，Sq=1（当前 token）
        #   所以不需要 mask（没有后面的 token）
        # 如果 past_kv 为空且 seq_len > 1，是 prefill 模式，需要 mask
        if past_kv is None and seq_len > 1:
            # 生成上三角 mask
            mask = torch.triu(
                torch.ones(seq_len, seq_len, dtype=torch.bool, device=x.device),
                diagonal=1
            )
            mask = mask.unsqueeze(0).unsqueeze(0)  # [1, 1, Sq, Sk]
            score = score.masked_fill(mask, float('-inf'))

        attn_weights = F.softmax(score, dim=-1)

        # P@V: [B, H, Sq, Sk] @ [B, H, Sk, D] → [B, H, Sq, D]
        attn_output = torch.matmul(attn_weights, v)

        # =============================
        # Step 5: 合并 heads + Output 投影
        # =============================

        # [B, H, S, D] → [B, S, H*D]
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(batch, -1, self.hidden_dim)

        # Output 投影
        output = self.wo(attn_output)

        return output, present_kv


# ================================================================
# 完整推理循环（带 KV Cache vs 不带）
# ================================================================

def inference_with_cache(model, input_ids, max_new_tokens=50):
    """
    带 KV Cache 的推理
    计算量：Prefill O(S²) + Decode O(S) per step
    """
    device = next(model.parameters()).device
    model.eval()

    past_kv = None
    generated = input_ids.clone()

    # =============================
    # Prefill 阶段
    # =============================

    # 处理整个 prompt
    with torch.no_grad():
        # 第一次 forward：prefill 整个 prompt
        # 返回 KV cache 供后续 decode 使用
        hidden = torch.randn(1, input_ids.shape[1], model.hidden_dim, device=device)
        _, past_kv = model(hidden, past_kv=None, use_cache=True)

    # =============================
    # Decode 阶段（逐 token 生成）
    # =============================

    for step in range(max_new_tokens):
        with torch.no_grad():
            # 每次只创建 1 个新 token 的 hidden（模拟生成）
            new_hidden = torch.randn(1, 1, model.hidden_dim, device=device)

            # 传入 past_kv，只计算当前 token 的 QKV
            # 然后拼接到 cach
            output, past_kv = model(new_hidden, past_kv=past_kv, use_cache=True)

        # 模拟 token 选择（随机，因为这不是真正的语言模型）
        generated = torch.cat([generated, torch.randint(0, 1000, (1, 1))], dim=1)

    return generated, past_kv


def inference_without_cache(model, input_ids, max_new_tokens=50):
    """
    不带 KV Cache 的推理
    计算量：O(S²) per step，总共 O(S³)！
    """
    device = next(model.parameters()).device
    model.eval()

    generated = input_ids.clone()

    for step in range(max_new_tokens):
        seq_len = generated.shape[1]

        with torch.no_grad():
            # 每次都传入完整的 generated sequence
            # 这意味着每次都要重新计算所有 past token 的 K/V！
            hidden = torch.randn(1, seq_len, model.hidden_dim, device=device)
            output, _ = model(hidden, past_kv=None, use_cache=False)

        # 取最后一个 token 的 output
        # 注意：前面 seq_len-1 个位置的计算全浪费了！
        generated = torch.cat([generated, torch.randint(0, 1000, (1, 1))], dim=1)

    return generated


# ================================================================
# 计算量对比分析
# ================================================================

def compare_computation():
    """
    对比有/无 KV Cache 的计算量

    假设模型 LLaMA-7B: H=32, D=128, L=32
    """
    print("=" * 60)
    print("KV Cache 计算量对比分析")
    print("=" * 60)

    # 参数
    H = 32   # num heads
    D = 128  # head dim
    L = 32   # num layers
    S = 4096  # prefill seq len
    T = 128   # generate 128 new tokens

    print(f"\n模型参数: {L} layers, {H} heads, D={D}")
    print(f"Prefill length: {S}, Generate tokens: {T}")

    # =============================
    # 每个 token 的 Attention FLOPs
    # =============================

    # Attention per layer = Q@K^T (2*H*S*D) + P@V (2*H*S*D)
    # 忽略 softmax（占比很小）

    # 方式 1：无 KV Cache
    # Step t: 序列长度 = S + t
    # FLOPs_step[t] = 4 * H * D * (S + t)^2
    flops_no_cache = 0
    for t in range(T):
        seq_len = S + t
        flops_no_cache += 4 * H * D * seq_len * seq_len
    flops_no_cache *= L  # 所有层

    # 方式 1 总 FLOPs（等价公式）
    # sum_{t=0}^{T-1} (S+t)^2 = T*S^2 + S*T*(T-1) + T*(T-1)*(2T-1)/6

    # 方式 2：有 KV Cache
    # Prefill: 4 * H * D * S^2
    flops_cache = 4 * H * D * S * S  # prefill

    # Decode step t: 序列长度 = S + t
    # 但只需要计算当前 token 的 Q，然后和完整的 K/V 做 attention
    # FLOPs_step[t] = 4 * H * D * (S + t)  (因为 Sq=1)
    for t in range(T):
        seq_len = S + t
        flops_cache += 4 * H * D * seq_len  # Sq=1!
    flops_cache *= L

    print(f"\n总 Attention FLOPs（{L} layers）:")
    print(f"  无 KV Cache: {flops_no_cache/1e12:.2f} TFLOPs")
    print(f"  有 KV Cache: {flops_cache/1e12:.2f} TFLOPs")
    print(f"  加速比: {flops_no_cache/flops_cache:.1f}x")

    # 具体看 Decode 阶段
    flops_decode_no_cache = 0
    flops_decode_cache = 0
    for t in range(T):
        seq_len = S + t
        flops_decode_no_cache += 4 * H * D * seq_len * seq_len
        flops_decode_cache += 4 * H * D * seq_len

    flops_decode_no_cache *= L
    flops_decode_cache *= L

    print(f"\nDecode 阶段 FLOPs（仅 T={T} 个生成步）:")
    print(f"  无 KV Cache: {flops_decode_no_cache/1e12:.2f} TFLOPs（每次扩增序列长度）")
    print(f"  有 KV Cache: {flops_decode_cache/1e12:.2f} TFLOPs（每次 Sq=1）")
    print(f"  Decode 加速: {flops_decode_no_cache/flops_decode_cache:.1f}x")

    # =============================
    # 显存对比
    # =============================

    kv_bytes = 2 * L * H * (S + T) * D * 2  # FP16

    print(f"\nKV Cache 显存（FP16, seq_len={S+T}）:")
    print(f"  {kv_bytes / 1024**3:.2f} GB")

    print(f"\n{'=' * 60}")


# ================================================================
# main
# ================================================================

if __main__ == "__main__":
    # 创建模型
    hidden_dim = 512
    num_heads = 8
    model = SimpleAttentionLayer(hidden_dim, num_heads)

    # 测试 forward
    batch, seq_len = 1, 4
    x = torch.randn(batch, seq_len, hidden_dim)
    output, kv = model(x, past_kv=None, use_cache=True)
    print(f"单次 forward 输出形状: {list(output.shape)}")
    print(f"KV cache 形状: K={list(kv[0].shape)}, V={list(kv[1].shape)}")

    # 测试 Decode（单个 token）
    x2 = torch.randn(1, 1, hidden_dim)
    output2, kv2 = model(x2, past_kv=kv, use_cache=True)
    print(f"Decode 输出形状: {list(output2.shape)}")
    print(f"更新后 KV cache: K={list(kv2[0].shape)}（长度增加 1）")

    # 计算量对比
    compare_computation()

    print("\n完成!")
