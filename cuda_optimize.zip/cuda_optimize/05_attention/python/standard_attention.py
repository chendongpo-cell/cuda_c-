"""
standard_attention.py — Scaled Dot-Product Attention 实现与性能分析

知识点覆盖：
  ✅ Standard Attention 的 PyTorch 实现（每行注释）
  ✅ 计算量与显存估算函数
  ✅ Prefill vs Decode 模式对比
  ✅ 性能 Profiling（torch.cuda.Event 计时）
  ✅ 推理场景分析

运行：python standard_attention.py
"""

import torch
import torch.nn.functional as F
import math
import time


# ================================================================
# 1. Standard Scaled Dot-Product Attention
# ================================================================

def standard_attention(q, k, v, mask=None):
    """
    Scaled Dot-Product Attention（Vaswani et al., 2017）

    Args:
        q: [batch, heads, seq_q, d_k] — Query
        k: [batch, heads, seq_k, d_k] — Key
        v: [batch, heads, seq_k, d_v] — Value
        mask: [batch, 1, seq_q, seq_k] — 因果 mask（可选）
              True 的位置表示被 mask 掉

    Returns:
        output: [batch, heads, seq_q, d_v]
        attention_weights: [batch, heads, seq_q, seq_k]
    """
    # 获取 head dimension
    d_k = q.size(-1)

    # ==============================
    # Step 1: Q @ K^T → 计算相似度分数
    #
    # q: [B, H, Sq, D]
    # k: [B, H, Sk, D]
    # k.transpose(-2, -1): [B, H, D, Sk]
    # matmul: [B, H, Sq, D] @ [B, H, D, Sk] → [B, H, Sq, Sk]
    # 每个 query head 的每个 query token，有 Sk 个分数
    # =============================
    score = torch.matmul(q, k.transpose(-2, -1))

    # ==============================
    # Step 2: Scale — 缩放分数
    #
    # 除以 √d_k 的数学原因：
    #   假设 q 和 k 的分量独立分布为 N(0, 1)
    #   则 q·k 的方差 = d_k
    #   除以 √d_k 后方差回到 1
    #   防止 softmax 进入梯度饱和区（太大 → one-hot，太小 → uniform）
    # =============================
    score = score / math.sqrt(d_k)

    # ==============================
    # Step 3: Apply causal mask（可选）
    #
    # 在 prefill 阶段需要 causal mask：token 不能 attention 后面的 token
    # mask=True 的位置用 -inf 填充，softmax 后为 0
    # =============================
    if mask is not None:
        # mask 形状: [batch, 1, seq_q, seq_k]
        # True → 用 -inf（softmax 后为 0）
        score = score.masked_fill(mask, float('-inf'))

    # ==============================
    # Step 4: Softmax — 归一化成权重
    #
    # dim=-1: 在 seq_k 维度上做 softmax
    # 每个 query token 的 Sk 个分数之和 = 1（因果 mask 让 future 的位置 = 0）
    # =============================
    attention_weights = F.softmax(score, dim=-1)

    # ==============================
    # Step 5: P @ V → 加权求和得到输出
    #
    # [B, H, Sq, Sk] @ [B, H, Sk, D] → [B, H, Sq, D]
    # 每个输出位置是 V 中所有 token 的加权和（权重来自 softmax）
    # =============================
    output = torch.matmul(attention_weights, v)

    return output, attention_weights


# ================================================================
# 2. Prefill 模式（批量处理 prompt 中的所有 token）
# ================================================================

def prefill_attention(q, k, v, seq_len):
    """
    Prefill 阶段的 attention

    Prefill 特征：
      - Sq = Sk = seq_len（处理完整序列）
      - 需要 causal mask（token 看不到后面的 token）
      - Compute-bound！因为大量矩阵乘（GEMM）
    """
    # 生成上三角 mask：每个 token 只能看自己及之前的 token
    # mask 形状: [seq_len, seq_len]
    # 例如 seq_len=3:  [[False, True, True],
    #                   [False, False, True],
    #                   [False, False, False]]
    # True = 被 mask 掉
    mask = torch.triu(
        torch.ones(seq_len, seq_len, dtype=torch.bool, device=q.device),
        diagonal=1  # diagonal=1: 从第 1 个对角线上方开始
    )
    # 扩展为 [1, 1, seq_len, seq_len]
    mask = mask.unsqueeze(0).unsqueeze(0)

    output, weights = standard_attention(q, k, v, mask)
    return output, weights


# ================================================================
# 3. Decode 模式（逐 token 推理）
# ================================================================

def decode_attention(q, k_cache, v_cache):
    """
    Decode 阶段的 attention

    Decode 特征：
      - Sq = 1（每次只生成一个 token）
      - Sk = current_seq_len（包括之前的 KV cache 和当前 token）
      - 不需要 causal mask！因为 Sk 只有当前及之前的 token
      - Memory-bound！因为要读取整个 KV cache
    """
    # 解码时 q 长度=1，k_cache 已经包含所有之前的 token
    # 不需要 mask 因为模型是自回归的，当前 token 后面没有内容
    output, weights = standard_attention(q, k_cache, v_cache, mask=None)
    return output, weights


# ================================================================
# 4. 模拟 KV Cache 推理过程
# ================================================================

def simulate_kv_cache_attention():
    """
    模拟带 KV Cache 的 Attention 计算过程
    展示 cache 如何累积
    """
    print("=" * 60)
    print("模拟 KV Cache 推理")
    print("=" * 60)

    B, H, D = 1, 2, 4  # 小参数
    prompt_len = 4      # prompt 长度

    # 模拟输入
    q = torch.randn(B, H, 1, D)        # 当前 token 的 Q
    k_initial = torch.randn(B, H, 1, D)  # 当前 token 的 K
    v_initial = torch.randn(B, H, 1, D)  # 当前 token 的 V

    # 初始化 KV cache（用之前的 prompt 生成）
    # 模拟 prompt 有 prompt_len 个 token
    k_cache = torch.randn(B, H, prompt_len, D)
    v_cache = torch.randn(B, H, prompt_len, D)

    print(f"\n初始 KV cache 形状: {list(k_cache.shape)}")
    print(f"  包含 {prompt_len} 个 prompt token 的 K/V")

    # ==============================
    # 第 1 个 decode 步
    # =============================

    print(f"\n--- Decode step 1 ---")
    print(f"  当前 Q 形状: {list(q.shape)}（1 个 new token）")

    # 用当前 Q 和全部 cache 做 attention
    output, weights = decode_attention(q, k_cache, v_cache)
    print(f"  Attention weights 形状: {list(weights.shape)}")
    print(f"    weights[0,0,0,:] = {weights[0,0,0,:].detach().numpy().round(2)}")
    print(f"    告诉我们对 {prompt_len} 个 token 的 attention 分布")

    # 更新 KV cache：把当前 token 的 K/V 加入 cache
    k_cache = torch.cat([k_cache, k_initial], dim=2)
    v_cache = torch.cat([v_cache, v_initial], dim=2)
    print(f"  更新后 cache 形状: {list(k_cache.shape)}（现在有 {prompt_len + 1} 个 token）")

    # ==============================
    # 第 2 个 decode 步（新的 token）
    # =============================

    print(f"\n--- Decode step 2 ---")
    q2 = torch.randn(B, H, 1, D)
    k2 = torch.randn(B, H, 1, D)
    v2 = torch.randn(B, H, 1, D)

    output2, _ = decode_attention(q2, k_cache, v_cache)
    print(f"  KV cache 现在有 {k_cache.size(2)} 个 token")
    print(f"  注意：Q 长度始终=1，但 KV cache 在增长！")

    # 更新 cache
    k_cache = torch.cat([k_cache, k2], dim=2)
    v_cache = torch.cat([v_cache, v2], dim=2)

    # ==============================
    # 关键观察
    # =============================

    print(f"\n{'=' * 60}")
    print(f"关键观察：")
    print(f"  1. Decode 时 Q 长度始终=1 → 计算量不变（O(Sk × D)）")
    print(f"  2. KV cache 线性增长 → 显存线性增长（每步 +O(D)）")
    print(f"  3. Decode 的计算强度 = 4×H×Sk×D / (H×D×(2×Sk+1)×2)")
    print(f"     ≈ 1 FLOP/BYTE → 带宽=瓶颈！")
    print(f"{'=' * 60}")


# ================================================================
# 5. 性能基准测试
# ================================================================

def benchmark_attention():
    """
    对比 Prefill 和 Decode 的性能特征
    使用 torch.cuda.Event 做精确计时
    """
    print("\n" + "=" * 60)
    print("Attention 性能基准测试")
    print("=" * 60)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"设备: {device}")

    B = 1
    H = 32        # LLaMA-7B 的 head 数
    D = 128       # head dimension

    # ==============================
    # 测试 Prefill（不同序列长度）
    # =============================

    print(f"\n--- Prefill 性能 ---")
    seq_lengths = [512, 1024, 2048, 4096]

    for seq_len in seq_lengths:
        q = torch.randn(B, H, seq_len, D, device=device)
        k = torch.randn(B, H, seq_len, D, device=device)
        v = torch.randn(B, H, seq_len, D, device=device)

        # warmup
        for _ in range(3):
            out, _ = prefill_attention(q, k, v, seq_len)
        torch.cuda.synchronize()

        # benchmark
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record()

        iters = 20
        for _ in range(iters):
            out, _ = prefill_attention(q, k, v, seq_len)
        end.record()
        torch.cuda.synchronize()

        elapsed_ms = start.elapsed_time(end) / iters

        # 计算 FLOPs
        # Q@K^T: 2*B*H*S*S*D
        # P@V:   2*B*H*S*S*D
        # Softmax: ~3*B*H*S*S
        total_flops = 2 * B * H * seq_len * seq_len * D * 2  # 两次矩阵乘
        total_flops += 3 * B * H * seq_len * seq_len          # softmax
        gflops = total_flops / elapsed_ms / 1e6

        # 估算 score 矩阵大小
        score_gb = B * H * seq_len * seq_len * 2 / (1024**3)  # FP16 bytes

        print(f"  S={seq_len:5d}  |  {elapsed_ms:8.3f} ms  |  {gflops:8.1f} GFLOPS  |  score={score_gb:.2f} GB")

    # ==============================
    # 测试 Decode（不同 cache 长度）
    # =============================

    print(f"\n--- Decode 性能 ---")
    cache_lengths = [1024, 2048, 4096, 8192, 16384]

    for cache_len in cache_lengths:
        # Q 长度=1
        q = torch.randn(B, H, 1, D, device=device)
        k_cache = torch.randn(B, H, cache_len, D, device=device)
        v_cache = torch.randn(B, H, cache_len, D, device=device)

        # warmup
        for _ in range(3):
            out, _ = decode_attention(q, k_cache, v_cache)
        torch.cuda.synchronize()

        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record()

        iters = 100
        for _ in range(iters):
            out, _ = decode_attention(q, k_cache, v_cache)
        end.record()
        torch.cuda.synchronize()

        elapsed_ms = start.elapsed_time(end) / iters

        # 计算吞吐（tokens/s）
        tokens_per_second = 1000 / elapsed_ms

        print(f"  cache={cache_len:5d}  |  {elapsed_ms*1000:8.2f} us  |  {tokens_per_second:8.0f} tok/s")

    print(f"\n注意：实际 Decode 还包含 GEMM 投影 + FFN，attention 只占一部分")


# ================================================================
# 6. 计算 Attention 的 FLOPs 和显存
# ================================================================

def analyze_attention_flops():
    """详细分析 Attention 的计算量分布"""
    print("\n" + "=" * 60)
    print("Attention 计算量详细分析")
    print("=" * 60)

    # LLaMA-7B 参数
    B, H, D = 1, 32, 128

    print(f"\n配置: B={B}, H={H}, D={D}")

    for seq_len in [4096, 8192, 16384, 32768]:
        print(f"\n--- 序列长度 S={seq_len} ---")

        # Softmax 的输入 = [B, H, S, S] → 约 3*S 个操作
        # 矩阵乘 Q@K^T: 2*B*H*D*S^2 FLOPs
        # 矩阵乘 P@V: 2*B*H*D*S^2 FLOPs
        flops_qk = 2 * B * H * D * seq_len * seq_len
        flops_pv = 2 * B * H * D * seq_len * seq_len
        flops_softmax = 3 * B * H * seq_len * seq_len
        total_flops = flops_qk + flops_pv + flops_softmax

        # 显存占用（FP16）
        score_bytes = B * H * seq_len * seq_len * 2
        total_memory = score_bytes

        print(f"  Q@K^T FLOPs:  {flops_qk/1e12:.2f} T")
        print(f"  P@V FLOPs:    {flops_pv/1e12:.2f} T")
        print(f"  Softmax:      {flops_softmax/1e12:.2f} T")
        print(f"  总 FLOPs:     {total_flops/1e12:.2f} T")
        print(f"  Score 矩阵:   {total_memory/1024**3:.2f} GB")
        print(f"  (NVIDIA A100: 80GB, 312 TFLOPS FP16)")


# ================================================================
# main
# ================================================================

if __name__ == "__main__":
    print("PyTorch version:", torch.__version__)
    print("CUDA available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("CUDA device:", torch.cuda.get_device_name(0))

    # 1. 模拟 KV Cache 推理过程
    simulate_kv_cache_attention()

    # 2. 性能基准测试
    if torch.cuda.is_available():
        benchmark_attention()
    else:
        print("\n跳过 GPU benchmark（无 CUDA 设备）")

    # 3. FLOPs 分析（不需要 GPU）
    analyze_attention_flops()

    print("\n完成!")
