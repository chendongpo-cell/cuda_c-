﻿"""
prefix_caching_demo.py — Prefix Caching 简化教学版

演示 [docs/20_prefix_caching.md](../docs/20_prefix_caching.md) 的核心思想:
- 把 KV Cache 按 block 分块
- 用 hash(block_tokens + prev_hash) 做 block 级 fingerprint
- 跨请求复用相同 prefix 的 block

这是 vLLM APC (Automatic Prefix Caching) 的最小化实现。
真实 vLLM 用 C++ + CUDA 实现, 这里用纯 Python 演示逻辑。

学习目标:
    1. 理解 block 级哈希怎么算
    2. 理解跨请求怎么命中
    3. 理解部分命中怎么处理 (最后一个 block 没对齐)
    4. 跑一遍看命中率

运行:
    cd 05_attention/python
    python prefix_caching_demo.py
"""

import hashlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import torch


# ============================================================
# 数据结构
# ============================================================

@dataclass
class KVBlock:
    """
    一个 KV Cache 物理块

    真实 vLLM 里, 这个块存在 GPU 显存的大 buffer 里, 通过 block_id 索引
    这里简化用 Python 对象模拟
    """
    block_id: int                       # 物理 block 编号 (唯一)
    token_ids: List[int]                # 这个块包含的 token (block_size 个)
    kv_data: torch.Tensor               # 假的 KV 数据, shape [block_size, num_heads, head_dim]
    hash_key: str                       # 这个块的指纹 (用于命中查找)
    ref_count: int = 0                  # 多少请求在引用 (LRU 用)


class PrefixCache:
    """
    Prefix Cache 核心

    工作流程:
        1. 来一个 prompt
        2. 按 block_size 切分
        3. 每个 block 算 hash(tokens + prev_hash)
        4. 查 pool, 命中就复用, 不命中就停下 (后面全不命中)
        5. 返回命中 blocks + 需要新算的 token 区间
        6. 新算完后, 把新 block 存入 pool
    """

    def __init__(
        self,
        block_size: int = 4,            # 每 block 多少 token (vLLM 默认 16)
        num_heads: int = 4,
        head_dim: int = 16,
        max_blocks: int = 1000,         # 物理块池上限
    ):
        self.block_size = block_size
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.max_blocks = max_blocks

        # 物理 block 池 (block_id -> KVBlock)
        self.blocks: Dict[int, KVBlock] = {}
        # hash -> block_id 的索引 (快速查找)
        self.hash_to_block: Dict[str, int] = {}
        # 下一个可用的 block_id
        self.next_block_id = 0

        # 统计
        self.query_count = 0
        self.block_hit_count = 0
        self.block_total_count = 0

    def _hash_block(
        self,
        token_ids: List[int],
        prev_hash: Optional[str],
    ) -> str:
        """
        计算一个 block 的 hash

        关键: hash 包含 prev_hash, 这样保证链式一致性
        如果前面任何一个 token 不同, prev_hash 不同, 当前 hash 也不同
        """
        key = f"{prev_hash or 'root'}|{'-'.join(map(str, token_ids))}"
        return hashlib.md5(key.encode()).hexdigest()

    def lookup(self, prompt: List[int]) -> Tuple[List[int], List[Tuple[int, int]]]:
        """
        查询: 给定 prompt, 返回命中信息和需要新算的区间

        返回:
            hit_block_ids: 命中的物理 block id 列表 (按顺序)
            miss_ranges: 需要新算的 token 区间 [(start, end), ...]

        算法:
            沿着 prompt 走, 每 block_size 个 token 算 hash
            查 pool, 命中就复用
            一旦未命中就停下 (因为后续 hash 依赖前面)
        """
        self.query_count += 1
        hit_block_ids = []
        miss_ranges = []

        prev_hash = None
        pos = 0

        while pos + self.block_size <= len(prompt):
            block_tokens = prompt[pos:pos + self.block_size]
            block_hash = self._hash_block(block_tokens, prev_hash)

            self.block_total_count += 1

            if block_hash in self.hash_to_block:
                # 命中! 复用
                block_id = self.hash_to_block[block_hash]
                hit_block_ids.append(block_id)
                self.blocks[block_id].ref_count += 1
                self.block_hit_count += 1
                prev_hash = block_hash
                pos += self.block_size
            else:
                # 未命中, 后面全不命中
                break

        # 剩下的 token (包括未命中 block 的起点 + 末尾不满 block 的部分)
        if pos < len(prompt):
            miss_ranges.append((pos, len(prompt)))

        return hit_block_ids, miss_ranges

    def store(
        self,
        token_ids: List[int],
        prev_hash: Optional[str] = None,
    ) -> List[Tuple[str, KVBlock]]:
        """
        新算了一批 token, 把它们按 block_size 切分存入 cache

        返回: [(block_hash, KVBlock), ...]
        """
        stored = []
        cur_prev_hash = prev_hash
        pos = 0

        while pos + self.block_size <= len(token_ids):
            block_tokens = token_ids[pos:pos + self.block_size]
            block_hash = self._hash_block(block_tokens, cur_prev_hash)

            if block_hash not in self.hash_to_block:
                # 新 block, 存入池
                if len(self.blocks) >= self.max_blocks:
                    self._evict()

                block_id = self.next_block_id
                self.next_block_id += 1

                # 生成假 KV 数据 (真实系统是模型 forward 算出来的)
                kv_data = torch.randn(
                    self.block_size, self.num_heads, self.head_dim
                )

                block = KVBlock(
                    block_id=block_id,
                    token_ids=block_tokens.copy(),
                    kv_data=kv_data,
                    hash_key=block_hash,
                    ref_count=1,
                )
                self.blocks[block_id] = block
                self.hash_to_block[block_hash] = block_id
                stored.append((block_hash, block))
            else:
                # 已经存在 (理论不会, 因为 lookup 时已经命中过)
                block_id = self.hash_to_block[block_hash]
                self.blocks[block_id].ref_count += 1
                stored.append((block_hash, self.blocks[block_id]))

            cur_prev_hash = block_hash
            pos += self.block_size

        # 末尾不满 block_size 的部分: 不存 (下次来时如果对齐了再存)
        # 真实 vLLM 会把这部分暂时挂在最后一个 block 上, 简化版忽略
        return stored

    def release(self, block_ids: List[int]) -> None:
        """请求结束时, 减少引用计数"""
        for bid in block_ids:
            if bid in self.blocks:
                self.blocks[bid].ref_count = max(0, self.blocks[bid].ref_count - 1)

    def _evict(self) -> None:
        """LRU 淘汰一个 block (ref_count==0 且最少使用)"""
        # 简化: 找 ref_count==0 的随便删一个
        for bid, block in list(self.blocks.items()):
            if block.ref_count == 0:
                del self.blocks[bid]
                del self.hash_to_block[block.hash_key]
                return
        # 如果都还在用, 强制删最早的 (不安全, 教学用)
        if self.blocks:
            bid = next(iter(self.blocks))
            block = self.blocks[bid]
            del self.blocks[bid]
            del self.hash_to_block[block.hash_key]

    def stats(self) -> dict:
        """返回统计信息"""
        hit_rate = (
            self.block_hit_count / max(self.block_total_count, 1)
        )
        return {
            "queries": self.query_count,
            "block_pool_size": len(self.blocks),
            "block_hit_rate": f"{hit_rate:.1%}",
            "block_hits": self.block_hit_count,
            "block_total": self.block_total_count,
        }


# ============================================================
# 演示场景
# ============================================================

def demo_basic_hit():
    """场景 1: 两个请求共享 system prompt"""
    print("\n" + "=" * 60)
    print("场景 1: 共享 system prompt")
    print("=" * 60)

    cache = PrefixCache(block_size=4)

    system_prompt = [100, 101, 102, 103, 104, 105, 106, 107]  # 8 tokens = 2 blocks
    user1 = [200, 201, 202, 203]
    user2 = [300, 301, 302, 303]

    # 请求 1: 完整 prefill (无 cache)
    prompt1 = system_prompt + user1
    hits, misses = cache.lookup(prompt1)
    print(f"\n请求 1: {prompt1}")
    print(f"  命中 blocks: {hits}  (预期: 空)")
    print(f"  未命中区间: {misses}  (预期: [(0, 12)])")
    cache.store(prompt1)

    # 请求 2: 共享 system prompt, 应命中前 2 个 block
    prompt2 = system_prompt + user2
    hits, misses = cache.lookup(prompt2)
    print(f"\n请求 2: {prompt2}")
    print(f"  命中 blocks: {hits}  (预期: 2 个, system prompt 复用)")
    print(f"  未命中区间: {misses}  (预期: [(8, 12)] 只算 user2)")
    cache.store(prompt2)

    # 请求 3: 完全一样的 prompt (全命中)
    hits, misses = cache.lookup(prompt1)
    print(f"\n请求 3: {prompt1} (和请求 1 一样)")
    print(f"  命中 blocks: {hits}  (预期: 3 个, 全部命中)")
    print(f"  未命中区间: {misses}  (预期: 空)")

    print(f"\n统计: {cache.stats()}")


def demo_multi_turn():
    """场景 2: 多轮对话, 每轮复用前面的 KV"""
    print("\n" + "=" * 60)
    print("场景 2: 多轮对话")
    print("=" * 60)

    cache = PrefixCache(block_size=4)

    # 模拟 3 轮对话
    turns = [
        [1, 2, 3, 4, 5, 6, 7, 8],        # 第 1 轮 user + assistant
        [10, 11, 12, 13, 14, 15, 16],    # 第 2 轮
        [20, 21, 22, 23, 24],            # 第 3 轮
    ]

    accumulated = []
    for i, turn in enumerate(turns):
        accumulated.extend(turn)
        print(f"\n第 {i+1} 轮: 累计 prompt = {accumulated}")
        hits, misses = cache.lookup(accumulated)
        print(f"  命中 blocks: {len(hits)}")
        print(f"  未命中区间: {misses}")
        cache.store(accumulated)

    print(f"\n统计: {cache.stats()}")


def demo_no_sharing():
    """场景 3: 无 prefix 共享, 命中率应该低"""
    print("\n" + "=" * 60)
    print("场景 3: 无 prefix 共享")
    print("=" * 60)

    cache = PrefixCache(block_size=4)

    # 5 个完全不同的 prompt
    prompts = [
        [1, 2, 3, 4, 5, 6, 7, 8],
        [10, 20, 30, 40, 50, 60, 70, 80],
        [11, 22, 33, 44, 55, 66, 77, 88],
        [100, 200, 300, 400, 500, 600, 700, 800],
        [9, 8, 7, 6, 5, 4, 3, 2],
    ]

    for i, p in enumerate(prompts):
        hits, misses = cache.lookup(p)
        print(f"请求 {i+1}: 命中 {len(hits)} blocks")
        cache.store(p)

    print(f"\n统计: {cache.stats()}")
    print("(预期: 命中率接近 0, 因为无共享)")


def demo_partial_block_miss():
    """场景 4: block 边界不对齐导致部分未命中"""
    print("\n" + "=" * 60)
    print("场景 4: block 边界不对齐")
    print("=" * 60)

    cache = PrefixCache(block_size=4)

    # 请求 1: 8 个 token, 刚好 2 个 block
    prompt1 = [1, 2, 3, 4, 5, 6, 7, 8]
    cache.lookup(prompt1)
    cache.store(prompt1)
    print(f"请求 1: {prompt1}")

    # 请求 2: 前 9 个 token 和请求 1 前 8 个相同, 但多 1 个
    # 第 3 个 block 只有 1 个 token, 不满, 不缓存
    prompt2 = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    hits, misses = cache.lookup(prompt2)
    print(f"请求 2: {prompt2}")
    print(f"  命中 blocks: {len(hits)}  (预期: 2, 前 8 token 复用)")
    print(f"  未命中区间: {misses}  (预期: [(8, 9)], 只算第 9 个 token)")

    # 请求 3: 前 9 个相同, 再加 3 个让第 3 个 block 满
    prompt3 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    cache.lookup(prompt3)
    cache.store(prompt3)
    print(f"\n请求 3: {prompt3} 存入 cache")

    # 请求 4: 前 12 个完全相同, 应全命中
    prompt4 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    hits, misses = cache.lookup(prompt4)
    print(f"请求 4: {prompt4}")
    print(f"  命中 blocks: {len(hits)}  (预期: 3, 全部命中)")


# ============================================================
# 主入口
# ============================================================

if __name__ == "__main__":
    print("╔" + "═" * 60 + "╗")
    print("║" + " Prefix Caching 教学版演示 ".center(58) + "║")
    print("╚" + "═" * 60 + "╝")

    demo_basic_hit()
    demo_multi_turn()
    demo_no_sharing()
    demo_partial_block_miss()

    print("\n" + "=" * 60)
    print("结论:")
    print("  1. 共享 prefix 的请求能命中前面算过的 block")
    print("  2. 多轮对话每轮都复用前面的 KV")
    print("  3. 无共享场景命中率低, 但开销也小")
    print("  4. block_size 决定命中粒度, 越小越精细但开销大")
    print("=" * 60)
