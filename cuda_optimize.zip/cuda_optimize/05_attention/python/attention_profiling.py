"""
attention_profiling.py — Attention 性能 Profiling 工具

功能：
  ✅ 使用 PyTorch Profiler 分析 attention 各操作耗时
  ✅ CUDA Event 精确计时
  ✅ 计算强度分析（arithmetic intensity）
  ✅ 带宽利用率估算

运行：python attention_profiling.py
"""

import torch
import torch.nn.functional as F
import math
import time


# ================================================================
# 1. Profiling 用 Attention 函数
# ================================================================

def profile_attention(B, H, Sq, Sk, D, use_causal_mask=True):
    """
    构建 attention 计算图并做 profiling

    Args:
        B: batch size
        H: num heads
        Sq: query sequence length
        Sk: key/value sequence length
        D: head dimension
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    q = torch.randn(B, H, Sq, D, device=device, requires_grad=True)
    k = torch.randn(B, H, Sk, D, device=device)
    v = torch.randn(B, H, Sk, D, device=device)

    # =============================
    # Forward pass
    # =============================

    # Q@K^T
    score = torch.matmul(q, k.transpose(-2, -1))

    # Scale
    score = score / math.sqrt(D)

    # Mask（causal）
    if use_causal_mask and Sq == Sk:
        mask = torch.triu(
            torch.ones(Sq, Sk, dtype=torch.bool, device=device),
            diagonal=1
        ).unsqueeze(0).unsqueeze(0)
        score = score.masked_fill(mask, float('-inf'))

    # Softmax
    attn_weights = F.softmax(score, dim=-1)

    # P@V
    output = torch.matmul(attn_weights, v)

    # =============================
    # Backward pass（计算梯度）
    # =============================

    if q.requires_grad:
        grad_output = torch.randn_like(output)
        output.backward(grad_output)

    return output


# ================================================================
# 2. PyTorch Profiler 分析
# ================================================================

def run_profiler():
    """使用 PyTorch Profiler 分析 attention 各操作的耗时"""

    if not torch.cuda.is_available():
        print("CUDA 不可用，跳过 profiler")
        return

    print("=" * 60)
    print("PyTorch Profiler — Attention 操作分解")
    print("=" * 60)

    B, H, D = 1, 32, 128
    S = 4096

    q = torch.randn(B, H, S, D, device='cuda', requires_grad=True)
    k = torch.randn(B, H, S, D, device='cuda')
    v = torch.randn(B, H, S, D, device='cuda')

    with torch.profiler.profile(
        activities=[
            torch.profiler.ProfilerActivity.CUDA,
            torch.profiler.ProfilerActivity.CPU,
        ],
        # 按 CUDA time 排序
        record_shapes=True,
        with_stack=True,
    ) as prof:
        for _ in range(10):
            out = profile_attention(B, H, S, S, D)

    # 打印 CPU 耗时最多的操作
    print("\nCPU 耗时 Top 10:")
    print(prof.key_averages().table(sort_by="cpu_time_total", row_limit=10))

    # 打印 CUDA 耗时最多的操作
    print("\nCUDA 耗时 Top 10:")
    print(prof.key_averages().table(sort_by="cuda_time_total", row_limit=10))


# ================================================================
# 3. CUDA Event 精确计时
# ================================================================

def time_attention_operations():
    """对 attention 的每个子操作单独计时"""

    if not torch.cuda.is_available():
        print("CUDA 不可用，跳过计时")
        return

    print("\n" + "=" * 60)
    print("Attention 子操作耗时分解（CUDA Event）")
    print("=" * 60)

    B, H, D = 1, 32, 128
    devices = torch.device('cuda')

    for S in [1024, 2048, 4096, 8192]:
        q = torch.randn(B, H, S, D, device=device)
        k = torch.randn(B, H, S, D, device=device)
        v = torch.randn(B, H, S, D, device=device)

        mask = torch.triu(
            torch.ones(1, 1, S, S, dtype=torch.bool, device=device),
            diagonal=1
        )

        def time_op(fn, iters=50):
            """计时工具，返回平均 ms"""
            # warmup
            for _ in range(10):
                fn()
                torch.cuda.synchronize()

            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(iters):
                fn()
            end.record()
            torch.cuda.synchronize()
            return start.elapsed_time(end) / iters

        # Step 1: Q@K^T
        def qk():
            s = torch.matmul(q, k.transpose(-2, -1))

        # Step 2: Scale + Mask + Softmax
        sm = k.transpose(-2, -1)
        def softmax_part():
            s = torch.matmul(q, sm) / math.sqrt(D)
            s = s.masked_fill(mask, float('-inf'))
            w = F.softmax(s, dim=-1)

        # Step 3: P@V
        pv_qk = torch.matmul(q, sm) / math.sqrt(D)
        pv_w = F.softmax(pv_qk.masked_fill(mask, float('-inf')), dim=-1).detach()
        def pv():
            o = torch.matmul(pv_w, v)

        t_qk = time_op(qk)
        t_softmax = time_op(softmax_part)
        t_pv = time_op(pv)

        total = t_qk + t_softmax + t_pv
        print(f"\n  S={S:5d}:")
        print(f"    Q@K^T:    {t_qk:8.3f} ms ({t_qk/total*100:5.1f}%)")
        print(f"    Softmax:  {t_softmax:8.3f} ms ({t_softmax/total*100:5.1f}%)")
        print(f"    P@V:      {t_pv:8.3f} ms ({t_pv/total*100:5.1f}%)")
        print(f"    总耗时:   {total:8.3f} ms")


# ================================================================
# 4. 计算强度分析
# ================================================================

def analyze_arithmetic_intensity():
    """
    分析 Prefill 和 Decode 的计算强度

    Arithmetic Intensity = FLOPs / Bytes
    - < 10: Memory-bound
    - > 100: Compute-bound
    - A100 FP16: 峰值 312 TFLOPS, 带宽 2 TB/s
    - Roofline 分界点: 312/2 ≈ 156 FLOPs/Byte
    """
    print("\n" + "=" * 60)
    print("计算强度分析 (Arithmetic Intensity)")
    print("=" * 60)

    B, H, D = 1, 32, 128

    # Prefill: Sq = Sk = S
    print(f"\n--- Prefill (Sq=Sk=S) ---")
    print(f"{'S':>6} | {'FLOPs':>12} | {'Bytes read':>12} | {'AI':>8} | {'Bound by':>10}")
    print("-" * 56)

    for S in [1024, 4096, 16384, 65536]:
        # FLOPs = 4 * B * H * D * S^2 (Q@K^T + P@V)
        flops = 4 * B * H * D * S * S

        # Bytes read = Q(B*H*S*D*2) + K + V = 3 * B * H * S * D * 2
        # Q 和 Score 写读各一次，K/V 各一次 = 简化计
        bytes_read = 3 * B * H * S * D * 2 + 2 * B * H * S * S * 2
        # 更精确：Q(读) + K(读) + V(读) + Score(写+读) + Output(写)
        # Score: [B,H,S,S]*2(FP) * 2(写+读)
        bytes_read = B * H * S * D * 2 + 2 * B * H * S * D * 2  # Q+K+V 读
        bytes_read += 2 * B * H * S * S * 2   # Score 写+读
        bytes_read += B * H * S * D * 2        # Output 写

        ai = flops / bytes_read if bytes_read > 0 else 0
        bound = "Compute" if ai > 100 else "Memory"

        print(f"{S:6d} | {flops/1e9:10.1f}G | {bytes_read/1024**3:10.2f}GB | {ai:7.1f} | {bound:>10}")

    # Decode: Sq=1, Sk=S
    print(f"\n--- Decode (Sq=1, Sk=S) ---")
    print(f"{'S':>6} | {'FLOPs':>12} | {'Bytes read':>12} | {'AI':>8} | {'Bound by':>10}")
    print("-" * 56)

    for S in [1024, 4096, 16384, 65536]:
        # FLOPs = 4 * B * H * D * S  (Sq=1!)
        flops = 4 * B * H * D * S

        # Bytes: Q(读) + K(读全量) + V(读全量) + Score(写+读) + Output(写)
        bytes_read = B * H * 1 * D * 2   # Q
        bytes_read += 2 * B * H * S * D * 2  # K + V (从 cache 读取)
        bytes_read += 2 * B * H * 1 * S * 2  # Score
        bytes_read += B * H * 1 * D * 2   # Output

        ai = flops / bytes_read if bytes_read > 0 else 0
        bound = "Compute" if ai > 100 else "Memory"

        print(f"{S:6d} | {flops/1e9:10.1f}G | {bytes_read/1024**3:10.2f}GB | {ai:7.1f} | {bound:>10}")

    print(f"\n结论: Decode 总是 memory-bound！因为 Sq=1 导致 FLOPs 很小")
    print(f"      而需要读取全量 K/V cache（O(S)）")
    print(f"      所以 Decode 优化的关键是减少内存访问量")

    # 理论最大 tok/s
    print(f"\n--- 理论最大 Decode 吞吐 ---")
    print(f"A100 80GB: ~2 TB/s HBM2e 带宽")
    print(f"每个 token 需要读取 {2*H*D*2} bytes/head * {32} heads = {2*32*128*2} 字节 per layer")
    for S in [4096, 8192, 32768]:
        bytes_per_token = 2 * 32 * 128 * S * 2  # K+V cache, FP16
        max_tok_s = (2e12 / bytes_per_token)  # 2TB/s 带宽
        print(f"  S={S:5d}: {max_tok_s:.0f} tok/s (理论上限)")


# ================================================================
# main
# ================================================================

if __name__ == "__main__":
    # 1. PyTorch Profiler
    run_profiler()

    # 2. CUDA Event 计时
    time_attention_operations()

    # 3. 计算强度分析
    analyze_arithmetic_intensity()
