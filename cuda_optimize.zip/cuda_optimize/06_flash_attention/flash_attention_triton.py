"""
FlashAttention 的 Triton 实现 —— 前向传播
=============================================
本文件实现了 FlashAttention 的前向传播算子，使用 Triton 编写。
参考了 Triton 官方教程 (https://triton-lang.org/main/getting-started/tutorials/06-fused-attention.html)。

核心思想：
  - 将 Q/K/V 沿序列维度分块（tiling），每个块在 SRAM 中完成所有计算
  - 使用 Online Softmax（running max + running sum）避免写出完整的 N×N 注意力矩阵
  - 大幅减少 HBM 访问，实现长序列下的高性能 Attention

对比基准：
  - PyTorch 原生 attention（torch.nn.functional.scaled_dot_product_attention）
  - 比较前向耗时和数值精度

依赖：torch, triton
"""

import torch
import torch.nn.functional as F
import triton
import triton.language as tl
import time
import math


# ==============================================================================
# Triton 内核：FlashAttention 前向传播
# ==============================================================================

@triton.jit
def _flash_attention_fwd_kernel(
    # 指针参数：Q, K, V, O 的基地址
    q_ptr, k_ptr, v_ptr, o_ptr,
    # 步长（stride）：用于计算每个元素的偏移量
    batch_stride_q, head_stride_q, seq_stride_q, d_stride_q,
    batch_stride_k, head_stride_k, seq_stride_k, d_stride_k,
    batch_stride_v, head_stride_v, seq_stride_v, d_stride_v,
    batch_stride_o, head_stride_o, seq_stride_o, d_stride_o,
    # 维度信息
    N, d,                     # N = 序列长度, d = 头维度
    B_r: tl.constexpr,        # Q 块大小（沿序列行方向）
    B_c: tl.constexpr,        # K/V 块大小（沿序列列方向）
    d_rem: tl.constexpr,      # d 是否是不完整的最后一个块（一般不需要）
):
    """
    FlashAttention 前向传播的 Triton 内核。

    处理一个 batch 中的一个 head：
    - pid_batch = tl.program_id(0)  # batch 索引
    - pid_head  = tl.program_id(1)  # head 索引
    - pid_blk   = tl.program_id(2)  # Q 块索引（沿序列维度）

    内存布局说明：
    Q, K, V, O 的形状均为 [batch_size, num_heads, N, d]。
    每个元素的地址 = base + batch_id * batch_stride + head_id * head_stride + seq_id * seq_stride + d_id * d_stride
    """
    # --------------------------------------------------------------------------
    # 1. 计算当前程序对应的 batch, head 和 Q 块索引
    # --------------------------------------------------------------------------
    pid_batch = tl.program_id(0)   # batch 索引
    pid_head = tl.program_id(1)    # head 索引
    pid_blk = tl.program_id(2)     # 当前处理的 Q 块索引（第几个 Q 块）

    # 计算当前 Q 块的起始位置
    q_blk_start = pid_blk * B_r    # 当前 Q 块的起始序列位置
    q_blk_offsets = q_blk_start + tl.arange(0, B_r)  # Q 块内的序列偏移 [B_r]
    q_blk_mask = q_blk_offsets < N  # 边界检查（处理最后一个可能不完整的块）

    # --------------------------------------------------------------------------
    # 2. 加载当前 Q 块数据
    # --------------------------------------------------------------------------
    # Q 的序列偏移：q_blk_offsets[:, None]  扩展为 [B_r, 1]
    # Q 的 d 维度偏移：[0, 1, ..., d-1]     扩展为 [1, d]
    # 组合得到 Q 块：形状 [B_r, d]
    q_offsets = (
        pid_batch * batch_stride_q
        + pid_head * head_stride_q
        + q_blk_offsets[:, None] * seq_stride_q
        + tl.arange(0, d)[None, :] * d_stride_q
    )
    # 加载 Q：mask 确保不越界
    q = tl.load(q_ptr + q_offsets, mask=q_blk_mask[:, None], other=0.0).to(tl.float32)

    # 计算 1/sqrt(d)，用于缩放得分矩阵
    scale = 1.0 / tl.sqrt(tl.cast(d, tl.float32))

    # --------------------------------------------------------------------------
    # 3. 初始化 Online Softmax 的状态变量
    # --------------------------------------------------------------------------
    # m: 运行最大值 (running max)，初始化为 -inf
    m_i = tl.full([B_r], float("-inf"), dtype=tl.float32)
    # l: 运行和 (running sum of exp)，初始化为 0
    l_i = tl.full([B_r], 0.0, dtype=tl.float32)
    # O_i: 部分输出，初始化为 0
    # 形状 [B_r, d]
    acc_o = tl.zeros([B_r, d], dtype=tl.float32)

    # --------------------------------------------------------------------------
    # 4. 内层循环：遍历 K/V 块（沿序列维度）
    # --------------------------------------------------------------------------
    # 计算需要遍历的 K/V 块总数
    # 每个 K/V 块的大小为 B_c，需要遍历 ceil(N / B_c) 次
    num_kv_blocks = tl.cdiv(N, B_c)

    # 内层循环开始：遍历所有 K/V 块
    for blk_idx in range(0, num_kv_blocks):
        # 当前 K/V 块的起始位置
        kv_blk_start = blk_idx * B_c
        kv_blk_offsets = kv_blk_start + tl.arange(0, B_c)  # K/V 块内偏移 [B_c]
        kv_blk_mask = kv_blk_offsets < N  # 边界检查

        # ----------------------------------------------------------------------
        # 4a. 加载当前 K 块
        # ----------------------------------------------------------------------
        k_offsets = (
            pid_batch * batch_stride_k
            + pid_head * head_stride_k
            + kv_blk_offsets[:, None] * seq_stride_k
            + tl.arange(0, d)[None, :] * d_stride_k
        )
        # 加载 K 块：形状 [B_c, d]
        k = tl.load(k_ptr + k_offsets, mask=kv_blk_mask[:, None], other=0.0).to(tl.float32)

        # ----------------------------------------------------------------------
        # 4b. 加载当前 V 块
        # ----------------------------------------------------------------------
        v_offsets = (
            pid_batch * batch_stride_v
            + pid_head * head_stride_v
            + kv_blk_offsets[:, None] * seq_stride_v
            + tl.arange(0, d)[None, :] * d_stride_v
        )
        # 加载 V 块：形状 [B_c, d]
        v = tl.load(v_ptr + v_offsets, mask=kv_blk_mask[:, None], other=0.0).to(tl.float32)

        # ----------------------------------------------------------------------
        # 4c. 计算注意力得分：S_ij = Q_i @ K_j^T / sqrt(d)
        #     Q: [B_r, d], K: [B_c, d], K^T: [d, B_c]
        #     S_ij: [B_r, B_c]
        # ----------------------------------------------------------------------
        s_ij = tl.dot(q, tl.trans(k)) * scale

        # ----------------------------------------------------------------------
        # 4d. Online Softmax 更新
        #     这是 FlashAttention 的核心步骤：
        #     分三步更新 running max, running sum 和部分输出
        # ----------------------------------------------------------------------

        # 第 1 步：计算新的 running max
        # m_i_new = max(m_i, rowmax(S_ij))
        m_ij = tl.max(s_ij, axis=1)  # [B_r]，当前块每行的最大值
        m_i_new = tl.maximum(m_i, m_ij)  # [B_r]，更新后的 running max

        # 第 2 步：计算重缩放因子，更新 running sum
        # alpha = exp(m_i - m_i_new)，用于重缩放旧状态
        alpha = tl.exp(m_i - m_i_new)  # [B_r]
        # beta = exp(S_ij - m_i_new)，当前块的 safe softmax 分子
        # 从这里也能看到，S_ij - m_i_new 是 <= 0 的，所以 exp 不会溢出
        p_ij = tl.exp(s_ij - m_i_new[:, None])  # [B_r, B_c]
        # l_i_new = alpha * l_i + rowsum(P_ij)
        l_i_new = alpha * l_i + tl.sum(p_ij, axis=1)  # [B_r]

        # 第 3 步：更新部分输出（重缩放 + 加入新贡献）
        # acc_o = alpha * acc_o + P_ij @ V_j
        # 注意：这里的 acc_o 还没有被 l_i_new 归一化，保持"未归一化累积"的形式
        # P_ij @ V_j: [B_r, B_c] @ [B_c, d] = [B_r, d]
        acc_o = acc_o * alpha[:, None] + tl.dot(p_ij.to(tl.float16), v)

        # 第 4 步：更新状态，为下一个块做准备
        m_i = m_i_new
        l_i = l_i_new

    # --------------------------------------------------------------------------
    # 5. 内层循环结束，最终归一化输出
    #    对整个累积的 acc_o 除以 l_i（running sum），得到正确的 attention 输出
    # --------------------------------------------------------------------------
    acc_o = acc_o / l_i[:, None]

    # --------------------------------------------------------------------------
    # 6. 写回 HBM
    # --------------------------------------------------------------------------
    o_offsets = (
        pid_batch * batch_stride_o
        + pid_head * head_stride_o
        + q_blk_offsets[:, None] * seq_stride_o
        + tl.arange(0, d)[None, :] * d_stride_o
    )
    tl.store(o_ptr + o_offsets, acc_o.to(tl.float16), mask=q_blk_mask[:, None])


# ==============================================================================
# 封装函数：调用 Triton 内核
# ==============================================================================

def flash_attention_triton(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """
    FlashAttention 前向传播的 Triton 实现。

    参数:
        q: [batch_size, num_heads, N, d] 查询张量
        k: [batch_size, num_heads, N, d] 键张量
        v: [batch_size, num_heads, N, d] 值张量

    返回:
        o: [batch_size, num_heads, N, d] 注意力输出
    """
    # 确保所有张量在 GPU 上且是连续的
    assert q.is_cuda and k.is_cuda and v.is_cuda, "Q, K, V 都必须在 GPU 上"
    assert q.is_contiguous() and k.is_contiguous() and v.is_contiguous(), "Q, K, V 必须是连续张量"

    # 获取形状信息
    batch_size, num_heads, N, d = q.shape

    # 创建输出张量
    o = torch.empty_like(q)

    # 定义块大小
    # B_r: Q 块大小，B_c: K/V 块大小
    # 选择原则：Q/K/V/O 四个块 + 中间变量能放入 SRAM
    # SRAM 约 192KB (A100)，每个元素 FP16 = 2 bytes
    # 4 * B * d * 2 = 8 * B * d <= SRAM * 0.8
    # d=64 时: B <= 192*1024*0.8/(8*64) ≈ 307，取 128
    B_r = 128  # Q 块大小
    B_c = 128  # K/V 块大小

    # 计算需要多少个 Q 块
    num_q_blocks = triton.cdiv(N, B_r)

    # 定义 Triton 内核的启动配置
    # 网格维度: [batch_size, num_heads, num_q_blocks]
    grid = (batch_size, num_heads, num_q_blocks)

    # 启动内核
    _flash_attention_fwd_kernel[grid](
        q, k, v, o,
        # Q 的步长
        q.stride(0), q.stride(1), q.stride(2), q.stride(3),
        # K 的步长
        k.stride(0), k.stride(1), k.stride(2), k.stride(3),
        # V 的步长
        v.stride(0), v.stride(1), v.stride(2), v.stride(3),
        # O 的步长
        o.stride(0), o.stride(1), o.stride(2), o.stride(3),
        # 其他参数
        N=N, d=d,
        B_r=B_r, B_c=B_c, d_rem=False,
    )

    return o


# ==============================================================================
# PyTorch 原生 Attention 实现（作为正确性基准）
# ==============================================================================

def attention_pytorch(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """
    PyTorch 原生 Attention 实现（使用 scaled_dot_product_attention）。
    作为正确性和性能对比的基准。
    """
    return F.scaled_dot_product_attention(q, k, v, attn_mask=None, dropout_p=0.0, is_causal=False)


# ==============================================================================
# 验证函数：对比 Triton 实现与 PyTorch 实现的正确性
# ==============================================================================

def test_correctness(batch_size=2, num_heads=4, N=512, d=64, atol=1e-2, rtol=1e-2):
    """
    验证 Triton FlashAttention 与 PyTorch 原生 Attention 的一致性。

    参数:
        batch_size: batch 大小
        num_heads: 注意力头数
        N: 序列长度
        d: 每个头的维度
        atol: 绝对误差容忍度
        rtol: 相对误差容忍度
    """
    print("=" * 60)
    print(f"正确性验证: batch={batch_size}, heads={num_heads}, N={N}, d={d}")
    print("=" * 60)

    # 生成随机 Q, K, V 张量
    torch.manual_seed(42)
    q = torch.randn(batch_size, num_heads, N, d, device="cuda", dtype=torch.float16)
    k = torch.randn(batch_size, num_heads, N, d, device="cuda", dtype=torch.float16)
    v = torch.randn(batch_size, num_heads, N, d, device="cuda", dtype=torch.float16)

    # Triton FlashAttention
    o_triton = flash_attention_triton(q, k, v)

    # PyTorch 原生 Attention
    o_pytorch = attention_pytorch(q, k, v)

    # 计算最大绝对误差和相对误差
    max_abs_error = (o_triton - o_pytorch).abs().max().item()
    max_rel_error = ((o_triton - o_pytorch).abs() / (o_pytorch.abs() + 1e-8)).max().item()

    print(f"最大绝对误差: {max_abs_error:.6f}")
    print(f"最大相对误差: {max_rel_error:.6f}")

    if max_abs_error < atol and max_rel_error < rtol:
        print(">> 正确性验证通过！")
        return True
    else:
        print(">> 警告：误差超过阈值！")
        return False


# ==============================================================================
# 性能对比函数：对比 Triton FlashAttention 与 PyTorch 原生 Attention 的速度
# ==============================================================================

def benchmark(batch_size=2, num_heads=4, N=512, d=64, num_warmup=10, num_iters=50):
    """
    对比 Triton FlashAttention 与 PyTorch 原生 Attention 的前向耗时。

    参数:
        batch_size: batch 大小
        num_heads: 注意力头数
        N: 序列长度
        d: 每个头的维度
        num_warmup: 预热迭代次数
        num_iters: 计时迭代次数
    """
    print("\n" + "=" * 60)
    print(f"性能对比: batch={batch_size}, heads={num_heads}, N={N}, d={d}")
    print("=" * 60)

    # 生成随机输入
    torch.manual_seed(42)
    q = torch.randn(batch_size, num_heads, N, d, device="cuda", dtype=torch.float16)
    k = torch.randn(batch_size, num_heads, N, d, device="cuda", dtype=torch.float16)
    v = torch.randn(batch_size, num_heads, N, d, device="cuda", dtype=torch.float16)

    # ---- Triton FlashAttention 计时 ----
    # 预热：让 GPU 驱动完成初始化，避免首次启动开销影响测量
    for _ in range(num_warmup):
        o_triton = flash_attention_triton(q, k, v)
    torch.cuda.synchronize()

    # 正式计时
    start = time.time()
    for _ in range(num_iters):
        o_triton = flash_attention_triton(q, k, v)
    torch.cuda.synchronize()
    triton_time = (time.time() - start) / num_iters
    print(f"Triton FlashAttention:  {triton_time * 1000:.3f} ms/iter")

    # ---- PyTorch 原生 Attention 计时 ----
    # 预热
    for _ in range(num_warmup):
        o_pytorch = attention_pytorch(q, k, v)
    torch.cuda.synchronize()

    # 正式计时
    start = time.time()
    for _ in range(num_iters):
        o_pytorch = attention_pytorch(q, k, v)
    torch.cuda.synchronize()
    pytorch_time = (time.time() - start) / num_iters
    print(f"PyTorch 原生 Attention: {pytorch_time * 1000:.3f} ms/iter")

    # 计算加速比
    speedup = pytorch_time / triton_time
    print(f"加速比: {speedup:.2f}x")

    return triton_time, pytorch_time, speedup


# ==============================================================================
# 多序列长度性能扫描
# ==============================================================================

def benchmark_sequence_lengths():
    """
    扫描不同序列长度下的性能，展示 FlashAttention 在长序列下的优势。
    """
    print("\n" + "=" * 60)
    print("序列长度扫描")
    print("配置: batch=2, heads=4, d=64")
    print("=" * 60)
    print(f"{'N':>8} {'Triton(ms)':>12} {'PyTorch(ms)':>12} {'加速比':>8}")

    for N in [128, 256, 512, 1024, 2048]:
        q = torch.randn(2, 4, N, 64, device="cuda", dtype=torch.float16)
        k = torch.randn(2, 4, N, 64, device="cuda", dtype=torch.float16)
        v = torch.randn(2, 4, N, 64, device="cuda", dtype=torch.float16)

        # 预热
        for _ in range(10):
            flash_attention_triton(q, k, v)
            attention_pytorch(q, k, v)
        torch.cuda.synchronize()

        # Triton 计时
        start = time.time()
        for _ in range(50):
            flash_attention_triton(q, k, v)
        torch.cuda.synchronize()
        t_triton = (time.time() - start) / 50

        # PyTorch 计时
        start = time.time()
        for _ in range(50):
            attention_pytorch(q, k, v)
        torch.cuda.synchronize()
        t_pytorch = (time.time() - start) / 50

        speedup = t_pytorch / t_triton
        print(f"{N:>8} {t_triton*1000:>10.3f} {t_pytorch*1000:>10.3f} {speedup:>7.2f}x")


# ==============================================================================
# 主函数：运行所有测试
# ==============================================================================

if __name__ == "__main__":
    print("FlashAttention Triton 实现 —— 测试与验证")
    print("=" * 60)

    # 检查 CUDA 是否可用
    if not torch.cuda.is_available():
        print("错误：需要 CUDA 设备来运行 Triton 内核！")
        exit(1)

    print(f"CUDA 设备: {torch.cuda.get_device_name(0)}")
    print(f"CUDA 版本: {torch.version.cuda}")
    print(f"Triton 版本: {triton.__version__}")

    # 运行正确性测试
    print("\n>>> 正确性测试")
    test_correctness(batch_size=2, num_heads=4, N=512, d=64)
    test_correctness(batch_size=1, num_heads=8, N=1024, d=128)

    # 运行性能对比
    print("\n>>> 性能对比")
    benchmark(batch_size=2, num_heads=4, N=512, d=64)
    benchmark(batch_size=2, num_heads=8, N=1024, d=128)

    # 扫描不同序列长度
    print("\n>>> 序列长度扫描")
    benchmark_sequence_lengths()

    print("\n全部测试完成！")
