/*
 * matmul.cu — 矩阵乘法：从朴素到 Shared Memory Tiled 优化
 *
 * 知识点覆盖：
 *   ✅ 朴素版本（每个线程算一个元素）
 *   ✅ 2D 线程索引
 *   ✅ Shared Memory Tiling（分块）优化
 *   ✅ 推理场景：GEMM 是 Attention 投影矩阵和 FFN 的核心计算
 *
 * 推理场景：
 *   - Q/K/V 投影矩阵：input @ W_Q, input @ W_K, input @ W_V
 *   - Attention 输出投影：attn_output @ W_O
 *   - FFN：hidden @ W_up, hidden @ W_gate
 *   - 这些占推理总计算量的 60%+！
 *
 * 编译：nvcc -O2 -arch=sm_80 -o matmul matmul.cu
 * 运行：./matmul
 *
 * 分析：ncu --set full -o ncu_matmul ./matmul
 */

#include <cstdio>
#include <cstdlib>
#include <cmath>

#define CUDA_CHECK(call)                                                      \
    do {                                                                      \
        cudaError_t err = call;                                               \
        if (err != cudaSuccess) {                                             \
            fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__, \
                    cudaGetErrorString(err));                                 \
            exit(EXIT_FAILURE);                                               \
        }                                                                     \
    } while(0)

/* ================================================================
 * 1. 朴素矩阵乘法 Kernel
 *
 * C = A * B     (M×K  *  K×N  =  M×N)
 *
 * 每个线程计算 C 的一个元素（row, col）。
 * 每个线程需要从 A 读一行的 K 个元素，从 B 读一列的 K 个元素。
 *
 * 全局内存访问模式：
 *   A[row][k]：行连续，合并访问 ✅
 *   B[k][col]：跨步 K*N，非合并 ❌（最严重问题！）
 *
 * 性能瓶颈：B 矩阵的列访问导致大量 cache miss，带宽利用率极低。
 * ================================================================ */

__global__ void matmul_naive(const float* A, const float* B, float* C,
                              int M, int N, int K) {
    // 2D 线程索引
    // row: 当前线程负责的行（C[row][*]）
    // col: 当前线程负责的列（C[*][col]）
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        // 累加 A[row][k] * B[k][col]
        for (int k = 0; k < K; ++k) {
            // A[row * K + k]：A 的行访问，连续 ✅
            // B[k * N + col]：B 的列访问，跨 K 个元素！❌
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}


/* ================================================================
 * 2. Shared Memory Tiled 矩阵乘法
 *
 * 核心思想：将大矩阵切成小 tile（方块），
 *   1. 每个 block 协同加载一个 tile 到 shared memory
 *   2. 从 shared memory 中读取数据（快 10x+ 比 global memory）
 *   3. 多个 tile 累加得到最终结果
 *
 * 优化点：
 *   - 读取 A 和 B 时，每个线程加载一个元素到 shared memory → 合并访问 ✅
 *   - 从 shared memory 读取时，所有线程读取小 tile → 无跨步访问 ✅
 *   - 每轮只加载 BLOCK_SIZE 个元素，而不是 K 次全局访问
 *
 * 访问次数对比：
 *   朴素版本：K 次全局内存读取 × 每个元素
 *   Tiled 版本：K/BLOCK_SIZE 次全局内存读取 × 每个元素
 *   = 减少 BLOCK_SIZE 倍的全局访问！
 * ================================================================ */

template <int BLOCK_SIZE>
__global__ void matmul_tiled(const float* A, const float* B, float* C,
                              int M, int N, int K) {
    // 共享内存：每个 block 持有两个 BLOCK_SIZE×BLOCK_SIZE 的 tile
    // As: A 矩阵的 tile（本 block 处理的行范围）
    // Bs: B 矩阵的 tile（本 block 处理的列范围）
    __shared__ float As[BLOCK_SIZE][BLOCK_SIZE];
    __shared__ float Bs[BLOCK_SIZE][BLOCK_SIZE + 1];  // +1 padding 避免 bank conflict

    // 当前线程负责的 C 矩阵位置
    int row = blockIdx.y * BLOCK_SIZE + threadIdx.y;
    int col = blockIdx.x * BLOCK_SIZE + threadIdx.x;

    float sum = 0.0f;

    // 沿 K 维度循环，每次处理 BLOCK_SIZE 个元素
    // 总共需要 ceil(K / BLOCK_SIZE) 轮
    int num_tiles = (K + BLOCK_SIZE - 1) / BLOCK_SIZE;

    for (int tile = 0; tile < num_tiles; ++tile) {
        // ================================================================
        // 协同加载 A 的 tile 到 shared memory
        // 每个线程从 A 中加载一个元素：A[row][tile*BLOCK_SIZE + threadIdx.x]
        //
        // 全局内存访问模式：
        //   同一 warp 的 threadIdx.x 连续 → 合并访问 ✅
        // ================================================================

        if (row < M && tile * BLOCK_SIZE + threadIdx.x < K) {
            As[threadIdx.y][threadIdx.x] =
                A[row * K + tile * BLOCK_SIZE + threadIdx.x];
        } else {
            As[threadIdx.y][threadIdx.x] = 0.0f;
        }

        // ================================================================
        // 协同加载 B 的 tile 到 shared memory
        // 每个线程从 B 中加载一个元素：B[tile*BLOCK_SIZE + threadIdx.y][col]
        //
        // 关键 insight：
        //   这里 threadIdx.y 给 B 的行索引，threadIdx.x 给 B 的列索引
        //   同一列的线程（threadIdx.x 相同）访问同一行 → 但 threadIdx.y 不同
        //   全局内存访问：B[(tile*BLOCK_SIZE + threadIdx.y) * N + col]
        //   threadIdx.y 连续变化时，访问的是 B 的行内不同行，不是连续地址
        //   这是 tiled 版本中不完美的部分，相比朴素版本已经大幅改善
        // ================================================================

        if (tile * BLOCK_SIZE + threadIdx.y < K && col < N) {
            Bs[threadIdx.y][threadIdx.x] =
                B[(tile * BLOCK_SIZE + threadIdx.y) * N + col];
        } else {
            Bs[threadIdx.y][threadIdx.x] = 0.0f;
        }

        // 等待所有线程加载完成
        __syncthreads();

        // ================================================================
        // 计算当前 tile 的部分和
        // 所有数据现在在 shared memory 中，高速访问
        // As 和 Bs 的大小都是 BLOCK_SIZE×BLOCK_SIZE
        // 每个线程累加 As[threadIdx.y][k] * Bs[k][threadIdx.x]
        // ================================================================

        for (int k = 0; k < BLOCK_SIZE; ++k) {
            sum += As[threadIdx.y][k] * Bs[k][threadIdx.x];
        }

        // 等待所有线程计算完成，再用完数据后才加载下一轮 tile
        __syncthreads();
    }

    // 写入结果
    if (row < M && col < N) {
        C[row * N + col] = sum;
    }
}


/* ================================================================
 * 3. 验证函数
 * ================================================================ */

void cpu_matmul(const float* A, const float* B, float* C, int M, int N, int K) {
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < K; ++k) {
                sum += A[i * K + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

bool verify(const float* expected, const float* actual, int n) {
    for (int i = 0; i < n; ++i) {
        if (fabs(expected[i] - actual[i]) > 1e-3f) {
            printf("  ❌ 验证失败 at %d: CPU=%f GPU=%f\n",
                   i, expected[i], actual[i]);
            return false;
        }
    }
    return true;
}


/* ================================================================
 * 4. 计时的 Benchmark 函数
 * ================================================================ */

template <typename KernelFunc>
double benchmark_kernel(KernelFunc kernel, int grid_x, int grid_y, int block_x, int block_y,
                        const float* d_A, const float* d_B, float* d_C,
                        int M, int N, int K, int shared_mem = 0) {
    dim3 grid(grid_x, grid_y);
    dim3 block(block_x, block_y);

    cudaEvent_t start, stop;
    float ms;
    CUDA_CHECK(cudaEventCreate(&start));
    CUDA_CHECK(cudaEventCreate(&stop));

    // warmup
    kernel<<<grid, block, shared_mem>>>(d_A, d_B, d_C, M, N, K);
    CUDA_CHECK(cudaDeviceSynchronize());

    // benchmark
    CUDA_CHECK(cudaEventRecord(start, 0));
    int iters = 10;
    for (int i = 0; i < iters; ++i) {
        kernel<<<grid, block, shared_mem>>>(d_A, d_B, d_C, M, N, K);
    }
    CUDA_CHECK(cudaEventRecord(stop, 0));
    CUDA_CHECK(cudaEventSynchronize(stop));
    CUDA_CHECK(cudaEventElapsedTime(&ms, start, stop));

    CUDA_CHECK(cudaEventDestroy(start));
    CUDA_CHECK(cudaEventDestroy(stop));

    return ms / iters;  // 平均时间
}


/* ================================================================
 * main
 * ================================================================ */

int main() {
    printf("===== CUDA Matrix Multiplication 性能对比 =====\n\n");

    // 矩阵大小（模拟推理场景中一次 Attention 投影）
    // B=1, H=32, S=4096, D=128
    // Q = input @ W_Q: [4096, 128] × [128, 4096] → [4096, 4096]
    // 对于简化测试，用较小的矩阵
    int M = 1024;  // 行（sequence length）
    int N = 1024;  // 列（hidden dimension）
    int K = 1024;  // 内维度

    printf("矩阵: A[%d×%d] × B[%d×%d] = C[%d×%d]\n", M, K, K, N, M, N);

    // host 内存
    size_t size_A = M * K * sizeof(float);
    size_t size_B = K * N * sizeof(float);
    size_t size_C = M * N * sizeof(float);

    float* h_A = (float*)malloc(size_A);
    float* h_B = (float*)malloc(size_B);
    float* h_C_naive = (float*)malloc(size_C);
    float* h_C_tiled = (float*)malloc(size_C);
    float* h_C_cpu = (float*)malloc(size_C);

    // 初始化
    for (int i = 0; i < M * K; ++i) h_A[i] = static_cast<float>(rand()) / RAND_MAX;
    for (int i = 0; i < K * N; ++i) h_B[i] = static_cast<float>(rand()) / RAND_MAX;

    // CPU 参考
    printf("计算 CPU ref...\n");
    cpu_matmul(h_A, h_B, h_C_cpu, M, N, K);

    // GPU 内存
    float *d_A, *d_B, *d_C;
    CUDA_CHECK(cudaMalloc(&d_A, size_A));
    CUDA_CHECK(cudaMalloc(&d_B, size_B));
    CUDA_CHECK(cudaMalloc(&d_C, size_C));

    CUDA_CHECK(cudaMemcpy(d_A, h_A, size_A, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_B, h_B, size_B, cudaMemcpyHostToDevice));

    // ================================================================
    // 朴素版本
    // ================================================================

    int block_size = 16;  // 常见的 2D block 大小
    dim3 block_2d(block_size, block_size);
    dim3 grid_2d(
        (N + block_size - 1) / block_size,
        (M + block_size - 1) / block_size
    );

    printf("\n--- 朴素版本 ---\n");
    double naive_ms = benchmark_kernel(
        matmul_naive, grid_2d.x, grid_2d.y, block_size, block_size,
        d_A, d_B, d_C, M, N, K);
    printf("  耗时: %.3f ms\n", naive_ms);
    printf("  GFLOPS: %.1f\n",
           2.0 * M * N * K / (naive_ms / 1000.0) / 1e9);

    CUDA_CHECK(cudaMemcpy(h_C_naive, d_C, size_C, cudaMemcpyDeviceToHost));
    printf("  验证: %s\n", verify(h_C_cpu, h_C_naive, M * N) ? "✅" : "❌");

    // ================================================================
    // Tiled 版本 (BLOCK_SIZE=16)
    // ================================================================

    printf("\n--- Shared Memory Tiled (BLOCK_SIZE=16) ---\n");
    double tiled16_ms = benchmark_kernel(
        matmul_tiled<16>, grid_2d.x, grid_2d.y, block_size, block_size,
        d_A, d_B, d_C, M, N, K);
    printf("  耗时: %.3f ms\n", tiled16_ms);
    printf("  GFLOPS: %.1f\n",
           2.0 * M * N * K / (tiled16_ms / 1000.0) / 1e9);

    CUDA_CHECK(cudaMemcpy(h_C_tiled, d_C, size_C, cudaMemcpyDeviceToHost));
    printf("  验证: %s\n", verify(h_C_cpu, h_C_tiled, M * N) ? "✅" : "❌");
    printf("  加速比: %.2fx\n", naive_ms / tiled16_ms);

    // ================================================================
    // Tiled 版本 (BLOCK_SIZE=32)
    // ================================================================

    int block_size_32 = 32;
    dim3 grid_32(
        (N + block_size_32 - 1) / block_size_32,
        (M + block_size_32 - 1) / block_size_32
    );

    printf("\n--- Shared Memory Tiled (BLOCK_SIZE=32) ---\n");
    double tiled32_ms = benchmark_kernel(
        matmul_tiled<32>, grid_32.x, grid_32.y, block_size_32, block_size_32,
        d_A, d_B, d_C, M, N, K);
    printf("  耗时: %.3f ms\n", tiled32_ms);
    printf("  GFLOPS: %.1f\n",
           2.0 * M * N * K / (tiled32_ms / 1000.0) / 1e9 );
    printf("  加速比 vs 朴素: %.2fx\n", naive_ms / tiled32_ms);

    // ================================================================
    // 对比 cuBLAS（NVIDIA 官方高度优化的 BLAS 库）
    // ================================================================

    printf("\n--- cuBLAS (NVIDIA 官方优化) ---\n");

    // cuBLAS handle
    cublasHandle_t cublas_handle;
    cublasCreate(&cublas_handle);

    // cuBLAS 的 GEMM 使用列主序，因此需要 transa=CUBLAS_OP_N / transb=CUBLAS_OP_N
    // 列主序下的 C = A * B → 用行主序时相当于 C^T = (A*B)^T = B^T * A^T
    // 所以 cuBLAS 的 C = op(A) * op(B)，其中 op 可以是转置或不变
    // 我们用 CUBLAS_OP_N: 不转置，但注意 cuBLAS 是列主序
    // 更简单的方式：直接用 cublasSgemm 并理解它计算的是 C = B^T * A^T 的列主序版本
    // 但由于我们的矩阵是按行主序存的，需要调换参数

    const float alpha = 1.0f;
    const float beta = 0.0f;

    // cuBLAS 使用列主序：C = alpha * op(A) * op(B) + beta * C
    // 对于行主序的 C = A * B，等价于列主序的 C^T = B^T * A^T
    // 所以调用 cublasSgemm 时交换 A/B 并转置
    cublasSgemm(cublas_handle,
                CUBLAS_OP_N, CUBLAS_OP_N,  // 不转置
                N, M, K,                    // 注意：N 和 M 交换
                &alpha,
                d_B, N,                    // B 的 leading dimension
                d_A, K,                    // A 的 leading dimension
                &beta,
                d_C, N);

    CUDA_CHECK(cudaDeviceSynchronize());

    // 计时 cuBLAS
    cudaEvent_t cublas_start, cublas_stop;
    float cublas_ms;
    CUDA_CHECK(cudaEventCreate(&cublas_start));
    CUDA_CHECK(cudaEventCreate(&cublas_stop));

    CUDA_CHECK(cudaEventRecord(cublas_start, 0));
    int cublas_iters = 100;
    for (int i = 0; i < cublas_iters; ++i) {
        cublasSgemm(cublas_handle,
                    CUBLAS_OP_N, CUBLAS_OP_N,
                    N, M, K,
                    &alpha,
                    d_B, N,
                    d_A, K,
                    &beta,
                    d_C, N);
    }
    CUDA_CHECK(cudaEventRecord(cublas_stop, 0));
    CUDA_CHECK(cudaEventSynchronize(cublas_stop));
    CUDA_CHECK(cudaEventElapsedTime(&cublas_ms, cublas_start, cublas_stop));
    cublas_ms /= cublas_iters;

    printf("  耗时: %.3f ms\n", cublas_ms);
    printf("  GFLOPS: %.1f\n",
           2.0 * M * N * K / (cublas_ms / 1000.0) / 1e9);
    printf("  加速比 vs 朴素: %.2fx\n", naive_ms / cublas_ms);
    printf("  加速比 vs Tiled: %.2fx\n", tiled32_ms / cublas_ms);

    cublasDestroy(cublas_handle);
    CUDA_CHECK(cudaEventDestroy(cublas_start));
    CUDA_CHECK(cudaEventDestroy(cublas_stop));

    // ================================================================
    // 总结
    // ================================================================

    printf("\n===== 总结 =====\n");
    printf("主要瓶颈分析:\n");
    printf("  朴素版本: 主要瓶颈在 B 矩阵的列访问（非合并）\n");
    printf("  Tiled 版本: 通过 shared memory 减少全局访问\n");
    printf("  cuBLAS: 用了寄存器级 tiling、warp-level 矩阵乘、双缓冲等优化\n");
    printf("\n推理场景中矩阵乘法的占比:\n");
    printf("  Attention: QKV 投影 3 次 + Output 投影 1 次 = 4 次 GEMM\n");
    printf("  FFN: up/gate/down 各 1 次 = 3 次 GEMM\n");
    printf("  总计: 每个 decoder layer 7 次 GEMM (MoE 更复杂)\n");

    // 清理
    CUDA_CHECK(cudaFree(d_A));
    CUDA_CHECK(cudaFree(d_B));
    CUDA_CHECK(cudaFree(d_C));
    free(h_A);
    free(h_B);
    free(h_C_naive);
    free(h_C_tiled);
    free(h_C_cpu);

    return 0;
}
