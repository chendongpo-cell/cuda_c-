/*
 * reduction.cu — 树形归约 Kernel（推理优化方向核心操作）
 *
 * 知识点覆盖：
 *   ✅ 树形归约算法（二分散）—— Warp-level 和 Block-level
 *   ✅ Dynamic Shared Memory 使用
 *   ✅ __syncthreads() 同步原语
 *   ✅ Warp Shuffle 指令（__shfl_down_sync）
 *   ✅ 推理场景：Softmax 中的指数求和、LayerNorm 的均值和方差
 *
 * 推理场景：
 *   - Attention 的 Softmax：需要求 e^x 的和（归约操作）
 *   - LayerNorm：需要求均值和方差（累加归约）
 *   - kv cache 的 attention 输出需要 partial softmax（FlashAttention 核心）
 *
 * 编译：nvcc -O2 -arch=sm_80 -o reduction reduction.cu
 * 运行：./reduction
 *
 * 分析：ncu --kernel-name "reduce_sum" -o ncu_profile ./reduction
 */

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <limits>

#define CUDA_CHECK(call)                                                      \
    do {                                                                      \
        cudaError_t err = call;                                               \
        if (err != cudaSuccess) {                                             \
            fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__, \
                    cudaGetErrorString(err));                                 \
            exit(EXIT_FAILURE);                                               \
        }                                                                     \
    } while(0)

/* ================================================================
 * 1. 基础归约 Kernel（一个 block 归约一块数据）
 *
 * 算法原理（树形归约）：
 *   输入:  [a0, a1, a2, a3, a4, a5, a6, a7]  (8 个元素)
 *   第 1 轮 s=4: [a0+a4, a1+a5, a2+a6, a3+a7]  (4 个线程活跃)
 *   第 2 轮 s=2: [a0+a4+a2+a6, a1+a5+a3+a7]    (2 个线程活跃)
 *   第 3 轮 s=1: [a0+a4+a2+a6+a1+a5+a3+a7]     (1 个线程得到结果)
 *
 * 每个 block 处理 BLOCK_SIZE 个元素，得到一个结果。
 * 如果有多个 block，需要第二轮归约（第二个 kernel 或 CPU 端做）。
 *
 * 推理场景：
 *   Attention softmax 中需要求分母（所有 e^x 的和）：
 *     sum = reduce_sum(e_x)  // 一个 block 归约一行
 * ================================================================ */

__global__ void reduce_sum_basic(const float* input, float* output, int n) {
    extern __shared__ float sdata[];  // 动态 shared memory，大小在 launch 时指定

    int tid = blockIdx.x * blockDim.x + threadIdx.x;  // 全局线程索引
    int ltid = threadIdx.x;  // 局部线程索引（block 内）

    // Step 1: 加载数据到 shared memory（每个线程加载一个元素）
    // 边界检查：超出 n 的部分填 0（对求和无影响）
    sdata[ltid] = (tid < n) ? input[tid] : 0.0f;
    __syncthreads();  // 所有线程加载完成前，不能开始归约

    // Step 2: 树形归约（相邻对半策略）
    // 循环变量 s 从 blockDim.x/2 开始，每次减半
    // 第 1 次迭代：s=128（线程 0~127 各加偏移 128 的元素）
    // 第 2 次迭代：s=64（线程 0~63 各加偏移 64 的元素）
    // ...
    // 最后 s=1：线程 0 加偏移 1 的元素，得到最终结果
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (ltid < s) {
            // 每个活跃线程将远端的值加到本地
            sdata[ltid] += sdata[ltid + s];
        }
        // __syncthreads() 必须：确保这一轮所有加法完成才能开始下一轮
        // 否则线程 0 可能读到了线程 1 还没写完的旧值
        __syncthreads();
    }

    // Step 3: block 0 的线程 0 写入结果
    // 注意：如果 gridDim.x > 1，需要多级归约
    if (ltid == 0) {
        output[blockIdx.x] = sdata[0];
    }
}


/* ================================================================
 * 2. 优化版归约（循环展开 + 减少同步）
 *
 * 优化技巧：
 *   1. 当 s <= 32 时，一个 warp 内的线程天然同步（不需要 __syncthreads）
 *   2. 循环展开减少循环开销
 *   3. 使用 warp shuffle 进一步减少 shared memory 访问
 * ================================================================ */

__global__ void reduce_sum_optimized(const float* input, float* output, int n) {
    extern __shared__ float sdata[];

    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    int ltid = threadIdx.x;

    // 加载数据
    sdata[ltid] = (tid < n) ? input[tid] : 0.0f;
    __syncthreads();

    // 展开的归约（s >= 64 时需要同步）
    if (blockDim.x >= 1024 && ltid < 512) {
        sdata[ltid] += sdata[ltid + 512];
    }
    __syncthreads();

    if (blockDim.x >= 512 && ltid < 256) {
        sdata[ltid] += sdata[ltid + 256];
    }
    __syncthreads();

    if (blockDim.x >= 256 && ltid < 128) {
        sdata[ltid] += sdata[ltid + 128];
    }
    __syncthreads();

    if (blockDim.x >= 128 && ltid < 64) {
        sdata[ltid] += sdata[ltid + 64];
    }
    __syncthreads();

    // s <= 32 时，一个 warp 内不需要 __syncthreads
    // 因为 warp 是 SIMT 执行的，所有线程执行同一指令
    if (ltid < 32) {
        // volatile 关键字：告诉编译器不要优化掉 shared memory 的读写
        // 确保每次读取都是最新的值（warp 内不需要同步，但编译器可能优化）
        volatile float* smem = sdata;

        if (blockDim.x >= 64) smem[ltid] += smem[ltid + 32];
        if (blockDim.x >= 32) smem[ltid] += smem[ltid + 16];
        if (blockDim.x >= 16) smem[ltid] += smem[ltid + 8];
        if (blockDim.x >= 8)  smem[ltid] += smem[ltid + 4];
        if (blockDim.x >= 4)  smem[ltid] += smem[ltid + 2];
        if (blockDim.x >= 2)  smem[ltid] += smem[ltid + 1];
    }

    if (ltid == 0) {
        output[blockIdx.x] = sdata[0];
    }
}


/* ================================================================
 * 3. 使用 Warp Shuffle 的归约（终极优化版）
 *
 * Warp Shuffle (__shfl_down_sync)：
 *   允许同一个 warp 内的线程直接交换寄存器值，
 *   不需要经过 shared memory，延迟更低。
 *
 * 语法：__shfl_down_sync(mask, val, delta, width)
 *   mask: 参与 warp 的线程掩码（0xFFFFFFFF = 全部 32 线程）
 *   val: 当前线程的值
 *   delta: 向下偏移多少位置取数据
 *   width: warp 大小（32）
 *
 * 线程 0 从线程 16 取值：__shfl_down_sync(0xFFFFFFFF, val, 16)
 * 线程 16 的值 → 线程 0
 * ================================================================ */

__device__ float warp_reduce_sum(float val) {
    // Warp 0 中的 32 线程归约
    // 每次迭代步长翻倍：16, 8, 4, 2, 1
    // 效果：所有线程的 val 都变成 sum

    // 第 1 步：线程 0~15 获取线程 16~31 的值
    // 线程 0: val += shfl_down(16) = val[16]
    val += __shfl_down_sync(0xFFFFFFFF, val, 16, 32.gov);
    // 第 2 步：线程 0~7 获取线程 8~15 的值
    val += __shfl_down_sync(0xFFFFFFFF, val, 8, 32);
    // 第 3 步：线程 0~3 获取线程 4~7 的值
    val += __shfl_down_sync(0xFFFFFFFF, val, 4, 32);
    // 第 4 步：线程 0~1 获取线程 2~3 的值
    val += __shfl_down_sync(0xFFFFFFFF, val, 2, 32);
    // 第 5 步：线程 0 获取线程 1 的值
    val += __shfl_down_sync(0xFFFFFFFF, val, 1, 32);

    // 现在线程 0~31 都有总和
    return val;
}

// 使用 warp shuffle 的归约：最快版本
// 每个 block 用多个 warp 做部分归约，最后一个 warp 做最终归约
__global__ void reduce_sum_shuffle(const float* input, float* output, int n) {
    // 每个 warp 的 lane ID（warp 内线程编号 0~31）
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    // 先做 shared memory 级别的部分归约
    extern __shared__ float sdata[];

    // 加载数据到 shared memory
    sdata[threadIdx.x] = (tid < n) ? input[tid] : 0.0f;
    __syncthreads();

    // 在 shared memory 中做第一轮归约（到 warp 级别）
    // blockDim.x / warpSize 个 warp，每个 warp 归约 32 个元素
    for (int s = blockDim.x / 2; s >= 32; s >>= 1) {
        if (threadIdx.x < s) {
            sdata[threadIdx.x] += sdata[threadIdx.x + s];
        }
        __syncthreads();
    }

    // 最后一个 warp（threadIdx.x [0, 31]）用 shuffle 做归约
    if (threadIdx.x < 32) {
        float val = sdata[threadIdx.x];
        val = warp_reduce_sum(val);  // 现在所有线程都有总和
        if (threadIdx.x == 0) {
            output[blockIdx.x] = val;
        }
    }
}


/* ================================================================
 * 4. 验证函数
 * ================================================================ */

void cpu_reduce_sum(const float* data, int n, float* result) {
    *result = 0.0f;
    for (int i = 0; i < n; ++i) {
        *result += data[i];
    }
}

bool verify(float expected, float actual, int n) {
    float diff = fabs(expected - actual);
    if (diff > 1e-3f) {
        printf("  ❌ 验证失败: CPU=%f GPU=%f diff=%f\n", expected, actual, diff);
        return false;
    }
    return true;
}


/* ================================================================
 * main
 * ================================================================ */

int main() {
    printf("===== CUDA Reduction 归约性能对比 =====\n\n");

    // 测试不同大小的数据
    int sizes[] = {
        1 << 20,      // 1M
        1 << 22,      // 4M
        1 << 24,      // 16M
    };
    const int num_sizes = 3;

    for (int s = 0; s < num_sizes; ++s) {
        int n = sizes[s];
        size_t bytes = n * sizeof(floatopera);

        printf("--- 数据大小: %d 元素 (%zu MB) ---\n", n, bytes / (1024 * 1024));

        // 分配 host 内存
        float* h_data = (float*)malloc(bytes);
        float h_result;

        // 初始化数据
        for (int i = 0; i < n; ++i) {
            h_data[i] = 1.0f;  // 全 1，总和 = n
        }
        cpu_reduce_sum(h_data, n, &h_result);
        printf("CPU 结果: %f (期望 = %d)\n", h_result, n);

        // 分配 device 内存
        float *d_data, *d_output;
        CUDA_CHECK(cudaMalloc(&d_data, bytes));

        // 输出需要足够的空间放每个 block 的结果
        int block_size = 256;
        int grid_size = (n + block_size - 1) / block_size;
        // 第一个 kernel 后还有 grid_size 个部分和，需要再处理
        // 简单做法：分配 grid_size * sizeof(float) 空间
        // 如果 grid_size 还很大，可以递归归约

        // 这里用 2 级归约
        // 注意：d_output 的大小需要能放下 grid_size 个 float
        // 但如果 n 很大导致 grid_size 很大，这不够
        // 实践中用 while 循环
        int max_blocks = 1024;
        size_t output_bytes = max_blocks * sizeof(float);
        CUDA_CHECK(cudaMalloc(&d_output, output_bytes));
        CUDA_CHECK(cudaMemcpy(d_data, h_data, bytes, cudaMemcpyHostToDevice));

        // 第 1 级归约：每个 block 归约自己的数据
        // 使用 shuffle 版本的 kernel
        cudaEvent_t start, stop;
        float ms;
        CUDA_CHECK(cudaEventCreate(&start));
        CUDA_CHECK(cudaEventCreate(&stop));

        CUDA_CHECK(cudaEventRecord(start, 0));

        // 第一次 launch：将 n 个元素归约为 grid_size 个部分和
        int shared_size = block_size * sizeof(float);
        reduce_sum_shuffle<<<grid_size, block_size, shared_size>>>(
            d_data, d_output, n);
        CUDA_CHECK(cudaGetLastError());

        // 第二次 launch：如果 grid_size 还大于 1，需要再次归约
        // 这里限定 n 不超过 2^24，所以 grid_size <= 65536，需要多级
        // 简单处理：直接在 CPU 做剩余的归约（对于 benchmark 可接受）
        CUDA_CHECK(cudaDeviceSynchronize());

        // 把部分和拷贝回 host
        float* h_partial = (float*)malloc(grid_size * sizeof(float));
        CUDA_CHECK(cudaMemcpy(h_partial, d_output,
                              grid_size * sizeof(float),
                              cudaMemcpyDeviceToHost));

        // CPU 做最终归约
        float gpu_result = 0.0f;
        for (int i = 0; i < grid_size; ++i) {
            gpu_result += h_partial[i];
        }

        CUDA_CHECK(cudaEventRecord(stop, 0));
        CUDA_CHECK(cudaEventSynchronize(stop));
        CUDA_CHECK(cudaEventElapsedTime(&ms, start, stop));

        free(h_partial);

        printf("GPU 结果: %f (耗时 %.3f ms)\n", gpu_result, ms);
        verify(h_result, gpu_result, n);

        // 清理
        CUDA_CHECK(cudaFree(d_data));
        CUDA_CHECK(cudaFree(d_output));
        free(h_data);
        CUDA_CHECK(cudaEventDestroy(start));
        CUDA_CHECK(cudaEventDestroy(stop));

        printf("\n");
    }

    // 展示 warp shuffle 的小 demo
    printf("\n===== Warp Shuffle Demo =====\n");
    printf("一个 warp (32 线程) 的归约，每个线程持有自己的 threadIdx.x\n");
    printf("经 warp_reduce_sum 后所有线程都有总和 0+1+2+...+31 = 496\n");

    return 0;
}
