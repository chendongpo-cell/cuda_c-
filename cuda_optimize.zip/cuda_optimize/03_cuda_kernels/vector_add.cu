/*
 * vector_add.cu — CUDA 基础 Kernel：向量加法
 *
 * 知识点覆盖：
 *   ✅ CUDA 线程层次：grid / block / thread
 *   ✅ 全局内存分配与拷贝：cudaMalloc / cudaMemcpy / cudaFree
 *   ✅ Kernel 编写：__global__ 声明、线程索引计算、边界检查
 *   ✅ 性能分析：cudaEvent 计时、带宽计算
 *   ✅ Nsight Systems/Compute 分析入口
 *
 * 编译：nvcc -O2 -arch=sm_80 -o vector_add vector_add.cu
 * 运行：./vector_add
 *
 * GPU 架构参数：
 *   sm_80 → A100 / RTX 3090 (Ampere)
 *   sm_86 → RTX 3060/3070/3080 (Ampere consumer)
 *   sm_89 → RTX 4090 (Ada Lovelace)
 *   sm_90 → H100 (Hopper)
 * 查看你的 GPU：nvidia-smi --query-gpu=name,compute_cap --format=csv
 */

#include <cstdio>       // printf, fprintf
#include <cstdlib>      // rand, srand
#include <cmath>        // fabs

/* ================================================================
 * 1. CUDA 错误检查宏
 *
 * 每个 CUDA API 调用都可能失败（显存不足、驱动问题等），
 * 每次调用后都应该检查错误码。这个宏自动做了这件事。
 *
 * 使用方式：CUDA_CHECK(cudaMalloc(&ptr, size));
 * ================================================================ */

#define CUDA_CHECK(call)                                                      \
    do {                                                                      \
        cudaError_t err = call;                                               \
        if (err != cudaSuccess) {                                             \
            fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__, \
                    cudaGetErrorString(err));                                 \
            exit(EXIT_FAILURE);                                               \
        }                                                                     \
    } while(0)

/* ================================================================
 * 2. CUDA Kernel：向量加法
 *
 * __global__ 关键字：
 *   - 在 host 端调用，在 device（GPU）端执行
 *   - 返回值必须是 void
 *   - 调用方式：kernel<<<grid, block>>>(args);
 *
 * 每个线程计算一个元素的加法，适用于"数据并行"场景。
 *
 * 线程索引公式（1D）：
 *   tid = blockIdx.x * blockDim.x + threadIdx.x
 *
 * 边界检查的重要性：
 *   数据大小不一定刚好是 blockDim 的整数倍，
 *   多余的线程（tid >= n）不执行有效计算。
 *   不加边界检查会导致 GPU 访问越界，可能 cudaError 或 segfault。
 * ================================================================ */

__global__ void vector_add(const float* a, const float* b, float* c, int n) {
    // 计算当前线程的全局线性索引
    // blockIdx.x: 当前 block 在 grid 中的编号
    // blockDim.x: 每个 block 的线程数
    // threadIdx.x: 当前线程在 block 内的编号
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    // 边界检查：确保 tid 在有效范围内
    if (tid < n) {
        // 每个线程只计算一个元素
        c[tid] = a[tid] + b[tid];
    }
}


/* ================================================================
 * 3. 验证函数（在 CPU 上计算结果进行比较）
 * ================================================================ */

bool verify_result(const float* cpu_result, const float* gpu_result, int n) {
    const float epsilon = 1e-5f;  // 允许的误差（浮点计算有舍入误差）
    for (int i = 0; i < n; ++i) {
        if (fabs(cpu_result[i] - gpu_result[i]) > epsilon) {
            printf("  验证失败 at index %d: CPU=%f GPU=%f\n",
                   i, cpu_result[i], gpu_result[i]);
            return false;
        }
    }
    return true;
}


/* ================================================================
 * 4. main 函数
 * ================================================================ */

int main() {
    // ================================================================
    // Step 1: 设置数据参数
    // ================================================================

    // 1 << 20 = 1048576 个元素，约 4 MB 每向量（float 4 字节）
    int n = 1 << 20;
    size_t bytes = n * sizeof(float);  // 需要分配的字节数

    printf("===== CUDA Vector Add =====\n");
    printf("向量大小: %d 元素 (%zu MB)\n", n, bytes / (1024 * 1024));

    // ================================================================
    // Step 2: 分配 host 内存并初始化数据
    // ================================================================

    // malloc: 在 CPU 上（host）分配内存
    float* h_a = (float*)malloc(bytes);
    float* h_b = (float*)malloc(bytes);
    float* h_c = (float*)malloc(bytes);      // GPU 计算结果会拷贝回来
    float* h_c_cpu = (float*)malloc(bytes);  // CPU 计算结果用于验证

    // 用随机数初始化 a 和 b
    // srand: 设置随机种子，确保可复现
    srand(42);  // 固定种子，每次运行结果相同
    for (int i = 0; i < n; ++i) {
        h_a[i] = static_cast<float>(rand()) / RAND_MAX;  // [0.0, 1.0]
        h_b[i] = static_cast<float>(rand()) / RAND_MAX;
        h_c_cpu[i] = h_a[i] + h_b[i];  // CPU 上的正确结果
    }

    // ================================================================
    // Step 3: 分配 GPU 显存
    // ================================================================

    float *d_a, *d_b, *d_c;

    // cudaMalloc: 在 GPU 上（device）分配显存
    // 注意传的是 &d_a（指针的地址），因为 cudaMalloc 需要修改指针指向分配的内存
    CUDA_CHECK(cudaMalloc(&d_a, bytes));
    CUDA_CHECK(cudaMalloc(&d_b, bytes));
    CUDA_CHECK(cudaMalloc(&d_c, bytes));

    printf("显存分配完成: %zu MB 总量\n", 3 * bytes / (1024 * 1024));

    // ================================================================
    // Step 4: 将数据从 host 拷贝到 device
    // ================================================================

    // cudaMemcpy: host ↔ device 数据传输
    // 参数: (dst, src, size, direction)
    CUDA_CHECK(cudaMemcpy(d_a, h_a, bytes, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_b, h_b, bytes, cudaMemcpyHostToDevice));

    printf("数据已拷贝到 GPU\n");

    // ================================================================
    // Step 5: 配置 Kernel launch 参数
    // ================================================================

    // block_size（每个 block 的线程数）：通常选 128 或 256
    // 原则：
    //   - 必须是 32 的倍数（warp 大小）
    //   - 不要超过 1024（GPU 硬限制）
    //   - 128 ~ 256 在大多数 GPU 上 occupancy 最佳
    int block_size = 256;

    // grid_size（block 数量）：向上取整
    // 公式： (n + block_size - 1) / block_size
    // 例如 n=1000, block_size=256 → (1000+255)/256 = 4.9 → 4 blocks
    // 这样最后一个 block 部分线程会 idle（边界检查）
    int grid_size = (n + block_size - 1) / block_size;

    printf("Kernel launch: grid=%d blocks, block=%d threads\n",
           grid_size, block_size);
    printf("线程总数: %d (%.1f%% 有效)\n",
           grid_size * block_size,
           100.0f * n / (grid_size * block_size));

    // ================================================================
    // Step 6: CUDA 事件计时
    // ================================================================

    cudaEvent_t start, stop;
    float elapsed_ms;

    // 创建 CUDA 事件
    CUDA_CHECK(cudaEventCreate(&start));
    CUDA_CHECK(cudaEventCreate(&stop));

    // ================================================================
    // Step 7: Launch Kernel + 计时
    // ================================================================

    // 记录开始时间
    CUDA_CHECK(cudaEventRecord(start, 0));  // 0 = default stream

    // 这是真正的 GPU Kernel 启动！
    // <<<grid_size, block_size>>> 是 CUDA 的 kernel launch 语法
    // 这行代码在 GPU 上启动 grid_size * block_size 个线程
    vector_add<<<grid_size, block_size>>>(d_a, d_b, d_c, n);

    // 记录结束时间
    CUDA_CHECK(cudaEventRecord(stop, 0));

    // 等待 GPU 完成（kernel launch 是异步的，不等待就执行后面的代码）
    // cudaDeviceSynchronize() 也可以，但 cudaEventSynchronize 更精确
    CUDA_CHECK(cudaEventSynchronize(stop));

    // 计算耗时（毫秒）
    CUDA_CHECK(cudaEventElapsedTime(&elapsed_ms, start, stop));

    // ================================================================
    // Step 8: 检查 Kernel 错误
    // ================================================================

    // cudaGetLastError() 检查异步 kernel launch 是否有错误
    // 比如：启动参数无效、shared memory 过大等
    cudaError_t kernel_err = cudaGetLastError();
    if (kernel_err != cudaSuccess) {
        fprintf(stderr, "Kernel launch failed: %s\n",
                cudaGetErrorString(kernel_err));
        exit(EXIT_FAILURE);
    }

    printf("Kernel 执行时间: %.3f ms\n", elapsed_ms);

    // ================================================================
    // Step 9: 计算结果拷贝回 host
    // ================================================================

    CUDA_CHECK(cudaMemcpy(h_c, d_c, bytes, cudaMemcpyDeviceToHost));
    printf("结果已拷贝回 CPU\n");

    // ================================================================
    // Step 10: 验证结果
    // ================================================================

    bool passed = verify_result(h_c_cpu, h_c, n);
    if (passed) {
        printf("✅ 验证通过! GPU 计算结果与 CPU 一致\n");
    } else {
        printf("❌ 验证失败! 结果不一致\n");
    }

    // ================================================================
    // Step 11: 计算有效带宽
    // ================================================================

    // Vector add 需要：
    //   读取: a (n bytes) + b (n bytes) = 2n bytes
    //   写入: c (n bytes) = n bytes
    //   总数据传输: 3 * n bytes
    // 带宽 = 总数据量 / 时间（GB/s）
    double total_bytes = 3.0 * bytes;  // 读 a + 读 b + 写 c
    double bandwidth = total_bytes / (elapsed_ms / 1000.0) / (1024 * 1024 * 1024);

    printf("有效带宽: %.2f GB/s\n", bandwidth);

    // 查看你的 GPU 理论峰值带宽：
    //   A100 80GB: ~2039 GB/s (HBM2e)
    //   H100: ~3352 GB/s (HBM3)
    //   RTX 4090: ~1008 GB/s (GDDR6X)
    //   RTX 3090: ~936 GB/s (GDDR6X)
    // 这个 kernel 是 memory-bound 的，应接近理论峰值

    // ================================================================
    // Step 12: 清理资源
    // ================================================================

    CUDA_CHECK(cudaEventDestroy(start));
    CUDA_CHECK(cudaEventDestroy(stop));
    CUDA_CHECK(cudaFree(d_a));
    CUDA_CHECK(cudaFree(d_b));
    CUDA_CHECK(cudaFree(d_c));
    free(h_a);
    free(h_b);
    free(h_c);
    free(h_c_cpu);

    printf("清理完成，程序退出.\n");
    return passed ? 0 : 1;
}
