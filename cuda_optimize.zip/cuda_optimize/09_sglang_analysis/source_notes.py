﻿"""
source_notes.py — SGLang 源码阅读导航

配合 [docs/22_sglang_source_analysis.md](../docs/22_sglang_source_analysis.md) 使用。

这个文件不是可执行代码, 而是源码阅读笔记 + 导航。
建议按顺序读, 每读一段对照看 SGLang GitHub 源码:
    https://github.com/sgl-project/sglang

学习目标:
    1. 知道 SGLang 的关键文件在哪
    2. 每个文件的核心类是什么
    3. 读源码的顺序建议
    4. 关键算法的实现细节

阅读建议:
    - 第一遍: 通读这个文件, 了解全貌
    - 第二遍: 对照 GitHub 源码逐段读
    - 第三遍: 自己跑 SGLang, 改一点代码看效果
"""

# ============================================================
# SGLang 源码结构 (基于 2024 末版本, 可能略有变化)
# ============================================================
#
# sglang/
# ├── sglang/
# │   ├── srt/                          # SGLang Runtime (服务端)
# │   │   ├── managers/                 # ★ 调度器, tokenizer manager
# │   │   │   ├── scheduler.py          # ★★★ 核心: Scheduler 类, 主循环
# │   │   │   ├── scheduler_output_processor_mixin.py
# │   │   │   ├── io_struct.py          # 进程间通信协议
# │   │   │   ├── tokenizer_manager.py  # Tokenizer + 请求分发
# │   │   │   └── detokenizer_manager.py
# │   │   │
# │   │   ├── model_executor/           # ★ 模型加载与 forward
# │   │   │   ├── model_runner.py       # ★★ ModelRunner 类
# │   │   │   ├── models/               # 各种 LLM 实现 (llama, qwen, ...)
# │   │   │   └── parallel_groups.py    # 多卡并行
# │   │   │
# │   │   ├── layers/                   # ★ 自定义层
# │   │   │   ├── attention/            # ★★ Attention backends
# │   │   │   │   ├── flashinfer.py     # FlashInfer backend (推荐)
# │   │   │   │   ├── flashattention.py # FlashAttention v2/v3
# │   │   │   │   └── triton_backend.py # Triton fallback
# │   │   │   ├── moe/                  # ★ MoE 层 (FusedMoE)
# │   │   │   └── quantization/         # 量化 (AWQ, GPTQ, FP8, ...)
# │   │   │
# │   │   ├── mem_cache/                # ★★ KV Cache 管理
# │   │   │   ├── radix_cache.py        # ★★★ RadixAttention 实现!
# │   │   │   ├── paged_kv_cache.py     # 物理 KV 存储
# │   │   │   └── memory_pool.py        # 显存池
# │   │   │
# │   │   ├── backend/                  # 推理后端 (static batch, ...)
# │   │   ├── constrained/              # 限制输出 (JSON, regex)
# │   │   ├── speculative/              # ★ 投机解码 (EAGLE)
# │   │   └── server_args.py            # 命令行参数
# │   │
# │   ├── lang/                         # ★ 前端 DSL
# │   │   ├── interpreter.py            # DSL 解释器
# │   │   ├── ir.py                     # 中间表示
# │   │   └── frontend.py               # 编译前端
# │   │
# └── ...
#
# ============================================================


# ============================================================
# 阅读顺序建议
# ============================================================
#
# 第 1 周: 入口和总览
#   1. python/sglang/srt/server_args.py
#      - 看 ServerArgs 类, 知道所有可配置参数
#      - 重点: enable_radix_cache, schedule_conservatism, mem_fraction_static
#
#   2. python/sglang/srt/managers/scheduler.py (前 200 行)
#      - 看 Scheduler.__init__, 理解它有哪些组件
#      - 不用看 event_loop 细节, 先知道有哪些队列和 cache
#
# 第 2 周: RadixAttention 核心
#   3. python/sglang/srt/mem_cache/radix_cache.py
#      - 这个文件是 SGLang 的灵魂, 仔细读
#      - 重点: TreeNode, match_prefix, insert, evict
#
#   4. python/sglang/srt/mem_cache/memory_pool.py
#      - 物理 KV 存储怎么分配
#      - 看 req_to_token_pool, token_to_kv_pool
#
# 第 3 周: 调度主循环
#   5. python/sglang/srt/managers/scheduler.py (event_loop_overlap)
#      - 这是 SGLang 的"零开销调度"核心
#      - 重点: CPU 调度 step N+1 和 GPU 跑 step N 重叠
#
#   6. python/sglang/srt/managers/scheduler.py (get_next_batch_to_run)
#      - 调度策略: 优先级, 抢占, batch 大小决定
#
# 第 4 周: 模型执行
#   7. python/sglang/srt/model_executor/model_runner.py
#      - ModelRunner.forward
#      - 看 attention metadata 怎么构造
#
#   8. python/sglang/srt/layers/attention/flashinfer.py
#      - 一个 attention backend 的实现
#      - 看 forward 方法
#
# 第 5 周: 高级特性
#   9. python/sglang/srt/speculative/eagle.py (EAGLE 投机解码)
#  10. python/sglang/srt/layers/moe/ (MoE 实现)
#  11. python/sglang/lang/interpreter.py (DSL 解释器)


# ============================================================
# 关键类和函数详解
# ============================================================


def radix_cache_key_points():
    """
    RadixCache (radix_cache.py) 的关键点

    类: RadixCache
    核心方法:
        match_prefix(key_tokens) -> (matched_node, matched_length)
            沿树找最长前缀匹配
            返回匹配到的节点和匹配长度
            如果某个节点部分匹配, 会触发分裂

        insert(key_tokens, kv_indices) -> inserted_node
            把新的 token 序列和对应 KV 插入树
            可能触发节点分裂

        evict(num_tokens)
            LRU 淘汰, 释放 num_tokens 个 token 的空间
            只淘汰 lock_ref==0 的节点

        inc_lock_ref(node) / dec_lock_ref(node)
            引用计数, 防止正在用的节点被 evict

    关键数据结构:
        TreeNode:
            key: List[int]              # 这个节点存的 token 序列
            value: List[int]            # KV 在物理池中的 indices
            children: Dict[int, TreeNode]
            parent: TreeNode
            lock_ref: int
            last_access_time: float

    关键算法:
        1. match_prefix 中的节点分裂:
           假设树里有节点 [A, B, C, D], 来查询 [A, B, X]
           匹配 A, B 后, 第 3 个 token 不一致
           需要把原节点分裂成 [A, B] 和 [C, D] 两部分
           然后返回 [A, B] 作为匹配结果

        2. insert 时的合并:
           如果插入新节点后, 父节点只剩一个子节点, 可以合并
           但 SGLang 实现里通常不合并, 保持稳定结构

        3. evict 的 LRU:
           遍历所有 lock_ref==0 的叶子节点
           按 last_access_time 排序, 淘汰最早的
           释放对应的 KV 物理 indices
    """
    pass


def scheduler_key_points():
    """
    Scheduler (scheduler.py) 的关键点

    类: Scheduler
    核心方法:
        event_loop_overlap()
            主循环, CPU/GPU 重叠执行
            while True:
                1. recv_requests()           # 收新请求
                2. process_batch_result()    # 处理上一步的结果 (异步)
                3. get_next_batch_to_run()   # 决定这一步跑什么
                4. run_batch()               # 提交到 GPU (异步)

        get_next_batch_to_run() -> Optional[Batch]
            调度决策:
                1. 优先处理 running_queue (decode)
                2. 如果显存够, 从 waiting_queue 拿新请求 (prefill)
                3. 用 RadixCache.match_prefix 查每个新请求能复用多少 KV
                4. 如果显存不够, 触发 evict

        run_batch(batch)
            调用 ModelRunner.forward, 异步返回

    关键优化:
        1. 双缓冲: CPU 调度 step N+1 时, GPU 在跑 step N
           这是"零开销"调度的关键
           vLLM 是同步等 GPU 完成才调度下一步

        2. RadixCache 集成: 新请求 prefill 前, 先查 cache
           复用部分不需要重算

        3. Conservative scheduling: 高负载时主动 reject
           避免 OOM 后被迫 preempt (preempt 代价大)
    """
    pass


def model_runner_key_points():
    """
    ModelRunner (model_runner.py) 的关键点

    类: ModelRunner
    核心方法:
        forward(batch) -> SampleOutput
            1. 准备 inputs (token ids, positions)
            2. 构造 attention metadata (block_table, seq_lens, ...)
            3. 调用 model.forward
            4. 采样 (greedy / top-k / top-p)
            5. 更新 KV Cache (通过 RadixCache)

    关键属性:
        model: 实际的 LLM (LlamaForCausalLM 等)
        kv_caches: 物理 KV 存储 (MultiGroupKVCache)
        req_to_token_pool: 请求级 token 映射
        token_to_kv_pool: token 到 KV 物理 index 的映射

    与 vLLM 的对应:
        vLLM ModelRunner → SGLang ModelRunner
        vLLM AttentionMetadata → SGLang AttentionMetadata
        vLLM Sampler → SGLang Sampler
    """
    pass


def attention_backend_key_points():
    """
    Attention Backend (layers/attention/) 的关键点

    多个 backend:
        flashinfer.py    # 用 FlashInfer 库 (推荐, 最快)
        flashattention.py # 用 FlashAttention v2/v3
        triton_backend.py # Triton kernel (fallback)

    每个 backend 实现:
        class XxxAttentionBackend:
            def forward(
                self,
                q, k, v,          # Q, K, V 张量
                attention_metadata,  # 位置, 长度, block_table
            ) -> output

    关键: attention_metadata 的构造
        - 在 prefill 时: 包含每个请求的 seq_len
        - 在 decode 时: 包含每个请求的 block_table (指向 RadixCache)
        - 不同 backend 的 metadata 结构略不同

    SGLang 的优势: attention 层和 RadixCache 紧密集成
        传统 vLLM: KV Cache 是线性连续的
        SGLang: KV Cache 在 RadixCache 里是树形的, attention 层要处理这个
    """
    pass


def dsl_interpreter_key_points():
    """
    DSL Interpreter (lang/interpreter.py) 的关键点

    类: ProgramState (也叫 s)
        s += "text"     # 把 text 加到当前对话
        s += gen("var") # 触发推理, 结果存到 s["var"]

    关键: gen() 的执行
        gen() 不是立即执行, 而是把"生成请求"加入队列
        真正执行在 run_batch 时

    优化点:
        1. 编译时分析: 知道哪些 prefix 是固定的
        2. 自动应用 RadixCache: 固定 prefix 会被缓存
        3. 批量调用: run_batch 一次性处理多个对话
            SGLang 会自动 batch 共享 prefix 的请求

    示例:
        @sgl.function
        def multi_turn(s, q):
            s += sgl.user(f"Q: {q}")
            s += sgl.assistant(sgl.gen("answer"))

        # 批量调用 1000 个不同 q
        states = multi_turn.run_batch([{"q": x} for x in questions])

        SGLang 内部:
            - 所有 1000 个请求共享 sgl.user 的模板结构
            - 自动用 RadixCache 复用
            - 批量调度, 吞吐提升明显
    """
    pass


# ============================================================
# 读源码的常见问题
# ============================================================

READING_TIPS = """
读 SGLang 源码的常见问题:

Q1: 为什么有这么多 mixin?
A1: Scheduler 用 mixin 拆分不同职责 (调度, 输出处理, 抢占等)
    看 Scheduler 类的基类列表, 每个 mixin 负责一块
    读的时候按 mixin 单独读, 不要一次看全部

Q2: event_loop_overlap 看不懂?
A2: 关键是理解双缓冲:
    - CPU 线程: 调度 + 处理结果 (Python)
    - GPU: 模型 forward (CUDA)
    - 两者并行: CPU 调度 step N+1 时, GPU 在跑 step N
    类比: 流水线, 不同 stage 同时工作

Q3: RadixCache 的 insert 逻辑复杂?
A3: 分三步:
    1. 找最长前缀匹配 (match_prefix)
    2. 如果需要, 分裂现有节点
    3. 把新节点挂上去, 存 KV
    画图辅助理解, 每次插入都画一下树形变化

Q4: KV 物理 index 怎么管理?
A4: 看 memory_pool.py:
    - req_to_token_pool: 每个请求的 token 序列 → KV index
    - token_to_kv_pool: KV index → 实际 KV 张量
    - 两者配合实现"逻辑 token → 物理 KV"的映射

Q5: 怎么调试 SGLang?
A5: 几个方法:
    - 加日志: 在 scheduler.py 加 print, 看每步调度
    - 用小模型: Llama-3-8B 跑得快, 方便调试
    - 单请求: 先测单请求, 再测批量
    - 看 metrics: 启动时 --metrics-port 暴露 Prometheus
"""

# ============================================================
# 实战练习建议
# ============================================================

EXERCISES = """
学完源码后的实战练习:

练习 1: 加日志看调度
    在 scheduler.py 的 event_loop_overlap 加 print
    跑一个多请求场景, 看每步调度决策

练习 2: 改 LRU 策略
    把 RadixCache 的 evict 改成 LFU (least frequently used)
    跑 benchmark 看命中率变化

练习 3: 加自定义 attention backend
    实现一个简单的 attention backend (即使慢)
    理解 attention metadata 的构造

练习 4: 对比 vLLM
    同样模型同样负载, 跑 vLLM 和 SGLang
    看吞吐 / 延迟 / 显存占用差异

练习 5: 改调度策略
    实现"VIP 请求优先" (某些请求 id 优先调度)
    理解 scheduler 的优先级机制

练习 6: 跑 SGLang benchmark
    SGLang 自带 benchmark 工具:
    python -m sglang.bench_serving --backend sglang --model ...
    对比不同参数的效果
"""

# ============================================================
# 主入口 (打印导航)
# ============================================================

if __name__ == "__main__":
    print("=" * 70)
    print("SGLang 源码阅读导航")
    print("=" * 70)
    print()
    print("详细阅读顺序和关键点见本文件注释。")
    print()
    print("快速开始:")
    print("  1. 先读本文件的所有 docstring")
    print("  2. 对照 SGLang GitHub 源码: https://github.com/sgl-project/sglang")
    print("  3. 按 5 周计划逐文件读")
    print()
    print("必读文件清单:")
    print("  ★★★ srt/mem_cache/radix_cache.py       RadixAttention 核心")
    print("  ★★★ srt/managers/scheduler.py          调度器主循环")
    print("  ★★  srt/model_executor/model_runner.py 模型 forward")
    print("  ★★  srt/layers/attention/              Attention backends")
    print("  ★   lang/interpreter.py                前端 DSL")
    print("  ★   srt/speculative/eagle.py           投机解码")
    print()
    print("练习建议:")
    print(EXERCISES)
