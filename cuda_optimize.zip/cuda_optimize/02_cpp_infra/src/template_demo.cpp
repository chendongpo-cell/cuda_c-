/*
 * template_demo.cpp — 模板与推理场景应用详解
 *
 * 知识点覆盖：
 *   ✅ 函数模板与类模板
 *   ✅ 变参模板 (Variadic Templates) + 折叠表达式 (C++17)
 *   ✅ if constexpr 编译期分支 (C++17)
 *   ✅ 模板特化与偏特化
 *   ✅ SFINAE
 *
 * 推理场景：数据类型泛化的 Kernel 封装（同一个 kernel 支持 FP16/BF16/FP32/FP8）
 *
 * 编译：g++ -std=c++17 -o template_demo template_demo.cpp
 * 运行：./template_demo
 */

#include <iostream>
#include <type_traits>
#include <cstdint>   // int8_t, uint8_t

/* ================================================================
 * 1. 函数模板基础
 *
 * template <typename T> 告诉编译器：T 是一个类型参数
 * 编译器在实例化时根据实际类型生成对应代码——零开销抽象。
 *
 * 推理场景：同样的 kernel 函数要支持 FP32/FP16/BF16/FP8 多种精度
 * ================================================================ */

// 基本函数模板
template <typename T>
T add(T a, T b) {
    return a + b;
}

// 多类型参数模板
template <typename T, typename U>
auto multiply(T a, U b) -> decltype(a * b) {
    return a * b;
}

// 非类型模板参数（值也是模板参数！）
// 推理场景：BLOCK_SIZE、WARP_SIZE 等编译期常量
template <typename T, size_t BLOCK_SIZE>
T block_sum(const T* data) {
    T sum = 0;
    for (size_t i = 0; i < BLOCK_SIZE; ++i) {
        sum += data[i];
    }
    return sum;
}


/* ================================================================
 * 2. 类模板
 *
 * 推理场景：推理引擎中固定大小的向量/矩阵缓冲区
 * ================================================================ */

template <typename T, size_t N>
class StaticVector {
private:
    T data_[N];  // 栈上数组，无堆分配

public:
    StaticVector() {
        for (size_t i = 0; i < N; ++i) data_[i] = T{};
    }

    T& operator[](size_t index) { return data_[index]; }
    const T& operator[](size_t index) const { return data_[index]; }
    size_t size() const { return N; }
    T* data() { return data_; }
    const T* data() const { return data_; }
};


/* ================================================================
 * 3. 变参模板 —— C++17 折叠表达式
 *
 * 推理场景：融合 kernel 接收可变数量参数
 * 例如 fused_add_residual_layernorm(a, b, gamma, beta, eps)
 * ================================================================ */

// C++17 折叠表达式：一元右折叠
template <typename... Args>
auto sum_all(Args... args) {
    return (args + ...);  // (arg1 + (arg2 + (arg3 + ...)))
}

// 打印所有参数（调试用）
template <typename... Args>
void debug_print(Args... args) {
    ((std::cout << args << " "), ...);  // 逗号折叠
    std::cout << std::endl;
}


/* ================================================================
 * 4. if constexpr 编译期分支 (C++17)
 *
 * 普通 if：所有分支都被编译
 * if constexpr：不满足条件的分支在编译期丢弃
 *
 * 推理场景：根据数据类型选择不同的 kernel 实现路径
 * ================================================================ */

void do_sgemm(int m, int n, int k) {
    std::cout << "    [FP32 SGEMM] m=" << m << " n=" << n << " k=" << k << std::endl;
}

void do_hgemm(int m, int n, int k) {
    std::cout << "    [FP16 HGEMM] m=" << m << " n=" << n << " k=" << k << std::endl;
}

// 编译期根据数据类型分派不同的 GEMM
template <typename T>
void dispatch_gemm(int m, int n, int k) {
    if constexpr (std::is_same_v<T, float>) {
        do_sgemm(m, n, k);  // T=float 时只编译此分支
    } else if constexpr (std::is_same_v<T, short>) {
        do_hgemm(m, n, k);  // T=short(模拟half) 时只编译此分支
    } else {
        static_assert(sizeof(T) == 0, "不支持的精度类型");
    }
}


/* ================================================================
 * 5. 模板特化
 *
 * 全特化：为特定类型提供不同实现
 * 偏特化：为一类类型提供不同实现
 *
 * 推理场景：INT8 需要特殊反量化逻辑
 * ================================================================ */

template <typename T>
struct Quantizer {
    static float dequantize(T val, float scale) {
        return static_cast<float>(val) * scale;
    }
};

// 全特化：int8_t 的反量化
template <>
struct Quantizer<int8_t> {
    static float dequantize(int8_t val, float scale) {
        return static_cast<float>(val) * scale;
    }
};

// 全特化：uint4（用 uint8_t 模拟，一个字节存两个 4-bit 值）
template <>
struct Quantizer<uint8_t> {
    static float dequantize(uint8_t val, float scale) {
        float low = static_cast<float>(val & 0x0F) * scale;   // 取低 4 位
        return low;
    }
};


/* ================================================================
 * 6. SFINAE (Substitution Failure Is Not An Error)
 *
 * 模板实例化时非法代码不报错，只是移除这个重载。
 * C++17 推荐用 if constexpr 替代大部分 SFINAE 场景。
 * ================================================================ */

// 只有浮点类型才能调用的版本
template <typename T>
typename std::enable_if<std::is_floating_point<T>::value, void>::type
only_for_floats(T value) {
    std::cout << "  " << value << " 是浮点数" << std::endl;
}

// 整数类型的版本
template <typename T>
typename std::enable_if<std::is_integral<T>::value, void>::type
only_for_floats(T value) {
    std::cout << "  " << value << " 是整数（SFINAE 自动匹配此版本）" << std::endl;
}


/* ================================================================
 * main
 * ================================================================ */

int main() {
    std::cout << "===== 1. 基础函数模板 =====" << std::endl;
    {
        std::cout << "  add<int>(3, 5) = " << add<int>(3, 5) << std::endl;
        std::cout << "  add(2.5, 3.7) = " << add(2.5, 3.7) << std::endl;
        std::cout << "  multiply(3, 4.5) = " << multiply(3, 4.5) << std::endl;
    }

    std::cout << "\n===== 2. 类模板 & 非类型参数 =====" << std::endl;
    {
        StaticVector<float, 4> vec;
        vec[0] = 1.0f; vec[1] = 2.0f; vec[2] = 3.0f; vec[3] = 4.0f;
        std::cout << "  StaticVector<float,4> size=" << vec.size()
                  << " sum=" << (vec[0] + vec[1] + vec[2] + vec[3]) << std::endl;

        StaticVector<float, 256> big_vec;
        big_vec[0] = 42.0f;
        std::cout << "  block_sum<float,256>: " << block_sum<float, 256>(big_vec.data()) << std::endl;
    }

    std::cout << "\n===== 3. 变参模板 + 折叠表达式 =====" << std::endl;
    {
        std::cout << "  sum_all(1, 2, 3, 4, 5) = " << sum_all(1, 2, 3, 4, 5) << std::endl;
        std::cout << "  sum_all(1.5, 2.5, 3.0) = " << sum_all(1.5, 2.5, 3.0) << std::endl;
        std::cout << "  debug_print: ";
        debug_print("tensor", "shape", 3, 4, "dtype=float32");
    }

    std::cout << "\n===== 4. if constexpr 编译期分派 =====" << std::endl;
    {
        std::cout << "  dispatch_gemm<float>:" << std::endl;
        dispatch_gemm<float>(1024, 1024, 4096);

        std::cout << "  dispatch_gemm<short>:" << std::endl;
        dispatch_gemm<short>(1024, 1024, 4096);
    }

    std::cout << "\n===== 5. 模板特化 =====" << std::endl;
    {
        std::cout << "  int8 反量化: "
                  << Quantizer<int8_t>::dequantize(42, 0.5f)
                  << " (42 * 0.5)" << std::endl;

        std::cout << "  uint4(低4位) 反量化: "
                  << Quantizer<uint8_t>::dequantize(0xAB, 0.5f)
                  << " (读取 0xB * 0.5)" << std::endl;
    }

    std::cout << "\n===== 6. SFINAE =====" << std::endl;
    {
        only_for_floats(3.14);
        only_for_floats(42);
    }

    return 0;
}
