/*
 * modern_features.cpp — 现代 C++ 特性详解（推理优化场景）
 *
 * 知识点覆盖：
 *   ✅ Lambda 表达式 + capture 模式
 *   ✅ 右值引用 && Move 语义 + 完美转发
 *   ✅ std::optional / std::variant / std::any (C++17)
 *   ✅ std::string_view (C++17)
 *   ✅ structured binding (C++17)
 *
 * 编译：g++ -std=c++17 -o modern_features modern_features.cpp
 * 运行：./modern_features
 */

#include <iostream>
#include <vector>
#include <string>
#include <optional>
#include <variant>
#include <any>
#include <string_view>
#include <cstring>     // strlen
#include <chrono>      // std::chrono (string_view 性能对比)
#include <functional>  // std::function

/* ================================================================
 * 1. Lambda 表达式
 *
 * 推理场景：CUDA kernel launch 的封装、自定义排序/过滤、
 *           调度器的任务回调、延迟执行的 kernel launch
 * ================================================================ */

// 模拟 GPU kernel launch
// 在真实 CUDA 中：kernel<<<grid, block, shared_mem, stream>>>(args);
// 这里用 lambda 封装 launch 前后逻辑
void launch_gpu_kernel(std::function<void()> kernel_func, const std::string& name) {
    std::cout << "  [Launch] " << name << " ... ";
    // 真实场景：cudaEventRecord(start);
    kernel_func();  // 调用 kernel
    // 真实场景：cudaEventRecord(stop); cudaEventSynchronize();
    std::cout << " 完成" << std::endl;
}

void demo_lambda() {
    std::cout << "--- Lambda 表达式 ---" << std::endl;

    // 基础 lambda：计算平方
    // [] 捕获列表，() 参数列表，{} 函数体
    auto square = [](int x) { return x * x; };
    std::cout << "  square(5) = " << square(5) << std::endl;

    // 值捕获 [=]：复制外部变量到 lambda 内部
    // 推理场景：在 launch kernel 时捕获当前 stream、kernel params
    int seq_id = 42;
    std::string kernel_name = "flash_attention";
    auto launch_kernel = [=]() {
        // = 捕获了 seq_id 和 kernel_name 的拷贝
        std::cout << "kernel=" << kernel_name << " seq=" << seq_id;
    };
    launch_gpu_kernel(launch_kernel, "capture_by_value");
    // 注意：值捕获的变量在 lambda 创建时"快照"，之后修改外部变量不影响 lambda 内部

    // 引用捕获 [&]：捕获外部变量的引用
    // 推理场景：需要在 lambda 中修改调度器的状态
    int counter = 0;
    auto increment = [&]() { counter++; };
    increment();
    increment();
    std::cout << "  引用捕获 counter = " << counter << " (期望 2)" << std::endl;

    // 指定捕获 [x, &y]
    int a = 1, b = 2;
    auto mixed = [a, &b]() {
        // a 是值捕获（只读），b 是引用捕获（可修改）
        // return a + b++;  // 编译错误：a 是 const
        return b++;  // 可以修改 b
    };
    mixed();
    std::cout << "  a=" << a << " b=" << b << " (b 被修改)" << std::endl;

    // 泛型 lambda (C++14)
    auto generic_add = [](auto x, auto y) { return x + y; };
    std::cout << "  泛型 lambda: " << generic_add(3, 4)
              << ", " << generic_add(2.5, 3.7) << std::endl;

    // mutable lambda：值捕获的变量也可以在内部修改
    // 推理场景：统计多个 kernel launch 的耗时
    int total_launches = 0;
    auto launch_counter = [total_launches]() mutable {
        // mutable 允许修改值捕获的变量（但外部不受影响）
        total_launches++;
        std::cout << "  当前 launch 次数（内部）: " << total_launches << std::endl;
    };
    launch_counter();
    launch_counter();
    std::cout << "  外部 total_launches = " << total_launches << " (仍然是 0)" << std::endl;
}


/* ================================================================
 * 2. 右值引用 && Move 语义 + 完美转发
 *
 * 这是 C++11 最重要的优化特性。
 * 核心思想：临时对象（右值）的资源可以"偷"而不是"拷贝"。
 *
 * 推理场景：
 *   - 推理请求在调度器之间转移所有权
 *   - KV cache block 在 block table 之间移动
 *   - Tensor 数据从 prefill stage 传到 decode stage
 * ================================================================ */

// 手动实现简易 string（展示 Move 语义）
// 真实 std::string 内部已经实现了 move 优化
class MyString {
private:
    char* data_;       // 堆上分配的 C 风格字符串
    size_t size_;      // 字符串长度

public:
    // 构造函数：分配内存并拷贝字符串
    explicit MyString(const char* str) : size_(strlen(str)) {
        data_ = new char[size_ + 1];
        memcpy(data_, str, size_ + 1);
        std::cout << "  [构造] 分配 " << size_ << " chars: " << str << std::endl;
    }

    // 析构函数：释放内存
    ~MyString() {
        if (data_) {
            std::cout << "  [析构] 释放: " << data_ << std::endl;
            delete[] data_;
        }
    }

    // 拷贝构造函数（深拷贝 — 成本高！）
    MyString(const MyString& other) : size_(other.size_) {
        data_ = new char[size_ + 1];
        memcpy(data_, other.data_, size_ + 1);
        std::cout << "  [深拷贝] 从 \"" << other.data_ << "\" 拷贝（O(n) 开销）" << std::endl;
    }

    // 拷贝赋值操作符
    MyString& operator=(const MyString& other) {
        if (this != &other) {
            delete[] data_;
            size_ = other.size_;
            data_ = new char[size_ + 1];
            memcpy(data_, other.data_, size_ + 1);
            std::cout << "  [拷贝赋值] " << other.data_ << std::endl;
        }
        return *this;
    }

    // 移动构造函数（浅拷贝 + 源对象置空 — O(1)！）
    // && 表示"右值引用"：只接受临时对象
    // noexcept 告诉编译器此函数不会抛异常
    MyString(MyString&& other) noexcept
        : data_(other.data_), size_(other.size_) {
        // 关键：直接把 other 的指针偷过来
        // 然后把 other 的指针置空，other 不再拥有资源
        other.data_ = nullptr;
        other.size_ = 0;
        std::cout << "  [移动] O(1) 转移所有权" << std::endl;
    }

    // 移动赋值操作符
    MyString& operator=(MyString&& other) noexcept {
        if (this != &other) {
            delete[] data_;          // 释放当前资源
            data_ = other.data_;     // 偷取 other 的资源
            size_ = other.size_;
            other.data_ = nullptr;   // other 不再拥有资源
            other.size_ = 0;
            std::cout << "  [移动赋值] O(1)" << std::endl;
        }
        return *this;
    }

    const char* c_str() const { return data_ ? data_ : "(null)"; }
    size_t size() const { return size_; }
};

// 完美转发演示
// 推理场景：工厂函数创建不同类型的请求/reuqest/tensor
// 函数参数可以指定不同的引用类型

// 左值引用 &：只能绑定到左值（有名字的变量）
void process_value(int& x) {
    std::cout << "  左值引用 &: " << x << std::endl;
}

// 右值引用 &&：只能绑定到右值（临时对象）
void process_value(int&& x) {
    std::cout << "  右值引用 &&: " << x << std::endl;
}

// 万能引用 T&& + 完美转发
// T&& 在模板上下文中是"万能引用"（不是右值引用）
// std::forward<T>() 保持参数的左右值属性不变
template <typename T>
void forward_example(T&& arg) {
    // 如果传入的是左值，调用 process_value(int&)
    // 如果传入的是右值，调用 process_value(int&&)
    // 如果不用 forward，arg 永远是左值（因为有名字）
    process_value(std::forward<T>(arg));
}


void demo_move_semantics() {
    std::cout << "\n--- Move 语义 ---" << std::endl;

    std::cout << "  [场景 1] 深拷贝（无 move 优化的情况）:" << std::endl;
    MyString s1("Hello, world!");
    MyString s2 = s1;  // 调用拷贝构造函数（深拷贝）
    std::cout << "  s1 = " << s1.c_str() << " (仍有效)" << std::endl;
    std::cout << "  s2 = " << s2.c_str() << std::endl;

    std::cout << "\n  [场景 2] Move 语义（临时对象）:" << std::endl;
    // MyString("Temp") 是右值（临时对象），自动调用移动构造函数
    // "偷走"临时对象的资源指针，临时对象析构时不会释放已偷走的资源
    MyString s3 = MyString("Temporary!");
    std::cout << "  s3 = " << s3.c_str() << std::endl;

    std::cout << "\n  [场景 3] 显式 move:" << std::endl;
    MyString s4("To be moved");
    MyString s5 = std::move(s4);  // 强制调用移动构造函数
    // 注意：move 之后 s4 处于"合法但未指定"状态
    std::cout << "  s4 = " << s4.c_str() << " (s4 已被偷空)" << std::endl;
    std::cout << "  s5 = " << s5.c_str() << " (s5 获得了资源)" << std::endl;
    // s4 可以重新赋值或销毁，但不能假设其值

    std::cout << "\n  [场景 4] std::move 在 vector 中的效果:" << std::endl;
    std::vector<MyString> vec;
    vec.reserve(2);  // 避免多次 reallocation
    vec.push_back(MyString("VecItem1"));  // 临时对象 → 移动构造
    std::cout << "  ---" << std::endl;

    std::cout << "\n  [场景 5] 完美转发:" << std::endl;
    int x = 10;
    std::cout << "  传入左值 x:" << std::endl;
    forward_example(x);       // T=int& → forward 为 int&
    std::cout << "  传入右值 20:" << std::endl;
    forward_example(20);      // T=int → forward 为 int&&
}


/* ================================================================
 * 3. std::optional / std::variant / std::any (C++17)
 *
 * 推理场景：
 *   - optional：调度器中的"这个请求是否有 KV cache 命中"
 *   - variant：引擎支持多种数据类型（FP16/BF16/FP8）
 *   - any：配置参数（不推荐在高性能路径使用）
 * ================================================================ */

void demo_optional_variant_any() {
    std::cout << "\n--- std::optional / variant / any ---" << std::endl;

    // optional：可能为空的值
    // 推理场景：Prefix Cache 命中查询
    // 如果命中返回对应的 KV cache block，否则返回 nullopt
    std::cout << "  [optional] 模拟 Prefix Cache 查找:" << std::endl;

    auto find_in_cache = [](const std::string& prefix) -> std::optional<int> {
        // 模拟：某些 prefix 命中，某些不命中
        if (prefix == "hello") {
            return 42;  // 返回 block_id = 42
        }
        return std::nullopt;  // 没有命中
    };

    // 安全的访问方式
    auto result1 = find_in_cache("hello");
    if (result1.has_value()) {
        std::cout << "    'hello' 命中! block_id = " << *result1 << std::endl;
    }

    auto result2 = find_in_cache("world");
    if (!result2) {  // operator bool()
        std::cout << "    'world' 未命中 cache" << std::endl;
    }

    // value_or()：有值返回值，无值返回默认值
    int block_id = find_in_cache("unknown").value_or(-1);
    std::cout << "    'unknown' value_or(-1) = " << block_id << std::endl;

    // variant：类型安全的联合体
    // 推理场景：推理引擎的 dtype 可以是多种精度
    std::cout << "\n  [variant] 多精度支持:" << std::endl;

    // 定义一个可以存 float / int / 字符串的变量
    std::variant<float, int, std::string> dtype;

    dtype = float(1.0);  // 存 float
    std::cout << "    dtype 是 float: "
              << std::get<float>(dtype) << std::endl;

    dtype = 8;  // 存 int（表示 INT8 量化位宽）
    std::cout << "    dtype 是 int: "
              << std::get<int>(dtype) << std::endl;

    // std::get_if 安全访问（不抛异常）
    if (auto* v = std::get_if<std::string>(&dtype)) {
        std::cout << "    是 string: " << *v << std::endl;
    } else {
        std::cout << "    当前不是 string 类型" << std::endl;
    }

    // any：任意类型（不推荐用于高性能代码）
    // 推理场景：模型配置参数
    std::cout << "\n  [any] 配置参数:" << std::endl;
    std::any config;
    config = 4096;  // hidden_size
    std::cout << "    hidden_size = " << std::any_cast<int>(config) << std::endl;
    config = std::string("llama");
    std::cout << "    model_type = " << std::any_cast<std::string>(config) << std::endl;
}


/* ================================================================
 * 4. std::string_view (C++17)
 *
 * 零拷贝的字符串引用。不持有数据，只持有指针+长度。
 * 推理场景：Tokenizer 输出、配置文件读取、日志输出
 * ================================================================ */

void demo_string_view() {
    std::cout << "\n--- std::string_view (零拷贝字符串) ---" << std::endl;

    // 可以从多种来源构造 string_view，不拷贝数据
    std::string s = "这是一个很长的模型名称：Meta-Llama-3-70B-Instruct";
    std::string_view sv(s);  // 不拷贝！只存指针和长度

    std::cout << "  string_view 长度: " << sv.size() << std::endl;
    std::cout << "  子串: " << sv.substr(0, 10) << "..." << std::endl;

    // 推理场景：解析模型名称
    auto extract_model_family = [](std::string_view model_name) -> std::string_view {
        // 找到第一个 '-' 之前的部分
        auto pos = model_name.find('-');
        if (pos != std::string_view::npos) {
            return model_name.substr(0, pos);
        }
        return model_name;
    };

    std::string_view family = extract_model_family(sv);
    std::cout << "  模型系列: " << family << std::endl;

    // 性能对比演示
    std::cout << "  性能对比:" << std::endl;
    std::string big_string(100000, 'A');

    // 方式 1：拷贝子串（O(n)）
    auto t1 = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 1000; ++i) {
        std::string sub = big_string.substr(0, 50000);
        volatile size_t len = sub.size();  // 防止编译器优化掉
    }
    auto t2 = std::chrono::high_resolution_clock::now();

    // 方式 2：string_view（O(1)）
    auto t3 = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 1000; ++i) {
        std::string_view sub = big_string;
        sub = sub.substr(0, 50000);
        volatile size_t len = sub.size();
    }
    auto t4 = std::chrono::high_resolution_clock::now();

    auto copy_time = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
    auto view_time = std::chrono::duration_cast<std::chrono::microseconds>(t4 - t3).count();
    std::cout << "  子串拷贝: " << copy_time << " us" << std::endl;
    std::cout << "  string_view: " << view_time << " us (零拷贝!)" << std::endl;

    // 警告：string_view 不拥有数据！
    // std::string_view dangling() {
    //     std::string temp = "临时字符串";
    //     return temp;  // 危险！temp 离开作用域后 string_view 悬垂
    // }
}


/* ================================================================
 * 5. Structured Binding (C++17)
 *
 * 推理场景：解析 KV cache block 的 metadata，解析 tensor shape
 * ================================================================ */

// 模拟一个 KV cache block 的 metadata
struct BlockMetadata {
    int block_id;
    size_t num_tokens;
    bool is_full;
};

void demo_structured_binding() {
    std::cout << "\n--- Structured Binding (结构化绑定) ---" << std::endl;

    // 绑定结构体成员
    BlockMetadata block{1, 16, true};
    auto [id, tokens, full] = block;
    std::cout << "  block_id=" << id << " tokens=" << tokens
              << " full=" << (full ? "yes" : "no") << std::endl;

    // 绑定数组
    int tensor_shape[4] = {1, 1024, 1024, 64};  // [B, H, S, D]
    auto [batch, heads, seq, dim] = tensor_shape;
    std::cout << "  tensor shape: B=" << batch << " H=" << heads
              << " S=" << seq << " D=" << dim << std::endl;

    // 绑定 tuple/pair
    std::pair<std::string, int> cache_result{"block_42", 16};
    auto [block_name, token_count] = cache_result;
    std::cout << "  cache: " << block_name << " tokens=" << token_count << std::endl;
}


/* ================================================================
 * main
 * ================================================================ */

int main() {
    demo_lambda();
    demo_move_semantics();
    demo_optional_variant_any();
    demo_string_view();
    demo_structured_binding();
    return 0;
}
