/*
 * raii_demo.cpp — RAII 与智能指针详解（推理引擎场景）
 *
 * 知识点覆盖：
 *   ✅ unique_ptr / shared_ptr / weak_ptr 使用
 *   ✅ RAII 原理：构造函数获取资源，析构函数释放资源
 *   ✅ Move 语义转移所有权
 *   ✅ 推理引擎 Block 管理模拟
 *
 * 编译：g++ -std=c++17 -o raii_demo raii_demo.cpp
 * 运行：./raii_demo
 */

#include <iostream>   // std::cout, std::endl
#include <memory>     // std::unique_ptr, std::shared_ptr, std::make_unique, std::make_shared
#include <vector>     // std::vector
#include <cassert>    // assert() 断言
#include <string>     // std::string

/* ================================================================
 * 1. RAII 基础：模拟 GPU 显存资源管理
 *
 * RAII（Resource Acquisition Is Initialization）：
 *   - 资源（显存/文件/锁）在构造函数中分配
 *   - 资源在析构函数中释放（离开作用域自动调用）
 *   - 异常安全：即使中途抛出异常，栈展开也会调用析构函数
 *
 * 推理场景：推理引擎中每个 KV cache block 就是 RAII 管理的资源
 * ================================================================ */

class GpuBuffer {
private:
    float* data_;        // 模拟的 GPU 显存指针（这里用 host memory 模拟）
    size_t size_;        // 元素个数
    std::string name_;   // 调试用名称

public:
    // 构造函数：获取资源（模拟在 GPU 上分配显存）
    explicit GpuBuffer(size_t size, std::string name = "unnamed")
        : size_(size), name_(std::move(name)) {

        // 模拟显存分配：用 new 在堆上申请连续内存
        // 在真实 CUDA 场景：cudaMalloc(&data_, size * sizeof(float))
        data_ = new float[size_];

        // 初始化数据为 0（对应 cudaMemset）
        for (size_t i = 0; i < size_; ++i) {
            data_[i] = 0.0f;
        }

        std::cout << "[构造] " << name_
                  << " 分配 " << size_ * sizeof(float)
                  << " 字节" << std::endl;
    }

    // 析构函数：释放资源（模拟显存释放）
    // 关键点：离开作用域自动调用，即使中间有异常
    ~GpuBuffer() {
        // 模拟显存释放：delete[] 释放 new[] 分配的内存
        // 在真实 CUDA 场景：cudaFree(data_)
        delete[] data_;
        std::cout << "[析构] " << name_
                  << " 释放 " << size_ * sizeof(float)
                  << " 字节" << std::endl;
    }

    // 禁止拷贝（显存资源通常不允许拷贝，只能移动）
    GpuBuffer(const GpuBuffer&) = delete;
    GpuBuffer& operator=(const GpuBuffer&) = delete;

    // 允许移动（转移所有权：源对象的指针置空）
    GpuBuffer(GpuBuffer&& other) noexcept
        : data_(other.data_), size_(other.size_), name_(std::move(other.name_)) {
        // 把源对象的指针置空，源对象不再持有资源
        other.data_ = nullptr;
        other.size_ = 0;
        std::cout << "[移动构造] " << name_ << std::endl;
    }

    // Move assignment operator
    GpuBuffer& operator=(GpuBuffer&& other) noexcept {
        if (this != &other) {          // 防止自我赋值
            delete[] data_;            // 先释放当前持有的资源
            data_ = other.data_;       // 偷走 other 的资源
            size_ = other.size_;
            name_ = std::move(other.name_);
            other.data_ = nullptr;     // other 不再持有资源
            other.size_ = 0;
        }
        return *this;
    }

    // 写入数据（模拟计算后将结果写回显存）
    void fill(float value) {
        for (size_t i = 0; i < size_; ++i) {
            data_[i] = value;
        }
    }

    // 读取数据
    float at(size_t index) const {
        assert(index < size_);          // 越界检查（debug 模式有效）
        return data_[index];
    }

    // 返回裸指针（用于传递给 CUDA kernel）
    float* get() const { return data_; }

    size_t size() const { return size_; }
};


/* ================================================================
 * 2. 推理场景实战：KV Cache Block 管理器
 * ================================================================ */

// 模拟一个 KV cache block：存放若干 token 的 K/V
class KVCacheBlock {
private:
    static constexpr size_t BLOCK_SIZE = 16;
    static constexpr size_t HIDDEN_DIM = 64;

    float* key_cache_;
    float* value_cache_;
    int block_id_;

public:
    explicit KVCacheBlock(int block_id) : block_id_(block_id) {
        size_t bytes = BLOCK_SIZE * HIDDEN_DIM * sizeof(float);
        key_cache_ = new float[BLOCK_SIZE * HIDDEN_DIM];
        value_cache_ = new float[BLOCK_SIZE * HIDDEN_DIM];
        std::cout << "  [Block #" << block_id_
                  << "] 分配 K: " << bytes << " bytes + V: " << bytes << " bytes"
                  << std::endl;
    }

    ~KVCacheBlock() {
        delete[] key_cache_;
        delete[] value_cache_;
        std::cout << "  [Block #" << block_id_ << "] 释放" << std::endl;
    }

    KVCacheBlock(const KVCacheBlock&) = delete;
    KVCacheBlock& operator=(const KVCacheBlock&) = delete;
};

// Block 表：一个推理请求持有的所有 block
class BlockTable {
private:
    // unique_ptr 的 vector：每个 block 独占所有权
    std::vector<std::unique_ptr<KVCacheBlock>> blocks_;

public:
    // 为一个请求分配 N 个 block
    void allocate_blocks(int num_blocks) {
        for (int i = 0; i < num_blocks; ++i) {
            blocks_.push_back(
                std::make_unique<KVCacheBlock>(static_cast<int>(blocks_.size()))
            );
        }
    }

    void free_all() {
        blocks_.clear();
    }

    size_t num_blocks() const { return blocks_.size(); }
};


/* ================================================================
 * 3. shared_ptr 演示：模型权重共享
 * ================================================================ */

class ModelWeights {
public:
    explicit ModelWeights(size_t num_params) {
        std::cout << "  [ModelWeights] 加载 " << num_params
                  << " 参数..." << std::endl;
    }
    ~ModelWeights() {
        std::cout << "  [ModelWeights] 卸载权重（最后一个请求结束）" << std::endl;
    }
};

class InferenceRequest {
private:
    std::shared_ptr<ModelWeights> weights_;

public:
    explicit InferenceRequest(std::shared_ptr<ModelWeights> weights)
        : weights_(std::move(weights)) {
        std::cout << "  [Request] 开始推理，引用计数: "
                  << weights_.use_count() << std::endl;
    }

    ~InferenceRequest() {
        if (weights_) {
            std::cout << "  [Request] 结束推理，引用计数: "
                      << weights_.use_count() - 1 << std::endl;
        }
    }
};


/* ================================================================
 * 4. weak_ptr 演示：解决循环引用
 * ================================================================ */

class B;

class A {
public:
    std::weak_ptr<B> b_ptr;  // weak_ptr 不增加引用计数
    ~A() { std::cout << "  [~A] A 析构" << std::endl; }
};

class B {
public:
    std::shared_ptr<A> a_ptr;
    ~B() { std::cout << "  [~B] B 析构" << std::endl; }
};


/* ================================================================
 * Demo 函数声明
 * ================================================================ */

void demo_unique_ptr();
void demo_block_table();
void demo_shared_ptr();
void demo_weak_ptr();

int main() {
    std::cout << "===== 1. unique_ptr 基础 =====" << std::endl;
    demo_unique_ptr();

    std::cout << "\n===== 2. KV Cache Block 管理 =====" << std::endl;
    demo_block_table();

    std::cout << "\n===== 3. shared_ptr 模型共享 =====" << std::endl;
    demo_shared_ptr();

    std::cout << "\n===== 4. weak_ptr 解决循环引用 =====" << std::endl;
    demo_weak_ptr();

    std::cout << "\n程序结束，所有资源自动释放." << std::endl;
    return 0;
}

void demo_unique_ptr() {
    auto buf = std::make_unique<GpuBuffer>(100, "demo_buffer");
    buf->fill(3.14f);
    std::cout << "data[0] = " << buf->at(0) << std::endl;

    float* raw = buf->get();
    std::cout << "裸指针有效: data[0] = " << raw[0] << std::endl;

    auto buf2 = std::move(buf);
    if (!buf) {
        std::cout << "buf 已为空 (move 后源对象指针置空)" << std::endl;
    }
    std::cout << "buf2 持有资源, data[0] = " << buf2->at(0) << std::endl;
}

void demo_block_table() {
    {
        BlockTable table;
        std::cout << "  为请求分配 3 个 block..." << std::endl;
        table.allocate_blocks(3);
        std::cout << "  当前持有 " << table.num_blocks() << " 个 block" << std::endl;
        std::cout << "  请求结束，自动释放..." << std::endl;
    }
}

void demo_shared_ptr() {
    auto weights = std::make_shared<ModelWeights>(70000000000ULL);
    std::cout << "  初始引用计数: " << weights.use_count() << std::endl;
    {
        InferenceRequest req1(weights);
        InferenceRequest req2(weights);
        std::cout << "  当前引用计数: " << weights.use_count() << std::endl;
    }
    std::cout << "  请求结束后引用计数: " << weights.use_count() << std::endl;
}

void demo_weak_ptr() {
    auto a = std::make_shared<A>();
    auto b = std::make_shared<B>();
    a->b_ptr = b;
    b->a_ptr = a;  // weak_ptr = shared_ptr（不增加引用计数）
    if (auto sp = a->b_ptr.lock()) {
        std::cout << "  weak_ptr.lock() 成功: B 仍存活" << std::endl;
    }
    std::cout << "  离开作用域，正常析构" << std::endl;
}
