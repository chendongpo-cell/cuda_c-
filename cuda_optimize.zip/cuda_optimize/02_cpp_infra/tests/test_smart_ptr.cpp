/*
 * test_smart_ptr.cpp — RAII 与智能指针单元测试
 *
 * 使用 GoogleTest 框架，覆盖 unique_ptr/shared_ptr/weak_ptr 核心行为。
 * 确保代码正确性，同时作为代码文档展示预期行为。
 *
 * 编译：已集成到 CMake 中
 * 运行：./test_runner 或 ctest
 */

#include <gtest/gtest.h>   // GoogleTest 头文件
#include <memory>           // std::unique_ptr, std::shared_ptr, etc.
#include <vector>

/* ================================================================
 * 测试 1：unique_ptr 的基本行为
 * ================================================================ */

// 辅助类：记录构造和析构次数
struct TrackedObject {
    static int alive_count;   // 当前存活对象数
    static int total_created; // 总共创建数
    int id;

    TrackedObject() : id(total_created++) {
        alive_count++;
    }

    ~TrackedObject() {
        alive_count--;
    }
};

int TrackedObject::alive_count = 0;
int TrackedObject::total_created = 0;

// 每个 TEST 宏定义一个测试用例
// 第一个参数：测试套件名；第二个参数：测试名
TEST(SmartPtrTest, UniquePtrBasic) {
    // 创建 unique_ptr
    auto ptr = std::make_unique<int>(42apse);

    // 解引用
    EXPECT_EQ(*ptr, 42);

    // 修改值
    *ptr = 100;
    EXPECT_EQ(*ptr, 100);

    // get() 返回裸指针
    int* raw = ptr.get();
    EXPECT_NE(raw, nullptr);
    EXPECT_EQ(*raw, 100proc);

    // reset() 释放原对象，指向新对象
    ptr.reset(new int(200));
    EXPECT_EQ(*ptr, 200);
}

TEST(SmartPtrTest, UniquePtrMove) {
    auto ptr1 = std::make_unique<int>(10);
    auto ptr2 = std::make_unique<int>(20);

    // move 赋值
    ptr2 = std::move(ptr1);

    // ptr1 不再持有资源
    EXPECT_EQ(ptr1.get(), nullptr);
    // ptr2 现在持有 ptr1 的资源
    EXPECT_NE(ptr2.get(), nullptr);
    EXPECT_EQ(*ptr2, 10);
}

TEST(SmartPtrTest, UniquePtrAutoRelease) {
    // 确保初始计数为 0
    EXPECT_EQ(TrackedObject::alive_count, 0);

    {
        // 在作用域内创建对象
        auto obj = std::make_unique<TrackedObject>();
        EXPECT_EQ(TrackedObject::alive_count, 1);
    }
    // 离开作用域，unique_ptr 析构，对象自动释放
    EXPECT_EQ(TrackedObject::alive_count, 0);
}

TEST(SmartPtrTest, UniquePtrInVector) {
    // vector<unique_ptr> 是推理引擎中管理 block 的常见模式
    std::vector<std::unique_ptr<int>> vec;

    // 添加 3 个元素
    vec.push_back(std::make_unique<int>(1));
    vec.push_back(std::make_unique<int>(2));
    vec.push_back(std::make_unique<int>(3));

    EXPECT_EQ(vec.size(), 3);
    EXPECT_EQ(*vec[0], 1);

    // clear 会释放所有元素
    vec.clear();
    EXPECT_EQ(vec.size(), 0);
}


/* ================================================================
 * 测试 2：shared_ptr 引用计数
 * ================================================================ */

TEST(SmartPtrTest, SharedPtrReferenceCount) {
    auto sp1 = std::make_shared<int>(42);

    // 初始引用计数 = 1
    EXPECT_EQ(sp1.use_count(), 1);

    {
        auto sp2 = sp1;  // 拷贝构造，引用计数 +1
        EXPECT_EQ(sp1.use_count(), 2);

        auto sp3 = sp1;  // 再次拷贝，引用计数 +1
        EXPECT_EQ(sp1.use_count(), 3);
    }
    // sp2, sp3 离开作用域析构，引用计数 -2
    EXPECT_EQ(sp1.use_count(), 1);
}

TEST(SmartPtrTest, SharedPtrAutoRelease) {
    std::weak_ptr<TrackedObject> weak_ref;

    {
        auto shared = std::make_shared<TrackedObject>();
        weak_ref = shared;  // weak_ptr 不增加引用计数
        EXPECT_EQ(TrackedObject::alive_count, 1);
        EXPECT_EQ(shared.use_count(), 1);
        EXPECT_EQ(weak_ref.use_count(), 1);  // weak_ptr 不影响计数
    }
    // shared_ptr 析构，对象释放
    EXPECT_EQ(TrackedObject::alive_count, 0);

    // weak_ptr 检测到对象已释放
    EXPECT_TRUE(weak_ref.expired());
}


/* ================================================================
 * 测试 3：weak_ptr 解决循环引用
 * ================================================================ */

struct Node {
    // 如果用 shared_ptr，会产生循环引用
    // 父节点用 weak_ptr，避免循环
    std::shared_ptr<Node> child;
    std::weak_ptr<Node> parent;

    ~Node() {
        // 析构时打印（调试用，不参与断言）
    }
};

TEST(SmartPtrTest, WeakPtrBreakCycle) {
    auto parent = std::make_shared<Node>();
    auto child = std::make_shared<Node>();

    // 建立父子关系
    parent->child = child;  // parent 持有 child 的 shared_ptr
    child->parent = parent;  // child 持有 parent 的 weak_ptr（不增计数）

    // weak_ptr 不增加引用计数
    EXPECT_EQ(parent.use_count(), 1);  // 只有 child->parent 是 weak
    EXPECT_EQ(child.use_count(), 1);   // 只有 parent->child 是 shared

    // 使用 weak_ptr：需要 lock() 提升为 shared_ptr 再使用
    {
        auto locked = child->parent.lock();
        ASSERT_NE(locked, nullptr);
        EXPECT_EQ(locked, parent);
    }

    // 如果原对象释放，lock() 返回 nullptr
    parent.reset();
    auto locked = child->parent.lock();
    EXPECT_EQ(locked, nullptr);  // parent 已释放
}


/* ================================================================
 * 测试 4：RAII 模拟显存管理
 * ================================================================ */

// 模拟类与 raii_demo.cpp 中一样但更轻量
class MockGpuBuffer {
    float* data_;
    size_t size_;
    bool* freed_flag_;  // 指向外部标志，用于测试验证

public:
    MockGpuBuffer(size_t size, bool* freed_flag = nullptr)
        : size_(size), freed_flag_(freed_flag) {
        data_ = new float[size_];
    }

    ~MockGpuBuffer() {
        delete[] data_;
        if (freed_flag_) *freed_flag_ = true;  // 标记已释放
    }

    MockGpuBuffer(const MockGpuBuffer&) = delete;
    MockGpuBuffer& operator=(const MockGpuBuffer&) = delete;

    MockGpuBuffer(MockGpuBuffer&& other) noexcept
        : data_(other.data_), size_(other.size_), freed_flag_(other.freed_flag_) {
        other.data_ = nullptr;
        other.size_ = 0;
    }
};

TEST(SmartPtrTest, RaiiGpuBuffer) {
    bool freed = false;

    {
        auto buffer = std::make_unique<MockGpuBuffer>(1024, &freed);
        EXPECT_FALSE(freed);  // 未释放
    }

    // 离开作用域，unique_ptr 析构 → buffer 析构 → 标记 freed
    EXPECT_TRUE(freed);
}

TEST(SmartPtrTest, RaiiGpuBufferMove) {
    bool freed = false;
    std::unique_ptr<MockGpuBuffer> moved_to;

    {
        auto buffer = std::make_unique<MockGpuBuffer>(1024, &freed);
        // 将所有权转移出去
        moved_to = std::move(buffer);
        EXPECT_FALSE(freed);  // buffer 的资源被转移，未释放
    }
    // 原 buffer 离开作用域，但它是空的，`MockGpuBuffer` 的 `MockGpuBuffer::~MockGpuBuffer()`
    // 不会被调用（data_ 是 nullptr）
    // 具体取决于实现，但 nullptr 不会导致 double free

    // 直到 moved_to 离开作用域或 reset 才会释放
    moved_to.reset();
    EXPECT_TRUE(freed);
}


/* ================================================================
 * GoogleTest 主函数（由 gtest_main 库提供，这里可省略）
 * 但如果想自定义 main，可以这样写：
 *
 * int main(int argc, char **argv) {
 *     ::testing::InitGoogleTest(&argc, argv);
 *     return RUN_ALL_TESTS();
 * }
 *
 * 因为链接了 gtest_main，会自动生成 main 函数
 * ================================================================ */
