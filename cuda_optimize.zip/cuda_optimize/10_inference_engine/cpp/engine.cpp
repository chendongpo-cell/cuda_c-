﻿/*
 * engine.cpp — 推理引擎主循环 (C++ 版)
 *
 * 对应 Python 版: 10_inference_engine/python/engine.py
 *
 * 引擎的职责:
 *     1. 持有 Scheduler 和 (简化版) Model
 *     2. 主循环: schedule → prefill → decode → 更新状态
 *     3. 输出每步生成结果
 *
 * 主循环结构 (伪代码):
 *     while scheduler.has_work():
 *         plan = scheduler.schedule()
 *         for req in plan.to_prefill:
 *             do_prefill(req)   # 算 prompt 的 KV, 存入 cache
 *         for req in plan.to_decode:
 *             do_decode(req)    # 用 cache 算下一个 token
 *         scheduler.step_decode()  # 更新状态
 *
 * 教学重点:
 *     - 引擎 = 调度器 + 模型 + KV Cache 的串联
 *     - prefill 和 decode 的区别
 *     - C++ 资源管理 (RAII)
 *
 * 注意: 这个版本不调真实模型, 用"随机 token 生成"模拟
 *       重点演示调度和 KV 管理的流程
 *
 * 编译: g++ -std=c++17 -O2 engine.cpp -o engine_demo
 * 运行: ./engine_demo
 *
 * 配套文档: docs/05_vllm_architecture.md, docs/07_continuous_batching.md
 */

#include <cstdio>
#include <vector>
#include <string>
#include <random>
#include <memory>

// ============================================================
// 简化请求结构 (复用 scheduler.cpp 的逻辑, 这里简化版)
// ============================================================
struct Request {
    int id;
    int prompt_length;
    int output_length = 0;
    int max_output;
    int kv_size = 0;
    bool finished = false;
    std::vector<int> generated_tokens;   // 生成的 token 序列
};

// ============================================================
// 简化模型 (用随机数模拟, 不真跑神经网络)
// ============================================================
// Python 类比:
//   class FakeModel:
//       def forward(self, tokens):
//           return random.randint(0, 1000)  # 假装是 logits argmax
class FakeModel {
public:
    std::mt19937 rng;

    FakeModel() : rng(42) {
        printf("[Model] 加载完成 (随机模拟)\n");
    }

    // prefill: 处理整个 prompt, 返回第一个 output token
    int prefill(const std::vector<int>& prompt_tokens) {
        // 真实场景: 算整个 prompt 的 KV, 存 cache, 算下一个 token
        // 这里: 直接返回随机 token
        return rng() % 1000;
    }

    // decode: 用 cache + 上一个 token, 算下一个 token
    int decode(int last_token) {
        return rng() % 1000;
    }
};


// ============================================================
// 推理引擎
// ============================================================
// Python 类比:
//   class InferenceEngine:
//       def __init__(self, model, kv_capacity):
//           self.model = model
//           self.scheduler = Scheduler(kv_capacity)
//           self.kv_used = 0
class InferenceEngine {
public:
    std::unique_ptr<FakeModel> model;
    int kv_capacity;
    int kv_used = 0;
    std::vector<Request> waiting;
    std::vector<Request> running;

    InferenceEngine(int capacity)
        : model(std::make_unique<FakeModel>()), kv_capacity(capacity) {
        printf("[Engine] 初始化, KV capacity = %d\n", capacity);
    }

    // 添加请求
    void add_request(int id, int prompt_len, int max_out) {
        Request req;
        req.id = id;
        req.prompt_length = prompt_len;
        req.max_output = max_out;
        // 生成假 prompt token
        // (真实场景从 tokenizer 来)
        waiting.push_back(std::move(req));
        printf("[Engine] 添加 req %d (prompt=%d, max_out=%d)\n",
               id, prompt_len, max_out);
    }

    // 一步 prefill
    void do_prefill(Request& req) {
        // 真实场景: prompt_tokens → model.prefill() → 第一个 token + 存 KV
        std::vector<int> prompt_tokens(req.prompt_length, 1);   // 假 prompt
        int first_token = model->prefill(prompt_tokens);

        req.generated_tokens.push_back(first_token);
        req.output_length = 1;
        req.kv_size = req.prompt_length + 1;
        kv_used += req.kv_size;

        printf("[Engine] PREFILL req %d → first token = %d (kv_used=%d)\n",
               req.id, first_token, kv_used);
    }

    // 一步 decode
    void do_decode(Request& req) {
        // 真实场景: last_token + KV cache → model.decode() → next token
        int last_token = req.generated_tokens.back();
        int next_token = model->decode(last_token);

        req.generated_tokens.push_back(next_token);
        req.output_length += 1;
        req.kv_size += 1;
        kv_used += 1;

        // 检查完成
        if (req.output_length >= req.max_output) {
            req.finished = true;
            kv_used -= req.kv_size;
            req.kv_size = 0;
            printf("[Engine] FINISH req %d (生成 %d tokens)\n",
                   req.id, req.output_length);
        }
    }

    // 调度 (简化版, 不做 preemption)
    bool schedule_and_step() {
        bool did_something = false;

        // 1. 尝试 prefill waiting 请求
        while (!waiting.empty()) {
            Request& req = waiting.front();
            if (kv_used + req.prompt_length + 1 > kv_capacity) {
                break;   // KV 不够, 停止
            }
            // 升级到 running
            running.push_back(std::move(req));
            waiting.erase(waiting.begin());
            Request& r = running.back();
            do_prefill(r);
            did_something = true;
        }

        // 2. decode 所有 running
        for (auto& req : running) {
            if (req.finished) continue;
            do_decode(req);
            did_something = true;
        }

        // 3. 移除完成的请求
        running.erase(
            std::remove_if(running.begin(), running.end(),
                [](const Request& r) { return r.finished; }),
            running.end());

        return did_something;
    }

    // 主循环
    void run() {
        printf("\n[Engine] 开始推理主循环\n");
        int step = 0;
        while ((!waiting.empty() || !running.empty()) && step < 100) {
            step++;
            printf("\n--- Step %d (kv_used=%d/%d) ---\n",
                   step, kv_used, kv_capacity);
            if (!schedule_and_step()) {
                printf("[Engine] 无事可做 (KV 不够? 等待?)\n");
                break;
            }
        }
        printf("\n[Engine] 推理完成, 共 %d steps\n", step);
    }
};


// ============================================================
// 主函数
// ============================================================
int main()
{
    printf("=== Inference Engine Demo (C++) ===\n\n");

    // 创建引擎 (KV 容量 50 tokens)
    InferenceEngine engine(/*capacity=*/50);

    // 添加 3 个请求
    engine.add_request(/*id=*/1, /*prompt=*/10, /*max_out=*/5);
    engine.add_request(/*id=*/2, /*prompt=*/12, /*max_out=*/5);
    engine.add_request(/*id=*/3, /*prompt=*/8,  /*max_out=*/5);

    // 跑主循环
    engine.run();

    // 打印结果
    printf("\n=== 生成结果 ===\n");
    // (这里 running 已清空, 真实场景要在 finish 前收集结果)
    printf("(详见 step 日志)\n");

    printf("\n=== Engine demo 完成 ===\n");
    printf("对比 Python 版: 10_inference_engine/python/engine.py\n");
    printf("关键收获:\n");
    printf("  1. 引擎 = 调度 + 模型 + KV 管理的串联\n");
    printf("  2. prefill 和 decode 是两种不同的 forward\n");
    printf("  3. KV 容量驱动调度决策\n");
    printf("  4. C++ 用 unique_ptr 管理模型生命周期 (RAII)\n");
    return 0;
}

/*
 * 学习建议:
 *   1. 先读 Python 版 engine.py, 理解流程
 *   2. 对照本文件, 看 C++ 怎么组织引擎类
 *   3. 把 FakeModel 换成真模型 (用 LibTorch 加载)
 *   4. 加 preemption (KV 不够时抢占)
 *   5. 加 continuous batching (prefill 和 decode 混合调度)
 *
 * 进阶路径:
 *   - 接 LibTorch (C++ PyTorch) 跑真模型
 *   - 接 real KV Cache (参考 paged_kv_cache.cu)
 *   - 加 preemption (参考 scheduler.cpp)
 *   - 这就是 vLLM 引擎的雏形!
 */
