﻿/*
 * paged_kv_cache.cu — PagedAttention 简化版 (分页 KV Cache)
 *
 * 对应 Python 版: 10_inference_engine/python/kv_cache.py
 *
 * 核心思想 (借鉴 OS 虚拟内存):
 *     朴素 KV Cache: 每个请求预分配 max_seq 连续空间 → 浪费 + 碎片
 *     PagedAttention: 把 KV Cache 切成固定大小的 block (比如 16 token/block)
 *                     请求用 block table 记录自己用了哪些 block
 *                     block 不连续, 按需分配
 *
 * 数据结构:
 *     - block pool: 所有 block 在一个大 buffer 里 [num_blocks, block_size, head_dim]
 *     - block table: 每个请求一个数组, 记录它用的 block id [max_blocks_per_seq]
 *     - free list: 空闲 block id 的栈
 *
 * 操作:
 *     - allocate_block(): 从 free list 取一个 block
 *     - free_block(id): 还回 free list
 *     - write_kv(seq, pos, k, v): 算出物理 block + offset, 写入
 *     - read_kv(seq, pos): 算出物理 block + offset, 读取
 *
 * 教学重点:
 *     - 逻辑地址 (seq, pos) → 物理地址 (block_id, offset) 的映射
 *     - block table 的存储
 *     - free list 的管理
 *
 * 编译: nvcc -std=c++17 -O2 paged_kv_cache.cu -o paged_kv_cache_demo
 * 运行: ./paged_kv_cache_demo
 *
 * 配套文档: docs/06_paged_attention.md
 */

#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <stack>

#define CUDA_CHECK(call)                                                \
    do {                                                                \
        cudaError_t err = (call);                                       \
        if (err != cudaSuccess) {                                       \
            fprintf(stderr, "CUDA error %s:%d: %s\n",                   \
                    __FILE__, __LINE__, cudaGetErrorString(err));       \
            exit(EXIT_FAILURE);                                         \
        }                                                               \
    } while (0)


// ============================================================
// 常量配置
// ============================================================
const int BLOCK_SIZE = 4;       // 每个 block 容纳 4 个 token (真实 vLLM 用 16)
const int HEAD_DIM = 8;          // head 维度 (简化)
const int MAX_BLOCKS_PER_SEQ = 8; // 每个请求最多 8 个 block = 32 token
const int NUM_BLOCKS = 16;       // block pool 总共 16 个 block


// ============================================================
// PagedKVCache 类
// ============================================================
// Python 类比:
//   class PagedKVCache:
//       def __init__(self):
//           self.block_pool = torch.zeros(NUM_BLOCKS, BLOCK_SIZE, HEAD_DIM)
//           self.free_blocks = list(range(NUM_BLOCKS))
//           self.block_tables = {}  # seq_id -> [block_id, ...]
class PagedKVCache {
public:
    float* d_block_pool;   // [NUM_BLOCKS, BLOCK_SIZE, HEAD_DIM] GPU 上的 block 池
    std::vector<std::vector<int>> block_tables;  // CPU 上的 block table (简化: CPU 管理)
    std::stack<int> free_blocks;                 // 空闲 block 栈

    PagedKVCache() {
        // 1. 分配 GPU block pool
        CUDA_CHECK(cudaMalloc(&d_block_pool,
            (size_t)NUM_BLOCKS * BLOCK_SIZE * HEAD_DIM * sizeof(float)));
        CUDA_CHECK(cudaMemset(d_block_pool, 0,
            (size_t)NUM_BLOCKS * BLOCK_SIZE * HEAD_DIM * sizeof(float)));

        // 2. 初始化 free list (所有 block 都空闲)
        for (int i = NUM_BLOCKS - 1; i >= 0; --i) {
            free_blocks.push(i);   // 倒序 push, 正序 pop 就是 0,1,2,...
        }

        printf("[PagedKVCache] 初始化: %d blocks, block_size=%d, head_dim=%d\n",
               NUM_BLOCKS, BLOCK_SIZE, HEAD_DIM);
    }

    ~PagedKVCache() {
        cudaFree(d_block_pool);
    }

    // 分配一个新 sequence, 返回 seq_id
    int allocate_sequence() {
        int seq_id = block_tables.size();
        block_tables.push_back({});   // 空 block table
        printf("[PagedKVCache] 分配 seq %d\n", seq_id);
        return seq_id;
    }

    // 给 seq 分配一个新 block, 返回 block_id
    int allocate_block(int seq_id) {
        if (free_blocks.empty()) {
            fprintf(stderr, "ERROR: block pool 耗尽!\n");
            return -1;
        }
        int block_id = free_blocks.top();
        free_blocks.pop();
        block_tables[seq_id].push_back(block_id);
        printf("[PagedKVCache] seq %d 分配 block %d (已用 %zu blocks)\n",
               seq_id, block_id, block_tables[seq_id].size());
        return block_id;
    }

    // 释放 seq 的所有 block
    void free_sequence(int seq_id) {
        for (int block_id : block_tables[seq_id]) {
            free_blocks.push(block_id);
        }
        printf("[PagedKVCache] 释放 seq %d (%zu blocks 回收)\n",
               seq_id, block_tables[seq_id].size());
        block_tables[seq_id].clear();
    }

    // 算逻辑位置 pos 对应的物理地址 (block_id, offset)
    // Python 类比:
    //   block_id = block_table[seq_id][pos // BLOCK_SIZE]
    //   offset = pos % BLOCK_SIZE
    void logical_to_physical(int seq_id, int pos,
                             int* block_id, int* offset) {
        int block_idx = pos / BLOCK_SIZE;
        *offset = pos % BLOCK_SIZE;
        *block_id = block_tables[seq_id][block_idx];
    }

    // 算 GPU 地址
    // block_pool[block_id][offset][d] 的偏移 = block_id * (BLOCK_SIZE * HEAD_DIM) + offset * HEAD_DIM + d
    size_t gpu_offset(int block_id, int offset) {
        return ((size_t)block_id * BLOCK_SIZE + offset) * HEAD_DIM;
    }
};


// ============================================================
// Kernel: 写入一个 token 的 K 到 cache
// ============================================================
// Python 类比:
//   block_id, offset = logical_to_physical(seq, pos)
//   block_pool[block_id, offset, :] = new_k
__global__ void write_kv_kernel(
    float* __restrict__ block_pool,
    const float* __restrict__ new_k,    // [HEAD_DIM]
    int block_id, int offset)
{
    int d = threadIdx.x;
    if (d >= HEAD_DIM) return;

    size_t addr = ((size_t)block_id * BLOCK_SIZE + offset) * HEAD_DIM + d;
    block_pool[addr] = new_k[d];
}


// ============================================================
// Kernel: 读取一个 token 的 K
// ============================================================
__global__ void read_kv_kernel(
    const float* __restrict__ block_pool,
    float* __restrict__ out_k,          // [HEAD_DIM]
    int block_id, int offset)
{
    int d = threadIdx.x;
    if (d >= HEAD_DIM) return;

    size_t addr = ((size_t)block_id * BLOCK_SIZE + offset) * HEAD_DIM + d;
    out_k[d] = block_pool[addr];
}


// ============================================================
// 主函数: 演示分页 KV Cache 的分配/写入/读取
// ============================================================
int main()
{
    printf("=== Paged KV Cache Demo ===\n\n");

    PagedKVCache cache;

    // ===== 1. 创建两个 sequence =====
    int seq0 = cache.allocate_sequence();
    int seq1 = cache.allocate_sequence();

    // ===== 2. 给 seq0 写 6 个 token (需要 2 个 block, 因为 BLOCK_SIZE=4) =====
    printf("\n--- 写入 seq0 的 6 个 token ---\n");
    float h_k[HEAD_DIM];
    float* d_k;
    CUDA_CHECK(cudaMalloc(&d_k, HEAD_DIM * sizeof(float)));

    for (int pos = 0; pos < 6; ++pos) {
        // 2.1 检查是否需要新 block
        if (pos % BLOCK_SIZE == 0) {
            cache.allocate_block(seq0);
        }

        // 2.2 算物理地址
        int block_id, offset;
        cache.logical_to_physical(seq0, pos, &block_id, &offset);

        // 2.3 生成 K 数据 (用 pos 标记, 方便验证)
        for (int d = 0; d < HEAD_DIM; ++d) h_k[d] = (float)(pos * 100 + d);
        CUDA_CHECK(cudaMemcpy(d_k, h_k, HEAD_DIM * sizeof(float),
                              cudaMemcpyHostToDevice));

        // 2.4 写入 GPU
        write_kv_kernel<<<1, HEAD_DIM>>>(cache.d_block_pool, d_k,
                                          block_id, offset);
        CUDA_CHECK(cudaGetLastError());

        printf("  seq0 pos %d → block %d offset %d, K[0]=%.0f\n",
               pos, block_id, offset, h_k[0]);
    }

    // ===== 3. 给 seq1 写 3 个 token (需要 1 个 block) =====
    printf("\n--- 写入 seq1 的 3 个 token ---\n");
    for (int pos = 0; pos < 3; ++pos) {
        if (pos % BLOCK_SIZE == 0) {
            cache.allocate_block(seq1);
        }
        int block_id, offset;
        cache.logical_to_physical(seq1, pos, &block_id, &offset);

        for (int d = 0; d < HEAD_DIM; ++d) h_k[d] = (float)(1000 + pos * 100 + d);
        CUDA_CHECK(cudaMemcpy(d_k, h_k, HEAD_DIM * sizeof(float),
                              cudaMemcpyHostToDevice));
        write_kv_kernel<<<1, HEAD_DIM>>>(cache.d_block_pool, d_k,
                                          block_id, offset);
        CUDA_CHECK(cudaGetLastError());
        printf("  seq1 pos %d → block %d offset %d, K[0]=%.0f\n",
               pos, block_id, offset, h_k[0]);
    }

    // ===== 4. 读取验证 =====
    printf("\n--- 读取 seq0 的 token 5 (跨 block 边界) ---\n");
    int block_id, offset;
    cache.logical_to_physical(seq0, 5, &block_id, &offset);
    printf("  物理地址: block %d offset %d\n", block_id, offset);

    float* d_out;
    CUDA_CHECK(cudaMalloc(&d_out, HEAD_DIM * sizeof(float)));
    read_kv_kernel<<<1, HEAD_DIM>>>(cache.d_block_pool, d_out,
                                     block_id, offset);
    CUDA_CHECK(cudaDeviceSynchronize());

    float h_out[HEAD_DIM];
    CUDA_CHECK(cudaMemcpy(h_out, d_out, HEAD_DIM * sizeof(float),
                          cudaMemcpyDeviceToHost));
    printf("  读出 K = [");
    for (int d = 0; d < HEAD_DIM; ++d) printf("%.0f ", h_out[d]);
    printf("]\n");
    printf("  期望 K = [501 502 503 504 505 506 507 508]\n");

    // ===== 5. 释放 seq0, 看 block 回收 =====
    printf("\n--- 释放 seq0 ---\n");
    cache.free_sequence(seq0);
    printf("  剩余 free blocks: %zu\n", cache.free_blocks.size());

    // ===== 6. 新 seq2 复用回收的 block =====
    printf("\n--- 创建 seq2, 复用 block ---\n");
    int seq2 = cache.allocate_sequence();
    cache.allocate_block(seq2);
    printf("  (seq2 应该复用了 seq0 释放的 block)\n");

    // ===== 7. 清理 =====
    cudaFree(d_k);
    cudaFree(d_out);

    printf("\nPaged KV Cache demo 完成.\n");
    printf("对比 Python 版: 10_inference_engine/python/kv_cache.py\n");
    printf("关键收获:\n");
    printf("  1. 逻辑地址 (seq,pos) → 物理地址 (block_id,offset) 的映射\n");
    printf("  2. block table 是 per-seq 的小数组\n");
    printf("  3. block pool 是全局共享的, 用 free list 管理\n");
    printf("  4. 释放 seq 后 block 立刻可复用 (无碎片)\n");
    return 0;
}

/*
 * 学习建议:
 *   1. 先读 Python 版 kv_cache.py, 理解逻辑
 *   2. 对照本文件, 看 C++ 怎么管理 block pool 和 block table
 *   3. 思考: 为什么 PagedAttention 比连续分配好?
 *      答: 1) 按需分配, 不浪费  2) 无碎片  3) 共享 prefix 容易
 *   4. 进阶: 加 prefix caching (相同 prefix 的 block 共享)
 *      参考 05_attention/python/prefix_caching_demo.py
 */
