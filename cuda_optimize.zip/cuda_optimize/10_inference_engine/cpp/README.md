﻿# 10_inference_engine/cpp/ — 推理引擎核心模块的 C++ 实现

> **对应 Python 版**：[10_inference_engine/python/](../10_inference_engine/python/)
>
> **定位**：用 C++/CUDA 重写 Python 教学版推理引擎的核心模块。这是最接近真实 vLLM 实现的一版。
>
> **前置**：学完阶段 4（vLLM 架构）+ 阶段 9（Python 版引擎）。

---

## 文件对应关系

| C++/CUDA 文件 | 对应 Python 脚本 | 教学重点 |
|--------------|----------------|---------|
| [paged_kv_cache.cu](paged_kv_cache.cu) | [10_inference_engine/python/kv_cache.py](../10_inference_engine/python/kv_cache.py) | PagedAttention 简化版：block 池、block table、虚→物映射 |
| [scheduler.cpp](scheduler.cpp) | [10_inference_engine/python/scheduler.py](../10_inference_engine/python/scheduler.py) | Continuous Batching 调度器：waiting/running 队列、prefill/decode 调度 |
| [engine.cpp](engine.cpp) | [10_inference_engine/python/engine.py](../10_inference_engine/python/engine.py) | 主循环：step 函数、prefill + decode 流程 |

---

## 编译运行

```bash
cd 10_inference_engine/cpp
mkdir build && cd build
cmake .. -DCMAKE_CUDA_ARCHITECTURES="80"
make -j4

./paged_kv_cache_demo
./scheduler_demo
./engine_demo
```

---

## Python vs C++ 实现对比要点

| 维度 | Python 版 | C++ 版 |
|------|----------|--------|
| KV Cache | `dict` 存 block table | C struct + 指针数组 |
| 调度器 | `list` 当队列 | `std::vector` + 状态机 |
| 引擎主循环 | `while` + step | 同结构, 但 C++ 显式管理资源 |
| 内存 | GC 自动 | RAII + cudaFree |
| 性能 | 慢（教学版） | 接近真实（少了真实模型 forward） |

**核心收获**：理解 vLLM 的 C++ 代码组织方式，为读真实源码打基础。
