﻿/*
 * scheduler.cpp — Continuous Batching 调度器 (C++ 版)
 *
 * 对应 Python 版: 10_inference_engine/python/scheduler.py
 *
 * 调度器的职责:
 *     1. 维护两个队列: waiting (新请求) + running (进行中)
 *     2. 每个 step 决定:
 *        - 哪些 waiting 升级到 running (prefill)
 *        - 哪些 running 继续 decode
 *        - 是否需要 preempt (KV Cache 不够时)
 *     3. 输出 step 的执行计划: to_prefill / to_decode / preempted
 *
 * 状态机 (每个请求):
 *     waiting → running (调度时升级)
 *     running → finished (生成完)
 *     running → waiting (preempt, 见 25_preemption_implementation.md)
 *
 * 教学重点:
 *     - C++ struct + std::vector 管理请求
 *     - 调度状态机的实现
 *     - KV Cache 容量检查
 *
 * 编译: g++ -std=c++17 -O2 scheduler.cpp -o scheduler_demo
 * 运行: ./scheduler_demo
 *
 * 配套文档: docs/07_continuous_batching.md, docs/25_preemption_implementation.md
 */

#include <cstdio>
#include <vector>
#include <string>
#include <queue>
#include <algorithm>

// ============================================================
// 请求状态
// ============================================================
enum class RequestStatus {
    WAITING,
    RUNNING,
    PREEMPTED,   // 被抢占, 等待恢复
    FINISHED
};

// 状态转字符串 (方便打印)
const char* status_str(RequestStatus s) {
    switch (s) {
        case RequestStatus::WAITING:   return "WAITING";
        case RequestStatus::RUNNING:   return "RUNNING";
        case RequestStatus::PREEMPTED: return "PREEMPTED";
        case RequestStatus::FINISHED:  return "FINISHED";
    }
    return "UNKNOWN";
}


// ============================================================
// 请求结构
// ============================================================
// Python 类比:
//   @dataclass
//   class Request:
//       request_id: int
//       prompt_length: int
//       output_length: int = 0
//       max_output: int = 20
//       status: str = "waiting"
struct Request {
    int request_id;
    int prompt_length;
    int output_length = 0;
    int max_output;
    RequestStatus status = RequestStatus::WAITING;

    // 当前占用的 KV cache token 数
    // prefill 后 = prompt_length
    // 每步 decode +1
    int kv_cache_size = 0;

    // 总长度 (prompt + output)
    int total_length() const {
        return prompt_length + output_length;
    }
};


// ============================================================
// 调度器
// ============================================================
// Python 类比:
//   class Scheduler:
//       def __init__(self, kv_capacity):
//           self.kv_capacity = kv_capacity
//           self.waiting = []
//           self.running = []
class Scheduler {
public:
    int kv_capacity;   // KV Cache 总容量 (token 数)
    int kv_used = 0;   // 当前已用
    std::vector<Request> waiting;
    std::vector<Request> running;

    Scheduler(int capacity) : kv_capacity(capacity) {
        printf("[Scheduler] 初始化, KV capacity = %d tokens\n", capacity);
    }

    // 添加新请求
    void add_request(const Request& req) {
        waiting.push_back(req);
        printf("[Scheduler] 添加 req %d (prompt=%d, max_out=%d)\n",
               req.request_id, req.prompt_length, req.max_output);
    }

    // 当前 KV 使用量
    int total_kv_used() const { return kv_used; }

    // 一次调度的输出
    struct SchedulePlan {
        std::vector<int> to_prefill;    // 要 prefill 的 request_id 列表
        std::vector<int> to_decode;     // 要 decode 的 request_id 列表
        std::vector<int> preempted;     // 被抢占的 request_id 列表
    };

    // 调度: 决定这一 step 做什么
    // Python 类比: scheduler.py 的 schedule() 方法
    SchedulePlan schedule() {
        SchedulePlan plan;

        // 1. 尝试把 waiting 升级到 running (prefill)
        while (!waiting.empty()) {
            Request& req = waiting.front();
            int cost = req.prompt_length;   // prefill 需要 prompt_length 个 KV

            if (kv_used + cost <= kv_capacity) {
                // 容量够, 升级
                req.status = RequestStatus::RUNNING;
                req.kv_cache_size = cost;
                kv_used += cost;
                plan.to_prefill.push_back(req.request_id);
                running.push_back(std::move(req));
                waiting.erase(waiting.begin());
            } else if (!running.empty()) {
                // 容量不够, 但有 running 可以 preempt
                // 简化: 抢占最后进来的 running (LIFO)
                preempt_last(plan);
            } else {
                // 无法 preempt, 停止调度
                break;
            }
        }

        // 2. 所有 running 都 decode
        for (auto& req : running) {
            if (req.status == RequestStatus::RUNNING) {
                plan.to_decode.push_back(req.request_id);
            }
        }

        return plan;
    }

    // 抢占最后进来的 running 请求 (RECOMPUTE 策略)
    void preempt_last(SchedulePlan& plan) {
        if (running.empty()) return;

        // 找最后一个 RUNNING 的请求
        int victim_idx = -1;
        for (int i = (int)running.size() - 1; i >= 0; --i) {
            if (running[i].status == RequestStatus::RUNNING) {
                victim_idx = i;
                break;
            }
        }
        if (victim_idx < 0) return;

        Request& victim = running[victim_idx];

        // RECOMPUTE: 释放 KV, 重置进度, 放回 waiting 头部
        kv_used -= victim.kv_cache_size;
        victim.kv_cache_size = 0;
        victim.output_length = 0;
        victim.status = RequestStatus::WAITING;

        plan.preempted.push_back(victim.request_id);
        printf("[Scheduler] PREEMPT req %d (freed KV), 放回 waiting\n",
               victim.request_id);

        // 移到 waiting 头部
        waiting.insert(waiting.begin(), std::move(victim));
        running.erase(running.begin() + victim_idx);
    }

    // 执行 decode 后的更新 (每步 decode 1 个 token)
    void step_decode() {
        for (auto& req : running) {
            if (req.status != RequestStatus::RUNNING) continue;

            // decode 占 1 个 KV
            kv_used += 1;
            req.kv_cache_size += 1;
            req.output_length += 1;

            // 检查是否完成
            if (req.output_length >= req.max_output) {
                req.status = RequestStatus::FINISHED;
                kv_used -= req.kv_cache_size;   // 释放 KV
                req.kv_cache_size = 0;
                printf("[Scheduler] FINISH req %d (output=%d tokens)\n",
                       req.request_id, req.output_length);
            }
        }

        // 移除完成的请求
        running.erase(
            std::remove_if(running.begin(), running.end(),
                [](const Request& r) {
                    return r.status == RequestStatus::FINISHED;
                }),
            running.end());
    }

    // 是否还有工作
    bool has_work() const {
        return !waiting.empty() || !running.empty();
    }

    // 打印状态
    void print_status() const {
        printf("  [状态] waiting=%zu, running=%zu, kv_used=%d/%d\n",
               waiting.size(), running.size(), kv_used, kv_capacity);
    }
};


// ============================================================
// 主函数: 模拟几步调度
// ============================================================
int main()
{
    printf("=== Continuous Batching Scheduler Demo ===\n\n");

    // 1. 创建调度器 (KV 容量故意设小, 触发 preemption)
    Scheduler scheduler(/*capacity=*/40);

    // 2. 添加 5 个请求
    for (int i = 1; i <= 5; ++i) {
        Request req;
        req.request_id = i;
        req.prompt_length = 8 + i;     // 9, 10, 11, 12, 13
        req.max_output = 5;
        scheduler.add_request(req);
    }

    // 3. 跑 15 step
    printf("\n--- 开始调度 ---\n");
    for (int step = 1; step <= 15 && scheduler.has_work(); ++step) {
        printf("\n[Step %d]\n", step);

        // 调度
        auto plan = scheduler.schedule();

        // 打印计划
        printf("  计划: prefill={");
        for (int id : plan.to_prefill) printf("%d ", id);
        printf("}, decode={");
        for (int id : plan.to_decode) printf("%d ", id);
        printf("}, preempted={");
        for (int id : plan.preempted) printf("%d ", id);
        printf("}\n");

        // 执行 decode (简化: prefill 也算 1 step)
        scheduler.step_decode();

        scheduler.print_status();
    }

    printf("\n=== Scheduler demo 完成 ===\n");
    printf("对比 Python 版: 10_inference_engine/python/scheduler.py\n");
    printf("关键收获:\n");
    printf("  1. waiting/running 队列的转换\n");
    printf("  2. KV 容量检查驱动调度决策\n");
    printf("  3. preemption 在 KV 不够时触发\n");
    return 0;
}

/*
 * 学习建议:
 *   1. 先读 Python 版 scheduler.py, 理解逻辑
 *   2. 对照本文件, 看 C++ 怎么用 std::vector 管理队列
 *   3. 改 kv_capacity, 观察 preemption 频率变化
 *   4. 进阶: 加 SWAP preemption (见 25_preemption_implementation.md)
 *      加优先级队列 (高优先级请求先调度)
 */
