﻿"""
benchmark_serving.py — 真实推理服务 benchmark 脚本

配合 [docs/26_real_optimization_workflow.md](../docs/26_real_optimization_workflow.md) 使用。

这是"真实优化工作流"里阶段 2 (建基线) 和阶段 5 (实施) 用的 benchmark 脚本。
结构参考 vLLM 官方 benchmark_serving.py, 简化但功能完整。

能测什么:
    1. TTFT (Time To First Token) - 首 token 延迟
    2. TPOT (Time Per Output Token) - 单 token 延迟
    3. 吞吐 (tok/s, req/s)
    4. P50/P90/P99/P999 尾延迟
    5. 错误率

用法:
    # 启动 vLLM 服务
    vllm serve meta-llama/Llama-3-8B --port 8000

    # 跑基线 benchmark
    python benchmark_serving.py \\
        --base-url http://localhost:8000/v1 \\
        --model meta-llama/Llama-3-8B \\
        --num-prompts 200 \\
        --request-rate 10 \\
        --output baseline.json

    # 改配置后重跑
    python benchmark_serving.py ... --output exp1.json

    # 对比
    python compare_results.py baseline.json exp1.json

学习目标:
    1. 知道真实 benchmark 怎么写
    2. 理解 TTFT / TPOT 怎么测
    3. 理解 P99 怎么算
    4. 能改成自己的场景
"""

import asyncio
import time
import json
import argparse
import statistics
import random
from typing import List, Dict, Optional
from dataclasses import dataclass, field, asdict

try:
    import httpx
except ImportError:
    raise ImportError("需要安装 httpx: pip install httpx")


# ============================================================
# 测试 prompt (用固定 prompt 保证可复现)
# ============================================================

DEFAULT_PROMPTS = [
    "Explain the concept of gradient descent in machine learning.",
    "Write a Python function to implement quicksort.",
    "What are the main causes of climate change?",
    "Describe the plot of Romeo and Juliet.",
    "How does a transformer neural network work?",
    "Write a short story about a robot learning to paint.",
    "Explain the difference between TCP and UDP.",
    "What is the meaning of life according to different philosophies?",
    "Describe how a vaccine works.",
    "Write a SQL query to find the top 10 customers by total sales.",
    "Compare and contrast mitosis and meiosis.",
    "What are the key principles of object-oriented programming?",
    "Explain the theory of relativity in simple terms.",
    "Write a haiku about autumn leaves.",
    "How do batteries work?",
]


# ============================================================
# 单请求结果
# ============================================================

@dataclass
class RequestResult:
    """单个请求的 benchmark 结果"""
    request_id: int
    prompt: str
    prompt_len: int = 0           # 输入 token 数 (从 usage 拿)
    output_len: int = 0           # 输出 token 数
    ttft: float = 0.0             # 首 token 延迟 (秒)
    total_time: float = 0.0       # 总耗时
    tpot: float = 0.0             # 单 token 延迟
    output_text: str = ""
    error: Optional[str] = None

    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================
# 发送单个请求 (流式)
# ============================================================

async def send_request(
    client: httpx.AsyncClient,
    base_url: str,
    model: str,
    prompt: str,
    request_id: int,
    max_tokens: int = 128,
    temperature: float = 0.7,
) -> RequestResult:
    """
    发送一个流式推理请求, 记录 TTFT / TPOT / 总时间

    流式响应的关键: 第一个 chunk 到达的时间就是 TTFT
    """
    result = RequestResult(request_id=request_id, prompt=prompt)
    start = time.time()
    ttft: Optional[float] = None
    output_tokens = 0
    output_text = ""

    try:
        async with client.stream(
            "POST",
            f"{base_url}/completions",
            json={
                "model": model,
                "prompt": prompt,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "stream": True,
                "stream_options": {"include_usage": True},
            },
            timeout=120.0,
        ) as response:
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue

                data = line[6:]
                if data == "[DONE]":
                    break

                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue

                # 1. 处理生成的 text
                if "choices" in chunk and chunk["choices"]:
                    delta = chunk["choices"][0].get("text", "")
                    if delta:
                        if ttft is None:
                            # 第一个 token 到达, 记录 TTFT
                            ttft = time.time() - start
                        output_text += delta
                        output_tokens += 1

                # 2. 处理 usage (服务端返回的真实 token 数)
                if "usage" in chunk and chunk["usage"]:
                    output_tokens = chunk["usage"].get(
                        "completion_tokens", output_tokens
                    )
                    result.prompt_len = chunk["usage"].get("prompt_tokens", 0)

    except Exception as e:
        result.error = str(e)

    total_time = time.time() - start
    result.output_len = output_tokens
    result.output_text = output_text
    result.ttft = ttft or 0.0
    result.total_time = total_time
    # TPOT = (总时间 - TTFT) / (剩余 token 数)
    # 如果只生成 1 个 token, TPOT = 0
    if output_tokens > 1:
        result.tpot = (total_time - (ttft or 0)) / (output_tokens - 1)

    return result


# ============================================================
# 按指定 rate 发送请求 (模拟真实流量)
# ============================================================

async def benchmark(
    base_url: str,
    model: str,
    prompts: List[str],
    num_prompts: int,
    request_rate: float,
    max_tokens: int,
    temperature: float,
) -> List[RequestResult]:
    """
    按 request_rate (QPS) 发送 num_prompts 个请求

    关键: 不是一次性全发, 而是按 rate 间隔发, 模拟真实流量
    """
    print(f"\n开始 benchmark:")
    print(f"  base_url: {base_url}")
    print(f"  model: {model}")
    print(f"  num_prompts: {num_prompts}")
    print(f"  request_rate: {request_rate} QPS")
    print(f"  max_tokens: {max_tokens}")

    # 准备 prompts (循环复用)
    if len(prompts) < num_prompts:
        prompts = (prompts * (num_prompts // len(prompts) + 1))[:num_prompts]

    async with httpx.AsyncClient() as client:
        # 检查服务可达
        try:
            r = await client.get(f"{base_url}/models", timeout=5.0)
            r.raise_for_status()
        except Exception as e:
            print(f"✗ 无法连接服务: {e}")
            return []

        # warmup (预热, 不计入统计)
        print("\n  warmup 10 请求...")
        for i in range(10):
            await send_request(
                client, base_url, model, prompts[i % len(prompts)],
                request_id=-1, max_tokens=max_tokens, temperature=temperature,
            )

        # 正式 benchmark
        print(f"  正式发送 {num_prompts} 请求...")
        results: List[RequestResult] = []
        start_time = time.time()

        # 按间隔发请求 (Poisson 到达更真实, 这里用均匀间隔简化)
        interval = 1.0 / request_rate if request_rate > 0 else 0

        async def send_with_delay(idx: int, prompt: str):
            if idx > 0 and interval > 0:
                await asyncio.sleep(interval * idx - (time.time() - start_time))
            result = await send_request(
                client, base_url, model, prompt,
                request_id=idx, max_tokens=max_tokens, temperature=temperature,
            )
            results.append(result)
            # 进度
            if (idx + 1) % 50 == 0:
                print(f"    完成 {idx + 1}/{num_prompts}")

        # 并发发送
        tasks = [
            send_with_delay(i, prompts[i])
            for i in range(num_prompts)
        ]
        await asyncio.gather(*tasks)

        total_time = time.time() - start_time

    # 按请求 id 排序
    results.sort(key=lambda r: r.request_id)
    print(f"\n  完成! 总时间 {total_time:.1f}s")
    return results


# ============================================================
# 统计 + 报告
# ============================================================

def percentile(data: List[float], p: float) -> float:
    """算 p 分位数 (p in [0, 100])"""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * (p / 100)
    f = int(k)
    c = min(f + 1, len(sorted_data) - 1)
    if f == c:
        return sorted_data[f]
    return sorted_data[f] + (sorted_data[c] - sorted_data[f]) * (k - f)


def compute_stats(results: List[RequestResult]) -> Dict:
    """算所有统计指标"""
    successful = [r for r in results if r.error is None]
    failed = [r for r in results if r.error is not None]

    if not successful:
        return {"error": "no successful requests"}

    ttfts = [r.ttft for r in successful]
    tpots = [r.tpot for r in successful if r.tpot > 0]
    total_times = [r.total_time for r in successful]
    output_tokens = sum(r.output_len for r in successful)
    prompt_tokens = sum(r.prompt_len for r in successful)
    total_time = max(total_times)  # 所有请求完成的总时间

    return {
        "num_requests": len(results),
        "num_successful": len(successful),
        "num_failed": len(failed),
        "error_rate": len(failed) / len(results) if results else 0,

        "ttft_ms": {
            "mean": statistics.mean(ttfts) * 1000,
            "p50": percentile(ttfts, 50) * 1000,
            "p90": percentile(ttfts, 90) * 1000,
            "p99": percentile(ttfts, 99) * 1000,
            "p999": percentile(ttfts, 99.9) * 1000,
            "max": max(ttfts) * 1000,
        },
        "tpot_ms": {
            "mean": statistics.mean(tpots) * 1000 if tpots else 0,
            "p50": percentile(tpots, 50) * 1000 if tpots else 0,
            "p90": percentile(tpots, 90) * 1000 if tpots else 0,
            "p99": percentile(tpots, 99) * 1000 if tpots else 0,
            "max": max(tpots) * 1000 if tpots else 0,
        },
        "throughput": {
            "total_time_s": total_time,
            "total_output_tokens": output_tokens,
            "total_prompt_tokens": prompt_tokens,
            "output_tok_per_sec": output_tokens / total_time if total_time > 0 else 0,
            "requests_per_sec": len(successful) / total_time if total_time > 0 else 0,
        },
    }


def print_report(stats: Dict) -> None:
    """打印人类可读的报告"""
    print("\n" + "=" * 60)
    print("Benchmark 结果")
    print("=" * 60)

    print(f"\n请求数: {stats['num_successful']}/{stats['num_requests']} "
          f"(失败 {stats['num_failed']}, 错误率 {stats['error_rate']:.1%})")

    print(f"\n--- TTFT (首 token 延迟, ms) ---")
    t = stats["ttft_ms"]
    print(f"  mean: {t['mean']:.1f}")
    print(f"  P50:  {t['p50']:.1f}")
    print(f"  P90:  {t['p90']:.1f}")
    print(f"  P99:  {t['p99']:.1f}")
    print(f"  P999: {t['p999']:.1f}")
    print(f"  max:  {t['max']:.1f}")

    print(f"\n--- TPOT (单 token 延迟, ms) ---")
    t = stats["tpot_ms"]
    print(f"  mean: {t['mean']:.1f}")
    print(f"  P50:  {t['p50']:.1f}")
    print(f"  P90:  {t['p90']:.1f}")
    print(f"  P99:  {t['p99']:.1f}")
    print(f"  max:  {t['max']:.1f}")

    print(f"\n--- 吞吐 ---")
    th = stats["throughput"]
    print(f"  总时间:       {th['total_time_s']:.1f}s")
    print(f"  总输出 token: {th['total_output_tokens']}")
    print(f"  吞吐:         {th['output_tok_per_sec']:.1f} tok/s")
    print(f"  请求吞吐:     {th['requests_per_sec']:.2f} req/s")

    print("\n" + "=" * 60)


# ============================================================
# 主入口
# ============================================================

async def main():
    parser = argparse.ArgumentParser(description="推理服务 benchmark")
    parser.add_argument("--base-url", default="http://localhost:8000/v1",
                        help="服务 URL (默认: http://localhost:8000/v1)")
    parser.add_argument("--model", required=True,
                        help="模型名 (如 meta-llama/Llama-3-8B)")
    parser.add_argument("--num-prompts", type=int, default=200,
                        help="请求数 (默认: 200)")
    parser.add_argument("--request-rate", type=float, default=10,
                        help="请求速率 QPS (默认: 10)")
    parser.add_argument("--max-tokens", type=int, default=128,
                        help="每个请求最大输出 token (默认: 128)")
    parser.add_argument("--temperature", type=float, default=0.7,
                        help="采样温度 (默认: 0.7)")
    parser.add_argument("--output", default=None,
                        help="结果保存到 JSON 文件")
    parser.add_argument("--seed", type=int, default=42,
                        help="随机种子 (默认: 42)")
    args = parser.parse_args()

    random.seed(args.seed)

    print("╔" + "═" * 60 + "╗")
    print("║" + " 推理服务 Benchmark ".center(54) + "║")
    print("╚" + "═" * 60 + "╝")

    # 跑 benchmark
    results = await benchmark(
        base_url=args.base_url,
        model=args.model,
        prompts=DEFAULT_PROMPTS,
        num_prompts=args.num_prompts,
        request_rate=args.request_rate,
        max_tokens=args.max_tokens,
        temperature=args.temperature,
    )

    if not results:
        print("无结果, 退出")
        return

    # 算统计
    stats = compute_stats(results)

    # 打印报告
    print_report(stats)

    # 保存
    if args.output:
        output_data = {
            "config": vars(args),
            "stats": stats,
            "results": [r.to_dict() for r in results],
        }
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        print(f"\n结果已保存到: {args.output}")
        print("下次对比: python compare_results.py baseline.json exp1.json")


if __name__ == "__main__":
    asyncio.run(main())

"""
学习建议:
    1. 先跑基线: python benchmark_serving.py --model xxx --output baseline.json
    2. 改一个 vLLM 配置, 重跑: python benchmark_serving.py ... --output exp1.json
    3. 对比 P99 / 吞吐变化
    4. 改 request_rate 看不同负载下的表现
    5. 改 max_tokens 看 prefill vs decode 比例的影响

进阶改造:
    - 加 Poisson 到达 (更真实模拟流量)
    - 加 multi-turn 对话场景 (测 prefix caching)
    - 加长 prompt 场景 (测 chunked prefill)
    - 加监控显存采样 (nvidia-smi 后台跑)
    - 加 nsys 自动 profile (出问题时自动抓 trace)

对比脚本 (compare_results.py) 可以自己写, 核心就是:
    读两个 JSON, 对比 P99/吞吐, 打印百分比变化
"""
