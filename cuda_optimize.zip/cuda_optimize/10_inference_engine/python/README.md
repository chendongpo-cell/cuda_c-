﻿# 最小推理引擎（Minimal Inference Engine）

> 这是一个**教学用**的简化推理引擎，用纯 Python + PyTorch 实现。目的是把前 19 章学到的概念串起来：
> - KV Cache（[04_attention_kv_cache.md](../docs/04_attention_kv_cache.md)）
> - PagedAttention 的分页思想（[06_paged_attention.md](../docs/06_paged_attention.md)）
> - Continuous Batching 调度（[07_continuous_batching.md](../docs/07_continuous_batching.md)）
> - Prefill / Decode 两阶段（[04_attention_kv_cache.md](../docs/04_attention_kv_cache.md)）
>
> **不是性能优化项目**：目标是"能跑通、能看懂、能改造"，不是替代 vLLM。
>
> 学完这个引擎，再读 vLLM 源码会感觉"哦原来是这样"。

---

## 文件结构

```
10_inference_engine/python/
├── README.md              # 本文件
├── model.py               # 简化 Transformer 模型（只够演示）
├── kv_cache.py            # 分页 KV Cache
├── scheduler.py           # Continuous Batching 调度器
├── engine.py              # 主引擎循环
└── run_demo.py            # 启动脚本：模拟 3 个并发请求
```

---

## 学习顺序

1. 读 `model.py` → 理解一个最小 Transformer 的 forward
2. 读 `kv_cache.py` → 理解分页 KV Cache 的存储和寻址
3. 读 `scheduler.py` → 理解 continuous batching 的状态机
4. 读 `engine.py` → 理解 prefill + decode 主循环
5. 跑 `run_demo.py` → 看真实运行输出
6. 改代码做实验：
   - 改 `block_size` 看 KV 利用率变化
   - 改 `max_batch_size` 看吞吐变化
   - 加 prefix caching

---

## 与 vLLM 的对应关系

| 本项目 | vLLM 对应 |
|-------|----------|
| `model.py` | `vllm/model_executor/models/` |
| `kv_cache.py` | `vllm/attention/backends/flash_attn.py` 的 KV Cache 部分 |
| `scheduler.py` | `vllm/core/scheduler.py` |
| `engine.py` | `vllm/engine/llm_engine.py` |
| `block_size = 16` | vLLM 默认 `block_size = 16` |
| `running_queue` | vLLM 的 `running` 队列 |
| `waiting_queue` | vLLM 的 `waiting` 队列 |

---

## 简化掉的真实复杂度

为了教学清晰，本项目省略了：

| 真实推理引擎做的事 | 本项目 |
|------------------|--------|
| 多卡并行（TP/PP/EP） | 单卡 |
| 真实 tokenizer / sampling | 用 argmax 简化 |
| CUDA kernel | 用 PyTorch op |
| 真实 LLM 权重 | 随机初始化小模型 |
| Prefix Caching | 不实现 |
| 抢占（preemption） | 不实现 |
| Speculative Decoding | 不实现 |

这些都可以作为练习加进去。每加一个，对照 [15-18 章](../docs/) 的文档看原理。

---

## 运行

```bash
cd 10_inference_engine/python
python run_demo.py
```

预期输出：3 个请求并发处理，能看到 prefill 阶段、decode 阶段、最后输出"生成完成"。
