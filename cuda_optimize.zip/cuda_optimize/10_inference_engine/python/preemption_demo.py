﻿"""
preemption_demo.py — Preemption 两种策略对比演示

配合 [docs/25_preemption_implementation.md](../docs/25_preemption_implementation.md) 使用。

演示 vLLM 在 KV Cache 不够时的两种抢占策略:
    1. RECOMPUTE: 丢弃 KV, 把请求放回 waiting, 恢复时重新 prefill
    2. SWAP: 把 KV 拷到 CPU, 恢复时拷回 GPU

用模拟数据演示流程, 不依赖真实模型。

学习目标:
    1. 理解 preemption 触发条件
    2. 理解 RECOMPUTE 和 SWAP 的差异
    3. 理解两种策略的恢复延迟
    4. 理解什么时候用哪种

运行:
    cd 10_inference_engine/python
    python preemption_demo.py
"""

import time
from dataclasses import dataclass, field
from typing import List, Optional, Dict
import random


# ============================================================
# 模拟数据结构
# ============================================================

@dataclass
class Request:
    """模拟推理请求"""
    request_id: int
    prompt_length: int             # prompt token 数
    output_length: int = 0         # 已生成的 output token 数
    max_output: int = 20           # 最多生成多少
    status: str = "waiting"        # waiting / running / preempted
    kv_cache_size: int = 0         # 当前占用的 KV token 数

    def total_length(self) -> int:
        return self.prompt_length + self.output_length


@dataclass
class KVCacheBlock:
    """模拟 KV Cache 物理 block"""
    block_id: int
    owner_request_id: Optional[int] = None
    token_count: int = 0


# ============================================================
# 简化引擎 (带 preemption)
# ============================================================

class EngineWithPreemption:
    """
    简化推理引擎, 演示 preemption 两种策略

    模拟流程:
        1. 每个时刻 (step) 收到若干新请求
        2. 调度: 把 waiting 升级到 running, 直到 KV Cache 不够
        3. KV Cache 不够时, 触发 preemption
        4. 被抢占的请求按策略 (RECOMPUTE / SWAP) 处理
        5. running 的请求每步生成 1 token
    """

    def __init__(
        self,
        total_kv_capacity: int = 200,   # KV Cache 总容量 (token 数)
        preemption_mode: str = "recompute",  # "recompute" or "swap"
        swap_cpu_memory: int = 1000,    # CPU swap 内存容量 (token 数)
    ):
        self.total_kv_capacity = total_kv_capacity
        self.preemption_mode = preemption_mode
        self.swap_cpu_memory = swap_cpu_memory

        self.waiting: List[Request] = []
        self.running: List[Request] = []

        # CPU swap 区: request_id -> kv_size
        self.swapped: Dict[int, int] = {}

        # 统计
        self.stats = {
            "preemption_count": 0,
            "recompute_count": 0,
            "swap_out_count": 0,
            "swap_in_count": 0,
            "total_tokens_generated": 0,
            "total_recompute_tokens": 0,  # 因 preemption 重算的 token
        }

        # 模拟时间 (每个 step = 1 ms)
        self.current_time = 0

    def add_request(self, req: Request) -> None:
        """添加新请求"""
        self.waiting.append(req)

    def total_kv_used(self) -> int:
        """当前 running 占用的 KV 总量"""
        return sum(r.kv_cache_size for r in self.running)

    def _prefill_cost(self, req: Request) -> int:
        """prefill 一个请求需要多少 KV (prompt 长度)"""
        return req.prompt_length

    def _decode_cost(self, req: Request) -> int:
        """decode 一个请求需要新增多少 KV (1 token)"""
        return 1

    def _try_schedule(self) -> List[str]:
        """
        尝试调度: 把 waiting 升级到 running

        返回: 这一 step 的事件列表
        """
        events = []

        while self.waiting:
            req = self.waiting[0]
            cost = self._prefill_cost(req)

            if self.total_kv_used() + cost <= self.total_kv_capacity:
                # 容量够, 升级
                self.waiting.pop(0)
                req.status = "running"
                req.kv_cache_size = cost
                self.running.append(req)
                events.append(f"Prefill req {req.request_id} "
                              f"(prompt={req.prompt_length}, cost={cost})")
            else:
                # 容量不够, 检查能否 preemption
                if self.running and self.preemption_mode != "none":
                    # 抢占最后进来的 running 请求
                    victim = self.running[-1]
                    preempt_event = self._preempt(victim)
                    events.append(preempt_event)
                else:
                    # 无法 preemption (或关闭), 停止调度
                    break

        return events

    def _preempt(self, victim: Request) -> str:
        """抢占一个请求"""
        self.stats["preemption_count"] += 1
        freed_kv = victim.kv_cache_size

        if self.preemption_mode == "recompute":
            # RECOMPUTE: 丢弃 KV
            self.stats["recompute_count"] += 1
            self.stats["total_recompute_tokens"] += victim.total_length()

            victim.kv_cache_size = 0
            victim.output_length = 0  # 重置进度, 恢复时重新 prefill
            victim.status = "waiting"

            self.running.remove(victim)
            self.waiting.insert(0, victim)  # 放回 waiting 头部

            return (f"PREEMPT req {victim.request_id} (RECOMPUTE, "
                    f"freed {freed_kv} tokens, lost progress)")

        elif self.preemption_mode == "swap":
            # SWAP: KV 拷到 CPU
            self.stats["swap_out_count"] += 1

            # 检查 CPU 内存够不够
            if sum(self.swapped.values()) + freed_kv > self.swap_cpu_memory:
                # CPU 内存也不够, 退化到 RECOMPUTE
                self.stats["recompute_count"] += 1
                self.stats["total_recompute_tokens"] += victim.total_length()
                victim.kv_cache_size = 0
                victim.output_length = 0
                victim.status = "waiting"
                self.running.remove(victim)
                self.waiting.insert(0, victim)
                return (f"PREEMPT req {victim.request_id} "
                        f"(SWAP→RECOMPUTE, CPU memory full)")

            # 正常 SWAP
            self.swapped[victim.request_id] = freed_kv
            victim.kv_cache_size = 0
            victim.status = "swapped"

            self.running.remove(victim)
            self.waiting.insert(0, victim)

            return (f"PREEMPT req {victim.request_id} (SWAP, "
                    f"freed {freed_kv} tokens, KV saved in CPU)")

        return ""

    def _swap_in(self, req: Request) -> str:
        """把 swapped 的请求恢复"""
        self.stats["swap_in_count"] += 1
        kv_size = self.swapped.pop(req.request_id)
        req.kv_cache_size = kv_size
        req.status = "running"
        return f"SWAP-IN req {req.request_id} (restored {kv_size} tokens)"

    def step(self) -> List[str]:
        """执行一个 step"""
        self.current_time += 1
        events = []

        # 1. 调度 (可能触发 preemption)
        events.extend(self._try_schedule())

        # 2. 每个 running 请求 decode 1 token
        for req in list(self.running):
            cost = self._decode_cost(req)

            # 检查容量
            if self.total_kv_used() + cost > self.total_kv_capacity:
                # 不够, 抢占 (但这里不处理, 留给下一 step)
                continue

            req.kv_cache_size += cost
            req.output_length += 1
            self.stats["total_tokens_generated"] += 1
            events.append(f"Decode req {req.request_id} "
                          f"(token #{req.output_length})")

            # 检查完成
            if req.output_length >= req.max_output:
                events.append(f"FINISH req {req.request_id}")
                self.running.remove(req)

        # 3. 尝试恢复 swapped 请求
        for req in list(self.waiting):
            if req.status == "swapped":
                cost = self.swapped.get(req.request_id, 0)
                if self.total_kv_used() + cost <= self.total_kv_capacity:
                    event = self._swap_in(req)
                    events.append(event)
                    self.waiting.remove(req)
                    self.running.append(req)
                    break  # 一次只恢复一个

        return events

    def has_work(self) -> bool:
        return bool(self.waiting or self.running)

    def print_stats(self) -> None:
        print(f"\n--- 统计 ({self.preemption_mode}) ---")
        print(f"  生成总 token:    {self.stats['total_tokens_generated']}")
        print(f"  preemption 次数: {self.stats['preemption_count']}")
        print(f"  RECOMPUTE 次数:  {self.stats['recompute_count']}")
        print(f"  SWAP out 次数:   {self.stats['swap_out_count']}")
        print(f"  SWAP in 次数:    {self.stats['swap_in_count']}")
        print(f"  重算 token:      {self.stats['total_recompute_tokens']}")
        print(f"  总耗时:          {self.current_time} steps")


# ============================================================
# 演示场景
# ============================================================

def run_scenario(mode: str, num_requests: int = 8):
    """跑一个场景: num_requests 个请求, KV Cache 不够"""
    print(f"\n{'=' * 60}")
    print(f"场景: preemption_mode = {mode}, {num_requests} 个请求")
    print(f"{'=' * 60}")

    random.seed(42)
    engine = EngineWithPreemption(
        total_kv_capacity=80,        # 故意设小, 触发 preemption
        preemption_mode=mode,
        swap_cpu_memory=500,
    )

    # 添加请求, 每个 prompt 长度 15-25
    for i in range(num_requests):
        req = Request(
            request_id=i + 1,
            prompt_length=random.randint(15, 25),
            max_output=random.randint(10, 20),
        )
        engine.add_request(req)

    print(f"\n初始请求:")
    for r in engine.waiting:
        print(f"  req {r.request_id}: prompt={r.prompt_length}, max_out={r.max_output}")

    print(f"\nKV Cache 容量: {engine.total_kv_capacity} tokens")

    # 跑主循环
    max_steps = 200
    step = 0
    while engine.has_work() and step < max_steps:
        step += 1
        events = engine.step()
        if events:
            print(f"\n[Step {step}]")
            for e in events:
                print(f"  {e}")

    # 统计
    engine.print_stats()
    return engine.stats


def compare_modes():
    """对比两种策略"""
    print("\n" + "=" * 60)
    print("对比 RECOMPUTE vs SWAP")
    print("=" * 60)

    recompute_stats = run_scenario("recompute", num_requests=8)
    swap_stats = run_scenario("swap", num_requests=8)

    print(f"\n{'=' * 60}")
    print(f"对比结果")
    print(f"{'=' * 60}")
    print(f"{'指标':<25} {'RECOMPUTE':<15} {'SWAP':<15}")
    print(f"{'-' * 55}")
    print(f"{'生成总 token':<25} "
          f"{recompute_stats['total_tokens_generated']:<15} "
          f"{swap_stats['total_tokens_generated']:<15}")
    print(f"{'preemption 次数':<25} "
          f"{recompute_stats['preemption_count']:<15} "
          f"{swap_stats['preemption_count']:<15}")
    print(f"{'重算 token':<25} "
          f"{recompute_stats['total_recompute_tokens']:<15} "
          f"{swap_stats['total_recompute_tokens']:<15}")

    print(f"\n结论:")
    print(f"  RECOMPUTE 模式: 抢占时丢失进度, 恢复时重新 prefill")
    print(f"  SWAP 模式:      抢占时保留 KV, 恢复时拷回, 浪费少")
    print(f"  实际部署:")
    print(f"    - 短 prompt 场景用 RECOMPUTE (重算代价小)")
    print(f"    - 长 prompt 场景用 SWAP (重算代价大)")
    print(f"    - vLLM 默认 RECOMPUTE, 通过 --preemption-mode swap 切换")


# ============================================================
# 主入口
# ============================================================

if __name__ == "__main__":
    print("╔" + "═" * 60 + "╗")
    print("║" + " Preemption 策略对比演示 ".center(54) + "║")
    print("╚" + "═" * 60 + "╝")

    compare_modes()

    print("\n" + "=" * 60)
    print("说明:")
    print("  这个 demo 用模拟数据演示 preemption 流程")
    print("  真实 vLLM 实现见 vllm/core/scheduler.py 的 _preempt 方法")
    print("  关键差异:")
    print("    RECOMPUTE: 释放 KV block, 重置请求, 恢复时重新 prefill")
    print("    SWAP: KV 拷到 CPU pinned memory, 恢复时拷回")
    print("=" * 60)
