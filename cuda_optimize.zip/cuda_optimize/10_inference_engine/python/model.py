"""
model.py — 简化 Transformer 模型（教学版）

这个文件实现一个最小的 Transformer decoder,用于推理引擎演示。
**不是真实可用的 LLM**:
- 参数随机初始化(输出是随机的,但流程正确)
- 只有 2 层,hidden=64,够跑通但不追求质量
- 用 PyTorch 的 eager 模式,不优化性能

学习目标:
    1. 理解 Transformer 的前向传播流程
    2. 理解 KV Cache 在前向中如何被读写
    3. 区分 prefill 模式和 decode 模式

对应 vLLM 的:
    vllm/model_executor/models/llama.py
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


class SimpleAttention(nn.Module):
    """
    简化版 Multi-Head Attention,带 KV Cache 支持

    和真实 LLM 的 attention 区别:
    - 没有 FlashAttention,用朴素的 softmax(Q @ K^T) @ V
    - 没有 GQA/MQA,所有 head 独立
    - 没有 rotary embedding
    - 但 KV Cache 的读写逻辑是完整的

    KV Cache 的工作方式:
    - Prefill: input 是 [batch, seq_len, hidden],要算整个 seq 的 attention
      K, V 算出来后存到 cache 里,供 decode 复用
    - Decode: input 是 [batch, 1, hidden](只 1 个新 token)
      把新 K, V append 到 cache,然后用完整 K, V 算 attention
    """

    def __init__(self, hidden: int, num_heads: int):
        super().__init__()
        self.hidden = hidden
        self.num_heads = num_heads
        self.head_dim = hidden // num_heads

        # Q/K/V 投影矩阵: 把 hidden 维映射到 3 * hidden (Q/K/V 各一份)
        self.qkv_proj = nn.Linear(hidden, 3 * hidden, bias=False)
        # Output 投影: 把 attention 输出映射回 hidden
        self.o_proj = nn.Linear(hidden, hidden, bias=False)

    def forward(
        self,
        x: torch.Tensor,                   # [batch, seq_len, hidden]
        kv_cache: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        positions: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """
        参数:
            x: 输入 token 的 embedding, [batch, seq_len, hidden]
            kv_cache: 之前的 K, V cache (如果有)
                - None: prefill 模式,从 0 开始
                - 不为 None: decode 模式,把新 K, V append 进去
            positions: 每个 token 的绝对位置 (用于位置编码,这里简化)

        返回:
            output: [batch, seq_len, hidden]
            new_kv_cache: 更新后的 (K, V) cache
        """
        b, s, h = x.shape

        # 1. Q/K/V 投影
        # qkv: [batch, seq_len, 3 * hidden]
        qkv = self.qkv_proj(x)

        # 切成 Q, K, V 三个 [batch, seq_len, hidden]
        q, k, v = qkv.split(self.hidden, dim=-1)

        # reshape 成多头形式: [batch, seq_len, num_heads, head_dim]
        # 然后转置成 [batch, num_heads, seq_len, head_dim] 方便 attention
        q = q.view(b, s, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(b, s, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(b, s, self.num_heads, self.head_dim).transpose(1, 2)

        # 2. 处理 KV Cache
        if kv_cache is not None:
            # Decode 模式: 把新的 K, V 拼到 cache 后面
            # kv_cache[0] shape: [batch, num_heads, past_seq_len, head_dim]
            past_k, past_v = kv_cache
            k = torch.cat([past_k, k], dim=2)  # 沿 seq_len 维拼接
            v = torch.cat([past_v, v], dim=2)
            # 现在 k, v 的 seq_len = past_seq_len + 1

        new_kv_cache = (k, v)

        # 3. Attention 计算
        # q @ k^T: [batch, num_heads, q_seq_len, k_seq_len]
        # 缩放: 除以 sqrt(head_dim) 防止 softmax 进入饱和区
        scores = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)

        # 4. Causal mask (避免看到未来的 token)
        # 在 prefill 时 q_seq_len == k_seq_len,需要 mask 上三角
        # 在 decode 时 q_seq_len == 1,不需要 mask
        q_seq_len = q.size(2)
        k_seq_len = k.size(2)
        if q_seq_len > 1:
            # 生成下三角 mask: [q_seq_len, k_seq_len]
            # mask[i][j] = 1 表示位置 i 可以看到位置 j
            causal_mask = torch.tril(
                torch.ones(q_seq_len, k_seq_len, device=x.device, dtype=torch.bool)
            )
            # 把 mask False 的位置设成 -inf,scores 经过 softmax 后变 0
            scores = scores.masked_fill(~causal_mask, float('-inf'))

        # 5. Softmax + 加权求和
        probs = F.softmax(scores, dim=-1)  # [batch, num_heads, q_seq_len, k_seq_len]
        out = torch.matmul(probs, v)       # [batch, num_heads, q_seq_len, head_dim]

        # 6. 合并多头: [batch, seq_len, hidden]
        out = out.transpose(1, 2).contiguous().view(b, s, h)

        # 7. Output 投影
        out = self.o_proj(out)
        return out, new_kv_cache


class SimpleMLP(nn.Module):
    """
    简化 FFN: SiLU 激活的 gate + up + down (Llama 风格)

    真实 LLM 的 FFN 通常是:
        hidden -> inter (gate) -> SiLU
        hidden -> inter (up)
        SiLU(gate) * up -> down -> hidden
    """

    def __init__(self, hidden: int, inter: int):
        super().__init__()
        self.gate_proj = nn.Linear(hidden, inter, bias=False)
        self.up_proj = nn.Linear(hidden, inter, bias=False)
        self.down_proj = nn.Linear(inter, hidden, bias=False)

    def forward(self, x):
        # SiLU(x) = x * sigmoid(x)
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class SimpleTransformerBlock(nn.Module):
    """一层 Transformer: LayerNorm -> Attention -> Residual -> LayerNorm -> MLP -> Residual"""

    def __init__(self, hidden: int, num_heads: int, inter: int):
        super().__init__()
        self.input_norm = nn.LayerNorm(hidden)
        self.attn = SimpleAttention(hidden, num_heads)
        self.post_norm = nn.LayerNorm(hidden)
        self.mlp = SimpleMLP(hidden, inter)

    def forward(
        self,
        x: torch.Tensor,
        kv_cache: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        # Pre-norm 结构: 先 norm 再 attention
        residual = x
        x_norm = self.input_norm(x)
        attn_out, new_kv = self.attn(x_norm, kv_cache)
        x = residual + attn_out

        # FFN 部分
        residual = x
        x_norm = self.post_norm(x)
        mlp_out = self.mlp(x_norm)
        x = residual + mlp_out
        return x, new_kv


class TinyLLM(nn.Module):
    """
    最小 LLM,用于推理引擎演示

    配置:
        vocab_size = 100    (词表小,演示用)
        hidden = 64
        num_layers = 2
        num_heads = 4
        head_dim = 16

    真实 Llama-7B 对比:
        vocab_size = 32000
        hidden = 4096
        num_layers = 32
        num_heads = 32
        head_dim = 128

    差距很大,但流程完全一样。
    """

    def __init__(
        self,
        vocab_size: int = 100,
        hidden: int = 64,
        num_layers: int = 2,
        num_heads: int = 4,
        inter: int = 256,
    ):
        super().__init__()
        self.hidden = hidden
        self.num_layers = num_layers

        # Token embedding: 把 token id 变成 hidden 向量
        self.token_embedding = nn.Embedding(vocab_size, hidden)

        # 堆叠 N 层 Transformer Block
        self.layers = nn.ModuleList([
            SimpleTransformerBlock(hidden, num_heads, inter)
            for _ in range(num_layers)
        ])

        # 最终 LayerNorm
        self.final_norm = nn.LayerNorm(hidden)

        # LM Head: 把 hidden 映射回 vocab_size,得到 logits
        # 注意: 真实 LLM 通常和 embedding 共享权重 (weight tying),这里简化
        self.lm_head = nn.Linear(hidden, vocab_size, bias=False)

    def forward(
        self,
        input_ids: torch.Tensor,       # [batch, seq_len]
        kv_caches: Optional[list] = None,  # list of (K, V) per layer
    ) -> Tuple[torch.Tensor, list]:
        """
        返回:
            logits: [batch, seq_len, vocab_size]
            new_kv_caches: 每层更新后的 KV cache
        """
        b, s = input_ids.shape

        # 1. Token embedding
        x = self.token_embedding(input_ids)  # [batch, seq_len, hidden]

        # 2. 走每一层 Transformer
        new_kv_caches = []
        for i, layer in enumerate(self.layers):
            layer_cache = kv_caches[i] if kv_caches is not None else None
            x, new_kv = layer(x, layer_cache)
            new_kv_caches.append(new_kv)

        # 3. Final norm + LM head
        x = self.final_norm(x)
        logits = self.lm_head(x)  # [batch, seq_len, vocab_size]

        return logits, new_kv_caches


# 测试代码
if __name__ == "__main__":
    torch.manual_seed(42)
    model = TinyLLM().cuda()
    print(f"模型参数量: {sum(p.numel() for p in model.parameters()) / 1e3:.1f}K")

    # 模拟 prefill
    input_ids = torch.randint(0, 100, (2, 10)).cuda()  # batch=2, seq_len=10
    logits, kv_caches = model(input_ids)
    print(f"Prefill logits shape: {logits.shape}")
    print(f"KV cache 数量 (layer 数): {len(kv_caches)}")
    print(f"每层 K shape: {kv_caches[0][0].shape}")
    # 预期: [batch=2, num_heads=4, seq_len=10, head_dim=16]

    # 模拟 decode: 输入 1 个新 token
    new_token = torch.randint(0, 100, (2, 1)).cuda()
    logits2, kv_caches2 = model(new_token, kv_caches)
    print(f"Decode logits shape: {logits2.shape}")
    print(f"更新后 K shape: {kv_caches2[0][0].shape}")
    # 预期: [batch=2, num_heads=4, seq_len=11, head_dim=16] (seq_len +1)

    print("\n模型测试通过!")
