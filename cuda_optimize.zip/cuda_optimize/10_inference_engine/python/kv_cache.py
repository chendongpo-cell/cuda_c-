﻿"""
kv_cache.py — 分页 KV Cache (PagedAttention 简化版)

实现 [06_paged_attention.md](../docs/06_paged_attention.md) 的核心思想:
- 把 KV Cache 分成固定大小的 block (block_size 个 token 一块)
- 用 block table 管理逻辑→物理映射
- 支持按需分配 (不需要连续内存)

和 vLLM 的 PagedAttention 区别:
- vLLM 在 GPU kernel 层做分页寻址 (custom CUDA kernel)
- 我们在 Python 层做,慢但易懂
- 真实 PagedAttention 用一次大 attention kernel 完成所有 batch 的计算
- 我们用 PyTorch 的标准 attention + Python 循环模拟

学习目标:
    1. 理解 block table 是什么
    2. 理解物理 block 和逻辑序列的映射
    3. 理解按需分配如何节省显存

数据结构:
    K/V cache: 物理块池
        shape: [num_blocks, block_size, num_heads, head_dim]
        所有 block 在一个大方阵里,谁要用就拿一个

    block_table: 每个 sequence 的逻辑→物理映射
        shape: [batch, max_blocks_per_seq]
        block_table[batch][logical_block_idx] = physical_block_idx
"""

import torch
from typing import List, Optional


class PagedKVCache:
    """
    分页 KV Cache 实现

    构造参数:
        num_blocks: 物理块总数 (决定了能装多少 KV)
        block_size: 每个块容纳的 token 数 (vLLM 默认 16)
        num_layers: 模型层数
        num_heads: 注意力头数
        head_dim: 每个头的维度
        dtype: 数据类型 (torch.float16 / torch.bfloat16)

    内部存储:
        self.k_blocks: [num_layers, num_blocks, block_size, num_heads, head_dim]
        self.v_blocks: 同上

        self.block_tables: [batch_size, max_blocks_per_seq]
            每个 sequence 有一行,记录它用到的物理 block 编号

        self.seq_lengths: [batch_size]
            每个 sequence 当前的实际长度
    """

    def __init__(
        self,
        num_blocks: int,
        block_size: int,
        num_layers: int,
        num_heads: int,
        head_dim: int,
        dtype=torch.float32,
        device="cuda",
    ):
        self.block_size = block_size
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.head_dim = head_dim

        # 物理块池: 所有 KV 数据存在这里
        # shape: [num_layers, num_blocks, block_size, num_heads, head_dim]
        # num_layers 维放在最外,因为每层独立
        self.k_blocks = torch.zeros(
            num_layers, num_blocks, block_size, num_heads, head_dim,
            dtype=dtype, device=device,
        )
        self.v_blocks = torch.zeros_like(self.k_blocks)

        # 空闲块列表: 用 Python list 维护,简单直观
        # vLLM 用更高效的 allocator,但思想一样
        self.free_blocks: List[int] = list(range(num_blocks))

        # block table: [batch, max_blocks_per_seq]
        # max_blocks_per_seq 决定单个 sequence 最长能到多少
        self.max_blocks_per_seq = 0  # 在 allocate 时设置
        self.block_tables: Optional[torch.Tensor] = None
        self.seq_lengths: Optional[torch.Tensor] = None

    def allocate_sequence(self, batch_size: int, max_seq_len: int) -> None:
        """
        为一个 batch 的 sequence 分配 block table 结构

        注意: 这里只分配 mapping,不立即分配物理块
        真实 PagedAttention 是"按需"分配: prefill 时需要几块就分几块
        """
        # 计算每个 sequence 最多需要多少块
        # 例如 max_seq_len=100, block_size=16 → 需要 ceil(100/16) = 7 块
        self.max_blocks_per_seq = (max_seq_len + self.block_size - 1) // self.block_size

        # block_table[i][j] = 第 i 个 sequence 的第 j 个逻辑块对应的物理块编号
        # 初始化为 -1 表示"还没分配"
        self.block_tables = torch.full(
            (batch_size, self.max_blocks_per_seq),
            -1, dtype=torch.int32, device=self.k_blocks.device,
        )

        # 每个 sequence 的实际长度
        self.seq_lengths = torch.zeros(
            batch_size, dtype=torch.int32, device=self.k_blocks.device,
        )

    def _allocate_block(self) -> int:
        """从空闲池里拿一个物理块,返回块编号"""
        if not self.free_blocks:
            raise RuntimeError("KV Cache 物理块用光了! 需要:增大 num_blocks 或减小 batch")
        return self.free_blocks.pop()

    def _free_block(self, block_idx: int) -> None:
        """归还一个物理块到空闲池"""
        self.free_blocks.append(block_idx)

    def ensure_blocks_for_seq(self, batch_idx: int, seq_len: int) -> None:
        """
        确保第 batch_idx 个 sequence 有足够的物理块来容纳 seq_len 个 token

        例如: seq_len=20, block_size=16
            需要 ceil(20/16) = 2 个块
            如果当前只有 1 个块,再分配 1 个
        """
        needed_blocks = (seq_len + self.block_size - 1) // self.block_size

        for logical_idx in range(needed_blocks):
            if self.block_tables[batch_idx, logical_idx] == -1:
                # 这个逻辑块还没分配物理块,分配一个
                phys_idx = self._allocate_block()
                self.block_tables[batch_idx, logical_idx] = phys_idx

    def write_kv(
        self,
        batch_idx: int,
        layer_idx: int,
        token_positions: List[int],
        new_k: torch.Tensor,    # [num_heads, head_dim] 或 [num_new_tokens, num_heads, head_dim]
        new_v: torch.Tensor,
    ) -> None:
        """
        把新的 K, V 数据写到 cache 里

        参数:
            batch_idx: 哪个 sequence
            layer_idx: 哪一层
            token_positions: 这些新 token 的绝对位置 [0, 1, 2, ...]
            new_k, new_v: 要写入的数据

        写入逻辑:
            for pos, k, v in zip(token_positions, new_k, new_v):
                logical_block = pos // block_size
                offset_in_block = pos % block_size
                physical_block = block_table[batch_idx][logical_block]
                k_blocks[layer][physical_block][offset_in_block] = k
        """
        if new_k.dim() == 2:  # 单个 token: [num_heads, head_dim]
            new_k = new_k.unsqueeze(0)
            new_v = new_v.unsqueeze(0)

        num_new = new_k.size(0)
        for i in range(num_new):
            pos = token_positions[i]
            logical_block = pos // self.block_size
            offset = pos % self.block_size
            physical_block = int(self.block_tables[batch_idx, logical_block].item())

            # 写入物理块
            self.k_blocks[layer_idx, physical_block, offset] = new_k[i]
            self.v_blocks[layer_idx, physical_block, offset] = new_v[i]

    def read_kv(
        self,
        batch_idx: int,
        layer_idx: int,
        seq_len: int,
    ) -> torch.Tensor:
        """
        读取第 batch_idx 个 sequence 在第 layer_idx 层的完整 KV cache

        返回:
            k: [seq_len, num_heads, head_dim]
            v: 同上

        读取逻辑:
            从 block_table 找出所有需要的物理块
            按顺序拼接起来
        """
        num_blocks_needed = (seq_len + self.block_size - 1) // self.block_size
        k_list = []
        v_list = []

        for logical_idx in range(num_blocks_needed):
            physical_block = int(self.block_tables[batch_idx, logical_idx].item())
            # 从物理块读取 block_size 个 token 的 KV
            k_list.append(self.k_blocks[layer_idx, physical_block])
            v_list.append(self.v_blocks[layer_idx, physical_block])

        # 拼接: [num_blocks * block_size, num_heads, head_dim]
        k = torch.cat(k_list, dim=0)
        v = torch.cat(v_list, dim=0)

        # 截断到实际 seq_len (最后一块可能没填满)
        k = k[:seq_len]
        v = v[:seq_len]
        return k, v

    def free_sequence(self, batch_idx: int) -> None:
        """释放一个 sequence 占用的所有物理块"""
        for logical_idx in range(self.max_blocks_per_seq):
            phys_idx = int(self.block_tables[batch_idx, logical_idx].item())
            if phys_idx != -1:
                self._free_block(phys_idx)
                self.block_tables[batch_idx, logical_idx] = -1

    def num_free_blocks(self) -> int:
        return len(self.free_blocks)

    def total_capacity_tokens(self) -> int:
        """KV Cache 总共能装多少 token"""
        return len(self.free_blocks) * self.block_size + (
            self.block_tables.numel() - self.block_tables.numel()
            if self.block_tables is not None else 0
        )


# 测试
if __name__ == "__main__":
    # 配置
    NUM_BLOCKS = 10
    BLOCK_SIZE = 4
    NUM_LAYERS = 2
    NUM_HEADS = 4
    HEAD_DIM = 16

    cache = PagedKVCache(
        num_blocks=NUM_BLOCKS,
        block_size=BLOCK_SIZE,
        num_layers=NUM_LAYERS,
        num_heads=NUM_HEADS,
        head_dim=HEAD_DIM,
    )

    # 模拟 2 个 sequence
    cache.allocate_sequence(batch_size=2, max_seq_len=20)
    print(f"初始空闲块数: {cache.num_free_blocks()}")  # 应该是 10

    # Sequence 0 需要 7 个 token
    cache.ensure_blocks_for_seq(0, 7)
    print(f"Seq0 分配后空闲块数: {cache.num_free_blocks()}")  # 10 - 2 = 8 (ceil(7/4)=2)
    print(f"Seq0 的 block_table: {cache.block_tables[0]}")
    # 预期: [phys_a, phys_b, -1, -1, -1] (分配了 2 个块)

    # Sequence 1 需要 10 个 token
    cache.ensure_blocks_for_seq(1, 10)
    print(f"Seq1 分配后空闲块数: {cache.num_free_blocks()}")  # 8 - 3 = 5

    # 写入测试
    new_k = torch.randn(NUM_HEADS, HEAD_DIM).cuda()
    new_v = torch.randn(NUM_HEADS, HEAD_DIM).cuda()
    cache.write_kv(0, 0, [0], new_k, new_v)  # 第 0 层,第 0 个位置

    # 读取测试
    k, v = cache.read_kv(0, 0, 1)
    print(f"读取的 K shape: {k.shape}")  # [1, 4, 16]

    # 释放
    cache.free_sequence(0)
    print(f"释放 Seq0 后空闲块数: {cache.num_free_blocks()}")  # 应该回到 8

    print("\nKV Cache 测试通过!")
