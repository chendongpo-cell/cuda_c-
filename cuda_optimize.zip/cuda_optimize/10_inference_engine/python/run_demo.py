﻿"""
run_demo.py — 启动脚本: 演示推理引擎处理 3 个并发请求

运行:
    cd 10_inference_engine/python
    python run_demo.py

观察输出:
    - 3 个请求被加入 waiting 队列
    - 调度器逐 step 把请求升级到 running
    - prefill 后开始 decode
    - 完成的请求从 running 移走
    - 最后所有请求完成

实验建议:
    1. 改 max_batch_size 看吞吐变化
    2. 改 max_total_tokens 触发 preemption
    3. 改 max_output_tokens 看长生成
    4. 加 print 看 KV Cache 利用率
"""

import torch
from model import TinyLLM
from engine import InferenceEngine
from scheduler import Request


def main():
    # 固定随机种子,结果可复现
    torch.manual_seed(42)

    print("初始化模型和引擎...")
    model = TinyLLM(
        vocab_size=100,
        hidden=64,
        num_layers=2,
        num_heads=4,
        inter=256,
    ).cuda()

    engine = InferenceEngine(
        model=model,
        num_blocks=50,            # 50 个物理块
        block_size=4,             # 每块 4 个 token
        max_batch_size=3,         # 同时处理 3 个请求
        max_total_tokens=100,     # KV Cache 总容量
    )

    # 构造 3 个请求
    # prompt 是随机 token,只为了演示流程
    req1 = Request(
        request_id=1,
        prompt_tokens=[1, 5, 8, 12, 3, 7],   # 6 token 的 prompt
        max_output_tokens=5,
    )
    req2 = Request(
        request_id=2,
        prompt_tokens=[20, 15, 9],           # 3 token 的 prompt
        max_output_tokens=4,
    )
    req3 = Request(
        request_id=3,
        prompt_tokens=[42, 11, 33, 7, 19],   # 5 token 的 prompt
        max_output_tokens=3,
    )

    print(f"加入 3 个请求: prompt 长度分别为 {len(req1.prompt_tokens)}, "
          f"{len(req2.prompt_tokens)}, {len(req3.prompt_tokens)}")

    engine.add_request(req1)
    engine.add_request(req2)
    engine.add_request(req3)

    # 跑!
    engine.run()

    # 输出最终结果
    print("\n" + "=" * 60)
    print("最终输出:")
    print("=" * 60)
    for req in [req1, req2, req3]:
        print(f"Request {req.request_id}:")
        print(f"  Prompt:  {req.prompt_tokens}")
        print(f"  Output:  {req.output_tokens}")
        print(f"  Total tokens: {req.total_length()}")


if __name__ == "__main__":
    main()
