"""
engine.py — 推理引擎主循环

把 model.py, kv_cache.py, scheduler.py 串起来,实现一个最小的推理引擎。

核心循环:
    while scheduler.has_pending_work():
        plan = scheduler.schedule()
        if plan["to_prefill"]:
            do_prefill(plan["to_prefill"])
        elif plan["to_decode"]:
            do_decode(plan["to_decode"])
        check_finished()

学习目标:
    1. 理解 prefill 和 decode 在代码上具体怎么写
    2. 理解 KV Cache 怎么和模型 forward 配合
    3. 理解 continuous batching 的主循环结构

对应 vLLM 的:
    vllm/engine/llm_engine.py 的 step() 方法
"""

import torch
from typing import List
from model import TinyLLM
from kv_cache import PagedKVCache
from scheduler import Scheduler, Request


class InferenceEngine:
    """
    最小推理引擎

    用法:
        engine = InferenceEngine(model, ...)
        engine.add_request(Request(...))
        engine.run()  # 跑到所有请求完成
    """

    def __init__(
        self,
        model: TinyLLM,
        num_blocks: int = 100,
        block_size: int = 4,
        max_batch_size: int = 4,
        max_total_tokens: int = 400,
        device: str = "cuda",
    ):
        self.model = model
        self.device = device
        self.block_size = block_size

        # 推断模型配置
        num_layers = model.num_layers
        # 从第一个 attention 层拿 num_heads 和 head_dim
        num_heads = model.layers[0].attn.num_heads
        head_dim = model.layers[0].attn.head_dim

        # 初始化分页 KV Cache
        self.kv_cache = PagedKVCache(
            num_blocks=num_blocks,
            block_size=block_size,
            num_layers=num_layers,
            num_heads=num_heads,
            head_dim=head_dim,
            dtype=torch.float32,
            device=device,
        )

        # 初始化调度器
        self.scheduler = Scheduler(
            max_batch_size=max_batch_size,
            max_total_tokens=max_total_tokens,
        )

        # 每个 sequence 的 KV cache 指针 (按 batch_idx 索引)
        # 真实系统这个 mapping 更复杂
        self.batch_idx_map = {}  # request_id -> batch_idx

    def add_request(self, req: Request) -> None:
        """外部: 加入新请求"""
        self.scheduler.add_request(req)

    def _do_prefill(self, requests: List[Request]) -> None:
        """
        执行 prefill 阶段: 处理每个请求的完整 prompt

        关键点:
            - 每个 prefill 请求独立处理 (简化版,不 batch prefill)
            - 真实 vLLM 会 batch 多个 prefill 请求一起算
            - prefill 完成后,KV Cache 已写入,可以开始 decode
        """
        for req in requests:
            # 1. 给这个请求分配 KV Cache 空间
            prompt_len = len(req.prompt_tokens)
            # 找一个空闲的 batch_idx (简化: 用 request_id 取模)
            batch_idx = req.request_id % 4  # 假设 batch 上限 4

            # 确保有足够的物理块
            self.kv_cache.ensure_blocks_for_seq(batch_idx, prompt_len)

            # 2. 准备输入: prompt 的 token ids
            input_ids = torch.tensor(
                [req.prompt_tokens], device=self.device, dtype=torch.long,
            )  # [1, prompt_len]

            # 3. 调用模型 forward (无 kv_cache,因为是第一次)
            with torch.no_grad():
                logits, new_kv_caches = self.model(input_ids, kv_caches=None)

            # 4. 把 K, V 写入分页 KV Cache
            for layer_idx, (k, v) in enumerate(new_kv_caches):
                # k shape: [1, num_heads, prompt_len, head_dim]
                # 转成 [prompt_len, num_heads, head_dim]
                k = k.squeeze(0).transpose(0, 1)  # [prompt_len, num_heads, head_dim]
                v = v.squeeze(0).transpose(0, 1)
                positions = list(range(prompt_len))
                self.kv_cache.write_kv(batch_idx, layer_idx, positions, k, v)

            # 5. 取最后一个位置的 logits,采样第一个输出 token
            last_logits = logits[0, -1, :]  # [vocab_size]
            next_token = torch.argmax(last_logits).item()

            # 6. 把这个 token 加到请求的 output 里
            req.output_tokens.append(next_token)
            req.current_length = prompt_len + 1

            # 记录 batch_idx
            self.batch_idx_map[req.request_id] = batch_idx

            # 检查是否完成 (生成 max_output_tokens 个或 EOS)
            if len(req.output_tokens) >= req.max_output_tokens:
                self.scheduler.mark_request_finished(req.request_id)

            print(f"  [Prefill] req={req.request_id} prompt_len={prompt_len} "
                  f"first_token={next_token}")

    def _do_decode(self, requests: List[Request]) -> None:
        """
        执行 decode 阶段: 每个请求生成 1 个新 token

        关键点:
            - 从 KV Cache 读出之前的 K, V
            - 用模型 forward 计算新 token 的 K, V, append 到 cache
            - 用完整 K, V 算 attention 得到下一个 token
        """
        for req in requests:
            batch_idx = self.batch_idx_map[req.request_id]
            current_len = req.current_length

            # 1. 准备输入: 上一步生成的 token
            last_token = req.output_tokens[-1]
            input_ids = torch.tensor(
                [[last_token]], device=self.device, dtype=torch.long,
            )  # [1, 1]

            # 2. 从分页 KV Cache 读出之前的 K, V (每层)
            past_kv_caches = []
            for layer_idx in range(self.model.num_layers):
                k, v = self.kv_cache.read_kv(batch_idx, layer_idx, current_len - 1)
                # reshape 成模型期望的形状: [1, num_heads, seq_len, head_dim]
                k = k.unsqueeze(0).transpose(1, 2)  # [1, num_heads, seq_len, head_dim]
                v = v.unsqueeze(0).transpose(1, 2)
                past_kv_caches.append((k, v))

            # 3. 调用模型 forward,传入 past kv cache
            with torch.no_grad():
                logits, new_kv_caches = self.model(input_ids, kv_caches=past_kv_caches)

            # 4. 把新的 K, V (1 个 token 的) 写入 KV Cache
            for layer_idx, (k, v) in enumerate(new_kv_caches):
                # k shape: [1, num_heads, 1, head_dim]
                # 转成 [1, num_heads, head_dim] (单个 token)
                k = k.squeeze(0).squeeze(1)  # [num_heads, head_dim]
                v = v.squeeze(0).squeeze(1)
                self.kv_cache.write_kv(
                    batch_idx, layer_idx, [current_len - 1], k, v,
                )

            # 5. 采样下一个 token
            last_logits = logits[0, -1, :]
            next_token = torch.argmax(last_logits).item()

            # 6. 更新请求状态
            req.output_tokens.append(next_token)
            req.current_length += 1

            if len(req.output_tokens) >= req.max_output_tokens:
                self.scheduler.mark_request_finished(req.request_id)

            print(f"  [Decode]  req={req.request_id} "
                  f"step={len(req.output_tokens)} token={next_token}")

    def run(self) -> None:
        """主循环: 跑到所有请求完成"""
        print("=" * 60)
        print("Inference Engine 开始运行")
        print(f"初始状态: {self.scheduler.stats()}")
        print("=" * 60)

        max_steps = 1000  # 安全阀,防止死循环
        step = 0

        while self.scheduler.has_pending_work() and step < max_steps:
            step += 1
            plan = self.scheduler.schedule()

            print(f"\n--- Step {step} | {self.scheduler.stats()} ---")

            if plan["to_prefill"]:
                # 这个 step 做 prefill
                self._do_prefill(plan["to_prefill"])
            elif plan["to_decode"]:
                # 这个 step 做 decode
                self._do_decode(plan["to_decode"])

            if plan["preempted"]:
                print(f"  [Preempt] {len(plan['preempted'])} 个请求被踢回 waiting")

        print("\n" + "=" * 60)
        print("Inference Engine 运行结束")
        print("=" * 60)
