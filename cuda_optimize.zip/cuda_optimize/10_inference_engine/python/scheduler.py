﻿"""
scheduler.py — Continuous Batching 调度器

实现 [07_continuous_batching.md](../docs/07_continuous_batching.md) 的核心调度逻辑:
- 维护两个队列: waiting (待 prefill) 和 running (正在 decode)
- 每个 step 决定:
    1. 哪些 waiting 请求可以升级到 running
    2. 哪些 running 请求完成了,移出
    3. 是否需要 preempt (KV Cache 不够时把请求踢回 waiting)

和 vLLM 的 scheduler 区别:
- vLLM 用优先级 + 复杂策略
- 这里用简单的 FIFO + 容量检查
- vLLM 支持 prefix caching, lookahead scheduling
- 这里只实现基础版本

学习目标:
    1. 理解 waiting/running 两个队列的角色
    2. 理解每个 step 的调度决策
    3. 理解 preemption 的触发条件

对应 vLLM 的:
    vllm/core/scheduler.py
"""

from dataclasses import dataclass, field
from typing import List, Optional
import torch


@dataclass
class Request:
    """
    一个推理请求的状态

    字段:
        request_id: 唯一 ID
        prompt_tokens: 输入的 token ids (prompt)
        max_output_tokens: 最多生成多少 token
        output_tokens: 已经生成的 token
        current_length: prompt + output 的总长度 (KV Cache 长度)
        is_finished: 是否已完成 (达到 max_output_tokens 或 EOS)
    """
    request_id: int
    prompt_tokens: List[int]
    max_output_tokens: int
    output_tokens: List[int] = field(default_factory=list)
    current_length: int = 0
    is_finished: bool = False

    def total_length(self) -> int:
        """prompt + 已生成的 token 总数"""
        return len(self.prompt_tokens) + len(self.output_tokens)


class Scheduler:
    """
    Continuous Batching 调度器

    核心方法:
        add_request(req): 把新请求加入 waiting 队列
        schedule(): 返回这个 step 要 prefill 哪些,decode 哪些
        update_finished(): 标记完成的请求,从 running 移走
    """

    def __init__(
        self,
        max_batch_size: int = 4,
        max_total_tokens: int = 1024,  # KV Cache 能容纳的总 token 数
    ):
        self.max_batch_size = max_batch_size
        self.max_total_tokens = max_total_tokens

        # 两个核心队列
        self.waiting: List[Request] = []   # 等 prefill 的请求
        self.running: List[Request] = []   # 正在 decode 的请求

        # 统计
        self.step_count = 0

    def add_request(self, req: Request) -> None:
        """外部调用: 来新请求了"""
        self.waiting.append(req)

    def schedule(self) -> dict:
        """
        做一次调度决策,返回这个 step 的执行计划

        返回:
            {
                "to_prefill": [Request, ...],  # 这个 step 要 prefill 的请求
                "to_decode": [Request, ...],   # 这个 step 要 decode 的请求
                "preempted": [Request, ...],   # 被踢回 waiting 的请求
            }

        调度逻辑 (简化版):
            1. 如果 running 队列空,从 waiting 取请求做 prefill (batch 一起)
            2. 如果 running 非空,优先 decode 已有请求
            3. 如果 KV Cache 不够,preempt 最后进来的请求
        """
        self.step_count += 1

        to_prefill: List[Request] = []
        to_decode: List[Request] = list(self.running)
        preempted: List[Request] = []

        # 1. 计算当前 KV Cache 占用
        current_usage = sum(r.total_length() for r in self.running)

        # 2. 尝试从 waiting 里加新请求做 prefill
        # 条件:
        #   - running 数 < max_batch_size
        #   - waiting 非空
        #   - KV Cache 还有空间
        while (
            self.waiting
            and len(self.running) + len(to_prefill) < self.max_batch_size
        ):
            req = self.waiting[0]
            prompt_len = len(req.prompt_tokens)

            # 检查 KV Cache 是否够
            # prefill 后请求会占用 prompt_len 个 token
            if current_usage + prompt_len > self.max_total_tokens:
                # 不够,先看能否 preempt 现有请求腾出空间
                if self.running:
                    # 简单策略: 把最后一个 running 请求踢回 waiting
                    victim = self.running.pop()
                    preempted.append(victim)
                    current_usage -= victim.total_length()
                    # 注意: 真实系统要释放 victim 的 KV Cache,这里只是逻辑上移走
                    continue
                else:
                    # 没有可以 preempt 的,只能等
                    break

            # 加入 prefill 计划
            to_prefill.append(req)
            self.waiting.pop(0)
            current_usage += prompt_len

        # 3. 决定这个 step 干什么
        # 优先级:
        #   - 如果有 prefill,这个 step 就做 prefill (一次只做 prefill,不混合)
        #   - 否则做 decode
        # 真实 vLLM 支持混合 prefill + decode (chunked prefill),更复杂

        if to_prefill:
            # 把 prefill 的请求加入 running
            for req in to_prefill:
                req.current_length = len(req.prompt_tokens)
                self.running.append(req)
            return {
                "to_prefill": to_prefill,
                "to_decode": [],
                "preempted": preempted,
            }
        else:
            # 这个 step 做 decode
            return {
                "to_prefill": [],
                "to_decode": to_decode,
                "preempted": preempted,
            }

    def mark_request_finished(self, request_id: int) -> None:
        """标记请求完成,从 running 移走"""
        for i, req in enumerate(self.running):
            if req.request_id == request_id:
                req.is_finished = True
                self.running.pop(i)
                break

    def has_pending_work(self) -> bool:
        """是否还有未完成的工作"""
        return len(self.waiting) > 0 or len(self.running) > 0

    def stats(self) -> dict:
        return {
            "waiting": len(self.waiting),
            "running": len(self.running),
            "step": self.step_count,
        }


# 测试
if __name__ == "__main__":
    sched = Scheduler(max_batch_size=2, max_total_tokens=20)

    # 加 3 个请求
    req1 = Request(request_id=1, prompt_tokens=[1]*5, max_output_tokens=3)
    req2 = Request(request_id=2, prompt_tokens=[2]*5, max_output_tokens=3)
    req3 = Request(request_id=3, prompt_tokens=[3]*5, max_output_tokens=3)

    sched.add_request(req1)
    sched.add_request(req2)
    sched.add_request(req3)

    print(f"初始: {sched.stats()}")  # waiting=3, running=0

    # 第 1 step: 应该 prefill req1 和 req2
    plan = sched.schedule()
    print(f"Step 1: prefill={len(plan['to_prefill'])}, decode={len(plan['to_decode'])}")
    # 预期: prefill=2, decode=0

    # 模拟 req1 完成
    sched.mark_request_finished(1)
    print(f"After req1 done: {sched.stats()}")  # waiting=1, running=1

    # 第 2 step: 应该 prefill req3
    plan = sched.schedule()
    print(f"Step 2: prefill={len(plan['to_prefill'])}, decode={len(plan['to_decode'])}")
    # 预期: prefill=1 (req3), decode=0 (因为 to_prefill 非空)

    # 第 3 step: 应该 decode 剩下的
    plan = sched.schedule()
    print(f"Step 3: prefill={len(plan['to_prefill'])}, decode={len(plan['to_decode'])}")
    # 预期: prefill=0, decode=2

    print("\nScheduler 测试通过!")
