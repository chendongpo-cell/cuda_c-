"""
INT8 GEMM 量化模拟器
======================
本文件实现了 INT8 矩阵乘法（GEMM）的完整量化-计算-反量化流程的模拟。

核心流程：
  1. 量化：FP32 权重 -> INT8（per-tensor 或 per-channel 量化）
  2. 模拟 INT8 矩阵乘法：使用 INT8 值做矩阵乘法（累积到 INT32）
  3. 反量化：INT32 结果 -> FP32
  4. 精度对比：与 FP32 参考实现对比

为什么需要量化 GEMM？
  - INT8 矩阵乘法比 FP32 快 4x+（利用 Tensor Core）
  - 存储减半：INT8 只需 1 byte vs FP32 的 4 bytes
  - 代价是精度损失

本模拟器在 CPU 上执行，便于理解原理。
实际 GPU 上的 INT8 GEMM 使用专用的 Tensor Core 指令（如 cuBLAS IMMA）。
"""

import numpy as np
import time


# ==============================================================================
# 量化函数
# ==============================================================================

def quantize_symmetric_per_tensor(x_fp: np.ndarray) -> tuple:
    """
    对称 per-tensor 量化：整个张量共享一个 scale。

    原理：
      x_int = clamp(round(x_fp / scale), -127, 127)
      其中 scale = max(|x_fp|) / 127

    参数:
        x_fp: 输入浮点张量，任意形状

    返回:
        x_int: INT8 量化后的张量，形状同 x_fp
        scale: 标量，量化因子
    """
    # 计算 scale：整个张量的最大值除以 127（INT8 正数范围）
    # 注意：对称量化不使用 -128，只使用 [-127, 127]
    abs_max = np.max(np.abs(x_fp))

    # 防止除零：如果所有值都是 0，scale 设为 1.0
    if abs_max == 0:
        return np.zeros_like(x_fp, dtype=np.int8), 1.0

    # 计算量化 scale
    scale = abs_max / 127.0

    # 量化：缩放 -> 四舍五入 -> 裁剪到 [-128, 127]
    x_int = np.round(x_fp / scale)
    x_int = np.clip(x_int, -128, 127).astype(np.int8)

    return x_int, scale


def quantize_symmetric_per_channel(x_fp: np.ndarray, axis: int = 0) -> tuple:
    """
    对称 per-channel 量化：每个通道（行或列）有独立的 scale。

    在权重量化中，通常对输出通道（axis=0）做 per-channel 量化，
    因为不同输出通道的权重分布可能差异很大。

    参数:
        x_fp: 输入浮点张量，通常为 2D [out_dim, in_dim]
        axis: 沿哪个轴（维度）做 per-channel 量化

    返回:
        x_int: INT8 量化后的张量
        scales: scale 数组，形状为 x_fp.shape[axis]
    """
    # 沿指定轴计算每个 channel 的 abs max
    # 例如，对 [out_dim, in_dim] 沿 axis=0 得到 [out_dim] 个 scale
    abs_max = np.max(np.abs(x_fp), axis=1 - axis)

    # 防止除零
    abs_max = np.where(abs_max == 0, 1.0, abs_max)

    # 每个 channel 独立的 scale
    scales = abs_max / 127.0

    # 量化：broadcast scales 到 x_fp 的形状
    # np.newaxis 用于对齐维度，例如 scales [out_dim] -> [out_dim, 1]
    expand_shape = [-1] * x_fp.ndim
    expand_shape[axis] = 1  # 只在 axis 维度保留，其他维度为 1
    scales_expanded = scales.reshape(-1 if axis == 0 else tuple(expand_shape))
    # 更通用的做法：
    scales_reshaped = scales.reshape([-1 if i == axis else 1 for i in range(x_fp.ndim)])

    x_int = np.round(x_fp / scales_reshaped)
    x_int = np.clip(x_int, -128, 127).astype(np.int8)

    return x_int, scales


def dequantize(x_int: np.ndarray, scale) -> np.ndarray:
    """
    反量化：将 INT8 值恢复为浮点值。

    x_fp = x_int * scale

    参数:
        x_int: INT8 张量
        scale: 标量（per-tensor）或数组（per-channel）

    返回:
        x_fp: 反量化后的浮点张量
    """
    return x_int.astype(np.float32) * scale


# ==============================================================================
# INT8 GEMM 模拟
# ==============================================================================

def int8_gemm_simulate(A_fp: np.ndarray, B_fp: np.ndarray,
                       quantize_A: bool = True, quantize_B: bool = True,
                       per_channel_A: bool = False, per_channel_B: bool = False) -> dict:
    """
    INT8 GEMM 完整流程模拟。

    C_fp32 = A_fp @ B_fp
    量化为：
    C_int32 = A_int8 @ B_int8 -> 累积到 INT32
    C_fp32_approx = C_int32 * (scale_A * scale_B)

    参数:
        A_fp: 输入矩阵 A，形状 [M, K]
        B_fp: 输入矩阵 B，形状 [K, N]
        quantize_A: 是否量化 A（如果 False，A 保持 FP32）
        quantize_B: 是否量化 B
        per_channel_A: 是否对 A 做 per-channel 量化
        per_channel_B: 是否对 B 做 per-channel 量化

    返回:
        dict 包含所有中间结果和最终输出
    """
    M, K = A_fp.shape
    K2, N = B_fp.shape
    assert K == K2, f"矩阵形状不匹配: A@B, A shape {A_fp.shape}, B shape {B_fp.shape}"

    # --------------------------------------------------------------------------
    # 1. FP32 参考计算
    # --------------------------------------------------------------------------
    # 使用 FP32 计算标准矩阵乘法，作为精度对比的 ground truth
    C_ref = A_fp @ B_fp

    # --------------------------------------------------------------------------
    # 2. 量化输入矩阵
    # --------------------------------------------------------------------------
    if quantize_A:
        if per_channel_A:
            # Per-channel 量化 A：沿 K 维度（输入通道）做量化
            # 注意：对 A 的 per-channel 量化沿 axis=1（每个输入通道）
            A_int8, scale_A = quantize_symmetric_per_channel(A_fp, axis=1)
        else:
            A_int8, scale_A = quantize_symmetric_per_tensor(A_fp)
        A_q = A_int8  # 量化后的 A
    else:
        A_q = A_fp
        scale_A = 1.0

    if quantize_B:
        if per_channel_B:
            # Per-channel 量化 B：沿 axis=0（每个输出通道/输入通道）
            B_int8, scale_B = quantize_symmetric_per_channel(B_fp, axis=0)
        else:
            B_int8, scale_B = quantize_symmetric_per_tensor(B_fp)
        B_q = B_int8
    else:
        B_q = B_fp
        scale_B = 1.0

    # --------------------------------------------------------------------------
    # 3. INT8 矩阵乘法（模拟）
    # --------------------------------------------------------------------------
    # 在 GPU 上，Tensor Core 执行 INT8 矩阵乘法时：
    #   - 从 1 个 32-bit 寄存器加载 4 个 INT8 值
    #   - 使用 IMMA (Integer Matrix Multiply-Accumulate) 指令
    #   - 累积到 INT32
    # 这里用 numpy 模拟这个行为：
    #   A_int8 [M, K] @ B_int8 [K, N] -> C_int32 [M, N]
    #
    # 注意：@ 操作符会自动将 INT8 提升为 INT64（在 numpy 中），
    # 但我们模拟 INT32 累积器的行为
    C_int = A_q.astype(np.int32) @ B_q.astype(np.int32)

    # 理论上结果是对 INT8 乘积累积到 INT32
    # 最大值：127 * 127 * K（K 是内维），对于 K < 65536 不会溢出 INT32
    assert K <= 65536, "K 太大，INT32 可能溢出"

    # --------------------------------------------------------------------------
    # 4. 反量化
    # --------------------------------------------------------------------------
    # C_fp_approx = C_int * (scale_A * scale_B)
    # 理论推导：
    #   A ≈ A_int8 * scale_A,  B ≈ B_int8 * scale_B
    #   A @ B ≈ (A_int8 * scale_A) @ (B_int8 * scale_B)
    #         = scale_A * scale_B * (A_int8 @ B_int8)
    #
    # 注意：如果 A 或 B 用了 per-channel 量化，scale 是向量而不是标量
    # 此时反量化更复杂：C_approx[i,j] = sum_k (A_int8[i,k]*scale_A[k]) * (B_int8[k,j]*scale_B[k,...])
    #
    # 简化的 per-tensor 反量化：
    if np.isscalar(scale_A) and np.isscalar(scale_B):
        # per-tensor: 简单乘法
        C_approx = C_int.astype(np.float32) * (scale_A * scale_B)
    else:
        # per-channel: 需要逐元素反量化
        # 这种情况需要更精确的计算
        # 对 A 做 per-channel: A_fp[i,:] = A_int8[i,:] * scale_A[:]
        # 对 B 做 per-channel: B_fp[:,j] = B_int8[:,j] * scale_B[:]
        # C_approx = (A_q * scale_A) @ (B_q * scale_B)
        A_deq = A_q.astype(np.float32) * (scale_A if not np.isscalar(scale_A) else 1.0)
        B_deq = B_q.astype(np.float32) * (scale_B if not np.isscalar(scale_B) else 1.0)
        C_approx = A_deq @ B_deq

    # --------------------------------------------------------------------------
    # 5. 误差分析
    # --------------------------------------------------------------------------
    # 计算绝对误差和相对误差
    abs_error = np.abs(C_approx - C_ref)
    rel_error = abs_error / (np.abs(C_ref) + 1e-10)

    # 统计误差指标
    results = {
        "C_ref": C_ref,           # FP32 参考结果
        "C_approx": C_approx,     # INT8 量化模拟结果
        "abs_error_max": np.max(abs_error),
        "abs_error_mean": np.mean(abs_error),
        "rel_error_max": np.max(rel_error),
        "rel_error_mean": np.mean(rel_error),
        "cosine_sim": np.dot(C_ref.flatten(), C_approx.flatten()) /
                      (np.linalg.norm(C_ref) * np.linalg.norm(C_approx) + 1e-10),
    }

    return results


# ==============================================================================
# 测试函数
# ==============================================================================

def run_experiment(name: str, M: int, K: int, N: int,
                   per_channel_A: bool = False, per_channel_B: bool = False,
                   weight_distribution: str = "uniform"):
    """
    运行一次 INT8 GEMM 实验并打印结果。

    参数:
        name: 实验名称
        M, K, N: 矩阵维度
        per_channel_A, per_channel_B: 是否使用 per-channel 量化
        weight_distribution: 权重分布类型 ("uniform", "normal", "outlier")
    """
    print(f"\n{'=' * 60}")
    print(f"实验: {name}")
    print(f"矩阵形状: A [{M}x{K}], B [{K}x{N}]")
    print(f"量化方式: A per_channel={per_channel_A}, B per_channel={per_channel_B}")
    print(f"权重分布: {weight_distribution}")
    print(f"{'=' * 60}")

    # 根据分布类型生成数据
    np.random.seed(42)
    if weight_distribution == "uniform":
        # 均匀分布 [-1, 1]
        A = np.random.uniform(-1.0, 1.0, (M, K)).astype(np.float32)
        B = np.random.uniform(-1.0, 1.0, (K, N)).astype(np.float32)
    elif weight_distribution == "normal":
        # 正态分布
        A = np.random.normal(0, 0.5, (M, K)).astype(np.float32)
        B = np.random.normal(0, 0.5, (K, N)).astype(np.float32)
    elif weight_distribution == "outlier":
        # 包含 outlier 的分布：大部分值小，少数值很大
        A = np.random.normal(0, 0.1, (M, K)).astype(np.float32)
        # 随机注入 outlier
        outlier_idx = np.random.choice(K, max(1, K // 20), replace=False)
        A[:, outlier_idx] = np.random.uniform(5.0, 10.0, (M, len(outlier_idx)))
        B = np.random.normal(0, 0.1, (K, N)).astype(np.float32)
        B[outlier_idx, :] = np.random.uniform(5.0, 10.0, (len(outlier_idx), N))

    # 执行 INT8 GEMM
    results = int8_gemm_simulate(
        A, B,
        quantize_A=True, quantize_B=True,
        per_channel_A=per_channel_A, per_channel_B=per_channel_B,
    )

    # 打印结果
    print(f"最大绝对误差: {results['abs_error_max']:.6f}")
    print(f"平均绝对误差: {results['abs_error_mean']:.6f}")
    print(f"最大相对误差: {results['rel_error_max']:.6f}")
    print(f"平均相对误差: {results['rel_error_mean']:.6f}")
    print(f"余弦相似度:  {results['cosine_sim']:.6f}")

    # 判断精度是否可接受
    if results['cosine_sim'] > 0.99:
        print(">> 精度良好 (余弦相似度 > 0.99)")
    elif results['cosine_sim'] > 0.95:
        print(">> 精度可接受 (余弦相似度 > 0.95)")
    else:
        print(">> 精度损失较大 (余弦相似度 < 0.95)")


# ==============================================================================
# 精度-速度对比
# ==============================================================================

def benchmark_gemm_sizes():
    """
    对不同大小的矩阵执行 INT8 和 FP32 GEMM 的模拟速度对比。
    """
    print("\n" + "=" * 60)
    print("INT8 vs FP32 矩阵乘法速度对比（CPU 模拟）")
    print("=" * 60)
    print(f"{'MxKxN':>15} {'FP32 (ms)':>12} {'INT8 (ms)':>12} {'加速比':>8} {'余弦相似度':>12}")
    print("-" * 60)

    sizes = [
        (256, 256, 256),
        (512, 512, 512),
        (1024, 1024, 1024),
        (512, 1024, 512),
        (1024, 2048, 1024),
    ]

    for M, K, N in sizes:
        # 生成测试数据
        np.random.seed(42)
        A = np.random.uniform(-1.0, 1.0, (M, K)).astype(np.float32)
        B = np.random.uniform(-1.0, 1.0, (K, N)).astype(np.float32)

        # FP32 参考
        t0 = time.time()
        C_ref = A @ B
        t_fp32 = time.time() - t0

        # INT8 量化模拟
        t0 = time.time()
        results = int8_gemm_simulate(A, B, quantize_A=True, quantize_B=True,
                                      per_channel_A=False, per_channel_B=False)
        t_int8 = time.time() - t0

        speedup = t_fp32 / t_int8
        print(f"{M}x{K}x{N:>4}  {t_fp32*1000:>10.3f}  {t_int8*1000:>10.3f}  {speedup:>7.2f}x  {results['cosine_sim']:>10.6f}")


# ==============================================================================
# 量化误差分析：per-tensor vs per-channel 对比
# ==============================================================================

def compare_quantization_strategies():
    """
    对比 per-tensor 和 per-channel 量化在含有 outlier 的矩阵上的精度差异。
    展示 per-channel 量化的优势。
    """
    print("\n" + "=" * 60)
    print("Per-Tensor vs Per-Channel 量化精度对比")
    print("矩阵含有 outlier 通道")
    print("=" * 60)

    # 制造一个含有 outlier 的矩阵
    # 清洗一个通道的值特别大，模拟实际场景中某些通道的权重特别大
    np.random.seed(42)
    M, K, N = 1024, 1024, 1024

    # 基础权重
    A = np.random.normal(0, 0.1, (M, K)).astype(np.float32)
    B = np.random.normal(0, 0.1, (K, N)).astype(np.float32)

    # 给 A 的一个通道注入 outlier（模拟某些输入通道的重要性差异）
    outlier_channel = 50
    A[:, outlier_channel] = np.random.uniform(5.0, 10.0, M).astype(np.float32)

    # 给 B 的一个通道注入 outlier
    B[outlier_channel, :] = np.random.uniform(5.0, 10.0, N).astype(np.float32)

    # 策略 1: per-tensor 量化（整个矩阵共享一个 scale）
    print("\n[策略 1] Per-Tensor 量化（整个矩阵共享 scale）:")
    r1 = int8_gemm_simulate(A, B, per_channel_A=False, per_channel_B=False)
    print(f"  最大相对误差: {r1['rel_error_max']:.6f}")
    print(f"  余弦相似度:   {r1['cosine_sim']:.6f}")

    # 策略 2: per-channel 量化 A（A 的每个列有独立 scale）
    print("\n[策略 2] Per-Channel 量化 A:")
    r2 = int8_gemm_simulate(A, B, per_channel_A=True, per_channel_B=False)
    print(f"  最大相对误差: {r2['rel_error_max']:.6f}")
    print(f"  余弦相似度:   {r2['cosine_sim']:.6f}")

    # 策略 3: per-channel 量化 B（B 的每个行有独立 scale）
    print("\n[策略 3] Per-Channel 量化 B:")
    r3 = int8_gemm_simulate(A, B, per_channel_A=False, per_channel_B=True)
    print(f"  最大相对误差: {r3['rel_error_max']:.6f}")
    print(f"  余弦相似度:   {r3['cosine_sim']:.6f}")

    # 策略 4: 双 per-channel
    print("\n[策略 4] Per-Channel 量化 A 和 B:")
    r4 = int8_gemm_simulate(A, B, per_channel_A=True, per_channel_B=True)
    print(f"  最大相对误差: {r4['rel_error_max']:.6f}")
    print(f"  余弦相似度:   {r4['cosine_sim']:.6f}")


# ==============================================================================
# 主函数
# ==============================================================================

if __name__ == "__main__":
    print("INT8 GEMM 量化模拟器")
    print("=" * 60)

    # 1. 基础测试：均匀分布矩阵
    run_experiment("均匀分布矩阵", M=256, K=256, N=256,
                   per_channel_A=False, per_channel_B=False,
                   weight_distribution="uniform")

    # 2. 正态分布矩阵
    run_experiment("正态分布矩阵", M=256, K=256, N=256,
                   per_channel_A=False, per_channel_B=False,
                   weight_distribution="normal")

    # 3. 含 outlier 的矩阵
    run_experiment("含 Outlier 矩阵 (per-tensor 量化)",
                   M=256, K=256, N=256,
                   per_channel_A=False, per_channel_B=False,
                   weight_distribution="outlier")

    # 4. 含 outlier 的矩阵 + per-channel 量化
    run_experiment("含 Outlier 矩阵 (per-channel 量化)",
                   M=256, K=256, N=256,
                   per_channel_A=True, per_channel_B=True,
                   weight_distribution="outlier")

    # 5. 不同量化策略对比
    compare_quantization_strategies()

    # 6. 速度对比
    benchmark_gemm_sizes()

    print("\n所有测试完成！")
