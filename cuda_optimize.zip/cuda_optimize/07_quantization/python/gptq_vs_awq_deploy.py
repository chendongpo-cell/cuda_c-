﻿"""
gptq_vs_awq_deploy.py — GPTQ vs AWQ 对比部署脚本

配合 [docs/24_gptq_vs_awq.md](../docs/24_gptq_vs_awq.md) 使用。

这个脚本同时测两个量化方案的推理性能, 用于对比:
    1. GPTQ 模型 (端口 8000)
    2. AWQ 模型 (端口 8001)

使用前需要先启动两个 vLLM 服务:

# 终端 1: 启动 GPTQ 服务
vllm serve TheBloke/Llama-2-7B-Chat-GPTQ \\
    --quantization gptq --port 8000

# 终端 2: 启动 AWQ 服务
vllm serve TheBloke/Llama-2-7B-Chat-AWQ \\
    --quantization awq --port 8001

# 终端 3: 跑对比
python gptq_vs_awq_deploy.py

学习目标:
    1. 知道 GPTQ 和 AWQ 怎么部署
    2. 量化方案对性能的影响
    3. 怎么写对比 benchmark
"""

import asyncio
import time
import statistics
import json
import argparse
from typing import List, Dict, Optional

try:
    import httpx
except ImportError:
    raise ImportError("需要安装 httpx: pip install httpx")


# ============================================================
# 配置
# ============================================================

# 两个服务的配置
DEFAULT_GPTQ_URL = "http://localhost:8000/v1"
DEFAULT_AWQ_URL = "http://localhost:8001/v1"

# 推理测试 prompt (用相同的 prompts 保证公平)
TEST_PROMPTS = [
    "Explain the concept of gradient descent in machine learning.",
    "Write a Python function to implement quicksort.",
    "What are the main causes of climate change?",
    "Describe the plot of Romeo and Juliet.",
    "How does a transformer neural network work?",
    "Write a short story about a robot learning to paint.",
    "Explain the difference between TCP and UDP.",
    "What is the meaning of life according to different philosophies?",
    "Describe how a vaccine works.",
    "Write a SQL query to find the top 10 customers by total sales.",
]

# 正确性测试 (用简单 fact 验证)
CORRECTNESS_CASES = [
    {"prompt": "1 + 1 = ", "expected": "2"},
    {"prompt": "The capital of France is ", "expected": "Paris"},
    {"prompt": "def hello_world():\n    ", "expected": "print"},
    {"prompt": "What is 5 * 6? ", "expected": "30"},
    {"prompt": "Translate 'hello' to Spanish: ", "expected": "hola"},
]


# ============================================================
# 推理函数
# ============================================================

async def send_request(
    client: httpx.AsyncClient,
    base_url: str,
    model: str,
    prompt: str,
    max_tokens: int = 128,
    temperature: float = 0.7,
    stream: bool = True,
) -> Dict:
    """
    发送一个推理请求, 返回统计

    返回:
        {
            "ttft": 首 token 延迟 (秒),
            "total_time": 总耗时,
            "output_tokens": 输出 token 数,
            "tpot": 单 token 延迟,
            "output": 生成的文本,
            "error": 错误信息 (如果有)
        }
    """
    start = time.time()
    ttft: Optional[float] = None
    output_tokens = 0
    output_text = ""
    error = None

    try:
        if stream:
            async with client.stream(
                "POST",
                f"{base_url}/completions",
                json={
                    "model": model,
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                    "stream": True,
                    "stream_options": {"include_usage": True},
                },
                timeout=120.0,
            ) as response:
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                        if "choices" in chunk and chunk["choices"]:
                            delta = chunk["choices"][0].get("text", "")
                            if delta:
                                if ttft is None:
                                    ttft = time.time() - start
                                output_text += delta
                                output_tokens += 1
                        if "usage" in chunk and chunk["usage"]:
                            output_tokens = chunk["usage"].get(
                                "completion_tokens", output_tokens
                            )
                    except json.JSONDecodeError:
                        continue
        else:
            response = await client.post(
                f"{base_url}/completions",
                json={
                    "model": model,
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                },
                timeout=120.0,
            )
            response.raise_for_status()
            data = response.json()
            output_text = data["choices"][0]["text"]
            output_tokens = data["usage"]["completion_tokens"]
    except Exception as e:
        error = str(e)

    total_time = time.time() - start
    return {
        "ttft": ttft or 0,
        "total_time": total_time,
        "output_tokens": output_tokens,
        "tpot": (
            (total_time - (ttft or 0)) / max(output_tokens - 1, 1)
            if output_tokens > 1 else 0
        ),
        "output": output_text,
        "error": error,
    }


# ============================================================
# 单服务 benchmark
# ============================================================

async def benchmark_service(
    base_url: str,
    model: str,
    label: str,
    num_concurrent: int = 20,
) -> Dict:
    """
    对一个服务跑完整 benchmark

    返回:
        {
            "label": "GPTQ" / "AWQ",
            "correctness": [...],
            "latency": {ttft, tpot},
            "throughput": {tokens_per_sec, requests_per_sec},
        }
    """
    print(f"\n{'=' * 60}")
    print(f"Benchmark: {label}")
    print(f"URL: {base_url}")
    print(f"Model: {model}")
    print(f"{'=' * 60}")

    async with httpx.AsyncClient() as client:
        # 检查服务可达
        try:
            r = await client.get(f"{base_url}/models", timeout=5.0)
            r.raise_for_status()
        except Exception as e:
            print(f"✗ 无法连接 {label} 服务: {e}")
            return {"label": label, "error": str(e)}

        # ===== 1. 正确性测试 =====
        print(f"\n--- {label} 正确性测试 ---")
        correctness = []
        for case in CORRECTNESS_CASES:
            r = await send_request(
                client, base_url, model,
                prompt=case["prompt"],
                max_tokens=10,
                temperature=0.0,
                stream=False,
            )
            if r["error"]:
                correctness.append({"case": case, "ok": False, "err": r["error"]})
                continue
            ok = case["expected"].lower() in r["output"].lower()
            correctness.append({
                "case": case,
                "ok": ok,
                "got": r["output"][:50],
            })
            status = "✓" if ok else "✗"
            print(f"  {status} Expected: {case['expected']!r}, Got: {r['output'][:30]!r}")

        # ===== 2. 延迟测试 (单请求) =====
        print(f"\n--- {label} 延迟测试 (10 单请求) ---")
        latencies = []
        for _ in range(10):
            r = await send_request(
                client, base_url, model,
                prompt=TEST_PROMPTS[0],
                max_tokens=100,
                temperature=0.7,
                stream=True,
            )
            if not r["error"]:
                latencies.append(r)

        if latencies:
            ttfts = [r["ttft"] for r in latencies]
            tpots = [r["tpot"] for r in latencies]
            print(f"  TTFT: mean={statistics.mean(ttfts)*1000:.1f}ms, "
                  f"P50={statistics.median(ttfts)*1000:.1f}ms")
            print(f"  TPOT: mean={statistics.mean(tpots)*1000:.1f}ms, "
                  f"P50={statistics.median(tpots)*1000:.1f}ms")

        # ===== 3. 吞吐测试 (并发) =====
        print(f"\n--- {label} 吞吐测试 ({num_concurrent} 并发) ---")
        prompts = (TEST_PROMPTS * (num_concurrent // len(TEST_PROMPTS) + 1))[:num_concurrent]

        start = time.time()
        results = await asyncio.gather(
            *[
                send_request(
                    client, base_url, model,
                    prompt=p,
                    max_tokens=128,
                    temperature=0.7,
                    stream=True,
                )
                for p in prompts
            ]
        )
        total_time = time.time() - start

        successful = [r for r in results if not r["error"]]
        total_tokens = sum(r["output_tokens"] for r in successful)

        if successful:
            tokens_per_sec = total_tokens / total_time
            req_per_sec = len(successful) / total_time
            print(f"  总时间: {total_time:.2f}s")
            print(f"  总 tokens: {total_tokens}")
            print(f"  吞吐: {tokens_per_sec:.1f} tok/s")
            print(f"  请求吞吐: {req_per_sec:.1f} req/s")

    return {
        "label": label,
        "correctness": correctness,
        "latency": {
            "ttft_mean": statistics.mean([r["ttft"] for r in latencies]) if latencies else 0,
            "tpot_mean": statistics.mean([r["tpot"] for r in latencies]) if latencies else 0,
        },
        "throughput": {
            "tokens_per_sec": tokens_per_sec if successful else 0,
            "req_per_sec": req_per_sec if successful else 0,
        },
    }


# ============================================================
# 对比报告
# ============================================================

def print_comparison(gptq_result: Dict, awq_result: Dict) -> None:
    """打印两个方案的对比报告"""
    print("\n" + "=" * 60)
    print("对比报告: GPTQ vs AWQ")
    print("=" * 60)

    if gptq_result.get("error") or awq_result.get("error"):
        print("⚠ 有服务不可用,无法完整对比")
        return

    # 正确性对比
    gptq_correct = sum(1 for c in gptq_result["correctness"] if c.get("ok"))
    awq_correct = sum(1 for c in awq_result["correctness"] if c.get("ok"))
    print(f"\n1. 正确性 (共 {len(CORRECTNESS_CASES)} 个 case):")
    print(f"   GPTQ: {gptq_correct}/{len(CORRECTNESS_CASES)}")
    print(f"   AWQ:  {awq_correct}/{len(CORRECTNESS_CASES)}")

    # 延迟对比
    print(f"\n2. 延迟 (mean):")
    gptq_ttft = gptq_result["latency"]["ttft_mean"] * 1000
    awq_ttft = awq_result["latency"]["ttft_mean"] * 1000
    gptq_tpot = gptq_result["latency"]["tpot_mean"] * 1000
    awq_tpot = awq_result["latency"]["tpot_mean"] * 1000
    print(f"   {'指标':<15} {'GPTQ':<15} {'AWQ':<15} {'AWQ 优势':<15}")
    print(f"   {'TTFT (ms)':<15} {gptq_ttft:<15.1f} {awq_ttft:<15.1f} "
          f"{(gptq_ttft - awq_ttft) / gptq_ttft * 100:+.1f}%")
    print(f"   {'TPOT (ms)':<15} {gptq_tpot:<15.1f} {awq_tpot:<15.1f} "
          f"{(gptq_tpot - awq_tpot) / gptq_tpot * 100:+.1f}%")

    # 吞吐对比
    print(f"\n3. 吞吐:")
    gptq_tps = gptq_result["throughput"]["tokens_per_sec"]
    awq_tps = awq_result["throughput"]["tokens_per_sec"]
    print(f"   {'指标':<15} {'GPTQ':<15} {'AWQ':<15} {'AWQ 优势':<15}")
    print(f"   {'tok/s':<15} {gptq_tps:<15.1f} {awq_tps:<15.1f} "
          f"{(awq_tps - gptq_tps) / gptq_tps * 100:+.1f}%")

    # 结论
    print(f"\n4. 结论:")
    if awq_tps > gptq_tps * 1.05:
        print("   AWQ 在吞吐上明显领先 (>5%)")
    elif gptq_tps > awq_tps * 1.05:
        print("   GPTQ 在吞吐上明显领先 (>5%)")
    else:
        print("   两者吞吐接近 (<5% 差异)")

    if abs(gptq_correct - awq_correct) >= 2:
        better = "AWQ" if awq_correct > gptq_correct else "GPTQ"
        print(f"   {better} 在正确性上明显领先")


# ============================================================
# 主入口
# ============================================================

async def main():
    parser = argparse.ArgumentParser(description="GPTQ vs AWQ 对比 benchmark")
    parser.add_argument("--gptq-url", default=DEFAULT_GPTQ_URL,
                        help=f"GPTQ 服务 URL (默认: {DEFAULT_GPTQ_URL})")
    parser.add_argument("--awq-url", default=DEFAULT_AWQ_URL,
                        help=f"AWQ 服务 URL (默认: {DEFAULT_AWQ_URL})")
    parser.add_argument("--gptq-model", default="TheBloke/Llama-2-7B-Chat-GPTQ",
                        help="GPTQ 模型名")
    parser.add_argument("--awq-model", default="TheBloke/Llama-2-7B-Chat-AWQ",
                        help="AWQ 模型名")
    parser.add_argument("--num-concurrent", type=int, default=20,
                        help="并发请求数 (默认: 20)")
    args = parser.parse_args()

    print("╔" + "═" * 60 + "╗")
    print("║" + " GPTQ vs AWQ 对比 Benchmark ".center(54) + "║")
    print("╚" + "═" * 60 + "╝")
    print(f"\nGPTQ 服务: {args.gptq_url}")
    print(f"AWQ  服务: {args.awq_url}")
    print(f"\n启动命令参考:")
    print(f"  vllm serve {args.gptq_model} --quantization gptq --port 8000")
    print(f"  vllm serve {args.awq_model} --quantization awq --port 8001")

    # 跑两个服务的 benchmark
    gptq_result = await benchmark_service(
        args.gptq_url, args.gptq_model, "GPTQ",
        num_concurrent=args.num_concurrent,
    )
    awq_result = await benchmark_service(
        args.awq_url, args.awq_model, "AWQ",
        num_concurrent=args.num_concurrent,
    )

    # 打印对比
    print_comparison(gptq_result, awq_result)

    print("\n" + "=" * 60)
    print("Benchmark 完成")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
