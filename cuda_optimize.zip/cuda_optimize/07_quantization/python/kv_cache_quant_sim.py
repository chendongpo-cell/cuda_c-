"""
KV Cache INT8 量化模拟器
=========================
模拟 LLM 推理中 KV Cache 的 INT8 量化存储与反量化读取流程。

场景:
  大模型推理时 KV Cache 占显存极大(如 LLaMA-70B 可达几十 GB)
  将 KV Cache 量化为 INT8 存储可节省约 2x 显存

核心流程:
  1. 写入: FP32 K/V → 计算 per-token scale → 量化到 INT8 → 存入 cache
  2. 读取: INT8 K/V × scale → 反量化回 FP32 → 用于 attention

量化粒度:
  - per-tensor: 整个 cache 一个 scale (最省内存, 精度最低)
  - per-token:  每个 token 一个 scale (推理最常用)
  - per-channel: 每个 channel 一个 scale

本模拟器在 CPU 上演示 per-token 量化, 方便理解原理。
对应 CUDA 版: 07_quantization/cuda/kv_cache_quant.cu
"""

import numpy as np


# ==============================================================================
# 量化 / 反量化函数
# ==============================================================================

def quantize_per_token(x: np.ndarray) -> tuple:
    """per-token 对称量化: FP32 → INT8

    Args:
        x: [num_tokens, head_dim] FP32 张量

    Returns:
        x_int8: [num_tokens, head_dim] INT8 张量
        scales: [num_tokens] 每个 token 的 scale
    """
    num_tokens = x.shape[0]
    scales = np.zeros(num_tokens, dtype=np.float32)
    x_int8 = np.zeros_like(x, dtype=np.int8)

    for i in range(num_tokens):
        token_data = x[i]
        abs_max = np.max(np.abs(token_data))
        abs_max = max(abs_max, 1e-8)  # 防止除零
        scales[i] = abs_max / 127.0
        x_int8[i] = np.clip(np.round(token_data / scales[i]), -127, 127).astype(np.int8)

    return x_int8, scales


def dequantize_per_token(x_int8: np.ndarray, scales: np.ndarray) -> np.ndarray:
    """per-token 反量化: INT8 → FP32"""
    num_tokens = x_int8.shape[0]
    x_fp = np.zeros_like(x_int8, dtype=np.float32)
    for i in range(num_tokens):
        x_fp[i] = x_int8[i].astype(np.float32) * scales[i]
    return x_fp


def quantize_per_tensor(x: np.ndarray) -> tuple:
    """per-tensor 对称量化: 整个 tensor 一个 scale"""
    abs_max = np.max(np.abs(x))
    abs_max = max(abs_max, 1e-8)
    scale = abs_max / 127.0
    x_int8 = np.clip(np.round(x / scale), -127, 127).astype(np.int8)
    return x_int8, scale


def dequantize_per_tensor(x_int8: np.ndarray, scale: float) -> np.ndarray:
    """per-tensor 反量化"""
    return x_int8.astype(np.float32) * scale


# ==============================================================================
# KV Cache 量化容器
# ==============================================================================

class QuantKVCache:
    """量化 KV Cache 模拟

    每个 cache 存储:
      - k_int8, v_int8: 量化后的 K/V 张量
      - k_scales, v_scales: 每个 token 的 scale

    对应 CUDA 版的 struct QuantKVCache
    """

    def __init__(self, max_seq: int, head_dim: int):
        self.max_seq = max_seq
        self.head_dim = head_dim
        self.k_int8 = np.zeros((max_seq, head_dim), dtype=np.int8)
        self.v_int8 = np.zeros((max_seq, head_dim), dtype=np.int8)
        self.k_scales = np.zeros(max_seq, dtype=np.float32)
        self.v_scales = np.zeros(max_seq, dtype=np.float32)
        self.current_len = 0

    def append(self, k_new: np.ndarray, v_new: np.ndarray):
        """追加一个新 token 的 K/V, 量化后写入 cache

        Args:
            k_new: [head_dim] 新 token 的 K
            v_new: [head_dim] 新 token 的 V
        """
        pos = self.current_len
        k_int8, k_scale = quantize_per_token(k_new.reshape(1, -1))
        v_int8, v_scale = quantize_per_token(v_new.reshape(1, -1))
        self.k_int8[pos] = k_int8[0]
        self.v_int8[pos] = v_int8[0]
        self.k_scales[pos] = k_scale[0]
        self.v_scales[pos] = v_scale[0]
        self.current_len += 1

    def get_k(self) -> np.ndarray:
        """读取反量化后的 K: [current_len, head_dim]"""
        return dequantize_per_token(self.k_int8[:self.current_len],
                                    self.k_scales[:self.current_len])

    def get_v(self) -> np.ndarray:
        """读取反量化后的 V: [current_len, head_dim]"""
        return dequantize_per_token(self.v_int8[:self.current_len],
                                    self.v_scales[:self.current_len])

    def memory_savings(self) -> dict:
        """计算显存节省量"""
        fp16_bytes = self.current_len * self.head_dim * 2  # FP16
        fp32_bytes = self.current_len * self.head_dim * 4  # FP32
        int8_data = self.current_len * self.head_dim * 1   # INT8
        scale_bytes = self.current_len * 4                 # FP32 scales
        quant_bytes = int8_data + scale_bytes
        return {
            "fp32_bytes": fp32_bytes * 2,      # K + V
            "fp16_bytes": fp16_bytes * 2,      # K + V (常见 baseline)
            "quant_bytes": quant_bytes * 2,     # K_int8 + V_int8 + scales
            "vs_fp16_ratio": (quant_bytes * 2) / (fp16_bytes * 2),
        }


# ==============================================================================
# 精度对比测试
# ==============================================================================

def compute_attention_scores(q: np.ndarray, k: np.ndarray) -> np.ndarray:
    """简化版 attention score: Q @ K^T"""
    return q @ k.T


def main():
    print("=" * 70)
    print("KV Cache INT8 量化模拟")
    print("=" * 70)

    head_dim = 64
    max_seq = 128
    num_tokens = 32

    rng = np.random.RandomState(42)

    # —— 生成模拟数据 ——
    k_orig = rng.randn(num_tokens, head_dim).astype(np.float32) * 0.5
    v_orig = rng.randn(num_tokens, head_dim).astype(np.float32) * 0.5
    q = rng.randn(1, head_dim).astype(np.float32)

    # —— 写入: 逐 token 量化存入 cache ——
    cache = QuantKVCache(max_seq, head_dim)
    for i in range(num_tokens):
        cache.append(k_orig[i], v_orig[i])

    # —— 读取: 反量化 ——
    k_deq = cache.get_k()
    v_deq = cache.get_v()

    # —— 精度对比 ——
    k_error = np.mean((k_orig - k_deq) ** 2)
    v_error = np.mean((v_orig - v_deq) ** 2)

    attn_orig = compute_attention_scores(q, k_orig)
    attn_deq = compute_attention_scores(q, k_deq)
    attn_error = np.mean((attn_orig - attn_deq) ** 2)
    attn_cosine = np.dot(attn_orig.flatten(), attn_deq.flatten()) / (
        np.linalg.norm(attn_orig) * np.linalg.norm(attn_deq) + 1e-8
    )

    # —— 显存对比 ——
    mem = cache.memory_savings()

    print(f"\n  序列长度: {num_tokens} tokens")
    print(f"  head_dim: {head_dim}")
    print(f"\n  K 量化 MSE:   {k_error:.6f}")
    print(f"  V 量化 MSE:   {v_error:.6f}")
    print(f"  Attention MSE: {attn_error:.6f}")
    print(f"  Attention 余弦相似度: {attn_cosine:.6f}")

    print(f"\n  显存对比 (K+V):")
    print(f"    FP32 原始:  {mem['fp32_bytes']:>8,d} bytes")
    print(f"    FP16 原始:  {mem['fp16_bytes']:>8,d} bytes")
    print(f"    INT8 量化:  {mem['quant_bytes']:>8,d} bytes")
    print(f"    相比 FP16 节省: {(1 - mem['vs_fp16_ratio']) * 100:.1f}%")

    print(f"\n  [✓] 量化后 attention 余弦相似度 ≈ {attn_cosine:.4f}, 精度损失很小")


if __name__ == "__main__":
    main()
