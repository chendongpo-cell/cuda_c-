﻿"""
awq_real_deploy.py — AWQ 量化模型真实部署 + Benchmark

配合 [docs/21_awq_deployment.md](../docs/21_awq_deployment.md) 使用。

这个脚本假设你已经用 vLLM 启动了 AWQ 量化模型:
    vllm serve casperhansen/llama-3-8b-instruct-awq \\
        --quantization awq \\
        --port 8000

然后跑这个脚本测吞吐 / 延迟 / 正确性。

学习目标:
    1. 知道 AWQ 模型怎么用 vLLM 部署
    2. 会写 benchmark 脚本测 TTFT / TPOT / 吞吐
    3. 知道怎么验证 AWQ 输出正确性
    4. 对比 FP16 看加速比

运行:
    # 先启动 vLLM 服务 (另一个终端)
    vllm serve casperhansen/llama-3-8b-instruct-awq \\
        --quantization awq --port 8000

    # 再跑这个脚本
    cd 07_quantization/python
    python awq_real_deploy.py
"""

import asyncio
import time
import statistics
import json
import argparse
from typing import List, Dict, Optional

try:
    import httpx
except ImportError:
    raise ImportError("需要安装 httpx: pip install httpx")


# ============================================================
# 配置
# ============================================================

DEFAULT_BASE_URL = "http://localhost:8000/v1"
DEFAULT_MODEL = "casperhansen/llama-3-8b-instruct-awq"

# 用于正确性测试的简单 prompt
CORRECTNESS_CASES = [
    {"prompt": "1 + 1 = ", "expected": "2", "max_tokens": 5},
    {"prompt": "The capital of France is ", "expected": "Paris", "max_tokens": 10},
    {"prompt": "def hello_world():\n    ", "expected": "print", "max_tokens": 20},
    {"prompt": "Translate 'hello' to Spanish: ", "expected": "hola", "max_tokens": 10},
    {"prompt": "What is 5 * 6? ", "expected": "30", "max_tokens": 5},
]

# 用于吞吐测试的 prompt 模板
THROUGHPUT_PROMPTS = [
    "Explain the concept of gradient descent in machine learning.",
    "Write a Python function to implement quicksort.",
    "What are the main causes of climate change?",
    "Describe the plot of Romeo and Juliet.",
    "How does a transformer neural network work?",
    "Write a short story about a robot learning to paint.",
    "Explain the difference between TCP and UDP.",
    "What is the meaning of life according to different philosophies?",
    "Describe how a vaccine works.",
    "Write a SQL query to find the top 10 customers by total sales.",
]


# ============================================================
# 核心推理函数
# ============================================================

async def send_request(
    client: httpx.AsyncClient,
    base_url: str,
    model: str,
    prompt: str,
    max_tokens: int = 256,
    temperature: float = 0.7,
    stream: bool = True,
) -> Dict:
    """
    发送一个推理请求, 返回详细统计

    参数:
        client: httpx 异步客户端
        base_url: vLLM 服务 URL
        model: 模型名
        prompt: 输入文本
        max_tokens: 最多生成多少 token
        temperature: 采样温度 (0 = greedy)
        stream: 是否流式返回

    返回:
        {
            "ttft": 首 token 延迟 (秒),
            "total_time": 总耗时,
            "output_tokens": 输出 token 数,
            "tpot": 单 token 延迟,
            "output": 生成的文本,
            "error": 错误信息 (如果有)
        }
    """
    start = time.time()
    ttft: Optional[float] = None
    output_tokens = 0
    output_text = ""
    error = None

    try:
        if stream:
            # 流式请求, 能拿到首 token 时间
            async with client.stream(
                "POST",
                f"{base_url}/completions",
                json={
                    "model": model,
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                    "stream": True,
                    "stream_options": {"include_usage": True},
                },
                timeout=120.0,
            ) as response:
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                        # 处理生成的 token
                        if "choices" in chunk and chunk["choices"]:
                            delta = chunk["choices"][0].get("text", "")
                            if delta:
                                if ttft is None:
                                    ttft = time.time() - start
                                output_text += delta
                                output_tokens += 1
                        # 处理 usage 信息 (最后一条)
                        if "usage" in chunk and chunk["usage"]:
                            output_tokens = chunk["usage"].get(
                                "completion_tokens", output_tokens
                            )
                    except json.JSONDecodeError:
                        continue
        else:
            # 非流式请求
            response = await client.post(
                f"{base_url}/completions",
                json={
                    "model": model,
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                },
                timeout=120.0,
            )
            response.raise_for_status()
            data = response.json()
            output_text = data["choices"][0]["text"]
            output_tokens = data["usage"]["completion_tokens"]
            ttft = None  # 非流式拿不到 TTFT

    except Exception as e:
        error = str(e)

    total_time = time.time() - start
    return {
        "ttft": ttft or 0,
        "total_time": total_time,
        "output_tokens": output_tokens,
        "tpot": (
            (total_time - (ttft or 0)) / max(output_tokens - 1, 1)
            if output_tokens > 1 else 0
        ),
        "output": output_text,
        "error": error,
    }


# ============================================================
# Benchmark 函数
# ============================================================

async def benchmark_correctness(
    base_url: str,
    model: str,
) -> None:
    """正确性测试: 看 AWQ 模型输出是否合理"""
    print("\n" + "=" * 60)
    print("1. 正确性测试")
    print("=" * 60)
    print(f"{'Status':<6}{'Prompt':<50}{'Expected':<15}{'Got':<30}")
    print("-" * 100)

    async with httpx.AsyncClient() as client:
        for case in CORRECTNESS_CASES:
            r = await send_request(
                client, base_url, model,
                prompt=case["prompt"],
                max_tokens=case["max_tokens"],
                temperature=0.0,  # greedy, 结果可复现
                stream=False,
            )
            if r["error"]:
                print(f"ERROR  {case['prompt'][:48]:<50}  err: {r['error']}")
                continue

            got = r["output"].strip()[:28]
            ok = case["expected"].lower() in r["output"].lower()
            status = "✓" if ok else "✗"
            print(f"{status:<6}{case['prompt'][:48]:<50}"
                  f"{case['expected']:<15}{got:<30}")


async def benchmark_latency(
    base_url: str,
    model: str,
    num_requests: int = 10,
) -> None:
    """延迟测试: 单请求逐个发, 测 TTFT / TPOT"""
    print("\n" + "=" * 60)
    print(f"2. 延迟测试 ({num_requests} 个单请求)")
    print("=" * 60)

    prompt = "Write a short poem about autumn."

    async with httpx.AsyncClient() as client:
        results = []
        for i in range(num_requests):
            r = await send_request(
                client, base_url, model,
                prompt=prompt,
                max_tokens=100,
                temperature=0.7,
                stream=True,
            )
            if r["error"]:
                print(f"  请求 {i+1} 失败: {r['error']}")
                continue
            results.append(r)
            print(f"  请求 {i+1}: TTFT={r['ttft']*1000:.0f}ms "
                  f"TPOT={r['tpot']*1000:.1f}ms "
                  f"tokens={r['output_tokens']}")

    if not results:
        return

    ttfts = [r["ttft"] for r in results]
    tpots = [r["tpot"] for r in results]

    def percentile(data, p):
        s = sorted(data)
        idx = int(len(s) * p / 100)
        return s[min(idx, len(s) - 1)]

    print(f"\n  TTFT  mean: {statistics.mean(ttfts)*1000:.1f}ms  "
          f"P50: {percentile(ttfts, 50)*1000:.1f}ms  "
          f"P99: {percentile(ttfts, 99)*1000:.1f}ms")
    print(f"  TPOT  mean: {statistics.mean(tpots)*1000:.1f}ms  "
          f"P50: {percentile(tpots, 50)*1000:.1f}ms")


async def benchmark_throughput(
    base_url: str,
    model: str,
    num_requests: int = 50,
    max_tokens: int = 128,
) -> None:
    """吞吐测试: 并发发 num_requests 个请求"""
    print("\n" + "=" * 60)
    print(f"3. 吞吐测试 ({num_requests} 并发, 每个生成 {max_tokens} tokens)")
    print("=" * 60)

    # 准备 prompts, 循环使用
    prompts = (THROUGHPUT_PROMPTS * (num_requests // len(THROUGHPUT_PROMPTS) + 1))[:num_requests]

    async with httpx.AsyncClient() as client:
        start = time.time()
        results = await asyncio.gather(
            *[
                send_request(
                    client, base_url, model,
                    prompt=p,
                    max_tokens=max_tokens,
                    temperature=0.7,
                    stream=True,
                )
                for p in prompts
            ]
        )
        total_time = time.time() - start

    successful = [r for r in results if not r["error"]]
    failed = [r for r in results if r["error"]]

    if failed:
        print(f"  ⚠ {len(failed)} 个请求失败")
        for r in failed[:3]:
            print(f"    {r['error']}")

    if not successful:
        return

    total_output_tokens = sum(r["output_tokens"] for r in successful)
    ttfts = [r["ttft"] for r in successful]
    tpots = [r["tpot"] for r in successful]

    def percentile(data, p):
        s = sorted(data)
        idx = int(len(s) * p / 100)
        return s[min(idx, len(s) - 1)]

    print(f"\n  总时间:           {total_time:.2f}s")
    print(f"  总输出 tokens:    {total_output_tokens}")
    print(f"  总吞吐:           {total_output_tokens / total_time:.1f} tok/s")
    print(f"  请求吞吐:         {len(successful) / total_time:.1f} req/s")
    print(f"  TTFT mean/P50/P99: "
          f"{statistics.mean(ttfts)*1000:.1f} / "
          f"{percentile(ttfts, 50)*1000:.1f} / "
          f"{percentile(ttfts, 99)*1000:.1f} ms")
    print(f"  TPOT mean/P50:    "
          f"{statistics.mean(tpots)*1000:.1f} / "
          f"{percentile(tpots, 50)*1000:.1f} ms")


# ============================================================
# 主入口
# ============================================================

async def main():
    parser = argparse.ArgumentParser(description="AWQ 模型 Benchmark")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL,
                        help=f"vLLM 服务地址 (默认: {DEFAULT_BASE_URL})")
    parser.add_argument("--model", default=DEFAULT_MODEL,
                        help=f"模型名 (默认: {DEFAULT_MODEL})")
    parser.add_argument("--num-requests", type=int, default=50,
                        help="吞吐测试的并发请求数 (默认: 50)")
    parser.add_argument("--skip-correctness", action="store_true",
                        help="跳过正确性测试")
    parser.add_argument("--skip-latency", action="store_true",
                        help="跳过延迟测试")
    parser.add_argument("--skip-throughput", action="store_true",
                        help="跳过吞吐测试")
    args = parser.parse_args()

    print("╔" + "═" * 60 + "╗")
    print("║" + " AWQ 模型 Benchmark ".center(58) + "║")
    print("╚" + "═" * 60 + "╝")
    print(f"Server: {args.base_url}")
    print(f"Model:  {args.model}")

    # 检查服务是否可达
    async with httpx.AsyncClient() as client:
        try:
            r = await client.get(f"{args.base_url}/models", timeout=5.0)
            r.raise_for_status()
            print(f"✓ 服务可达")
        except Exception as e:
            print(f"✗ 无法连接服务: {e}")
            print(f"  请先启动 vLLM:")
            print(f"  vllm serve {args.model} --quantization awq --port 8000")
            return

    if not args.skip_correctness:
        await benchmark_correctness(args.base_url, args.model)

    if not args.skip_latency:
        await benchmark_latency(args.base_url, args.model)

    if not args.skip_throughput:
        await benchmark_throughput(
            args.base_url, args.model,
            num_requests=args.num_requests,
        )

    print("\n" + "=" * 60)
    print("Benchmark 完成")
    print("=" * 60)
    print("\n对比 FP16:")
    print("  1. 启动 FP16 服务: vllm serve meta-llama/Llama-3-8B --port 8001")
    print("  2. 跑同样 benchmark: python awq_real_deploy.py --base-url http://localhost:8001/v1 --model meta-llama/Llama-3-8B")
    print("  3. 对比吞吐 / TTFT / TPOT")


if __name__ == "__main__":
    asyncio.run(main())
