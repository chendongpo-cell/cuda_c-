﻿/*
 * kv_cache_quant.cu — KV Cache INT8 量化
 *
 * 对应 Python 版: 07_quantization/python/kv_cache_quant_sim.py
 *
 * 场景: LLM 推理时 KV Cache 占大量显存, 把它量化到 INT8 能省 2x
 *
 * 流程:
 *     1. 写入: FP16/FP32 K/V → 求 scale → INT8 K/V → 存到 cache
 *     2. 读取: INT8 K/V → 反量化 → FP16/FP32 → 用于 attention
 *
 * 两种量化粒度:
 *     - per-tensor: 整个 cache 一个 scale (省内存, 精度低)
 *     - per-token: 每个 token 一个 scale (精度高, scale 占额外内存)
 *     - per-channel: 每个 channel 一个 scale (常见)
 *
 * 本文件演示 per-token 量化 (推理最常用)
 *
 * 教学重点:
 *     - 量化和反量化 kernel 的写法
 *     - scale 数组的管理
 *     - 量化误差对 attention 的影响
 *
 * 编译: nvcc -std=c++17 -O2 kv_cache_quant.cu -o kv_cache_quant_demo
 * 运行: ./kv_cache_quant_demo
 *
 * 配套文档: docs/11_kv_cache_optimization.md
 */

#include <cuda_runtime.h>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstdint>

#define CUDA_CHECK(call)                                                \
    do {                                                                \
        cudaError_t err = (call);                                       \
        if (err != cudaSuccess) {                                       \
            fprintf(stderr, "CUDA error %s:%d: %s\n",                   \
                    __FILE__, __LINE__, cudaGetErrorString(err));       \
            exit(EXIT_FAILURE);                                         \
        }                                                               \
    } while (0)


// ============================================================
// 数据结构: 量化版 KV Cache
// ============================================================
// Python 类比:
//   class QuantKVCache:
//       self.k_int8 = torch.zeros(max_seq, head_dim).to(torch.int8)
//       self.k_scale = torch.zeros(max_seq)  # 每个 token 一个 scale
//       self.current_len = 0
struct QuantKVCache {
    int8_t* k_int8;     // [max_seq, head_dim] 量化后的 K
    float* k_scale;     // [max_seq] 每个 token 的 scale
    int max_seq;
    int head_dim;
    int current_len;
};


// ============================================================
// Kernel 1: 求 per-token max (算 scale)
// ============================================================
// 输入: new_k [head_dim] (单个 token)
// 输出: max_abs (单个值)
__global__ void token_max_kernel(const float* new_k, float* max_abs, int head_dim) {
    __shared__ float s_max[256];
    int tid = threadIdx.x;

    float local_max = 0.0f;
    for (int i = tid; i < head_dim; i += blockDim.x) {
        local_max = fmaxf(local_max, fabsf(new_k[i]));
    }
    s_max[tid] = local_max;
    __syncthreads();

    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) s_max[tid] = fmaxf(s_max[tid], s_max[tid + s]);
        __syncthreads();
    }

    if (tid == 0) *max_abs = s_max[0];
}


// ============================================================
// Kernel 2: 量化写入 (FP32 → INT8 + 记录 scale)
// ============================================================
// Python 类比:
//   scale = max(abs(new_k)) / 127
//   k_int8[current_len] = round(new_k / scale).to(int8)
//   k_scale[current_len] = scale
__global__ void quantize_write_kernel(
    const float* __restrict__ new_k,     // [head_dim] FP32 输入
    int8_t* __restrict__ k_int8,         // [max_seq, head_dim] 量化 cache
    float* __restrict__ k_scale,         // [max_seq] scale 数组
    int max_seq, int head_dim,
    int current_len,
    float scale)
{
    int d = blockIdx.x * blockDim.x + threadIdx.x;
    if (d >= head_dim) return;

    // 量化: round(new_k[d] / scale), clip 到 [-127, 127]
    float v = new_k[d] / scale;
    int v_int = (int)lroundf(v);
    v_int = max(-127, min(127, v_int));

    k_int8[current_len * head_dim + d] = (int8_t)v_int;

    // 记录 scale (每个线程都写, 但值一样, 简化: 只让 tid=0 写)
    if (d == 0) {
        k_scale[current_len] = scale;
    }
}


// ============================================================
// Kernel 3: 反量化读取 (INT8 → FP32) + 同时算 attention score
// ============================================================
// Python 类比:
//   k_fp32 = k_int8[:current_len].float() * k_scale[:current_len, None]
//   scores = Q @ k_fp32.T * scale_attn
//
// 这里 fused: 反量化 + 点积, 避免中间结果写回 HBM
__global__ void dequant_and_qk_kernel(
    const float* __restrict__ Q,          // [head_dim] 单个 query
    const int8_t* __restrict__ k_int8,    // [max_seq, head_dim]
    const float* __restrict__ k_scale,    // [max_seq]
    float* __restrict__ scores,           // [current_len] 输出
    int max_seq, int head_dim,
    int current_len,
    float scale_attn)
{
    int kv_idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (kv_idx >= current_len) return;

    float s = k_scale[kv_idx];   // 这个 token 的 scale

    // 反量化 + 点积: sum_d Q[d] * (k_int8[kv_idx][d] * s)
    float sum = 0.0f;
    for (int d = 0; d < head_dim; ++d) {
        float k_fp32 = (float)k_int8[kv_idx * head_dim + d] * s;
        sum += Q[d] * k_fp32;
    }
    scores[kv_idx] = sum * scale_attn;
}


// ============================================================
// 主函数
// ============================================================
int main()
{
    printf("=== KV Cache INT8 量化 Demo ===\n");

    const int max_seq = 64;
    const int head_dim = 32;
    const int num_steps = 5;   // 模拟 5 步 decode

    // ===== 1. 分配量化 KV Cache =====
    QuantKVCache cache;
    cache.max_seq = max_seq;
    cache.head_dim = head_dim;
    cache.current_len = 0;

    CUDA_CHECK(cudaMalloc(&cache.k_int8, max_seq * head_dim * sizeof(int8_t)));
    CUDA_CHECK(cudaMalloc(&cache.k_scale, max_seq * sizeof(float)));
    CUDA_CHECK(cudaMemset(cache.k_int8, 0, max_seq * head_dim * sizeof(int8_t)));

    // 同时分配一个 FP32 cache 做对照 (验证精度)
    float* d_k_fp32_ref;
    CUDA_CHECK(cudaMalloc(&d_k_fp32_ref, max_seq * head_dim * sizeof(float)));

    printf("配置: max_seq=%d, head_dim=%d, 量化=per-token INT8\n",
           max_seq, head_dim);

    // ===== 2. 模拟 decode: 每步 append 一个 token =====
    for (int step = 0; step < num_steps; ++step) {
        // 2.1 生成"新 token 的 K" (FP32)
        float* h_new_k = (float*)malloc(head_dim * sizeof(float));
        for (int d = 0; d < head_dim; ++d) {
            h_new_k[d] = 0.5f * sinf(step + d * 0.1f);   // 用 sin 模拟
        }
        float* d_new_k;
        CUDA_CHECK(cudaMalloc(&d_new_k, head_dim * sizeof(float)));
        CUDA_CHECK(cudaMemcpy(d_new_k, h_new_k,
                              head_dim * sizeof(float),
                              cudaMemcpyHostToDevice));

        // 2.2 存到 FP32 ref (对照)
        CUDA_CHECK(cudaMemcpy(d_k_fp32_ref + cache.current_len * head_dim,
                              h_new_k, head_dim * sizeof(float),
                              cudaMemcpyHostToDevice));

        // 2.3 求 max → 算 scale
        float* d_scale;
        CUDA_CHECK(cudaMalloc(&d_scale, sizeof(float)));
        token_max_kernel<<<1, 32>>>(d_new_k, d_scale, head_dim);
        CUDA_CHECK(cudaDeviceSynchronize());
        float h_scale;
        CUDA_CHECK(cudaMemcpy(&h_scale, d_scale, sizeof(float),
                              cudaMemcpyDeviceToHost));
        h_scale /= 127.0f;

        // 2.4 量化写入
        quantize_write_kernel<<<(head_dim + 255) / 256, 256>>>(
            d_new_k, cache.k_int8, cache.k_scale,
            max_seq, head_dim, cache.current_len, h_scale);
        CUDA_CHECK(cudaGetLastError());

        cache.current_len++;
        printf("[Step %d] append, scale=%.6f, current_len=%d\n",
               step, h_scale, cache.current_len);

        cudaFree(d_new_k);
        cudaFree(d_scale);
        free(h_new_k);
    }

    // ===== 3. 用 Q 查询, 对比量化 vs FP32 =====
    printf("\n用 Q 查询 cache, 对比量化 vs FP32:\n");

    float* h_Q = (float*)malloc(head_dim * sizeof(float));
    for (int d = 0; d < head_dim; ++d) h_Q[d] = 0.3f;
    float* d_Q;
    CUDA_CHECK(cudaMalloc(&d_Q, head_dim * sizeof(float)));
    CUDA_CHECK(cudaMemcpy(d_Q, h_Q, head_dim * sizeof(float),
                          cudaMemcpyHostToDevice));

    float scale_attn = 1.0f / sqrtf((float)head_dim);

    // 3.1 量化路径
    float* d_scores_quant;
    CUDA_CHECK(cudaMalloc(&d_scores_quant, cache.current_len * sizeof(float)));
    dequant_and_qk_kernel<<<(cache.current_len + 255) / 256, 256>>>(
        d_Q, cache.k_int8, cache.k_scale, d_scores_quant,
        max_seq, head_dim, cache.current_len, scale_attn);
    CUDA_CHECK(cudaDeviceSynchronize());

    // 3.2 FP32 路径 (CPU 算对照)
    float* h_k_ref = (float*)malloc(cache.current_len * head_dim * sizeof(float));
    CUDA_CHECK(cudaMemcpy(h_k_ref, d_k_fp32_ref,
                          cache.current_len * head_dim * sizeof(float),
                          cudaMemcpyDeviceToHost));
    float* h_scores_ref = (float*)malloc(cache.current_len * sizeof(float));
    for (int j = 0; j < cache.current_len; ++j) {
        float s = 0.0f;
        for (int d = 0; d < head_dim; ++d) {
            s += h_Q[d] * h_k_ref[j * head_dim + d];
        }
        h_scores_ref[j] = s * scale_attn;
    }

    // 3.3 对比
    float* h_scores_quant = (float*)malloc(cache.current_len * sizeof(float));
    CUDA_CHECK(cudaMemcpy(h_scores_quant, d_scores_quant,
                          cache.current_len * sizeof(float),
                          cudaMemcpyDeviceToHost));

    printf("  %-10s %-15s %-15s %-15s\n",
           "kv_idx", "FP32_score", "INT8_score", "diff");
    float max_diff = 0.0f;
    for (int j = 0; j < cache.current_len; ++j) {
        float diff = fabsf(h_scores_ref[j] - h_scores_quant[j]);
        max_diff = fmaxf(max_diff, diff);
        printf("  %-10d %-15.6f %-15.6f %-15.6e\n",
               j, h_scores_ref[j], h_scores_quant[j], diff);
    }
    printf("\n  最大误差: %e\n", max_diff);

    // ===== 4. 显存对比 =====
    printf("\n显存对比 (per token):\n");
    printf("  FP32 K cache:  %d bytes\n", head_dim * 4);
    printf("  INT8 K cache:  %d bytes (INT8) + 4 bytes (scale) = %d bytes\n",
           head_dim * 1, head_dim * 1 + 4);
    printf("  节省: %.1f%%\n",
           100.0f * (1 - (float)(head_dim + 4) / (head_dim * 4)));

    // ===== 5. 清理 =====
    cudaFree(cache.k_int8);
    cudaFree(cache.k_scale);
    cudaFree(d_k_fp32_ref);
    cudaFree(d_Q);
    cudaFree(d_scores_quant);
    free(h_Q);
    free(h_k_ref);
    free(h_scores_ref);
    free(h_scores_quant);

    printf("\nKV Cache 量化 demo 完成.\n");
    printf("对比 Python 版: 07_quantization/python/kv_cache_quant_sim.py\n");
    return 0;
}

/*
 * 学习建议:
 *   1. 跑 Python 版 kv_cache_quant_sim.py, 理解量化数学
 *   2. 对照本文件, 理解 per-token scale 的存储方式
 *   3. 改输入数据范围, 观察量化误差变化
 *   4. 进阶:
 *      - 加 per-channel 量化 (每个 channel 一个 scale)
 *      - 加 FP8 量化 (新硬件支持)
 *      - 用 INT4 量化 (更省内存, 精度更低)
 *
 * 关键收获:
 *   - KV Cache 量化 = 写时量化 + 读时反量化
 *   - per-token scale 是精度和开销的折中
 *   - fused kernel (反量化+点积) 比分开做快 (省 HBM 访问)
 */
