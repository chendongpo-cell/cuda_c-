﻿# 07_quantization/cuda/ — 量化算子的 C++/CUDA 实现

> **对应 Python 版**：[07_quantization/python/](../07_quantization/python/)
>
> **定位**：用 CUDA C++ 重写 Python 教学版里的量化代码，让你看到 INT8 量化在 GPU 上到底怎么实现。
>
> **前置**：学完 [docs/10_quantization.md](../docs/10_quantization.md) + [03_cuda_kernels/matmul_tensorcore.cu](../03_cuda_kernels/matmul_tensorcore.cu)。

---

## 文件对应关系

| C++/CUDA 文件 | 对应 Python 脚本 | 教学重点 |
|--------------|----------------|---------|
| [int8_gemm.cu](int8_gemm.cu) | [07_quantization/python/int8_gemm_sim.py](../07_quantization/python/int8_gemm_sim.py) | INT8 量化 + matmul + 反量化完整流程 |
| [kv_cache_quant.cu](kv_cache_quant.cu) | [07_quantization/python/kv_cache_quant_sim.py](../07_quantization/python/kv_cache_quant_sim.py) | KV Cache 的 INT8 量化写入与反量化读取 |

---

## 编译运行

```bash
cd 07_quantization/cuda
mkdir build && cd build
cmake .. -DCMAKE_CUDA_ARCHITECTURES="80"
make -j4

./int8_gemm_demo
./kv_cache_quant_demo
```

---

## Python vs C++ 实现对比要点

| 维度 | Python (模拟) | C++/CUDA |
|------|--------------|----------|
| 量化 | `torch.round(x / scale).to(torch.int8)` | 自定义 kernel，手动 round |
| matmul | `torch.matmul` (FP32 模拟 INT8) | 真实 INT8 计算（或 wmma） |
| 反量化 | `(x.float() * scale)` | 手动 kernel |
| 速度 | 慢（模拟） | 快（真实 INT8 算力） |

**核心收获**：理解"量化节省显存和带宽"在 GPU 层面到底怎么发生。
