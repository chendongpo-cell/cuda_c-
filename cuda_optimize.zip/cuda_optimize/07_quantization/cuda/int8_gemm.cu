﻿/*
 * int8_gemm.cu — INT8 量化 GEMM 完整流程
 *
 * 对应 Python 版: 07_quantization/python/int8_gemm_sim.py
 *
 * 完整流程:
 *     1. 量化: FP32 权重 W_fp32 → INT8 W_int8 (用 scale = max(|W|) / 127)
 *     2. 量化: FP32 激活 X_fp32 → INT8 X_int8
 *     3. INT8 matmul: Y_int = X_int @ W_int (值范围 [-127*127, 127*127] 在 INT32 范围内)
 *     4. 反量化: Y_fp32 = Y_int * scale_x * scale_w
 *
 * Python 模拟版用 torch.matmul + round, 没有真的用 INT8 算力
 * 这里用 CUDA kernel 真的做 INT8 计算
 *
 * 教学重点:
 *     - per-tensor 量化的 scale 计算
 *     - 量化 kernel (FP32 → INT8)
 *     - INT8 GEMM kernel (用 int32 累加)
 *     - 反量化 kernel
 *     - 量化误差的来源
 *
 * 注意: 这个版本用普通 CUDA core 做 INT8 计算
 *       真实生产用 TensorCore (wmma INT8) 能快 4x
 *       参考 03_cuda_kernels/matmul_tensorcore.cu
 *
 * 编译: nvcc -std=c++17 -O2 int8_gemm.cu -o int8_gemm_demo
 * 运行: ./int8_gemm_demo
 *
 * 配套文档: docs/10_quantization.md, docs/21_awq_deployment.md
 */

#include <cuda_runtime.h>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <algorithm>

#define CUDA_CHECK(call)                                                \
    do {                                                                \
        cudaError_t err = (call);                                       \
        if (err != cudaSuccess) {                                       \
            fprintf(stderr, "CUDA error %s:%d: %s\n",                   \
                    __FILE__, __LINE__, cudaGetErrorString(err));       \
            exit(EXIT_FAILURE);                                         \
        }                                                               \
    } while (0)


// ============================================================
// Kernel 1: 求 max (用于算 scale)
// ============================================================
// 简化: 用单 block reduction. 真实实现用多 block + 两阶段
// 输入: x [N], 输出: max_abs (单个值)
__global__ void max_abs_kernel(const float* x, float* max_abs, int N) {
    __shared__ float s_max[256];

    int tid = threadIdx.x;
    int i = blockIdx.x * blockDim.x + tid;

    // 1. 每个线程算自己覆盖范围的最大值
    float local_max = 0.0f;
    while (i < N) {
        local_max = fmaxf(local_max, fabsf(x[i]));
        i += gridDim.x * blockDim.x;
    }
    s_max[tid] = local_max;
    __syncthreads();

    // 2. block 内 reduction (树形归约)
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            s_max[tid] = fmaxf(s_max[tid], s_max[tid + s]);
        }
        __syncthreads();
    }

    // 3. block 0 写结果 (简化: 假设单 block)
    if (blockIdx.x == 0 && tid == 0) {
        *max_abs = s_max[0];
    }
}


// ============================================================
// Kernel 2: 量化 FP32 → INT8
// ============================================================
// 数学: x_int8 = round(x_fp32 / scale), clip 到 [-127, 127]
//        scale = max_abs / 127
//
// 线程映射: 一个线程量化一个元素
__global__ void quantize_fp32_to_int8_kernel(
    const float* __restrict__ x_fp32,
    int8_t* __restrict__ x_int8,
    int N,
    float scale)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    float v = x_fp32[i] / scale;
    // round + clip
    // Python 程序员注意: C++ 的 round() 和 Python 的 round() 行为略不同
    //   C++ round() 是 "round half away from zero"
    int v_int = (int)lroundf(v);   // lroundf 返回 long, 转成 int
    v_int = max(-127, min(127, v_int));  // clip
    x_int8[i] = (int8_t)v_int;
}


// ============================================================
// Kernel 3: INT8 GEMM (朴素版, 不分块)
// ============================================================
// 数学: Y[m][n] = sum_k X_int8[m][k] * W_int8[n][k]
//       累加用 int32 (避免溢出: 127*127*K 可能很大)
//
// 线程映射: 一个线程算 Y 的一个元素
__global__ void int8_gemm_kernel(
    const int8_t* __restrict__ X,     // [M, K]
    const int8_t* __restrict__ W,     // [N, K]  (注意: W 已经转置, 行主序)
    int32_t* __restrict__ Y,          // [M, N]
    int M, int N, int K)
{
    int m = blockIdx.x * blockDim.x + threadIdx.x;
    int n = blockIdx.y * blockDim.y + threadIdx.y;
    if (m >= M || n >= N) return;

    int32_t sum = 0;
    for (int k = 0; k < K; ++k) {
        // X[m][k] 在 X[m*K + k]
        // W[n][k] 在 W[n*K + k] (W 已转置, 行主序)
        sum += (int32_t)X[m * K + k] * (int32_t)W[n * K + k];
    }
    Y[m * N + n] = sum;
}


// ============================================================
// Kernel 4: 反量化 INT32 → FP32
// ============================================================
// 数学: Y_fp32 = Y_int32 * scale_x * scale_w
__global__ void dequantize_kernel(
    const int32_t* __restrict__ x_int32,
    float* __restrict__ x_fp32,
    int N,
    float scale_x,
    float scale_w)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;
    x_fp32[i] = (float)x_int32[i] * scale_x * scale_w;
}


// ============================================================
// 主函数: 串联完整流程
// ============================================================
int main()
{
    printf("=== INT8 GEMM CUDA Demo ===\n");

    const int M = 64, N = 64, K = 32;
    printf("M=%d, N=%d, K=%d\n", M, N, K);

    // ===== 1. 生成 FP32 数据 =====
    size_t x_size = M * K * sizeof(float);
    size_t w_size = N * K * sizeof(float);
    size_t y_size = M * N * sizeof(float);

    float *h_X = (float*)malloc(x_size);
    float *h_W = (float*)malloc(w_size);   // 注意: W 用 [N, K] 布局 (已转置)
    float *h_Y_int8 = (float*)malloc(y_size);     // INT8 路径输出
    float *h_Y_fp32 = (float*)malloc(y_size);     // FP32 ground truth

    // 初始化 (用小值, 避免量化饱和)
    for (int i = 0; i < M * K; ++i) h_X[i] = 0.1f * ((i % 11) - 5);
    for (int i = 0; i < N * K; ++i) h_W[i] = 0.1f * ((i % 13) - 6);

    // ===== 2. FP32 ground truth (CPU) =====
    for (int m = 0; m < M; ++m) {
        for (int n = 0; n < N; ++n) {
            float sum = 0.0f;
            for (int k = 0; k < K; ++k) {
                sum += h_X[m * K + k] * h_W[n * K + k];
            }
            h_Y_fp32[m * N + n] = sum;
        }
    }

    // ===== 3. 分配 GPU 内存 =====
    float *d_X_fp32, *d_W_fp32, *d_Y_fp32;
    int8_t *d_X_int8, *d_W_int8;
    int32_t *d_Y_int32;
    float *d_max_x, *d_max_w;

    CUDA_CHECK(cudaMalloc(&d_X_fp32, x_size));
    CUDA_CHECK(cudaMalloc(&d_W_fp32, w_size));
    CUDA_CHECK(cudaMalloc(&d_Y_fp32, y_size));
    CUDA_CHECK(cudaMalloc(&d_X_int8, M * K * sizeof(int8_t)));
    CUDA_CHECK(cudaMalloc(&d_W_int8, N * K * sizeof(int8_t)));
    CUDA_CHECK(cudaMalloc(&d_Y_int32, M * N * sizeof(int32_t)));
    CUDA_CHECK(cudaMalloc(&d_max_x, sizeof(float)));
    CUDA_CHECK(cudaMalloc(&d_max_w, sizeof(float)));

    CUDA_CHECK(cudaMemcpy(d_X_fp32, h_X, x_size, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_W_fp32, h_W, w_size, cudaMemcpyHostToDevice));

    // ===== 4. Step 1: 求 max_abs (算 scale) =====
    max_abs_kernel<<<1, 256>>>(d_X_fp32, d_max_x, M * K);
    max_abs_kernel<<<1, 256>>>(d_W_fp32, d_max_w, N * K);
    CUDA_CHECK(cudaDeviceSynchronize());

    float h_max_x, h_max_w;
    CUDA_CHECK(cudaMemcpy(&h_max_x, d_max_x, sizeof(float), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&h_max_w, d_max_w, sizeof(float), cudaMemcpyDeviceToHost));

    float scale_x = h_max_x / 127.0f;
    float scale_w = h_max_w / 127.0f;
    printf("scale_x = %.6f (max_abs=%.4f)\n", scale_x, h_max_x);
    printf("scale_w = %.6f (max_abs=%.4f)\n", scale_w, h_max_w);

    // ===== 5. Step 2: 量化 FP32 → INT8 =====
    quantize_fp32_to_int8_kernel<<<(M*K+255)/256, 256>>>(
        d_X_fp32, d_X_int8, M * K, scale_x);
    quantize_fp32_to_int8_kernel<<<(N*K+255)/256, 256>>>(
        d_W_fp32, d_W_int8, N * K, scale_w);
    CUDA_CHECK(cudaGetLastError());

    // ===== 6. Step 3: INT8 GEMM =====
    dim3 gemm_block(16, 16);
    dim3 gemm_grid((M + 15) / 16, (N + 15) / 16);
    int8_gemm_kernel<<<gemm_grid, gemm_block>>>(
        d_X_int8, d_W_int8, d_Y_int32, M, N, K);
    CUDA_CHECK(cudaGetLastError());

    // ===== 7. Step 4: 反量化 =====
    dequantize_kernel<<<(M*N+255)/256, 256>>>(
        d_Y_int32, d_Y_fp32, M * N, scale_x, scale_w);
    CUDA_CHECK(cudaDeviceSynchronize());

    CUDA_CHECK(cudaMemcpy(h_Y_int8, d_Y_fp32, y_size, cudaMemcpyDeviceToHost));

    // ===== 8. 对比 INT8 vs FP32 的精度损失 =====
    float max_diff = 0.0f, mean_diff = 0.0f;
    for (int i = 0; i < M * N; ++i) {
        float diff = fabsf(h_Y_int8[i] - h_Y_fp32[i]);
        max_diff = fmaxf(max_diff, diff);
        mean_diff += diff;
    }
    mean_diff /= (M * N);

    printf("\n精度对比:\n");
    printf("  FP32 输出[0][:4] = ");
    for (int n = 0; n < 4; ++n) printf("%.4f ", h_Y_fp32[n]);
    printf("\n  INT8 输出[0][:4] = ");
    for (int n = 0; n < 4; ++n) printf("%.4f ", h_Y_int8[n]);
    printf("\n");
    printf("  最大误差: %e\n", max_diff);
    printf("  平均误差: %e\n", mean_diff);
    printf("  (误差来源: 量化 round + clip)\n");

    // ===== 9. 显存对比 =====
    printf("\n显存对比:\n");
    printf("  FP32 权重: %zu bytes\n", (size_t)N * K * 4);
    printf("  INT8 权重: %zu bytes (%.1f%% 节省)\n",
           (size_t)N * K * 1,
           100.0f * (1 - 1.0f / 4));

    // ===== 10. 清理 =====
    cudaFree(d_X_fp32); cudaFree(d_W_fp32); cudaFree(d_Y_fp32);
    cudaFree(d_X_int8); cudaFree(d_W_int8); cudaFree(d_Y_int32);
    cudaFree(d_max_x); cudaFree(d_max_w);
    free(h_X); free(h_W); free(h_Y_int8); free(h_Y_fp32);

    printf("\nINT8 GEMM demo 完成.\n");
    printf("对比 Python 版: 07_quantization/python/int8_gemm_sim.py\n");
    return 0;
}

/*
 * 学习建议:
 *   1. 先跑 Python 版 int8_gemm_sim.py, 理解量化数学
 *   2. 对照本文件, 理解每个 kernel 对应 Python 的哪一步
 *   3. 改输入数据范围 (比如把 0.1 改成 1.0), 观察量化误差变化
 *   4. 进阶: 用 wmma INT8 TensorCore 重写 int8_gemm_kernel
 *      参考 03_cuda_kernels/matmul_tensorcore.cu
 *
 * 关键收获:
 *   - 量化 = scale + round + clip
 *   - INT8 matmul 用 INT32 累加 (避免溢出)
 *   - 反量化 = 乘 scale_x * scale_w
 *   - 误差来自 round 和 clip
 */
