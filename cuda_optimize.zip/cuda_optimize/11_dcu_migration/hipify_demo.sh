﻿#!/bin/bash
# hipify_demo.sh — CUDA → HIP 自动迁移演示
#
# hipify-perl 和 hipify-clang 是 AMD 提供的自动迁移工具。
# 可以把 CUDA 源码中的 cudaMalloc → hipMalloc、cudaMemcpy → hipMemcpy 等自动替换。
#
# 用法：
#   bash hipify_demo.sh
#
# 前置条件：
#   安装 ROCm（hipify-perl 随 ROCm 一起提供）

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CUDA_SRC="${SCRIPT_DIR}/../03_cuda_kernels/vector_add.cu"
HIP_SRC="${SCRIPT_DIR}/hip_vector_add_auto.cpp"

echo "=== hipify 自动迁移演示 ==="
echo

# 检查 hipify-perl 是否可用
if ! command -v hipify-perl &> /dev/null; then
    echo "[WARN] hipify-perl 未找到，跳过自动迁移。"
    echo "  在 DCU 开发机上：hipify-perl 随 ROCm 提供"
    echo "  手动迁移参考：hip_vector_add.cpp（人工编写版）"
    exit 0
fi

echo "源文件: ${CUDA_SRC}"
echo "目标: ${HIP_SRC}"
echo

# hipify-perl 迁移
hipify-perl "${CUDA_SRC}" > "${HIP_SRC}"

echo "=== 迁移完成 ==="
echo "输出: ${HIP_SRC}"
echo
echo "=== 检查差异 ==="
grep -n "hipMalloc\|hipMemcpy\|hipFree\|hipLaunchKernel" "${HIP_SRC}" | head -20
echo
echo "=== 编译 ==="
echo "  hipcc -O2 -o hip_vector_add_auto hip_vector_add_auto.cpp"
echo "  ./hip_vector_add_auto"
