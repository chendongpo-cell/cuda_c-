# Wavefront=64 适配指南 — DCU 迁移最重要的差异

## 问题

NVIDIA GPU 的 warp 大小固定为 **32**。
DCU（AMD 架构）的 wavefront 大小为 **64**。

这意味着所有依赖于 warp 大小的代码都需要适配。

## 影响范围

### 1. Block Size 选择

```cuda
// CUDA：block_size 选 32 的倍数即可
int block_size = 128;  // 32 * 4

// DCU：block_size 建议选 64 的倍数
int block_size = 128;  // 64 * 2（128 同时是 32 和 64 的倍数，兼容性好）
```

### 2. Warp-level 归约

```cuda
// CUDA 版本（warp=32）
for (int s = 16; s > 0; s >>= 1) {
    val += __shfl_down_sync(0xFFFFFFFF, val, s, 32);
}

// DCU 版本（wavefront=64）
// 方式 1：在 HIP 中使用 __shfl_down（无 mask 参数）
for (int s = 32; s > 0; s >>= 1) {
    val += __shfl_down(val, s, 64);
}

// 方式 2：用 WARP_SIZE 宏统一
#if defined(__HIP_PLATFORM_AMD__)
    #define WARP_SIZE 64
#else
    #define WARP_SIZE 32
#endif
for (int s = WARP_SIZE / 2; s > 0; s >>= 1) {
    val += __shfl_down(val, s, WARP_SIZE);
}
```

### 3. Shared Memory Bank Conflict

CUDA 有 32 个 bank，DCU 的 LDS 也是 32 个 bank。
所以 bank conflict 的 padding 技巧在两个平台上通用：

```cuda
// 两个平台都适用
__shared__ float sdata[32][32 + 1];  // +1 padding 避免 bank conflict
```

### 4. 线程掩码（mask）

```cuda
// CUDA __shfl_down_sync 需要 mask 参数
val += __shfl_down_sync(0xFFFFFFFF, val, 16, 32);

// HIP __shfl_down 不需要 mask 参数
val += __shfl_down(val, 16, 64);

// 兼容写法：
#if HIP_VERSION >= 500
    // HIP 5.0+ 也支持带 mask 的版本
    val += __shfl_down_sync(0xFFFFFFFF, val, 16, 64);
#else
    val += __shfl_down(val, 16, 64);
#endif
```

## 检查清单

迁移 CUDA kernel 到 DCU 时检查这些：

- [ ] block_size 是 64 的倍数？
- [ ] warp-level 归约的步长从 32 改为 64？
- [ ] __shfl_down_sync → __shfl_down（根据 HIP 版本）
- [ ] 所有硬编码的 32 都改为 WARP_SIZE 宏？
- [ ] dynamic shared memory 大小不超过 DCU 的 LDS（64KB/CU）？
- [ ] CUDA graph 相关代码需要重写（ROCm 支持 hipGraph）
