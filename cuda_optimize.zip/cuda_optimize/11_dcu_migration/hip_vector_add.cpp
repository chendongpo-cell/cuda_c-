/*
 * hip_vector_add.cpp — HIP 版向量加法（CUDA → HIP 迁移对照）
 *
 * 和 CUDA 版本的唯一区别：
 *   cudaMalloc → hipMalloc
 *   cudaMemcpy → hipMemcpy
 *   cudaFree   → hipFree
 *   头文件从 cuda_runtime.h 变为 hip/hip_runtime.h
 *
 * 编译（DCU 上）：
 *   hipcc -O2 -o hip_vector_add hip_vector_add.cpp
 *
 * 编译（NVIDIA GPU 上，通过 HIP）：
 *   hipcc -O2 --offload-arch=sm_80 -o hip_vector_add hip_vector_add.cpp
 *
 * 运行：./hip_vector_add
 */

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <hip/hip_runtime.h>

#define HIP_CHECK(call)                                                         \
    do {                                                                        \
        hipError_t err = call;                                                  \
        if (err != hipSuccess) {                                                \
            fprintf(stderr, "HIP error at %s:%d: %s\n", __FILE__, __LINE__,     \
                    hipGetErrorString(err));                                    \
            exit(EXIT_FAILURE);                                                 \
        }                                                                       \
    } while(0)

// HIP kernel 写法完全兼容 CUDA 语法
__global__ void vector_add(const float* a, const float* b, float* c, int n) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < n) {
        c[tid] = a[tid] + b[tid];
    }
}

bool verify(const float* expected, const float* actual, int n) {
    for (int i = 0; i < n; ++i) {
        if (fabs(expected[i] - actual[i]) > 1e-5f) {
            printf("  FAIL at %d: expected=%f actual=%f\n",
                   i, expected[i], actual[i]);
            return false;
        }
    }
    return true;
}

int main() {
    int n = 1 << 20;
    size_t bytes = n * sizeof(float);

    float* h_a = (float*)malloc(bytes);
    float* h_b = (float*)malloc(bytes);
    float* h_c = (float*)malloc(bytes);
    float* h_cpu = (float*)malloc(bytes);

    for (int i = 0; i < n; ++i) {
        h_a[i] = static_cast<float>(rand()) / RAND_MAX;
        h_b[i] = static_cast<float>(rand()) / RAND_MAX;
        h_cpu[i] = h_a[i] + h_b[i];
    }

    float *d_a, *d_b, *d_c;
    HIP_CHECK(hipMalloc(&d_a, bytes));
    HIP_CHECK(hipMalloc(&d_b, bytes));
    HIP_CHECK(hipMalloc(&d_c, bytes));

    HIP_CHECK(hipMemcpy(d_a, h_a, bytes, hipMemcpyHostToDevice));
    HIP_CHECK(hipMemcpy(d_b, h_b, bytes, hipMemcpyHostToDevice));

    int block_size = 256;
    int grid_size = (n + block_size - 1) / block_size;
    vector_add<<<grid_size, block_size>>>(d_a, d_b, d_c, n);

    HIP_CHECK(hipMemcpy(h_c, d_c, bytes, hipMemcpyDeviceToHost));

    printf("HIP Vector Add: %s\n",
           verify(h_cpu, h_c, n) ? "PASS" : "FAIL");

    HIP_CHECK(hipFree(d_a));
    HIP_CHECK(hipFree(d_b));
    HIP_CHECK(hipFree(d_c));
    free(h_a);
    free(h_b);
    free(h_c);
    free(h_cpu);
    return 0;
}
