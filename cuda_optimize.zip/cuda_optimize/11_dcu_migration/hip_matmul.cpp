/*
 * hip_matmul.cpp — HIP 版矩阵乘法（朴素 + Tiled）
 *
 * 和 CUDA 的区别：
 *   头文件、API 前缀，kernel 语法完全一致
 *
 * wavefront=64 的影响：
 *   CUDA 中 warpSize=32，HIP 中 warpSize=64（DCU）
 *   会影响 warp-level 归约和 block_size 选择
 *   建议 block_size 选 64 的倍数
 *
 * 编译：hipcc -O2 -o hip_matmul hip_matmul.cpp
 */

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <hip/hip_runtime.h>

#define HIP_CHECK(call)                                                         \
    do {                                                                        \
        hipError_t err = call;                                                  \
        if (err != hipSuccess) {                                                \
            fprintf(stderr, "HIP error at %s:%d: %s\n", __FILE__, __LINE__,     \
                    hipGetErrorString(err));                                    \
            exit(EXIT_FAILURE);                                                 \
        }                                                                       \
    } while(0)

// 朴素版本：每个线程算一个元素
__global__ void matmul_naive(const float* A, const float* B, float* C,
                              int M, int N, int K) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}

// Tiled 版本：使用共享内存
template <int BLOCK_SIZE>
__global__ void matmul_tiled(const float* A, const float* B, float* C,
                              int M, int N, int K) {
    __shared__ float As[BLOCK_SIZE][BLOCK_SIZE];
    __shared__ float Bs[BLOCK_SIZE][BLOCK_SIZE + 1];  // +1 padding 避免 bank conflict

    int row = blockIdx.y * BLOCK_SIZE + threadIdx.y;
    int col = blockIdx.x * BLOCK_SIZE + threadIdx.x;

    float sum = 0.0f;
    int num_tiles = (K + BLOCK_SIZE - 1) / BLOCK_SIZE;

    for (int tile = 0; tile < num_tiles; ++tile) {
        if (row < M && tile * BLOCK_SIZE + threadIdx.x < K)
            As[threadIdx.y][threadIdx.x] = A[row * K + tile * BLOCK_SIZE + threadIdx.x];
        else
            As[threadIdx.y][threadIdx.x] = 0.0f;

        if (tile * BLOCK_SIZE + threadIdx.y < K && col < N)
            Bs[threadIdx.y][threadIdx.x] = B[(tile * BLOCK_SIZE + threadIdx.y) * N + col];
        else
            Bs[threadIdx.y][threadIdx.x] = 0.0f;

        __syncthreads();

        for (int k = 0; k < BLOCK_SIZE; ++k) {
            sum += As[threadIdx.y][k] * Bs[k][threadIdx.x];
        }
        __syncthreads();
    }

    if (row < M && col < N) {
        C[row * N + col] = sum;
    }
}

int main() {
    int M = 1024, N = 1024, K = 1024;
    size_t size_A = M * K * sizeof(float);
    size_t size_B = K * N * sizeof(float);
    size_t size_C = M * N * sizeof(float);

    float *h_A = (float*)malloc(size_A);
    float *h_B = (float*)malloc(size_B);
    float *h_C = (float*)malloc(size_C);

    for (int i = 0; i < M*K; ++i) h_A[i] = (float)rand()/RAND_MAX;
    for (int i = 0; i < K*N; ++i) h_B[i] = (float)rand()/RAND_MAX;

    float *d_A, *d_B, *d_C;
    HIP_CHECK(hipMalloc(&d_A, size_A));
    HIP_CHECK(hipMalloc(&d_B, size_B));
    HIP_CHECK(hipMalloc(&d_C, size_C));
    HIP_CHECK(hipMemcpy(d_A, h_A, size_A, hipMemcpyHostToDevice));
    HIP_CHECK(hipMemcpy(d_B, h_B, size_B, hipMemcpyHostToDevice));

    dim3 block(16, 16);
    dim3 grid((N+15)/16, (M+15)/16);
    matmul_naive<<<grid, block>>>(d_A, d_B, d_C, M, N, K);
    HIP_CHECK(hipGetLastError());
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipMemcpy(h_C, d_C, size_C, hipMemcpyDeviceToHost));
    printf("Naive matmul done. First element: %f\n", h_C[0]);

    // Tiled 32
    dim3 block32(32, 32);
    dim3 grid32((N+31)/32, (M+31)/32);
    matmul_tiled<32><<<grid32, block32>>>(d_A, d_B, d_C, M, N, K);
    HIP_CHECK(hipGetLastError());
    HIP_CHECK(hipDeviceSynchronize());
    HIP_CHECK(hipMemcpy(h_C, d_C, size_C, hipMemcpyDeviceToHost));
    printf("Tiled matmul (32) done. First element: %f\n", h_C[0]);

    HIP_CHECK(hipFree(d_A));
    HIP_CHECK(hipFree(d_B));
    HIP_CHECK(hipFree(d_C));
    free(h_A);
    free(h_B);
    free(h_C);

    printf("HIP matmul: PASS\n");
    return 0;
}
