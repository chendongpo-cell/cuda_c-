# 推理优化技术发展史与关联图谱

> 本文梳理推理优化领域各项技术的来龙去脉、演化关系、以及为什么一个技术会催生另一个技术。
> 读完本文你将理解：`为什么 PagedAttention 会出现？FlashAttention 解决了什么问题？DCU 移植难在哪？`

---

## 目录

1. [技术全景总览](#1-技术全景总览)
2. [Transformer + Attention（2017）：一切的起点](#2-transformer--attention2017一切的起点)
3. [KV Cache（2018-2019）：推理优化的第一个突破](#3-kv-cache2018-2019推理优化的第一个突破)
4. [MHA → MQA → GQA（2019-2023）：压缩 KV Cache](#4-mha--mqa--gqa2019-2023压缩-kv-cache)
5. [PagedAttention + vLLM（2023.06）：显存管理革命](#5-pagedattention--vllm202306显存管理革命)
6. [Continuous Batching（2023）：动态调度](#6-continuous-batching2023动态调度)
7. [FlashAttention（2022-2023）：算法层面的 IO 优化](#7-flashattention2022-2023算法层面的-io-优化)
8. [量化技术（2020-2024）：更激进的精度压缩](#8-量化技术2020-2024更激进的精度压缩)
9. [SGLang + RadixAttention（2024.01）：前缀树管理](#9-sglang--radixattention202401前缀树管理)
10. [DCU/HIP 适配（2024-2025）：国产化的挑战](#10-dcuhip-适配2024-2025国产化的挑战)
11. [完整技术关联图谱](#11-完整技术关联图谱)
12. [核心结论](#12-核心结论)

---

## 1. 技术全景总览

```
2017  Transformer 诞生
  │
  ├── Attention is All You Need（原始 Scaled Dot-Product Attention）
  │    └── 问题：Score 矩阵 O(n²)，显存爆炸
  │
  ├── 训练时优化 → 推理时复用
  │    ├── KV Cache（2018-2019） ─── 不重复算已生成的 K/V
  │    └── MHA → MQA → GQA（2019-2023）── 减少 KV head 数量，压缩 cache
  │
  ├── 显存管理革命
  │    ├── PagedAttention（vLLM, 2023.06）── 像操作系统分页管理显存
  │    └── 催生 Continuous Batching ─── 动态调度多请求的 KV cache
  │
  ├── 算法优化：FlashAttention（2022-2023）
  │    ├── FlashAttention-1（2022.05）── IO-aware tiling，省显存
  │    ├── FlashAttention-2（2023.06）── 减少 non-matmul，加速
  │    └── triton 实现 ─── 不写 CUDA 也能写高性能 kernel
  │
  ├── 低精度计算：量化
  │    ├── INT8 量化（2020-2021）─ 模型减半
  │    ├── AWQ/GPTQ（2023）────── 训练后量化，几乎不损精度
  │    ├── KV Cache 量化（2024） ── KIVI/KVQuant，压缩 cache 大小
  │    └── FP8（2024-2025）────── H100 原生支持
  │
  └── 推理框架集成
       ├── vLLM（2023.06）── PagedAttention + Continuous Batching
       ├── SGLang（2024.01）── RadixAttention + 前端编程语言
       └── DCU/HIP 移植 ──── 把以上全部搬到国产硬件
```

---

## 2. Transformer + Attention（2017）：一切的起点

**论文**：Attention is All You Need (Vaswani et al., 2017)

### 核心公式

```
Attention(Q, K, V) = softmax(Q × K^T / √d) × V
```

其中：
- Q（Query）：当前 token 的查询向量
- K（Key）：所有 token 的键向量
- V（Value）：所有 token 的值向量
- d：head dimension

### 当时没人预料到的问题

Standard Attention 的计算流程：

```
Q × K^T  →  得到 N×N 的 Score 矩阵（显存 O(n²)）
  ↓
Softmax  →  Score 矩阵上的归一化
  ↓
× V       →  最终输出
```

**Score 矩阵的大小**：

| 序列长度 N | Score 矩阵（FP16, H=32） | 能不能装下 |
|:----------:|:------------------------:|:----------:|
| 4096 | 1 × 32 × 4096² × 2B = **1 GB** | ✅ A100 能装 |
| 8192 | **4 GB** | ✅ |
| 16384 | **16 GB** | ⚠️ 开始紧张 |
| 32768 | **64 GB** | ❌ A100 都装不下 |
| 65536 | **256 GB** | ❌ 完全不可能 |

### 它催生了什么

1. **KV Cache**（推理时避免重复算 Attention）
2. **FlashAttention**（不显式构建 Score 矩阵）
3. **PagedAttention**（更高效地管理 KV Cache 的显存）

---

## 3. KV Cache（2018-2019）：推理优化的第一个突破

### 解决的问题

推理是逐 token 生成的（自回归）。在没有 KV Cache 时，生成第 t 个 token 需要**从 token 1 到 token t 重新算一遍**。

```
没有 KV Cache：
  生成 token 1: Attention([t1])
  生成 token 2: Attention([t1, t2])    ← 重复算了 t1 的 KV
  生成 token 3: Attention([t1, t2, t3]) ← 重复算了 t1, t2 的 KV
  ...
  生成 token 100: Attention([t1...t100]) ← 重复算了 99 次前面的 KV！
  计算量 = O(n²) ← 无法接受！
```

### 核心洞察

在 Decode 阶段，每个 token 的 **Key 和 Value 只依赖于自己**，不依赖于后面的 token。

所以：
- 第 t 步的 K、V → 存下来
- 第 t+1 步时 → 直接读 cache 中的 K、V，和新 token 的 Q 做 Attention
- **不需要重复算之前的 KV**

```
有 KV Cache：
  生成 token 1: 算 KV1，存入缓存
  生成 token 2: 读 KV1 + 新算 KV2，存入缓存  ← KV1 复用
  生成 token 3: 读 KV1+KV2 + 新算 KV3         ← KV1, KV2 复用
  ...
  生成 token 100: 读 KV1...KV99 + 新算 KV100  ← 前面 99 个复用
  每步计算量 ≈ O(1)（不随序列长度增长）
```

### 显存公式

```
KV Cache 显存 = 2 × num_layers × num_heads × seq_len × d_head × bytes_per_elem

示例（LLaMA-7B, FP16）：
  = 2 × 32 × 32 × 4096 × 128 × 2
  = 2,147,483,648 bytes
  ≈ 2 GB（32K 上下文时 ≈ 16 GB）
```

### 带来的新问题

KV Cache 很大，而且每个请求都需要**一块连续显存**来存。这直接导致了 **PagedAttention** 的诞生。

### 演化关系

```
没有 KV Cache → Decode 每步 O(n²) 计算量，根本没法用
有 KV Cache  → Decode 每步 O(n)，但显存占用大
需要优化     → PagedAttention + KV Cache 量化 + FlashAttention
```

---

## 4. MHA → MQA → GQA（2019-2023）：压缩 KV Cache

### MHA（Multi-Head Attention, 2017）

原始 Transformer 的设计：每个 head 有独立的 Q、K、V。

```
MHA（32 Q head × 32 KV head）：
  每个 Q head 看到不同的 "视角"
  每个 KV head 也对应不同的视角
  → 模型容量大，但 KV Cache 也大
  → KV Cache = 2 × L × 32 × S × D × 2
```

### MQA（Multi-Query Attention, 2019）

Google 在 T5 中提出：所有 Q head **共享一组 K、V**。

```
MQA（32 Q head × 1 KV head）：
  32 个 Q head 共享同一组 Key 和 Value
  → KV Cache 减小到 1/32
  → 但精度有损失（表达能力下降）
```

### GQA（Grouped Query Attention, 2023）

折中方案，LLaMA-2 70B 首次使用，现已成为业界标准。

```
GQA-8（32 Q head × 8 KV head）：
  Q heads:   0-3  4-7  8-11  ... 28-31  （分 8 组）
  KV heads:    0    1    2    ...   7     （每组共享一个 KV head）
  → KV Cache 是 MHA 的 1/4
  → 精度接近 MHA
```

### 当前现状

几乎所有新模型都用 GQA：
- LLaMA-2 70B：GQA-8
- LLaMA-3 系列：GQA-8
- Qwen2 系列：GQA
- DeepSeek-V2：GQA + MLA（更激进）

### 演化关系

```
MHA（大 KV Cache，精度最好）
  ↓ 显存不够用
MQA（小 KV Cache，精度稍差）
  ↓ 需要平衡
GQA（现在的主流选择，精度 vs 显存的折中）
  ↓ 但光压缩 head 数不够，还需要 PagedAttention 管理显存
```

---

## 5. PagedAttention + vLLM（2023.06）：显存管理革命

### 历史背景

2023 年 6 月，UC Berkeley 团队在 SOSP 发布论文并开源 vLLM。

### 解决的核心问题

传统 KV Cache 管理方式有三大问题：

```
问题 1：需要连续显存
  每个请求的 KV Cache 必须存在一块连续区域
  → 显存碎片化严重（已分配但无法使用）
  → 实测浪费 60%+ 显存

问题 2：预分配浪费
  预分配最大序列长度的显存
  → 实际只用了一部分（大部分被闲置）

问题 3：无法共享
  两个请求的 System Prompt 相同
  → 各自存一份，浪费
```

### PagedAttention 的核心创新

像操作系统分页管理内存一样管理 KV Cache：

```
┌────────────────────────────────────────────────────┐
│                   逻辑视角                           │
│  请求 A 的 KV Cache = Block 0, Block 1, ..., Block N│
│  (逻辑上连续的 block 序列)                           │
└──────────────────────┬─────────────────────────────┘
                       │ Block Table（页表）映射
                       ▼
┌────────────────────────────────────────────────────┐
│                   物理视角                           │
│  显存中的 block 可以不连续！                          │
│  Block 0 → 物理 Block 5                              │
│  Block 1 → 物理 Block 17                             │
│  Block 2 → 物理 Block 3                              │
│  ...                                                 │
└────────────────────────────────────────────────────┘
```

**关键技术**：

1. **Block Table（页表）**：记录逻辑 block → 物理 block 映射
2. **Copy-on-Write**：共享 block 在写时才复制
3. **Prefix Caching**：相同前缀的请求共享 block

### 性能提升

```
传统管理方式：
  显存利用率 40% → 只能处理 16 个请求

PagedAttention：
  显存利用率 95%+ → 可处理 30+ 请求
  吞吐量提升 2-4x
```

### 出现的必然性

```
Transformer 推理 →
  每个请求要 1~几十 GB KV Cache →
    连续分配 → 碎片 ≥ 60% 浪费 →
      操作系统已经解决过这个问题（分页）→
        "为什么不把分页用在 KV Cache 上？"
```

---

## 6. Continuous Batching（2023）：动态调度

### 背景

PagedAttention 出来后，显存管理灵活了，调度就可以更激进。

### Static Batching vs Continuous Batching

```
Static Batching（2022 之前）：
  ┌──────────────────────┐
  │  请求 A  B  C  同时来  │
  │  ┌───┐               │
  │  │ A │               │
  │  │ B │  → 全部完成后  │
  │  │ C │     才处理下一批│
  │  └───┘               │
  └──────────────────────┘
  问题：A 很短却要等 C 完成
         GPU 利用率不稳定

Continuous Batching（vLLM, 2023）：
  ┌──────────────────────┐
  │  A 来了 → 开始处理    │
  │  B 来了 → 加入正在跑的│
  │  A 完成了 → 移除      │
  │  C 来了 → 加入        │
  │  D 来了 → 加入        │
  └──────────────────────┘
  效果：GPU 一直满载，利用率 90%+
```

### PagedAttention 和 Continuous Batching 的配合

```
PagedAttention 让显存可以动态分配
  ↓
Continuous Batching 让调度可以动态进行
  ↓
两个配合：
  请求来了 → 分配 block → 加入计算 → 完成 → 释放 block
  整个过程连续、无中断
```

---

## 7. FlashAttention（2022-2023）：算法层面的 IO 优化

### 背景

Standard Attention 需要把 N×N 的 Score 矩阵**完整写到显存（HBM）** 中再读回来。

```
Standard Attention 的 IO 流程：
  1. 从 HBM 读 Q, K 到 SRAM（片上缓存）
  2. Q×K^T → Score 矩阵（写回 HBM）        ← 慢！
  3. 从 HBM 读 Score → Softmax
  4. Softmax → Attention Weights（写回 HBM） ← 慢！
  5. 从 HBM 读 Weights 和 V
  6. Weights × V → Output（写回 HBM）
  
  每步都要读写 HBM（延迟 ~400 cycles）
  Score 矩阵 N×N → 瓶颈
```

### FlashAttention 的核心洞察

GPU 的内存层次（速度从快到慢）：

```
SRAM（片上缓存）：19 TB/s，20 MB     ← 快但小
HBM（显存）：     1.5 TB/s，80 GB    ← 大但慢

差距：SRAM 比 HBM 快 10-15x！
```

如果能把计算拆成小块，**在 SRAM 中完成全部操作**，就能避免 HBM 的瓶颈。

### FlashAttention-1（2022.05，Stanford）

**核心思想**：IO-aware tiling

```
1. 把 Q、K、V 切成小块（tile）
2. 每次加载一个 Q-tile 和一个 K-tile 到 SRAM
3. 在 SRAM 中算局部 Score，做局部 Softmax
4. 用 Online Softmax 合并不同 tile 的结果
5. 完全不写 Score 矩阵到 HBM！
```

**效果**：
- HBM 读写从 O(N²) 降到 O(N)
- 速度 2-4x 加速
- 显存占用从 O(N²) 降到 O(N)

### FlashAttention-2（2023.06）

**改进**：
1. 减少 non-matmul 操作（Softmax、rescale 等）
2. 更好地利用 Tensor Core
3. 更好的并行化策略

**效果**：比 FA-1 再快约 2x

### 关联到其他技术

```
FlashAttention 优化了 Attention 计算本身
  ↓
但推理中 Decode 阶段的瓶颈是 KV Cache 读（不是算）
  ↓
FlashAttention 对 Prefill 加速明显（计算密集型）
FlashAttention 对 Decode 加速有限（访存密集型）
  ↓
所以 FlashAttention 和 KV Cache 量化互补：
  FlashAttention 优化 Prefill
  量化优化 Decode 和显存占用
```

---

## 8. 量化技术（2020-2024）：更激进的精度压缩

### 本质

用更少的 bit 表示模型参数和中间结果，换取速度提升和显存节省。

### 精度格式演进

```
FP32（32bit）：原始精度
  ┃ 训练发现可以用更少 bit
FP16（16bit）：主流推理精度，显存减半
  ┃ 推理对精度要求更低
INT8（8bit）：显存再减半，速度 2-4x（有 Tensor Core）
  ┃ 但简单量化掉精度
AWQ/GPTQ（INT4, 2023）：训练后量化，几乎不损精度
  ┃ KV Cache 太大怎么办？
KIVI/KVQuant（2024）：KV Cache 量化到 INT4/FP8
  ┃
FP8（2024-2025）：H100 原生支持
```

### 各类量化方法对比

| 方法 | 精度 | 方式 | 是否需要训练 | 精度损失 |
|------|:----:|:----:|:----------:|:--------:|
| 普通 INT8 量化 | INT8 | 直接映射 | 否 | 中 |
| AWQ | INT4 | 保留 1% 重要通道为 FP16 | 否（需校准集） | 低 |
| GPTQ | INT4 | 基于 Hessian 矩阵做补偿 | 否（需校准集） | 低 |
| SmoothQuant | INT8 | 平滑异常值 | 否（需校准集） | 低 |
| KIVI | INT4 KV Cache | 按通道量化 KV Cache | 否 | 低 |
| FP8 推理 | FP8 | H100 原生支持 | 可选 | 极低 |

### 和 DCU 的特殊关联

```
NVIDIA A100：有 Tensor Core
  FP16 = 312 TFLOPS
  INT8 = 624 TOPS
  FP8  = 1248 TOPS（H100）
  → 量化后速度翻倍

DCU K100：无 Tensor Core
  FP16 = 40 TFLOPS
  INT8 = 80 TOPS
  → 量化后速度只翻倍，还是比 A100 差很多

结论：
  DCU 上 INT8 量化是必须的（不量化更慢）
  但量化了也只是勉强解决显存问题
  速度差距仍然很大
```

---

## 9. SGLang + RadixAttention（2024.01）

### 背景

vLLM 火了以后，大家发现 PagedAttention 有一个问题：前缀共享不够高效。

### vLLM 的 Prefix Caching

vLLM 的 Prefix Caching 基于 block hash 匹配，匹配粒度是 block 级别。

```
请求 A: "System: 你是 AI 助手..." + "中国的首都是什么？"
请求 B: "System: 你是 AI 助手..." + "地球的半径是多少？"
                                  
两个请求共享：System Prompt 部分（但基于 block hash 匹配）
如果 block_size=16，且不同请求的划分边界不同 → 无法共享
```

### SGLang 的 RadixAttention

用**前缀树（trie）**管理 KV Cache：

```
                  "System: 你是 AI 助手"
                          |
                    "中国的首都是"
                   /              \
              "什么？"           "北京吗？"
                ↓                  ↓
           请求 A 的后续       请求 B 的后续
           
  新请求 "System: 你是 AI 助手 + 法国的首都是"
  → 直接从 "System: 你是 AI 助手" 开始共享
  → 无需重新计算 System Prompt 的 KV Cache！
```

### 两者对比

| 特性 | PagedAttention（vLLM） | RadixAttention（SGLang） |
|------|:-------------------:|:---------------------:|
| 数据结构 | 页表（Block Table） | 前缀树（Trie） |
| 共享粒度 | Block 级别 | Token 级别 |
| 适用场景 | 通用推理 | 多轮对话、system prompt 长 |
| 实现复杂度 | 较低 | 较高 |
| LRU 淘汰 | 无（仅 FIFO） | 原生 LRU |

**现状**：两者不冲突，最新的 vLLM V1 在吸收 RadixAttention 的思路。

---

## 10. DCU/HIP 适配（2024-2025）：国产化的挑战

### 背景

NVIDIA GPU 被限制出口，中国需要国产替代。中科曙光的 Deep Computing Unit（DCU）就是其中之一。

### 问题

前面讲的所有技术（PagedAttention、FlashAttention、量化等）都是基于 **CUDA** 开发的，只能跑在 NVIDIA GPU 上。

### 曙光的工作

```
vLLM for NVIDIA GPU         vLLM for DCU
  ┌─────────────────┐         ┌──────────────────┐
  │ CUDA 代码        │         │ HIP 代码          │
  │ PagedAttention  │   →→    │ PagedAttention   │
  │ FlashAttention  │         │ (没有FA，需手写)  │
  │ cuBLAS (GEMM)   │         │ rocBLAS (GEMM)   │
  │ cuDNN           │         │ MIOpen           │
  │ NCCL (多卡)     │         │ RCCL (多卡)      │
  └─────────────────┘         └──────────────────┘
```

### DCU 的硬件局限

```
                       A100-80G      DCU K100      差距
  ┌──────────────────  ──────────    ──────────    ──────
  │ 显存              80 GB HBM2e   32 GB HBM2    40%
  │ 显存带宽          2 TB/s        1.2 TB/s      60%
  │ FP16 算力         312 TFLOPS    40 TFLOPS     13%
  │ Tensor Core       有            无             -
  │ 卡间互联          NVLink        PCIe 4.0      较慢
  └────────────────────────────────────────────────
```

### 三大挑战

**挑战 1：CUDA → HIP 迁移（中等难度）**
```
cudaMalloc  →  hipMalloc
cudaMemcpy  →  hipMemcpy
nvcc        →  hipcc

看起来差异很小，但：
  NVIDIA warp=32 vs DCU wavefront=64  ← 影响所有 warp-level 算法
  __shfl_down_sync(mask, val, s, 32) → __shfl_down(val, s, 64)
```

**挑战 2：无 Tensor Core（高难度）**
```
A100 上 FlashAttention 用 Tensor Core 加速
DCU 上没有 → 只能手写纯 CUDA Core 版本
性能差距 8x+

同样的问题出现在：
  FP16 GEMM（矩阵乘法）
  FP8 推理（完全不支持）
  INT8 矩阵乘（无硬件加速）
```

**挑战 3：显存少、带宽低（硬伤）**
```
32GB 显存
  模型 7B FP16 = 14GB
  剩下 18GB 给 KV Cache
  32K 上下文都困难

1.2TB/s 带宽
  Decode 阶段是 memory-bound
  带宽低 = Decode 慢
```

### 曙光的技术重点

```
在 DCU 上推理，优化链是断裂的：

A100 上的全链路优化：
  FP16 Attention → FlashAttention（Tensor Core加速）
  KV Cache FP16 → 显存够用（80GB）
  → 所有优化都很顺畅

DCU 上的受限链路：
  FP16 Attention → 没有 FA（无 Tensor Core）
  KV Cache FP16 → 32GB 不够 → 必须 INT8 量化
  但 INT8 GEMM 也慢（无硬件加速）
  → 优化空间窄

所以曙光核心工作：
  1. CUDA→HIP 代码移植（基础工作）
  2. 小模型推理（1-2B，不是 70B）
  3. 量化技术适配（没量化跑不了长上下文）
  4. 算子融合（减少 kernel launch 开销）
```

---

## 11. 完整技术关联图谱

```
                   Transformer (2017)
                         │
                    Attention 机制
                  ┌──────┴──────┐
                  │             │
            计算优化         显存优化
                  │             │
        ┌─────────┼──┐     ┌───┴────┐
        │         │  │     │        │
   FlashAttn  INT8  FP8  KV     MHA→MQA
   (省显存)  量化   量化  Cache  →GQA
        │         │  │     │        │
        └────┬────┘  │     └──┬─────┘
             │       │        │
        Custom Kernel    PagedAttention
        (Triton手写)       (分页管理)
                              │
                     ┌────────┴────────┐
                     │                 │
               Continuous         Prefix
               Batching          Caching
               (调度)          (前缀共享)
                     │                 │
                     └──────┬──────────┘
                            │
                ┌───────────┴───────────┐
                │                       │
            vLLM 框架              SGLang 框架
                │                       │
                └───────────┬───────────┘
                            │
                    推理引擎部署
                            │
                ┌───────────┴───────────┐
                │                       │
          NVIDIA GPU (CUDA)       DCU (HIP)
          (原版，全功能)        (曙光，需移植)
```

---

## 12. 核心结论

1. **一切从 Attention 开始**
   - Attention 的 O(n²) 复杂度催生了所有优化技术
   - 无论是 KV Cache、FlashAttention 还是 PagedAttention，核心目标都是解决 Attention 带来的显存/计算问题

2. **KV Cache 是最重要的工程优化**
   - 没有 KV Cache，推理无法实用（每步 O(n²) 计算量）
   - 所有后续优化（PagedAttention、量化、GQA）都围绕 KV Cache 展开

3. **FlashAttention 是算法优化，PagedAttention 是工程优化**
   - 两者互补，解决不同层面的问题
   - FlashAttention 优化"怎么算更省显存"
   - PagedAttention 优化"怎么管理显存更高效"
   - FlashAttention 对 Prefill 加速明显，PagedAttention 影响整个推理吞吐

4. **量化和 KV Cache 压缩是 DCU 上的核心**
   - 因为没有 NVLink 和 Tensor Core，靠传统方法拼不过
   - INT8 量化是 DCU 推理的必需品，不是可选项
   - 小模型（1-2B）在 DCU 上更实用

5. **你入职曙光做的工作**
   - 把 NVIDIA 的推理技术栈从 CUDA 移植到 HIP/ROCm
   - 根据 DCU 的硬件特性（warp=64、无 Tensor Core、显存小）做适配
   - 核心任务：量化适配 + 算子移植 + 推理框架（vLLM）在 DCU 上的性能优化
