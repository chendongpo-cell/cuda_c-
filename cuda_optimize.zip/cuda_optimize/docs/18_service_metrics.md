# 推理服务指标与容量规划

> 这一章是"如何评估你的优化有没有用"。优化前后不挂指标，就是凭感觉调参；挂上指标，才能理性决策。
>
> 学习定位：**理解 TTFT / TPOT / 吞吐 / SLO 这四个核心指标，掌握 Little's Law，能根据硬件算出能扛多少并发**。
>
> 前置知识：[04_attention_kv_cache.md](04_attention_kv_cache.md)、[07_continuous_batching.md](07_continuous_batching.md)。

---

## 0. 一个真实场景

假设你部署了 Llama-3-70B 给 100 个客服客服同时使用，他们反馈"卡"。你怎么定位？

可能的原因：
1. 模型本身慢（kernel 没优化）
2. batch 太大（每个 token 等待调度）
3. KV Cache 不够（请求被 preempt）
4. 网络慢（首 token 等传输）
5. 调度策略问题（prefill 和 decode 抢资源）

光说"卡"无法定位。有了指标才能拆分：
- 如果 TTFT 高 → prefill 阶段慢或调度排队长
- 如果 TPOT 高 → decode 阶段慢或 batch 过大
- 如果吞吐低 → GPU 利用率不足
- 如果 P99 暴涨 → 有尾延迟问题（预热、抢占、GC）

**指标是把"慢"翻译成"哪里慢"的语言**。

---

## 1. 四个核心指标

### 1.1 TTFT（Time To First Token，首 token 延迟）

```
用户发送请求  ────────────────  收到第一个 token
                TTFT
```

**组成**：
- 网络延迟（请求到服务）
- 队列等待（请求在 continuous batcher 里排队）
- Prefill 计算（处理整个 prompt）
- 第一个 token 的 decode（生成第一个 token）

**为什么重要**：用户感知"快不快"的关键。聊天场景下 TTFT > 1s 用户就觉得卡。

**典型 SLO**：
- 对话：TTFT < 500ms
- 助手：TTFT < 1s
- 后台批处理：TTFT 不敏感

**优化手段**：
- Prefill 优化：Flash Attention、Chunked Prefill
- 减少队列等待：调度策略优化
- Prefix Caching：复用 system prompt 的 KV

### 1.2 TPOT（Time Per Output Token，单 token 延迟）

```
第 i 个 token  ────────  第 i+1 个 token
                TPOT
```

**定义**：decode 阶段每生成一个 token 的平均时间。

**为什么重要**：决定用户看到文字流的速度。TPOT > 50ms 用户会觉得"打字慢"。

**典型 SLO**：
- 对话：TPOT < 50ms（每秒 20 token）
- 流式代码生成：TPOT < 100ms

**注意**：TPOT 不包括 prefill 时间。`总延迟 = TTFT + (生成长度 - 1) × TPOT`。

**优化手段**：
- 算子优化：Flash Attention、TensorCore
- 投机解码（[16_speculative_decoding.md](16_speculative_decoding.md)）
- PD 分离（[15_distributed_inference.md](15_distributed_inference.md)）
- 量化（INT8/FP8）

### 1.3 吞吐（Throughput）

两种度量：

**Output Token Throughput**（最常用）：
```
吞吐 = 总输出 token 数 / 总时间
单位: tokens/s
```

**Request Throughput**：
```
吞吐 = 完成请求数 / 总时间
单位: requests/s
```

**为什么重要**：决定单 GPU 能服务多少用户，直接影响成本。

**优化手段**：
- Continuous Batching（提高 batch 大小）
- 多卡并行
- 量化（减少显存压力，提高 batch）

### 1.4 显存利用率（GPU Memory Utilization）

```
已用显存 / 总显存
```

包括：
- 模型权重
- KV Cache
- 激活
- 临时 buffer

**vLLM 默认 `gpu_memory_utilization=0.9`**：留 10% 给临时 buffer 和 CUDA context。

---

## 2. 延迟分布：看均值不够

### 2.1 为什么看 P50/P99

假设 100 个请求：
- P50（中位数）= 50ms
- P99 = 500ms
- Max = 2000ms

**用户体验的真相在 P99 / Max**：100 个用户里总有一个等 2 秒，他觉得卡，差评。

工业界 SLO 通常用 P99 或 P99.9：
- "TPOT P99 < 50ms" 才算达标

### 2.2 尾延迟的来源

- 抢占（preemption）：KV Cache 不够时把请求踢出
- GC（Garbage Collection）：Python 侧 GC 卡顿
- 调度抖动：batch 突然变大
- 网络抖动
- 硬件变慢（thermal throttling）

### 2.3 优化尾延迟

- 减少抢占：增大 KV Cache 空间（量化 KV、更大显存）
- 用 C++ 重写关键路径（减少 Python GC）
- PD 分离（隔离 prefill 和 decode）
- 请求级 QoS（VIP 请求优先）

---

## 3. Little's Law — 容量规划的基石

### 3.1 公式

```
L = λ × W

L: 系统中平均请求数（在途）
λ: 请求到达速率（requests/s）
W: 平均每个请求的处理时间（s）
```

**直觉**：水管里同时有多少水 = 流量 × 水通过水管的时间。

### 3.2 推理服务的应用

假设：
- 用户请求到达速率 λ = 10 req/s
- 每个请求平均生成 200 token
- TPOT = 50ms

每个请求的处理时间 W ≈ 200 × 50ms = 10s。
系统中同时处理的请求数 L = 10 × 10 = **100 个请求**。

**含义**：要支持这个负载，continuous batcher 需要能同时容纳 100 个并发请求。

### 3.3 反向算容量

我有 8 卡 A100 跑 Llama-70B：
- 单卡 batch 上限假设 32（受 KV Cache 限制）
- 8 卡 TP=8，整体 batch 上限 = 32（TP 共享 batch）
- TPOT = 50ms
- 每个请求平均 200 token → W = 10s

L_max = 32，所以 λ_max = L / W = 32 / 10 = 3.2 req/s。

如果用户实际 λ = 5 req/s，就过载了，需要扩容。

### 3.4 吞吐和延迟的权衡

```
吞吐 ↑ 通常需要 batch ↑
batch ↑ 导致 TPOT ↑（每 token 慢）
```

存在"延迟约束下的最大吞吐"：在 TPOT ≤ 50ms 的约束下，最大 batch 是多少？这是真实部署要解的问题。

---

## 4. KV Cache 容量计算

### 4.1 公式

对于 L 层、H 个头、每头 d 维、batch B、seq S、FP16（2 bytes）：

```
KV Cache 大小 = 2 (K+V) × L × B × S × H × d × 2 bytes
```

**简化记忆**：Llama-70B 单 token KV Cache ≈ 320KB（FP16）。

### 4.2 实际容量估算

A100 80GB，Llama-70B FP16 占 140GB → 单卡放不下，至少要 2 卡 TP。
TP=2 后每卡权重 70GB，剩 10GB 给 KV Cache。

每 token KV Cache ≈ 160KB（TP=2 减半）。
10GB / 160KB = **62500 token**。

按每请求 2K context 算，能支持 30 个并发请求。

如果量化 KV 到 INT8：容量翻倍 → 60 并发。

### 4.3 PagedAttention 的影响

[06_paged_attention.md](06_paged_attention.md) 的分页让 KV 碎片减少，但总容量公式不变。优势是"能装更多请求"而非"装更多 token"。

---

## 5. SLO（Service Level Objective）

### 5.1 常见 SLO 模板

```
服务等级 SLO:
  可用性: 99.9% 请求能成功返回
  TTFT P99: < 800ms
  TPOT P99: < 50ms
  完成延迟 P99: < 5s (常见对话长度)
```

### 5.2 SLO 驱动的优化决策

每个优化都对应一个 SLO 维度：

| 优化 | 影响 SLO |
|------|---------|
| Flash Attention | TTPT ↓, TPOT ↓ |
| Chunked Prefill | TTFT ↓（长 prompt） |
| Prefix Caching | TTFT ↓（重复 prefix） |
| 投机解码 | TPOT ↓ |
| PD 分离 | TTFT ↓, TPOT ↓ |
| 量化 | TPOT ↓, 显存 ↓（→ batch ↑ → 吞吐 ↑） |
| Continuous Batching | 吞吐 ↑ |
| 优化调度策略 | P99 ↓ |

### 5.3 容量规划流程

1. 确定 SLO（TTFT/TPOT P99 上限）
2. 用 Little's Law 算最大并发 L
3. 算 KV Cache 容量是否够 L 个请求
4. 测试实际 batch 在 SLO 约束下的 TPOT
5. 反推单 GPU 能扛多少 qps
6. 除以用户 qps 得到 GPU 数量

---

## 6. Benchmark 方法论

### 6.1 用 vLLM 自带 benchmark

```bash
# 启动服务
vllm serve meta-llama/Llama-3-8B --port 8000

# 运行 benchmark
python -m vllm.entrypoints.openai.benchmark_serving \
    --backend vllm \
    --base-url http://localhost:8000 \
    --model meta-llama/Llama-3-8B \
    --dataset-name random \
    --random-input-len 1024 \
    --random-output-len 256 \
    --num-prompts 1000
```

输出会包含：
- Successful requests
- Total token throughput
- TTFT mean / P50 / P99
- TPOT mean / P50 / P99

### 6.2 用 SGLang 的 benchmark

```bash
python -m sglang.bench_serving \
    --backend sglang \
    --port 30000 \
    --model meta-llama/Llama-3-8B \
    --dataset-name random \
    --random-input-len 1024 \
    --random-output-len 256 \
    --num-prompts 1000
```

### 6.3 负载模式

不同负载模式测不同维度：

| 负载模式 | 测什么 |
|---------|-------|
| 单请求短 prompt | 纯 decode 性能 |
| 单请求长 prompt | Prefill 性能 |
| 低并发长输出 | 单请求稳定性 |
| 高并发短输出 | 吞吐 + 调度 |
| 高并发长输出 | KV Cache 容量 |
| 混合（不同长度） | 真实场景 |

### 6.4 关键观察点

跑完 benchmark 别只看平均吞吐，要看：
1. **P99 延迟** 是否在 SLO 内
2. **吞吐曲线**（qps 增加时延迟何时暴涨）→ 找到拐点
3. **GPU 利用率**（`nvidia-smi dmon`）是否吃满
4. **显存使用** 是否接近上限
5. **抢占次数**（vLLM 有 metric）

---

## 7. 监控指标体系

### 7.1 vLLM 的 Prometheus metrics

```
vllm:num_requests_running        # 正在 decode 的请求数
vllm:num_requests_waiting        # 排队中的请求数
vllm:num_requests_swapped        # 被换出的请求数
vllm:gpu_cache_usage_perc        # KV Cache 使用率
vllm:num_preemption              # 抢占次数
vllm:e2e_request_latency_seconds # 端到端延迟
vllm:time_to_first_token_seconds # TTFT
vllm:time_per_output_token_seconds # TPOT
```

### 7.2 关键告警

- `vllm:num_requests_waiting > 50` → 排队过多，扩容
- `vllm:num_preemption rate > 0` → KV Cache 不够
- `vllm:gpu_cache_usage_perc > 0.9` → 显存快满
- `TTFT P99 > SLO` → prefill 瓶颈

---

## 8. 一个完整的容量规划示例

**场景**：用 Llama-3-70B 服务客服助手，预计 50 个并发用户。

**输入数据**：
- 平均 prompt 长度：1K token
- 平均输出长度：200 token
- SLO: TTFT P99 < 1s, TPOT P99 < 80ms

**步骤 1：算 KV Cache 需求**

Llama-70B 单 token KV Cache ≈ 320KB（FP16）。
50 并发 × (1K + 200) × 320KB = **19.2 GB**

加上权重 140GB → 单卡 80GB 装不下。需要 TP。

**步骤 2：选 TP 数**

TP=2：权重 70GB/卡，剩 10GB/卡 → KV 容量 20GB（INT8 量化后）→ 够 50 并发。

**步骤 3：估算 TPOT**

Llama-70B 在 A100 TP=2 上跑 decode，batch=50 的 TPOT 大约 60-80ms（实测）→ 在 SLO 内。

**步骤 4：估算 TTFT**

Prefill 1K token 在 A100 TP=2 上约 200-400ms → 在 SLO 内。

**结论**：2 卡 A100 够用。

**步骤 5：验证**

实际跑 benchmark，看 P99 是否达 SLO。如果 P99 暴涨，再扩容或优化。

---

## 9. 学习路径建议

1. **跑 vLLM 的 benchmark_serving** → 拿到真实数据
2. **手算一次容量规划**（上面的例子）
3. **改 batch 看 TPOT 变化** → 体验延迟-吞吐权衡
4. **监控 vLLM 的 Prometheus 指标** → 看真实运行状态
5. **对比不同优化开关**：开/关 prefix caching、开/关投机解码，看指标变化

---

## 10. 常见误区

1. **"吞吐越高越好"** — 错。超出 SLO 约束的吞吐没意义，延迟暴涨时再高的吞吐也不可服务。
2. **"看平均延迟够了"** — 错。P99 才是用户体验。
3. **"batch 越大吞吐越高"** — 有上限。超过后 KV Cache 溢出，抢占，反而降。
4. **"显存用满就好"** — 错。要留 buffer 给临时分配，否则 OOM。
5. **"加卡总能解决"** — 错。TP 超过 NVLink 域后通信开销暴增，可能反而变慢。

---

## 11. 速查表

| 指标 | 单位 | 典型 SLO | 主要影响因素 |
|------|------|---------|------------|
| TTFT | ms | < 500-1000 | Prefill 速度、队列长度、Prefix Cache |
| TPOT | ms | < 50-100 | Decode 速度、batch 大小 |
| 完成延迟 | s | < 5-10 | TTFT + (输出长度-1) × TPOT |
| 吞吐 | tokens/s | 看场景 | batch、并行度、算子优化 |
| P99 | - | 用户感知 | 抢占、调度、GC |
| 显存利用率 | % | 85-90% | 权重 + KV Cache + buffer |
| GPU 利用率 | % | > 80% | batch、kernel 效率 |

**Little's Law**：`L = λ × W`（并发 = 速率 × 处理时间）

**容量公式**：`最大并发 ≈ KV Cache 总容量 / (单 token KV × 平均序列长度)`
