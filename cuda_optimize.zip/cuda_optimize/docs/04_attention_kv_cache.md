# 第4周：注意力机制与 KV Cache — 推理优化方向

> 目标：透彻理解 Scaled Dot-Product Attention 的实现和性能特征，掌握 KV Cache 的显存模型和推理循环设计，为阅读 vLLM PagedAttention 源码打好基础。
> 预计时间：周均 7h（每天 ~1h）

---

## 目录

1. [Standard Attention 数学原理](#1-standard-attention-数学原理)
2. [PyTorch 实现与复杂度分析](#2-pytorch-实现与复杂度分析)
3. [KV Cache 原理](#3-kv-cache-原理)
4. [Prefill vs Decode 阶段](#4-prefill-vs-decode-阶段)
5. [推理场景中的 Attention](#5-推理场景中的-attention)
6. [面试考点](#6-面试考点)
7. [配套实例](#7-配套实例)

---

## 1. Standard Attention 数学原理

### 1.1 公式

Scaled Dot-Product Attention（Vaswani et al., 2017）：

```
Attention(Q, K, V) = softmax(Q × K^T / √d_k) × V

其中：
  Q: [batch, heads, seq_q, d_k] — Query
  K: [batch, heads, seq_k, d_k] — Key  
  V: [batch, heads, seq_v, d_v] — Value（seq_v = seq_k）
  d_k: head dimension
  √d_k: scaling factor，防止 softmax 进入梯度饱和区
```

### 1.2 计算过程分解

```
Step 1: Score = Q × K^T            // [B, H, Sq, Sk] — O(Sq × Sk × d_k)
Step 2: Scale = Score / √d_k        // 防止 softmax 梯度消失
Step 3: Weights = softmax(Scale)    // 在 Sk 维度上做 softmax
Step 4: Output = Weights × V        // [B, H, Sq, d_v]

计算量 = O(Sq × Sk × d_k + Sq × Sk × d_v)
内存  = O(B × H × Sq × Sk)         // Score 矩阵！这是 O(n²) 的根源
```

### 1.3 复杂度分析

| 阶段 | 计算量 (FLOPs) | 显存 (bytes) |
|------|----------------|--------------|
| Q@K^T | 2 × B × H × Sq × Sk × d_k | — |
| Softmax | B × H × Sq × Sk | — |
| P@V | 2 × B × H × Sq × Sk × d_v | — |
| Score 矩阵 | — | B × H × Sq × Sk × 2 (FP16) |
| Output | — | B × H × Sq × d_v × 2 |

**核心问题**：Sq × Sk 项！当序列长度 n 增长时，计算量和显存都是 O(n²) 增长。这就是 FlashAttention 要解决的核心问题。

**示例**（B=1, H=32, D=128, FP16）：
- Sq=4096, Sk=4096：Score 矩阵 = 1 × 32 × 4096² × 2B = **1GB**
- Sq=32768, Sk=32768：Score 矩阵 = 1 × 32 × 32768² × 2B = **64GB**

单张 A100 只有 80GB 显存！64GB 的 Score 矩阵完全不可接受 → **需要 FlashAttention 的 tiling 技术**。

---

## 2. PyTorch 实现与复杂度分析

### 2.1 标准实现

```python
import torch
import torch.nn.functional as F

def standard_attention(q, k, v):
    """
    Args:
        q: [batch, heads, seq_q, d_k]
        k: [batch, heads, seq_k, d_k]
        v: [batch, heads, seq_v, d_v]
    Returns:
        output: [batch, heads, seq_q, d_v]
    """
    d_k = q.size(-1)

    # Step 1: Q @ K^T → score
    # [B, H, Sq, d_k] @ [B, H, d_k, Sk] → [B, H, Sq, Sk]
    score = torch.matmul(q, k.transpose(-2, -1))

    # Step 2: Scale
    score = score / (d_k ** 0.5)

    # Step 3: Softmax over last dim (Sk)
    # 在序列维度上做 softmax，每个 query 位置的分数归一化
    weights = F.softmax(score, dim=-1)

    # Step 4: Weights @ V → output
    # [B, H, Sq, Sk] @ [B, H, Sk, d_v] → [B, H, Sq, d_v]
    output = torch.matmul(weights, v)

    return output
```

### 2.2 计算量与理论 FLOPS

```python
def compute_flops(B, H, Sq, Sk, D):
    """
    计算 Attention 的总 FLOPs
    FLOPs 定义：一次乘法 + 一次加法 = 1 个 FLOP（float operation）
    """
    # Q @ K^T: [B, H, Sq, D] x [B, H, D, Sk] → 2 * B * H * Sq * Sk * D
    flops_qk = 2 * B * H * Sq * Sk * D

    # Softmax: 约 3 * B * H * Sq * Sk（exp + add + divide）
    flops_softmax = 3 * B * H * Sq * Sk

    # P @ V: [B, H, Sq, Sk] x [B, H, Sk, D] → 2 * B * H * Sq * Sk * D
    flops_pv = 2 * B * H * Sq * Sk * D

    return flops_qk + flops_softmax + flops_pv

# LLaMA-7B 推理：B=1, H=32, D=128
# Prefill Sq=4096: ~8.6 TFLOPs  per layer
# Decode  Sq=1,  Sk=4096: ~2.1 GFLOPs per layer
```

### 2.3 显存分析

```python
def estimate_memory(B, H, Sq, Sk, D, dtype_bytes=2):
    """估算 attention 中间结果的显存占用"""
    score_bytes = B * H * Sq * Sk * dtype_bytes  # Q@K^T 结果
    output_bytes = B * H * Sq * D * dtype_bytes   # Output
    q_bytes = B * H * Sq * D * dtype_bytes        # Q
    k_bytes = B * H * Sk * D * dtype_bytes        # K
    v_bytes = B * H * Sk * D * dtype_bytes        # V
    return {
        "score": score_bytes / (1024**3),  # GB
        "output": output_bytes / (1024**3),
        "qkv": (q_bytes + k_bytes + v_bytes) / (1024**3),
    }

# Prefill: Sq=4096, Sk=4096, 32 heads, D=128
# score = 1*32*4096*4096*2 = 1.0 GB!  这是 O(n²) 问题的根源
```

---

## 3. KV Cache 原理

### 3.1 为什么需要 KV Cache？

在自回归推理中，生成第 t 个 token 时：
- sequence = [token_0, token_1, ..., token_{t-1}]
- 我们需要 attention 到**所有之前的 token**

```
时间步 0: Q[0] ← attention → K[0], V[0]  → 输出 token_0
时间步 1: Q[1] ← attention → K[0..1], V[0..1]  → 输出 token_1
时间步 2: Q[2] ← attention → K[0..2], V[0..2]  → 输出 token_2
```

**关键观察**：K[0] 和 V[0] 在每个时间步都被重复计算！

KV Cache 的优化：**把之前所有时间步的 K/V 缓存在 GPU 显存中**，每个 decode 步只计算当前 token 的 K/V，然后拼接。

```
没有 KV Cache：
  第 t 步：计算 K = input @ W_K  ← 重复了 t 次之前的计算！
          计算 V = input @ W_V

有 KV Cache：
  第 t 步：只算当前 token 的 K_new = input[t] @ W_K
          cache = concat(K_old, K_new)  → O(1) 计算
```

### 3.2 显存占用模型

KV Cache 的显存占用：

```
KV cache = 2 (K和V) × num_layers × num_heads × seq_len × head_dim × dtype_bytes

示例 — LLaMA-7B (32 layers, 32 heads, d=128, FP16):
  每个 token 的 KV cache: 2 × 32 × 32 × 1 × 128 × 2 = 524,288 bytes ≈ 0.5 MB/token

  序列长度 4096: 4096 × 0.5 MB = 2 GB
  序列长度 32768: 32768 × 0.5 MB = 16 GB  ❌ 显存爆炸！
```

**量化 KV Cache**：INT8 量化可将显存减半（需要处理精度损失）。

```python
def kv_cache_memory(num_layers, num_heads, seq_len, head_dim, dtype_bytes=2):
    """计算 KV cache 的显存占用"""
    bytes_per_token = 2 * num_layers * num_heads * head_dim * dtype_bytes
    return bytes_per_token * seq_len

# LLaMA-7B: 32L, 32H, 128D, FP16
print(kv_cache_memory(32, 32, 4096, 128, 2))  # 2,147,483,648 ≈ 2 GB
```

### 3.3 推理循环实现

```python
def inference_with_kv_cache(model, input_ids, max_new_tokens=128):
    """
    带 KV Cache 的自回归推理循环

    Args:
        model: HuggingFace-like model with past_key_values support
        input_ids: [batch, seq_len] 初始 prompt token ids
    """
    # 第 1 步：Prefill — 计算 prompt 的所有 K/V
    # 输出: logits 和 KV cache
    with torch.no_grad():
        outputs = model(
            input_ids,
            use_cache=True,        # 告诉 model 返回 KV cache
        )
    past_key_values = outputs.past_key_values  # tuple of (K, V) per layer
    next_token = outputs.logits[:, -1, :].argmax(dim=-1, keepdim=True)
    generated = [next_token.item()]

    # 第 2 步：Decode — 逐 token 生成
    for step in range(max_new_tokens - 1):
        with torch.no_grad():
            outputs = model(
                next_token,          # 只传入当前 token ！！！
                past_key_values=past_key_values,  # 传入之前所有 K/V
                use_cache=True,
            )
        past_key_values = outputs.past_key_values  # 更新 cache
        next_token = outputs.logits[:, -1, :].argmax(dim=-1, keepdim=True)
        generated.append(next_token.item())

    return generated  # 返回生成的 token 序列
```

### 3.4 GQA (Grouped Query Attention)

在多 GPU 推理中，**KV Cache 是显存瓶颈**。GQA 通过减少 KV head 数量来降低 cache 大小。

```
MHA (Multi-Head Attention):    H_q = H_k = H_v = 32
  - 每个 query head 有自己的 key/value head
  - KV cache size = 2 × L × H × S × D

GQA (Grouped Query Attention): H_q = 32, H_k = H_v = 8
  - 4 个 query head 共享一组 key/value head
  - KV cache 缩小 4 倍！
  - LLaMA-3-70B 和 DeepSeek-V2 使用 GQA

MQA (Multi-Query Attention):   H_q = 32, H_k = H_v = 1
  - 所有 query head 共享同一组 key/value head
  - KV cache 缩小 32 倍！
  - 最早的优化方案（原始 PaLM 使用），精度损失较大
```

---

## 4. Prefill vs Decode 阶段

### 4.1 计算特征对比

| 特征 | Prefill | Decode |
|------|---------|--------|
| 输入 | 整个 prompt（批量 token） | 单个 token |
| Q 大小 | [1, H, Sq, D] | [1, H, 1, D] |
| K/V 大小 | [1, H, Sq, D] | [1, H, Sk+cache, D] |
| 计算类型 | Compute-bound | Memory-bound |
| 瓶颈 | FLOPS | 显存带宽 |
| 并行性 | 高（长序列并行） | 低（串行生成） |
| Softmax | 大矩阵 | 小矩阵 |

### 4.2 为什么 Decode 是 Memory-bound？

```
Decode 单步计算量：
  Q @ K^T: 2 × H × 1 × Sk × D  FLOPs
  P @ V:   2 × H × 1 × Sk × D  FLOPs
  Total:   4 × H × Sk × D       FLOPs

需要读取的数据量：
  Q: H × D                      元素
  K cache: H × Sk × D           元素（从显存读取）
  V cache: H × Sk × D           元素（从显存读取）
  Total: H × D × (2×Sk + 1)    元素

计算强度 (arithmetic intensity) = FLOPs / bytes
  = (4 × H × Sk × D) / (H × D × (2×Sk + 1) × 2 bytes)
  ≈ 1 FLOP/byte  ← bandwidth-bound!

对比 Prefill:
  计算强度 ≈ Sk/2 FLOP/byte  ← compute-bound（当 Sk 大时）
```

### 4.3 两种阶段的优化方向

```
Prefill 优化（compute-bound）：
  - 使用 Tensor Core（FP16/BF16/FP8 GEMM）
  - 增大 batch size / sequence length
  - FlashAttention tiling 减少显存带宽

Decode 优化（memory-bound）：
  - KV Cache 量化（INT8/FP8）
  - Page optimization（PagedAttention）
  - Batching multiple decode requests
  - Kernel fusion（减少 kernel launch 开销）
  - Continuous batching（vLLM 的核心优化）
```

---

## 5. Attention Variants 在推理场景中的作用

### 5.1 FlashAttention

核心思想：**IO-aware tiling** — 将 Q/K/V 分块加载到 SRAM，在片上计算 partial softmax，减少 global memory 读写。

```
Non-flash attention:
  1. 读 Q, K → 写 Score (global memory)  — O(S²) 显存写
  2. 读 Score → 写 P (global memory)      — O(S²) 显存写
  3. 读 P, V → 写 Output                  — O(S²) 显存读

FlashAttention tiling:
  1. 加载 tile of Q/K/V → SRAM
  2. 在 SRAM 内算 partial softmax
  3. 写回 Output                          — O(S) 显存读写！
```

### 5.2 PagedAttention

核心思想：将 KV Cache 分页管理，解决**显存碎片**和**过度预留**问题。

```
传统 KV Cache（vLLM 之前的系统）：
  为最大序列长度预留连续显存 → 大量浪费（内部碎片）

PagedAttention：
  固定大小的 page/block（16 tokens/block）
  逻辑连续 → 物理离散（类似 OS 的分页）
  按需分配，共享 block（prefix caching、copy-on-write）
```

### 5.3 Sliding Window Attention / StreamingLLM

长序列推理的优化：
- **Sliding Window**：只 attention 最近的 W 个 token，O(W) 而不是 O(S)
- **StreamingLLM**：保留起始的几个 "attention sinks" + 最近的窗口

---

## 6. 面试考点

| 考点 | 重要度 | 说明 |
|------|--------|------|
| KV Cache 显存公式及优化方法 | ⭐⭐⭐ | 必问，40B/70B 模型的 KV cache 多大 |
| Prefill vs Decode 区别 | ⭐⭐⭐ | 为什么 prefill compute-bound, decode memory-bound |
| 自回归推理的因果 mask | ⭐⭐⭐ | 为什么 prefir 需要 mask，decoder 不需要 |
| GQA vs MHA vs MQA | ⭐⭐ | LLaMA-3 用的 GQA 原理 |
| FlashAttention 核心思想 | ⭐⭐⭐ | IO-aware tiling，不用 matmul 完整 score 矩阵 |
| Attention 的 O(n²) 复杂度 | ⭐⭐ | 如何扩展长序列 |
| Softmax 中的 online safe softmax | ⭐⭐ | FlashAttention 的 online softmax 实现 |

---

## 7. 配套实例

- 实例代码目录：[attention_lab/](../attention_lab/)
  - [standard_attention.py](../attention_lab/standard_attention.py) — PyTorch 实现 + 性能分析
  - [kv_cache_demo.py](../attention_lab/kv_cache_demo.py) — KV Cache 推理循环
  - [attention_profiling.py](../attention_lab/attention_profiling.py) — 计算量/显存分析

### 运行命令

```bash
# Attention 基础
cd attention_lab
python standard_attention.py

# KV Cache 推理循环模拟
python kv_cache_demo.py

# 性能 Profiling
python attention_profiling.py

# PyTorch Profiler
python -m torch.utils.bottleneck standard_attention.py

# Nsight Systems profiling
nsys profile -o attn_profile python standard_attention.py
```
