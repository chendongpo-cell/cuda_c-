# 曙光专篇2：深算一号 DCU + HIP 编程 — 中科曙光入职必学

> 目标：掌握深算一号 DCU 的异构编程模型，学会 CUDA 代码迁移到 HIP 适配 DCU。
> 曙光的核心工作就是把 NVIDIA GPU 的推理优化移植到 DCU 上跑。
> 预计时间：5 天（权重最高）

---

## 目录

1. [DCU 深算一号架构](#1-dcu-深算一号架构)
2. [HIP 编程基础](#2-hip-编程基础)
3. [CUDA → HIP 迁移实战](#3-cuda--hip-迁移实战)
4. [DCU 显存管理与优化](#4-dcu-显存管理与优化)
5. [ROCm 工具链](#5-rocm-工具链)
6. [DCU 上的 vLLM 适配](#6-dcu-上的-vllm-适配)
7. [配套实例](#7-配套实例)

---

## 1. DCU 深算一号架构

### 1.1 硬件规格

深算一号（DCU, Deep Computing Unit）是中科曙光自研的 GPGPU：

```
DCU K100 (深算一号) 技术规格：
  ┌──────────────────────────────┐
  │  计算单元:  60 个 Compute Unit│
  │  流处理器:  3840 个           │
  │  显存:      32 GB HBM2       │
  │  显存带宽:  1.2 TB/s         │
  │  FP32:      20 TFLOPS        │
  │  FP16:      40 TFLOPS        │
  │  INT8:      80 TOPS          │
  │  互联:      PCIe 4.0 x16    │
  │  TDP:       300W             │
  │  制程:      7nm              │
  └──────────────────────────────┘

对比 NVIDIA A100:
  ┌──────────────────────────────┐
  │  A100 80GB:                  │
  │  计算单元:  108 SM           │
  │  FP32:      19.5 TFLOPS      │
  │  FP16:      312 TFLOPS (稀疏)│
  │  显存:      80 GB HBM2e     │
  │  显存带宽:  2 TB/s          │
  └──────────────────────────────┘

关键差距：
  1. DCU 显存仅 32 GB → KV cache 容量受限
  2. DCU FP16 40T vs A100 312T → 差距主要在 Tensor Core
  3. DCU 无 NVLink → 多卡通信靠 PCIe（慢 5-10x）
```

### 1.2 架构特点

```
Compute Unit (CU) = 类比 NVIDIA 的 SM
  ┌──────────────────────────────┐
  │  CU (Compute Unit)           │
  │  ├── 64 个 ALU (算术逻辑单元)│
  │  ├── 64 KB Local Data Share  │ ← 相当于 Shared Memory
  │  ├── 16 KB L1 Cache          │
  │  ├── 32 个 Vector Registers   │
  │  └── Scalar Unit             │
  └──────────────────────────────┘

Wavefront = 64 线程（类比 NVIDIA 的 Warp = 32 线程）
  ⚠️ 重要差异：DCU 的 wavefront 是 64 线程！
  所以在写 DCU kernel 时，wavefront size = 64
  block_size 应选 64 的倍数（而不是 32 的倍数）
```

### 1.3 与 NVIDIA 架构术语对照

| NVIDIA | DCU (AMD ROCm) | 说明 |
|--------|----------------|------|
| CUDA Core | ALU | 基本的计算单元 |
| SM | Compute Unit (CU) | 计算单元组 |
| Warp (32 threads) | Wavefront (64 threads) | **注意这个差异！** |
| Thread Block | Workgroup | 线程块 |
| Shared Memory | Local Data Share (LDS) | 片内共享内存 |
| Global Memory | Global Memory | 全局显存 |
| NVLink | PCIe / Infinity Fabric | 卡间互联 |
| CUDA Toolkit | ROCm | 开发工具链 |
| nvcc | hipcc / rocm-llvm | 编译器 |
| Nsight | rocprof / rocgdb | 性能分析/调试 |
| cuBLAS | rocBLAS | BLAS 库 |
| cuDNN | MIOpen | 深度学习库 |
| TensorRT | MIGraphX | 推理优化引擎 |

---

## 2. HIP 编程基础

### 2.1 HIP 是什么

HIP（Heterogeneous-compute Interface for Portability）是 AMD 推出的异构计算编程模型：

```
HIP 的目标：
  写一次代码，同时兼容 AMD GPU（DCU）和 NVIDIA GPU

关键宏：
  __global__     →  在 GPU 上执行的 kernel （兼容 CUDA）
  __device__     →  在 GPU 上调用的函数 （兼容）
  __shared__     →  共享内存 （兼容）
  hipMalloc      →  对应 cudaMalloc
  hipMemcpy      →  对应 cudaMemcpy
  hipFree        →  对应 cudaFree
```

### 2.2 HIP 与 CUDA 语法对比

```cpp
// ============ CUDA 版本 ============
__global__ void vector_add_cuda(const float* a, const float* b, float* c, int n) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < n) {
        c[tid] = a[tid] + b[tid];
    }
}

int main() {
    float *d_a, *d_b, *d_c;
    cudaMalloc(&d_a, bytes);
    cudaMalloc(&d_b, bytes);
    cudaMalloc(&d_c, bytes+I]);

    cudaMemcpy(d_a, h_a, bytes, cudaMemcpyHostToDevice);
    cudaMemcpy(d_b, h_b, bytes, cudaMemcpyHostToDevice);

    vector_add_cuda<<<grid, block>>>(d_a, d_b, d_c, n);

    cudaMemcpy(h_c, d_c, bytes, cudaMemcpyDeviceToHost);

    cudaFree(d_a);
    cudaFree(d_b);
    cudaFree(d_c);
    return 0;
}


// ============ HIP 版本（几乎一样！） ============
// 改动点：cuda → hip, 其他完全一致

__global__ void vector_add_hip(const float* a, const float* b, float* c, int n) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < n) {
        c[tid] = a[tid] + b[tid];
    }
}

int main() {
    float *d_a, *d_b, *d_c;
    hipMalloc(&d_a, bytes);
    hipMalloc(&d_b, bytes);
    hipMalloc(&d_c, bytes);

    hipMemcpy(d_a, h_a, bytes, hipMemcpyHostToDevice);
    hipMemcpy(d_b, h_b, bytes, hipMemcpyHostToDevice);

    vector_add_hip<<<grid, block>>>(d_a, d_b, d_c, n);

    hipMemcpy(h_c, d_c, bytes, hipMemcpyDeviceToHost);

    hipFree(d_a);
    hipFree(d_b);
    hipFree(d_c);
    return 0;
}
```

### 2.3 统一的 HIP 代码（同时兼容 NVIDIA 和 DCU）

```cpp
// 用 hipify 工具自动转换，或手写统一代码

// 头文件兼容
#if defined(__HIP_PLATFORM_AMD__)
    // DCU / AMD GPU
    #include <hip/hip_runtime.h>
    #define WARP_SIZE 64          // DCU wavefront = 64
#elif defined(__HIP_PLATFORM_NVIDIA__)
    // NVIDIA GPU (通过 HIP 编译 CUDA)
    #include <cuda_runtime.h>
    #define WARP_SIZE 32          // NVIDIA warp = 32
#endif

// 统一的 Kernel
__global__ void unified_kernel(const float* data, int n) {
    int tid = blockIdx.x * blockDim.x + threadIdx.xFixed;
    if (tid < n) {
        // 代码写法完全一致
        data[tid] *= 2.0f;
    }
}

// 统一的内存管理
template <typename T>
void safe_alloc(T** ptr, size_t size) {
    hipError_t err = hipMalloc(ptr, size);
    if (err != hipSuccess) {
        fprintf(stderr, "hipMalloc failed: %s\n",
                hipGetErrorString(err));
        exit(1);
    }
}
```

### 2.4 编译器使用

```bash
# CUDA 编译
nvcc -O2 -arch=sm_80 -o kernel kernel.cu

# HIP 编译（在 DCU 上）
hipcc -O2 --offload-arch=gfx906 -o kernel kernel.cpp
# gfx906 = MI50/MI60 (AMD), DCU 类似

# HIP 编译（在 NVIDIA GPU 上）
hipcc -O2 --offload-arch=sm_80 -o kernel kernel.cpp

# 查看 DCU 架构
rocm-smi --showhw
```

---

## 3. CUDA → HIP 迁移实战

### 3.1 自动迁移：hipify

```bash
# hipify-perl：自动将 CUDA 代码转为 HIP
hipify-perl vector_add.cu > vector_add_hip.cpp

# hipify-clang：更精确的转换
hipify-clang vector_add.cu --cuda-path=/usr/local/cuda

# 实际效果：cudaMalloc → hipMalloc, 宏定义自动替换
```

### 3.2 手动迁移常见问题

```
问题 1：Warp Size 差异
  CUDA: warpSize = 32
  DCU:  warpSize = 64 (hipDeviceProp::warpSize)

  影响代码：
    // CUDA 代码（warp 归约）
    for (int s = 16; s > 0; s >>= 1) {  // 32 → 16 → 8 → 4 → 2 → 1
        val += __shfl_down_sync(mask, val, s, 32);
    }

    // HIP 适配（wavefront 64）
    for (int s = 32; s > 0; s >>= 1) {  // 64 → 32 → 16 → 8 → 4 → 2 → 1
        val += __shfl_down(mask, val, s, 64);
    }

问题 2：内置变量名差异
  CUDA: threadIdx.x, blockDim.x, blockIdx.x
  HIP:  完全一致（这是 HIP 的设计目标）

问题 3：数学函数
  CUDA: __fadd_rn(), __expf(), __sinf()
  HIP:  直接使用标准数学函数（编译器优化）
        或使用 HIP 内建函数

问题 4：Tensor Core
  CUDA: nvcuda::wmma::mma_sync (WMMA API)
  DCU:  不直接支持 Tensor Core
        → 需要手工 tile 优化来接近性能
        → 这是 DCU 推理优化的核心挑战！
```

### 3.3 写一个可移植的 Reduction Kernel

```cpp
// 跨平台归约 kernel（兼容 CUDA 和 HIP）

#include <cstdio>
#include <hip/hip_runtime.h>

template <int BLOCK_SIZE>
__global__ void portable_reduce(
    const float* input, float* output, int n) {

    // 使用动态 shared memory（和 CUDA 一样）
    extern __shared__ float sdata[];
    int tid = blockIdx.x * blockDim.x + threadIdx.x;

    // 加载数据
    sdata[threadIdx.x] = (tid < n) ? input[tid] : 0.0f;
    __syncthreads();

    // 树形归约
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (threadIdx.x < s) {
            sdata[threadIdx.x] += sdata[threadIdx.x + s];
        }
        // __syncthreads 在 CUDA 和 HIP 中完全相同
        __syncthreads();
    }

    // 最后 64 个线程（兼容 wavefront=64）
    if (threadIdx.x < 64) {
        volatile float* vsmem = sdata;
        // 对 HIP 和 CUDA 都能工作（CUDA 会浪费 32 个线程但不出错）
        if (BLOCK_SIZE >= 128) vsmem[threadIdx.x] += vsmem[threadIdx.x + 64];
        if (BLOCK_SIZE >= 64)  vsmem[threadIdx.x] += vsmem[threadIdx.x + 32];
        if (BLOCK_SIZE >= 32)  vsmem[threadIdx.x] += vsmem[threadIdx.x + 16];
        if (BLOCK_SIZE >= 16)  vsmem[threadIdx.x] += vsmem[threadIdx.x + 8];
        if (BLOCK_SIZE >= 8)   vsmem[threadIdx.x] += vsmem[threadIdx.x + 4];
        if (BLOCK_SIZE >= 4)   vsmem[threadIdx.x] += vsmem[threadIdx.x + 2];
        if (BLOCK_SIZE >= 2)   vsmem[threadIdx.x] += vsmem[threadIdx.x + 1];
    }

    if (threadIdx.x == 0) {
        output[blockIdx.x] = sdata[0];
    }
}
```

---

## 4. DCU 显存管理与优化

### 4.1 DCU 显存限制

```
DCU K100: 32 GB HBM2
A100:     80 GB HBM2e

对于 7B 模型推理（FP16）：
  模型权重:      7B × 2 bytes = 14 GB
  KV cache:      至少 2 GB (32层 × 32K tokens)
  Activation:    几百 MB

  剩余给 KV cache: 32 - 14 - 0.5 ≈ 17.5 GB
  可处理序列长度:  17.5 GB / (2GB/4K) ≈ 35K tokens

  → DCU 能跑 32K 上下文，但显存确实紧张
  → 量化和 KV cache 优化在 DCU 上比 NVIDIA 更重要！
```

### 4.2 显存优化策略

```cpp
// 策略 1：显存池（Arena Allocation）
// 避免频繁的 hipMalloc/hipFree（慢！）

class DcuMemoryPool {
private:
    struct Block {
        void* ptr;
        size_t size;
        bool in_use;
    };
    std::vector<Block> pool_;

public:
    void* allocate(size_t size) {
        // 先查 pool 中有无合适空闲块
        for (auto& block : pool_) {
            if (!block.in_use && block.size >= size) {
                block.in_use = true;
                return block.ptr;
            }
        }
        // 没有，新分配
        void* ptr;
        hipMalloc(&ptr, size);
        pool_.push_back({ptr, size, true});
        return ptr;
    }

    void deallocate(void* ptr) {
        for (auto& block : pool_) {
            if (block.ptr == ptr) {
                block.in_use = false tension;
                // 不真正 hipFree，只是标记为可用
                return;
            }
        }
    }

    ~DcuMemoryPool() {
        for (auto& block : pool_) {
            hipFree(block.ptr);
        }
    }
};


// 策略 2：显存复用（同一个缓冲区反复使用）
// vLLM 中 KV cache 就是复用策略

class KVCacheBuffer {
private:
    // 预分配最大显存
    void* kv_cache;
    size_t total_size;

public:
    void init(int num_layers, int max_tokens) {
        total_size = 2 * num_layers * max_tokens * 128 * 2; // FP16
        hipMalloc(&kv_cache, total_size);
    }

    // 每个请求从中取一段
    void* get_slot(int layer_id, int block_id) {
        // 计算偏移
        size_t offset = /* ... */;
        return (char*)kv_cache + offset;
    }
};
```

---

## 5. ROCm 工具链

### 5.1 rocprof — DCU 性能分析器

```bash
# rocprof：DCU 上的 Nsight Compute 等价物
# 分析 kernel 耗时和显存带宽

# 基本用法
rocprof --stats ./my_kernel

# 输出：stats.csv（所有 kernel 的耗时统计）
rocr_analytics.csv  # 更详细的分析

# 跟踪具体 kernel
rocprof --trace ./my_kernel

# 查看 DCU 利用率
rocm-smi

# 示例输出
# =========================================
#  Kernel Name        Calls  Duration(us)
#  vector_add           1       152.3
#  matmul_kernel        3      12450.1
#  =========================================
```

### 5.2 rocgdb — DCU 调试器

```bash
# DCU 上的 GPU kernel 调试
rocgdb ./my_program

# 在 rocgdb 中：
# (rocgdb) break kernel_name   # 在 kernel 入口断点
# (rocgdb) run                  # 运行
# (rocgdb) info threads         # 查看 GPU 线程
# (rocgdb) thread apply all bt  # 所有线程的 backtrace
```

### 5.3 ROCm 生态库

| NVIDIA | DCU (ROCm) | 用途 |
|--------|-----------|------|
| cuBLAS | rocBLAS | BLAS 矩阵运算 |
| cuFFT | rocFFT | FFT 计算 |
| cuSPARSE | rocSPARSE | 稀疏矩阵 |
| cuDNN | MIOpen | 深度学习算子 |
| TensorRT | MIGraphX | 推理优化 |
| NCCL | RCCL | 多卡通信 |
| cuRAND | rocRAND | 随机数生成 |

```python
# 在 DL 框架中使用 ROCm

# PyTorch + ROCm（DCU 上运行）
# 安装：pip3 install torch torchvision --index-url https://download.pytorch.org/whl/rocm6.2

import torch

# 检查是否识别到 DCU
print(torch.cuda.is_available())  # ROCm 兼容 CUDA API
print(torch.cuda.get_device_name(0))  # 显示 DCU K100

# 代码和 CUDA 版本完全一致！
device = torch.device('cuda')
model = model.to(device)
output = model(input_ids.to(device))
```

---

## 6. DCU 上的 vLLM 适配

### 6.1 适配层次

```
在曙光部署 vLLM 到 DCU 上，涉及三层适配：

第 1 层（简单）：启动命令适配
  # NVIDIA GPU:
  python -m vllm.entrypoints.openai.api_server --model llama

  # DCU (ROCm):
  # 如果 vLLM 已适配 ROCm，启动命令完全一样
  python -m vllm.entrypoints.openai.api_server --model llama

第 2 层（中等）：Python 调度层适配
  # 检查 vLLM 是否有 ROCm backend
  # vllm/worker/ 下需要 rocm_worker.py
  # vllm/attention/ 下需要 rocm_attention_backend.py

第 3 层（最难）：C++/HIP 算子适配
  # vllm/csrc/ 下的 CUDA kernel 需要转 HIP
  # 核心文件：
  #   csrc/attention/  → PagedAttention HIP 移植
  #   csrc/quantization/ → AWQ/GPTQ 量化的 HIP 移植
  #   csrc/cuda_utils_kernels.cu → HIP 版本
```

### 6.2 实战：移植 PagedAttention 到 DCU

```cpp
// vllm csrc/attention/kernel 的 HIP 移植示例

// CUDA 原版（PagedAttention kernel）
// 文件: csrc/attention/attention_kernels.cu
__global__ void paged_attention_kernel_cuda(
    float* output,
    const float* query,
    const float* key_cache,
    const float* value_cache,
    const int* block_tables,
    int num_blocks,
    int num_heads,
    int head_size,
    int block_size
) {
    // CUDA 实现...
    // 使用 __shfl_xor_sync, __syncthreads 等
}

// HIP 移植版
// 文件: csrc/attention/attention_kernels_hip.cpp
__global__ void paged_attention_kernel_hip(
    float* output,
    const float* query,
    const float* key_cache,
    const float* value_cache,
    const int* block_tables,
    int num_blocks,
    int num_heads,
    int head_size,
    int block_size
) {
    // 移植主要改动：
    // 1. cuda → hip API
    // 2. warp size: 32 → 64 的适配
    // 3. shared memory 大小检查（DCU LDS 可能更小）

    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    // ... 逻辑基本不变
}

// CMake 适配
if(HIP_FOUND)
    # DCU 编译
    hip_add_library(attention_ops_hip attention_kernels_hip.cpp)
    target_compile_definitions(attention_ops_hip PRIVATE USE_ROCM)
else()
    # NVIDIA CUDA 编译
    cuda_add_library(attention_ops_cu attention_kernels.cu)
endif()
```

### 6.3 曙光实测性能对比

```
（参考数据，实际值因模型和配置而异）

LLaMA-7B 推理，batch=1，seq_len=4096：
  ┌────────────────────┬──────────┬──────────┬──────┐
  │      指标          │ A100-80G │ DCU K100 │ 比例 │
  ├────────────────────┼──────────┼──────────┼──────┤
  │ Prefill 延迟        │  180 ms  │  420 ms  │ 43%  │
  │ Decode 延迟/步      │  28 ms   │  65 ms   │ 43%  │
  │ 最大序列长度        │  32K     │  16K     │ 50%  │
  │ 最大并发请求数      │  64      │  16      │ 25%  │
  │ 吞吐 (req/s)       │  8.5     │  2.1     │ 25%  │
  └────────────────────┴──────────┴──────────┴──────┘

DCU 瓶颈主要在：
  1. 显存带宽 1.2T vs A100 2T → 直接影响 Decode 速度
  2. 无 Tensor Core → FP16 矩阵乘只有 A100 的 1/8
  3. 显存 32GB vs 80GB → 无法跑大批量
  4. 无 NVLink → 多卡通信受限

优化方向：
  ✓ INT8 量化（DCU 原生支持好）→ 显存减半 + 速度提升
  ✓ 算子融合 → 减少 kernel launch 开销
  ✓ 减少 batch size → 更现实的部署配置
  ✓ 小模型更适合 DCU（比如 1-2B 级别）
```

---

## 7. 配套实例

实例代码目录：`cuda_kernels/` 中的代码稍加修改即可转为 HIP：

```bash
# HIP 编译
hipify-perl cuda_kernels/vector_add.cu > dcu_kernels/vector_add_hip.cpp
hipcc -O2 -o vector_add_hip vector_add_hip.cpp
./vector_add_hip

# 使用 ROCm 工具
rocprof --stats ./vector_add_hip   # 性能分析
rocm-smi                            # 查看 DCU 状态

# 环境变量（调试用）
export HIP_LAUNCH_BLOCKING=1        # 同步 kernel launch（debug）
export HIP_VISIBLE_DEVICES=0        # 选择 DCU 设备
export ROCBLAS_LAYER=2              # rocBLAS log（类似 cuBLAS log）

# 查看 DCU 架构
rocm_agent_enumerator               # 列出 ROCm 支持的所有设备
```

### HIP 编程速查卡

| CUDA 代码 | HIP 等价代码 | 备注 |
|-----------|-------------|------|
| `cudaMalloc` | `hipMalloc` | 完全一致 |
| `cudaFree` | `hipFree` | |
| `cudaMemcpy` | `hipMemcpy` | |
| `cudaMemcpyKind` | `hipMemcpyKind` | 枚举值也一致 |
| `cudaStream_t` | `hipStream_t` | |
| `cudaEvent_t` | `hipEvent_t` | |
| `cudaDeviceSynchronize` | `hipDeviceSynchronize` | |
| `cudaGetLastError` | `hipGetLastError` | |
| `__syncthreads()` | `__syncthreads()` | 完全一致 |
| `__shfl_down_sync` | `__shfl_down` | 无 mask 参数 |
| `threadIdx.x` | `threadIdx.x` | 完全一致 |
| `blockDim.x` | `blockDim.x` | 完全一致 |
| `nvcc` | `hipcc` | 编译器 |
| `-arch=sm_80` | `--offload-arch=gfx906` | 架构参数不同 |
