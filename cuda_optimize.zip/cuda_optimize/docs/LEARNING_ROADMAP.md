﻿# AI 推理优化工程师 - 分阶段学习路线图

> **目标读者**：有 Python + PyTorch 基础的 AI 应用工程师，即将入职中科曙光做 AI 推理优化。
>
> **总周期**：约 4-5 个月（日均 1 小时，共 ~120 小时）。3 个月紧凑版可压缩，但建议留 buffer。
>
> **设计原则**：
> 1. 从 Python/PyTorch 平滑过渡到 C++/CUDA/HIP，不跳过语法本身
> 2. 每个阶段有明确的"输出物"，不只是看完
> 3. 曙光 DCU/HIP 内容贯穿后半程，不是附加题
> 4. 已有文档复用，新文档只填补基础空白

---

## 目录

- [阶段 0：入职前准备（第 1 周，7h）](#阶段-0入职前准备第-1-周7h)
- [阶段 1：C++ 从 Python 视角切入（第 2-3 周，14h）](#阶段-1c-从-python-视角切入第-2-3-周14h)
- [阶段 2：GPU 编程基础 - CUDA（第 4-5 周，14h）](#阶段-2gpu-编程基础---cuda第-4-5-周14h)
- [阶段 3：Attention 与 KV Cache（第 6 周，7h）](#阶段-3attention-与-kv-cache第-6-周7h)
- [阶段 4：推理框架核心（第 7-9 周，21h）](#阶段-4推理框架核心第-7-9-周21h)
- [阶段 5：算子优化（第 10-11 周，14h）](#阶段-5算子优化第-10-11-周14h)
- [阶段 6：量化（第 12 周，7h）](#阶段-6量化第-12-周7h)
- [阶段 7：服务化与 Profiler（第 13 周，7h）](#阶段-7服务化与-profiler第-13-周7h)
- [阶段 8：高级主题（第 14-15 周，14h）](#阶段-8高级主题第-14-15-周14h)
- [阶段 9：手写推理引擎（第 16 周，7h）](#阶段-9手写推理引擎第-16-周7h)
- [阶段 10：SGLang 源码（第 17 周，7h）](#阶段-10sglang-源码第-17-周7h)
- [阶段 11：曙光专篇 - DCU/HIP（第 18-19 周，14h）](#阶段-11曙光专篇---dcuhip第-18-19-周14h)

- [学习节奏建议](#学习节奏建议)
- [自检清单](#自检清单)

---

## 阶段 0：入职前准备（第 1 周，7h）

### 0.1 目标

建立对"推理优化工程师"这个岗位的全局认知，搞清楚要学什么、为什么学、学到什么程度够用。

### 0.2 学习材料

| 序号 | 文件 | 时长 | 说明 |
|------|------|------|------|
| 0.2.1 | [00_getting_started.md](00_getting_started.md) | 2h | 从零理解推理链路白话版 |
| 0.2.2 | [glossary.md](glossary.md) | 2h | 术语词典，边查边记 |
| 0.2.3 | [LEARNING_ROADMAP.md](LEARNING_ROADMAP.md)（本文件） | 1h | 通读一遍，心里有数 |
| 0.2.4 | [user-background.md](../../../C:/Users/H2412208/.claude/projects/d--Desktop-fox-projects-cuda-optimize/memory/user-background.md) | 0.5h | 自己的背景定位 |
| 0.2.5 | 跑通 [05_attention/python/standard_attention.py](../05_attention/python/standard_attention.py) | 1.5h | 第一个能跑的代码，建立信心 |

### 0.3 基础知识（必须先懂）

- **什么是推理（inference）vs 训练（training）**：你已经懂 PyTorch 训练，推理是只用 forward 不用 backward
- **什么是 LLM 推理服务**：用户发 prompt，服务返回 generated text，按 token 计费
- **为什么推理需要优化**：模型大（70B+）、用户多（并发）、延迟要求严（P99 < 1s）

### 0.4 输出物

- [ ] 能用一段话讲清楚"推理优化工程师每天在干嘛"
- [ ] 能跑通 `python 05_attention/python/standard_attention.py`
- [ ] 在 glossary.md 里标记出"完全不懂"的术语，后续阶段重点攻克

### 0.5 自检问题

1. 推理和训练在计算上的核心差异是什么？（答：推理不需要 backward，但需要 KV Cache）
2. 为什么不能直接用 PyTorch 跑生产推理？（答：太慢、无 batching、无显存管理）
3. vLLM 和 SGLang 各自解决什么问题？（答：vLLM=PagedAttention，SGLang=RadixAttention+DSL）

---

## 阶段 1：C++ 从 Python 视角切入（第 2-3 周，14h）

### 1.1 目标

能读懂 C++17 代码（推理框架源码 99% 是 C++），能写简单的 C++ 程序。**不要求精通**，要求"看懂 + 能改"。

### 1.2 为什么先学 C++

- vLLM/SGLang 源码都是 C++
- 性能关键路径（kernel、scheduler）必须 C++
- 面试必考 C++ 基础
- 你以后写 CUDA/HIP 也需要 C++ 语法

### 1.3 学习材料

#### 1.3.1 基础衔接（先看，2h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 1.3.1.1 | [foundations/01_python_to_cpp_bridge.md](foundations/01_python_to_cpp_bridge.md) | **新文档**：Python 程序员的 C++ 速通，用 Python 类比讲 C++ |

#### 1.3.2 核心语法（4h）

| 序号 | 文件 | 章节 |
|------|------|------|
| 1.3.2.1 | [01_cpp17_basics.md](01_cpp17_basics.md) | RAII、智能指针 |
| 1.3.2.2 | 同上 | 模板、变参 |
| 1.3.2.3 | 同上 | Lambda、move 语义、optional、string_view |

#### 1.3.3 编译工具链（1h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 1.3.3.1 | [foundations/03_build_toolchain.md](foundations/03_build_toolchain.md) | **新文档**：g++/cmake/make 基础，Python 程序员最缺这块 |

#### 1.3.4 实战代码（7h）

| 序号 | 文件 | 练习 |
|------|------|------|
| 1.3.4.1 | [02_cpp_infra/src/raii_demo.cpp](../02_cpp_infra/src/raii_demo.cpp) | 读懂 + 改一个智能指针的例子 |
| 1.3.4.2 | [02_cpp_infra/src/template_demo.cpp](../02_cpp_infra/src/template_demo.cpp) | 读懂 + 自己写一个模板函数 |
| 1.3.4.3 | [02_cpp_infra/src/modern_features.cpp](../02_cpp_infra/src/modern_features.cpp) | 读懂 + 跑通 |
| 1.3.4.4 | [02_cpp_infra/CMakeLists.txt](../02_cpp_infra/CMakeLists.txt) | 看懂 CMake 配置 |

### 1.4 基础知识（必须先懂）

- **编译 vs 解释**：C++ 是编译型，Python 是解释型。编译 = 把源码转成机器码（.exe / .so）
- **头文件 vs 源文件**：.h 声明，.cpp 实现。Python 没这个区分
- **指针 vs 引用**：Python 没有指针，这是 C++ 最大的门槛
- **内存管理**：Python 有 GC，C++ 要手动（或用智能指针 RAII）
- **类型系统**：C++ 是静态强类型，Python 是动态弱类型

### 1.5 输出物

- [ ] 能解释 RAII 是什么、为什么重要
- [ ] 能读懂 `std::unique_ptr<T>` 和 `std::shared_ptr<T>` 的区别
- [ ] 能写一个简单的模板函数（比如 `template<typename T> T add(T a, T b)`）
- [ ] 能用 cmake 编译 02_cpp_infra/ 项目

### 1.6 自检问题

1. 为什么 C++ 需要头文件而 Python 不需要？
2. `int* p` 和 `int &r` 的区别？
3. `std::move` 到底 move 了什么？
4. 智能指针怎么避免内存泄漏？

---

## 阶段 2：GPU 编程基础 - CUDA（第 4-5 周，14h）

### 2.1 目标

理解 GPU 架构（SIMT 模型），能写基础 CUDA kernel（vector_add、reduction、matmul），理解 memory coalescing 和 shared memory。

### 2.2 为什么学 CUDA

- 推理优化的核心是 GPU 编程
- 学了 CUDA 才能学 HIP（曙光 DCU）
- vLLM/SGLang 的 kernel 都是 CUDA/HIP 写的
- 不懂 CUDA 看不懂 profiler 输出

### 2.3 学习材料

#### 2.3.1 硬件基础（2h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 2.3.1.1 | [foundations/02_hardware_for_inference.md](foundations/02_hardware_for_inference.md) | **新文档**：CPU/GPU 架构、SIMT vs SIMD、内存层次 |


#### 2.3.2 CUDA 核心（4h）

| 序号 | 文件 | 章节 |
|------|------|------|
| 2.3.2.1 | [02_cuda_basics.md](02_cuda_basics.md) | grid/block/thread 模型 |
| 2.3.2.2 | 同上 | 共享内存、warp、bank conflict |
| 2.3.2.3 | 同上 | memory coalescing |

#### 2.3.3 实战 kernel（8h）

| 序号 | 文件 | 难度 | 练习 |
|------|------|------|------|
| 2.3.3.1 | [03_cuda_kernels/vector_add.cu](../03_cuda_kernels/vector_add.cu) | ⭐ | 跑通 + 改成 float4 向量化 |
| 2.3.3.2 | [03_cuda_kernels/reduction.cu](../03_cuda_kernels/reduction.cu) | ⭐⭐ | 读懂树形归约 |
| 2.3.3.3 | [03_cuda_kernels/matmul.cu](../03_cuda_kernels/matmul.cu) | ⭐⭐⭐ | 读懂 Tiled GEMM |
| 2.3.3.4 | [03_cuda_kernels/matmul_tensorcore.cu](../03_cuda_kernels/matmul_tensorcore.cu) | ⭐⭐⭐⭐ | 读懂 wmma，不要求会写 |

### 2.4 基础知识（必须先懂）

- **CPU vs GPU**：CPU 低延迟（强核少），GPU 高吞吐（弱核多）
- **SIMD vs SIMT**：CPU 用 SIMD（AVX），GPU 用 SIMT（warp）
- **warp**：GPU 最小执行单元，32 线程同步执行
- **内存层次**：register → shared memory → L1/L2 → global memory → host memory
- **kernel 启动开销**：CPU 调用 GPU kernel 有 ~5us 开销，所以小任务不适合 GPU

### 2.5 输出物

- [ ] 能画出 GPU 的 grid/block/thread 层次图
- [ ] 能解释为什么 shared memory 比 global memory 快 100x
- [ ] 能独立写出 vector_add kernel
- [ ] 能用 ncu profiler 看 kernel 的访存效率

### 2.6 自检问题

1. warp divergence 是什么？为什么影响性能？
2. shared memory 和 L1 cache 的关系？
3. 为什么 GEMM 要 tile？
4. TensorCore 和普通 CUDA core 的区别？

---

## 阶段 3：Attention 与 KV Cache（第 6 周，7h）

### 3.1 目标

从底层重新理解 Attention 机制（你已懂 PyTorch 层），理解 KV Cache 为什么是推理的核心瓶颈。

### 3.2 学习材料

| 序号 | 文件 | 时长 |
|------|------|------|
| 3.2.1 | [04_attention_kv_cache.md](04_attention_kv_cache.md) | 3h |
| 3.2.2 | [05_attention/python/standard_attention.py](../05_attention/python/standard_attention.py) | 1h |
| 3.2.3 | [05_attention/python/kv_cache_demo.py](../05_attention/python/kv_cache_demo.py) | 2h |
| 3.2.4 | [05_attention/python/attention_profiling.py](../05_attention/python/attention_profiling.py) | 1h |

### 3.3 基础知识

- **Attention 公式**：`softmax(QK^T / sqrt(d)) V`（你已懂）
- **为什么需要 KV Cache**：decode 时每生成一个 token，如果不缓存 KV，要重算所有历史 token 的 K/V
- **KV Cache 显存公式**：`2 × L × H × S × D × dtype_size`（L=层数，H=头数，S=序列长度，D=头维度）
- **MHA vs GQA vs MQA**：头数越多显存越大，GQA 是折中

### 3.4 输出物

- [ ] 能手算一个 7B 模型在 batch=32、seq=2048 下的 KV Cache 显存
- [ ] 能解释 KV Cache 为什么是推理（不是训练）特有的问题
- [ ] 跑通 attention_profiling.py，看懂 profiler 输出

---

## 阶段 4：推理框架核心（第 7-9 周，21h）

### 4.1 目标

深入理解 vLLM 三大核心创新（PagedAttention、Continuous Batching、Prefix Caching），能读懂关键源码。

### 4.2 学习材料

#### 4.2.1 vLLM 架构（5h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 4.2.1.1 | [05_vllm_architecture.md](05_vllm_architecture.md) | 架构总览 |
| 4.2.1.2 | [08_vllm_analysis/source_notes.py](../08_vllm_analysis/source_notes.py) | V1 源码导航 |

#### 4.2.2 PagedAttention（6h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 4.2.2.1 | [06_paged_attention.md](06_paged_attention.md) | 原理 + 源码 |
| 4.2.2.2 | [10_inference_engine/python/kv_cache.py](../10_inference_engine/python/kv_cache.py) | 简化实现（先看这个再读源码） |

#### 4.2.3 Continuous Batching（5h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 4.2.3.1 | [07_continuous_batching.md](07_continuous_batching.md) | 调度状态机 |
| 4.2.3.2 | [10_inference_engine/python/scheduler.py](../10_inference_engine/python/scheduler.py) | 简化调度器 |

#### 4.2.4 Preemption（2h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 4.2.4.1 | [25_preemption_implementation.md](25_preemption_implementation.md) | RECOMPUTE vs SWAP |
| 4.2.4.2 | [10_inference_engine/python/preemption_demo.py](../10_inference_engine/python/preemption_demo.py) | 模拟实现 |

#### 4.2.5 SGLang 对比（3h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 4.2.5.1 | [08_sglang_comparison.md](08_sglang_comparison.md) | 框架对比 |

### 4.3 基础知识

- **操作系统的虚拟内存**：PagedAttention 借鉴的就是 OS 的分页机制（逻辑页→物理页）
- **批处理（batching）**：多个请求一起算，提高 GPU 利用率
- **prefill vs decode**：prefill 是处理 prompt（计算密集），decode 是生成 token（访存密集）

### 4.4 输出物

- [ ] 能画出 PagedAttention 的 block table 示意图
- [ ] 能解释 Continuous Batching 为什么比 static batching 快
- [ ] 能讲清楚 preemption 的两种策略和触发条件
- [ ] 跑通 [10_inference_engine/python/run_demo.py](../10_inference_engine/python/run_demo.py)

### 4.5 自检问题

1. PagedAttention 解决了什么问题？（显存碎片 + 共享）
2. Continuous Batching 的"continuous"体现在哪？
3. 为什么 prefill 和 decode 要分开调度？
4. vLLM 的 KV Cache 和 SGLang 的 RadixAttention 区别？

---

## 阶段 5：算子优化（第 10-11 周，14h）

### 5.1 目标

理解 FlashAttention 的 IO-aware tiling 原理，能用 Triton 写简单算子，能写 PyTorch C++ Extension。

### 5.2 学习材料

| 序号 | 文件 | 时长 |
|------|------|------|
| 5.2.1 | [03_pytorch_extension.md](03_pytorch_extension.md) | 2h |
| 5.2.2 | [04_pytorch_extension/custom_relu_matmul.py](../04_pytorch_extension/custom_relu_matmul.py) | 2h |
| 5.2.3 | [04_pytorch_extension/stream_demo.py](../04_pytorch_extension/stream_demo.py) | 1h |
| 5.2.4 | [09_flash_attention.md](09_flash_attention.md) | 4h |
| 5.2.5 | [06_flash_attention/flash_attention_triton.py](../06_flash_attention/flash_attention_triton.py) | 3h |
| 5.2.6 | [05_attention/cuda/attention.cu](../05_attention/cuda/attention.cu) | 2h |
| 5.2.7 | [05_attention/cuda/kv_cache.cu](../05_attention/cuda/kv_cache.cu) | 2h |
| 5.2.8 | [05_attention/cuda/flash_attention.cu](../05_attention/cuda/flash_attention.cu) | 3h |

### 5.3 基础知识

- **roofline 模型**：算子的性能上限由"算力"或"带宽"决定，看算术强度
- **online softmax**：FlashAttention 的核心 trick，不用一次性加载所有 QK
- **CUDA stream**：异步执行队列，可以隐藏 H2D 拷贝延迟
- **Triton**：OpenAI 的 GPU 编程 DSL，比 CUDA 易写，比 PyTorch 高效

### 5.4 输出物

- [ ] 能解释 FlashAttention 为什么比朴素 attention 快
- [ ] 能跑通 Triton flash attention demo
- [ ] 能写一个 PyTorch C++ extension（自定义 op）

---

## 阶段 6：量化（第 12 周，7h）

### 6.1 目标

理解量化的数学原理（INT8/INT4），掌握 AWQ 和 GPTQ 两大方案，能部署量化模型。

### 6.2 学习材料

| 序号 | 文件 | 时长 |
|------|------|------|
| 6.2.1 | [10_quantization.md](10_quantization.md) | 2h |
| 6.2.2 | [21_awq_deployment.md](21_awq_deployment.md) | 1.5h |
| 6.2.3 | [24_gptq_vs_awq.md](24_gptq_vs_awq.md) | 1.5h |
| 6.2.4 | [07_quantization/python/int8_gemm_sim.py](../07_quantization/python/int8_gemm_sim.py) | 1h |
| 6.2.5 | [07_quantization/python/kv_cache_quant_sim.py](../07_quantization/python/kv_cache_quant_sim.py) | 1h |
| 6.2.6 | [07_quantization/cuda/int8_gemm.cu](../07_quantization/cuda/int8_gemm.cu) | 2h |
| 6.2.7 | [07_quantization/cuda/kv_cache_quant.cu](../07_quantization/cuda/kv_cache_quant.cu) | 2h |

### 6.3 基础知识

- **浮点数表示**：FP32 / FP16 / BF16 / INT8 / INT4 的差异
- **对称 vs 非对称量化**：zero-point 的作用
- **per-channel vs per-tensor vs per-group**：粒度越细精度越高但开销越大
- **校准（calibration）**：用少量数据确定 scale 和 zero-point

### 6.4 输出物

- [ ] 能解释为什么 INT4 量化能省 4x 显存
- [ ] 能讲清楚 AWQ 和 GPTQ 的核心差异（一阶 vs 二阶）
- [ ] 跑通 int8_gemm_sim.py 理解量化误差

---

## 阶段 7：服务化与 Profiler（第 13 周，7h）

### 7.1 目标

掌握推理服务的核心指标（TTFT/TPOT/P99），能用 Nsight 定位性能瓶颈。

### 7.2 学习材料

| 序号 | 文件 | 时长 |
|------|------|------|
| 7.2.1 | [18_service_metrics.md](18_service_metrics.md) | 3h |
| 7.2.2 | [19_nsight_lab.md](19_nsight_lab.md) | 4h |
| 7.2.3 | [26_real_optimization_workflow.md](26_real_optimization_workflow.md) | 3h |
| 7.2.4 | [10_inference_engine/python/benchmark_serving.py](../10_inference_engine/python/benchmark_serving.py) | 2h |

### 7.3 基础知识

- **延迟 vs 吞吐**：延迟 = 单请求耗时，吞吐 = 单位时间完成请求数
- **P50/P90/P99**：尾延迟，P99 是 SLO 的关键
- **Little's Law**：`L = λ × W`（并发数 = 到达率 × 平均延迟）
- **profiler 分类**：system-level（nsys）看时间线，kernel-level（ncu）看单 kernel 细节

### 7.4 输出物

- [ ] 能用 Little's Law 算出给定 QPS 需要多少并发
- [ ] 能用 nsys 抓 vLLM 的 timeline，找出 GPU idle 时间
- [ ] 能用 ncu 分析一个 kernel 的 roofline

---

## 阶段 8：高级主题（第 14-15 周，14h）

### 8.1 目标

掌握现代推理系统的高级优化：分布式、投机解码、MoE、Prefix Caching。

### 8.2 学习材料（按子主题分）

#### 8.2.1 Prefix Caching（2h）

| 序号 | 文件 |
|------|------|
| 8.2.1.1 | [20_prefix_caching.md](20_prefix_caching.md) |
| 8.2.1.2 | [05_attention/python/prefix_caching_demo.py](../05_attention/python/prefix_caching_demo.py) |

#### 8.2.2 分布式推理（4h）

| 序号 | 文件 |
|------|------|
| 8.2.2.1 | [15_distributed_inference.md](15_distributed_inference.md) |

#### 8.2.3 投机解码（4h）

| 序号 | 文件 |
|------|------|
| 8.2.3.1 | [16_speculative_decoding.md](16_speculative_decoding.md) |
| 8.2.3.2 | [23_eagle_practice.md](23_eagle_practice.md) |
| 8.2.3.3 | [05_attention/python/eagle_speculative_demo.py](../05_attention/python/eagle_speculative_demo.py) |

#### 8.2.4 MoE（2h）

| 序号 | 文件 |
|------|------|
| 8.2.4.1 | [17_moe_inference.md](17_moe_inference.md) |

#### 8.2.5 KV Cache 优化（2h）

| 序号 | 文件 |
|------|------|
| 8.2.5.1 | [11_kv_cache_optimization.md](11_kv_cache_optimization.md) |

### 8.3 输出物

- [ ] 能解释 Prefix Caching 在多轮对话场景的收益
- [ ] 能画出 TP=2 的 all-reduce 通信图
- [ ] 能讲清楚 EAGLE 为什么比 Medusa 接受率高

---

## 阶段 9：手写推理引擎（第 16 周，7h）

### 9.1 目标

通过手写一个简化推理引擎，把前面学的所有知识串起来。

### 9.2 学习材料

| 序号 | 文件 | 说明 |
|------|------|------|
| 9.2.1 | [10_inference_engine/python/README.md](../10_inference_engine/python/README.md) | 导读 |
| 9.2.2 | [10_inference_engine/python/model.py](../10_inference_engine/python/model.py) | TinyLLM |
| 9.2.3 | [10_inference_engine/python/kv_cache.py](../10_inference_engine/python/kv_cache.py) | 分页 KV Cache (Python 版) |
| 9.2.4 | [10_inference_engine/python/scheduler.py](../10_inference_engine/python/scheduler.py) | 调度器 (Python 版) |
| 9.2.5 | [10_inference_engine/python/engine.py](../10_inference_engine/python/engine.py) | 主循环 (Python 版) |
| 9.2.6 | [10_inference_engine/python/run_demo.py](../10_inference_engine/python/run_demo.py) | 启动脚本 |
| 9.2.7 | [10_inference_engine/cpp/paged_kv_cache.cu](../10_inference_engine/cpp/paged_kv_cache.cu) | 分页 KV Cache (C++/CUDA 版) |
| 9.2.8 | [10_inference_engine/cpp/scheduler.cpp](../10_inference_engine/cpp/scheduler.cpp) | 调度器 (C++ 版) |
| 9.2.9 | [10_inference_engine/cpp/engine.cpp](../10_inference_engine/cpp/engine.cpp) | 主循环 (C++ 版) |

### 9.3 输出物

- [ ] 跑通 run_demo.py
- [ ] 自己加一个特性（比如优先级队列、或 chunked prefill）

---

## 阶段 10：SGLang 源码（第 17 周，7h）

### 10.1 目标

读懂 SGLang 的关键源码（RadixCache、Scheduler、ModelRunner）。

### 10.2 学习材料

| 序号 | 文件 |
|------|------|
| 10.2.1 | [22_sglang_source_analysis.md](22_sglang_source_analysis.md) |
| 10.2.2 | [09_sglang_analysis/source_notes.py](../09_sglang_analysis/source_notes.py) |

---

## 阶段 11：曙光专篇 - DCU/HIP（第 18-19 周，14h）

### 11.1 目标

掌握海光 CPU 优化和 DCU/HIP 编程，能做 CUDA→HIP 迁移。**这是你的差异化竞争力**。

### 11.2 学习材料

#### 11.2.1 海光 CPU 优化（4h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 11.2.1.1 | [13_sugon_hygon_cpu.md](13_sugon_hygon_cpu.md) | AVX/AMX/NUMA/绑核/HugePage |


#### 11.2.2 DCU + HIP 编程（6h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 11.2.2.1 | [14_sugon_dcu_hip.md](14_sugon_dcu_hip.md) | DCU 架构 + HIP 编程 + ROCm 工具链 |
| 11.2.2.2 | [11_dcu_migration/hip_vector_add.cpp](../11_dcu_migration/hip_vector_add.cpp) | HIP 版 vector_add |
| 11.2.2.3 | [11_dcu_migration/hip_matmul.cpp](../11_dcu_migration/hip_matmul.cpp) | HIP 版 matmul |
| 11.2.2.4 | [11_dcu_migration/wavefront_adapt.md](../11_dcu_migration/wavefront_adapt.md) | wavefront=64 适配 |

#### 11.2.3 CUDA→HIP 迁移实战（4h）

| 序号 | 文件 | 说明 |
|------|------|------|
| 11.2.3.1 | [11_dcu_migration/hipify_demo.sh](../11_dcu_migration/hipify_demo.sh) | 自动迁移脚本 |
| 11.2.3.2 | 把 [03_cuda_kernels/vector_add.cu](../03_cuda_kernels/vector_add.cu) 手动迁移成 HIP | 实战练习 |

### 11.3 基础知识（关键差异点）

- **wavefront=64 vs warp=32**：DCU 一个 wavefront 64 线程，NVIDIA 一个 warp 32 线程
- **HIP ≈ CUDA 95%**：语法几乎一样，关键字 `__global__` 等都兼容
- **5% 差异**：`cudaMalloc` → `hipMalloc`，`cudaMemcpy` → `hipMemcpy` 等
- **ROCm 工具链**：`hipcc`（替代 nvcc）、`rocm-smi`（替代 nvidia-smi）、`rocprof`（替代 ncu）
- **shared memory 在 DCU 上叫 local memory**（LDS）

### 11.4 输出物

- [ ] 能解释 wavefront=64 对 kernel 编写的影响
- [ ] 能把一个简单 CUDA kernel 迁移成 HIP
- [ ] 能用 rocprof profile 一个 HIP kernel

---

---

## 学习节奏建议

### 推荐时间分配（日均 1h）

```
工作日 1h：30min 看文档 + 30min 跑代码
周末 2-3h：集中做实战练习
```

### 每周节奏

- **周一-周二**：通读当周文档（标记不懂的地方）
- **周三-周四**：跑通对应代码，对照文档理解
- **周五**：做自检问题
- **周末**：实战练习 + 补充笔记

### 关键里程碑

| 时间 | 里程碑 | 验证方式 |
|------|--------|---------|
| 第 3 周末 | 能读懂 C++ | 看 02_cpp_infra/ 代码无障碍 |
| 第 5 周末 | 能写 CUDA kernel | 独立写 vector_add |
| 第 9 周末 | 能读懂 vLLM 源码 | 讲清楚 PagedAttention |
| 第 13 周末 | 能定位性能瓶颈 | 用 nsys 找出 GPU idle |
| 第 17 周末 | 能讲清楚推理全链路 | 从 prompt 到 token 全流程 |
| 第 19 周末 | 能做 CUDA→HIP 迁移 | 迁移一个 kernel |

---

## 自检清单（入职前应该都能答上来）

### 基础概念

- [ ] 推理和训练的核心差异
- [ ] KV Cache 显存公式
- [ ] prefill vs decode 的计算特征

### 框架机制

- [ ] PagedAttention 解决什么问题
- [ ] Continuous Batching 的状态机
- [ ] Preemption 的两种策略
- [ ] Prefix Caching 的命中条件

### 性能优化

- [ ] FlashAttention 的 IO-aware tiling
- [ ] 量化的精度-速度权衡
- [ ] TTFT/TPOT/P99 的定义
- [ ] Little's Law 容量规划

### 硬件相关

- [ ] CPU vs GPU 架构差异
- [ ] CUDA 的 grid/block/thread
- [ ] wavefront=64 vs warp=32（曙光）
- [ ] HIP 和 CUDA 的差异

### 实战能力

- [ ] 读懂 C++17 代码
- [ ] 写简单 CUDA kernel
- [ ] 用 nsys/ncu profile
- [ ] 做 CUDA→HIP 迁移

---

## 备注与延伸

1. **3 个月紧凑版**：跳过阶段 8 的 8.2.4 MoE 和阶段 10 SGLang 源码，阶段 11 压缩到 1 周
2. **6 个月深入版**：每个阶段翻倍时间，加 CUTLASS 深入、TensorRT-LLM、PD 分离实战
3. **曙光特色强化**：阶段 11 可以提前到阶段 5 之后，边学 CUDA 边对照 HIP
4. **面试导向**：重点看每个阶段的"自检问题"，这些是高频考点

> 文档维护：本路线图随学习进展持续更新。每完成一个阶段，在对应章节标记 ✅。
