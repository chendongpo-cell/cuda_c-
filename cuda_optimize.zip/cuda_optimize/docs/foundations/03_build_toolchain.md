﻿# 编译工具链：从 pip install 到 cmake/make

> **定位**：PyTorch 工程师习惯了 `pip install` 和 `python xxx.py`，但 C++/CUDA 项目要自己编译。这份文档帮你跨过"我不会编译"的门槛。
>
> **前置**：会命令行基础。
>
> **目标**：能用 cmake 编译 C++/CUDA 项目，看懂 CMakeLists.txt，能自己加一个源文件。
>
> **配套**：[02_cpp_infra/CMakeLists.txt](../../02_cpp_infra/CMakeLists.txt)、[03_cuda_kernels/CMakeLists.txt](../../03_cuda_kernels/CMakeLists.txt)、[04_pytorch_extension/setup.py](../../04_pytorch_extension/setup.py)。

---

## 0. 为什么 PyTorch 工程师要学编译

Python 是解释型，写完就跑。C++/CUDA 是编译型，要先转成机器码：

```
源码 (.cpp/.cu)  →  [编译器]  →  可执行文件 (.exe/.out) 或库 (.so/.dll)
```

**你必须懂编译的原因**：
1. vLLM/SGLang 从源码部署要编译
2. 自己写 CUDA kernel 要编译
3. PyTorch C++ Extension 要编译
4. 改一行 C++ 代码不会自动生效，要重新编译
5. 编译错误 vs 运行错误要分得清

---

## 1. 编译器基础

### 1.1 主流编译器

| 编译器 | 用途 | 曙光环境 |
|--------|------|---------|
| gcc / g++ | C / C++ | ✅ |
| clang / clang++ | C / C++ | 可选 |
| nvcc | CUDA | NVIDIA GPU |
| **hipcc** | HIP（DCU） | ✅ DCU 必用 |
| MSVC | Windows C++ | Windows |

### 1.2 g++ 基础用法

```bash
# 最简单：单文件编译
g++ main.cpp -o main
./main

# 加 C++17 标准
g++ -std=c++17 main.cpp -o main

# 加优化（-O2 是常用级别）
g++ -std=c++17 -O2 main.cpp -o main

# 加调试信息
g++ -std=c++17 -g main.cpp -o main

# 多文件编译
g++ -std=c++17 main.cpp util.cpp -o main

# 警告全开
g++ -std=c++17 -Wall -Wextra main.cpp -o main
```

**常用参数表**：

| 参数 | 含义 |
|------|------|
| `-std=c++17` | 用 C++17 标准 |
| `-O0 / -O1 / -O2 / -O3` | 优化级别（O0 不优化用于调试，O2 常用） |
| `-g` | 加调试信息 |
| `-Wall -Wextra` | 开启警告 |
| `-I/path/to/include` | 加头文件搜索路径 |
| `-L/path/to/lib` | 加库搜索路径 |
| `-lmylib` | 链接 libmylib.so |
| `-o output` | 输出文件名 |
| `-c` | 只编译不链接（生成 .o） |

### 1.3 编译的四个阶段

```
main.cpp  →  预处理  →  编译  →  汇编  →  链接  →  可执行文件
              (.i)       (.s)      (.o)              (.out)
```

**预处理**：处理 `#include`、`#define`，展开宏
```bash
g++ -E main.cpp -o main.i   # 看预处理结果
```

**编译**：转成汇编
```bash
g++ -S main.i -o main.s
```

**汇编**：转成机器码（.o 文件）
```bash
g++ -c main.s -o main.o
```

**链接**：把多个 .o 和库链接成可执行
```bash
g++ main.o util.o -o main
```

**Python 类比**：Python 没有显式编译步骤，但 `.pyc` 文件是 Python 解释器自动编译的字节码。

---

## 2. CMake：C++ 项目的"setup.py"

### 2.1 为什么用 CMake

直接用 g++ 编译：
- 单文件可以
- 多文件、多依赖、跨平台 → 命令行爆炸

CMake 是 C++ 的构建系统生成器，根据 `CMakeLists.txt` 生成 Makefile 或 VS 工程。

**Python 类比**：
- CMakeLists.txt ≈ `setup.py` / `pyproject.toml`
- cmake ≈ `pip install .`
- make ≈ 实际编译动作

### 2.2 最简单的 CMakeLists.txt

```cmake
# 声明 CMake 最低版本
cmake_minimum_required(VERSION 3.10)

# 声明项目名
project(MyProject)

# 设置 C++ 标准
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# 创建可执行文件
add_executable(main main.cpp)
```

### 2.3 编译流程

```bash
# 1. 创建 build 目录（避免污染源码目录）
mkdir build
cd build

# 2. 生成 Makefile（配置阶段）
cmake ..

# 3. 编译（构建阶段）
make

# 4. 运行
./main
```

**为什么要有 build 目录**：
- 编译产物（.o, .so, 可执行文件）和源码分离
- 想清理：`rm -rf build/` 即可
- 改了 CMakeLists.txt 要重新 `cmake ..`

### 2.4 实战：看 [02_cpp_infra/CMakeLists.txt](../../02_cpp_infra/CMakeLists.txt)

实际项目的 CMakeLists.txt 更复杂，常见模式：

```cmake
cmake_minimum_required(VERSION 3.10)
project(cpp_infra CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# 加编译选项
add_compile_options(-Wall -Wextra)

# 找 GoogleTest 包
find_package(GTest REQUIRED)

# 加多个源文件
add_executable(raii_demo src/raii_demo.cpp)
add_executable(template_demo src/template_demo.cpp)
add_executable(modern_features src/modern_features.cpp)

# 链接库
target_link_libraries(raii_demo GTest::gtest_main)

# 加头文件路径
target_include_directories(raii_demo PRIVATE include/)
```

**关键命令表**：

| 命令 | 作用 |
|------|------|
| `cmake_minimum_required(VERSION X)` | CMake 最低版本 |
| `project(Name)` | 项目名 |
| `set(VAR value)` | 设置变量 |
| `add_executable(name src...)` | 定义可执行文件 |
| `add_library(name src...)` | 定义库 |
| `target_link_libraries(name lib...)` | 链接库 |
| `target_include_directories(name path...)` | 加头文件路径 |
| `find_package(Package)` | 找第三方包 |
| `add_compile_options(...)` | 加编译选项 |
| `add_subdirectory(dir)` | 包含子目录 |

### 2.5 CUDA 项目的 CMakeLists.txt

CUDA 项目要加：

```cmake
# 启用 CUDA 语言
enable_language(CUDA)

# 指定 GPU 架构（A100 是 sm_80）
set(CMAKE_CUDA_ARCHITECTURES 80)

# 加 CUDA 可执行文件
add_executable(vector_add vector_add.cu)

# 链接 cudart（CUDA runtime）
target_link_libraries(vector_add cuda)
```

详见 [03_cuda_kernels/CMakeLists.txt](../../03_cuda_kernels/CMakeLists.txt)。

---

## 3. Makefile 基础（够看就行）

CMake 生成的是 Makefile，了解 Makefile 能帮你调试。

### 3.1 最简单的 Makefile

```makefile
# 变量
CXX = g++
CXXFLAGS = -std=c++17 -O2 -Wall

# 默认目标
all: main

# 编译规则
main: main.o util.o
	$(CXX) $(CXXFLAGS) main.o util.o -o main

main.o: main.cpp
	$(CXX) $(CXXFLAGS) -c main.cpp -o main.o

util.o: util.cpp
	$(CXX) $(CXXFLAGS) -c util.cpp -o util.o

# 清理
clean:
	rm -f *.o main
```

**注意**：Makefile 的缩进必须是 **Tab**，不是空格！

### 3.2 常用 make 命令

```bash
make            # 编译默认目标
make main       # 编译 main
make clean      # 清理
make -j4        # 并行编译（4 个任务）
make install    # 安装（如果配置了）
```

---

## 4. PyTorch C++ Extension 的编译

PyTorch 支持用 C++/CUDA 写自定义 op，有两种编译方式：

### 4.1 JIT 编译（运行时编译）

```python
# fused_relu_matmul_jit.py
import torch
from torch.utils.cpp_extension import load

# 加载时编译
ext = load(
    name="fused_relu_matmul",
    sources=["csrc/fused_relu_matmul_kernel.cu"],
    verbose=True,
)

# 用起来和普通 PyTorch op 一样
output = ext.fused_relu_matmul(input, weight)
```

**优点**：不用提前 setup.py，运行时编译。
**缺点**：第一次运行慢。

详见 [04_pytorch_extension/fused_relu_matmul_jit.py](../../04_pytorch_extension/fused_relu_matmul_jit.py)。

### 4.2 setup.py 预编译

```python
# setup.py
from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name="my_extension",
    ext_modules=[
        CUDAExtension(
            name="my_ext",
            sources=["csrc/my_kernel.cu"],
            extra_compile_args={
                "cxx": ["-O3"],
                "nvcc": ["-O3", "--use_fast_math"],
            },
        )
    ],
    cmdclass={"build_ext": BuildExtension},
)
```

编译：
```bash
python setup.py install
```

之后在 Python 里直接 `import my_ext`。

详见 [04_pytorch_extension/setup.py](../../04_pytorch_extension/setup.py)。

---

## 5. 曙光 DCU 的编译（hipcc）

DCU 用 hipcc 替代 nvcc：

```bash
# CUDA 编译
nvcc -std=c++17 -O2 vector_add.cu -o vector_add

# HIP 编译（DCU）
hipcc -std=c++17 -O2 hip_vector_add.cpp -o vector_add
```

**CMakeLists.txt 的 HIP 版本**：

```cmake
# 替换 enable_language(CUDA)
enable_language(HIP)

# 替换 CMAKE_CUDA_ARCHITECTURES
set(CMAKE_HIP_ARCHITECTURES gfx906)  # MI100/DCU 架构

# 链接 hip runtime
target_link_libraries(vector_add hip::host)
```

**hipify 工具**：自动把 CUDA 代码转成 HIP 代码
```bash
hipify-perl vector_add.cu > hip_vector_add.cpp
```

详见 [11_dcu_migration/hipify_demo.sh](../../11_dcu_migration/hipify_demo.sh) 和 [14_sugon_dcu_hip.md](../14_sugon_dcu_hip.md)。

---

## 6. 常见编译错误排查

### 6.1 头文件找不到

```
fatal error: 'foo.h' file not found
```

**原因**：编译器找不到头文件路径。
**解决**：
- 加 `-I/path/to/include`（g++）
- 或在 CMake 里 `target_include_directories(target PRIVATE /path)`

### 6.2 链接错误（undefined reference）

```
undefined reference to `foo(int)`
```

**原因**：声明了但没实现，或没链接库。
**解决**：
- 检查 .cpp 文件是否在 sources 里
- 加 `-lmylib` 或 `target_link_libraries(target mylib)`

### 6.3 CUDA 架构不匹配

```
nvcc fatal: Unsupported gpu architecture 'compute_90'
```

**原因**：CUDA 版本不支持该架构。
**解决**：检查 CUDA 版本和 GPU 架构对应关系：
- CUDA 11.x: sm_70 (V100) ~ sm_80 (A100)
- CUDA 12.x: 加 sm_90 (H100)

### 6.4 找不到 cuda 库

```
cannot find -lcuda
```

**解决**：设置 CUDA_HOME
```bash
export CUDA_HOME=/usr/local/cuda
export LD_LIBRARY_PATH=$CUDA_HOME/lib64:$LD_LIBRARY_PATH
```

### 6.5 CMake 找不到包

```
CMake Error: Could not find GTest
```

**解决**：
- Ubuntu: `apt install libgtest-dev`
- 或用 vcpkg / conan 包管理器

---

## 7. 学习路径建议

### 第 1 天：用 g++ 编译单文件

```bash
cd 02_cpp_infra/src
g++ -std=c++17 -o raii_demo raii_demo.cpp
./raii_demo
```

改一行代码，重新编译运行。

### 第 2 天：用 cmake 编译项目

```bash
cd 02_cpp_infra
mkdir build && cd build
cmake ..
make
./raii_demo
```

读懂 CMakeLists.txt。

### 第 3 天：编译 CUDA 项目

```bash
cd 03_cuda_kernels
mkdir build && cd build
cmake .. -DCMAKE_CUDA_ARCHITECTURES="80"
make
./vector_add
```

### 第 4 天：编译 PyTorch Extension

```bash
cd 04_pytorch_extension
python fused_relu_matmul_jit.py
```

观察 JIT 编译的输出日志。

### 第 5 天：编译 HIP 项目（曙光）

```bash
cd 11_dcu_migration
hipcc -std=c++17 -o hip_vector_add hip_vector_add.cpp
./hip_vector_add
```

---

## 8. 自检问题

1. g++ 和 gcc 的区别？
2. `-O2` 和 `-O3` 的区别？什么时候用哪个？
3. 为什么要 `mkdir build && cd build && cmake ..` 而不是直接 `cmake .`？
4. Makefile 的缩进用什么？
5. CUDA 项目的 CMakeLists.txt 和普通 C++ 项目有什么不同？
6. JIT 编译和 setup.py 预编译的 PyTorch Extension 各有什么优缺点？
7. hipcc 和 nvcc 的命令行参数兼容吗？
8. `undefined reference to xxx` 是编译错误还是链接错误？

---

## 9. 速查表

### g++ 常用命令

```bash
# 单文件
g++ -std=c++17 -O2 main.cpp -o main

# 多文件
g++ -std=c++17 -O2 main.cpp util.cpp -o main

# 只编译不链接
g++ -std=c++17 -c main.cpp -o main.o

# 加头文件路径
g++ -I./include main.cpp -o main

# 链接库
g++ main.cpp -lmylib -o main
```

### cmake 常用命令

```bash
# 配置
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release

# 构建
make -j4

# 安装
make install

# 清理
rm -rf build/
```

### 常用 CMake 变量

| 变量 | 含义 |
|------|------|
| `CMAKE_CXX_STANDARD` | C++ 标准 |
| `CMAKE_BUILD_TYPE` | Debug/Release/RelWithDebInfo |
| `CMAKE_CUDA_ARCHITECTURES` | CUDA GPU 架构 |
| `CMAKE_INSTALL_PREFIX` | 安装路径 |
| `CMAKE_CXX_FLAGS` | C++ 编译选项 |

### 架构代号（sm_xx）

| GPU | 架构代号 |
|-----|---------|
| V100 | sm_70 |
| T4 | sm_75 |
| A100 | sm_80 |
| H100 | sm_90 |
