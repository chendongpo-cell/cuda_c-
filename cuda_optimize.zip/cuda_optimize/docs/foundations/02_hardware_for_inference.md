﻿# 硬件架构基础：推理优化工程师必须懂的硬件知识

> **定位**：你不是硬件工程师，但推理优化是"软件吃硬件红利"。不懂硬件，你看不懂为什么 FlashAttention 快、为什么 TensorCore 快、为什么 PagedAttention 重要。
>
> **前置**：会用 PyTorch 训练模型。
>
> **目标**：建立"代码 → 硬件行为"的因果链。看到一个优化，能推出它在硬件上为什么有效。
>
> **配套**：[02_cuda_basics.md](../02_cuda_basics.md)、[09_flash_attention.md](../09_flash_attention.md)、[13_sugon_hygon_cpu.md](../13_sugon_hygon_cpu.md)、[14_sugon_dcu_hip.md](../14_sugon_dcu_hip.md)。

---

## 0. 一句话总览

推理优化的本质：**让代码尽量吃满硬件的算力或带宽，避免空转。**

要做到这点，你必须知道硬件有哪些"挡板"。

---

## 1. CPU 架构（你必须懂的基础）

### 1.1 CPU 的核心组件

```
┌─────────────────────────────────────────┐
│                  CPU                    │
│  ┌──────────┐  ┌──────────┐            │
│  │  Core 0  │  │  Core 1  │  ...       │
│  │ ┌──────┐ │  │ ┌──────┐ │            │
│  │ │ ALU  │ │  │ │ ALU  │ │  ALU=算术逻辑单元
│  │ ├──────┤ │  │ ├──────┤ │            │
│  │ │ L1   │ │  │ │ L1   │ │  L1=~1ns
│  │ │ cache│ │  │ │ cache│ │            │
│  │ └──────┘ │  │ └──────┘ │            │
│  └──────────┘  └──────────┘            │
│  ┌──────────────────────────┐          │
│  │       L2 cache           │          │  L2=~10ns
│  └──────────────────────────┘          │
│  ┌──────────────────────────┐          │
│  │       L3 cache (共享)    │          │  L3=~50ns
│  └──────────────────────────┘          │
│  ┌──────────────────────────┐          │
│  │     Memory Controller    │──────────┼─→ DRAM (~100ns)
│  └──────────────────────────┘          │
└─────────────────────────────────────────┘
```

### 1.2 关键参数（要记住的数量级）

| 层级 | 延迟 | 大小 |
|------|------|------|
| 寄存器 | <1ns | 几十个 |
| L1 cache | ~1ns | 32-64 KB/核 |
| L2 cache | ~10ns | 256KB-1MB/核 |
| L3 cache | ~50ns | 几 MB-几十 MB（共享） |
| DRAM（内存） | ~100ns | 几 GB-几 TB |
| SSD | ~100us | 几百 GB-几 TB |
| 网络 | ~1ms+ | - |

**核心结论**：内存比 cache 慢 100 倍，比寄存器慢 1000 倍。所以**优化推理 = 减少 cache miss**。

### 1.3 SIMD（单指令多数据）

CPU 通过 SIMD 一条指令处理多个数据：

```cpp
// 标量（一次 1 个）
for (int i = 0; i < 4; i++) c[i] = a[i] + b[i];  // 4 条指令

// SIMD（一次 4 个，AVX2）
__m128i va = _mm_loadu_si128((__m128i*)a);  // 一次加载 4 个 int
__m128i vb = _mm_loadu_si128((__m128i*)b);
__m128i vc = _mm_add_epi32(va, vb);          // 一次加 4 个
_mm_storeu_si128((__m128i*)c, vc);           // 一次存 4 个
// 1 条指令搞定 4 个加法
```

**SIMD 指令集**：
- AVX2：256 位，一次 8 个 float
- AVX-512：512 位，一次 16 个 float
- **AMX**（海光 CPU 支持）：矩阵计算专用，推理优化重要

**Python 类比**：PyTorch 的 `torch.add(a, b)` 底层就是用 SIMD 优化的。

### 1.4 NUMA（多 socket CPU）

```
┌─────────────┐         ┌─────────────┐
│   CPU 0     │◄────────│   CPU 1     │
│  (Node 0)   │  QPI    │  (Node 1)   │
│  ┌────────┐ │  互联    │  ┌────────┐ │
│  │ 本地   │ │         │  │ 本地   │ │
│  │ DRAM   │ │         │  │ DRAM   │ │
│  └────────┘ │         │  └────────┘ │
└─────────────┘         └─────────────┘
```

- CPU 0 访问自己的本地 DRAM：~100ns
- CPU 0 访问 CPU 1 的 DRAM：~200ns（远）

**推理优化启示**：
- 把模型权重绑到跑推理的 CPU 的本地 NUMA node
- 用 `numactl --cpunodebind=0 --membind=0 python serve.py`
- 详见 [13_sugon_hygon_cpu.md](../13_sugon_hygon_cpu.md)

### 1.5 CPU 优化推理的 3 个手段

1. **绑核**：把进程绑到固定核，避免 OS 调度抖动（影响 P99）
2. **HugePage**：用 2MB 大页代替 4KB 小页，减少 TLB miss
3. **NUMA 绑定**：CPU 和内存绑定在同一 node

---

## 2. GPU 架构（推理优化的主战场）

### 2.1 GPU vs CPU 设计哲学

| 维度 | CPU | GPU |
|------|-----|-----|
| 核数 | 少（8-64） | 多（数千） |
| 单核性能 | 强 | 弱 |
| 设计目标 | 低延迟 | 高吞吐 |
| 控制单元 | 大（分支预测等） | 小 |
| ALU 占比 | ~20% | ~80% |
| 适合任务 | 串行、复杂控制 | 并行、简单计算 |

**类比**：
- CPU = 几个老教授，能解复杂问题，但人少
- GPU = 上万名小学生，只会加减乘除，但人多

### 2.2 GPU 架构（NVIDIA）

```
┌──────────────────────────────────────┐
│              GPU (A100)              │
│  ┌──────────┐  ┌──────────┐         │
│  │   SM 0   │  │   SM 1   │  ...    │  SM = Streaming Multiprocessor
│  │ ┌──────┐ │  │ ┌──────┐ │         │  A100 有 108 个 SM
│  │ │ 32   │ │  │ │ 32   │ │         │
│  │ │ CUDA │ │  │ │ CUDA │ │         │  每 SM 有 64-128 个 CUDA core
│  │ │ cores│ │  │ │ cores│ │         │
│  │ ├──────┤ │  │ ├──────┤ │         │
│  │ │shared│ │  │ │shared│ │         │  每 SM 有 ~192KB shared/L1
│  │ │ mem  │ │  │ │ mem  │ │         │
│  │ ├──────┤ │  │ ├──────┤ │         │
│  │ │regis-│ │  │ │regis-│ │         │  每 SM 有 65536 寄存器
│  │ │ters  │ │  │ │ters  │ │         │
│  │ ├──────┤ │  │ ├──────┤ │         │
│  │ │ 4 个 │ │  │ │ 4 个 │ │         │
│  │ │Tensor│ │  │ │Tensor│ │         │  TensorCore 矩阵加速
│  │ │Cores │ │  │ │Cores │ │         │
│  │ └──────┘ │  │ └──────┘ │         │
│  └──────────┘  └──────────┘         │
│  ┌──────────────────────────────┐   │
│  │       L2 cache (40MB)        │   │
│  └──────────────────────────────┘   │
│  ┌──────────────────────────────┐   │
│  │     HBM (40-80GB, ~1.5TB/s)  │   │  ← GPU 显存
│  └──────────────────────────────┘   │
└──────────────────────────────────────┘
            │
            │  PCIe 4.0 (~64 GB/s) 或 NVLink (~600 GB/s)
            ▼
         CPU + DRAM
```

### 2.3 关键参数对比（A100）

| 层级 | 延迟 | 带宽 |
|------|------|------|
| 寄存器 | <1ns | ~13 TB/s |
| Shared memory | ~30ns | ~19 TB/s |
| L2 cache | ~100ns | ~5 TB/s |
| HBM (显存) | ~400ns | ~1.5 TB/s |
| 主机内存 (CPU DRAM) | ~10us | ~64 GB/s (PCIe) |

**核心结论**：
- shared memory 比 HBM 快 10 倍
- HBM 比 CPU 内存快 20 倍（带宽）
- PCIe 是最大瓶颈（H2D / D2H 传输）

### 2.4 SIMT 执行模型

GPU 用 SIMT（Single Instruction, Multiple Threads）执行：

```
一个 warp（32 线程）同时执行同一条指令
  ↓
thread 0: a[0] + b[0]
thread 1: a[1] + b[1]
...
thread 31: a[31] + b[31]
```

**warp divergence（分支分歧）**：
```cpp
// 假设一个 warp 内一半线程 i<16，一半 i>=16
if (i < 16) {
    x = a + b;   // 这一半线程执行
} else {
    x = a - b;   // 另一半执行
}
// GPU 实际执行：两个分支都跑一遍，一半线程空闲
// 性能损失 50%
```

**优化原则**：尽量让 warp 内线程走同一条分支。

### 2.5 CUDA 内存层次（必背）

| 层级 | 范围 | 速度 | 大小 | 谁负责 |
|------|------|------|------|--------|
| Register | 单线程 | 最快 | 几百个/线程 | 编译器 |
| Local memory | 单线程 | 慢（在 L1/L2） | - | 编译器（溢出时） |
| Shared memory | 单 block | 快 | ~192KB/SM | 程序员 `__shared__` |
| Global memory | 全 grid | 慢（HBM） | 几十 GB | 程序员 `cudaMalloc` |
| Constant memory | 全 grid | 快（有 cache） | 64KB | 程序员 `__constant__` |
| Texture memory | 全 grid | 中（有 cache） | - | 程序员 |

**推理优化的核心技巧**：把热数据从 global memory 搬到 shared memory，提速 10 倍。

### 2.6 TensorCore（A100/H100 的核武器）

普通 CUDA core：一次做一个 FMA（fused multiply-add）：
```
c = a * b + c   // 1 个乘加
```

TensorCore：一次做一个矩阵乘加：
```
D[16x16] = A[16x16] * B[16x16] + C[16x16]
// 一次 16x16x16 矩阵乘加，4096 个 FMA！
```

**性能差距**：
- A100 CUDA core FP16: ~156 TFLOPS
- A100 TensorCore FP16: ~312 TFLOPS（2x）
- A100 TensorCore BF16: ~312 TFLOPS
- A100 TensorCore INT8: ~624 TOPS（4x）

**启示**：
- 推理要尽量用 TensorCore（用半精度 + 矩阵形状对齐到 16）
- 这就是为什么 FP16/BF16 量化对推理提速明显
- 详见 [03_cuda_kernels/matmul_tensorcore.cu](../../03_cuda_kernels/matmul_tensorcore.cu)

---

## 3. 内存层次对推理优化的指导

### 3.1 算术强度（Arithmetic Intensity）

```
算术强度 = 计算量 (FLOPs) / 访存量 (Bytes)
```

**roofline 模型**：
```
性能上限 = min(峰值算力, 峰值带宽 × 算术强度)
```

```
                ┌────────────── 算力瓶颈
性能          ╱
(TFLOPS)     ╱
            ╱
           ╱ ← 带宽瓶颈
          ╱
         ╱
        ╱
       └──────────────────── 算术强度 (FLOPs/Byte)
```

### 3.2 推理中常见操作的算术强度

| 操作 | 算术强度 | 瓶颈 |
|------|---------|------|
| matmul (大矩阵) | 高 | 算力 |
| matmul (小矩阵) | 中 | 平衡 |
| attention (短序列) | 中 | 平衡 |
| attention (长序列, 朴素) | 低 | 带宽 |
| FlashAttention | 高（重计算） | 算力 |
| elementwise (ReLU 等) | 低 | 带宽 |
| decode (batch=1) | 极低 | 带宽 |

**核心洞察**：
- 训练 / prefill：算力瓶颈 → 用 TensorCore
- decode（batch 小）：带宽瓶颈 → 用 batching / 量化省显存

### 3.3 为什么 decode 是带宽瓶颈

decode 时每生成一个 token：
- 要加载整个模型权重（几十 GB）
- 只算一次 matmul（output_dim 个乘加）
- 算术强度 ≈ 1（极低）

```
算术强度 ≈ output_dim / (权重字节)
        ≈ 4096 / 2 (FP16) = 2048 FLOPs/Byte
                  ↑
          看起来不低？
```

**但 batch=1 时**：算力没吃满，所以实际是带宽瓶颈。

**解决**：
- Continuous Batching：把多个 decode 请求 batch 起来
- 量化：减半权重字节
- 详见 [07_continuous_batching.md](../07_continuous_batching.md)

---

## 4. 海光 CPU + DCU 的特殊性（曙光必看）

### 4.1 海光 CPU

海光 CPU 是 x86 架构（基于 AMD Zen 授权），支持：
- AVX2 / AVX-512
- **AMX**（Advanced Matrix Extensions）：矩阵加速，类似 TensorCore
- 多 socket NUMA 架构

**和 Intel/AMD 的差异**：
- 微架构落后 1-2 代
- AMX 支持是亮点（CPU 上跑矩阵推理用）
- NUMA 调优对多 socket 服务器尤其重要

详见 [13_sugon_hygon_cpu.md](../13_sugon_hygon_cpu.md)。

### 4.2 DCU（深算一号）

DCU = 海光的 GPU，架构基于 AMD GPU（类 CDNA），用 **HIP** 编程（不是 CUDA）。

**和 NVIDIA GPU 的关键差异**：

| 维度 | NVIDIA (A100) | DCU (类 MI100) |
|------|--------------|----------------|
| 编程语言 | CUDA | HIP |
| 最小执行单元 | warp (32 线程) | **wavefront (64 线程)** |
| 矩阵加速 | TensorCore | Matrix Core |
| 显存 | HBM2e | HBM2 |
| 工具链 | nvcc, ncu, nsys | hipcc, rocprof, rocm-smi |
| 共享内存 | shared memory | **local memory (LDS)** |

**wavefront=64 的 5% 差异最坑**：
- NVIDIA 写 `for (int i = 0; i < 32; i++)` 处理一个 warp
- DCU 要改成 `for (int i = 0; i < 64; i++)` 处理一个 wavefront
- 不改的话性能直接掉 50%

详见 [14_sugon_dcu_hip.md](../14_sugon_dcu_hip.md) 和 [11_dcu_migration/](../../11_dcu_migration/)。

---

## 5. 推理优化的"硬件-软件"对应表

| 优化技术 | 利用的硬件特性 | 对应文档 |
|---------|---------------|---------|
| FlashAttention | shared memory + online softmax | [09_flash_attention.md](../09_flash_attention.md) |
| PagedAttention | 虚拟内存分页思想 | [06_paged_attention.md](../06_paged_attention.md) |
| Continuous Batching | 提高算术强度 | [07_continuous_batching.md](../07_continuous_batching.md) |
| TensorCore matmul | 矩阵加速单元 | [03_cuda_kernels/matmul_tensorcore.cu](../../03_cuda_kernels/matmul_tensorcore.cu) |
| 量化 (INT8/FP8) | TensorCore INT8 算力高 | [10_quantization.md](../10_quantization.md) |
| KV Cache 量化 | 减少显存带宽压力 | [11_kv_cache_optimization.md](../11_kv_cache_optimization.md) |
| Prefix Caching | 减少重复计算 | [20_prefix_caching.md](../20_prefix_caching.md) |
| 投机解码 | 减少串行 decode | [16_speculative_decoding.md](../16_speculative_decoding.md) |
| PD 分离 | prefill 算力瓶颈 vs decode 带宽瓶颈 | [15_distributed_inference.md](../15_distributed_inference.md) |
| NUMA 绑核 | 减少 NUMA 远端访问 | [13_sugon_hygon_cpu.md](../13_sugon_hygon_cpu.md) |
| HugePage | 减少 TLB miss | [13_sugon_hygon_cpu.md](../13_sugon_hygon_cpu.md) |

---

## 6. 学习路径建议

### 第 1 天：建立数量级感觉

记住这张表：

| 操作 | 时间 |
|------|------|
| L1 cache 命中 | 1ns |
| L2 cache 命中 | 10ns |
| L3 cache 命中 | 50ns |
| DRAM 访问 | 100ns |
| SSD 访问 | 100us |
| 网络往返 | 1ms |

看到任何代码，先想：这步是 cache 命中还是 miss？

### 第 2 天：理解 GPU 内存层次

读 [02_cuda_basics.md](../02_cuda_basics.md)，重点看：
- grid/block/thread
- shared memory
- coalesced access

### 第 3 天：理解算术强度

练习：算一下 Llama-7B decode 时（batch=1, seq=1）的算术强度。

### 第 4 天：硬件 → 优化的映射

复习第 5 节的对应表，把每个优化对应到硬件特性。

---

## 7. 自检问题

1. 为什么 shared memory 比 global memory 快 10 倍？
2. warp divergence 为什么损失性能？
3. TensorCore 和 CUDA core 的本质区别？
4. 算术强度 1 FLOP/Byte 的算子是算力瓶颈还是带宽瓶颈？
5. 为什么 decode（batch=1）是带宽瓶颈？
6. NUMA 远端访问比本地访问慢多少？
7. wavefront=64 vs warp=32，对 kernel 编写有什么影响？
8. PagedAttention 借鉴了 OS 的什么机制？

---

## 8. 速查表

### NVIDIA GPU 关键参数

| GPU | SM | CUDA cores | TensorCore | HBM | 带宽 |
|-----|-----|-----------|------------|-----|------|
| A100 | 108 | 6912 | 432 | 80GB | 2.0 TB/s |
| H100 | 132 | 16896 | 528 | 80GB | 3.35 TB/s |
| H200 | 132 | 16896 | 528 | 141GB | 4.8 TB/s |

### 海光 DCU 关键参数（参考公开资料）

| DCU | 计算单元 | 显存 | 带宽 |
|-----|---------|------|------|
| 深算一号 | 类 MI100 | 32GB HBM2 | ~1.2 TB/s |

### 单位换算

- 1 TFLOPS = 10^12 FLOPs/s
- 1 TB/s = 10^12 Bytes/s
- FP16 一个元素 = 2 Bytes
- INT8 一个元素 = 1 Byte
- INT4 一个元素 = 0.5 Byte
