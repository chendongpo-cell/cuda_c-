﻿# Python → C++ 衔接：给 PyTorch 工程师的 C++ 速通

> **定位**：你不是 C++ 新手，是 PyTorch 工程师。这份文档用 Python 类比讲 C++，帮你跨过最大的心智门槛。
>
> **前置**：会 Python + PyTorch。
>
> **目标**：读完这份，你能看懂推理框架（vLLM/SGLang）的 C++ 源码，知道每一行在干嘛。
>
> **配套**：[01_cpp17_basics.md](../01_cpp17_basics.md) 讲细节，本文件讲心智模型。

---

## 0. 为什么要从 Python 切到 C++

你可能会问：PyTorch 底层不也是 C++ 吗？我写 Python 不就够了？

**答案**：PyTorch 帮你封装好了，但代价是：

| 场景 | Python 够用吗 | 为什么 |
|------|:-------------:|--------|
| 训练模型 | ✅ | PyTorch eager 模式够用 |
| 跑 demo 推理 | ✅ | 慢点但能跑 |
| 生产推理服务 | ❌ | 延迟/吞吐不够，需要 vLLM 这类 C++ 框架 |
| 写 CUDA kernel | ❌ | kernel 本身就是 C++ |
| 读 vLLM 源码 | ❌ | 99% 是 C++ |
| 性能 profiling | ❌ | 要看 C++ 实现才知道瓶颈 |

**结论**：推理优化工程师必须懂 C++，不是"加分项"是"门槛"。

---

## 1. 心智模型差异：最大的 5 个冲击

### 1.1 编译 vs 解释

**Python（解释型）**：
```python
# 直接运行
x = [1, 2, 3]
print(x[0])
```
写完回车就跑，不用编译。

**C++（编译型）**：
```cpp
// main.cpp
#include <iostream>
#include <vector>
int main() {
    std::vector<int> x = {1, 2, 3};
    std::cout << x[0] << std::endl;
    return 0;
}
```
要先编译成机器码：
```bash
g++ -std=c++17 main.cpp -o main  # 编译
./main                            # 运行
```

**为什么 C++ 快**：编译时已经优化成机器码，运行时不需要解释。

**代价**：改一行代码要重新编译（大项目可能几分钟）。

### 1.2 静态类型 vs 动态类型

**Python**：
```python
x = 1          # x 是 int
x = "hello"    # 现在 x 是 str，没问题
```

**C++**：
```cpp
int x = 1;         // x 永远是 int
x = "hello";       // ❌ 编译错误
```

**适应策略**：
- C++ 里每个变量必须先声明类型
- 类型不能改
- 好处：编译器帮你抓 bug，性能更好

### 1.3 指针 vs 引用（Python 程序员最大门槛）

**Python**：所有变量都是"引用"，但你感觉不到
```python
a = [1, 2, 3]
b = a           # b 和 a 指向同一个 list
b.append(4)     # a 也变了
print(a)        # [1, 2, 3, 4]
```

**C++ 有三种"指向"方式**：

```cpp
// 1. 值（拷贝）
std::vector<int> a = {1, 2, 3};
std::vector<int> b = a;      // 拷贝，a 和 b 独立
b.push_back(4);              // a 不变

// 2. 引用（别名，必须立即绑定，不能改）
std::vector<int>& c = a;     // c 是 a 的别名
c.push_back(5);              // a 也变了

// 3. 指针（存地址，可以为 null，可以改指向）
std::vector<int>* d = &a;    // d 存 a 的地址
d->push_back(6);             // a 也变了（用 -> 不是 .）
```

**Python 类比**：
- C++ 值 = Python 里你以为是值其实也是引用的简单类型（int, str 不可变）
- C++ 引用 = Python 变量本身（别名）
- C++ 指针 = Python `id(x)` 返回的那个数字（地址）

**什么时候用哪个**：
- 默认用值（小对象）
- 不想拷贝大对象用 `const &`（const 引用，只读不拷贝）
- 需要"可能为空"或"要改指向"用指针

### 1.4 手动内存管理 vs GC

**Python**：自动 GC
```python
def f():
    x = [1, 2, 3]  # 创建
    # 函数结束，x 没人引用了，GC 会回收
```

**C++：两种模式**

#### 模式 A：栈对象（自动管理，像 Python）

```cpp
void f() {
    std::vector<int> x = {1, 2, 3};  // 创建（在栈上）
    // 函数结束，x 自动析构（销毁）
}
// 离开作用域自动清理，类似 Python
```

#### 模式 B：堆对象（手动管理）

```cpp
// 老式 C++（C 风格）
int* p = new int(42);   // 手动分配
delete p;               // 手动释放，忘了就内存泄漏

// 现代 C++：用智能指针，不用手动 delete
#include <memory>
auto p = std::make_unique<int>(42);  // 创建
// 离开作用域自动 delete，不用管
```

**关键概念 RAII**：Resource Acquisition Is Initialization。
资源获取即初始化 —— 对象创建时获取资源，对象销毁时释放资源。
这就是 C++ 智能指针的哲学，让你像 Python 一样不用管内存。

### 1.5 头文件 vs 模块

**Python**：一个 .py 文件就是一个模块
```python
# mymodule.py
def foo(): pass

# main.py
from mymodule import foo
```

**C++**：声明和实现分离
```cpp
// mymodule.h（头文件，声明）
#pragma once
void foo();

// mymodule.cpp（源文件，实现）
#include "mymodule.h"
void foo() { /* ... */ }

// main.cpp
#include "mymodule.h"
int main() { foo(); }
```

**为什么要分离**：
- .h 是"接口"，告诉别人有什么
- .cpp 是"实现"，具体怎么做
- 编译时只看 .h，链接时才找 .cpp

**Python 类比**：
- .h ≈ Python 的 `__init__.py` + 类型注解
- .cpp ≈ Python 的实际实现

---

## 2. PyTorch ↔ C++ 概念对照表

| PyTorch (Python) | C++ (推理框架) | 说明 |
|------------------|----------------|------|
| `torch.Tensor` | `at::Tensor` / `torch::Tensor` | 同一个东西，C++ 端叫 ATen |
| `model(x)` | `model->forward(x)` | C++ 用指针调用方法 |
| `nn.Linear` | `torch::nn::Linear` | 模块名一致 |
| `model.eval()` | `model->eval()` | 同名 |
| `with torch.no_grad():` | `torch::NoGradGuard guard;` | RAII 守卫 |
| `tensor.to("cuda")` | `tensor.to(torch::kCUDA)` | 设备枚举 |
| `tensor.detach()` | `tensor.detach()` | 同名 |
| `for x in loader:` | `for (auto& x : loader)` | range-for |
| `print(...)` | `std::cout << ... << std::endl` | 流式输出 |
| `f"{x}"` | `std::to_string(x)` 或 fmt 库 | 字符串格式化 |

---

## 3. 现代 C++ 必会的 7 个特性

### 3.1 auto 类型推导

```cpp
// 不写 auto
std::vector<int>::iterator it = v.begin();

// 写 auto，简洁
auto it = v.begin();
auto x = 42;          // int
auto y = 3.14;        // double
auto z = "hello"s;    // std::string
```

**Python 类比**：auto ≈ Python 的"变量类型自动推导"，但 C++ 是编译期决定，运行时不变。

### 3.2 智能指针

```cpp
#include <memory>

// unique_ptr：独占所有权（最常用）
auto p = std::make_unique<int>(42);
// 离开作用域自动 delete

// shared_ptr：共享所有权（引用计数）
auto p1 = std::make_shared<int>(42);
auto p2 = p1;  // 引用计数 +1
// 最后一个 shared_ptr 销毁时才 delete

// weak_ptr：观察 shared_ptr 不增加引用计数（避免循环引用）
std::weak_ptr<int> w = p1;
```

**Python 类比**：
- `unique_ptr` ≈ Python 唯一持有对象的引用
- `shared_ptr` ≈ Python 多个变量引用同一对象（GC 引用计数）
- 区别：C++ 是确定性销毁（离开作用域），Python 是非确定性（GC 时机不定）

### 3.3 RAII（资源获取即初始化）

```cpp
// 文件自动关闭
{
    std::ifstream f("data.txt");  // 打开
    // 用 f
}   // 离开作用域，自动关闭

// 锁自动释放
{
    std::lock_guard<std::mutex> lock(mtx);  // 加锁
    // 临界区
}   // 自动解锁
```

**Python 类比**：
```python
with open("data.txt") as f:
    # 用 f
# 自动关闭
```
C++ 的 RAII 比 Python `with` 更彻底，**所有**栈对象都自动析构。

### 3.4 移动语义（std::move）

```cpp
std::vector<int> a = {1, 2, 3, 4, 5};
std::vector<int> b = std::move(a);  // 把 a 的内容"搬"到 b
// a 现在是空的，b 拥有数据，没拷贝
```

**Python 类比**：Python 没这个概念，因为 Python 永远是引用。C++ `std::move` 是"我不要这个对象了，给你，避免拷贝"。

**什么时候用**：
- 函数返回大对象：`return std::move(big_obj);`（其实编译器会自动做 RVO）
- 把对象塞进容器：`v.push_back(std::move(x));`

### 3.5 Lambda 表达式

```cpp
// Python: lambda x: x * 2
auto f = [](int x) { return x * 2; };
f(21);  // 42

// 带捕获
int factor = 3;
auto g = [factor](int x) { return x * factor; };  // 捕获 factor
g(14);  // 42

// STL 算法用
std::vector<int> v = {3, 1, 4, 1, 5};
std::sort(v.begin(), v.end(), [](int a, int b) { return a > b; });
// 降序排序
```

**Python 类比**：
```python
f = lambda x: x * 2
# C++ 的 [factor] 相当于 Python 闭包自动捕获外部变量
```

### 3.6 模板

```cpp
// 泛型函数
template<typename T>
T add(T a, T b) {
    return a + b;
}

add<int>(1, 2);        // 3
add<double>(1.5, 2.5); // 4.0
add(1, 2);             // 自动推导 T=int

// 泛型类
template<typename T>
class Stack {
    std::vector<T> data;
public:
    void push(T x) { data.push_back(x); }
    T pop() { T x = data.back(); data.pop_back(); return x; }
};

Stack<int> s1;
Stack<std::string> s2;
```

**Python 类比**：
```python
# Python 用鸭子类型，不需要模板
def add(a, b):
    return a + b
```
C++ 模板的好处：编译期类型检查 + 性能（每个类型生成一份代码）。

### 3.7 std::optional（可能有值可能没有）

```cpp
#include <optional>

std::optional<int> find(const std::vector<int>& v, int target) {
    for (int x : v) {
        if (x == target) return x;
    }
    return std::nullopt;  // 没找到
}

auto r = find({1, 2, 3}, 2);
if (r.has_value()) {
    std::cout << *r;  // 2
}
```

**Python 类比**：
```python
def find(v, target):
    for x in v:
        if x == target:
            return x
    return None  # C++ 的 nullopt ≈ Python None
```

---

## 4. 第一次读 C++ 推理框架源码的 cheatsheet

vLLM/SGLang 源码里高频出现的模式：

### 4.1 类的写法

```cpp
// Python:
# class Scheduler:
#     def __init__(self):
#         self.queue = []
#     def add(self, req):
#         self.queue.append(req)

// C++:
class Scheduler {
private:
    std::vector<Request> queue_;   // 成员变量，带 _ 后缀是 Google 风格
public:
    Scheduler() : queue_() {}      // 构造函数
    void add(const Request& req) { // 成员函数
        queue_.push_back(req);
    }
};
```

### 4.2 头文件 + 源文件

```cpp
// scheduler.h
#pragma once
#include <vector>
#include "request.h"

class Scheduler {
public:
    void add(const Request& req);
    size_t size() const;  // const 表示不修改成员
private:
    std::vector<Request> queue_;
};

// scheduler.cpp
#include "scheduler.h"

void Scheduler::add(const Request& req) {
    queue_.push_back(req);
}

size_t Scheduler::size() const {
    return queue_.size();
}
```

### 4.3 智能指针持有对象

```cpp
// Python: self.model = LLM()
// C++:
class Engine {
    std::unique_ptr<LLM> model_;  // 独占
    std::shared_ptr<KVCache> cache_;  // 共享
public:
    Engine() {
        model_ = std::make_unique<LLM>();
        cache_ = std::make_shared<KVCache>();
    }
};
```

### 4.4 回调函数

```cpp
// Python: def schedule(callback): callback(x)
// C++:
void schedule(std::function<void(int)> callback) {
    callback(42);
}

// 调用
schedule([](int x) { std::cout << x; });
```

---

## 5. 常见坑（PyTorch 工程师转 C++ 必踩）

### 5.1 忘记 `;`

```cpp
int x = 1   // ❌ 缺分号
int y = 2;
```
Python 不需要分号，C++ 每条语句必须分号。

### 5.2 拷贝 vs 引用搞混

```cpp
void bad(std::vector<int> v) {  // 拷贝！大 vector 慢
    v.push_back(1);
}

void good(const std::vector<int>& v) {  // const 引用，不拷贝
    // 只读 v
}

void modify(std::vector<int>& v) {  // 引用，可修改
    v.push_back(1);
}
```

**规则**：
- 只读 → `const T&`
- 要改 → `T&`
- 要拷贝 → `T`（只对小对象）

### 5.3 NULL vs nullptr

```cpp
int* p = NULL;      // 老式，可能有歧义
int* p = nullptr;   // 现代，推荐
```

### 5.4 数组越界不报错（undefined behavior）

```cpp
std::vector<int> v = {1, 2, 3};
int x = v[100];   // ❌ 越界，但可能不报错，返回垃圾值
int y = v.at(100); // 抛异常，安全但慢
```
Python 越界会立刻 IndexError，C++ 默认不检查。

### 5.5 未初始化变量

```cpp
int x;          // ❌ 未初始化，值不确定
int y = 0;      // ✅ 显式初始化
```
Python 不初始化会 NameError，C++ 用未初始化变量是 UB。

---

## 6. 学习路径建议

### 第 1 天：装环境

```bash
# Windows: 装 Visual Studio 或 MinGW
# Linux: gcc 已预装
g++ --version  # 验证
```

### 第 2-3 天：读 [01_cpp17_basics.md](../01_cpp17_basics.md)

重点看：
- RAII
- 智能指针
- 模板
- Lambda

### 第 4-5 天：跑 [02_cpp_infra/](../../02_cpp_infra/) 代码

```bash
cd 02_cpp_infra/src
g++ -std=c++17 -o raii_demo raii_demo.cpp && ./raii_demo
g++ -std=c++17 -o template_demo template_demo.cpp && ./template_demo
g++ -std=c++17 -o modern_features modern_features.cpp && ./modern_features
```

每行代码问自己：这行在 Python 里怎么写？

### 第 6-7 天：自己写一个

练习：用 C++ 写一个简单的 BatchScheduler
- 有 `add_request(Request)` 方法
- 有 `next_batch(int max_batch_size)` 方法
- Request 是 struct，有 id 和 prompt_length

参考 [10_inference_engine/python/scheduler.py](../../10_inference_engine/python/scheduler.py) 的 Python 版，翻译成 C++。

---

## 7. 延伸阅读

- [cppreference.com](https://cppreference.com) — C++ 标准库权威文档
- [learncpp.com](https://learncpp.com) — 最佳 C++ 免费教程
- 《Effective Modern C++》Scott Meyers — C++11/14 最佳实践
- 《C++ Primer》— 入门经典（厚，可查阅）

---

## 8. 速查表

| 你想做的事 | C++ 怎么写 |
|-----------|-----------|
| 创建 vector | `std::vector<int> v = {1, 2, 3};` |
| 遍历 | `for (int x : v) {}` 或 `for (const auto& x : v)` |
| 字符串 | `std::string s = "hello";` |
| 字典 | `std::unordered_map<K, V>` |
| 集合 | `std::unordered_set<T>` |
| 智能指针 | `auto p = std::make_unique<T>();` |
| 打印 | `std::cout << x << std::endl;` |
| 异常 | `throw std::runtime_error("msg");` |
| 可空 | `std::optional<T>` |
| 函数对象 | `std::function<Ret(Args...)>` |
