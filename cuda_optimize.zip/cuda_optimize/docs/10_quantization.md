# 量化技术原理与工程实践

## 1. FP16/BF16/FP8/INT8 量化原理与权衡

### 1.1 浮点数格式概述

#### FP32 (IEEE 754 单精度)
- 1 bit 符号位 + 8 bit 指数位 + 23 bit 尾数位
- 动态范围：~1.4e-45 到 3.4e38
- 精度：约 7 位有效十进制数字
- 存储：4 bytes
- 训练的标准精度格式

#### FP16 (IEEE 754 半精度)
- 1 bit 符号位 + 5 bit 指数位 + 10 bit 尾数位
- 动态范围：~6.1e-5 到 6.6e4
- 精度：约 3-4 位有效十进制数字
- 存储：2 bytes（相比 FP32 减半）
- 问题：指数位只有 5 bit，容易上溢/下溢

#### BF16 (Brain Floating Point, Google)
- 1 bit 符号位 + 8 bit 指数位 + 7 bit 尾数位
- 动态范围：与 FP32 相同（8 bit 指数）
- 精度：约 2-3 位有效十进制数字（尾数少）
- 存储：2 bytes
- 优势：保持 FP32 的动态范围，训练更稳定
- 目前主流训练/推理格式

**FP16 vs BF16 对比**：
- FP16 精度更高（10 bit vs 7 bit 尾数），但动态范围窄（易溢出）
- BF16 精度更低，但动态范围同 FP32（不易溢出）
- 实践中 BF16 更常用于训练（梯度稳定），推理两者都可能用

#### FP8 (E4M3 和 E5M2)
- E4M3: 4 bit 指数 + 3 bit 尾数，最大值为 448
  - 用于前向传播（权重和激活）
- E5M2: 5 bit 指数 + 2 bit 尾数，最大值为 57344，精度更低但范围更广
  - 用于反向传播（梯度）
- 存储：1 byte
- 硬件支持：H100 (Hopper) 原生支持 FP8 张量核心
- FP8 训练可以达到与 FP16/BF16 接近的精度（需要精细的 scaling）

#### INT8
- 1 bit 符号位 + 7 bit 数值位
- 范围：[-128, 127] 有符号 或 [0, 255] 无符号
- 存储：1 byte
- 要求输入数据已被缩放到 [-128, 127] 范围内
- 推理加速显著：INT8 GEMM 比 FP16 GEMM 快约 2x，比 FP32 快 4x+

### 1.2 量化权衡总结

| 格式 | 存储 | 动态范围 | 精度 | 硬件支持 | 适用场景 |
|------|------|---------|------|---------|---------|
| FP32 | 4B | 极宽 | 高 | 所有 GPU | 训练基线 |
| FP16 | 2B | 窄 | 中高 | Turing+ | 训练/推理 |
| BF16 | 2B | 宽 | 中 | A100+ | 训练/推理 |
| FP8 | 1B | 窄 | 低 | H100+ | 推理/训练 |
| INT8 | 1B | 窄 | 低 | 所有 GPU | 推理（需 calibration） |
| INT4 | 0.5B | 极窄 | 极低 | 部分 GPU | 极低精度推理 |

---

## 2. 对称量化与非对称量化

### 2.1 对称量化 (Symmetric Quantization)

映射关系：x_int = clamp(round(x_fp / scale), -127, 127)

其中 scale = max(|x_fp|) / 127

特点：
- 零点 (zero point) 为 0
- 量化前后数值对称分布
- 适用于权重（通常对称分布在 0 附近）
- 实现更简单，计算效率更高

反量化：x_fp = x_int * scale

### 2.2 非对称量化 (Asymmetric Quantization)

映射关系：x_int = clamp(round(x_fp / scale + zero_point), 0, 255)

其中：
- scale = (max(x_fp) - min(x_fp)) / 255
- zero_point = round(-min(x_fp) / scale)

特点：
- 零点 (zero point) 可以是任意整数
- 可以更好地利用量化范围
- 适用于激活值（通常分布在 0 附近但可能有偏移）
- 计算时需要处理 zero_point，略微增加开销

反量化：x_fp = (x_int - zero_point) * scale

### 2.3 量化误差分析

量化误差主要来源：
1. **舍入误差**：浮点到整数的四舍五入
2. **截断误差**：超出量化范围的值被截断（clipping）

对称量化更适合权重（值对称、均值 0），非对称量化更适合激活（可通过 zero_point 偏移来匹配分布）。

---

## 3. AWQ/GPTQ 权重量化

### 3.1 GPTQ (Frantar et al., 2023)

基于 Optimal Brain Quantization (OBQ) 的后训练权重量化方法。

**核心思想**：
- 逐列（per-column/group）量化权重矩阵
- 在量化某一列时，用剩余列的误差来补偿
- 使用 Hessian 矩阵（二阶信息）来决定量化顺序

**算法流程**：
1. 收集校准数据（几百个样本）
2. 对每个线性层，计算权重矩阵 W 的 Hessian H = 2XX^T
3. 对权重逐列进行量化，每次量化后调整未量化的列来补偿误差
4. 使用 Cholesky 分解提高数值稳定性

**特点**：
- 后训练量化，无需完整训练
- 支持 4-bit 甚至 2-bit 量化
- 通常 group size = 128，每组共享 scale
- 量化后精度损失小（特别是 4-bit）

### 3.2 AWQ (Activation-Aware Weight Quantization, Lin et al., 2023)

**核心洞察**：
- 权重中只有约 1% 的 "salient"（显著）通道对模型输出影响大
- 这些显著通道可以通过激活值的分布来识别
- 对显著通道提高精度（更大的 scale），对不重要通道降低精度

**算法**：
1. 分析校准数据的激活分布，识别显著通道
2. 对权重进行 per-group 量化
3. 对显著通道的权重乘以一个大于 1 的 scale factor（等效于减少量化误差）
4. 将 scale factor 吸收到后续的 layernorm 或线性层中（不增加推理开销）

**特点**：
- 比 GPTQ 更简单、更快（无需 Hessian）
- 同等比特率下精度优于 GPTQ
- 特别适合 4-bit 量化
- 实现上更容易集成到推理引擎中

### 3.3 AWQ vs GPTQ 对比

| 特性 | GPTQ | AWQ |
|------|------|-----|
| 原理 | 二阶优化 (Hessian) | 激活感知缩放 |
| 校准速度 | 慢（需要矩阵求逆） | 快（只需前向统计） |
| 硬件要求 | 高（存储 Hessian） | 低 |
| 实现复杂度 | 高 | 中 |
| 精度 (4-bit) | 优秀 | 优秀 (略优) |
| 是否需要激活数据 | 是 | 是 |

---

## 4. SmoothQuant (激活量化)

### 4.1 问题：激活值难以量化

权重量化相对容易（权重分布稳定、对称），但激活量化面临挑战：
- 激活值分布范围大（不同 token 差异巨大）
- 存在 outlier（异常值通道），其值可达到其他通道的 100x
- 这些 outlier 使量化的 scale 被拉大，导致整体精度下降

### 4.2 SmoothQuant 核心思想

**数学迁移**：将激活值的量化难度"迁移"到权重上。

具体做法：
- 对每个通道，计算平滑因子 s = max(|X|)^α / max(|W|)^(1-α)
- 对激活进行平滑：X' = X / diag(s)
- 对权重进行补偿：W' = diag(s) * W
- α 控制迁移程度（α=0.5 时均匀均衡）

**原理**：
- 激活 outlier 导致激活量化困难
- 通过引入 s，将激活的方差转移到权重上
- 权重本来就相对容易量化（且可以提前量化好）
- 最终结果是激活和权重的量化难度都变得更均衡

### 4.3 SmoothQuant 的优势

- **无需训练**：后处理即可
- **支持 INT8 激活量化**：可以做到 W8A8（权重 INT8 + 激活 INT8）
- **精度损失小**：LLaMA-65B W8A8 几乎无损
- **与 FlashAttention 兼容**：融合到线性层前

---

## 5. vLLM 量化实现流程

### 5.1 vLLM 的量化架构

vLLM 支持多种量化方案（按代码目录 `vllm/model_executor/layers/quantization/`）：

```
quantization/
├── __init__.py          # 注册所有量化方案
├── awq.py               # AWQ 权重量化
├── gptq.py              # GPTQ 权重量化
├── awq_marlin.py        # AWQ + Marlin 内核
├── gptq_marlin.py       # GPTQ + Marlin 内核
├── smooth_quant.py      # SmoothQuant (W8A8)
├── fp8.py               # FP8 量化
└── kv_cache.py          # KV cache 量化
```

### 5.2 量化层替换流程

1. **模型加载阶段**:
   ```
   原始 Linear -> 替换为 QuantLinear (AWQ/GPTQ)
                -> 替换为 Fp8Linear (FP8)
   ```

2. **权重重构**:
   - 从量化 checkpoint 加载 scale 和 zero_point
   - 对每组的权重进行反量化（但保持量化格式存储）
   - 实际计算时，使用专用的量化 GEMM 内核

3. **前向传播**:
   - W4A16 (AWQ/GPTQ): 权重 INT4，激活 FP16
     使用 Marlin 内核 (Moore's law 之后更高效的稀疏矩阵乘)
   - W8A8 (SmoothQuant): 权重 INT8，激活 INT8
     使用 INT8 Tensor Core
   - FP8: 权重和激活均为 FP8
     使用 H100 FP8 Tensor Core

### 5.3 vLLM 量化配置

通过 `quantization` 参数指定：
```python
# 在 vLLM 中加载量化模型
llm = LLM(model="TheBloke/Llama-2-7B-AWQ", quantization="awq")
```

支持格式：
- `awq`: AWQ 格式
- `gptq`: GPTQ 格式  
- `squeezellm`: SqueezeLLM 格式
- `fp8`: FP8 格式
- `marlin`: Marlin 稀疏内核格式

### 5.4 AWQ 在 vLLM 中的实现流程

```
加载 AWQ checkpoint
  └─> AWQLinearMethod.quant_weights: 读取 qweight, qzeros, scales
  └─> AWQLinearMethod.apply: 前向调用
       └─> awq_gemm: INT4 权重 × FP16 激活
       └─> awq_dequant: 反量化以便处理 residual connection
  └─> 在 fused_moe 层中也有 AWQ 支持
```

关键性能优化：**Marlin 内核**（AWQ 和 GPTQ 都可用的高效量化 GEMM 内核）：
- 将量化权重重新排列为更友好的内存布局
- 使用 warp-level 矩阵分块
- 异步预取权重块
- 比标准 cuBLAS INT4 实现快 2-3 倍

---

## 6. KV Cache 量化 (KIVI, KVQuant)

### 6.1 KV Cache 量化动机

KV cache 在推理时存储所有历史 token 的 K 和 V 张量：
- 形状：[batch_size, num_layers, num_heads, seq_len, d_head]
- 对于 7B 模型，上下文 4K 时约 1-2 GB
- 对于 70B 模型，上下文 32K 时可达 50+ GB
- 是长上下文推理的主要显存瓶颈

KV cache 量化的目标是：**在不显著影响精度的情况下，将 KV cache 压缩为 INT8/FP8**。

### 6.2 KIVI (Kang et al., 2024)

KIVI 是一个 2-bit 到 8-bit 的 KV cache 量化方案。

**核心发现**：
- **K cache 更难量化**：K 的 channel 间差异大，需要 per-channel 量化
- **V cache 较易量化**：V 的 channel 间差异小，per-token 量化即可

**KIVI 方案**：
- K cache: per-channel 量化（每个 channel 独立 scale）
  - 设为分组量化（group size = 128）
- V cache: per-token 量化（每个 token 独立 scale）
  - 保持 key 的查找精度，value 检索对数值精度不敏感
- 非对称量化（考虑 K/V 分布不一定对称）

### 6.3 KVQuant (Zhao et al., 2024)

KVQuant 进一步改进了 KV cache 量化：

1. **Per-Channel + Per-Token 混合量化**：
   - Per-channel 用于 K（通道方差大）
   - Per-token 用于 V（token 间方差大）

2. **Non-uniform 量化**：
   - 使用非均匀量化网格（而非线性 grid）
   - 更适配值分布（K/V 值通常集中在 0 附近）

3. **Dense-and-Sparse 分解**：
   - outlier 通道保持高精度（FP16）
   - 常规通道使用 INT8/INT4

4. **前几个 tokens 特殊处理**：
   - 前几个 tokens 的 K/V 值特别大，需要更高的精度
   - 可以为前几个 tokens 分配更多的 bits

### 6.4 vLLM 中 KV Cache 量化实现

vLLM 的 KV cache 量化实现位于 `vllm/model_executor/layers/quantization/kv_cache.py`：

```python
# 伪代码：KV cache 量化流程
class KVCacheQuantizer:
    def quantize(self, key, value):
        # K: per-channel 量化
        k_scale = key.abs().max(dim=1) / 127
        k_quant = (key / k_scale).round().clamp(-128, 127).to(torch.int8)
        
        # V: per-token 量化
        v_scale = value.abs().max(dim=-1) / 127
        v_quant = (value / v_scale).round().clamp(-128, 127).to(torch.int8)
        
        return k_quant, k_scale, v_quant, v_scale
    
    def dequantize(self, k_quant, k_scale, v_quant, v_scale):
        k = k_quant * k_scale
        v = v_quant * v_scale
        return k, v
```

**性能收益**：
- INT8 KV cache：存储减半，带宽需求减半
- 可支持更长的上下文（2x 长度）或更大的 batch size

---

## 7. 面试题

### 7.1 基础概念

**Q1: 解释对称量化与非对称量化的区别，以及各自的适用场景。**

A: 对称量化的零点 z=0，范围 [-127, 127]；非对称量化的零点可以非零，范围 [0, 255]。对称量化适合权重（对称分布），非对称量化适合激活（可能有偏移）。非对称量化能更好利用量化范围但多了一个零点参数。

**Q2: AWQ 为什么选择对显著通道使用更大的 scale？**

A: AWQ 发现权重中 1% 的显著通道对模型输出影响大。乘上大于 1 的 scale factor 相当于降低了这些权重的相对量化误差（signal-to-quantization-noise ratio 提高）。这些 scale factor 被吸收到后续层中，不会增加计算量。

### 7.2 进阶问题

**Q3: SmoothQuant 如何实现激活量化？为什么能保持精度？**

A: SmoothQuant 将激活的量化难度转移到权重上（X'/W' = X·s / W/s）。因为激活有 outlier 导致量化困难，权重更容易量化。通过选择合适的迁移强度 α，使两者都变得容易量化。整个过程可以通过数学变换融合到线性层中，不增加推理开销。

**Q4: FP8 E4M3 和 E5M2 分别适用于什么场景？**

A: E4M3 范围小（max=448）但精度略高，适合前向传播的权重和激活。E5M2 范围大（max=57344）但精度低，适合反向传播的梯度（梯度范围变化大）。H100 硬件同时支持两种格式。

**Q5: KV cache 量化为什么 K 和 V 需要使用不同策略？**

A: K 的通道间方差大（不同 heads 关注不同特征），需要 per-channel 量化。V 的通道间方差小但 token 间方差大，需要 per-token 量化。K 的精度影响 attention score 计算，V 的精度影响加权求和。

### 7.3 系统设计

**Q6: 设计一个生产环境中的量化推理方案，需要考虑哪些因素？**

A: 1) 精度要求：确定目标 bit-width（W4A16 vs W8A8 vs FP8）
2) 硬件支持：目标 GPU 的 Tensor Core 支持哪种格式
3) 校准数据：选择代表性数据集，避免过拟合到校准集
4) 内核效率：使用 Marlin/TRT-LLM 等优化内核
5) KV cache 量化：长上下文场景下必须
6) 运行时开销：量化/反量化操作的融合
7) 动态 vs 静态：是否支持动态 per-token 量化

**Q7: 为什么 INT4 量化在 NVIDIA GPU 上并不比 INT8 快多少（有时甚至更慢）？**

A: 两个原因：1) NVIDIA Tensor Core 对 INT8 有原生支持，对 INT4 不是所有架构都支持（或需要额外解包操作）；2) INT4 的权重 packing/unpacking 开销显著。因此虽然 INT4 存储减半，但计算速度未必提升。Marlin 内核通过精心设计的内存布局部分解决了这个问题。
