﻿# Prefix Caching 实战

> 这是 vLLM 和 SGLang 都默认开启的核心优化。能让你在 system prompt 重复的场景下 TTFT 降低 5-10 倍。
>
> 学习定位：**理解为什么 prefix 可以复用、vLLM 和 SGLang 各自怎么实现、命中率怎么测、什么时候不适用**。
>
> 前置知识：[04_attention_kv_cache.md](04_attention_kv_cache.md)、[06_paged_attention.md](06_paged_attention.md)、[08_sglang_comparison.md](08_sglang_comparison.md)。

---

## 0. 一个真实场景

你部署了个客服助手 LLM，每次请求都是这样的结构：

```
[System Prompt 2000 tokens] + [User Query 50 tokens]
```

100 个不同用户来问问题，他们的 **system prompt 完全一样**，只有 user query 不同。

朴素做法：每个请求都重新算一遍 system prompt 的 prefill，2000 token × 100 次 = 20 万 token 的重复计算。

**Prefix Caching**：第一个请求算完 system prompt 后，把 KV Cache 存下来。后续 99 个请求直接复用，只算 user query 的 50 token。

**收益**：
- TTFT 从 ~500ms 降到 ~50ms（10 倍）
- 算力消耗降到 1/40
- 显存压力大（要存 cache），但用 PagedAttention 分页管理可控

---

## 1. 原理：为什么 KV Cache 能跨请求复用

回忆 Attention 的计算：

```
对于 token t:
Q_t = token_t @ W_Q
K_t = token_t @ W_K    ← 这个能复用!
V_t = token_t @ W_V    ← 这个也能复用!

Attention(t) = softmax(Q_t @ all_K^T / sqrt(d)) @ all_V
```

关键观察：**K_t 和 V_t 只取决于 token_t 和权重 W_K/W_V，跟其他 token 无关**。

所以：
- 如果两个请求的**前 N 个 token 完全相同**
- 它们前 N 个位置的 K、V 也完全相同
- 第一个请求算完后，KV Cache 里前 N 个位置的值可以直接给第二个请求用

这就是 prefix caching 的可行性基础。

**注意**：必须是**完全相同的 prefix**，差一个 token 都不行（因为 attention 是因果的，prefix 里任何一个 token 不同，后续所有 K/V 都不受影响 — 但 cache 命中点就断了）。

---

## 2. vLLM 的 Prefix Caching 实现

vLLM 的 Prefix Caching 基于 PagedAttention，叫 **Automatic Prefix Caching (APC)**。

### 2.1 核心思想：Block 级哈希

PagedAttention 把 KV Cache 分成固定大小的 block（默认 16 token/block）。vLLM 给每个 block 算一个**哈希值**：

```
block_hash = hash(block 内所有 token ids + 前一个 block 的 hash)
```

这个哈希是**链式**的：第 N 个 block 的 hash 依赖第 N-1 个的 hash。所以：
- 两个请求如果前 N 个 block 的 token 完全相同
- 它们的前 N 个 block hash 也完全相同
- 可以直接复用

### 2.2 工作流程

```
请求到来: prompt = [system_prompt_tokens..., user_query_tokens...]

  ↓
逐步走 prompt, 每 block_size 个 token 算一个 hash:

  block 0: hash(token[0..15])
  block 1: hash(token[16..31], block_0.hash)
  block 2: hash(token[32..47], block_1.hash)
  ...

  ↓
查全局 block pool:
  - 如果 block 0 的 hash 在 pool 里 → 复用物理块,不重算
  - 如果不在 → 算新 block,加入 pool
  - 同理 block 1, 2, ...

  ↓
最终 prefill 只需要算"未命中"的部分
```

### 2.3 命中粒度

注意 vLLM 的命中是**以 block 为粒度**的。如果 block_size=16：
- system prompt 长度 = 2000 → 125 个 block
- user query 长度 = 50 → 3 个 block
- 命中 125 个 block，新算 3 个

如果 system prompt 长度 = 2005（多了 5 个 token）：
- 2005 / 16 = 125.3 → 126 个 block
- 前 125 个 block 完全相同 → 命中
- 第 126 个 block 包含 5 个旧 token + 11 个新 token → **不命中**
- 所以 block_size 越小，命中率越高，但管理开销越大

### 2.4 开启方式

vLLM 0.4+ 默认开启 APC：

```bash
# 显式开启（新版本默认开）
vllm serve meta-llama/Llama-3-8B \
    --enable-prefix-caching

# 显式关闭（不推荐，除非有特殊原因）
vllm serve meta-llama/Llama-3-8B \
    --no-enable-prefix-caching
```

### 2.5 监控命中率

vLLM 的 Prometheus metrics 暴露了：

```
vllm:gpu_prefix_cache_queries_total     # 查询次数
vllm:gpu_prefix_cache_hits_total        # 命中次数
vllm:gpu_prefix_cache_hit_rate          # 命中率
```

也可以从日志看：

```
INFO: GPU prefix cache hit rate: 0.87 (8741/10000)
```

---

## 3. SGLang 的 RadixAttention

SGLang 用了一个更通用的结构：**Radix Tree（基数树）** 来管理 KV Cache。

### 3.1 为什么用树而不是链表

vLLM 的 APC 只能匹配**前缀**（线性结构）。但实际上，**不同请求可能有公共中间部分**：

```
请求 A: [System] [User1] [Assistant1] [User3]
请求 B: [System] [User2] [Assistant2] [User3]
请求 C: [System] [User1] [Assistant1] [User4]
```

公共部分：
- A 和 C 共享 [System][User1][Assistant1]（3 轮对话）
- A 和 B 共享 [System][User3]
- 都共享 [System]

**树形结构**能完整表达这种共享关系：

```
                [System]
                /      \
            [User1]   [User2]
              |          |
          [Asst1]    [Asst2]
            / \
        [User3] [User4]
          |
        ...
```

RadixAttention 用 Radix Tree 存所有历史请求的 KV，新请求来时在树上找最长匹配。

### 3.2 Radix Tree 节点结构

```python
class TreeNode:
    token_ids: List[int]           # 这个节点存的 token 序列
    kv_cache: KVCache              # 这段 token 对应的 KV
    children: Dict[int, TreeNode]  # 子节点 (按下一个 token id 索引)
    parent: TreeNode
    ref_count: int                 # 有多少请求在用
    last_access_time: float        # LRU 用的
```

### 3.3 工作流程

```
新请求来: prompt = [t0, t1, ..., tN]

1. 从根节点开始, 沿着树找最长匹配:
   current = root
   matched_len = 0
   for token in prompt:
       if token in current.children and token matches:
           current = current.children[token]
           matched_len += len(current.token_ids)
       else:
           break

2. 复用匹配部分的 KV cache
3. 剩下的 token (prompt[matched_len:]) 重新计算
4. 把新算的部分插入树中
```

### 3.4 eviction（淘汰）

树会越长越大，显存有限。SGLang 用 LRU 策略：
- 节点 `last_access_time` 超过阈值且 `ref_count == 0` → 可以淘汰
- 淘汰时把节点从树中删除，释放 KV cache 空间
- 父节点如果只剩一个子节点，可以合并

### 3.5 RadixAttention vs APC 对比

| 维度 | vLLM APC | SGLang RadixAttention |
|------|---------|----------------------|
| 数据结构 | 哈希表 | Radix Tree |
| 匹配粒度 | block 级 | 任意 token 级 |
| 共享模式 | 仅前缀 | 树形任意共享 |
| 命中率 | 中 | 高 |
| 实现复杂度 | 中 | 高 |
| 适合场景 | system prompt 重复 | 多轮对话、Tree of Thought |

---

## 4. 简化 Python 实现（教学版）

下面是一个最小化的 prefix cache 实现，帮你理解原理。真实系统复杂得多。

```python
"""
prefix_caching_demo.py — 简化版 Prefix Cache 演示

用 block_size=4 的简化场景演示:
- 第一次请求: 完整 prefill
- 第二次请求 (相同 prefix): 命中 cache, 只算 suffix
"""

import torch
import torch.nn as nn
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import hashlib


# ============================================================
# 简化的 "假模型" - 只为演示 cache 逻辑,不做真实计算
# ============================================================

@dataclass
class KVBlock:
    """一个 KV Cache 块 (对应 block_size 个 token)"""
    block_id: int                    # 物理 block 编号
    token_ids: List[int]             # 这个块包含的 token
    kv_data: torch.Tensor            # [block_size, num_heads, head_dim] 假数据
    hash_key: str                    # 这个块的哈希 (用于命中查找)


class PrefixCache:
    """
    简化版 Prefix Cache (类似 vLLM APC 的核心思想)

    用 hash(block_tokens + prev_hash) 作为 key
    存全局 block pool: hash -> KVBlock
    """

    def __init__(self, block_size: int = 4):
        self.block_size = block_size
        self.block_pool: Dict[str, KVBlock] = {}
        self.next_block_id = 0

        # 统计
        self.query_count = 0
        self.hit_count = 0

    def _hash_block(
        self,
        token_ids: List[int],
        prev_hash: Optional[str] = None,
    ) -> str:
        """计算 block 的 hash: hash(tokens + prev_hash)"""
        key = f"{prev_hash}|{'-'.join(map(str, token_ids))}"
        return hashlib.md5(key.encode()).hexdigest()

    def compute_prefill_plan(self, prompt: List[int]) -> Tuple[List[int], List[int]]:
        """
        给定 prompt, 返回:
        - hit_blocks: 命中的物理 block id 列表 (这些不用重算)
        - miss_token_ranges: 未命中的 token 区间 [(start, end), ...] (这些要重算)

        算法: 沿着 prompt 走,每 block_size 个 token 算一个 hash
              查 pool,命中就复用,不命中就停止 (因为后续 hash 依赖前面,前面断了后面全断)
        """
        self.query_count += 1
        hit_blocks = []
        miss_token_ranges = []

        prev_hash = None
        pos = 0
        first_miss = None

        while pos < len(prompt):
            # 取一个 block 的 token
            block_tokens = prompt[pos:pos + self.block_size]
            # 如果最后一块不满,也算未命中 (简化处理)
            if len(block_tokens) < self.block_size:
                if first_miss is None:
                    first_miss = pos
                break

            block_hash = self._hash_block(block_tokens, prev_hash)

            if block_hash in self.block_pool:
                # 命中!
                hit_blocks.append(self.block_pool[block_hash].block_id)
                prev_hash = block_hash
                pos += self.block_size
            else:
                # 未命中,从这里开始后面都要重算
                if first_miss is None:
                    first_miss = pos
                break

        if first_miss is not None:
            miss_token_ranges.append((first_miss, len(prompt)))

        # 更新命中统计
        if hit_blocks:
            self.hit_count += 1

        return hit_blocks, miss_token_ranges

    def store_block(
        self,
        token_ids: List[int],
        prev_hash: Optional[str],
        kv_data: torch.Tensor,
    ) -> Tuple[str, KVBlock]:
        """新算了一个 block,存进 pool"""
        block_hash = self._hash_block(token_ids, prev_hash)
        block = KVBlock(
            block_id=self.next_block_id,
            token_ids=token_ids,
            kv_data=kv_data,
            hash_key=block_hash,
        )
        self.block_pool[block_hash] = block
        self.next_block_id += 1
        return block_hash, block

    def hit_rate(self) -> float:
        if self.query_count == 0:
            return 0.0
        return self.hit_count / self.query_count


# ============================================================
# 演示
# ============================================================

def demo():
    """演示 prefix cache 的命中场景"""

    print("=" * 60)
    print("Prefix Caching 演示")
    print("=" * 60)

    cache = PrefixCache(block_size=4)

    # 场景: 3 个请求,共享 system prompt
    system_prompt = [100, 101, 102, 103, 104, 105, 106, 107]  # 8 tokens = 2 blocks

    # 请求 1: 完整 prompt = system + user1
    user1 = [200, 201, 202, 203]
    prompt1 = system_prompt + user1

    print(f"\n请求 1: prompt = {prompt1}")
    hits, misses = cache.compute_prefill_plan(prompt1)
    print(f"  命中 blocks: {hits}")
    print(f"  未命中区间: {misses}")
    # 预期: 0 命中, 全部未命中

    # 模拟计算并存储 system prompt 的 2 个 block
    prev_h = None
    for i in range(0, len(system_prompt), 4):
        block_tokens = system_prompt[i:i+4]
        kv_data = torch.randn(4, 4, 16)  # 假数据
        prev_h, _ = cache.store_block(block_tokens, prev_h, kv_data)

    # 存 user1 的 block
    user1_block = user1[:4]
    kv_data = torch.randn(4, 4, 16)
    cache.store_block(user1_block, prev_h, kv_data)

    # 请求 2: 完整 prompt = system + user2 (共享 system)
    user2 = [300, 301, 302, 303]
    prompt2 = system_prompt + user2

    print(f"\n请求 2: prompt = {prompt2}")
    hits, misses = cache.compute_prefill_plan(prompt2)
    print(f"  命中 blocks: {hits}  (预期: 2 个, system prompt 复用)")
    print(f"  未命中区间: {misses}  (预期: 只有 user2 部分)")

    # 请求 3: 同样的 prompt 再来一次 (完全命中)
    print(f"\n请求 3: prompt = {prompt1} (和请求 1 一样)")
    hits, misses = cache.compute_prefill_plan(prompt1)
    print(f"  命中 blocks: {hits}  (预期: 3 个, 全部命中)")

    print(f"\n命中率: {cache.hit_rate():.1%}")
    print(f"Block pool 大小: {len(cache.block_pool)}")

    print("\n" + "=" * 60)
    print("结论: 共享 prefix 的请求能大幅减少 prefill 计算量")
    print("=" * 60)


if __name__ == "__main__":
    demo()
```

---

## 5. 实战：在 vLLM 中测 Prefix Caching 效果

### 5.1 启动 vLLM（开启 prefix caching）

```bash
vllm serve meta-llama/Llama-3-8B \
    --enable-prefix-caching \
    --port 8000
```

### 5.2 写一个 benchmark 脚本测命中率

```python
# benchmark_prefix_cache.py
import asyncio
import time
import httpx

BASE_URL = "http://localhost:8000/v1"

# 共享的 system prompt (2000 token)
SYSTEM_PROMPT = "You are a helpful assistant. " * 200  # 约 1000+ token

async def send_request(client, user_query):
    """发送一个请求,返回 TTFT"""
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_query},
    ]
    
    start = time.time()
    async with client.stream(
        "POST",
        f"{BASE_URL}/chat/completions",
        json={
            "model": "meta-llama/Llama-3-8B",
            "messages": messages,
            "max_tokens": 50,
            "stream": True,
        },
        timeout=60.0,
    ) as response:
        async for chunk in response.aiter_lines():
            if chunk.startswith("data: ") and chunk != "data: [DONE]":
                ttft = time.time() - start
                return ttft
    return None

async def main():
    queries = [
        "What is the capital of France?",
        "Explain quantum computing.",
        "Write a Python function to sort a list.",
        "What is the meaning of life?",
        "How does attention work in transformers?",
    ]
    
    # 先发一个请求预热 cache
    async with httpx.AsyncClient() as client:
        await send_request(client, "warmup query")
    
    # 测 5 个请求 (都共享 system prompt)
    async with httpx.AsyncClient() as client:
        for q in queries:
            ttft = await send_request(client, q)
            print(f"TTFT: {ttft*1000:.1f}ms | Query: {q}")

asyncio.run(main())
```

预期结果：
- 第 1 个请求 TTFT ~500ms（冷启动 prefill）
- 第 2-5 个请求 TTFT ~50-100ms（system prompt 命中 cache）

### 5.3 关闭 prefix caching 对比

```bash
vllm serve meta-llama/Llama-3-8B \
    --no-enable-prefix-caching \
    --port 8000
```

再跑同样的 benchmark，所有请求 TTFT 都应该 ~500ms。

---

## 6. 适用与不适用场景

### 6.1 适合 Prefix Caching

- ✅ 客服 / 助手类应用（固定 system prompt）
- ✅ Few-shot learning（few-shot 例子作为 prefix）
- ✅ 文档问答（长文档作为 prefix，多次提问）
- ✅ 多轮对话（历史对话作为 prefix）
- ✅ Code completion（仓库代码作为 prefix）

### 6.2 不适合 / 收益小

- ❌ 每个请求 prompt 完全不同（命中率低）
- ❌ 单次请求场景（无 cache 可复用）
- ❌ Prompt 极短（cache 命中也省不了多少）
- ❌ 对延迟不敏感的批处理

### 6.3 调优建议

- **block_size 调小** → 命中率提升，但管理开销大（vLLM 默认 16）
- **cache 容量调大** → 命中率提升，但显存压力大
- **eviction 策略** → LRU 是默认，特殊情况可定制

---

## 7. Prefix Caching 与其他优化的关系

| 优化 | 关系 |
|------|------|
| PagedAttention | 基础：分页管理让 cache 复用可行 |
| Continuous Batching | 互补：CB 提升吞吐，PC 降低 TTFT |
| Speculative Decoding | 互补：PC 加速 prefill，SD 加速 decode |
| PD 分离 | 协同：P 节点存 prefix cache，D 节点查表 |
| 量化 | 互补：KV Cache 量化让 cache 容量翻倍 |

---

## 8. 常见误区

1. **"Prefix Caching 损失精度"** — 错。命中的 KV 是真实算出来的，和重算结果完全一样。
2. **"任意相同部分都能命中"** — 错。只能命中**前缀**（vLLM）或**树形路径**（SGLang），中间相同部分不行。
3. **"命中率 100% 才有用"** — 错。哪怕 50% 命中也能显著降低 TTFT。
4. **"开了 Prefix Caching 就一定快"** — 错。请求间无共享时反而增加 hash 计算开销。
5. **"Prefix Caching 和 KV Cache 量化互斥"** — 错。可以叠加。

---

## 9. 学习路径建议

1. **跑 prefix_caching_demo.py** → 理解 block 级哈希
2. **跑 vLLM 的 prefix caching benchmark** → 看真实效果
3. **读 vLLM `prefix_cache.py` 源码** → 看工业实现
4. **读 SGLang `radix_cache.py` 源码** → 看树形实现
5. **加到我给你的 [10_inference_engine/python/](../10_inference_engine/python/)**：给手写引擎加 prefix cache，作为练习

---

## 10. 速查表

| 维度 | vLLM APC | SGLang RadixAttention |
|------|---------|----------------------|
| 数据结构 | 哈希表 | Radix Tree |
| 命中粒度 | block_size (默认 16) | token 级 |
| 共享模式 | 仅前缀 | 树形任意 |
| 默认开启 | vLLM 0.4+ | 默认 |
| 监控指标 | `vllm:gpu_prefix_cache_*` | SGLang 日志 |
| 适合场景 | system prompt 重复 | 多轮对话、ToT |
