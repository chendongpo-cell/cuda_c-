# 第6周：PagedAttention 核心源码 — 推理优化方向

> 目标：深入理解 PagedAttention 的原理、vLLM 中 Block Manager 的设计以及 KV Cache 的逐页管理机制。
> 预计时间：周均 7h（每天 ~1h）

---

## 目录

1. [PagedAttention 原理](#1-pagedattention-原理)
2. [Block Manager：核心数据结构](#2-block-manager核心数据结构)
3. [逻辑页→物理页映射](#3-逻辑页物理页映射)
4. [Prefix Caching（自动前缀缓存）](#4-prefix-caching自动前缀缓存)
5. [Copy-on-Write 机制](#5-copy-on-write-机制)
6. [Attention Backend 源码路径](#6-attention-backend-源码路径)
7. [面试考点](#7-面试考点)

---

## 1. PagedAttention 原理

### 1.1 为什么需要 PagedAttention？

**传统 KV Cache 的问题**：
```
为每个请求预先分配最大长度的连续显存：
  ┌──────────────────────────────────────────────┐
  │  [Allocated for request A]                   │
  │  ████████████████████████░░░░░░░░░░░░░░░░░░  │
  │  ← used: 16 tokens  →  ← wasted: 48 tokens  │
  │                                    │         │
  │              内部碎片！大量显存浪费             │
  └──────────────────────────────────────────────┘

  - 为最长序列预留：如果 max_len=2048，实际只用了 512 → 75% 浪费
  - 显存碎片：不同请求分配/释放后留下无法合并的小空闲块
  - 过量预留：batch 中每个请求的最大序列长度之和可能超过显存总量
```

**PagedAttention 的解决方案**：
```
类似 OS 的分页（Paging）机制：
  - 将逻辑上连续的 KV Cache 分成固定大小的 page/block
  - 物理上可以不连续存放
  - 按需分配，不浪费

请求 A 的逻辑地址空间：       物理显存分布：
  Block 0                      ┌──────┐
  Block 1                      │ Blk 7│ ← 请求 A 的 Block 2
  Block 2         ───►         ├──────┤
  Block 3                      │ Blk 3│ ← 请求 A 的 Block 1
                               ├──────┤
                               │ Blk 0│ ← 请求 A 的 Block 0
                               ├──────┤
                               │ Blk 5│ ← 请求 A 的 Block 3
                               └──────┘
```

### 1.2 Block Size 选择

| Block Size | 优点 | 缺点 | 适用场景 |
|------------|------|------|----------|
| 8 tokens | 碎片最少、精细控制 | block table 大、管理开销大 | 显存紧张 |
| 16 tokens | **vLLM 默认**，平衡好 | 一般 | 大部分场景 |
| 32 tokens | block table 小 | 内部碎片增大 | 长序列为主 |
| 64 tokens | 管理开销最小 | 内部碎片严重 | 大批量长序列 |

vLLM 默认 block_size=16。选择依据：
- 每个 block 存放的 KV cache 大小 = 2 × num_layers × num_heads × block_size × head_dim × dtype_bytes
- LLaMA-7B 每 block ≈ 2 × 32 × 32 × 16 × 128 × 2 = **8.4 MB**
- 用 16 token block，64K block 可管理 A100 80GB 的 KV cache

### 1.3 PagedAttention Kernel 运算

PagedAttention 的核心思想：**在 block 级别计算 attention**。

```
传统 Attention（单块大矩阵）：
  Q × [K_0, K_1, ..., K_{n-1}]^T → 整个 score 矩阵

PagedAttention（逐 block 计算）：
  Step 1: Q × K_block_0^T  →  score_block_0
  Step 2: score_block_0 × V_block_0 → partial_output_0
  Step 3: Q × K_block_1^T  →  score_block_1
  Step 4: score_block_1 × V_block_1 → partial_output_1
  ...
  Final: output = partial_output_0 + partial_output_1 + ...

  注意：因为 softmax 需要全局归一化，实际实现更复杂
  PagedAttention 用的是 PLA（Piecewise-Linear Attention）近似
  或先算完整的 score，只是读取时通过 block table 映射
```

---

## 2. Block Manager：核心数据结构

文件位置（V1）：`vllm/v1/core/block_manager.py`

### 2.1 BlockAllocator（块分配器）

```python
# 简化版 vLLM V1 BlockAllocator
class BlockAllocator:
    def __init__(self, num_blocks: int, block_size: int):
        self.num_blocks = num_blocks       # 总 block 数（由 GPU 显存决定）
        self.block_size = block_size       # 每 block 的 token 数（默认 16）
        self.free_blocks = list(range(num_blocks))  # 空闲 block ID 列表
        self.ref_counts = [0] * num_blocks  # 每个 block 的引用计数

    def allocate(self) -> int:
        """分配一个物理 block"""
        assert self.free_blocks, "No free blocks available!"
        block_id = self.free_blocks.pop()   # 从空闲列表取一个
        self.ref_counts[block_id] = 1       # 引用计数 = 1
        return block_id

    def free(self, block_id: int):
        """释放一个物理 block"""
        self.ref_counts[block_id] -= 1
        if self.ref_counts[block_id] == 0:
            self.free_blocks.append(block_id)  # 真正回收

    def get_num_free_blocks(self) -> int:
        return len(self.free_blocks)
```

### 2.2 BlockTable（块映射表）

每个推理请求维护一个 BlockTable。

```python
class BlockTable:
    """
    逻辑 block → 物理 block 的映射

    逻辑地址空间: [0, 1, 2, ..., num_logical_blocks-1]
    物理地址空间: GpuBlockAllocator 管理的任意空闲块

    映射关系: self.blocks[logical_idx] = physical_block_id
    """
    def __init__(self, allocator: BlockAllocator):
        self.allocator = allocator
        self.blocks: List[int] = []  # blocks[i] = 逻辑 block i 的物理 block ID

    def append_block(self):
        """为请求追加一个 block（对应 decode 一步/或多步）"""
        phys_id = self.allocator.allocate()
        self.blocks.append(phys_id)

    def get_physical_block(self, logical_idx: int) -> int:
        """逻辑地址 → 物理地址"""
        return self.blocks[logical_idx]

    def free_all(self):
        """请求完成，释放所有 block"""
        for phys_id in self.blocks:
            self.allocator.free(phys_id)
        self.blocks.clear()
```

### 2.3 BlockManager（块管理器）

更完整的 V1 BlockManager 视角：

```python
class BlockManager:
    """
    整体 KV Cache 块管理器

    职责：
    1. 计算 GPU 上总共有多少个 block
    2. 管理所有请求的 BlockTable
    3. 调度时检查是否有足够空闲 block
    4. 处理 prefix cache 命中
    """
    def __init__(self, gpu_memory: int, block_size: int, num_layers: int):
        # 计算一个 block 占用的显存
        # block_memory = 2(K+V) × num_layers × num_heads × block_size × head_dim × dtype
        self.block_size = block_size
        self.num_layers = num_layers
        self.block_memory = self._calc_block_memory()

        # GPU 上可用的 block 总数
        # gpu_memory_utilization 决定留给 KV cache 的比例（默认 0.9）
        self.total_blocks = int(gpu_memory * 0.9 // self.block_memory)

        # 分配器
        self.allocator = BlockAllocator(self.total_blocks, block_size)

        # 每个请求的 BlockTable
        self.request_tables: Dict[str, BlockTable] = {}

    def can_allocate(self, num_tokens: int) -> bool:
        """
        检查是否能分配 num_tokens 的 KV cache

        核心判断：空闲 block 数 ≥ 需要分配的 block 数
        """
        needed_blocks = (num_tokens + self.block_size - 1) // self.block_size
        return self.allocator.get_num_free_blocks() >= needed_blocks

    def get_num_available_blocks(self) -> int:
        return self.allocator.get_num_free_blocks()
```

---

## 3. 逻辑页→物理页映射

### 3.1 地址翻译过程

```
请求 A 的推理过程：

Step 1: Prefill 阶段（处理 prompt of 3 tokens）
  ┌─────┬─────┬─────┐
  │ T0  │ T1  │ T2  │   逻辑 block 0: [T0, T1, T2]
  └─────┴─────┴─────┘
       ↓ allocate physical block(s)
  BlockTable: [7]          → 物理 block 7
  显存: [block 7] = [T0, T1, T2]

Step 2: Decode 阶段（生成 T3）
  ┌─────┬─────┬─────┬─────┐
  │ T0  │ T1  │ T2  │ T3  │    逻辑 block 0 满了（block_size=3 示例）
  └─────┴─────┴─────┴─────┘
                             需要新 block
  BlockTable: [7, 12]       → 新增物理 block 12
  显存: [block 7] = [T0, T1, T2]
        [block 12] = [T3]

Step 3: 继续 Decode（生成 T4, T5, T6）
  BlockTable: [7, 12]       → block 12 装 T3, T4, T5
  BlockTable: [7, 12, 3]   → block 3 装 T6, ...
```

### 3.2 GPU Kernel 侧如何读取不连续的 KV Cache

PagedAttention 的 GPU kernel 需要 block table 来获取 KV cache 的物理地址：

```cpp
// 简化版思路（实际是 Triton kernel）
// block_tables: [num_seqs, max_num_blocks_per_seq]
// 每个 seq 有一个 block table，记录其物理 block ID
// key_cache 和 value_cache 是按物理 block 存储的

__global__ void paged_attention_kernel(
    float* output,              // [num_seqs, num_heads, head_dim]
    const float* query,         // [num_seqs, num_heads, head_dim]
    const float* key_cache,     // [num_blocks, num_heads, block_size, head_dim]
    const float* value_cache,   // [num_blocks, num_heads, block_size, head_dim]
    const int* block_tables,    // [num_seqs, max_blocks]
    int num_blocks,             // 当前 seq 的实际 block 数
) {
    int seq_idx = blockIdx.x;  // 当前是第几个 seq
    int head_idx = ...;

    float acc = 0.0f;

    for (int block_idx = 0; block_idx < num_blocks; block_idx++) {
        // 通过 block table 找到物理 block ID
        int phys_block_id = block_tables[seq_idx * max_blocks + block_idx];

        // 从物理 block 加载 K/V 到寄存器
        // key_cache[phys_block_id, head_idx, :, :]
        // value_cache[phys_block_id, head_idx, :, :]

        // 计算当前 block 的 attention
        // ...
    }
}
```

---

## 4. Prefix Caching（自动前缀缓存）

### 4.1 原理

多个请求可能有相同的 prompt 前缀（system prompt、few-shot examples 等）。

```
请求 A: [system_prompt, user_question_1, ...]
请求 B: [system_prompt, user_question_2, ...]
         ↑                ↑
      相同前缀         不同后缀

如果 system_prompt 的 KV cache 被缓存，
请求 B 不需要重新计算 system_prompt 的 KV → 节省显存 + 计算！
```

### 4.2 vLLM 的实现

```python
class PrefixCachingBlockAllocator(BlockAllocator):
    """
    带自动前缀缓存的 BlockAllocator

    核心：block 的内容哈希 → 可复用的物理 block
    """
    def __init__(self, num_blocks, block_size):
        super().__init__(num_blocks, block_size)
        # 内容 → 物理 block ID 的映射
        self.content_hash_to_block: Dict[int, int] = {}

    def allocate(self, content_hash: int = None) -> int:
        """
        分配 block（如果 content_hash 命中，直接返回已有 block）

        内容哈希基于 block 中所有 token 的 hash
        例如 hash("system_prompt_tokens[0:block_size]") # = 0xABCD...

        如果另一个请求的相同位置的 token 相同
        → hash 相同
        → 复用物理 block
        → ref_count +1（不重复分配显存！）
        """
        if content_hash and content_hash in self.content_hash_to_block:
            # Prefix cache 命中！
            block_id = self.content_hash_to_block[content_hash]
            self.ref_counts[block_id] += 1
            return block_id

        # 未命中，正常分配
        block_id = super().allocate()
        if content_hash:
            self.content_hash_to_block[content_hash] = block_id
        return block_id
```

### 4.3 Prefix Cache 的调度影响

```python
# Prefix Cache 命中时的调度决策
class PrefixAwareScheduler(Scheduler):
    def schedule(self):
        for request in self.waiting_queue:
            # 检查前缀 hash 是否在 cache 中
            prefix_blocks = self.block_manager.get_cached_prefix_blocks(request)

            if prefix_blocks:
                # 前缀已缓存！只需要为剩余部分分配 block
                new_blocks = self.block_manager.allocate(
                    request.num_remaining_tokens
                )
                # 请求的总 block = 缓存 block + 新 block
                request.block_table = prefix_blocks + new_blocks
            else:
                # 无缓存，完整分配
                request.block_table = self.block_manager.allocate(
                    request.num_prompt_tokens
                )
```

---

## 5. Copy-on-Write 机制

### 5.1 为什么需要 CoW？

并行采样（beam search / 多个不同的 generation）：
```
请求 A 有一个 prompt，生成 3 个不同的 continuation：
  A: [prompt] → continuation_1
  A: [prompt] → continuation_2  （共享 prompt 的 KV cache）
  A: [prompt] → continuation_3

如果没有 CoW：
  每个 continuation 都要 copy prompt 的 KV cache → 巨大显存浪费

使用 CoW：
  所有 continuation「共享」prompt 的 KV cache block
  直到某个 continuation 需要修改 → copy 一份（copy-on-write）
```

### 5.2 实现

```python
class CopyOnWriteBlockManager:
    def __init__(self, allocator):
        self.allocator = allocator

    def fork_request(self, parent_request, child_request):
        """
        子请求共享父请求的所有 block
        ref_count += 1（不实际拷贝显存！）
        """
        child_request.block_table = BlockTable()
        for phys_id in parent_request.block_table.blocks:
            # 共享物理 block，引用计数 +1
            child_request.block_table.blocks.append(phys_id)
            self.allocator.ref_counts[phys_id] += 1

    def write_to_block(self, request, logical_idx, data):
        """
        写入 block（可能触发 CoW）

        如果 ref_count > 1，不能直接写，需要先 copy
        """
        phys_id = request.block_table.blocks[logical_idx]

        if self.allocator.ref_counts[phys_id] > 1:
            # 有人共享 → 先 copy！
            new_phys_id = self.allocator.allocate()
            # copy 数据：cudaMemcpy(new_phys_id, phys_id, ...)
            cuda_memcpy_block(new_phys_id, phys_id)
            # 减少原 block 引用
            self.allocator.free(phys_id)
            # 更新 block table
            request.block_table.blocks[logical_idx] = new_phys_id
            # 写新数据到新 block
            cuda_write_block(new_phys_id, data)
        else:
            # 没有共享，直接写
            cuda_write_block(phys_id, data)
```

---

## 6. Attention Backend 源码路径

### 6.1 V1 架构的 Attention 模块

文件：`vllm/v1/attention/`

```
vllm/v1/attention/
├── __init__.py                # backend 统一接口
├── flash_attention.py         # FlashAttention 实现
├── flash_attention_varlen.py  # 变长序列版本
└── paged_attention.py         # PagedAttention Triton kernel
```

### 6.2 Backend 选择逻辑

```python
# vllm/v1/attention/__init__.py
def get_attention_backend(
    num_heads: int,
    head_size: int,
    block_size: int,
    use_v1: bool,
) -> AttentionBackend:
    # V1 默认使用 FlashAttention varlen 作为 forward 实现
    # 但显存管理始终通过 BlockManager（PagedAttention 的页管理思想）

    if use_v1:
        return FlashAttentionVarlenBackend()
    else:
        return PagedAttentionBackend()
```

### 6.3 Forward 调用链

```
LLMEngine.step()
  → model_runner.execute_model()
    → transformer_layers[i].forward()
      → self_attn.forward()
        → attention_backend.forward(
            query, key, value,
            block_tables=block_tables,  # BlockTable 中的物理 block 列表
            block_size=block_size,
        )
          → PagedAttentionKernel / FlashAttentionKernel
```

---

## 7. 面试考点

| 考点 | 重要度 | 说明 |
|------|--------|------|
| PagedAttention 解决了什么问题 | ⭐⭐⭐ | 显存碎片/过度预留/无法共享 |
| Block Table 映射原理 | ⭐⭐⭐ | 逻辑→物理地址翻译 |
| Block Size 的选择权衡 | ⭐⭐ | 对显存利用率和灵活性的影响 |
| Prefix Caching 原理 | ⭐⭐⭐ | 内容 hash → 物理 block 复用 |
| Copy-on-Write 场景 | ⭐⭐⭐ | parallel sampling / beam search |
| PagedAttention vs FlashAttention 关系 | ⭐⭐⭐ | vLLM 同时使用两者 |
| 一个 block 占用多少显存 | ⭐⭐ | 能根据模型参数算 |
| 如何计算 GPU 上的总 block 数 | ⭐⭐ | gpu_memory * utilization / block_memory |

### 显存估算速查

```python
def calc_block_memory(num_layers, num_heads, head_dim, block_size, dtype_bytes=2):
    """每 block 的 KV cache 显存"""
    return 2 * num_layers * num_heads * block_size * head_dim * dtype_bytes

# LLaMA-7B: 32L, 32H, 128D, block_size=16, FP16
# = 2 * 32 * 32 * 16 * 128 * 2 = 8,388,608 bytes ≈ 8 MB/block
# A100 80GB 可用 ~0.9*80 = 72GB for KV cache
# 总 block 数 ≈ 72GB / 8MB ≈ 9000 blocks
# 最长序列（假设 4096 tokens）= 4096/16 = 256 blocks/request
# 最大并发请求数 ≈ 9000/256 ≈ 35 请求
```

---

### 本周学习清单

```
Day 1-2: 阅读 PagedAttention 论文（Efficient Memory Management for LLM Inference）
Day 3-4: 阅读 vllm/v1/core/block_manager.py 源码
Day 5-6: 阅读 vllm/v1/core/block_table.py 源码
Day 7: 阅读 vllm/v1/attention/ 中的 backend 选择逻辑
```
