# 推理优化术语词典（大白话版）

> 按首字母排序，每个术语 3 句话内讲清楚。
> 边看文档边查这个，遇到不懂的来翻。

---

## A

### Attention（注意力机制）

**是什么**：模型理解词与词之间关系的核心机制。比如模型看到"它"时，通过 Attention 知道"它"指的是前文的"北京"。

**推理场景**：Attention 占了推理 60-80% 的计算量，是优化的主要目标。

**相关**：KV Cache, FlashAttention, PagedAttention

### AWQ（Activation-aware Weight Quantization）

**是什么**：一种量化方法，保留 1% 的"重要"权重通道为 FP16，其余量化到 INT4/INT8。

**特点**：比 GPTQ 量化损失略小，是 vLLM 默认支持的量化格式。

## B

### Block（页 / 数据块）

**是什么**：PagedAttention 中显存管理的基本单位，一般是 16 个 token 的 KV cache 数据。

**类比**：操作系统内存管理中的"页"（page），大小固定。

### Block Table（页表）

**是什么**：记录每个请求的逻辑 block 到物理 block 的映射关系。

**类比**：操作系统的页表，把虚拟地址翻译成物理地址。

### BF16（Brain Floating Point 16）

**是什么**：16 位浮点数格式，和 FP32 有相同的指数范围（8 位指数），但精度更低（7 位尾数）。

**特点**：适合深度学习，不易溢出，现在的主流训练/推理精度。

## C

### Continuous Batching（连续批处理）

**是什么**：vLLM 的核心优化。传统批处理要等一批所有请求完成才处理下一批。连续批处理可以随时加入新请求、随时完成旧请求。

**类比**：餐厅流水席 vs 固定开饭时间。

### CUDA（Compute Unified Device Architecture）

**是什么**：NVIDIA 的 GPU 编程平台。用 C++ 扩展语法写代码，在 GPU 上并行执行。

**特点**：推理优化岗位必须掌握，因为 vLLM 的 PagedAttention、FlashAttention 都是用 CUDA 写的。

### CUDA Stream

**是什么**：GPU 上的一个执行队列，不同 stream 的操作可以并行执行。

**场景**：一边传输数据到 GPU（H2D），一边在 GPU 上做计算。

## D

### DCU（Deep Computing Unit）深算一号

**是什么**：中科曙光自研的 GPGPU，用来替代 NVIDIA GPU 做 AI 推理。

**规格**：32GB HBM2 显存、60 个计算单元、wavefront=64 线程。

**和 A100 对比**：显存 32GB vs 80GB、无 Tensor Core、PCIe 互联 vs NVLink。

### Decode（解码阶段）

**是什么**：逐个生成 token 的过程。每次输入 1 个 token，利用 KV Cache 计算下一个 token。

**特点**：memory-bound（受显存带宽限制），计算量小但访存量大。

**和 Prefill 对比**：Prefill 是计算密集，Decode 是访存密集。

## E

### Event（CUDA 事件）

**是什么**：CUDA 中用来计时和同步的机制。可以记录 GPU 上某个操作完成的时间点。

**用法**：cudaEventRecord(start) → 执行 kernel → cudaEventRecord(stop) → cudaEventSynchronize(stop)。

## F

### FlashAttention

**是什么**：一种省显存、更快的 Attention 计算方法。核心思想是不需要把整个 Score 矩阵（O(n²)）存在显存里，而是分块计算。

**原理**：IO-aware tiling，把计算分成小块，每块读入 SRAM（片上缓存），算完写回 HBM（显存），再处理下一块。

**效果**：训练时显存占用从 O(n²) 降到 O(n)，速度提升 2-4x。

### FP16（Float Point 16）

**是什么**：16 位浮点数，比 FP32（32 位）省一半显存，计算也更快。

**精度问题**：范围比 FP32 窄（最大 65504），大的数会溢出。

### FP8（Float Point 8）

**是什么**：8 位浮点数，H100 才开始支持。比 FP16 再省一半显存。

**两种格式**：E4M3（更大范围）和 E5M2（更大精度），不同场景选用不同格式。

## G

### GEMM（General Matrix Multiply，通用矩阵乘法）

**是什么**：矩阵乘法 C = A × B + C，是所有深度学习计算的核心操作。

**场景**：Attention 中的 Q@K^T 和 P@V、FFN 中的线性层，本质上都是 GEMM。

### Global Memory（全局内存）

**是什么**：GPU 上的主显存（HBM），最大、最慢。

**延迟**：约 400 cycles（Shared Memory 的 10 倍以上）。

### GQA（Grouped Query Attention）

**是什么**：MHA 和 MQA 的折中方案。多个 query head 共享一组 key/value head。

**参数量**：32 个 Q head，8 个 KV head（GQA-8），减少了 KV cache 但比 MQA 精度高。

**使用**：LLaMA-2 70B、LLaMA-3 系列都用了 GQA。

## H

### HIP（Heterogeneous-compute Interface for Portability）

**是什么**：AMD 的 GPU 编程平台，与 CUDA 几乎完全兼容。

**核心优势**：一份代码可以同时编译到 AMD GPU（DCU）和 NVIDIA GPU 上运行。

**迁移代价**：cudaMalloc → hipMalloc，cudaMemcpy → hipMemcpy，差异极小。

### HugePage（大页内存）

**是什么**：使用 2MB 或 1GB 的内存页代替默认的 4KB 页。

**效果**：减少 TLB（页表缓存）miss，推理性能提升 10-30%。

**配置**：echo 8192 > /proc/sys/vm/nr_hugepages（分配 8192 个 2MB 大页 = 16GB）。

## I

### INT4 / INT8

**是什么**：4 位或 8 位整数。用整数代替浮点数做计算，速度快、显存省。

**INT8 推理**：显存减半，计算速度提升 2-4x（有 Tensor Core 的 GPU 上）。

**风险**：精度损失，需要量化校准。

## K

### Kernel（核函数）

**是什么**：在 GPU 上执行的函数。用 `__global__` 声明，用 `<<<grid, block>>>` 启动。

**特点**：成千上万个线程同时执行同一个 kernel 函数，每个线程处理不同的数据。

### KV Cache（Key-Value 缓存）

**是什么**：把已计算过的 Key 和 Value 向量存起来，避免 Decode 阶段重复计算。

**原理**：生成第 100 个 token 时，前面 99 个 token 的 K、V 已经算过了，直接复用。

**显存公式**：2 × num_layers × num_heads × seq_len × d_head × bytes_per_elem

**计算量节省**：从 O(n²) 降到 O(n)。

## L

### Local Data Share / LDS（本地数据共享）

**是什么**：DCU 上的 Shared Memory 叫法。作用完全一样：同一个 workgroup（线程块）内的线程共享的高速缓存。

**大小**：DCU K100 每个 CU 有 64KB LDS。

## M

### Memory Coalescing（内存合并访问）

**是什么**：相邻线程访问相邻地址时，GPU 可以把多个小请求合并成一次大请求。

**为什么重要**：非合并访问会导致带宽利用率降到 10-20%。

**例子**：A[row][col] 按行访问是合并的，按列访问不是。

### MHA / MQA（Multi-Head / Multi-Query Attention）

**MHA**：每个 attention head 有自己的 Q、K、V → 模型容量大，但 KV cache 也大。

**MQA**：所有 query head 共享一组 K、V → KV cache 减小到 1/n，但精度略有损失。

**GQA**（见上）：折中方案。

## N

### NUMA（Non-Uniform Memory Access）

**是什么**：多路 CPU 系统中，每个 CPU 访问自己的本地内存快，访问另一个 CPU 的内存慢。

**推理优化**：推理进程和 GPU 绑定到同一个 NUMA 节点，减少跨 NUMA 访问延迟。

**命令**：numactl --cpunodebind=0 --membind=0

### NVLink

**是什么**：NVIDIA 的 GPU 间高速互联，带宽远高于 PCIe。多卡模型并行时需要。

**DCU 替代**：PCIe（慢 5-10x），这是 DCU 的硬伤。

## O

### Occupancy（占用率）

**是什么**：GPU 上活跃 warp 数 / 最大 warp 数。占用率越高，越能隐藏内存延迟。

**经验值**：> 50% 算好，> 75% 优秀。但 occupancy 高不等于性能好（可能寄存器压力大）。

## P

### PagedAttention（分页注意力）

**是什么**：vLLM 的核心创新。像操作系统分页一样，把 KV cache 分成固定大小的"页"（block），通过页表管理显存。

**解决的问题**：传统方式需要连续显存，导致显存碎片化严重。PagedAttention 让不连续的显存块可以被组织起来使用。

**相关概念**：Block Table、逻辑页→物理页映射、Copy-on-Write

### Prefill（预填充阶段）

**是什么**：处理输入 prompt 的阶段。比如输入 1000 个 token 的 prompt，一次性算出所有 token 的 KV cache。

**特点**：计算密集型（compute-bound），利用 Tensor Core 做矩阵乘。

### Prefix Caching（前缀缓存）

**是什么**：把请求的前缀（如 System Prompt）的 KV cache 缓存起来，多个请求共享。命中时直接跳过前缀的计算。

**实现**：基于 block 粒度的缓存和匹配（vLLM V1 的 hash-based Prefix Caching）。

## Q

### Quantization（量化）

**是什么**：把高精度数字（FP32/FP16）用更低的位数（INT8/INT4）表示。

**收益**：模型体积减半/减 4 倍、推理更快、显存更省。

**代价**：精度损失，需要校准。

## R

### RAII（Resource Acquisition Is Initialization）

**是什么**：C++ 核心资源管理思想。资源（显存/文件）在构造函数中获取，在析构函数中释放。

**推理场景**：Block 对象的生命周期用 RAII 管理，离开作用域自动释放显存。

### RCCL / NCCL

**NCCL**：NVIDIA 的多卡通信库（GPU 之间高效传数据）。

**RCCL**：AMD 的版本（ROCm Collective Communications Library），接口和 NCCL 几乎一样。

### ROCm（Radeon Open Compute）

**是什么**：AMD 的 GPU 计算平台，对标 NVIDIA 的 CUDA Toolkit。

**曙光场景**：DCU 上跑 ROCm，用 hipcc 编译代码，用 MIOpen 替代 cuDNN。

## S

### Shared Memory（共享内存）

**是什么**：同一个线程块（block）内所有线程共享的高速缓存，比全局内存快 10x 以上。

**容量**：一般 48-164KB per SM，很小。需要程序员手动管理数据加载和同步。

**类比**：手边的便签纸（快但地方小）vs 文件柜（慢但装得多）。

### Scheduler（调度器）

**是什么**：vLLM 中的核心模块，负责决定哪些请求可以执行、哪些需要等待、哪些需要抢占。

**状态机**：WAITING（排队中）→ RUNNING（执行中）→ FINISHED（已完成）。

### SIMT（Single Instruction, Multiple Threads）

**是什么**：GPU 的执行模型。一个 warp 里的所有线程同时执行同一条指令，但可以处理不同的数据。

**和 SIMD 的区别**：SIMD 是向量化（数据必须有规律），SIMT 是线程化（每个线程可以走不同分支，但不同分支串行化）。

### Softmax

**是什么**：把一组数转换成概率分布，所有数加起来等于 1。

**公式**：softmax(x_i) = e^{x_i} / Σ e^{x_j}

**Attention 中的作用**：把相似度分数转为注意力权重。

## T

### Tensor Core

**是什么**：NVIDIA GPU 上的专用矩阵乘硬件。能做 FP16/INT8/FP4 的快速矩阵乘法。

**性能**：A100 Tensor Core FP16 达到 312 TFLOPS，是普通 CUDA Core 的 10x+。

**DCU 差距**：DCU K100 没有 Tensor Core，FP16 只有 40 TFLOPS。

### Tiling（分块）

**是什么**：把大矩阵/大数据分成小块，一块一块地加载到 Shared Memory 计算，减少 Global Memory 访问。

**FlashAttention 中的使用**：把 Q、K、V 分别切成 tile，逐个 tile 计算局部 attention。

### Token

**是什么**：文本被 Tokenizer 切分后的基本单位。中文一般一个字或一个词是一个 token。

**例子**："中国的首都是北京" → ["中国", "的", "首都", "是", "北京"]（5 个 token）

### Transformer

**是什么**：现代大语言模型的基本架构，由 Attention + Feed-Forward Network 堆叠而成。

**结构**：N 层 Transformer 层，每层包含 Self-Attention + FFN。LLaMA-7B 有 32 层。

### Triton

**是什么**：OpenAI 推出的 GPU 编程语言，目标是让不熟悉 CUDA C++ 的开发者也能写高性能 GPU kernel。

**写法**：用 Python 写 kernel（decorator + 类型注解），Triton 自动处理线程调度和内存优化。

## V

### vLLM

**是什么**：目前最流行的大模型推理框架。核心贡献是 PagedAttention 和 Continuous Batching。

**架构**：LLMEngine → Scheduler（调度）+ Model Runner（执行）→ Worker（GPU 操作）。

## W

### Warp / Wavefront

**Warp**：NVIDIA GPU 上一起执行的 32 个线程。最小调度单位。

**Wavefront**：AMD GPU（包括 DCU）上一起执行的 64 个线程。**注意这个差异**！

**影响**：写 warp-level 归约时，CUDA 用 s=16→8→4→2→1，HIP 用 s=32→16→...→1。

### Warp Divergence（线程束分歧）

**是什么**：同一个 warp 内的线程走不同分支（if/else），导致分支串行执行。

**规则**：if (threadIdx.x < 16) 会导致分歧（因为 warp 中部分线程走 if 部分，部分走 else），if (blockIdx.x % 2 == 0) 不会（每个 warp 内的所有线程条件一致）。
