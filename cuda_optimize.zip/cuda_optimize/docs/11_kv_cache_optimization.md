# KV Cache 优化详解

## 1. KV Cache 显存模型深度分析

### 1.1 什么是 KV Cache

在大语言模型的自回归解码中，每个 token 的生成都需要计算 attention：
- 对于当前 token（query），需要与所有之前的 tokens（keys 和 values）计算 attention
- 如果不缓存 K 和 V，每次生成都需要重新计算所有之前 tokens 的 K 和 V → O(N²) 计算量
- KV cache 将之前 tokens 的 K 和 V 保存在显存中 → O(N) 计算量

KV cache 形状：`[batch_size, num_layers, 2, num_heads, max_seq_len, d_head]`
- 2 代表 K 和 V 两个张量
- 每层都有独立的 KV cache

### 1.2 精确显存计算公式

#### 总显存占用公式

```
M_kv_cache = 2 × L × H × N × d × b  (bytes)
```

其中：
- L = 层数 (num_layers)
- H = 每层注意力头数 (num_heads)  
- N = 序列长度 (seq_len)
- d = 每个头的维度 (d_head)
- b = 每个元素的字节数 (bytes per element)
- 前面的 2 代表 K 和 V

#### 具体模型示例

所有计算假设 dtype=float16 (b=2)：

| 模型 | L | H | d | N=4096 | N=8192 | N=32768 |
|------|---|---|---|--------|--------|---------|
| LLaMA-7B | 32 | 32 | 128 | 2 GB | 4 GB | 16 GB |
| LLaMA-13B | 40 | 40 | 128 | 3.1 GB | 6.2 GB | 25 GB |
| LLaMA-30B | 60 | 52 | 128 | 6.1 GB | 12.2 GB | 49 GB |
| LLaMA-70B | 80 | 64 | 128 | 10.7 GB | 21.4 GB | 86 GB |
| GPT-3 175B | 96 | 96 | 128 | 19.3 GB | 38.6 GB | 154 GB |

**关键观察**：70B 模型在 32K 上下文下，KV cache 就需要 86 GB 显存（远超模型权重自身）。

#### Per-Token 增长

每个新生成的 token 增加的 KV cache 大小：
```
ΔM_per_token = 2 × L × H × d × b
```

| 模型 | 每 token 增长 |
|------|--------------|
| LLaMA-7B | 2 × 32 × 32 × 128 × 2 = 524 KB |
| LLaMA-70B | 2 × 80 × 64 × 128 × 2 = 2.6 MB |

### 1.3 多层 KV cache 共享

**MLA (Multi-head Latent Attention, DeepSeek)**：
- 将 KV 投影到低维 latent 空间再缓存
- 大幅减少 KV cache：压缩比可达 8x-16x
- 是当前长上下文推理的前沿方案

---

## 2. KV Cache INT8/FP8 量化

### 2.1 量化动机

从上面公式可见，KV cache 是长上下文推理的主要瓶颈。量化可以从两个维度减少显存：
1. **存储减半**：INT8/FP8 (1 byte) 替代 FP16 (2 bytes)
2. **带宽需求减半**：从 HBM 读取 KV cache 的带宽需求减半

### 2.2 INT8 KV Cache 量化方案

#### Per-Token 量化（应用于 Key）

对每个 token 单独计算 scale：
```
对于 K 的第 t 个 token: K_t ∈ ℝ^d
scale_t = max(|K_t|) / 127
K_quant_t = clamp(round(K_t / scale_t), -128, 127)
```

优点：每个 token 的 scale 自适应，适合激活值变化大的场景
缺点：需要每个 token 单独存储 scale（但 scale 只有 4 bytes，可忽略）

#### Per-Channel 量化（应用于 Key）

对每个 channel（head 维度）单独计算 scale：
```
对于 K 的第 c 个 channel: K[:,c] ∈ ℝ^N
scale_c = max(|K[:,c]|) / 127
K_quant[:,c] = clamp(round(K[:,c] / scale_c), -128, 127)
```

优点：不同 channels 分布不同时效果更好
缺点：需要更多的 scale（N 个）

#### Per-Token + Per-Channel 混合

KIVI 提出的方案：
- K cache: per-channel 量化（K 的 channel 间方差大）
- V cache: per-token 量化（V 的 token 间方差大）

### 2.3 FP8 KV Cache

FP8 (E4M3) 比 INT8 更适合 KV cache 量化：
- 动态范围更大：FP8 E4M3 最大值 448，INT8 最大值 127
- 更自然地表示小值（非均匀分布）
- 实测精度损失更小

H100 上 KV cache 通常使用 FP8：
```python
# 伪代码：FP8 KV cache 量化
k_fp8 = k.to(torch.float8_e4m3fn)  # 直接转换
v_fp8 = v.to(torch.float8_e4m3fn)
# 通常需要配合 per-tensor scale
```

### 2.4 vLLM 中的实现

vLLM 的 KV cache 量化配置：
```python
# 启动时指定
llm = LLM(model="...", kv_cache_dtype="fp8")      # FP8 KV cache
llm = LLM(model="...", kv_cache_dtype="fp8_e5m2") # FP8 E5M2
```

源码位置：`vllm/model_executor/layers/quantization/kv_cache.py`

核心流程：
1. 在模型初始化时分配 KV cache 的量化缓冲区
2. 每个 token 生成后，将 K/V 张量量化后写入 cache
3. Attention 计算时，从 cache 读取并反量化（或直接使用量化值计算）

---

## 3. Page Size 对碎片化的影响

### 3.1 PagedAttention 中的页面

PagedAttention 将 KV cache 划分为固定大小的物理块（pages）：
- 每个 page 包含固定数量的 tokens 的 KV 值
- 逻辑上连续的 tokens 可能映射到不连续的物理页

### 3.2 页面大小选择的影响

#### 小页面（page_size = 16）

优点：
- 内部碎片少（internal fragmentation）：每个请求的最后一块浪费少
- 内存利用率高

缺点：
- 页表大：更多页面需要管理（N / page_size 个页面）
- 块分配/释放开销大
- GPU 的 block 调度粒度粗（每个 block 处理一个页面）

#### 大页面（page_size = 64 或 128）

优点：
- 页表小，管理层开销低
- 每个 block 处理更多 tokens，计算效率高

缺点：
- 内部碎片大：短序列浪费大量 KV cache 空间
- 内存利用率低

#### 碎片率公式

```
internal_fragmentation = (page_size - last_page_used) / page_size
average_fragmentation ≈ page_size / (2 × avg_seq_len)
```

例如：
- avg_seq_len = 512, page_size = 16 → 碎片率 ≈ 1.6%
- avg_seq_len = 512, page_size = 128 → 碎片率 ≈ 12.5%

### 3.3 vLLM 的默认选择

vLLM 默认 page_size = 16（V1 架构中可配置）。

权衡考量：
- 长上下文场景：建议 page_size 稍大（64），减少页表开销
- 混合长度场景：建议 page_size 较小（16），减少碎片
- 最大序列长度受限的场景：page_size 影响不大

---

## 4. 内存池 / Arena 分配器设计

### 4.1 问题描述

KV cache 的特点：
- 动态增长（每个 step 增加几个 tokens）
- 不能提前预知最大长度（用户可能提前停止）
- 多请求共享显存
- 需要高效分配和释放

### 4.2 Arena Allocator 设计

```
┌──────────────────────────────────────────────┐
│ 预先分配的显存池 (KV Cache Arena)             │
├──────────────┬──────────────┬────────────────┤
│ 请求 A       │ 请求 B       │ 空闲区域       │
│ (方块表)     │ (方块表)     │ (Free List)   │
└──────────────┴──────────────┴────────────────┘
```

核心设计：

1. **预分配**：在初始化时分配一大块连续显存作为 KV cache pool
2. **Free List**：管理空闲块（标记哪些 page 可用）
3. **Block Table**：每个请求维护逻辑 page → 物理 page 的映射
4. **引用计数**：beam search 时多个请求共享部分 blocks

### 4.3 分配策略

```python
class BlockAllocator:
    def __init__(self, total_blocks, block_size):
        self.total_blocks = total_blocks
        self.free_blocks = list(range(total_blocks))
        self.ref_counts = [0] * total_blocks
    
    def allocate(self, num_blocks):
        # 从 free list 中取出 num_blocks 个块
        blocks = self.free_blocks[:num_blocks]
        self.free_blocks = self.free_blocks[num_blocks:]
        for b in blocks:
            self.ref_counts[b] = 1
        return blocks
    
    def free(self, block_id):
        self.ref_counts[block_id] -= 1
        if self.ref_counts[block_id] == 0:
            self.free_blocks.append(block_id)
```

### 4.4 避免显存碎片

- **固定大小块**：所有 block 大小相同，天然消除外部碎片
- **内部碎片**：只发生在最后一个 block，通过选择合适 block size 控制
- **Copy-on-Write (CoW)**：beam search 时共享块，写入时才复制

---

## 5. vLLM V1 Block Pool 源码阅读指南

### 5.1 V1 架构概览

vLLM V1 引入了新的 block 管理架构，主要文件：

```
vllm/v1/core/
├── block_pool.py          # Block pool 实现
├── block_table.py          # Block table 管理
├── scheduler.py           # 调度器（使用 block pool）
└── kv_cache_manager.py     # KV cache 管理器
```

### 5.2 Block Pool 设计 (vllm/v1/core/block_pool.py)

核心类：`BlockPool`

```
class BlockPool:
    - pool: 预先分配的 block 数组
    - free: 空闲块索引列表
    - ref_count: 每个块的引用计数
    - block_size: 每块包含的 token 数
    
    关键方法：
    - alloc(): 分配一个 block，返回 (索引, 数据指针)
    - free(idx): 释放一个 block，只在 ref_count 降为 0 时真正释放
    - get_block(idx): 获取 block 数据指针
```

### 5.3 Block Table 设计 (vllm/v1/core/block_table.py)

```
class BlockTable(ABC):
    """逻辑到物理块的映射表"""
    
    核心功能：
    - 每个请求一个 BlockTable
    - 将逻辑 page 索引映射到物理 block 索引
    - 支持 append token: 分配新 block 或写入已有 block
    - 支持 fork: beam search 时复制 block table（CoW）
```

### 5.4 KV Cache Manager (vllm/v1/core/kv_cache_manager.py)

```
class KVCacheManager:
    """管理所有层的 KV cache 分配和释放"""
    
    核心功能：
    - 为每层分配独立的 block pool
    - 请求到达时：为请求分配初始 blocks
    - 请求运行时：按需分配新 blocks
    - 请求结束时：释放所有 blocks
    - Prefetch: 预取下一个 token 需要的 blocks
```

### 5.5 阅读源码的路线图

```
1. 从 vllm/v1/engine.py 开始
   → 找到 KV cache 初始化位置
   
2. 跟踪到 vllm/v1/core/kv_cache_manager.py
   → 理解 allocate/free/prefetch 流程
   
3. 深入 vllm/v1/core/block_pool.py
   → 理解 block 的分配算法
   
4. 结合 vllm/v1/core/block_table.py
   → 理解逻辑到物理映射

5. 最后看 scheduler.py
   → 理解调度决策如何影响 block 分配
```

---

## 6. Chunked Prefill

### 6.1 问题：Prefill vs Decode 的冲突

Prefill 阶段：
- 处理大量 tokens（如 4096 个）的并行计算
- 计算密集型（compute-bound）
- 需要大量 GPU 算力

Decode 阶段：
- 每次只生成 1 个 token
- 内存密集型（memory-bound）
- KV cache 读取成为瓶颈

当 prefill 请求和 decode 请求混合时：
- Prefill 独占 GPU 导致 decode 延迟急剧增加（time-to-first-token 变大）
- 问题称为 "resource starvation"

### 6.2 Chunked Prefill 解决方案

**核心思想**：将 prefill 的序列切分成多个 chunk，交替执行 prefill chunk 和 decode。

```
未使用 Chunked Prefill:
[Prefill 4096 tokens (占用 GPU 500ms)] → [Decode token 1] → [Decode token 2] → ...

使用 Chunked Prefill (chunk_size=512):
[Chunk 1] [Decode] [Chunk 2] [Decode] [Chunk 3] [Decode] ...
```

### 6.3 Chunked Prefill 的优势

1. **降低 TTFT (Time-to-First-Token)**：后续 decode 请求不需要等待整个 prefill 完成
2. **提高 GPU 利用率**：混合 compute-bound 和 memory-bound 操作
3. **更好的 QoS**：减少长序列抢占短序列的情况

### 6.4 实现要点

```python
# Chunked Prefill 调度伪代码
def schedule():
    running_decode_requests = [...]  # 正在 decode 的请求
    pending_prefill_requests = [...]  # 等待 prefill 的请求
    
    # 尽可能多地运行 decode
    for req in running_decode_requests:
        schedule_decode(req)
    
    # 如果还有剩余算力，做 prefill chunk
    remaining_budget = compute_remaining_budget()
    for req in pending_prefill_requests:
        chunk = get_next_chunk(req, chunk_size=512)
        schedule_prefill_chunk(chunk)
        remaining_budget -= chunk_cost(chunk)
        if remaining_budget <= 0:
            break
```

---

## 7. 面试题

### 7.1 基础知识

**Q1: KV cache 为什么是推理的关键瓶颈？**

A: 两个原因。1) 显存占用：70B 模型在 32K 上下文下，KV cache 需要 86 GB 显存（FP16），已经超过模型权重本身（140 GB @ FP16）。2) Decode 阶段是 memory-bound 的，KV cache 的 HBM 读取速度直接决定 decode 速度。

**Q2: PagedAttention 如何解决 KV cache 碎片问题？**

A: 将 KV cache 划分为固定大小的物理 page，通过 block table 做逻辑到物理的映射。这消除了外部碎片（因为都是固定大小），内部碎片只出现在每个请求的最后一个 block。相比于为每个请求分配连续的显存空间，利用率大幅提升。

### 7.2 进阶问题

**Q3: Per-token 和 per-channel 量化在 KV cache 中各自的优劣？**

A: Per-token 量化适合 V（token 间方差大），per-channel 量化适合 K（channel 间方差大）。Per-token 需要 token 数个 scale（N 个），per-channel 需要 channel 数个 scale（d 个）。KIVI 的方案是 K per-channel + V per-token。

**Q4: Chunked Prefill 的代价是什么？**

A: 主要代价：1) Attention 计算量略有增加（chunk 边界上有 padding/overhead）；2) 实现复杂度显著增加（需要管理 chunk 状态、做部分 prefill 和 decode 的混合调度）；3) 每 step 调度决策更复杂（需要在 decode 和 prefill 之间分配算力）。

### 7.3 系统设计

**Q5: 如果需要在 1 张 A100-80G 上运行 70B 模型同时支持 32K 上下文，需要哪些优化？**

A: 1) 模型量化：FP8 或 INT8 量化（70B @ FP8 = 70 GB → 仍略超 80G）
2) KV cache 量化：INT8/FP8（从 FP16 的 86 GB 降至 43 GB @ INT8）
3) PagedAttention + 合理的 page size
4) 可能需要张量并行（2× A100-80G）
5) 或者使用 4-bit 量化（如 AWQ）进一步降低权重占比

**Q6: 设计一个支持 1M 上下文长度的推理系统，KV cache 如何管理？**

A: 1) 必须使用 KV cache 量化（INT8 或 FP8）
2) 考虑使用稀疏 attention（如 StreamingLLM、H2O）丢弃部分 K/V
3) MLA (DeepSeek) 压缩 KV 到低维
4) 对最旧 tokens 的 KV 使用更低精度（如 INT4）
5) 分布式 KV cache：将长序列 split 到多个 GPU 上（Ring Attention）
6) Offloading：将冷 tokens 的 KV cache 卸载到 CPU 内存
