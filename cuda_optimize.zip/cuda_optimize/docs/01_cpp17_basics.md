# 第1周：C++17 核心基础 — 推理优化方向

> 目标：掌握现代 C++ 的核心特性，为阅读 vLLM/SGLang C++ 后端源码和编写高性能 CUDA kernel 打底。
> 预计时间：周均 7h（每天 ~1h）

---

## 目录

1. [智能指针与 RAII](#1-智能指针与-raii)
2. [模板基础](#2-模板基础)
3. [现代 C++ 特性](#3-现代-c-特性)
4. [CMake 工程实践](#4-cmake-工程实践)
5. [面试考点](#5-面试考点)
6. [配套实例](#6-配套实例)

---

## 1. 智能指针与 RAII

### 1.1 RAII（Resource Acquisition Is Initialization）

RAII 是 C++ 最核心的资源管理思想：**资源在构造函数中获取，在析构函数中释放**。避免了手动 `new`/`delete` 导致的内存泄漏。

```
申请资源 → 构造函数
使用资源 → 成员函数
释放资源 → 析构函数（离开作用域自动调用）
```

**vLLM 推理引擎中的应用**：显存分配器（block allocator）使用 RAII 管理页表的内存生命周期，GPU 上的 tensor buffer 在析构时自动释放显存。

### 1.2 `std::unique_ptr`

独占所有权的智能指针。不能拷贝，只能移动。开销和裸指针相同。

```cpp
// 常用函数
std::make_unique<T>(args...)   // C++14 引入，构造 unique_ptr
ptr.get()                       // 获取裸指针（不转移所有权）
ptr.release()                   // 释放所有权，返回裸指针
ptr.reset(new_ptr)              // 重置指向新对象，释放原对象
std::move(ptr)                  // 转移所有权
```

### 1.3 `std::shared_ptr`

共享所有权的智能指针，使用引用计数。开销略大（原子操作维护引用计数）。

```cpp
std::make_shared<T>(args...)   // 推荐，一次分配控制块+对象（比 new 高效）
ptr.use_count()                  // 返回引用计数
ptr.reset()                      // 减少引用计数，为 0 释放对象
```

### 1.4 `std::weak_ptr`

不增加引用计数的"弱引用"，解决 `shared_ptr` 循环引用问题。使用时需 `lock()` 提升为 `shared_ptr`。

### 1.5 推理场景中的应用

```cpp
// vLLM 中 BlockAllocator 伪代码思路
class BlockAllocator {
    std::vector<std::unique_ptr<Block>> free_blocks_;  // 独占空闲块
    // unique_ptr 保证离开作用域时自动调用 Block 析构，释放显存
};
```

---

## 2. 模板基础

### 2.1 函数模板与类模板

模板是 CUDA kernel 编写的核心工具 — 同一个 kernel 可以用不同数据类型（FP16/BF16/FP8）实例化。

### 2.2 变参模板（Variadic Templates）

```cpp
template <typename... Args>
void print_all(Args... args) {
    (std::cout << ... << args) << '\n';  // C++17 折叠表达式
}
```

在训练框架中，变参模板常用于实现 LayerNorm/Attention 等算子的多参数融合 kernel 调用。

### 2.3 SFINAE 与 `if constexpr`（C++17）

`if constexpr` 编译期条件分支，用于根据数据类型选择不同的 kernel 实现路径。

```cpp
template <typename T>
void kernel_impl(T* data) {
    if constexpr (std::is_same_v<T, half>) {
        // 调用 FP16 优化路径
    } else if constexpr (std::is_same_v<T, float>) {
        // 调用 FP32 路径
    }
}
```

---

## 3. 现代 C++ 特性

### 3.1 Lambda 表达式

```cpp
// 基本语法
[capture](params) -> return_type { body }

// 常见 capture 模式
[=]           // 值捕获所有变量
[&]           // 引用捕获所有变量
[x, &y]       // x 值捕获，y 引用捕获
[this]        // 捕获 this 指针（成员函数内）
```

CUDA kernel launch 调度时，常用 lambda 封装 launch 逻辑。

### 3.2 右值引用与 Move 语义

右值引用解决的是 **"临时对象的深拷贝开销"** 问题。

```cpp
// 左值：有地址、可取地址的表达式（变量名、返回左值引用的函数）
// 右值：临时对象、字面量（即将销毁的资源）

std::vector<int> a(1000000);
std::vector<int> b = std::move(a);  // a 的资源转移到 b，a 为空
// move 后 a 处于"合法但未指定"状态，只能销毁或赋值
```

**推理场景**：推理引擎中请求的 input tensor、KV cache block 的 ownership 转移大量使用 move 语义，避免深拷贝。

### 3.3 `std::optional` / `std::variant` / `std::any`（C++17）

- `std::optional<T>`：表示"要么有值，要么无值"（类比 Rust 的 Option / Python 的 None）
- `std::variant<T1, T2, ...>`：类型安全的联合体（类比 Rust 的 Enum）
- `std::any`：可存储任意类型（不适合高性能场景）

### 3.4 `std::string_view`（C++17）

只读字符串引用，不持有数据。zero-copy 读取字符串的利器。

```cpp
// 在 vLLM tokenizer 场景，从 kv cache 读取 token string 时用 string_view 避免拷贝
std::string s = "hello world";
std::string_view sv(s);  // 不拷贝，只引用
```

---

## 4. CMake 工程实践

### 4.1 基础 CMake 命令速查

```cmake
cmake_minimum_required(VERSION 3.18)   # 最低版本要求
project(MyProject VERSION 1.0 LANGUAGES CXX)  # 项目声明
set(CMAKE_CXX_STANDARD 17)             # C++ 标准
set(CMAKE_CXX_STANDARD_REQUIRED ON)    # 强制使用指定标准
add_executable(target_name src/main.cpp)  # 生成可执行文件
add_library(lib_name STATIC src/lib.cpp)  # 生成静态库
target_link_libraries(target PRIVATE lib) # 链接库
target_include_directories(target PRIVATE include/)  # 头文件路径
find_package(CUDA REQUIRED)            # 查找 CUDA
enable_language(CUDA)                  # 启用 CUDA 编译（CMake 3.18+）
```

### 4.2 CUDA + C++ 混编 CMake

```cmake
cmake_minimum_required(VERSION 3.18)
project(CUDAMixed VERSION 1.0 LANGUAGES CXX CUDA)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CUDA_STANDARD 17)

# 添加 CUDA 架构支持（根据实际 GPU 调整）
set(CMAKE_CUDA_ARCHITECTURES "80;90")  # Ampere(8.0) + Blackwell(9.0)

add_executable(run src/main.cpp src/cuda_kernel.cu)
```

### 4.3 GoogleTest 集成

```cmake
include(FetchContent)
FetchContent_Declare(
    googletest
    URL https://github.com/google/googletest/archive/release-1.12.1.zip
)
FetchContent_MakeAvailable(googletest)

enable_testing()
add_test(NAME test_suite COMMAND test_runner)
```

---

## 5. 面试考点

| 考点 | 重要度 | 说明 |
|------|--------|------|
| RAII 原理及在显存管理中的应用 | ⭐⭐⭐ | 必问，推理引擎的显存分配器本质就是 RAII |
| `unique_ptr` vs `shared_ptr` 区别 | ⭐⭐⭐ | 问用哪个管理 GPU buffer |
| Move 语义 && 完美转发 | ⭐⭐⭐ | 看过 vLLM C++ 源码就懂 |
| 模板特化与 `if constexpr` | ⭐⭐ | 数据类型泛化 kernel 的关键 |
| `string_view` | ⭐ | 了解即可 |

---

## 6. 配套实例

- 实例代码目录：[cpp_infra/](../cpp_infra/)
  - [src/raii_demo.cpp](../cpp_infra/src/raii_demo.cpp) — RAII 与智能指针示例
  - [src/template_demo.cpp](../cpp_infra/src/template_demo.cpp) — 模板与变参示例
  - [src/modern_features.cpp](../cpp_infra/src/modern_features.cpp) — 现代 C++ 特性汇总
  - [CMakeLists.txt](../cpp_infra/CMakeLists.txt) — 完整 CMake 工程配置
  - [tests/test_smart_ptr.cpp](../cpp_infra/tests/test_smart_ptr.cpp) — GoogleTest 单测

### Linux 命令备忘

```bash
# 编译与运行
cd cpp_infra && mkdir -p build && cd build
cmake ..                                   # 配置（生成 Makefile）
cmake --build .                            # 编译
cmake --build . --target test_runner       # 只编译测试
./run                                      # 运行
./test_runner                              # 运行测试

# CUDA 相关
nvcc --version                             # 查看 CUDA 版本
nvidia-smi                                 # 查看 GPU 信息
nsys profile -o output ./run               # Nsight Systems 性能分析
ncu -o output ./run                        # Nsight Compute 核函数分析

# 调试
gdb ./run                                  # 进入 GDB 调试
objdump -d ./run | less                    # 反汇编
nm ./run | grep function_name              # 查看符号表
```
