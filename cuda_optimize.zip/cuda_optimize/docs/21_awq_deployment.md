# AWQ 量化推理部署实战

> 这是工业界部署大模型最常用的量化方案之一。代表模型：TheBloke 的 AWQ 系列、官方 Llama-3-AWQ、Qwen-AWQ。
>
> 学习定位：**理解 AWQ 为什么比朴素 INT4 量化精度高、怎么用 AutoAWQ 量化自己的模型、怎么用 vLLM 部署 AWQ 模型做推理**。
>
> 前置知识：[10_quantization.md](10_quantization.md) 的基础量化概念。

---

## 0. 为什么需要 AWQ

大模型部署的最大瓶颈是显存。Llama-3-70B FP16 需要 140GB，单卡 A100 80GB 装不下。

朴素解法：把权重 INT4 量化（4 bit），显存降到 35GB，单卡能装下。

但朴素 INT4 量化精度损失严重，70B 模型可能损失 5-10% 的能力（MMLU 等基准测试下降）。

**AWQ（Activation-aware Weight Quantization）** 是 MIT Han Song 团队 2023 年提出的方案：
- INT4 权重 + FP16 激活（W4A16）
- 通过"激活感知"找到重要权重，保护它们不被量化损失
- 精度接近 FP16，速度比 FP16 快 2-3 倍

目前 AWQ 是 vLLM/SGLang 推理最主流的量化方案之一。

---

## 1. AWQ 核心思想

### 1.1 关键洞察：不是所有权重都重要

朴素量化：所有权重统一量化到 INT4。

AWQ 发现：**只有少数"显著权重"（salient channels）对模型输出影响大**，这些权重如果量化损失大，模型性能崩得快。

如何找出"显著权重"？看激活值：
- 激活值大的通道 → 对应权重要精心处理
- 激活值小的通道 → 量化无所谓

### 1.2 三个核心技巧

#### 技巧 1：Per-channel Scaling（逐通道缩放）

对每个权重通道，找一个缩放因子 `s`：

```
原始:    Y = X @ W
缩放后:  Y = (X * s) @ (W / s) = X @ W  (数学等价)

但量化时:
  - W / s 量化到 INT4 → 误差可控 (因为 s 调大了重要权重)
  - X * s 在 FP16 计算 → 没量化误差
```

通过调 `s`，让"重要权重的相对值变大"，量化时被保护。

#### 技巧 2：Search-based 最优 scale

最优 `s` 不是闭式解，AWQ 用网格搜索：

```
for s in [0.0, 0.1, 0.2, ..., 1.0]:
    量化 W/s 到 INT4
    在校准集上跑一遍,看输出和 FP16 差多少
选差最小的 s
```

校准集通常是 128-512 条文本（不需要标签）。

#### 技巧 3：Group-wise Quantization

不是整个 tensor 一个 scale，而是分成 group（通常 128 个权重一组），每组一个 scale。

```
权重 W shape [4096, 11008]
分成 group_size=128 的小组
每组的 scale 独立计算
共 (4096 * 11008) / 128 = 351232 个 scale
```

更细粒度 → 更高精度，但 scale 占额外显存。

### 1.3 AWQ vs GPTQ vs SmoothQuant 对比

| 方案 | 权重 | 激活 | 校准 | 精度 | 速度 | 易用性 |
|------|-----|------|-----|------|-----|--------|
| 朴素 INT4 | INT4 | INT4 | - | 差 | 最快 | 简单 |
| GPTQ | INT4 | FP16 | 需要 | 中 | 快 | 中 |
| AWQ | INT4 | FP16 | 需要 | 高 | 快 | 高 |
| SmoothQuant | INT8 | INT8 | 需要 | 高 | 中 | 中 |
| FP8 (H100) | FP8 | FP8 | - | 极高 | 极快 | 简单 |

AWQ 在精度和易用性之间平衡最好：
- 精度：通常只比 FP16 低 1-2%
- 速度：W4A16 GEMM 用 TensorCore 加速，比 FP16 快 2-3 倍
- 易用：vLLM/SGLang 原生支持，一行参数加载

---

## 2. AWQ 量化模型的结构

一个 AWQ 量化模型包含：

### 2.1 量化权重

```
model.layers[0].self_attn.q_proj.qweight    INT4 量化后的权重 (packed)
model.layers[0].self_attn.q_proj.scales     FP16 scale, shape [out, in/128]
model.layers[0].self_attn.q_proj.qzeros     INT4 zero point (部分实现)
```

INT4 packing：两个 INT4 值 pack 进一个 INT8，节省存储。

### 2.2 非量化部分

```
model.layers[0].input_layernorm.weight      FP16 (layer norm 不量化)
model.layers[0].post_attention_layernorm.weight  FP16
model.embed_tokens.weight                   FP16 (embedding 不量化)
model.lm_head.weight                        FP16 (output 不量化)
```

### 2.3 配置文件

`quantize_config.json`:
```json
{
  "bits": 4,
  "group_size": 128,
  "quant_method": "awq",
  "version": "gemm",
  "modules_to_not_convert": ["lm_head"]
}
```

---

## 3. 用 AutoAWQ 量化自己的模型

### 3.1 安装

```bash
pip install autoawq
```

### 3.2 量化脚本

```python
"""
quantize_with_awq.py — 用 AutoAWQ 量化一个 HF 模型

输入: HuggingFace 模型路径
输出: AWQ 量化后的模型,保存到本地

注意:
- 量化需要 GPU (建议 >= 24GB 显存)
- 7B 模型量化约需 30 分钟
- 校准数据集用 WikiText 或自定义
"""

from awq import AutoAWQForCausalLM
from transformers import AutoTokenizer
import torch

# ============ 配置 ============
MODEL_PATH = "meta-llama/Llama-3-8B"          # 原模型 (FP16)
OUTPUT_PATH = "./Llama-3-8B-AWQ"               # 量化后输出路径
CALIB_DATA = ["autoawq calibration default"]   # 校准数据

# 量化配置
quant_config = {
    "zero_point": True,         # 用 zero point (更精确,稍慢)
    "q_group_size": 128,        # group 大小,128 是 sweet spot
    "w_bit": 4,                 # 权重量化到 4 bit
    "version": "GEMM",          # GEMM 版本 (兼容 vLLM)
}

print(f"加载模型: {MODEL_PATH}")
model = AutoAWQForCausalLM.from_pretrained(
    MODEL_PATH,
    device_map="auto",
    torch_dtype=torch.float16,
)
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)

print(f"开始量化 (校准数据 {len(CALIB_DATA)} 条)...")
model.quantize(
    tokenizer,
    quant_config=quant_config,
    calib_data=CALIB_DATA,
)

print(f"保存量化模型到: {OUTPUT_PATH}")
model.save_quantized(OUTPUT_PATH)
tokenizer.save_pretrained(OUTPUT_PATH)

print("量化完成!")
```

### 3.3 校准数据选择

校准数据影响量化质量：
- **通用模型**：用 WikiText / RedPajamas 摘录
- **领域模型**：用领域内文本（代码、医学、法律）
- **数量**：128-512 条文本，每条 512 token

```python
# 自定义校准数据示例
CALIB_DATA = [
    "The quick brown fox jumps over the lazy dog.",
    "In machine learning, gradient descent is...",
    # ... 128-512 条
]

# 或从 HuggingFace dataset 加载
from datasets import load_dataset
ds = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
CALIB_DATA = [t for t in ds["text"] if len(t) > 200][:256]
```

---

## 4. 用 vLLM 部署 AWQ 模型

### 4.1 直接用现成的 AWQ 模型

HuggingFace 上有大量现成的 AWQ 模型，比如：
- `TheBloke/Llama-2-7B-Chat-AWQ`
- `casperhansen/llama-3-8b-instruct-awq`
- `Qwen/Qwen2-7B-Instruct-AWQ`

### 4.2 vLLM 启动

```bash
vllm serve casperhansen/llama-3-8b-instruct-awq \
    --quantization awq \
    --port 8000
```

关键参数：
- `--quantization awq`：告诉 vLLM 用 AWQ 反量化路径
- vLLM 会自动检测 `quantize_config.json` 并用对应 kernel

### 4.3 性能对比

```bash
# FP16 基线
vllm serve meta-llama/Llama-3-8B --port 8000

# AWQ INT4
vllm serve casperhansen/llama-3-8b-instruct-awq \
    --quantization awq --port 8000
```

跑 benchmark 对比：

```bash
python -m vllm.entrypoints.openai.benchmark_serving \
    --backend vllm \
    --base-url http://localhost:8000 \
    --model casperhansen/llama-3-8b-instruct-awq \
    --num-prompts 200 \
    --random-input-len 1024 \
    --random-output-len 256
```

预期结果（A100 80GB，Llama-3-8B）：

| 模式 | 显存 | 吞吐 | TPOT |
|------|------|-----|------|
| FP16 | 16 GB | 2000 tok/s | 25ms |
| AWQ INT4 | 5 GB | 3500 tok/s | 15ms |
| 提升 | 3.2x | 1.75x | 1.67x |

**为什么显存省 3.2x 而不是 4x**：因为 LM head、embedding、layer norm 等不量化，仍占 FP16。

---

## 5. AWQ 真实部署脚本

下面是一个完整的部署 + benchmark 脚本：

```python
"""
awq_real_deploy.py — AWQ 模型部署与 benchmark

功能:
    1. 启动 vLLM 服务加载 AWQ 模型
    2. 跑 benchmark 测吞吐和延迟
    3. 验证输出正确性 (对比预期)

使用:
    1. 先启动 vLLM 服务:
       vllm serve casperhansen/llama-3-8b-instruct-awq --quantization awq --port 8000
    2. 再跑这个脚本:
       python awq_real_deploy.py
"""

import asyncio
import time
import statistics
import httpx
import json
from typing import List, Dict

BASE_URL = "http://localhost:8000/v1"
MODEL_NAME = "casperhansen/llama-3-8b-instruct-awq"


async def send_request(
    client: httpx.AsyncClient,
    prompt: str,
    max_tokens: int = 256,
) -> Dict:
    """
    发送一个推理请求,返回统计信息

    返回:
        {
            "ttft": 首 token 延迟 (秒),
            "total_time": 总时间,
            "output_tokens": 输出 token 数,
            "tpot": 单 token 延迟,
            "output": 生成的文本,
        }
    """
    start = time.time()
    ttft = None
    output_tokens = 0
    output_text = ""

    async with client.stream(
        "POST",
        f"{BASE_URL}/completions",
        json={
            "model": MODEL_NAME,
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": 0.7,
            "stream": True,
            "stream_options": {"include_usage": True},
        },
        timeout=120.0,
    ) as response:
        async for line in response.aiter_lines():
            if not line.startswith("data: "):
                continue
            data = line[6:]
            if data == "[DONE]":
                break
            try:
                chunk = json.loads(data)
                if "choices" in chunk and chunk["choices"]:
                    delta = chunk["choices"][0].get("text", "")
                    if delta:
                        if ttft is None:
                            ttft = time.time() - start
                        output_text += delta
                        output_tokens += 1
                if "usage" in chunk:
                    output_tokens = chunk["usage"].get(
                        "completion_tokens", output_tokens
                    )
            except json.JSONDecodeError:
                continue

    total_time = time.time() - start
    return {
        "ttft": ttft or 0,
        "total_time": total_time,
        "output_tokens": output_tokens,
        "tpot": (total_time - (ttft or 0)) / max(output_tokens - 1, 1),
        "output": output_text,
    }


async def benchmark_throughput(num_requests: int = 50):
    """测吞吐: 并发发 num_requests 个请求"""
    prompts = [
        "Explain the concept of gradient descent in machine learning.",
        "Write a Python function to implement quicksort.",
        "What are the main causes of climate change?",
        "Describe the plot of Romeo and Juliet.",
        "How does a transformer neural network work?",
    ] * (num_requests // 5 + 1)
    prompts = prompts[:num_requests]

    print(f"\n===== 吞吐测试: {num_requests} 个并发请求 =====")
    
    async with httpx.AsyncClient() as client:
        start = time.time()
        results = await asyncio.gather(
            *[send_request(client, p, max_tokens=128) for p in prompts]
        )
        total_time = time.time() - start

    ttfts = [r["ttft"] for r in results]
    tpots = [r["tpot"] for r in results]
    total_output_tokens = sum(r["output_tokens"] for r in results)

    print(f"总时间: {total_time:.2f}s")
    print(f"总输出 tokens: {total_output_tokens}")
    print(f"吞吐: {total_output_tokens / total_time:.1f} tok/s")
    print(f"TTFT (mean / P50 / P99): "
          f"{statistics.mean(ttfts)*1000:.1f}ms / "
          f"{statistics.median(ttfts)*1000:.1f}ms / "
          f"{sorted(ttfts)[int(len(ttfts)*0.99)]*1000:.1f}ms")
    print(f"TPOT (mean / P50): "
          f"{statistics.mean(tpots)*1000:.1f}ms / "
          f"{statistics.median(tpots)*1000:.1f}ms")
    
    return results


async def benchmark_latency():
    """测延迟: 单请求逐个发"""
    prompt = "Write a short poem about autumn."
    
    print(f"\n===== 延迟测试: 10 个单请求 =====")
    
    async with httpx.AsyncClient() as client:
        results = []
        for _ in range(10):
            r = await send_request(client, prompt, max_tokens=100)
            results.append(r)
    
    ttfts = [r["ttft"] for r in results]
    tpots = [r["tpot"] for r in results]
    
    print(f"TTFT (mean / P50 / P99): "
          f"{statistics.mean(ttfts)*1000:.1f}ms / "
          f"{statistics.median(ttfts)*1000:.1f}ms / "
          f"{sorted(ttfts)[int(len(ttfts)*0.99)]*1000:.1f}ms")
    print(f"TPOT (mean): {statistics.mean(tpots)*1000:.1f}ms")


async def verify_correctness():
    """验证推理正确性: 看输出是否合理"""
    test_cases = [
        ("1 + 1 = ", "2"),
        ("The capital of France is ", "Paris"),
        ("def hello_world():", "print"),
    ]
    
    print(f"\n===== 正确性测试 =====")
    async with httpx.AsyncClient() as client:
        for prompt, expected_keyword in test_cases:
            r = await send_request(client, prompt, max_tokens=30)
            ok = expected_keyword.lower() in r["output"].lower()
            status = "✓" if ok else "✗"
            print(f"{status} Prompt: {prompt!r}")
            print(f"  Expected keyword: {expected_keyword!r}")
            print(f"  Got: {r['output']!r[:100]}")


async def main():
    print("=" * 60)
    print(f"AWQ 模型 benchmark")
    print(f"Model: {MODEL_NAME}")
    print(f"Server: {BASE_URL}")
    print("=" * 60)
    
    # 1. 正确性测试
    await verify_correctness()
    
    # 2. 延迟测试
    await benchmark_latency()
    
    # 3. 吞吐测试
    await benchmark_throughput(num_requests=50)
    
    print("\n" + "=" * 60)
    print("Benchmark 完成")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
```

---

## 6. AWQ 部署常见问题

### 6.1 `quantization` 参数报错

vLLM 较新版本会自动检测 `quantize_config.json`，不需要显式传 `--quantization awq`。如果报错，确认模型路径里有：

```
config.json
quantize_config.json    ← 这个必须有
model-*.safetensors
tokenizer.json
```

### 6.2 显存不够

AWQ INT4 的 7B 模型大约 5GB 权重 + KV Cache。如果还报 OOM：
- 降低 `--gpu-memory-utilization 0.85`
- 降低 `--max-model-len`
- 启用 KV Cache 量化

### 6.3 输出乱码 / 重复

可能是量化版本和 vLLM 版本不匹配。检查：
- `quantize_config.json` 里的 `version` 字段（GEMM 还是 GEMV）
- vLLM 版本（建议用最新 stable）

### 6.4 速度没提升

如果 AWQ 比 FP16 还慢，可能原因：
- GPU 不支持 INT4 TensorCore（需要 sm_80+，即 A100/A30/RTX 30+）
- vLLM 版本过旧
- batch 太小（小 batch 时 AWQ 优势不明显）

---

## 7. AWQ vs GPTQ 实战选择

| 场景 | 推荐 |
|------|------|
| 用 vLLM/SGLang 部署 | AWQ（生态支持更好） |
| 自己量化训练好的模型 | AWQ（精度高） |
| 极致推理速度 | GPTQ（kernel 更成熟，但差距小） |
| H100 部署 | 直接用 FP8，跳过 INT4 |
| 资源受限（如 Jetson） | AWQ |

---

## 8. 学习路径建议

1. **跑现成 AWQ 模型**：下载 `casperhansen/llama-3-8b-instruct-awq`，用 vLLM 启动
2. **跑 awq_real_deploy.py**：测吞吐和延迟
3. **对比 FP16**：跑同样 benchmark，看 2-3x 加速
4. **用 AutoAWQ 量化自己的模型**：跑 quantize_with_awq.py
5. **调 group_size**：试 64 / 128 / 256，看精度和速度权衡
6. **读 AWQ 论文** → 理解数学原理

---

## 9. 延伸阅读

- AWQ 论文：Lin et al., 2023 "AWQ: Activation-aware Weight Quantization for LLM Compression and Acceleration"
- AutoAWQ: `https://github.com/casper-hansen/AutoAWQ`
- vLLM 量化文档: `https://docs.vllm.ai/en/latest/quantization/`
- GPTQ 论文（对比用）

---

## 10. 速查表

| 项目 | AWQ |
|------|-----|
| 权重精度 | INT4 (W4A16) |
| 激活精度 | FP16 |
| group_size | 128 (典型) |
| 校准数据 | 128-512 条文本 |
| 7B 模型大小 | ~5 GB |
| 70B 模型大小 | ~35 GB |
| 加速比 (vs FP16) | 2-3x |
| 精度损失 | 1-2% |
| vLLM 支持 | ✅ 原生 |
| SGLang 支持 | ✅ 原生 |
| 量化工具 | AutoAWQ |
