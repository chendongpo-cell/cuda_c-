# Uni-Mol 迁移分析 — AI4S 分子表示学习

> 目标：理解 Uni-Mol 项目结构，规划 PyTorch 迁移策略。
> 难度：⭐⭐（纯 PyTorch，无自定义 CUDA kernel）

---

## 1. 项目概况

Uni-Mol 是深势科技开发的分子表示学习模型，基于 Transformer。
类似"分子领域的 BERT"——预训练后可以用于各种分子预测任务。

```
官网：https://github.com/dptech-corp/Uni-Mol
核心思想：用 3D 位置编码的 Transformer 学习分子表示
```

### 1.1 和 LLM 推理的相似性

Uni-Mol 本质上也是一个 Transformer：

| 组件 | LLM Transformer | Uni-Mol |
|------|----------------|---------|
| 输入 | token IDs | 原子类型 + 3D 坐标 |
| 位置编码 | RoPE | 3D 距离偏置 + 原子对特征 |
| Attention | Self-Attention | Self-Attention + Pair-wise bias |
| FFN | SwiGLU | GELU / LayerNorm |
| 输出 | next token logits | 分子表示向量 (embedding) |

---

## 2. 模型结构

### 2.1 核心文件

```
Uni-Mol/
├── unirn/mol/                  # 模型定义
│   ├── transformer.py          # Transformer encoder（主要改这里）
│   ├── pair_encoder.py         # 原子对编码器
│   ├── coord_encoder.py        # 3D 坐标编码
│   └── head.py                 # 下游任务 head
├── unirn/data/                 # 数据预处理（分子指纹、3D 构象生成）
├── unirn/tasks/                # 预训练和下游任务
└── scripts/                    # 训练/推理脚本
```

### 2.2 特殊之处

```
1. 3D 位置编码
   不是 RoPE，而是用 Gaussian 核函数对原子间距离做编码
   形状: [batch, seq, seq, num_kernels]
   影响：显存占用比 LLM 更大（O(n² * k)）

2. Pair-wise Attention Bias
   在标准 Attention 上加了 pair bias
   attention_score = QK^T / sqrt(d) + pair_bias
   迁移时无需改 CUDA kernel（纯 PyTorch 实现）

3. 无 KV Cache 优化
   Uni-Mol 是 encoder-only，一次性计算，不需要自回归生成
   所以不需要 PagedAttention 等优化
```

---

## 3. 迁移要点

### 3.1 为什么简单？

```
Uni-Mol 的所有算子都可以用 PyTorch 原生 API 实现：
  torch.nn.MultiheadAttention → 标准 Attention
  torch.nn.Linear → 所有投影矩阵
  torch.nn.GELU → 激活函数
  F.dropout → Dropout
  LayerNorm → 归一化

没有自定义 CUDA kernel！
所以迁移 = 确保 PyTorch ROCm 版本能跑
```

### 3.2 迁移步骤

```bash
# 第 1 步：安装 ROCm PyTorch
pip3 install torch torchvision --index-url https://download.pytorch.org/whl/rocm6.2

# 第 2 步：检查 DCU 可用
python -c "
import torch
print(torch.cuda.is_available())  # ROCm 兼容 CUDA API
print(torch.cuda.get_device_name(0))
"

# 第 3 步：运行 pre-training
python scripts/pretrain.py --device cuda

# 第 4 步：运行下游任务
python scripts/finetune_qm9.py --device cuda
```

### 3.3 可能遇到的问题

```python
# 问题 1：torch.compile 在 ROCm 上的支持
# ROCm 6.2+ 才支持 torch.compile
# 如果版本不够，用 eager mode 或加装饰器

# 问题 2：混合精度训练
# AMP (automatic mixed precision) 在 ROCm 上需要验证
with torch.cuda.amp.autocast():
    output = model(input)

# 问题 3：DataLoader 的多进程
# 需要在 ROCm 上测试 num_workers > 0
```

---

## 4. 验证方式

```python
# 验证前向传播输出一致（CUDA vs HIP）
import torch

# CUDA 版本（NVIDIA GPU）
model_cuda = UniMol.from_pretrained("unimol_base")
x_cuda = torch.randn(1, 128, 512).cuda()
out_cuda = model_cuda(x_cuda)

# HIP 版本（DCU）
model_hip = UniMol.from_pretrained("unimol_base")
model_hip = model_hip.hip()        # ROCm 兼容 .cuda() 语法
x_hip = torch.randn(1, 128, 512).hip()
out_hip = model_hip(x_hip)

# 对比（浮点误差 < 1e-5）
diff = (out_cuda.cpu() - out_hip.cpu()).abs().max()
```

---

## 面试考点

| 知识点 | 说明 |
|--------|------|
| Uni-Mol 和 LLM 的异同 | 都是 Transformer，但 Uni-Mol 是 encoder-only |
| 迁移难度 | 纯 PyTorch 项目，主要是 ROCm 版本兼容问题 |
| 3D 位置编码 | Gaussian kernel 编码原子间距离，不是 RoPE |
| 显存消耗 | Pair bias 导致 O(n²*k) 显存占用 |
