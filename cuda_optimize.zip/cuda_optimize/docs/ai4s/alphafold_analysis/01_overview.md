# AlphaFold2 / GraphCast 迁移分析 — AI4S 高级方向

> 目标：规划 JAX-based 科学模型迁移策略。
> 难度：⭐⭐⭐⭐⭐（JAX 生态 + TPU 优化 + 巨大项目）

---

## 1. 项目概况

### AlphaFold2

```
官网：https://github.com/google-deepmind/alphafold
任务：蛋白质结构预测（输入氨基酸序列 → 输出 3D 结构）
核心模型：Evoformer + Structure Module
框架：JAX（Google 生态）
训练数据：PDB 数据库 + 基因序列数据库
预训练权重：~2.5GB（不做重训练）
```

### GraphCast

```
官网：https://github.com/google-deepmind/graphcast
任务：天气预报（输入历史天气数据 → 预测未来天气）
核心模型：Graph Neural Network + Transformer
框架：JAX
训练数据：ERA5 再分析数据
```

---

## 2. JAX 生态和 DCU 的兼容性

### 2.1 最大的难题

```bash
# JAX 目前官方支持的硬件：
#   - NVIDIA GPU（CUDA）
#   - Google TPU
#   - CPU 模式
#
# JAX 不支持 AMD GPU / DCU！
#
# 这意味着：AlphaFold2 和 GraphCast 不能直接在 DCU 上跑
```

### 2.2 可能的解决方案

```
方案 1：等待 ROCm 对 JAX 的支持
  目前 AMD 有 ROCm 版 JAX（实验性）
  但 DCU 的 ROCm 版本可能落后于 AMD 官方 ROCm
  可行性：低（依赖上游）

方案 2：JAX → PyTorch 翻译
  把 JAX 代码翻译成 PyTorch
  工作量巨大（AlphaFold2 有 ~20 万行 JAX 代码）
  可行性：低（等于重写）

方案 3：只做推理，不做训练
  用 NVIDIA GPU 跑推理
  在 CPU 上运行 JAX（慢，但不要求 DCU 兼容）
  可行性：中（可用于验证）

方案 4：使用 ONNX 中间表示
  JAX → ONNX → DCU 推理框架
  需要处理 JAX 特有的操作（如 lax.*）
  可行性：中
```

---

## 3. 曙光工作场景的实际建议

### 3.1 你做为主力的内容

```
✅ 高优先（需要你做）：
  DeePMD-kit 迁移 ← 曙光最常用的 AI4S 框架
  有现成的 CUDA kernel 可以迁移
  和推理优化的技能重叠（GPU kernel 优化）

⚠️ 中优先（了解即可）：
  Uni-Mol 迁移
  纯 PyTorch，ROCm PyTorch 版本稳定后自然兼容
  主要工作是验证 + 修小 bug

❌ 低优先（非曙光主力）：
  AlphaFold2 / GraphCast
  JAX 生态不支持 DCU
  需要等上游支持或架构决策
```

### 3.2 如果被要求做 AlphaFold2

```bash
# 1. 确认需求范围
#   是推理？还是训练？
#   推理可以用 CPU JAX（慢但可用）

# 2. 如果是推理：
python run_alphafold.py \
  --fasta_paths=protein.fasta \
  --output_dir=./output \
  --model_names=model_1 \
  --data_dir=./databases

# 设置 JAX 使用 CPU
export JAX_PLATFORMS=cpu,python

# 3. 如果是训练/微调：
#   建议申请 NVIDIA GPU 资源
#   或等待 ROCm JAX 的 DCU 支持
```

---

## 4. 迁移策略对比

| 模型 | 框架 | 自定义 Kernel | 迁移难度 | 曙光优先级 |
|------|------|--------------|---------|-----------|
| DeePMD-kit | TF/PyTorch | 很多 CUDA kernel | ⭐⭐⭐⭐ | **最高** |
| Uni-Mol | PyTorch | 无 | ⭐⭐ | 中 |
| AlphaFold2 | JAX | 少量 | ⭐⭐⭐⭐⭐ | **低** |
| GraphCast | JAX | 无 | ⭐⭐⭐⭐⭐ | 低 |

---

## 面试考点

| 知识点 | 说明 |
|--------|------|
| JAX 和 CUDA 的关系 | JAX 用 XLA 编译到 CUDA，不支持 ROCm |
| AlphaFold2 架构 | Evoformer (Transformer) + Structure Module |
| 迁移的拦路虎 | JAX 不兼容 DCU 是核心问题 |
| 曙光实际场景 | 主力是 DeePMD-kit，AlphaFold 不是重点 |
