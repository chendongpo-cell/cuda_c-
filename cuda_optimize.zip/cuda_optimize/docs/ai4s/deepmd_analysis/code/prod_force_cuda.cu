/*
 * prod_force_cuda.cu — DeePMD-kit prod_force kernel（简化版）
 *
 * 原始文件：source/op/cu/prod_force.cu
 * 功能：计算每个原子受到的力（F = -dE/dR）
 *
 * 这是 DeePMD-kit 中最复杂的 CUDA kernel，占推理计算量 60%+。
 * 迁移到 HIP 时的核心模式都在这里。
 *
 * 编译：nvcc -O2 -arch=sm_80 -o prod_force_cuda prod_force_cuda.cu
 * 运行：./prod_force_cuda
 */

#include <cstdio>
#include <cstdlib>
#include <cmath>

#define CUDA_CHECK(call)                                                      \
    do {                                                                      \
        cudaError_t err = call;                                               \
        if (err != cudaSuccess) {                                             \
            fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__, \
                    cudaGetErrorString(err));                                 \
            exit(EXIT_FAILURE);                                               \
        }                                                                     \
    } while(0)

// ================================================================
// prod_force kernel（简化版）
//
// 每个 block 处理一个原子，block 内线程处理该原子的邻居
// 用 shared memory 累加部分力，最后 atomicAdd 到全局 force
//
// 为什么这么设计？
//   DeePMD 的力和每个原子的邻居有关，不同原子的邻居数不同
//   这是典型的不规则并行——block 间负载不均衡
// ================================================================

__global__ void prod_force_kernel(
    const float* net_deriv,     // [nloc, 4, ndescrpt]  网络导数
    const float* env_deriv,     // [nloc, nnei, 3]      环境导数
    const int*   nlist,         // [nloc, nnei]         邻居列表（-1 表示无邻居）
    float*       force,         // [nloc, 3]            输出：每个原子的力分量
    int nloc,                   // 原子数
    int nnei,                   // 每个原子的最大邻居数
    int ndescrpt                // 描述符维度
) {
    int atom_id = blockIdx.x;   // 每个 block 处理一个原子
    if (atom_id >= nloc) return;

    // 共享内存：保存该原子的部分力贡献
    // 用 3 个 float 累加 x/y/z 方向
    __shared__ float fx[256];
    __shared__ float fy[256];
    __shared__ float fz[256];

    int tid = threadIdx.x;
    fx[tid] = 0.0f;
    fy[tid] = 0.0f;
    fz[tid] = 0.0f;

    // 步进遍历该原子的所有邻居
    // 每个线程处理 stride 个邻居
    for (int nei_idx = tid; nei_idx < nnei; nei_idx += blockDim.x) {
        int neighbor_id = nlist[atom_id * nnei + nei_idx];
        if (neighbor_id < 0) continue;  // 无效邻居

        // 从 net_deriv 读取该原子的网络导数
        // 简化：只用前 4 个描述符维度
        float nd0 = net_deriv[atom_id * 4 * ndescrpt + 0 * ndescrpt + nei_idx];
        float nd1 = net_deriv[atom_id * 4 * ndescrpt + 1 * ndescrpt + nei_idx];
        float nd2 = net_deriv[atom_id * 4 * ndescrpt + 2 * ndescrpt + nei_idx];
        float nd3 = net_deriv[atom_id * 4 * ndescrpt + 3 * ndescrpt + nei_idx];

        // 从 env_deriv 读取环境导数（3 个方向）
        float ed_x = env_deriv[atom_id * nnei * 3 + nei_idx * 3 + 0];
        float ed_y = env_deriv[atom_id * nnei * 3 + nei_idx * 3 + 1];
        float ed_z = env_deriv[atom_id * nnei * 3 + nei_idx * 3 + 2];

        // 力贡献 = net_deriv · env_deriv（简化计算）
        fx[nei_idx % 256] += nd0 * ed_x;
        fy[nei_idx % 256] += nd1 * ed_y;
        fz[nei_idx % 256] += nd2 * ed_z;
        // 注意：这里用 nei_idx % 256 做索引是折中方案
        // 实际 DeePMD 中更复杂，需要正确处理描述符到邻居的映射
    }

    __syncthreads();

    // 树形归约：将 shared memory 中的部分和累加
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            fx[tid] += fx[tid + s];
            fy[tid] += fy[tid + s];
            fz[tid] += fz[tid + s];
        }
        __syncthreads();
    }

    // 线程 0 用 atomicAdd 将结果写到全局 force
    // 因为一个原子可能被多个 block 处理（不同 block 处理该原子的不同邻居组）
    if (tid == 0) {
        atomicAdd(&force[atom_id * 3 + 0], fx[0]);
        atomicAdd(&force[atom_id * 3 + 1], fy[0]);
        atomicAdd(&force[atom_id * 3 + 2], fz[0]);
    }
}

// ================================================================
// main（功能测试）
// ================================================================

int main() {
    int nloc = 256;     // 256 个原子
    int nnei = 128;     // 每个原子最多 128 个邻居
    int ndescrpt = 128; // 描述符维度

    size_t size_net  = nloc * 4 * ndescrpt * sizeof(float);
    size_t size_env  = nloc * nnei * 3 * sizeof(float);
    size_t size_list = nloc * nnei * sizeof(int);
    size_t size_force = nloc * 3 * sizeof(float);

    // 随机初始化数据
    float* h_net   = (float*)malloc(size_net);
    float* h_env   = (float*)malloc(size_env);
    int*   h_list  = (int*)malloc(size_list);
    float* h_force = (float*)calloc(nloc * 3, sizeof(float));

    for (int i = 0; i < nloc * 4 * ndescrpt; ++i)
        h_net[i] = static_cast<float>(rand()) / RAND_MAX;
    for (int i = 0; i < nloc * nnei * 3; ++i)
        h_env[i] = static_cast<float>(rand()) / RAND_MAX;
    for (int i = 0; i < nloc * nnei; ++i)
        h_list[i] = (rand() % 100 < 90) ? (rand() % nloc) : -1; // 90% 有效

    float *d_net, *d_env, *d_force;
    int *d_list;
    CUDA_CHECK(cudaMalloc(&d_net, size_net));
    CUDA_CHECK(cudaMalloc(&d_env, size_env));
    CUDA_CHECK(cudaMalloc(&d_list, size_list));
    CUDA_CHECK(cudaMalloc(&d_force, size_force));

    CUDA_CHECK(cudaMemcpy(d_net, h_net, size_net, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_env, h_env, size_env, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_list, h_list, size_list, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemset(d_force, 0, size_force));

    prod_force_kernel<<<nloc, 256>>>(d_net, d_env, d_list, d_force,
                                     nloc, nnei, ndescrpt);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    CUDA_CHECK(cudaMemcpy(h_force, d_force, size_force, cudaMemcpyDeviceToHost));

    // 验证：力应该非零（随机输入不会全零）
    bool ok = false;
    for (int i = 0; i < nloc * 3; ++i) {
        if (fabs(h_force[i]) > 1e-6f) { ok = true; break; }
    }
    printf("CUDA prod_force: %s\n", ok ? "PASS" : "FAIL (all zeros)");
    printf("  First atom forces: fx=%f fy=%f fz=%f\n",
           h_force[0], h_force[1], h_force[2]);

    CUDA_CHECK(cudaFree(d_net));
    CUDA_CHECK(cudaFree(d_env));
    CUDA_CHECK(cudaFree(d_list));
    CUDA_CHECK(cudaFree(d_force));
    free(h_net); free(h_env); free(h_list); free(h_force);

    return 0;
}
