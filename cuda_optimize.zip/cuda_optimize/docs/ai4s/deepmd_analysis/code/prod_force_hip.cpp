/*
 * prod_force_hip.cpp — DeePMD-kit prod_force 的 HIP 移植版
 *
 * 对照 prod_force_cuda.cu，演示 CUDA → HIP 迁移模式。
 *
 * 迁移总结：
 *   头文件:   <cuda_runtime.h>  →  <hip/hip_runtime.h>
 *   API:      cudaMalloc        →  hipMalloc
 *             cudaMemcpy        →  hipMemcpy
 *             cudaFree          →  hipFree
 *   Kernel:   语法完全兼容，无需改动
 *   atomicAdd: 兼容，无需改动
 *   block_size: 建议 64 的倍数（wavefront=64）
 *
 * 编译：hipcc -O2 -o prod_force_hip prod_force_hip.cpp
 * 运行：./prod_force_hip
 */

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <hip/hip_runtime.h>  // ★ 迁移点 1：头文件

#define HIP_CHECK(call)                                                         \
    do {                                                                        \
        hipError_t err = call;                                                  \
        if (err != hipSuccess) {                                                \
            fprintf(stderr, "HIP error at %s:%d: %s\n", __FILE__, __LINE__,     \
                    hipGetErrorString(err));                                    \
            exit(EXIT_FAILURE);                                                 \
        }                                                                       \
    } while(0)

// ================================================================
// prod_force kernel（HIP 版）
//
// 和 CUDA 版本的区别（几乎无！）：
//   __global__  → 不变
//   __shared__  → 不变
//   atomicAdd   → 不变
//   blockDim/gridDim → 不变
//
// ★ 核心差异：block_size 选择
//   CUDA (warp=32):  block_size=128 或 256 都行
//   HIP  (warp=64):  建议 block_size=128 或 256（64 的倍数）
//   如果 CUDA 用 128 → HIP 用 128 即可（都是 64 的倍数）
//   如果 CUDA 用 96  → HIP 应该改成 128！
//
// ★ 共享内存（LDS）限制
//   CUDA: shared memory 最大 48KB/block（默认）或 164KB（opt-in）
//   HIP:  DCU 的 LDS 最大 64KB/CU
//   如果 CUDA 代码用了 >64KB shared memory → 需要分块
// ================================================================

__global__ void prod_force_kernel(
    const float* net_deriv,     // [nloc, 4, ndescrpt]
    const float* env_deriv,     // [nloc, nnei, 3]
    const int*   nlist,         // [nloc, nnei]
    float*       force,         // [nloc, 3]
    int nloc, int nnei, int ndescrpt
) {
    // ★ 迁移点 2：block_size 改为 64 的倍数
    // blockIdx.x 对应原子 ID（CUDA 和 HIP 一致）
    int atom_id = blockIdx.x;
    if (atom_id >= nloc) return;

    // ★ 迁移点 3：shared memory 大小检查
    // 256 * 3 * 4 bytes = 3072 bytes，远小于 64KB → 安全
    __shared__ float fx[256];
    __shared__ float fy[256];
    __shared__ float fz[256];

    int tid = threadIdx.x;
    fx[tid] = 0.0f;
    fy[tid] = 0.0f;
    fz[tid] = 0.0f;

    // ★ 迁移点 4：warp-level 归约适配
    // 核心循环（和 CUDA 完全一致）
    for (int nei_idx = tid; nei_idx < nnei; nei_idx += blockDim.x) {
        int neighbor_id = nlist[atom_id * nnei + nei_idx];
        if (neighbor_id < 0) continue;

        float nd0 = net_deriv[atom_id * 4 * ndescrpt + 0 * ndescrpt + nei_idx];
        float nd1 = net_deriv[atom_id * 4 * ndescrpt + 1 * ndescrpt + nei_idx];
        float nd2 = net_deriv[atom_id * 4 * ndescrpt + 2 * ndescrpt + nei_idx];
        float nd3 = net_deriv[atom_id * 4 * ndescrpt + 3 * ndescrpt + nei_idx];

        float ed_x = env_deriv[atom_id * nnei * 3 + nei_idx * 3 + 0];
        float ed_y = env_deriv[atom_id * nnei * 3 + nei_idx * 3 + 1];
        float ed_z = env_deriv[atom_id * nnei * 3 + nei_idx * 3 + 2];

        fx[nei_idx % 256] += nd0 * ed_x;
        fy[nei_idx % 256] += nd1 * ed_y;
        fz[nei_idx % 256] += nd2 * ed_z;
    }

    __syncthreads();

    // ★ 迁移点 5：树形归约（CUDA 和 HIP 语法一致）
    // 但如果是 warp-level 的 __shfl_down 版本：
    //   CUDA: __shfl_down_sync(mask, val, delta)
    //   注意 HIP 中 __shfl_down 可以没有 mask 参数
    //   但为了兼容性，建议保留 mask
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            fx[tid] += fx[tid + s];
            fy[tid] += fy[tid + s];
            fz[tid] += fz[tid + s];
        }
        __syncthreads();
    }

    // atomicAdd 兼容
    if (tid == 0) {
        atomicAdd(&force[atom_id * 3 + 0], fx[0]);
        atomicAdd(&force[atom_id * 3 + 1], fy[0]);
        atomicAdd(&force[atom_id * 3 + 2], fz[0]);
    }
}

// ================================================================
// main —— 和 CUDA 版本逻辑一致，API 替换
// ================================================================

int main() {
    int nloc = 256;
    int nnei = 128;
    int ndescrpt = 128;

    size_t size_net   = nloc * 4 * ndescrpt * sizeof(float);
    size_t size_env   = nloc * nnei * 3 * sizeof(float);
    size_t size_list  = nloc * nnei * sizeof(int);
    size_t size_force = nloc * 3 * sizeof(float);

    float* h_net   = (float*)malloc(size_net);
    float* h_env   = (float*)malloc(size_env);
    int*   h_list  = (int*)malloc(size_list);
    float* h_force = (float*)calloc(nloc * 3, sizeof(float));

    for (int i = 0; i < nloc * 4 * ndescrpt; ++i)
        h_net[i] = static_cast<float>(rand()) / RAND_MAX;
    for (int i = 0; i < nloc * nnei * 3; ++i)
        h_env[i] = static_cast<float>(rand()) / RAND_MAX;
    for (int i = 0; i < nloc * nnei; ++i)
        h_list[i] = (rand() % 100 < 90) ? (rand() % nloc) : -1;

    float *d_net, *d_env, *d_force;
    int *d_list;

    // ★ 迁移点 6：cudaMalloc → hipMalloc
    HIP_CHECK(hipMalloc(&d_net, size_net));
    HIP_CHECK(hipMalloc(&d_env, size_env));
    HIP_CHECK(hipMalloc(&d_list, size_list));
    HIP_CHECK(hipMalloc(&d_force, size_force));

    // ★ 迁移点 7：cudaMemcpy → hipMemcpy
    HIP_CHECK(hipMemcpy(d_net, h_net, size_net, hipMemcpyHostToDevice));
    HIP_CHECK(hipMemcpy(d_env, h_env, size_env, hipMemcpyHostToDevice));
    HIP_CHECK(hipMemcpy(d_list, h_list, size_list, hipMemcpyHostToDevice));
    HIP_CHECK(hipMemset(d_force, 0, size_force));

    // ★ 迁移点 8：block_size 选择 64 的倍数
    // CUDA 中 block_size=256 常见
    // HIP 中 256 也是 64 的倍数，无需修改
    prod_force_kernel<<<nloc, 256>>>(d_net, d_env, d_list, d_force,
                                     nloc, nnei, ndescrpt);
    HIP_CHECK(hipGetLastError());
    HIP_CHECK(hipDeviceSynchronize());

    HIP_CHECK(hipMemcpy(h_force, d_force, size_force, hipMemcpyDeviceToHost));

    bool ok = false;
    for (int i = 0; i < nloc * 3; ++i) {
        if (fabs(h_force[i]) > 1e-6f) { ok = true; break; }
    }
    printf("HIP  prod_force: %s\n", ok ? "PASS" : "FAIL (all zeros)");
    printf("  First atom forces: fx=%f fy=%f fz=%f\n",
           h_force[0], h_force[1], h_force[2]);

    // ★ 迁移点 9：cudaFree → hipFree
    HIP_CHECK(hipFree(d_net));
    HIP_CHECK(hipFree(d_env));
    HIP_CHECK(hipFree(d_list));
    HIP_CHECK(hipFree(d_force));
    free(h_net); free(h_env); free(h_list); free(h_force);

    return 0;
}
