# DeePMD-kit 迁移分析 — AI4S 分子动力学

> 目标：理解 DeePMD-kit 项目结构，规划 CUDA→HIP 迁移策略。
> 职位：曙光 AI4S 迁移工程师
> 难度：⭐⭐⭐⭐（C++ custom op 多，依赖复杂）

---

## 1. 项目概况

DeePMD-kit 是深度分子动力学框架，用神经网络拟合原子间势能（DP potential）。

```
官网：https://github.com/deepmodeling/deepmd-kit
核心技术：Deep Potential — 用 DNN 学习原子间相互作用
应用场景：材料科学、药物设计、催化反应
```

### 1.1 和 LLM 推理的区别

| | LLM 推理（你已熟悉的） | DeePMD-kit（AI4S） |
|--|----------------------|-------------------|
| 核心计算 | Attention + FFN | 邻居搜索 + pair-wise 计算 + 对称性映射 |
| 数据 | token 序列 | 3D 原子坐标 |
| 计算模式 | 密集矩阵乘法 (GEMM) | 稀疏 + 不规则（每个原子邻居数不同） |
| 算子 | 少而通用 | 多而领域专用 |
| 网络结构 | Transformer | 嵌入网络 + 拟合网络 + 对称函数 (se_e2_a) |

### 1.2 项目结构

```
deepmd-kit/
├── deepmd/           # Python 前端
│   ├── model/        # 模型定义
│   ├── train/        # 训练逻辑
│   ├── infer/        # 推理（预测）模式
│   └── op/           # TensorFlow/PyTorch op 注册
├── source/
│   ├── lib/          # C++ 核心库（邻居搜索、矩阵计算）
│   └── op/           # C++ custom ops (TF + PyTorch)
│       ├── cu/       # CUDA kernel
│       └── hip/      # HIP kernel（已有部分）
├── CMakeLists.txt
└── setup.py
```

---

## 2. 需要迁移的 CUDA Kernel

### 2.1 核心 CUDA 文件

```
source/op/cu/
├── prod_force.cu     # 力的计算（最复杂！）
├── prod_virial.cu    # 压力张量
├── neighbor_list.cu  # 邻居搜索（不规则计算，GPU 上难优化）
├── euler_angle.cu    # 欧拉角计算
├── soft_min.cu       // 平滑最小函数 CUDA Kernel
├── tabulate.cu       // 查表计算
└── nlist.cu          # 邻居列表构建
```

### 2.2 迁移优先级

| 文件 | 复杂度 | 推理路径占比 | 迁移难度 | 建议优先 |
|------|--------|-------------|---------|---------|
| `prod_force.cu` | ⭐⭐⭐⭐⭐ | 60% | 高（复杂内存访问） | 第 1 个 |
| `prod_virial.cu` | ⭐⭐⭐⭐ | 20% | 中（类似 force） | 第 2 个 |
| `neighbor_list.cu` | ⭐⭐⭐⭐ | 15% | 高（不规则 + 原子操作） | 第 3 个 |
| `nlist.cu` | ⭐⭐⭐ | 5% | 中 | 第 4 个 |
| `euler_angle.cu` | ⭐⭐ | <1% | 低（纯数学计算） | 最后 |

### 2.3 prod_force kernel 分析

参考 [code/prod_force_cuda.cu](code/prod_force_cuda.cu) 和 [code/prod_force_hip.cpp](code/prod_force_hip.cpp) 获取可编译的对照示例。

```cuda
// prod_force 核心逻辑（简化）
// 计算每个原子受到的力
__global__ void prod_force_kernel(
    const float* net_deriv,     // [nframes, nloc, 4, ndescrpt]
    const float* env_deriv,     // [nframes, nloc, nnei, 3]
    const int*   nlist,         // 邻居列表
    const int*   type,          // 原子类型
    float*       force,         // 输出：力 [nframes, nloc, 3]
    int nloc, int nnei, int ndescrpt
) {
    // 对每个原子：
    //   1. 遍历邻居
    //   2. 从 net_deriv 和 env_deriv 计算力贡献
    //   3. 用原子操作累加到 force
    //   需要处理非规则邻居数，warp divergence 严重
    //
    // 迁移注意：
    //   1. atomicAdd 在 CUDA 和 HIP 中兼容
    //   2. 邻居遍历的循环边界检查
    //   3. 共享内存大小适配 DCU 的 LDS
}
```

---

## 3. 迁移要点

### 3.1 核心差异点

```
1. Warp = 32 → Wavefront = 64
   影响：warp-level 归约、shuffle 指令、block_size 选择
   参考: dcu_migration/wavefront_adapt.md

2. Tensor Core → 手工 Tile
   DeePMD-kit 没有用到 Tensor Core，所以影响不大
   但 GEMM 性能会直接用 rocBLAS 替代 cuBLAS

3. Atomic Operations
   atomicAdd 在 HIP 中兼容
   atomicAdd(double) 在 DCU 上需要确保硬件支持

4. Dynamic Shared Memory
   检查 DCU 上每个 CU 的 LDS 上限（64KB）
   CUDA 中 Shared Memory 最高可达 164KB（取决于配置）
```

### 3.2 CMake 迁移

```cmake
# CUDA 版本
find_package(CUDA REQUIRED)
cuda_add_library(deepmd_op_cu prod_force.cu neighbor_list.cu ...)

# HIP 版本
find_package(HIP REQUIRED)
hip_add_library(deepmd_op_hip_prod_force.cpp ...)
target_compile_definitions(deepmd_op_hip PRIVATE __HIP_PLATFORM_AMD__)
```

---

## 4. 验证方式

### 4.1 正确性验证

```python
import deepmd_kit

# CUDA 版本（NVIDIA GPU）
dp_cuda = deepmd_kit.DeepPot("graph.pb")
force_cuda = dp_cuda.eval(coord, cell, atype)

# HIP 版本（DCU）
# 推理结果应该一致（同输入、同模型权重）
# 浮点误差在 1e-4 以内可接受
```

### 4.2 性能验证

```bash
# 对比指标
# 1. 单步推理延迟（ms/step）
# 2. 每秒模拟的原子步数（atom-steps/s）
# 3. 最大 batch size

# profiler
rocprof --stats ./run_test
```

---

## 面试考点（曙光版）

| 知识点 | 级别 | 说明 |
|--------|------|------|
| DeePMD 执行流程 | ⭐⭐⭐ | 输入是 3D 坐标，输出是力和能量 |
| 邻居搜索的 GPU 实现 | ⭐⭐⭐⭐ | 不规则计算如何并行化 |
| prod_force 迁移 | ⭐⭐⭐⭐⭐ | 最复杂的 CUDA kernel 迁移 |
| 对称函数 (se_e2_a) | ⭐⭐⭐ | 嵌入网络的输入特征构造 |
