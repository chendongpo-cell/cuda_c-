# DeePMD-kit 迁移检查清单

## 代码示例

参考 [code/](code/) 目录中的对照示例：
- `prod_force_cuda.cu` — CUDA 原版 kernel
- `prod_force_hip.cpp` — HIP 移植版（标注 9 个迁移点）

## 文件级迁移进度

- [ ] `source/op/cu/prod_force.cu` → `source/op/hip/prod_force_hip.cpp`
  - atomicAdd 检查
  - 共享内存适配 LDS 64KB
  - block_size 改为 64 的倍数
- [ ] `source/op/cu/prod_virial.cu` → `source/op/hip/prod_virial_hip.cpp`
- [ ] `source/op/cu/neighbor_list.cu` → `source/op/hip/neighbor_list_hip.cpp`
- [ ] `source/op/cu/nlist.cu` → `source/op/hip/nlist_hip.cpp`
- [ ] `source/op/cu/euler_angle.cu` → `source/op/hip/euler_angle_hip.cpp`
- [ ] `source/op/cu/soft_min.cu` → `source/op/hip/soft_min_hip.cpp`
- [ ] `source/op/cu/tabulate.cu` → `source/op/hip/tabulate_hip.cpp`

## 构建系统

- [ ] CMakeLists.txt 添加 HIP 分支
- [ ] setup.py 添加 ROCm 编译选项
- [ ] 确认 rocBLAS 替代 cuBLAS

## 第三方依赖

- [ ] TensorFlow 的 ROCm 版本
- [ ] PyTorch 的 ROCm 版本
- [ ] LAMMPS + ROCm（分子动力学模拟器）

## 测试

- [ ] Python 接口：CUDA vs HIP 输出一致
- [ ] LAMMPS 中 DP 推理测试
- [ ] 性能对比：单步延迟、吞吐
