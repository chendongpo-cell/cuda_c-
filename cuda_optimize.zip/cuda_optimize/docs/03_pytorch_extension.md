# Week 3: PyTorch Custom Operators & 底层机制深入

> 本文档是推理优化学习路线图的第三周内容，聚焦 PyTorch 自定义算子开发与底层执行机制，为理解 vLLM/SGLang 中的高性能 CUDA kernel 打下基础。

---

## 目录

1. [PyTorch C++ Extension (pybind11)](#1-pytorch-c-extension-pybind11)
2. [PyTorch Autograd 机制深度剖析](#2-pytorch-autograd-机制深度剖析)
3. [torch.compile 完全理解](#3-torchcompile-完全理解)
4. [CUDA Stream/Event 异步执行模式](#4-cuda-streamevent-异步执行模式)
5. [Host-Device 数据传输优化](#5-host-device-数据传输优化)
6. [面试题](#6-面试题)

---

## 1. PyTorch C++ Extension (pybind11)

### 1.1 为什么需要 C++ Extension

PyTorch 提供了大量预定义算子，但在推理优化场景中，我们常常需要：

| 需求 | 原生 PyTorch | C++ Extension |
|------|-------------|---------------|
| 融合多个操作（Fusion） | 多次 kernel launch | 单次 custom kernel |
| 减少显存读写 | 临时 tensor 反复读写 | 寄存器直接传递 |
| 量化/稀疏算子 | 不支持 | 完全自定义 |
| 与 vLLM 集成 | 无法直接调用 | 通过 CUDA kernel 集成 |

**核心思想**：将多个计算步骤融合到一个 CUDA kernel 中，减少 global memory 访问次数和 kernel launch 开销。

### 1.2 pybind11 绑定机制

pybind11 是一个轻量级的 C++ 库，用于将 C++/CUDA 代码暴露为 Python 模块。

```
Python 调用
    │
    ▼
pybind11 bindings  ───►  C++ 包装函数
    │                           │
    ▼                           ▼
Python 对象                ATen Tensor (torch::Tensor)
(C++ 侧接收)               CUDA kernel 调用
```

### 1.3 完整的 fused ReLU + MatMul 示例

下面是一个完整的 fused ReLU + MatMul 自定义算子，包含：

1. **CUDA kernel** — 在 kernel 内部完成 ReLU 和矩阵乘法
2. **C++ wrapper** — 通过 pybind11 暴露给 Python
3. **Python 调用** — 像使用普通 PyTorch 函数一样使用

#### CUDA Kernel 编写 (relu_matmul_kernel.cu)

```cpp
// ============================================================
// 文件名: relu_matmul_kernel.cu
// 说明: fused ReLU + MatMul CUDA kernel
// 融合目的: ReLU 的输出不需要写回 global memory, 直接在寄存器中
//          传递给 MatMul, 减少一次 global memory 读写
// ============================================================

#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cuda_fp16.h>

// ------------------------------------------------------------
// 前向 kernel: fused ReLU + MatMul
// C = ReLU(A) @ B
// 其中 A 是输入, B 是权重, C 是输出
//
// 为什么融合: 通常的写法是 T = relu(A), C = T @ B,
//   这会导致 T 写回 global memory, 然后又被读出来。
//   融合后 T 留在寄存器/共享内存中, 直接参与矩阵乘法。
// ------------------------------------------------------------
__global__ void fused_relu_matmul_forward_kernel(
    const float* __restrict__ A,  // 输入矩阵 [M, K]
    const float* __restrict__ B,  // 权重矩阵 [K, N]
    float* __restrict__ C,        // 输出矩阵 [M, N]
    int M, int K, int N
) {
    // 计算当前线程负责的输出位置
    int row = blockIdx.y * blockDim.y + threadIdx.y;  // M 维度索引
    int col = blockIdx.x * blockDim.x + threadIdx.x;  // N 维度索引

    if (row < M && col < N) {
        float sum = 0.0f;
        // 内积循环: 每个线程计算输出矩阵中的一个元素
        for (int k = 0; k < K; ++k) {
            // 关键融合点: 在读取 A 之后立即应用 ReLU
            // 这样 A 的原始值从 global memory 读取一次,
            // ReLU 结果直接用于计算, 不需要写回
            float a_val = A[row * K + k];
            float relu_a = a_val > 0.0f ? a_val : 0.0f;  // fused ReLU
            sum += relu_a * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}

// ------------------------------------------------------------
// 反向 kernel: 计算融合算子的梯度
// 损失 L, 需要计算 dL/dA 和 dL/dB
//
// 数学推导:
//   C = ReLU(A) @ B
//   dL/dA = (dL/dC @ B^T) * ReLU'(A)
//   dL/dB = ReLU(A)^T @ dL/dC
//
// 其中 ReLU'(x) = 1 if x > 0 else 0 (阶梯函数)
// ------------------------------------------------------------

// 计算 dL/dA: dL/dC @ B^T, 再乘以 ReLU 的梯度
__global__ void fused_relu_matmul_backward_A_kernel(
    const float* __restrict__ dL_dC,  // 上游梯度 [M, N]
    const float* __restrict__ B,      // 权重 [K, N]
    const float* __restrict__ A,      // 原始输入 [M, K] (用于 ReLU 判断)
    float* __restrict__ dL_dA,        // 输出梯度 [M, K]
    int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < K) {
        float sum = 0.0f;
        for (int n = 0; n < N; ++n) {
            sum += dL_dC[row * N + n] * B[col * N + n];  // B^T: KxN -> NxK
        }
        // ReLU 的梯度: A[row, col] > 0 时梯度为 1, 否则为 0
        float relu_grad = A[row * K + col] > 0.0f ? 1.0f : 0.0f;
        dL_dA[row * K + col] = sum * relu_grad;
    }
}

// 计算 dL/dB: ReLU(A)^T @ dL/dC
__global__ void fused_relu_matmul_backward_B_kernel(
    const float* __restrict__ A,      // 输入 [M, K]
    const float* __restrict__ dL_dC,  // 上游梯度 [M, N]
    float* __restrict__ dL_dB,        // 输出梯度 [K, N]
    int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < K && col < N) {
        float sum = 0.0f;
        for (int m = 0; m < M; ++m) {
            // 读取 A 时再次应用 ReLU (因为反向时需要的是 ReLU(A) 而非原始 A)
            float a_val = A[m * K + row];
            float relu_a = a_val > 0.0f ? a_val : 0.0f;
            sum += relu_a * dL_dC[m * N + col];
        }
        dL_dB[row * N + col] = sum;
    }
}

// ------------------------------------------------------------
// C++ wrapper 函数: 供 pybind11 绑定
// ------------------------------------------------------------

// 前向包装: 接收 torch::Tensor, 返回 torch::Tensor
torch::Tensor fused_relu_matmul_forward(
    torch::Tensor A,    // [M, K]
    torch::Tensor B     // [K, N]
) {
    // 检查输入合法性
    TORCH_CHECK(A.device().is_cuda(), "A must be CUDA tensor");
    TORCH_CHECK(B.device().is_cuda(), "B must be CUDA tensor");
    TORCH_CHECK(A.dim() == 2 && B.dim() == 2, "Inputs must be 2D");
    TORCH_CHECK(A.size(1) == B.size(0), "Inner dimensions must match");

    int M = A.size(0);
    int K = A.size(1);
    int N = B.size(1);

    // 分配输出 tensor
    auto C = torch::empty({M, N}, A.options());

    // 设置 CUDA grid/block 维度
    // 典型的 2D 线程块: 16x16 = 256 线程
    dim3 block(16, 16);
    dim3 grid(
        (N + block.x - 1) / block.x,
        (M + block.y - 1) / block.y
    );

    // 启动 CUDA kernel (异步, 立即返回)
    fused_relu_matmul_forward_kernel<<<grid, block>>>(
        A.data_ptr<float>(),
        B.data_ptr<float>(),
        C.data_ptr<float>(),
        M, K, N
    );

    return C;
}

// 反向包装: 返回梯度元组 (dL_dA, dL_dB)
std::vector<torch::Tensor> fused_relu_matmul_backward(
    torch::Tensor A,      // 前向输入 [M, K]
    torch::Tensor B,      // 前向权重 [K, N]
    torch::Tensor dL_dC   // 上游梯度 [M, N]
) {
    int M = A.size(0);
    int K = A.size(1);
    int N = B.size(1);

    auto dL_dA = torch::empty({M, K}, A.options());
    auto dL_dB = torch::empty({K, N}, B.options());

    dim3 block(16, 16);
    dim3 grid_A(
        (K + block.x - 1) / block.x,
        (M + block.y - 1) / block.y
    );
    dim3 grid_B(
        (N + block.x - 1) / block.x,
        (K + block.y - 1) / block.y
    );

    fused_relu_matmul_backward_A_kernel<<<grid_A, block>>>(
        dL_dC.data_ptr<float>(),
        B.data_ptr<float>(),
        A.data_ptr<float>(),
        dL_dA.data_ptr<float>(),
        M, K, N
    );

    fused_relu_matmul_backward_B_kernel<<<grid_B, block>>>(
        A.data_ptr<float>(),
        dL_dC.data_ptr<float>(),
        dL_dB.data_ptr<float>(),
        M, K, N
    );

    return {dL_dA, dL_dB};
}

// ------------------------------------------------------------
// pybind11 绑定: 将 C++ 函数暴露为 Python 模块
// ------------------------------------------------------------
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &fused_relu_matmul_forward,
          "Fused ReLU + MatMul forward (CUDA)");
    m.def("backward", &fused_relu_matmul_backward,
          "Fused ReLU + MatMul backward (CUDA)");
}
```

#### 编译安装 (setup.py)

```python
# ============================================================
# 文件名: setup.py
# 说明: 使用 PyTorch 的 C++ Extension 工具链编译 CUDA 代码
# ============================================================
from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name='fused_relu_matmul',
    ext_modules=[
        CUDAExtension(
            name='fused_relu_matmul',           # Python 导入名
            sources=['relu_matmul_kernel.cu'],   # CUDA 源文件
            # 编译参数
            extra_compile_args={
                'cxx': ['-O3'],                  # C++ 编译器优化级别
                'nvcc': [
                    '-O3',                       # CUDA 编译器优化级别
                    '--use_fast_math',           # 使用快速数学函数(精度略低但更快)
                    '-lineinfo',                 # 生成行信息用于 profiling
                ]
            }
        )
    ],
    cmdclass={
        'build_ext': BuildExtension  # PyTorch 提供的构建扩展
    }
)
```

编译命令:

```bash
# 编译 CUDA extension
python setup.py install

# 或者使用 JIT 模式 (无需预先编译)
# 见下方 JIT 示例
```

#### Python 调用

```python
# ============================================================
# 导入并使用编译好的 CUDA extension
# ============================================================
import torch
import fused_relu_matmul  # 编译好的 C++ 模块

# 创建测试数据
M, K, N = 1024, 768, 512
A = torch.randn(M, K, device='cuda')
B = torch.randn(K, N, device='cuda')

# 调用自定义 CUDA kernel
C_custom = fused_relu_matmul.forward(A, B)

# 验证结果: 等价于 torch.relu(A) @ B
C_ref = torch.relu(A) @ B
print(f"Max error: {(C_custom - C_ref).abs().max().item()}")
```

### 1.4 PyTorch JIT 编译模式

除了 setup.py 编译, PyTorch 还支持 JIT (Just-In-Time) 编译:

```python
# ============================================================
# JIT 编译: 运行时自动编译 CUDA 代码
# 优点: 无需预先安装, 适合开发和原型验证
# 缺点: 首次调用有编译延迟
# ============================================================
from torch.utils.cpp_extension import load_inline

# CUDA kernel 源码 (字符串形式)
cuda_source = """
__global__ void relu_kernel(float* x, int n) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        x[idx] = x[idx] > 0.0f ? x[idx] : 0.0f;
    }
}
"""

# C++ 包装代码
cpp_source = """
torch::Tensor relu_cuda(torch::Tensor x) {
    int n = x.numel();
    dim3 block(256);
    dim3 grid((n + 255) / 256);
    relu_kernel<<<grid, block>>>(x.data_ptr<float>(), n);
    return x;
}
"""

# JIT 编译
relu_cuda = load_inline(
    name='relu_jit',
    cpp_sources=cpp_source,
    cuda_sources=cuda_source,
    functions=['relu_cuda'],  # 需要暴露给 Python 的函数
    verbose=True
)

# 使用
x = torch.randn(1000, device='cuda')
relu_cuda.relu_cuda(x)
```

### 1.5 vLLM 中的实际应用模式

vLLM/SGLang 大量使用 Custom CUDA Kernel 来优化推理:

```python
# vLLM 中 fused attention 的调用模式示例
# 实际代码在 vllm/attention/ops/ 目录下

# 1. 预编译的 CUDA kernel 通过 setup.py 安装
# 2. Python 层调用封装函数
# 3. 使用 torch.autograd.Function 包装以支持自动求导

# 典型调用方式:
# from vllm._C import ops  # 编译好的 C extension
# ops.silu_and_mul(output, input)  # 融合 activation
# ops.rms_norm(output, input, weight, epsilon)  # fused norm
```

---

## 2. PyTorch Autograd 机制深度剖析

### 2.1 自动求导基本原理

PyTorch 的 autograd 通过记录所有张量操作构建一个**动态计算图** (DAG):

```
计算图构建 (前向):
  x ---> relu ---> t ---> matmul ---> y ---> loss ---> l
                       ↗
                      w

计算图反向传播:
  l ---> grad(l) ---> grad(y) ---> grad(w)
                         │
                         ▼
                      grad(t) ---> grad(x) (通过 ReLU 反向)
```

每个 `torch.Tensor` 包含:
- `.data` — 张量数据
- `.grad` — 梯度 (累积)
- `.grad_fn` — 指向产生该张量的 `Function` 节点
- `.requires_grad` — 是否需要梯度

### 2.2 torch.autograd.Function 详解

`Function` 是 autograd 的核心抽象, 允许自定义前向和反向传播:

```python
# ============================================================
# 自定义 autograd.Function 的完整生命周期
# ============================================================
import torch

class MyFusedOp(torch.autograd.Function):
    """
    自定义 autograd Function 的模板
    
    关键约定:
    1. forward() 是静态方法, ctx 是 context 对象
    2. backward() 接收 upstream gradient, 返回 downstream gradient
    3. forward() 的返回值数量 = backward() 的参数数量 (除 ctx 外)
    4. forward() 的参数数量 = backward() 的返回值数量 (除 ctx 外)
    """
    
    @staticmethod
    def forward(ctx, input, weight):
        """
        前向传播
        Args:
            ctx: context, 用于保存 backward 需要的中间变量
            input: 输入张量
            weight: 权重张量
        Returns:
            输出张量
        """
        # 保存反向传播需要的张量
        # 注意: 保存的 tensor 会在反向中使用, 需考虑显存占用
        ctx.save_for_backward(input, weight)
        
        # 实际计算: fused ReLU + MatMul
        output = torch.mm(torch.relu(input), weight)
        return output
    
    @staticmethod
    def backward(ctx, grad_output):
        """
        反向传播
        Args:
            ctx: context, 可通过 ctx.saved_tensors 获取保存的变量
            grad_output: 上游梯度 dL/d(output)
        Returns:
            每个 forward 输入对应的梯度 (None 表示不需要梯度)
        """
        # 获取前向保存的变量
        input, weight = ctx.saved_tensors
        
        # 计算梯度
        # dL/d(input) = dL/d(output) @ weight^T * relu'(input)
        grad_input = torch.mm(grad_output, weight.t()) * (input > 0).float()
        
        # dL/d(weight) = relu(input)^T @ dL/d(output)
        grad_weight = torch.mm(torch.relu(input).t(), grad_output)
        
        # 返回梯度 (顺序与 forward 参数一致)
        return grad_input, grad_weight


# 使用自定义 Function
input = torch.randn(64, 256, requires_grad=True, device='cuda')
weight = torch.randn(256, 128, requires_grad=True, device='cuda')

# 调用前向 (会记录计算图)
output = MyFusedOp.apply(input, weight)

# 反向传播
loss = output.sum()
loss.backward()

# 查看梯度
print(input.grad.shape)   # [64, 256]
print(weight.grad.shape)  # [256, 128]
```

### 2.3 custom_function 装饰器 (PyTorch 2.x+)

PyTorch 2.0+ 提供了更简洁的 `custom_function` 装饰器:

```python
from torch.autograd import FunctionCtx

@torch.library.custom_framework("my_ops", vender="my_library")
def fused_relu_matmul(input: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    """使用装饰器定义自定义操作, 自动处理 autograd"""
    ...

# 或者使用 torch.autograd.function.once_differentiable
```

### 2.4 梯度计算的内存管理

理解 autograd 的内存管理对推理优化很重要:

```python
# ============================================================
# autograd 内存管理机制
# ============================================================

# 1. 计算图默认在前向时构建, 反向后释放
x = torch.randn(100, 100, requires_grad=True)
y = x.sin().sum()
y.backward()  # 反向后, 中间节点的 grad_fn 被释放

# 2. retain_graph: 多次反向 (如 GAN 训练)
y.backward(retain_graph=True)  # 保留计算图
y.backward()                   # 第二次反向后释放

# 3. retain_grad: 保留中间变量的梯度
hidden = x.sin()
hidden.retain_grad()           # 强制保留 hidden.grad
y = hidden.sum()
y.backward()
print(hidden.grad)             # 可以访问

# 4. 推理阶段关闭梯度追踪以节省显存
with torch.no_grad():
    # 这里的所有操作不会构建计算图
    # 不保存中间变量, 大幅节省显存
    output = model(input)

# 5. 手动清除计算图
del y  # 释放计算图引用
torch.cuda.empty_cache()  # 清空缓存
```

### 2.5 vLLM 中的 autograd 使用模式

```python
# vLLM 推理时的重要优化: 所有 forward 都包装在 torch.no_grad() 中
# 因为推理不需要反向传播

# 实际上, vLLM 的模型 forward 函数:
# @torch.no_grad()  <-- 类级别或方法级别装饰
# def forward(self, input_ids, ...):
#     ...
#     return logits

# 这避免了: 1) 构建计算图 2) 保存中间变量 3) grad_fn 链
# 对长序列推理可节省数 GB 显存
```

---

## 3. torch.compile 完全理解

### 3.1 架构总览

`torch.compile` 是 PyTorch 2.x 引入的 JIT 编译框架, 通过三阶段流水线将 Python 代码编译为高效 GPU kernel:

```
Python 源码
    │
    ▼
┌─────────────────────────────────────┐
│  Stage 1: Graph Capture (图捕获)    │
│  工具: TorchDynamo                   │
│  原理: 使用 PEP 523 框架评估钩子     │
│        拦截 Python 字节码执行        │
│        将 eager mode 调用图转为 FX   │
│        Graph                        │
│  输出: FX Graph (计算图)             │
└──────────────┬──────────────────────┘
               ▼
┌─────────────────────────────────────┐
│  Stage 2: Graph Lowering (图降级)   │
│  工具: TorchInductor (默认)          │
│  备选: NVFuser, ONNX, XLA           │
│  原理: 将 FX Graph 降级为            │
│        特定后端的中间表示            │
│  输出: Triton IR / NVFuser IR       │
└──────────────┬──────────────────────┘
               ▼
┌─────────────────────────────────────┐
│  Stage 3: Code Generation (代码生成)│
│  工具: Triton / NVFuser              │
│  原理: 从 IR 生成 CUDA kernel 源码   │
│        调用 nvcc/ptxas 编译          │
│  输出: CUDA kernel (二进制)          │
└─────────────────────────────────────┘
```

### 3.2 TorchDynamo: 图捕获机制

TorchDynamo 是 torch.compile 的基石, 它的工作原理如下:

```python
# ============================================================
# TorchDynamo 图捕获原理演示
# ============================================================
import torch
import torch._dynamo as dynamo

def my_model(x, w):
    """一个简单的模型函数"""
    # Dynamo 会尝试捕获整个函数为一张图
    x = torch.relu(x)
    x = torch.mm(x, w)
    x = x * 0.5  # scale
    return x

# 演示 Dynamo 捕获了什么
def explain_capture():
    """
    Dynamo 通过以下步骤工作:
    
    1. 当 my_model 被编译后首次调用时, Dynamo 启动
    2. Dynamo 使用 PEP 523 的框架评估钩子
       → 每执行一行 Python 字节码, Dynamo 都会检查
    3. 它记录所有 PyTorch 操作到一个 FX Graph 中
    4. 遇到 "不支持的" 操作 (如控制流) 时:
       → Graph Break: 图在此处断裂
       → 断裂处之前的子图被编译
       → 断裂处之后的代码回退到 eager mode
    """
    pass

# 查看 Dynamo 捕获到的图
x = torch.randn(64, 256, device='cuda')
w = torch.randn(256, 128, device='cuda')

# 使用 explain 模式查看编译细节
compiled_fn = torch.compile(my_model, backend="inductor")
output = compiled_fn(x, w)

# 查看编译日志
# torch._dynamo.config.log_level = logging.DEBUG
# torch._dynamo.config.output_code = True
```

### 3.3 TorchInductor: Triton Kernel 生成

Inductor 是默认的后端, 将 FX Graph 降级为 Triton kernel:

```python
# ============================================================
# Inductor 生成的 Triton Kernel 示例
# 
# 对于 torch.relu(x) @ w, Inductor 可能会生成类似下面的
# Triton kernel, 自动完成 kernel fusion
# ============================================================

# 这是 Inductor 生成的 Triton 代码 (human readable 版本)
"""
@triton.jit
def fused_relu_matmul_kernel(
    A_ptr, B_ptr, C_ptr,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    '''Inductor 生成的 fused ReLU + MatMul Triton kernel'''
    
    pid = tl.program_id(0)
    num_pid_m = tl.cdiv(M, BLOCK_M)
    pid_m = pid // tl.cdiv(N, BLOCK_N)
    pid_n = pid % tl.cdiv(N, BLOCK_N)
    
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)
    
    A_ptrs = A_ptr + offs_m[:, None] * stride_am + offs_k[None, :] * stride_ak
    B_ptrs = B_ptr + offs_k[:, None] * stride_bk + offs_n[None, :] * stride_bn
    
    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    
    for k in range(0, K, BLOCK_K):
        a = tl.load(A_ptrs)
        # ReLU fused here (关键融合点)
        a = tl.where(a > 0, a, 0)
        b = tl.load(B_ptrs)
        accumulator = tl.dot(a, b, accumulator)
        A_ptrs += BLOCK_K * stride_ak
        B_ptrs += BLOCK_K * stride_bk
    
    C_ptrs = C_ptr + offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn
    tl.store(C_ptrs, accumulator)
"""

# 关键 insight: Inductor 自动发现了 ReLU + MatMul 的融合机会
# 并将它们合并到同一个 Triton kernel 中
# 这就是 "Compiler Fusion" 的核心
```

### 3.4 Graph Break 检测

当 torch.compile 遇到无法捕获的操作时, 会发生 Graph Break:

```python
# ============================================================
# Graph Break 检测与分析
# ============================================================
import torch
import torch._dynamo as dynamo

def function_with_breaks(x, w):
    """
    这个函数演示各种导致 Graph Break 的场景
    
    最佳实践: 尽量减少 graph break, 因为每个 break
    意味着一次额外的 kernel launch 和 Python 回退开销
    """
    # 第1段: 可捕获
    x = torch.relu(x)
    
    # ---- GRAPH BREAK 1: 控制流 ----
    # Dynamo 无法捕获 Python 原生控制流
    if x.sum() > 0:
        x = x * 2
    else:
        x = x * 3
    # ---- 图上界 ----
    
    # 第2段: 可捕获
    x = torch.mm(x, w)
    
    # ---- GRAPH BREAK 2: 外部函数调用 ----
    # Dynamo 默认不追踪非 torch 函数
    x = custom_python_func(x)
    # ---- 图上界 ----
    
    return x

def custom_python_func(x):
    """普通的 Python 函数, 会导致 graph break"""
    return x + 1

# 检查 graph break
def check_graph_breaks():
    """
    使用 torch.compile 的 verbose 模式查看 graph break
    
    运行:
        torch.compile(func, fullgraph=True)  # 要求无 graph break
        
        # 或者在调用时设置环境变量:
        # TORCH_COMPILE_DEBUG=1 python script.py
    """
    pass
```

### 3.5 torch.compile 性能分析

```python
# ============================================================
# torch.compile 性能分析
# ============================================================

# 常见 backend 对比:
backends = {
    "eager":     "原生 PyTorch, 无编译, 用于基准",
    "inductor":  "默认后端, 生成 Triton kernel, 通用优化",
    "cudagraphs": "CUDA Graphs, 消除 kernel launch 开销",
    "nvfuser":   "NVIDIA 编译器, 适合 training",
    "onnxrt":    "ONNX Runtime 后端",
    "ipex":      "Intel Extension for PyTorch",
}

# 性能调优参数
# torch.compile(..., options={
#     "max_autotune": True,        # 尝试所有 tile size 组合
#     "triton.cudagraphs": True,   # 叠加 CUDA Graphs
#     "epilogue_fusion": True,     # 融合 epilogue 操作
# })

# 常见问题:
# 1. 首次调用慢: 因为包含编译时间
# 2. 动态 shape 性能下降: 每次 shape 变化可能需要重新编译
#    → 使用 shape_padding 或 dynamic=True 参数
# 3. Graph break 过多: 检查代码是否有控制流 / 非 torch 调用
```

---

## 4. CUDA Stream/Event 异步执行模式

### 4.1 CUDA Stream 基本概念

CUDA Stream 是一个异步执行队列, 同一 stream 内的操作按序执行, 不同 stream 可以**并发**执行:

```
默认 Stream (Stream 0):
  Kernel_A ──► Kernel_B ──► Kernel_C
                                      (串行)

多 Stream:
  Stream 1:  Kernel_A ──► Kernel_C
  Stream 2:  Kernel_B ──► Kernel_D
                    (并发执行, 无依赖)
```

### 4.2 PyTorch CUDA Stream API

```python
# ============================================================
# PyTorch CUDA Stream 使用
# ============================================================
import torch

# 创建 stream (低优先级/高优先级)
default_stream = torch.cuda.current_stream()      # 默认 stream
s1 = torch.cuda.Stream()                           # 普通 stream
s2 = torch.cuda.Stream(priority=-1)                # 高优先级 stream

# 使用 stream
with torch.cuda.stream(s1):
    # 在此 context 中, 所有 CUDA 操作提交到 s1
    a = torch.randn(1000, 1000, device='cuda')
    b = torch.randn(1000, 1000, device='cuda')
    c = torch.mm(a, b)

# 等待 stream 完成
s1.synchronize()           # 阻塞 CPU 直至 s1 完成
torch.cuda.synchronize()   # 等待所有 stream

# 不同 stream 间的同步
# s1 上的操作需要等待 s2 的结果
event = torch.cuda.Event()
with torch.cuda.stream(s2):
    result = compute_on_stream2()
    event.record()  # 在 s2 中记录事件

with torch.cuda.stream(s1):
    s1.wait_event(event)      # s1 等待 s2 完成
    use_result(result)        # 安全使用 s2 的结果
```

### 4.3 Async Compute 与数据传输重叠

核心优化思路: **让 GPU 计算和 CPU->GPU 数据传输同时进行**:

```python
# ============================================================
# 计算与传输重叠模式
# ============================================================
import torch
import time

def compute_data_transfer_overlap():
    """
    使用多个 stream 实现计算和传输的并行:
    
    时间线 (无 overlap):
        CPU:  [准备数据]────[H2D 传输]────[GPU 计算]────[D2H 传输]────
        GPU:                 [H2D传输] [GPU计算] [D2H传输]
    
    时间线 (有 overlap):
        CPU:  [准备数据1] [准备数据2] [准备数据3] ...
              ┌─H2D1─┐ ┌─H2D2─┐ ┌─H2D3─┐
        GPU:  │      │ │      │ │      │
              └─Compute1┘ └─Compute2┘ └─Compute3┘
    """
    # 创建两个 stream
    compute_stream = torch.cuda.Stream()
    transfer_stream = torch.cuda.Stream()
    
    # 锁页内存 (pinned memory) 用于异步传输
    # 普通内存(pageable)不能用于异步 H2D 传输
    host_data = torch.randn(1000, 1000).pin_memory()
    gpu_data = torch.empty(1000, 1000, device='cuda')
    weights = torch.randn(1000, 1000, device='cuda')
    
    # 启动传输 (异步)
    with torch.cuda.stream(transfer_stream):
        # 从 CPU 异步拷贝到 GPU
        # 注意: 使用 non_blocking=True 实现异步传输
        gpu_data.copy_(host_data, non_blocking=True)
        # 在传输 stream 上记录事件
        transfer_done = torch.cuda.Event()
        transfer_done.record()
    
    # 计算 stream 等待传输完成
    with torch.cuda.stream(compute_stream):
        compute_stream.wait_event(transfer_done)
        # 进行计算 (此时传输已完成)
        output = torch.mm(gpu_data, weights)
    
    # 同步等待所有完成
    torch.cuda.synchronize()
```

### 4.4 CUDA Event 时序测量

```python
# ============================================================
# 使用 CUDA Event 精确测量 GPU 执行时间
# ============================================================

def measure_gpu_time():
    """
    CUDA Event 测量的是 GPU 端的实际执行时间,
    不包含 CPU 侧的 dispatch 开销
    """
    start_event = torch.cuda.Event(enable_timing=True)
    end_event = torch.cuda.Event(enable_timing=True)
    
    # 记录开始
    start_event.record()
    
    # 需要测量的操作
    a = torch.randn(4096, 4096, device='cuda')
    b = torch.randn(4096, 4096, device='cuda')
    c = torch.mm(a, b)
    
    # 记录结束
    end_event.record()
    
    # 等待完成
    torch.cuda.synchronize()
    
    # 计算时间 (毫秒)
    elapsed_ms = start_event.elapsed_time(end_event)
    print(f"GPU 时间: {elapsed_ms:.2f} ms")
    
    return elapsed_ms
```

### 4.5 vLLM 中的 Stream 使用

```python
# vLLM 在多 GPU 推理中广泛使用 CUDA Stream:
#
# 1. 每个 GPU 有独立的 compute stream
# 2. P2P (Peer-to-Peer) 通信使用专用 stream
# 3. 异步调度: 一个请求的计算与下一个请求的
#    数据传输通过不同 stream 重叠
#
# 关键代码位置 (vllm 源码中):
# - vllm/distributed/parallel_state.py
# - vllm/worker/model_runner.py
```

---

## 5. Host-Device 数据传输优化

### 5.1 数据传输瓶颈分析

对于推理系统, 数据传输往往是瓶颈:

| 传输方向 | 带宽 | 延迟 | 关键优化 |
|----------|------|------|----------|
| CPU → GPU (H2D) | PCIe 4.0 x16: ~32 GB/s | ~5-10 us | 异步传输, 锁页内存 |
| GPU → CPU (D2H) | 同 H2D | 同 H2D | 异步回传, 预取 |
| GPU → GPU (P2P) | NVLink: ~600 GB/s | ~1 us | 直接 P2P 访问 |
| GPU → GPU (跨节点) | InfiniBand: ~400 Gbps | ~1 us | NCCL 通信 |

### 5.2 锁页内存 (Pinned Memory)

```python
# ============================================================
# 锁页内存详解
# ============================================================

def pinned_memory_demo():
    """
    锁页内存 vs 普通内存:
    
    普通内存 (pageable):
        CPU 内存页可以被 OS 换出到磁盘
        GPU 传输时需要先拷贝到临时锁页缓冲区
        → 额外的拷贝开销
    
    锁页内存 (pinned):
        CPU 内存页锁定在物理内存中, 不会被换出
        GPU 可以直接 DMA 访问
        → 更快的数据传输
        → 支持异步传输 (non_blocking=True)
    """
    
    # 创建锁页内存
    # 方法1: 直接创建
    pinned = torch.randn(1000, 1000).pin_memory()
    
    # 方法2: 从现有 tensor 转换
    regular = torch.randn(1000, 1000)
    pinned = regular.pin_memory()  # 返回新的 pinned tensor
    
    # 方法3: 使用 empty_pinned
    pinned = torch.empty(1000, 1000).pin_memory()
    
    # 异步传输 (需要 pinned memory)
    gpu_tensor = torch.empty(1000, 1000, device='cuda')
    
    # non_blocking=True: 立即返回, 传输在后台进行
    gpu_tensor.copy_(pinned, non_blocking=True)
    
    # 注意: 此时不能修改 pinned 的内容!
    # 需要显式同步:
    torch.cuda.synchronize()
    # 同步后才能安全地重用 pinned 内存

# 性能对比:
# 普通传输: ~12 GB/s (受限于 pageable 到 pinned 的拷贝)
# 锁页传输: ~25 GB/s (接近 PCIe 峰值)
# 异步锁页: ~25 GB/s + CPU 可以同时做其他工作
```

### 5.3 异步传输深入

```python
# ============================================================
# 异步传输完整示例
# ============================================================

def async_transfer_demo():
    """展示如何使用异步传输重叠计算与 I/O"""
    
    # 准备数据传输 pipeline
    num_batches = 10
    batch_size = 4096
    
    # 锁页内存池 (避免重复 pin/unpin)
    host_buffers = [
        torch.randn(batch_size, batch_size).pin_memory()
        for _ in range(2)  # 双缓冲: 传输用 buffer 0, 计算用 buffer 1
    ]
    gpu_buffers = [
        torch.empty(batch_size, batch_size, device='cuda')
        for _ in range(2)
    ]
    
    # 创建 stream
    transfer_stream = torch.cuda.Stream()
    compute_stream = torch.cuda.Stream()
    
    events = [torch.cuda.Event() for _ in range(2)]
    
    for i in range(num_batches):
        buf_idx = i % 2  # 双缓冲切换
        
        # Step 1: 异步传输当前 batch 到 GPU
        with torch.cuda.stream(transfer_stream):
            gpu_buffers[buf_idx].copy_(
                host_buffers[buf_idx], non_blocking=True
            )
            events[buf_idx].record()
        
        # Step 2: 在 compute stream 上等待传输完成
        with torch.cuda.stream(compute_stream):
            compute_stream.wait_event(events[buf_idx])
            # 前一个 batch 的计算结果已在 GPU 上
            # 当前 batch 也已传输完成
            result = torch.mm(gpu_buffers[buf_idx], 
                            gpu_buffers[buf_idx])
        
        # 实际 pipeline:
        # batch 0: 传输 → 计算
        # batch 1:          传输 → 计算
        # batch 2:                   传输 → 计算
        # 计算和传输完全重叠!
    
    torch.cuda.synchronize()
```

### 5.4 CUDA Graphs 消除传输开销

对于推理场景, CUDA Graphs 可以完全消除 kernel launch 和数据传输的开销:

```python
# ============================================================
# CUDA Graphs: 录制备份, 一次传输
# ============================================================

def cuda_graph_demo():
    """
    CUDA Graphs 工作原理:
    
    1. Capture 阶段:
       - 在 CUDA stream 上 "录制" 所有 kernel launch
       - 记录所有参数和数据指针
       - 生成一个 "graph" 对象
    
    2. Replay 阶段:
       - 一次调用执行整个 graph
       - 无 kernel launch 开销
       - 无数据传输开销 (数据指针已固定)
    
    适用场景:
       - 静态 shape 的推理 (LLM 中常用)
       - 反复执行相同计算图
    """
    
    # 锁页输入
    static_input = torch.randn(1, 512, 512, device='cuda')
    static_weight = torch.randn(512, 512, device='cuda')
    
    # 预热
    for _ in range(3):
        _ = torch.mm(static_input, static_weight)
    
    torch.cuda.synchronize()
    
    # 捕获 CUDA Graph
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        static_output = torch.mm(static_input, static_weight)
    
    # 后续执行只需 replay, 无 kernel launch 开销
    graph.replay()    # 微秒级
    graph.replay()    # 再次执行
    
    # vLLM 中的使用:
    # vLLM 在推理时对 transformer layer 使用 CUDA Graphs
    # 每个 layer 一个 graph, 在推理循环中 replay
    # 显著减少 kernel launch 开销 (对于小模型尤其明显)
```

### 5.5 推理引擎中的传输优化策略

```
┌─────────────────────────────────────────────┐
│ 推理引擎数据流优化策略                        │
├─────────────────────────────────────────────┤
│                                             │
│  请求到达                                    │
│    │                                         │
│  ┌─▼──────────┐     ┌──────────────────┐    │
│  │ Prefill     │────►│ 锁页内存池       │    │
│  │ (计算密集)   │     │ (避免重复分配)    │    │
│  └─────────────┘     └────────┬─────────┘    │
│                               │              │
│  ┌────────────────────────────▼─────────┐   │
│  │ CUDA Stream 1: H2D 传输 (请求数据)   │   │
│  │ CUDA Stream 2: GPU 计算 (decode)     │   │
│  │ CUDA Stream 3: D2H 传输 (输出结果)   │   │
│  └──────────────────────────────────────┘   │
│                                             │
│  关键优化点:                                 │
│  • 请求 Fix 大小 → 复用 CUDA Graph          │
│  • 预分配显存 → 避免 cudaMalloc 延迟         │
│  • KV Cache 预分配 → 避免增量分配            │
│  • async H2D → 计算与传输重叠                │
│                                             │
└─────────────────────────────────────────────┘
```

---

## 6. 面试题

### 6.1 PyTorch 自定义算子

**Q1**: 如何使用 PyTorch 的 C++ Extension 编写自定义 CUDA 算子?

<details>
<summary>答案</summary>

1. 编写 CUDA kernel 文件 (`.cu`)
2. 编写 pybind11 绑定的 C++ wrapper
3. 使用 `torch.utils.cpp_extension.CUDAExtension` 在 `setup.py` 中配置编译
4. 通过 `torch.autograd.Function` 包装以支持自动求导
</details>

**Q2**: 解释 `torch.autograd.Function` 的 forward 和 backward 方法的签名和约定。

<details>
<summary>答案</summary>

- `forward(ctx, *args)`: ctx 用于保存反向所需变量 (`save_for_backward`), 返回输出 tensor
- `backward(ctx, *grad_outputs)`: 接收上游梯度, 返回与 forward 参数对应的梯度 tuple
- forward 参数数量 = backward 返回值数量 (排除 ctx 和 grad_outputs)
</details>

**Q3**: 在自定义 CUDA kernel 中, 如何实现算子融合 (operator fusion)?

<details>
<summary>答案</summary>

在 kernel 内部合并多个计算步骤。例如 fused ReLU+MatMul:
- 在读取 A 矩阵元素后, 立即在寄存器中应用 ReLU
- 用 ReLU 结果直接参与矩阵乘法累加
- 避免了中间 tensor 的 global memory 读写
</details>

### 6.2 Autograd

**Q4**: PyTorch 的计算图在反向传播后如何释放内存? `retain_graph=True` 的作用是什么?

<details>
<summary>答案</summary>

反向传播遍历计算图, 释放中间节点的 grad_fn 和不需要的中间 tensor。`retain_graph=True` 保留计算图用于多次反向 (如 GAN 训练)。推理时使用 `torch.no_grad()` 完全避免构建计算图。
</details>

**Q5**: 解释 `torch.no_grad()` 和 `torch.set_grad_enabled(False)` 的区别。

<details>
<summary>答案</summary>

二者功能相同, 都禁用梯度计算。`no_grad()` 通常作为 context manager 或 decorator 使用; `set_grad_enabled()` 可以动态切换, 常用于训练/评估模式切换。
</details>

### 6.3 torch.compile

**Q6**: 什么是 Graph Break? 什么操作会导致 Graph Break?

<details>
<summary>答案</summary>

Graph Break 是 torch.compile 遇到无法捕获的操作时, 在计算图中产生的断裂点。常见原因:
- Python 控制流 (if/for/while)
- 非 PyTorch 函数调用
- `print()` 等 Python 原生操作
- 动态数据类型变化
</details>

**Q7**: `torch.compile` 的三个主要阶段是什么? 每个阶段的作用是什么?

<details>
<summary>答案</summary>

1. TorchDynamo (图捕获): 拦截 Python 字节码, 构建 FX Graph
2. TorchInductor (图降级): 将 FX Graph 转为 Triton IR
3. Triton (代码生成): 生成并编译 CUDA kernel
</details>

**Q8**: `torch.compile` 的 `dynamic=True` 参数作用是什么?

<details>
<summary>答案</summary>

允许动态 shape, 当输入的 tensor shape 变化时避免重新编译。代价是生成的 kernel 可能不如静态 shape 优化得彻底。适用于 LLM 推理等变长输入场景。
</details>

### 6.4 CUDA Stream

**Q9**: 什么是 CUDA Stream? 如何使用多个 stream 实现并发?

<details>
<summary>答案</summary>

CUDA Stream 是一个 GPU 操作队列。同一 stream 内的操作按序执行, 不同 stream 的操作可以并发。通过 `torch.cuda.Stream()` 创建, `with torch.cuda.stream(s):` 使用。
</details>

**Q10**: 如何实现 GPU 计算和 CPU-GPU 数据传输的重叠?

<details>
<summary>答案</summary>

1. 使用锁页内存 (`pin_memory()`)
2. 创建两个 CUDA stream: 传输 stream 和计算 stream
3. 传输 stream 执行 `copy_(non_blocking=True)`
4. 计算 stream 使用 `wait_event()` 等待传输完成
5. 使用双缓冲技术交替传输和计算
</details>

### 6.5 传输优化

**Q11**: 锁页内存 (pinned memory) 为什么能加速 GPU 数据传输?

<details>
<summary>答案</summary>

普通内存是可分页的, GPU 传输时需要先通过 CPU 拷贝到临时锁页缓冲区, 增加了额外拷贝。锁页内存固定在物理内存, GPU 可通过 DMA 直接访问, 减少一次拷贝, 且支持异步传输。
</details>

**Q12**: CUDA Graphs 是什么? 在推理中如何使用?

<details>
<summary>答案</summary>

CUDA Graphs 将一组 CUDA kernel launch "录制" 为 graph 对象, 后续可重复 "replay"。消除了多次 kernel launch 的 CPU 端开销。适用于静态 shape 的推理, vLLM 中使用它来加速每个 transformer layer。
</details>

### 6.6 综合题

**Q13**: 编写一个 PyTorch 自定义算子: fused silu + matmul 的前向和反向 (仅伪代码 + 核心逻辑)。

<details>
<summary>答案</summary>

```python
class SiluMatmul(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, w):
        # silu(x) = x * sigmoid(x)
        silu_x = x * torch.sigmoid(x)
        ctx.save_for_backward(x, w, silu_x)
        return torch.mm(silu_x, w)
    
    @staticmethod
    def backward(ctx, grad_output):
        x, w, silu_x = ctx.saved_tensors
        # dsilu/dx = sigmoid(x) * (1 + x * (1 - sigmoid(x)))
        sig_x = torch.sigmoid(x)
        dsilu = sig_x * (1 + x * (1 - sig_x))
        grad_x = torch.mm(grad_output, w.t()) * dsilu
        grad_w = torch.mm(silu_x.t(), grad_output)
        return grad_x, grad_w
```
</details>

**Q14**: 解释 vLLM 中 PagedAttention 使用 CUDA kernel 进行的内存优化。

<details>
<summary>答案</summary>

PagedAttention 使用自定义 CUDA kernel 实现:
1. KV cache 以 page (block) 为单位管理, 非连续显存
2. Attention kernel 通过 page table 间接访问 KV cache
3. 避免了 KV cache 的显存碎片和预留浪费
4. 通过 `fused_attention_kernel` 将 mask, softmax, matmul 融合
</details>

---

> **下一周预告: Week 4 — CUDA Memory Hierarchy 与 Kernel 性能调优**
> 深入学习: 共享内存优化,  bank conflict 避免,  occupancy 计算,  ncu profiling
