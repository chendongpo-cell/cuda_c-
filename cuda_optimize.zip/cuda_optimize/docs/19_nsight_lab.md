﻿# Nsight 实战 Lab — 端到端 Profiling

> 这是工具链实操文档。前 18 章都在讲"是什么"和"为什么"，这一章讲"怎么看到"。
>
> 学习定位：**学会用 Nsight Systems 和 Nsight Compute 分析真实推理瓶颈，能定位"是计算瓶颈还是访存瓶颈、哪个 kernel 慢、为什么慢"**。
>
> 前置知识：[02_cuda_basics.md](02_cuda_basics.md)、[09_flash_attention.md](09_flash_attention.md)。

---

## 0. 为什么要用 Profiler

你写了个 kernel 或部署了个模型，跑得慢。凭感觉猜：
- "是不是 batch 太小？" → 改大 batch，反而更慢
- "是不是没并行？" → 加 stream，没效果
- "是不是访存瓶颈？" → 改 shared memory，没变化

**不 profile 就是盲调**。Profiler 告诉你：
- 哪个 kernel 占了 80% 时间
- 这个 kernel 是计算瓶颈还是访存瓶颈
- 显存带宽利用率多少
- 算力利用率多少
- 是否有 warp stall，为什么 stall

**Profiler 是推理优化工程师的"X 光机"**。

---

## 1. NVIDIA 提供的两个核心工具

### 1.1 Nsight Systems（nsys）— 系统级时间线

**作用**：看整个程序的时间线，定位"哪个 kernel 占用最多时间"。

```
时间 →
[CPU] init  ──── launch kernel A ──── launch kernel B ──── ...
[GPU]            [==== kernel A ====][== kernel B ==]
                                          ↑
                                     这一段是瓶颈
```

特点：
- **粗粒度**：看程序整体，不看单 kernel 内部
- **看 CPU/GPU 异步**：CPU launch 是否过慢导致 GPU 闲
- **看 stream 并行**：多 stream 是否真的重叠
- 输出：`.nsys-rep` 文件，用 GUI 打开看时间线

### 1.2 Nsight Compute（ncu）— Kernel 级深度分析

**作用**：对**单个 kernel** 做深度分析，看它为什么慢。

特点：
- **细粒度**：单 kernel 的每个指标
- **roofline 模型**：算出你离理论上限有多远
- **stall 原因分析**：为什么 warp 在等
- 输出：`.ncu-rep` 文件，GUI 或命令行查看

### 1.3 何时用哪个

```
程序慢?
  ↓
用 nsys 跑一遍  →  找到最慢的几个 kernel
  ↓
用 ncu 分析这些 kernel  →  找到为什么慢
  ↓
针对性优化
  ↓
再用 nsys 验证优化效果
```

**先 nsys 后 ncu**：先找瓶颈 kernel，再深挖单个 kernel。直接 ncu 整个程序会跑几小时。

---

## 2. 环境准备

### 2.1 安装

CUDA Toolkit 自带 Nsight Systems 和 Nsight Compute，检查：

```bash
# 检查 nsys
which nsys
nsys --version

# 检查 ncu
which ncu
ncu --version
```

如果没装：
- Linux: 装 CUDA Toolkit 时勾选 Nsight
- Windows: 装 NVIDIA Nsight 独立安装包

### 2.2 GUI（强烈推荐）

命令行只看文本，GUI 看时间线直观得多。

- Linux: 在能 SSH 转发 X11 的环境跑 `nsys-ui` / `ncu-ui`
- Windows: 在本地装 Nsight Systems / Compute，把 `.nsys-rep` / `.ncu-rep` 下载到本地用 GUI 打开

**学习时强烈用 GUI**，时间线一眼能看出问题。

---

## 3. Lab 1: Nsight Systems 分析 vLLM 推理

### 3.1 启动 vLLM 并 profile

```bash
# 1. 启动 vllm 服务,加上 CUDA_LAUNCH_BLOCKING 让 profiling 更清晰
CUDA_LAUNCH_BLOCKING=0 vllm serve meta-llama/Llama-3-8B --port 8000 &

# 2. 等服务起来
sleep 60

# 3. 找到 vllm 进程的 PID
pid=$(pgrep -f "vllm serve" | head -1)

# 4. 用 nsys profile 这个进程,跑 30 秒
nsys profile \
    --output=vllm_profile \
    --duration=30 \
    --trace=cuda,nvtx,osrt,cudnn,cublas \
    --kill=none \
    --process=python:$pid \
    --wait=app

# 同时发请求触发推理
python benchmark_send_requests.py --num-prompts 50
```

说明：
- `--trace=cuda,nvtx,osrt,cudnn,cublas` 跟踪这些事件
- `--output=vllm_profile` 生成 `vllm_profile.nsys-rep`
- `--duration=30` 跑 30 秒就停

### 3.2 看时间线

把 `vllm_profile.nsys-rep` 下载到本地，用 Nsight Systems GUI 打开。

**关键观察点**：

1. **CUDA Kernel 时间线**
   - 哪个 kernel 反复出现？
   - 哪个 kernel 持续时间最长？
   - kernel 之间有没有空隙（GPU 闲着）？

2. **CUDA Stream**
   - 是否有多个 stream？
   - stream 之间的 kernel 是否真的并行？

3. **CPU 线程**
   - CPU launch kernel 的频率
   - 是否有 CPU 线程阻塞导致 GPU 闲

4. **Memory 操作**
   - `cudaMemcpy` 频率
   - H2D / D2H 传输大小

### 3.3 vLLM 典型时间线分析

正常情况下你会看到：
- 一串 `flash_attn` kernel（attention 计算）
- 中间夹着 `gemm` kernel（MLP / 投影）
- 高频出现的 `elementwise` kernel（reshape、add、layernorm）
- 偶尔的 `cudaMemcpy`（输出 token 拷回）

**异常模式**：
- **GPU 大段空白**：CPU 调度跟不上，需要优化 Python 调度或减少 kernel launch 开销
- **`cudaMemcpy` 太多**：可能 KV Cache 管理有问题，或 preemption 频繁
- **某个 kernel 持续时间长**：用 ncu 深入分析

### 3.4 NVTX 标记

vLLM 在关键位置加了 NVTX 标记，能在 nsys 时间线上看到带颜色的区域：
- "model_forward"
- "sampler"
- "prepare_inputs"

如果代码里没 NVTX，可以自己加：

```python
import torch
# 在你想测的代码段前后加 NVTX 标记
torch.cuda.nvtx.range_push("my_attention")
# ... 你的代码 ...
torch.cuda.nvtx.range_pop()
```

nsys 时间线上会显示这个区域，方便定位。

---

## 4. Lab 2: Nsight Compute 分析单个 kernel

### 4.1 准备一个简单 kernel

用 [03_cuda_kernels/matmul.cu](../03_cuda_kernels/matmul.cu) 的 matmul_tiled 作为例子。

### 4.2 用 ncu 分析

```bash
# 编译(确保带 -lineinfo)
cd 03_cuda_kernels/build
cmake .. -DCMAKE_CUDA_ARCHITECTURES="80"
cmake --build .

# 用 ncu 跑 matmul,分析所有 kernel
ncu --set full \
    --target-processes all \
    --import-source on \
    -o matmul_ncu \
    ./matmul
```

参数说明：
- `--set full`：收集所有指标（慢，但信息全）
- `--target-processes all`：跟踪所有进程
- `--import-source on`：把源码导入报告
- `-o matmul_ncu`：生成 `matmul_ncu.ncu-rep`

### 4.3 只分析特定 kernel

如果程序里有多个 kernel，用 `--kernel-name` 过滤：

```bash
ncu --set full \
    --kernel-name "matmul_tiled" \
    --launch-count 1 \
    --launch-skip 5 \
    -o matmul_tiled_ncu \
    ./matmul
```

- `--kernel-name "regex"`：只分析名字匹配的 kernel
- `--launch-skip 5`：跳过前 5 次调用（warmup）
- `--launch-count 1`：只分析 1 次

### 4.4 看 ncu 报告

GUI 打开 `matmul_ncu.ncu-rep`。关键指标：

#### 4.4.1 Roofline 图

X 轴：计算密度（FLOPs / Byte）
Y 轴：算力（FLOPs/s）

你的 kernel 会画成一个点，落在屋顶线下方。看它靠近：
- **左边的斜线**（memory-bound）：访存瓶颈
- **右边的水平线**（compute-bound）：算力瓶颈

#### 4.4.2 关键指标

| 指标 | 含义 | 经验阈值 |
|------|------|---------|
| Compute Throughput | 算力利用率 | > 60% 算 compute-bound |
| Memory Throughput | 显存带宽利用率 | > 60% 算 memory-bound |
| L2 Cache Hit Rate | L2 命中率 | 越高越好 |
| SM Occupancy | SM 占用率 | 50-100% 健康 |
| Warp Stall Reasons | warp 停滞原因 | 看分布 |

#### 4.4.3 Stall 原因

warp 停滞的常见原因：
- `Stall Long Scoreboard`：等显存（memory-bound）
- `Stall Short Scoreboard`：等 shared memory 或 L1
- `Stall Wait`：等固定功能单元
- `Stall Not Selected`：就绪但没被调度（资源不够）
- `Stall IMC Miss`：指令 cache miss（罕见）

如果 `Long Scoreboard` 占 60%+，说明访存是瓶颈 → 优化访存。
如果 `Not Selected` 占 30%+，说明 occupancy 低 → 调整 block size。

### 4.5 Source 视图

ncu 能把每个指标的"热点代码行"标出来：

```
matmul.cu:45   for (int k = 0; k < K; ++k) {
matmul.cu:46       sum += A[row*K + k] * B[k*N + col];  ← 80% 时间在这行
matmul.cu:47   }
```

直接定位到"哪一行慢"。

---

## 5. Lab 3: 分析 FlashAttention 为什么快

### 5.1 对比标准 Attention 和 FlashAttention

```python
# bench_attention.py
import torch
import torch.nn.functional as F

# 标准 attention
def standard_attention(q, k, v):
    scores = torch.matmul(q, k.transpose(-2, -1)) / (q.size(-1) ** 0.5)
    probs = F.softmax(scores, dim=-1)
    return torch.matmul(probs, v)

# Flash Attention (PyTorch 2.0+ 内置)
def flash_attention(q, k, v):
    return F.scaled_dot_product_attention(q, k, v)

q = torch.randn(1, 8, 4096, 64).cuda()
k = torch.randn(1, 8, 4096, 64).cuda()
v = torch.randn(1, 8, 4096, 64).cuda()

# Warmup
for _ in range(10):
    standard_attention(q, k, v)
    flash_attention(q, k, v)
torch.cuda.synchronize()

# Profile
with torch.profiler.profile(
    activities=[torch.profiler.ProfilerActivity.CUDA],
) as prof:
    for _ in range(100):
        standard_attention(q, k, v)
    torch.cuda.synchronize()
    for _ in range(100):
        flash_attention(q, k, v)
    torch.cuda.synchronize()

print(prof.key_averages().table(sort_by="cuda_time", row_limit=10))
```

### 5.2 跑 nsys 分析

```bash
nsys profile --output=attn_profile --trace=cuda,torch python bench_attention.py
```

打开 `attn_profile.nsys-rep`，对比：
- 标准 attention 有几个 kernel？（softmax + 2 个 gemm + 1 个 mul）
- Flash attention 有几个 kernel？（通常 1 个 `_flash_attention_forward`）
- 总耗时差多少？

### 5.3 ncu 对比

```bash
# 只分析 flash attention 的 kernel
ncu --set full --kernel-name "flash" -o flash_ncu python bench_attention.py
ncu --set full --kernel-name "softmax" -o softmax_ncu python bench_attention.py
```

对比两个 kernel 的：
- Memory Throughput（FA 应该更高，因为更充分用了显存带宽）
- Compute Throughput（FA 也应该更高）
- 临时显存使用（FA 应该几乎为 0）

---

## 6. Lab 4: 调试 GPU 闲置问题

### 6.1 现象

跑 vLLM 时 `nvidia-smi` 显示 GPU 利用率只有 60%，吞吐也低于预期。

### 6.2 nsys 时间线特征

```
[GPU]  [kernel][kernel]      [gap]      [kernel][kernel]      [gap]
                          ↑ 50ms 闲置  ↑                       ↑ 50ms 闲置
```

GPU 在 kernel 之间有明显空隙。

### 6.3 可能原因

1. **CPU 调度慢**：Python 解释器慢，launch kernel 之间卡顿
   - 验证：nsys 看 CPU 线程，是否有大段空闲
   - 修复：减少 Python 开销，用 C++ 重写调度路径

2. **同步等待**：`torch.cuda.synchronize()` 调用太频繁
   - 验证：nsys 看 `cudaDeviceSynchronize` 事件
   - 修复：减少同步，用 stream 异步

3. **数据传输**：H2D / D2H 阻塞
   - 验证：nsys 看 `cudaMemcpy` 是否阻塞 kernel
   - 修复：用 pinned memory + 异步 copy

4. **batch 调度问题**：continuous batching 调度间隔大
   - 验证：nsys 看"step"之间的间隔
   - 修复：调小调度间隔

### 6.4 案例：vLLM 的 step 调度

vLLM 每个调度 step：
1. 决定哪些请求进 batch
2. 准备 inputs
3. 调用 model forward
4. 采样
5. 更新 KV Cache

如果 step 之间间隔大（step 4-5 在 CPU 上跑），GPU 就闲着。vLLM V1 的优化就是把这个间隔缩短。

---

## 7. Lab 5: PyTorch Profiler（轻量级日常用）

如果不用 nsys/ncu 这么重，PyTorch 内置 profiler 日常够用：

```python
import torch.profiler

with torch.profiler.profile(
    activities=[
        torch.profiler.ProfilerActivity.CPU,
        torch.profiler.ProfilerActivity.CUDA,
    ],
    schedule=torch.profiler.schedule(
        wait=2,   # 前 2 步不算（warmup）
        warmup=2, # 接下来 2 步 warmup
        active=6, # 接下来 6 步真正记录
        repeat=1,
    ),
    on_trace_ready=torch.profiler.tensorboard_trace_handler('./log_dir'),
    record_shapes=True,
    profile_memory=True,
    with_stack=True,
) as prof:
    for _ in range(10):
        output = model(input)
        loss = loss_fn(output, target)
        loss.backward()
        prof.step()  # 必须调用
```

### 7.1 看结果

```bash
# 启动 tensorboard
tensorboard --logdir=./log_dir --port=6006
```

打开 `http://localhost:6006` 看 TensorBoard 的 PyTorch Profiler 插件。

### 7.2 关键视图

- **Overview**：CPU/CUDA 时间占比、GPU 利用率
- **Operator view**：每个算子的耗时
- **Kernel view**：每个 CUDA kernel 的耗时
- **Trace view**：时间线（类似 nsys）
- **Memory view**：显存增长曲线
- **Module view**：按 nn.Module 分组的耗时

日常开发用 PyTorch Profiler，深度调优再用 nsys/ncu。

---

## 8. 常见 Profiling 陷阱

### 8.1 没warmup

第一次调用 kernel 会触发编译、内存分配、cache miss，前几次都很慢。

**解决**：跑 5-10 次再开始 profile。

### 8.2 不同步

```python
# 错误: 没有 synchronize,profile 会捕捉不到
for _ in range(100):
    output = model(input)
# 正确:
torch.cuda.synchronize()
```

CUDA 是异步的，不 sync 可能 kernel 还在 queue 里。

### 8.3 Profile 影响性能

ncu `--set full` 会让 kernel 慢 10-100 倍。不要用 profile 数据算绝对时间，只用来找瓶颈。

### 8.4 看错指标

新手常只看"总时间"。但要看：
- **瓶颈 kernel 的时间占比**：80% 时间在哪个 kernel？
- **那个 kernel 的资源利用率**：是访存还是计算瓶颈？

### 8.5 优化过早

看到某 kernel 慢就立刻优化。但它可能只占总时间 5%，优化了没意义。

**先看占比，再优化最热的**。

---

## 9. 实战 checklist

定位推理慢的标准流程：

```
□ 1. nsys 跑一次,看时间线
□ 2. 找出占时间最多的 3 个 kernel
□ 3. ncu 分析这 3 个 kernel
□ 4. 看 roofline 图,判断 compute-bound 还是 memory-bound
□ 5. 看 stall reason,判断具体瓶颈
□ 6. 查 source view,定位慢的代码行
□ 7. 针对性优化
□ 8. nsys 再跑一次,验证优化效果
□ 9. 确认没有引入新瓶颈
```

**优化循环**：profile → 分析 → 优化 → 验证 → 再 profile。

---

## 10. 学习路径建议

1. **装好 Nsight Systems + Compute + GUI**
2. **跑 Lab 1**（vLLM nsys profile）→ 看懂时间线
3. **跑 Lab 2**（matmul ncu 分析）→ 理解各项指标
4. **跑 Lab 3**（对比标准 attention 和 FlashAttention）→ 看 FA 为什么快
5. **跑 Lab 4**（GPU 闲置诊断）→ 学会定位调度问题
6. **日常用 PyTorch Profiler** → 开发时快速 profile

---

## 11. 速查表

| 工具 | 用途 | 粒度 | 输出 |
|------|------|-----|------|
| `nvidia-smi` | 看显存、利用率、温度 | 粗 | 终端文本 |
| `nvidia-smi dmon` | 持续监控 | 中 | 终端滚动 |
| `nvprof` | 老工具，已被 nsys/ncu 取代 | - | - |
| `nsys` | 系统级时间线 | 粗 | .nsys-rep |
| `ncu` | 单 kernel 深度分析 | 细 | .ncu-rep |
| PyTorch Profiler | 日常开发 | 中 | TensorBoard |

| 指标 | 健康范围 | 异常处理 |
|------|---------|---------|
| GPU Utilization | > 80% | 查 CPU 调度、batch |
| SM Occupancy | 50-100% | 调 block size、寄存器使用 |
| Memory Throughput | > 60% | 已经接近带宽上限 |
| Compute Throughput | > 60% | 已经接近算力上限 |
| L2 Hit Rate | > 50% | 改访存模式 |
| Warp Stall (Long Sco) | < 30% | 访存瓶颈 |
| Warp Stall (Not Sel) | < 20% | occupancy 低 |
