# 第8周：SGLang 与推理框架对比 — 推理优化方向

> 目标：理解 SGLang 的核心技术创新（RadixAttention、前端编程模型），并与 vLLM 做架构性对比，形成对推理框架设计空间的全面认识。
> 预计时间：周均 7h（每天 ~1h）

---

## 目录

1. [SGLang 整体架构](#1-sglang-整体架构)
2. [RadixAttention 原理](#2-radixattention-原理)
3. [Frontend: SGLang 编程语言](#3-frontend-sglang-编程语言)
4. [vLLM vs SGLang 架构对比](#4-vllm-vs-sglang-架构对比)
5. [推理框架设计空间总结](#5-推理框架设计空间总结)
6. [面试考点](#6-面试考点)

---

## 1. SGLang 整体架构

### 1.1 核心理念

SGLang = **S**tructured **G**eneration **Lang**uage

SGLang 认为 LLM 推理不仅仅是"文本生成"，而是"程序执行"。
前端编程语言 + 后端运行时 + 高效调度。

```
用户编写 .sgl 程序
    │
    ▼
SGLang 编译器
    │
    ▼
SGLang Runtime (SRT)
    ├── RadixAttention    ← 核心注意力/缓存管理
    ├── Scheduler         ← 调度器
    ├── Model Executor    ← 模型执行
    └── Tokenizer/Detokenizer
```

### 1.2 与 vLLM 的关键区别

| 维度 | vLLM | SGLang |
|------|------|--------|
| 设计哲学 | 提供标准 LLM API | 提供编程语言 + 优化运行时 |
| 前端 | OpenAI API / Python SDK | 自定义 .sgl 编程语言 |
| 缓存管理 | Prefix Caching（content hash） | **RadixAttention**（前缀树） |
| 调度 | Prefill/Decode 分离或混合 | 统一调度（所有请求做同一个 attention） |
| Attention | FlashAttention + PagedAttention | RadixAttention（树形 KV cache） |
| 路由 | 每个请求独立 | 共享 prompt KV cache 更高效 |
| 多模态 | 通过 VLM 后端支持 | 原生支持 |
| 开源时间 | 2023.06 | 2024.01 |

---

## 2. RadixAttention 原理

### 2.1 问题：前缀匹配不够灵活

vLLM 的 Prefix Caching 只能匹配**完全一致**的前缀。

```
请求 A: "What is the capital of France?"
请求 B: "What is the capital of Germany?"
            ↑ 前缀完全匹配到"capital of" → 可共享
                但后续路径不同，只能共享前缀

请求 C: "What is the capital of France? Berlin"（之前生成的）
请求 D: "What is the capital of"（还在打字）
            ↑ 前缀匹配 → 可共享
                但 D 要生成新的，C 以后可能被"编辑"修改
```

问题：**系统的 prompt、few-shot examples 形成的是一棵树，不是一条线**。

### 2.2 RadixAttention 的解决方案

RadixAttention 使用**前缀树（Trie / Radix Tree）**来管理 KV cache。

```
                     Root
                      │
              "What is the"
              /           \
     "capital of"    "weather in"
        /      \           │
    "France?" "Germany?" "Tokyo?"
       │         │          │
   "Paris"    "Berlin"   "Cloudy"
```

```
前缀树中每个节点 = 一个 KV cache block

共享路径：
  "What is the capital of" → 所有以这个前缀开头的请求共享 KV cache

新增路径：
  请求 D: "What is the capital of Japan?"
    → 共享 "What is the capital of"
    → 在 "capital of" 节点下新增 "Japan?" 分支
    → 只需要计算 "Japan?" 的 KV cache！

Reuse 策略：
  LRU (Least Recently Used) 淘汰
  最近最少使用的前缀路径被优先淘汰
```

### 2.3 实现细节

```python
class RadixNode:
    """前缀树节点"""
    def __init__(self):
        self.children: Dict[int, "RadixNode"] = {}
        # 这个节点对应的 token 序列（前缀）
        self.tokens: List[int] = []
        # 这个前缀对应的 KV cache（GPU 指针）
        self.kv_cache: Optional[KVCache] = None
        # 最后使用时间（LRU 淘汰）
        self.last_access_time: float = 0.0
        # 引用计数（多少请求在使用这个节点）
        self.ref_count: int = 0

class RadixAttention:
    """RadixAttention 管理器"""
    def __init__(self):
        self.root = RadixNode()

    def match_prefix(self, tokens: List[int]):
        """
        在树上匹配最长前缀

        返回匹配的节点路径和未匹配的剩余 tokens
        """
        node = self.root
        matched_tokens = []
        while node and matched_tokens < len(tokens):
            # 检查子节点是否有匹配的 token
            next_token = tokens[len(matched_tokens)]
            if next_token in node.children:
                child = node.children[next_token]
                # 检查 child 的完整 token 序列
                match_len = min(
                    len(child.tokens),
                    len(tokens) - len(matched_tokens)
                )
                # 确认所有 token 都匹配
                if child.tokens[:match_len] == tokens[-match_len:]:
                    node = child
                    matched_tokens += child.tokens[:match_len]
                else:
                    break
            else:
                break

        remaining = tokens[len(matched_tokens):]
        return node, remaining, matched_tokens

    def insert(self, tokens: List[int], kv_cache: KVCache):
        """将新路径插入前缀树"""
        node, remaining, _ = self.match_prefix(tokens)
        if remaining:
            # 在 node 下创建新节点
            new_node = RadixNode()
            new_node.tokens = remaining
            new_node.kv_cache = kv_cache
            node.children[remaining[0]] = new_node

    def evict(self, num_tokens: int):
        """LRU 淘汰：释放最近最少使用的 num_tokens 的 KV cache"""
        # 找到最不常用的叶子节点
        candidates = self._find_leaf_nodes()
        candidates.sort(key=lambda n: n.last_access_time)
        for leaf in candidates:
            if num_tokens <= 0:
                break
            # 释放这个叶子的 KV cache
            num_freed = self._free_node(leaf)
            num_tokens -= num_freed
```

### 2.4 vLLM Prefix Caching vs RadixAttention

| 特性 | vLLM Prefix Caching | SGLang RadixAttention |
|------|---------------------|----------------------|
| 数据结构 | HashMap（content_hash → block） | Radix Tree（前缀树） |
| 匹配粒度 | 按 block（16 tokens）哈希 | 按 token 序列匹配 |
| 分支支持 | 不支持（只有线性前缀） | 支持多分支（树形结构） |
| 共享度 | 仅完全一致的前缀 | 任意公共前缀 |
| 淘汰策略 | 全局 LRU（block 级别） | 树上 LRU（节点级别） |
| 编辑支持 | 不支持 | 支持（树上增删改路径） |
| 实现复杂度 | 简单 | 复杂 |

**实际效果**：
- RadixAttention 在**共享前缀**的场景下比 Prefix Caching 多节省 20-40% 的 KV cache
- 在**最常见的 system prompt + few-shot** 场景优势明显
- 在**完全独立**的请求下效果相仿

---

## 3. Frontend: SGLang 编程语言

### 3.1 基本语法

```python
# .sgl 文件示例
# 一个简单的聊天程序

import sglang as sgl

@sgl.function
def chat(system_prompt, user_message):
    """
    SGLang 程序 = 标准的 Python 函数
    但推理调用被编译为优化执行计划
    """
    # 系统 prompt
    sgl.system(system_prompt)

    # 用户消息
    sgl.user(user_message)

    # Assistant 回复（流式生成）
    with sgl.gen("response", max_tokens=256) as resp:
        ...

    return resp.text()


# 调用
result = chat(
    system_prompt="You are a helpful assistant.",
    user_message="What is the capital of France?",
)
```

### 3.2 为什么需要 SGLang 语言？

```
传统方式（vLLM 的 OpenAI API）：
  发送 HTTP 请求 → 框架内部解析 → 调用模型 → 返回响应
  对 multi-turn / branching 不友好

SGLang 方式：
  把"推理逻辑"写成程序
  编译器可以：
  1. 分析依赖关系 → 并行执行独立部分
  2. 识别共享前缀 → RadixAttention 优化
  3. 计划 KV cache 重用 → 减少显存

示例：Branching（多分支探索）
  @sgl.function
  def explore(model, prompt):
      sgl.user(prompt)
      # 两个分支可以并行执行（共享 prompt 的 KV cache）
      with sgl.gen("branch1", max_tokens=100):
          pass
      with sgl.gen("branch2", max_tokens=100):
          pass
      # 比较两个分支的结果
      return {
          "branch1": branch1,
          "branch2": branch2,
      }
```

### 3.3 与 vLLM 的前端对比

```python
# vLLM 方式（OpenAI API 风格）
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8000/v1")

response = client.chat.completions.create(
    model="llama",
    messages=[
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "What is AI?"},
    ],
    max_tokens=100,
)

# 等价 SGLang 方式
@sgl.function
def answer(system_prompt, question):
    sgl.system(system_prompt)
    sgl.user(question)
    sgl.gen("answer")

state = answer.run(
    system_prompt="You are helpful.",
    question="What is AI?",
    max_new_tokens=100,
)
state["answer"]
```

---

## 4. vLLM vs SGLang 架构对比

### 4.1 整体对比表

| 维度 | vLLM | SGLang |
|------|------|--------|
| 创建时间 | 2023.06 (UC Berkeley) | 2024.01 (Stanford) |
| 核心作者 | Kwon et al. (PagedAttention) | Zheng et al. (RadixAttention) |
| GitHub Stars | 40k+ | 10k+ |
| 生态 | OpenAI API 兼容，生态最大 | sglang 原生语言 |
| 部署广度 | 最广泛（vLLM 几乎是标准） | 快速增长 |
| 推理优化 | PagedAttention + FlashInfer | RadixAttention + FlashInfer |
| 调度策略 | Prefill/Decode 分离（可混合） | Unified scheduling |
| LoRA 支持 | 原生支持 | 支持 |
| 量化 | AWQ/GPTQ/FP8 | AWQ/GPTQ/FP8 |
| 多模态 | 通过外部后端 | 原生 |
| 文档质量 | 好 | 较好 |

### 4.2 性能对比

```
Short prompts (< 512 tokens):
  vLLM: 通用的 PagedAttention，优化载入存储，速度稳定
  SGLang: RadixAttention 优势不大，两者接近，vLLM 略快 ~5%

Long prompts (> 4096 tokens + 高共享):
  vLLM: Prefix Caching 帮助有限（线性匹配）
  SGLang: RadixAttention 多分支匹配优势明显，快 20-50%

Multiple-turn conversation (高分支场景):
  SGLang 的 RadixAttention 能复用历史对话的 KV cache
  vLLM 必须每次都重新计算（因为前缀变了）
  SGLang 可快 2-3x

Benchmark 数据（LLaMA-7B, ShareGPT dataset）:
  vLLM:   ~2800 tokens/s 吞吐
  SGLang: ~3200 tokens/s 吞吐
  SGLang 在共享前缀多的场景提升更大
```

---

## 5. 推理框架设计空间总结

### 5.1 设计维度

```
1. 缓存管理
   ├── 无缓存（最原始）
   ├── 连续缓存（Contiguous Cache）
   ├── 分页缓存（Paged — vLLM）
   └── 前缀树缓存（Radix — SGLang）

2. 调度策略
   ├── Static Batching（传统）
   ├── Continuous Batching（vLLM/SGLang）
   ├── Chunked Prefill（LightLLM）
   └── SplitFuse（TensorRT-LLM）

3. Attention 实现
   ├── Vanilla Attention
   ├── FlashAttention-2/3
   ├── PagedAttention
   └── RadixAttention

4. Quantization
   ├── FP16（无量化）
   ├── FP8（H100 原生支持）
   ├── INT8 AWQ/GPTQ
   └── INT4

5. 执行模式
   ├── Eager（Pytorch eager mode）
   ├── Compiled（torch.compile）
   └── Custom CUDA kernels
```

### 5.2 框架选型建议

| 场景 | 推荐框架 | 原因 |
|------|---------|------|
| 生产部署、OpenAI 兼容 API | vLLM | 最成熟、生态最大 |
| 高共享前缀场景（SFT Chat） | SGLang | RadixAttention 优势 |
| 复杂推理逻辑、多分支 | SGLang | 编程语言模型 |
| LoRA 适配器批量部署 | vLLM | LoRA 支持最成熟 |
| 低延迟（单请求） | TensorRT-LLM | 最极致的优化 |
| 多 GPU 推理 | vLLM + TensorRT-LLM | 分布式兼容性好 |
| 学术研究、快速原型 | SGLang | 灵活性高 |

---

## 6. 面试考点

| 考点 | 重要度 | 说明 |
|------|--------|------|
| vLLM vs SGLang 核心区别 | ⭐⭐⭐ | 缓存管理策略 |
| RadixAttention 原理 | ⭐⭐⭐ | 前缀树 + KV cache 共享 |
| Prefix Caching vs RadixAttention | ⭐⭐⭐ | HashMap vs 前缀树 |
| SGLang 前端编程语言的设计目的 | ⭐⭐ | 编译优化 + 依赖分析 |
| 框架选型依据 | ⭐⭐ | 不同场景选哪个 |
| FlashInfer 的作用 | ⭐ | vLLM/SGLang 都使用的优化 kernel 库 |
| Chunked Prefill / SplitFuse | ⭐⭐ | 不考但值得了解 |

---

### 本周学习清单

```
Day 1-2: 阅读 SGLang 仓库结构，画架构图
Day 3-4: 部署 SGLang，编写一个 .sgl 程序
Day 5-6: 读 RadixAttention 源码（sglang/srt/）
Day 7: 写 vLLM vs SGLang 对比笔记（从 5 个维度）
```
