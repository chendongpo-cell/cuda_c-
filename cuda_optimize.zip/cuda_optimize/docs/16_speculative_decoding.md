# 投机解码（Speculative Decoding）详解

> 这是 2023-2026 推理加速最重要的"免费午餐"之一。代表方法：Speculative Decoding、Medusa、EAGLE、Lookahead Decoding。
>
> 学习定位：**理解为什么用小模型猜、大模型验，能在不损失精度的前提下让推理快 2-3 倍**。这是少数几个真正在工业界大规模落地的推理加速算法。
>
> 前置知识：[04_attention_kv_cache.md](04_attention_kv_cache.md) 的 decode 流程、[07_continuous_batching.md](07_continuous_batching.md) 的 batch 概念。

---

## 0. 一个直觉比喻

普通 decode 像写文章时**每写一个字都要查一次大字典**：
- 慢，但每个字都准确
- GPU 视角：每生成一个 token 要做一次完整的前向传播，GEMM 算力其实没吃满（decode 是访存密集）

投机解码像**让一个学徒先快速写一段草稿**，然后老师批改：
- 学徒写得快但可能错
- 老师只检查"对不对"，对的直接采纳，错的从错的地方重写
- 如果学徒准确率高，整体速度比老师逐字写快得多

**关键**：老师批改的成本 ≠ 重新写一遍。批改是"并行验证"，比逐字生成快。

---

## 1. 普通 Decode 的瓶颈

回忆 [04_attention_kv_cache.md](04_attention_kv_cache.md) 的 decode 过程：

```python
# 标准 decode 一次生成一个 token
def decode_one_token(model, tokens, kv_cache):
    # 1. 把最后一个 token 送进模型
    # 2. 前向传播：embedding + 多层 attention + MLP + LM head
    # 3. 取最后一个位置的 logits，argmax 或采样
    # 4. 把新 token 加到序列里，更新 KV Cache
    return new_token
```

**问题**：
- 每生成 1 个 token 要做一次完整前向（几十层）
- decode 阶段 batch=1（单用户）时，GEMM 形状是 `[1, hidden] @ [hidden, 4*hidden]`
- 这种"瘦长"的矩阵乘 **算力利用率极低**（5-20%）
- 但访存不少：要把所有权重从 HBM 读到 SRAM
- 所以 decode 是 **memory-bound**：被显存带宽限制，不是算力限制

**洞察**：decode 时算力其实闲着，能多算就多算 —— 投机解码就是利用这个"闲算力"。

---

## 2. Speculative Decoding 原始版本（Leviathan 2023 / Chen 2023）

### 2.1 核心流程

需要两个模型：
- **Target Model**：大模型，准确（如 Llama-70B）
- **Draft Model**：小模型，快（如 Llama-7B 或 1B）

```
步骤 1: Draft 模型自回归生成 k 个 token（草稿）
    [A, B, C]  →  Draft  →  [A, B, C, d1, d2, d3]
                              ^^^^^^^^^^^^^^^^^
                              草稿 3 个 token

步骤 2: Target 模型**一次前向**算出这 k+1 个位置的概率分布
    [A, B, C, d1, d2, d3]  →  Target  →  [p0, p1, p2, p3, p4, p5]
    注意：Target 一次前向就能算出所有位置的概率（并行）

步骤 3: 逐个验证
    位置 3: Target 说应该是 p3，Draft 说 d1
        如果 d1 在 p3 里被采样到 → 接受 d1，继续
        否则 → 拒绝，从 p3 重新采样一个 token 替代 d1
    位置 4: 同理
    ...

步骤 4: 遇到第一个拒绝的位置就停止，从那里开始新一轮投机
```

### 2.2 为什么能加速

- Draft 生成 k 个 token：k 次小模型前向（很快）
- Target 验证 k 个 token：**1 次大模型前向**（关键！）
- 大模型一次前向算 k 个位置 vs 普通 decode 算 k 次 = k 次大模型前向
- 即使加上 draft 的开销，只要接受率够高，整体快

**接受率**：草稿 token 被 Target 接受的比例。50-70% 是常见水平。

### 2.3 数学保证：为什么没有精度损失

这是投机解码最聪明的地方 —— **采样过程严格等价于直接用 Target 采样**。

对于每个位置 i：
- Draft 提议 token x，概率 q(x)
- Target 真实概率 p(x)
- 接受概率 = min(1, p(x) / q(x))

- 如果接受 x：保留 x
- 如果拒绝：从归一化后的 `max(0, p - q)` 分布重新采样

数学上可以证明：这样采出来的 token 跟直接从 p 采样**完全等价**（同样分布）。

所以**投机解码不损失精度，只是加速**。这是它能广泛落地的根本原因。

### 2.4 加速比公式

设：
- α = 接受率（draft 提议被接受的概率）
- k = 草稿长度
- τ = 大模型一次前向时间
- τ' = 小模型一次前向时间

每次"投机一轮"的期望生成长度：
```
E[生成长度] = (1 - α^(k+1)) / (1 - α)
```

当 α=0.5, k=4 时，期望生成 ≈ 1.94 个 token / 大模型一次前向。
相比普通 decode 1 token / 大模型一次前向，加速 ≈ 1.94 倍（扣除小模型开销后约 1.5-1.8 倍）。

α=0.7, k=4 时，期望 ≈ 3.3 个 token，加速 2-2.5 倍。

---

## 3. Medusa — 不要 Draft 模型，加多个头

### 3.1 动机

原始投机解码的痛点：
- 要训练一个单独的 draft 模型
- draft 模型也要部署，占显存
- draft 和 target 不共享权重，跨模型传 KV Cache 麻烦

### 3.2 Medusa 思路

**在大模型最后一层加多个"预测头"**，每个头预测未来第 i 个位置的 token。

```
原始 LM Head:    hidden → logits (预测下一个 token)
Medusa Head 1:   hidden → logits (预测下下个 token)
Medusa Head 2:   hidden → logits (预测下下下个 token)
...
Medusa Head k:   hidden → logits (预测第 k+1 个 token)
```

一次前向就能得到 k 个未来位置的候选。

### 3.3 Tree Attention — 并行验证多个候选

不同头可能预测多个候选，用树形结构组织：

```
位置 1: 候选 [A, B, C]    (top-3)
位置 2: 候选 [D, E, F]    (top-3)
位置 3: 候选 [G, H, I]    (top-3)

组合成树：3 × 3 × 3 = 27 条路径
并行验证所有路径 → 一次前向
接受最长合法前缀
```

vLLM/SGLang 都实现了 tree attention 的并行验证。

### 3.4 Medusa 的优势

- 不需要单独 draft 模型
- 共享 KV Cache
- 训练成本低（只训练几个新头，原模型冻结）
- 部署简单

代价：每个头要训练，且通常要做"典型接受"（typical acceptance）来简化采样。

---

## 4. EAGLE — 当前最强的投机方法

### 4.1 关键改进

Medusa 的头只看 hidden state，没用 token id 信息。EAGLE 的改进：
1. **输入**：把 hidden state + 上一个 token 的 embedding 一起喂进去
2. **结构**：用一个轻量 transformer 作为 draft，但**和 target 共享 embedding**
3. **自回归 + tree**：draft 模型也能自回归生成多步，再用 tree attention 验证

### 4.2 为什么 EAGLE 比 Medusa 快

- Medusa 的头是"独立预测"，越往后越不准
- EAGLE 的 draft 是真正的自回归，每步基于前一步，准确率高
- 论文报告接受长度 3-5，加速 3-5 倍

### 4.3 EAGLE-2 动态草稿树

EAGLE-1 用固定的树结构。EAGLE-2 根据上下文动态调整树的形状：
- 高置信度路径多扩展
- 低置信度路径剪枝
- 进一步提升接受率

---

## 5. Lookahead Decoding — 不需要 Draft 也不用训头

### 5.1 思路

完全不用额外的模型或头，**用大模型自己生成的 n-gram 历史做投机**。

```
当前生成到位置 t
查找过去生成内容里和当前 n-gram 匹配的位置
把匹配位置后面的 k 个 token 作为草稿
大模型自己验证
```

### 5.2 优势

- 零训练成本
- 纯算法，部署简单
- 对代码、重复文本特别有效

### 5.3 局限

- 对话场景下加速比不如 Medusa/EAGLE
- 依赖文本重复性

---

## 6. 工程实现要点

### 6.1 Tree Attention 的并行验证

最棘手的部分：一次前向验证多条候选路径。

**朴素做法**：每条路径单独前向 → 退化成普通 decode
**正确做法**：把所有候选拼成 batch，一次前向算完

```python
# 伪代码：3 条候选路径 [A,B,C], [A,B,D], [A,E,F]
# 树形结构，共享前缀
# 把树展开成 batch:
batch_tokens = [A, B, C, A, B, D, A, E, F]  # 9 个位置
batch_positions = [0, 1, 2, 0, 1, 2, 0, 1, 2]
batch_attention_mask = tree_causal_mask  # 树形因果 mask

logits = target_model(batch_tokens, batch_attention_mask, batch_positions)
# 一次前向得到所有位置的 logits
```

vLLM 实现了高效的 tree mask 构造和验证。

### 6.2 KV Cache 复用

草稿生成时也要写 KV Cache。如果 token 被接受，KV 保留；被拒绝，KV 要回滚。

实现：维护一个 "draft KV cache" 区和 "verified KV cache" 区，验证成功才合并。

### 6.3 Continuous Batching + Speculative

投机解码在 continuous batching 下的复杂度：
- 不同请求的草稿长度不同
- batch 内有些请求在投机，有些在普通 decode
- vLLM/SGLang 的处理：每步动态决定哪些请求投机、投机多长

---

## 7. PyTorch 简易实现（学习用）

下面是一个**纯教学**的最小投机解码实现，帮助你理解流程。真实系统会优化 100 倍。

```python
import torch
import torch.nn.functional as F

def speculative_decode_step(
    target_model,      # 大模型
    draft_model,       # 小模型
    input_ids,         # 当前已生成的 token [batch, seq_len]
    max_draft_len=4,   # 草稿长度 k
):
    """
    执行一轮投机解码,返回这轮生成的所有 token
    """
    batch_size = input_ids.shape[0]
    
    # ===== 第 1 步: Draft 模型生成 k 个草稿 token =====
    draft_tokens = []
    draft_probs = []
    
    # Draft 模型先做一次前向,拿到 KV Cache
    with torch.no_grad():
        draft_output = draft_model(input_ids, use_cache=True)
    draft_kv = draft_output.past_key_values
    last_logits = draft_output.logits[:, -1, :]  # [batch, vocab_size]
    
    # 采样第一个草稿 token
    draft_prob = F.softmax(last_logits, dim=-1)
    next_token = torch.multinomial(draft_prob, num_samples=1)  # [batch, 1]
    draft_tokens.append(next_token)
    draft_probs.append(draft_prob)
    
    # Draft 模型继续自回归生成剩下 k-1 个
    for _ in range(max_draft_len - 1):
        with torch.no_grad():
            draft_output = draft_model(
                next_token, past_key_values=draft_kv, use_cache=True
            )
        draft_kv = draft_output.past_key_values
        last_logits = draft_output.logits[:, -1, :]
        draft_prob = F.softmax(last_logits, dim=-1)
        next_token = torch.multinomial(draft_prob, num_samples=1)
        draft_tokens.append(next_token)
        draft_probs.append(draft_prob)
    
    # 整理草稿 token: [batch, k]
    draft_tokens = torch.cat(draft_tokens, dim=1)
    # draft_probs 是 list of [batch, vocab], 后面验证时用
    
    # ===== 第 2 步: Target 模型一次前向验证 k+1 个位置 =====
    # 把 input_ids 和 draft_tokens 拼起来,一次前向
    verify_input = torch.cat([input_ids, draft_tokens], dim=1)  # [batch, seq+k]
    
    with torch.no_grad():
        target_output = target_model(verify_input, use_cache=True)
    # 取最后 k+1 个位置的 logits
    # 位置 seq-1 是预测 draft_tokens[0] 的概率
    # 位置 seq 是预测 draft_tokens[1] 的概率
    # ...
    target_logits = target_output.logits[:, -max_draft_len-1:-1, :]  # [batch, k, vocab]
    target_probs = F.softmax(target_logits, dim=-1)
    
    # ===== 第 3 步: 逐个验证 =====
    accepted_tokens = []
    
    for i in range(max_draft_len):
        # Target 在位置 i 的概率
        p = target_probs[:, i, :]  # [batch, vocab]
        # Draft 在位置 i 提议的 token
        d = draft_tokens[:, i]  # [batch]
        # Draft 提议该 token 的概率
        q = draft_probs[i].gather(1, d.unsqueeze(1)).squeeze(1)  # [batch]
        # Target 真实概率
        p_d = p.gather(1, d.unsqueeze(1)).squeeze(1)  # [batch]
        
        # 接受概率 = min(1, p/q)
        accept_prob = torch.minimum(torch.ones_like(p_d), p_d / q)
        # 采样一个 [0,1) 的随机数,小于 accept_prob 就接受
        rand = torch.rand_like(accept_prob)
        accepted = rand < accept_prob  # [batch] bool
        
        # 对于接受的样本,保留 draft token
        # 对于拒绝的样本,从 (p - q) 归一化分布重新采样
        # 简化处理: 这里假设整个 batch 同步(真实系统是 per-sample)
        
        if accepted.all():
            accepted_tokens.append(d)
        else:
            accepted_tokens.append(torch.where(accepted, d, torch.zeros_like(d)))
            # 拒绝的位置从 target 重新采样
            reject_mask = ~accepted
            if reject_mask.any():
                # 修正分布: max(0, p - q),归一化
                corrected = torch.clamp(p - q.unsqueeze(1), min=0)
                corrected = corrected / corrected.sum(dim=-1, keepdim=True)
                new_token = torch.multinomial(corrected, num_samples=1).squeeze(1)
                # 在拒绝的位置用新 token 替换
                # ... (实现略)
            break  # 遇到第一个拒绝就停止
    
    return torch.cat(accepted_tokens, dim=1) if accepted_tokens else None
```

**注意**：上面是教学版，省略了大量边界情况（per-sample 处理、KV cache 回滚、batch 异步等）。真实实现看 vLLM 的 `spec_decode_worker.py`。

---

## 8. 实际部署：vLLM 启用投机解码

### 8.1 vLLM 配置

```bash
# 用一个显式 draft 模型
vllm serve meta-llama/Llama-3-70B \
    --speculative-model meta-llama/Llama-3-1B \
    --num-speculative-tokens 5

# 用 EAGLE (需要适配的权重)
vllm serve meta-llama/Llama-3-8B \
    --speculative-model "[eagle] meta-llama/Llama-3-8B-Eagle-Leader"

# 用 Medusa
vllm serve lmsys/vicuna-7b-v1.3 \
    --speculative-model "medusa-vicuna-7b-1.3"
```

### 8.2 调参经验

| 参数 | 经验值 | 说明 |
|------|-------|------|
| `num_speculative_tokens` | 3-5 | 太小收益少，太大拒绝率高浪费 |
| Draft 模型大小 | Target 的 1/10-1/50 | 太小接受率低，太大变慢 |
| 接受率下限 | > 30% | 低于这个投机反而拖累 |

### 8.3 适用场景

- ✅ 短-中长度生成（对话、问答）
- ✅ Draft 与 Target 同源（同家族，接受率高）
- ❌ 超长 context（draft 也要处理长 context，开销大）
- ❌ 对延迟极敏感的流式场景（首 token 不受投机影响，只影响 decode）

---

## 9. 性能数据参考

来自各论文（仅供参考，实际看场景）：

| 方法 | 模型 | 加速比 | 接受长度 |
|------|------|-------|---------|
| 原始 Speculative | LLaMA-65B + 7B | 2.0x | ~2.5 |
| Medusa | Vicuna-7B | 2.3x | ~3.0 |
| EAGLE-1 | LLaMA-2-13B | 3.0x | ~3.8 |
| EAGLE-2 | LLaMA-2-13B | 3.7x | ~4.5 |
| Lookahead | LLaMA-2-7B (代码) | 1.8x | - |

---

## 10. 学习路径建议

按顺序学习：

1. **理解原始 Speculative Decoding 论文** (Leviathan 2023) → 数学基础
2. **手写简化版**（上面的 PyTorch 代码，跑通流程）
3. **读 Medusa 论文** → 理解 tree attention
4. **读 EAGLE 论文** → 理解为什么自回归 draft 更好
5. **跑 vLLM 的 spec decode demo** → 看真实系统的实现
6. **读 vLLM `spec_decode/` 源码** → 工程细节

---

## 11. 常见误区

1. **"投机解码损失精度"** — 错。数学上严格等价于 Target 直接采样。
2. **"Draft 越大越好"** — 错。Draft 大了接受率高但慢，存在最优值。
3. **"草稿越长越好"** — 错。草稿越长后段拒绝率越高，浪费算力。
4. **"所有场景都适合"** — 错。长 context 或流式首 token 不受益。
5. **"投机解码和量化互斥"** — 错。可以叠加，量化模型照样能做投机。

---

## 12. 延伸阅读

- Speculative Decoding 论文：Leviathan et al., 2023
- Medusa 论文：Cai et al., 2024
- EAGLE 论文：Li et al., 2024
- EAGLE-2 论文：2024
- Lookahead Decoding 论文：2023
- vLLM spec decode 文档：`https://docs.vllm.ai/en/latest/features/spec_decode.html`

---

## 13. 速查表

| 方法 | 需要 Draft 模型 | 需要训练 | 加速比 | 工程复杂度 |
|------|----------------|---------|-------|----------|
| Speculative Decoding | ✅ 单独模型 | ❌ | 1.5-2x | 中 |
| Medusa | ❌ 多头 | ✅ 训练头 | 2-2.5x | 中 |
| EAGLE | ❌ 轻量 draft | ✅ 训练 draft | 3-4x | 高 |
| Lookahead | ❌ | ❌ | 1.5-2x | 低 |
