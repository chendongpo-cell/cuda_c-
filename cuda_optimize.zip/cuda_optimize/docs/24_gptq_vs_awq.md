﻿# GPTQ vs AWQ 量化对比与部署

> GPTQ 是大模型量化的另一主流方案，和 AWQ 是竞争对手。代表模型：TheBloke 的 GPTQ 系列。
>
> 学习定位：**理解 GPTQ 的数学原理、和 AWQ 的核心区别、怎么用 vLLM 部署 GPTQ、选哪个**。
>
> 前置知识：[10_quantization.md](10_quantization.md)、[21_awq_deployment.md](21_awq_deployment.md)。

---

## 0. 一句话对比

| 维度 | GPTQ | AWQ |
|------|------|-----|
| 数学方法 | 二阶信息（Hessian） | 一阶信息（activation scale） |
| 校准数据量 | 128-1024 条 | 128-512 条 |
| 量化速度 | 慢（5-30 分钟/7B） | 快（2-10 分钟/7B） |
| 推理速度 | 快 | 快（略快于 GPTQ） |
| 精度 | 中-高 | 高 |
| 工程成熟度 | 高 | 高 |
| vLLM 支持 | ✅ | ✅ |

**结论先行**：两者差距很小，工业部署**任选其一**即可。AWQ 精度略好且量化快，GPTQ 生态更成熟。本节讲清楚两者的差异和怎么选。

---

## 1. GPTQ 原理

### 1.1 历史背景

GPTQ 来自 2022 年 Frantar et al. 的论文 "GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers"。基于更早的 OBQ（Optimal Brain Quantization）工作。

### 1.2 核心思想：用二阶信息指导量化

朴素量化：每个权重独立量化到 INT4，不考虑其他权重的影响。

GPTQ 的洞察：**量化一个权重会影响其他权重的输出**。如果量化 W[i,j] 引起输出误差，可以通过微调其他权重来补偿。

数学上：
- 用 Hessian 矩阵 H 描述"权重对输出的敏感度"
- 量化时按列处理，每量化一列就用 H 信息更新剩余权重，补偿误差

### 1.3 算法细节

#### 1.3.1 Hessian 计算

对于一个线性层 `Y = X @ W`：
- X 是输入（校准数据跑出来的激活）
- W 是权重 `[in, out]`
- Hessian H = 2 * X^T @ X（形状 `[in, in]`）

H 的对角线表示每个输入通道的"重要性"，非对角线表示通道之间的相关性。

#### 1.3.2 逐列量化 + 误差补偿

```python
# 伪代码: GPTQ 核心算法
def gptq_quantize(W, H, group_size=128):
    """
    W: [in, out] 权重
    H: [in, in] Hessian
    """
    Q = W.clone()  # 量化后的权重
    Err = torch.zeros_like(W)
    
    # 按列处理 (in 维度)
    for i in range(0, in_dim, group_size):
        # 1. 取一组列
        indices = list(range(i, min(i + group_size, in_dim)))
        
        # 2. 对这组列量化
        for j in indices:
            # 计算 quantization step
            q = quantize_column(Q[j], scales[j])
            Q[j] = q
            
            # 3. 计算量化误差
            err = (Q[j] - W[j]) / H[j, j]
            
            # 4. 把误差"摊"到剩余未量化的列上
            for k in range(j+1, in_dim):
                Q[k] -= err * H[j, k]
            
            # 5. 更新 Hessian (减去已处理的行列)
            # ... (具体见论文)
    
    return Q
```

**关键点**：每量化一个权重，就用 Hessian 信息更新剩余权重，让它们"补偿"量化误差。这是 GPTQ 比朴素量化精度高的根本原因。

### 1.4 Cholesky 分解

直接用 Hessian 数值不稳定（小特征值导致除零）。GPTQ 用 Cholesky 分解稳定化：

```
H = L @ L^T  (L 是下三角)
用 L 替代 H 参与计算
```

这是 GPTQ 论文的关键工程贡献之一。

---

## 2. AWQ vs GPTQ 数学对比

### 2.1 优化目标不同

**GPTQ**：
- 直接最小化输出误差 `||X @ W - X @ Q||^2`
- 用二阶 Hessian 信息指导
- 是"反向传播式"的迭代优化

**AWQ**：
- 找出"重要"权重通道（基于 activation）
- 给重要通道一个 scale，让它们相对值变大
- 是"前向传播式"的一次性 scale + 量化

### 2.2 计算复杂度

| 步骤 | GPTQ | AWQ |
|------|------|-----|
| 校准前向 | 1 次 | 1 次 |
| Hessian 计算 | ✅ O(in^2 × out) | ❌ |
| Scale 搜索 | ❌ | ✅ 网格搜索 |
| 量化迭代 | O(in × out × group) | O(in × out) |

GPTQ 的 Hessian 计算和迭代量化比 AWQ 重。

### 2.3 精度对比（Llama-2-7B，INT4）

| 基准 | FP16 | GPTQ | AWQ |
|------|------|------|-----|
| MMLU | 45.3 | 44.5 | 44.8 |
| Wikitext PPL | 7.2 | 7.5 | 7.4 |
| HellaSwag | 77.1 | 76.5 | 76.8 |

差距很小（<1%），都在可接受范围。

### 2.4 推理速度对比

vLLM 在 A100 上的实测：

| 模型 | 量化 | 吞吐 (tok/s) | 显存 |
|------|-----|-------------|------|
| Llama-3-8B | FP16 | 2000 | 16 GB |
| Llama-3-8B | GPTQ | 3300 | 5.5 GB |
| Llama-3-8B | AWQ | 3500 | 5 GB |

两者速度接近，AWQ 略快（kernel 优化更好）。

---

## 3. GPTQ 量化模型部署

### 3.1 现成 GPTQ 模型

HuggingFace 上有大量现成 GPTQ 模型，比如：
- `TheBloke/Llama-2-7B-Chat-GPTQ`
- `TheBloke/Mistral-7B-Instruct-v0.2-GPTQ`
- `Qwen/Qwen2-7B-Instruct-GPTQ-Int4`

### 3.2 vLLM 启动 GPTQ

```bash
vllm serve TheBloke/Llama-2-7B-Chat-GPTQ \
    --quantization gptq \
    --port 8000
```

vLLM 会自动读取 `quantize_config.json` 选对应 kernel。

### 3.3 GPTQ 配置文件

```json
{
  "bits": 4,
  "group_size": 128,
  "damp_percent": 0.01,
  "desc_act": false,
  "static_groups": false,
  "sym": true,
  "true_sequential": true,
  "model_name_or_path": "...",
  "model_file_base_name": "model",
  "quant_method": "gptq"
}
```

关键参数：
- `bits`: 量化位数（4 是主流，3 也有）
- `group_size`: 分组大小（128 主流，越小精度越高）
- `desc_act`: 是否按 activation 大小降序处理列（精度高但慢）
- `sym`: 对称量化 vs 非对称

---

## 4. 自己用 GPTQ 量化模型

### 4.1 安装

```bash
pip install auto-gptq optimum
```

### 4.2 量化脚本

```python
"""
quantize_with_gptq.py — 用 AutoGPTQ 量化一个 HF 模型

输入: HuggingFace 模型路径
输出: GPTQ 量化后的模型,保存到本地
"""

from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
from transformers import AutoTokenizer
import torch

# ============ 配置 ============
MODEL_PATH = "meta-llama/Llama-3-8B"
OUTPUT_PATH = "./Llama-3-8B-GPTQ"

# GPTQ 量化配置
quant_config = BaseQuantizeConfig(
    bits=4,                # 4 bit 量化
    group_size=128,        # group 大小
    desc_act=False,        # 不按 activation 排序 (快, 精度略低)
    sym=True,              # 对称量化
)

# 校准数据
CALIB_DATA = [
    "The quick brown fox jumps over the lazy dog.",
    "In machine learning, gradient descent is...",
    # ... 通常 128-256 条
]

print(f"加载模型: {MODEL_PATH}")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)

# 准备校准样本 (tokenize)
calib_samples = []
for text in CALIB_DATA:
    calib_samples.append(tokenizer(text, return_tensors="pt"))

# 加载模型
model = AutoGPTQForCausalLM.from_pretrained(
    MODEL_PATH,
    quantize_config=quant_config,
    device_map="auto",
    torch_dtype=torch.float16,
)

print("开始 GPTQ 量化 (可能需要 10-30 分钟)...")
model.quantize(calib_samples)

print(f"保存量化模型到: {OUTPUT_PATH}")
model.save_quantized(OUTPUT_PATH, use_safetensors=True)
tokenizer.save_pretrained(OUTPUT_PATH)

print("GPTQ 量化完成!")
```

### 4.3 校准数据选择

和 AWQ 类似：
- 通用模型：WikiText / RedPajamas
- 领域模型：领域内文本
- 数量：128-256 条足够

GPTQ 对校准数据量更敏感（因为用二阶信息），多一些数据精度更好。

---

## 5. 对比 benchmark

下面是一个完整对比脚本，同时跑 GPTQ 和 AWQ：

```python
"""
gptq_vs_awq_deploy.py — GPTQ vs AWQ 对比部署脚本

配合 [docs/24_gptq_vs_awq.md](../docs/24_gptq_vs_awq.md) 使用。

用法:
    # 终端 1: 启动 GPTQ 服务
    vllm serve TheBloke/Llama-2-7B-Chat-GPTQ --quantization gptq --port 8000

    # 终端 2: 启动 AWQ 服务 (换端口)
    vllm serve TheBloke/Llama-2-7B-Chat-AWQ --quantization awq --port 8001

    # 终端 3: 跑对比
    python gptq_vs_awq_deploy.py
"""
# 详见 07_quantization/python/gptq_vs_awq_deploy.py
```

完整脚本见 [07_quantization/python/gptq_vs_awq_deploy.py](../07_quantization/python/gptq_vs_awq_deploy.py)。

---

## 6. 选型建议

### 6.1 选 GPTQ 的场景

- ✅ 团队已有 GPTQ 量化流水线
- ✅ 需要 INT3 等更激进量化
- ✅ 用 TheBloke 的现成模型（GPTQ 版本多）
- ✅ 团队对 Hessian 数学熟悉

### 6.2 选 AWQ 的场景

- ✅ 追求最佳精度
- ✅ 量化时间敏感（AWQ 快）
- ✅ 用 vLLM 部署（AWQ kernel 更优化）
- ✅ MoE 模型（AWQ 对 MoE 支持更好）

### 6.3 不要选量化的场景

- H100 / H200 部署 → 直接用 FP8，精度更高
- 模型本身很小（7B 以下）→ 量化收益不显著
- 对精度极敏感（医疗、法律）→ 用 FP16

### 6.4 量化 + 其他优化叠加

GPTQ/AWQ 可与以下优化叠加：
- ✅ Prefix Caching（互补）
- ✅ Continuous Batching（互补）
- ✅ Speculative Decoding（互补）
- ✅ TP / PP / EP（互补）
- ✅ KV Cache 量化（叠加省显存）

---

## 7. 常见误区

1. **"GPTQ 比 AWQ 慢"** — 不完全对。量化过程 GPTQ 慢，推理速度两者接近。
2. **"INT4 一定比 INT8 快"** — 错。算力瓶颈在小 batch 时是访存，INT4 优势在显存和带宽。
3. **"量化损失 1% 无所谓"** — 看场景。某些任务（数学、代码）对量化极敏感，可能损失 5-10%。
4. **"GPTQ 和 AWQ 可以互换权重"** — 错。量化方案不同，权重格式不同，不能互换。
5. **"group_size 越小越好"** — 错。group_size 小增加 scale 数量，占显存且增加访存。

---

## 8. 学习路径建议

1. **跑 AWQ 部署**（[21_awq_deployment.md](21_awq_deployment.md)）
2. **跑 GPTQ 部署**（本节）
3. **跑对比脚本**：[07_quantization/python/gptq_vs_awq_deploy.py](../07_quantization/python/gptq_vs_awq_deploy.py)
4. **读 GPTQ 论文** → 理解 Hessian 和误差补偿
5. **读 AWQ 论文** → 理解 activation-aware scale
6. **自己量化同一模型两次** → 对比精度

---

## 9. 延伸阅读

- GPTQ 论文：Frantar et al., 2022
- OBQ 论文（GPTQ 基础）
- AutoGPTQ: `https://github.com/AutoGPTQ/AutoGPTQ`
- vLLM 量化文档: `https://docs.vllm.ai/en/latest/quantization/`
- GPTQ vs AWQ 实测: `https://github.com/vllm-project/vllm/blob/main/docs/source/quantization/`

---

## 10. 速查表

| 项目 | GPTQ | AWQ |
|------|------|-----|
| 量化位数 | 3/4/8 | 4 |
| 数学方法 | Hessian 二阶 | Activation 一阶 |
| 量化时间 (7B) | 10-30 min | 2-10 min |
| 推理速度 | 快 | 略快 |
| 精度 | 中-高 | 高 |
| group_size | 128 | 128 |
| 校准数据 | 128-1024 | 128-512 |
| 工具 | AutoGPTQ | AutoAWQ |
| vLLM 支持 | ✅ | ✅ |
| SGLang 支持 | ✅ | ✅ |
| 适合 MoE | 一般 | 好 |
