# 第2周：CUDA 基础与 Kernel 编写 — 推理优化方向

> 目标：掌握 CUDA 编程模型核心概念，能手写简单的 CUDA kernel，理解 GPU 内存层次和性能优化基本方法。
> 预计时间：周均 7h（每天 ~1h）

---

## 目录

1. [CUDA 编程模型](#1-cuda-编程模型)
2. [内存层次与内存模型](#2-内存层次与内存模型)
3. [Kernel 编写实战](#3-kernel-编写实战)
4. [Shared Memory 优化](#4-shared-memory-优化)
5. [Nsight 性能分析](#5-nsight-性能分析)
6. [面试考点](#6-面试考点)
7. [配套实例与 Linux 命令](#7-配套实例与-linux-命令)

---

## 1. CUDA 编程模型

### 1.1 线程层次结构

```
Grid（网格）                    ← 一个 kernel launch
  └── Block（线程块）           ← 同一个 block 内的线程可以共享内存
       └── Warp（线程束）       ← 32 个线程为一组，SIMT 执行
            └── Thread（线程）  ← 最小的执行单元
```

**关键概念**：
- **Grid**：一个 CUDA kernel 启动时创建的所有线程集合
- **Block**：一组线程，共享 shared memory，可以同步（`__syncthreads()`）
- **Warp**：硬件级执行单元，32 个线程**同时执行同一指令**（SIMT 模型）
- **Thread**：最小的执行单元，每个线程有独立的寄存器、PC、local memory

**内置变量**：

| 变量 | 类型 | 说明 | 范围 |
|------|------|------|------|
| `gridDim` | dim3 | Grid 尺寸（block 数） | 用户指定 |
| `blockIdx` | uint3 | 当前 block 在 grid 中的索引 | [0, gridDim) |
| `blockDim` | dim3 | Block 尺寸（thread 数） | 用户指定 |
| `threadIdx` | uint3 | 当前 thread 在 block 中的索引 | [0, blockDim) |
| `warpSize` | int | warp 大小（始终为 32） | 固定值 |

**线程索引计算公式**（1D 到 3D）：

```cpp
// 1D 情况：最常用
int tid = blockIdx.x * blockDim.x + threadIdx.x;

// 2D 情况（常用于矩阵）
int row = blockIdx.y * blockDim.y + threadIdx.y;
int col = blockIdx.x * blockDim.x + threadIdx.x;

// 3D 情况（用于 3D 体积数据）
int x = blockIdx.x * blockDim.x + threadIdx.x;
int y = blockIdx.y * blockDim.y + threadIdx.y;
int z = blockIdx.z * blockDim.z + threadIdx.z;
```

### 1.2 SIMT 模型（Single Instruction, Multiple Threads）

SIMT 是 CUDA 执行的核心模型：**一个 warp 内的所有线程执行相同的指令**。

```
warp 0:  thread 0-31  同时执行 instruction A
warp 1:  thread 32-63 同时执行 instruction A
...
```

**Warp Divergence（线程束分歧）**：当 warp 内的线程走不同分支时，**所有分支串行执行**，不走的线程被 mask 屏蔽。

```cpp
// ⚠️ 坏的写法：warp 内分歧
if (threadIdx.x < 16) {
    // 线程 0-15 执行此分支
    result = a + b;
} else {
    // 线程 16-31 执行此分支（必须等前面分支完成）
    result = a - b;
}
// 两个分支串行，性能减半！

// ✅ 好的写法：不同 warp 走不同分支
if (blockIdx.x % 2 == 0) {
    // warp 0, 2, 4... 全部走此分支
    result = a + b;
} else {
    // warp 1, 3, 5... 全部走此分支
    result = a - b;
}
// 没有 warp divergence！
```

### 1.3 Kernel 声明与启动

**Kernel 声明**：

```cpp
// __global__：在 host 端调用，在 device 端执行
__global__ void my_kernel(float* data) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    data[tid] = data[tid] * 2.0f;
}

// __device__：在 device 端调用，在 device 端执行
__device__ float warp_reduce(float val) {
    // 供其他 __global__ 或 __device__ 函数调用
    return val;
}
```

**Kernel 启动语法**：

```cpp
// kernel<<<grid, block, shared_mem, stream>>>(args);
my_kernel<<<num_blocks, threads_per_block>>>(d_data kv;
my_kernel<<<num_blocks, threads_per_block, shared_mem_size>>>(d_data);  // 带动态 shared memory
my_kernel<<<num_blocks, threads_per_block, 0, stream>>>(d_data);       // 指定 stream
```

**Grid/Block 尺寸选择经验**：

```
threads_per_block: 128 或 256（通常最佳）
  - 太小（<64）：occupancy 低（SM 上活跃 warp 少）
  - 太大（>1024）：寄存器压力大，可能降低 occupancy
  - 最好是 32 的倍数（warp 大小）

num_blocks: 至少 GPU 上 SM 数量的 4~8 倍
  - 提供足够的"超额订阅"，隐藏内存延迟
  - 常见的 GPU 有 80~132 个 SM（如 A100: 108 SM）
```

### 1.4 CUDA API 基础

```cpp
// 显存管理
cudaMalloc(void** ptr, size_t size);        // GPU 显存分配
cudaFree(void* ptr);                         // GPU 显存释放
cudaMemcpy(void* dst, void* src, size_t count, cudaMemcpyKind kind);
    // kind: cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost, cudaMemcpyDeviceToDevice

// Stream（流）
cudaStream_t stream;
cudaStreamCreate(&stream);                   // 创建流
cudaStreamSynchronize(stream);               // 等待流中所有操作完成
cudaStreamDestroy(stream);                   // 销毁流

// Event（事件，用于计时/同步）
cudaEvent_t start, stop;
cudaEventCreate(&start);
cudaEventCreate(&stop);
cudaEventRecord(start, stream);              // 记录事件
kernel<<<grid, block, 0, stream>>>(args);
cudaEventRecord(stop, stream);
cudaEventSynchronize(stop);                  // 等待事件
float ms;
cudaEventElapsedTime(&ms, start, stop);      // 计算耗时

// 错误检查（非常重要！）
#define CUDA_CHECK(call) \
    do { \
        cudaError_t err = call; \
        if (err != cudaSuccess) { \
            fprintf(stderr, "CUDA error at %s:%d: %s\n", \
                __FILE__, __LINE__, cudaGetErrorString(err)); \
            exit(EXIT_FAILURE); \
        } \
    } while(0)
```

---

## 2. 内存层次与内存模型

### 2.1 GPU 内存层次

```
                       GPU 芯片
┌───────────────────────────────────────────────┐
│  SM 0            SM 1           SM ...        │
│  ┌──────┐       ┌──────┐       ┌──────┐      │
│  │Regs  │       │Regs  │       │Regs  │      │ ← 最快，~0.5TB/s per SM
│  │ 256KB│       │ 256KB│       │ 256KB│      │
│  ├──────┤       ├──────┤       ├──────┤      │
│  │L1/SM │       │L1/SM │       │L1/SM │      │ ← L1/Shared Memory 192KB
│  │      │       │      │       │      │      │
│  └──────┘       └──────┘       └──────┘      │
├───────────────────────────────────────────────┤
│               L2 Cache (40MB)                 │ ← ~2TB/s
├───────────────────────────────────────────────┤
│             HBM2/HBM3 (80GB)                  │ ← 显存，~2TB/s
│              Global Memory                     │   延迟 ~200-400 cycles
└───────────────────────────────────────────────┘
```

### 2.2 各种内存的对比

| 内存类型 | 作用域 | 生命周期 | 延迟 | 带宽 | 大小 |
|----------|--------|----------|------|------|------|
| **Register** | 单线程 | Kernel 内 | 0 cycles | ~48 PB/s | 256KB/SM |
| **Local Memory** | 单线程 | Kernel 内 | ~500 cycles | 同 Global | 同 Global |
| **Shared Memory** | 整个 Block | Kernel 内 | ~30 cycles | ~10 TB/s | 48~164KB/SM |
| **Global Memory** | 所有线程+Host | 整个程序 | ~400 cycles | ~2 TB/s | 80GB+ |
| **Constant Memory** | 所有线程+Host | 整个程序 | ~400 cycles（命中 cache 快） | 受限 | 64KB |
| **Texture Memory** | 所有线程+Host | 整个程序 | 有缓存加速 | 有缓存加速 | 同 Global |

### 2.3 Memory Coalescing（内存合并访问）

**最重要的性能优化原则**：相邻线程访问相邻地址。

```
✅ 合并访问（好的）：
Thread:    0  1  2  3  4  5  6  7  ...
Address:   0  4  8  12 16 20 24 28 ...
           ↑  单个 32 字节 cache line →  一次内存事务即可

❌ 非合并访问（坏的）：
Thread:    0  1  2  3  4  5  6  7  ...
Address:   0  100 200 300 ...（跨步访问）
           ↑  需要多个 cache line 事务，带宽利用率低
```

**矩阵转置的内存访问模式对比**：

```cpp
// ✅ 合并写入：按行写入（连续地址）
// 每个线程写一行中的一个元素
data[ row * cols + col ] = value;  // 相邻线程写相邻地址

// ❌ 列访问（非合并）：按列读取
data[ row + col * rows ] = value;  // 跨步 = rows * sizeof(T)，极大浪费带宽

// 解决方案：使用 shared memory 作为中转，做矩阵转置时先加载到共享内存再读取
```

---

## 3. Kernel 编写实战

### 3.1 Vector Add（最简单的 Kernel）

```cpp
// 每个线程计算一个元素的加法
__global__ void vector_add(const float* a, const float* b, float* c, int n) {
    // 计算当前线程的全局索引
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    
    // 边界检查：防止越界
    if (tid < n) {
        c[tid] = a[tid] + b[tid];
    }
}

// 调用
int n = 1 << 20;  // 1M 元素
int block_size = 256;
int grid_size = (n + block_size - 1) / block_size;  // 向上取整
vector_add<<<grid_size, block_size>>>(d_a, d_b, d_c, n);
```

### 3.2 Matrix Multiply（最简单的 2D Kernel）

```cpp
// C = A * B
// A: M×K, B: K×N, C: M×N
__global__ void matmul_naive(const float* A, const float* B, float* C,
                              int M, int N, int K) {
    // 每个线程计算 C[row][col] 一个元素
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    
    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}
```

### 3.3 Reduction（归约 — 推理场景的核心）

归约在推理引擎中的应用：
- **Attention 中的 Softmax**：需要求指数和（归约）
- **LayerNorm**：求均值和方差
- **Warp-level 归约**：FlashAttention 中 tiling 的核心操作

```cpp
// 树形归约：每个 block 归约一个数据块
// 第 1 轮：线程 0-127 归并，步长 = 1
// 第 2 轮：线程 0-63 归并，步长 = 2
// ...
// 第 7 轮：线程 0 得到最终结果
__global__ void reduce_sum(const float* input, float* output, int n) {
    extern __shared__ float sdata[];  // 动态 shared memory
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    int ltid = threadIdx.x;  // local thread id in block
    
    // 1. 加载数据到 shared memory
    sdata[ltid] = (tid < n) ? input[tid] : 0.0f;
    __syncthreads();  // 等待所有线程加载完成
    
    // 2. 树形归约（步长倍增）
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (ltid < s) {
            sdata[ltid] += sdata[ltid + s];
        }
        __syncthreads();  // 每次迭代后同步
    }
    
    // 3. block 0 的线程 0 写入结果
    if (ltid == 0) {
        output[blockIdx.x] = sdata[0];
    }
}
```

---

## 4. Shared Memory 优化

### 4.1 Shared Memory Bank Conflict

Shared memory 被分成 **32 个 bank**（32 位宽）。不同线程同时访问不同 bank 可以并行，但访问同一 bank 会串行化。

```
bank 0:  地址 0, 32, 64, 96, ...   (每 32 字节)
bank 1:  地址 4, 36, 68, 100, ...
...
bank 31: 地址 124, 156, ...

✅ 无冲突：每个线程访问不同的 bank
  thread 0→bank0, thread 1→bank1, ..., thread 31→bank31

❌ 2-way 冲突：两个线程访问同一 bank
  thread 0→bank0, thread 16→bank0 → 串行化（两次访问）

✅ 广播：所有线程访问同一地址 → 一次广播（无冲突）
```

**避免 bank conflict 的技巧**：

```cpp
// ❌ 列访问会导致 bank conflict
__shared__ float sdata[32][32];
float val = sdata[threadIdx.y][threadIdx.x];
// 如果 threadIdx.x 相同时 threadIdx.y 不同 → bank conflict！

// ✅ 增加 padding 打破 bank alignment
__shared__ float sdata[32][32 + 1];  // +1 padding
float val = sdata[threadIdx.y][threadIdx.x];
// padding 改变了偏移量，不同的 threadIdx.x 映射到不同 bank
```

### 4.2 Tiling（分块）技巧

矩阵乘法的 tiling 优化：

```cpp
// 使用 shared memory 分块加载数据
// BLOCK_SIZE × BLOCK_SIZE 的子矩阵存入 shared memory
// 减少 global memory 访问次数：从 O(K) 降到 O(K/BLOCK_SIZE)

template <int BLOCK_SIZE>
__global__ void matmul_tiled(const float* A, const float* B, float* C,
                              int M, int N, int K) {
    // 共享内存：两个 BLOCK_SIZE×BLOCK_SIZE 的 tile
    __shared__ float As[BLOCK_SIZE][BLOCK_SIZE];
    __shared__ float Bs[BLOCK_SIZE][BLOCK_SIZE];
    
    int row = blockIdx.y * BLOCK_SIZE + threadIdx.y;
    int col = blockIdx.x * BLOCK_SIZE + threadIdx.x;
    
    float sum = 0.0f;
    
    // 分阶段加载 K 维度
    for (int phase = 0; phase < (K + BLOCK_SIZE - 1) / BLOCK_SIZE; ++phase) {
        // 协同加载数据到 shared memory
        if (row < M && phase * BLOCK_SIZE + threadIdx.x < K)
            As[threadIdx.y][threadIdx.x] = A[row * K + phase * BLOCK_SIZE + threadIdx.x];
        else
            As[threadIdx.y][threadIdx.x] = 0.0f;
            
        if (col < N && phase * BLOCK_SIZE + threadIdx.y < K)
            Bs[threadIdx.y][threadIdx.x] = B[(phase * BLOCK_SIZE + threadIdx.y) * N + col];
        else
            Bs[threadIdx.y][threadIdx.x] = 0.0f;
            
        __syncthreads();  // 确保所有数据加载完成
        
        // 计算当前 tile
        for (int k = 0; k < BLOCK_SIZE; ++k) {
            sum += As[threadIdx.y][k] * Bs[k][threadIdx.x];
        }
        __syncthreads();  // 确保所有线程用完数据再加载下一轮
    }
    
    if (row < M && col < N) {
        C[row * N + col] = sum;
    }
}
// 调用：matmul_tiled<16><<<grid, block>>>(...)
// 或：matmul_tiled<32><<<grid, block>>>(...)
```

---

## 5. Nsight 性能分析

### 5.1 Nsight Compute (ncu)

核函数级别的性能分析器，提供：
- 内存带宽利用率（Memory throughput）
- 计算利用率（Compute throughput）
- Roofline 分析
- 瓶颈识别（memory-bound vs compute-bound）

```bash
# 分析单个 kernel
ncu -o profile_output ./vector_add

# 分析特定 kernel（按名称过滤）
ncu --kernel-name "vector_add" --set full -o profile ./vector_add

# 交互式分析
ncu --set full -o profile ./vector_add
ncu --import profile.ncu-rep  # 在 CLI 中查看报告
```

### 5.2 Nsight Systems (nsys)

系统级性能分析，追踪整个应用的时间线，包括 kernel 执行、内存拷贝、API 调用。

```bash
# 快速分析
nsys profile -o timeline ./vector_add

# 跟踪 CUDA API + kernel + memcpy
nsys profile --trace=cuda,osrt -o timeline ./vector_add

# 只看 timeline
nsys stats --report gputrace timeline.qdrep
```

### 5.3 关键性能指标

| 指标 | 含义 | 优秀值 |
|------|------|--------|
| Occupancy | 每个 SM 上活跃 warp 数 / 最大 warp 数 | > 50% |
| Memory Throughput | 全局内存带宽利用率 | > 60% 峰值 |
| Compute Throughput | 计算单元利用率 | > 60% 峰值 |
| L1 Hit Rate | L1 缓存命中率 | > 80% |
| L2 Hit Rate | L2 缓存命中率 | > 50% |
| Branch Efficiency | 无分歧分支比例 | > 95% |
| Sector Misses | 合并访问效率 | 越低越好 |

---

## 6. 面试考点

| 考点 | 重要度 | 说明 |
|------|--------|------|
| Memory Coalescing 原理 | ⭐⭐⭐ | 必问！**推理 QA 中几乎必问** |
| Shared Memory 与 Bank Conflict | ⭐⭐⭐ | 手撕代码高频考点 |
| SIMT 模型与 Warp Divergence | ⭐⭐⭐ | 解释 why 和 how to avoid |
| Occupancy 计算 | ⭐⭐⭐ | 给定资源能算 occupancy |
| Reduction 实现 | ⭐⭐⭐ | 归约是 Attention softmax 的基础 |
| Tiled MM 实现 | ⭐⭐⭐ | FP8 GEMM 优化的核心 |
| Stream 与异步执行 | ⭐⭐ | 推理计算和通信 overlap |
| CUDA Unified Memory | ⭐ | 了解即可 |

---

## 7. 配套实例与 Linux 命令

- 实例代码目录：[cuda_kernels/](../cuda_kernels/)
  - [vector_add.cu](../cuda_kernels/vector_add.cu) — 基础 vector add kernel
  - [matmul_naive.cu](../cuda_kernels/matmul_naive.cu) — 朴素矩阵乘法
  - [matmul_tiled.cu](../cuda_kernels/matmul_tiled.cu) — Shared memory tiled matmul
  - [reduction.cu](../cuda_kernels/reduction.cu) — 树形归约 kernel
  - [CMakeLists.txt](../cuda_kernels/CMakeLists.txt) — CUDA 工程配置

### 编译与运行

```bash
# 编译 CUDA 程序
nvcc -o vector_add vector_add.cu

# 编译 + 性能优化
nvcc -O2 -arch=sm_80 -o matmul_tiled matmul_tiled.cu
# -arch=sm_80: A100 架构, sm_90: H100, sm_89: RTX 4090

# 查看 GPU 架构
nvidia-smi --query-gpu=name,compute_cap --format=csv

# 编译所有 CUDA sample
cd cuda_kernels && mkdir -p build && cd build
cmake .. -DCMAKE_CUDA_ARCHITECTURES="80"
cmake --build .

# 性能分析
nsys profile -o nsys_report ./vector_add        # 系统级
ncu -o ncu_report ./matmul_tiled                  # Kernel 级
ncu --set full --import-source yes -o ncu_full ./matmul_tiled

# 查看 GPU 详细规格
nvidia-smi -a | grep -E "Max|Memory|SM"   # 显存/SM 数量
cuda-samples/deviceQuery                   # CUDA capability 查询
```
