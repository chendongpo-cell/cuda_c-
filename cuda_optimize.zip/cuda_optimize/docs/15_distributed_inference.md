# 分布式推理详解 — TP / PP / EP / NCCL / PD 分离

> 这是第 2 月末必读文档。现代推理服务几乎都是多卡部署，单卡放不下大模型，更扛不住吞吐。理解分布式是理解 vLLM/SGLang 部署配置的前提。
>
> 学习定位：**搞清楚每种并行切的是什么、通信开销在哪、什么场景用**。不要求你会手写 NCCL，但要能看懂 `vllm serve --tensor-parallel-size 4 --pipeline-parallel-size 2` 在做什么。

---

## 0. 为什么单卡不够

以 Llama-3-70B 为例：
- 参数量：70B
- FP16 权重显存：70 × 2 = **140 GB**
- 单卡 A100 80G / H100 80G **放不下**
- 即便能放下（比如用 4-bit 量化约 35GB），推理时还要留 KV Cache、激活、临时 buffer，单卡仍然紧张

吞吐侧更严重：
- 单卡 decode 速度 ~50-100 token/s/请求
- 100 个并发用户需要 ~5000-10000 token/s 总吞吐
- 单卡扛不住，必须多卡分摊

所以**分布式不是可选项，是默认配置**。

---

## 1. 三种基础并行策略

### 1.1 数据并行（DP）— 训练用，推理少用

每张卡持有**完整模型**，处理不同 batch。推理里很少用，因为：
- 单卡放不下完整大模型
- 没有梯度同步需求，DP 优势消失

但**副本部署（replica）**可以看作 DP 的退化形式：N 张卡跑 N 个独立实例，前面用负载均衡分发请求。简单粗暴，工程上常用。

### 1.2 张量并行（Tensor Parallel, TP）

**核心思想**：把每一层的权重矩阵**沿某个维度切成 N 份**，分给 N 张卡，每张卡只算一部分，最后用通信合并。

####列切分（Column-Parallel）

```
Y = X @ W      W shape: [K, N]
              切成 W_1, W_2, ..., W_p  每份 shape [K, N/p]
              
卡 i 计算: Y_i = X @ W_i    shape [batch, N/p]
最终 Y = [Y_1 | Y_2 | ... | Y_p]  (沿 N 维拼接)
```

特点：
- **无需通信即可得到完整 Y**（每张卡算出来的部分直接拼起来就是结果）
- 但下游层如果要继续用 Y，必须保证后续操作能跨卡

#### 行切分（Row-Parallel）

```
Y = X @ W      W shape: [K, N]
              切成 W_1, ..., W_p  每份 shape [K/p, N]
              X 也对应切成 X_1, ..., X_p  每份 shape [batch, K/p]

卡 i 计算: Y_i = X_i @ W_i    shape [batch, N]
最终 Y = Y_1 + Y_2 + ... + Y_p  (逐元素相加)
```

特点：
- 需要一次 **all-reduce** 把各卡结果加起来
- 但加完之后 Y 在每张卡上都一样，下游层直接用

#### 经典组合：Megatron 的 MLP 层

```
MLP(x) = Dropout( Act(x @ W_gate) @ W_down )

W_gate: [hidden, 4*hidden]   用 column-parallel 切 → 不用通信
W_down: [4*hidden, hidden]   用 row-parallel 切    → 一次 all-reduce
```

整个 MLP 只需**一次 all-reduce**，通信开销相对计算开销很小。

#### Attention 层的 TP

多头注意力天然适合 TP：**每个头分到一张卡**。
- Q/K/V 投影：column-parallel，按 head 数切
- Attention 计算：每卡独立算自己负责的 head
- Output 投影：row-parallel，一次 all-reduce

#### TP 的特点

| 维度 | 说明 |
|------|------|
| 切粒度 | 层内切（每一层都跨卡） |
| 通信频率 | 每层 1-2 次 all-reduce |
| 通信量 | 与 hidden_size 成正比，与 batch 无关 |
| 显存节省 | 权重 + 激活 + KV Cache 都切 |
| 扩展性 | 通常 ≤ 8 卡（受 NVLink 域限制），再多收益递减 |

**关键约束**：TP 要求卡间**极高带宽**（NVLink 或 NVSwitch），否则 all-reduce 成为瓶颈。跨节点 TP 几乎不可行。

### 1.3 流水线并行（Pipeline Parallel, PP）

**核心思想**：把模型**按层切成 N 段**，每段放一张卡。输入像流水线上的工件一样流过各卡。

```
卡 0: Layer 0-15   →   卡 1: Layer 16-31   →   卡 2: Layer 32-47   →   卡 3: Layer 48-63
```

#### 朴素 PP 的问题：气泡（Bubble）

```
时刻  →  t0  t1  t2  t3  t4  t5  t6  t7
卡 0:     F0  F1  F2  F3  ..  ..  ..  ..     (前向完就闲着)
卡 1:     ..  F0  F1  F2  F3  ..  ..  ..     
卡 2:     ..  ..  F0  F1  F2  F3  ..  ..     
卡 3:     ..  ..  ..  F0  F1  F2  F3  ..     
```

后面几卡在等输入，前面几卡在等反向梯度传回来，大量空闲。

#### 1F1B（One Forward One Backward）调度

经典优化：让前向和反向交错，卡 0 算完前向立刻开始反向，减少气泡。

```
时刻  →  t0  t1  t2  t3  t4  t5  t6  t7  t8  ...
卡 0:     F0  F1  F2  F3  B0  B1  B2  B3            (前面忙完立刻反向)
卡 1:         F0  F1  F2  B0  F3  B1  B2  B3        
卡 2:             F0  F1  B0  F2  B1  F3  B2  B3    
卡 3:                 F0  B0  F1  B1  F2  B2  F3  B3
```

气泡占比：`(p-1) / (p-1+m)`，p 是 PP 数，m 是 micro-batch 数。m 越大越能掩盖气泡。

#### PP 在推理里的现状

- **训练用得多**（DeepSpeed、Megatron）
- **推理用得少**，原因：
  - 推理 batch 通常小，气泡占比高
  - 推理没有反向，PP 的优势少一半
  - 跨卡串行依赖，延迟累加 → TTFT 升高
- 但**大模型推理（70B+/175B+）**单节点 TP 不够时，PP 是补充方案

vLLM 在 2024 年后开始支持 PP，SGLang 也支持。

### 1.4 三种并行对比

| 维度 | TP | PP | DP |
|------|-----|-----|-----|
| 切法 | 层内切权重 | 按层切模型 | 复制整个模型 |
| 通信 | 每层 all-reduce | 段间传 activation | 几乎不通信 |
| 带宽要求 | 极高（NVLink） | 中等 | 低 |
| 显存 | 权重+激活+KV 都省 | 主要省权重 | 不省 |
| 扩展上限 | 8 卡/节点 | 数十卡 | 无上限 |
| 推理常用度 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |

---

## 2. 专家并行（Expert Parallel, EP）— MoE 专用

> 配合 [17_moe_inference.md](17_moe_inference.md) 一起看。

MoE 模型（如 DeepSeek-V3、Mixtral）的 FFN 层有多个"专家"，每个 token 只激活其中几个。**专家并行**就是把不同的专家分到不同的卡上。

```
8 个专家，4 张卡：
卡 0: expert 0, 1
卡 1: expert 2, 3
卡 2: expert 4, 5
卡 3: expert 6, 7

token 路由到 expert 2 → 必须发到卡 1
```

#### 关键操作：all-to-all

- **前向 all-to-all**：每张卡把自己收到的 token 按目标专家分组，发给对应卡
- **专家计算**：每张卡对自己负责的专家做 GEMM
- **反向 all-to-all**：把结果发回原来的卡

all-to-all 比 all-reduce 更复杂，是 MoE 推理的主要通信开销。

#### TP vs EP 对 MoE 的对比

| 维度 | TP 切 MoE | EP 切 MoE |
|------|----------|----------|
| 切法 | 每个专家的权重切片 | 整个专家分到不同卡 |
| 通信 | all-reduce（每层） | all-to-all（每个 MoE 层） |
| 适用 | 专家数少 | 专家多（DeepSeek 256 专家） |
| 显存 | 权重切，激活切 | 权重切更彻底 |

DeepSeek-V3 用的是 EP + TP 结合，256 个专家用 EP 散到多卡，每个专家内部再用 TP。

---

## 3. NCCL — NVIDIA 集合通信库

NCCL (NVIDIA Collective Communications Library) 是 GPU 间通信的底层库，PyTorch 的 `torch.distributed`、vLLM、SGLang 都基于它。

### 3.1 常见集合通信原语

#### Broadcast
```
卡 0 有数据 X → 发给所有卡
0: X    1: X    2: X    3: X
```
用途：参数初始化时广播权重。

#### All-Gather
```
每张卡有自己的 X_i → 收集所有人的拼接
0: X_0   →  [X_0|X_1|X_2|X_3]
1: X_1   →  [X_0|X_1|X_2|X_3]
...
```
用途：TP 中 column-parallel 后拼接结果。

#### Reduce-Scatter
```
每张卡有 X_i → 求和后切片分发给各卡
0: X_0   →  sum[0:N/p][0]
1: X_1   →  sum[0:N/p][1]
...
```
用途：训练里梯度同步的拆分步。

#### All-Reduce
```
每张卡有 X_i → 求和后所有人拿到同样的 sum
等价于 Reduce-Scatter + All-Gather
```
用途：TP 中 row-parallel 后合并结果。**推理里最常见的操作**。

#### All-to-All
```
每张卡有发给其他卡的分片 → 一次性交换
0: [→1, →2, →3]   散出去，收齐其他卡发来的
```
用途：MoE 专家路由。

### 3.2 Ring 实现（理解 all-reduce 怎么做到的）

all-reduce 直观做法是"卡 0 收集所有 → 求和 → 广播"，但卡 0 成为瓶颈。

**Ring 算法**：把卡排成环，每张卡把自己的一块发给下一卡，转 N-1 圈就完成了。

```
卡0 → 卡1 → 卡2 → 卡3 → 卡0   (环)

第 1 步: 卡0 发 chunk0 给 卡1, 卡1 发 chunk1 给 卡2, ...
第 2 步: 每卡累加收到的块, 再传给下一卡
...
第 N-1 步: 每卡累加完, 自己负责的 chunk 已经是总和
接着再转 N-1 圈做 all-gather, 每卡拿到完整 sum
```

通信量：每卡发送 `2(N-1)/N × data_size`，远小于"先 gather 再 broadcast"的 `2 × data_size × N`。

NCCL 还会自动选择 **Ring** 或 **Tree** 或 **CollNet** 算法，根据拓扑和规模选最优。

### 3.3 NVLink vs PCIe vs InfiniBand

| 互联 | 带宽 | 适用 |
|------|------|------|
| NVLink 4.0 | 900 GB/s 双向 | 节点内 TP（A100/H100） |
| NVLink 3.0 | 600 GB/s | 节点内（A100） |
| PCIe Gen4 x16 | 64 GB/s 双向 | 节点内非 NVLink |
| IB HDR | 200 Gbps = 25 GB/s | 节点间 |
| IB NDR | 400 Gbps = 50 GB/s | 节点间（H100 集群） |

**经验法则**：
- TP 必须在 NVLink 域内（单节点）
- PP 可以跨节点（通信量小）
- DP/EP 可以跨节点（IB 够用）

---

## 4. PD 分离（Prefill-Decode Disaggregation）

> 2024-2026 推理系统最重要的架构演进之一。代表系统：DistServe、Mooncake（Moonshot）、Splitwise。

### 4.1 为什么要把 Prefill 和 Decode 分开

回忆 [04_attention_kv_cache.md](04_attention_kv_cache.md)：
- **Prefill 阶段**：处理整个 prompt，计算密集（GEMM 主导），生成第一个 token
- **Decode 阶段**：每次生成 1 个 token，访存密集（KV Cache 读取主导）

两者的资源特征完全相反：

| 阶段 | 瓶颈 | batch 行为 | 延迟特征 |
|------|------|----------|---------|
| Prefill | 计算 | 单请求就吃满 GPU | 长 prompt 几百 ms |
| Decode | 访存 | 小 batch 浪费算力 | 每 token 几十 ms |

**混合在一张卡上跑的问题**：
- Prefill 时 GPU 忙，Decode 请求被拖累 → TPOT 升高
- Decode 时 GPU 闲，但不能接新 Prefill（否则互相干扰）
- Continuous Batching 缓解但没解决根本矛盾

### 4.2 PD 分离架构

```
[请求到达]
    ↓
Prefill 集群（P 节点）   ← 算力密集，用满 GPU
    ↓ 生成 KV Cache
KV Cache 传输         ← 跨节点传大块显存
    ↓
Decode 集群（D 节点）   ← 访存密集，跑大 batch
    ↓ 输出 token
```

**关键挑战：KV Cache 传输**
- Llama-70B，长 context 8K，batch 32 的 KV Cache 总量可达数十 GB
- 跨节点传输需要高带宽网络（IB/RoCE）
- Mooncake 提出用 **KV Cache Pool**（SSD + DRAM + GPU 显存分层）做中转

### 4.3 PD 分离的收益

- **吞吐**：P 和 D 各自最大化利用率，总体吞吐提升 30-100%（DistServe 论文数据）
- **TTFT**：P 节点专门优化 prefill，TTFT 降低
- **TPOT**：D 节点跑大 batch decode，TPOT 稳定
- **隔离性**：长 prompt 不会拖累正在 decode 的请求

### 4.4 代价

- **跨节点 KV 传输**：网络压力增加，需要 RDMA
- **调度复杂度**：P 节点要预测 D 节点负载，提前传输
- **KV 复用变复杂**：Prefix Caching 要跨节点命中

Mooncake 用 **KVCache Pool + lookup** 解决：decode 前先查池里有没有现成 prefix，命中就跳过 prefill。

---

## 5. Ring Attention / Context Parallel（CP）

> 用于超长 context（100K+ token）训练和推理。代表：Llama-3 1M context、Ring Attention 论文。

### 5.1 问题：单卡 KV Cache 放不下

Llama-3-8B，context = 1M token：
- KV Cache 大小 ≈ 1M × 8B × 2 (K+V) × 2 bytes (FP16) ≈ **32 GB**
- 单卡放不下，必须跨卡切

### 5.2 Context Parallel 的切法

把 sequence 维度切到多张卡上：
```
卡 0: token 0 ~ 250K 的 Q, K, V
卡 1: token 250K ~ 500K 的 Q, K, V
...
```

但 Attention 的 Q @ K^T 需要所有 token 的 K，怎么办？

### 5.3 Ring Attention 算法

类似 Ring all-reduce：
1. 每张卡持有自己一段的 Q, K, V
2. 计算 Q_local @ K_local^T 得到部分 attention
3. 把 K, V 沿环传给下一卡，同时计算 Q_local @ K_received^T
4. 转 N-1 圈，每卡都见过所有 K, V
5. 用 online softmax（FlashAttention 的 trick）累加得到正确结果

**核心**：通信和计算重叠，KV 在环上传递时不闲着。

vLLM 的 long context serving 已经在用类似思路。

---

## 6. vLLM / SGLang 中的分布式配置实战

### 6.1 vLLM 启动参数

```bash
# 单卡
vllm serve meta-llama/Llama-3-8B

# 4 卡 TP
vllm serve meta-llama/Llama-3-70B \
    --tensor-parallel-size 4

# 2 节点 × 4 卡 TP + PP
vllm serve meta-llama/Llama-3-405B \
    --tensor-parallel-size 8 \
    --pipeline-parallel-size 2

# DeepSeek-V3 MoE 用 EP
vllm serve deepseek-ai/DeepSeek-V3 \
    --tensor-parallel-size 8 \
    --expert-parallel-size 8
```

### 6.2 SGLang 启动参数

```bash
# 多卡 TP
python -m sglang.launch_server \
    --model-path meta-llama/Llama-3-70B \
    --tp 4

# PD 分离（SGLang 的 RadixAttention 天然支持 prefix 复用）
# 启动 prefill 节点和 decode 节点，配 router
```

### 6.3 代码层：torch.distributed

```python
import torch.distributed as dist

# 初始化进程组
dist.init_process_group(
    backend="nccl",
    init_method="env://",
)

# 获取当前卡号和总卡数
rank = dist.get_rank()        # 0 ~ world_size-1
world_size = dist.get_world_size()

# 设置当前卡
torch.cuda.set_device(rank)

# All-Reduce（TP 的 row-parallel 后合并）
dist.all_reduce(tensor, op=dist.ReduceOp.SUM)

# All-Gather（TP 的 column-parallel 后拼接）
dist.all_gather([tensor_list], input_tensor)

# All-to-All（MoE 路由）
dist.all_to_all_single(output_tensor, input_tensor)
```

---

## 7. 学习路径建议

按以下顺序学习，避免上来啃 NCCL 源码：

1. **跑通 vLLM 单卡** → 理解单卡推理流程
2. **跑通 vLLM 2 卡 TP** → 观察 NVLink 利用率（`nvidia-smi dmon`）
3. **读 vLLM 的 `parallel_state.py`** → 看它怎么管理 rank/group
4. **手写一个小 demo**：PyTorch + `torch.distributed` 在 2 卡上做矩阵乘法，列切+行切+all-reduce
5. **试 PP**：vLLM 跑 Llama-70B 用 `--pipeline-parallel-size 2`
6. **看 DistServe 论文** → 理解 PD 分离
7. **跑 DeepSeek-V3**（如果有资源）→ 感受 EP

---

## 8. 动手实验清单

| 实验 | 目的 | 预计耗时 |
|------|------|---------|
| 单卡跑 vLLM 推理 | 基线 | 0.5h |
| 2 卡 TP 对比单卡吞吐 | 理解 TP 收益 | 1h |
| `nvidia-smi dmon` 看 NVLink 利用率 | 直观感受通信开销 | 0.5h |
| 手写 PyTorch 分布式 GEMM | 理解 TP 切法 | 2h |
| 跑 PP 配置 | 理解 PP 气泡 | 1h |
| 读 DistServe 论文 | 理解 PD 分离动机 | 2h |

---

## 9. 常见误区

1. **"TP 越多越好"** — 错。跨节点 TP 几乎不可行，PCIe 跨卡 all-reduce 拖垮性能。通常 ≤ 8。
2. **"PP 节省显存随便用"** — 错。PP 有气泡，推理延迟累加，小 batch 尤其明显。
3. **"DP 简单就行"** — 错。DP 副本之间 KV Cache 不能共享，长 prompt 场景浪费显存。
4. **"PD 分离万能"** — 错。短 prompt 场景 PD 分离的 KV 传输开销可能超过收益。
5. **"NCCL 是黑盒不用懂"** — 错。NCCL 调优（`NCCL_IB_DISABLE`、`NCCL_NET_GDR_LEVEL`）对大规模部署影响巨大。

---

## 10. 延伸阅读

- Megatron-LM 论文：TP 的原始论文
- DistServe 论文 (OSDI 2024)：PD 分离
- Mooncake 论文 (KVCache Pool)
- DeepSeek-V3 技术报告：EP 实战
- NCCL 用户指南：`https://docs.nvidia.com/deeplearning/nccl/`
- vLLM `parallel_state.py` 源码

---

## 11. 速查表

| 想做的事 | 用什么 |
|---------|-------|
| 大模型单节点装下 | TP=8 |
| 模型超大单节点装不下 | TP=8 + PP 跨节点 |
| 提升吞吐（小模型） | DP 副本 |
| MoE 推理 | EP |
| 长上下文（1M+） | Ring Attention / CP |
| 高吞吐服务部署 | PD 分离 |
| 减少 TTFT | 优化 Prefill（Flash Attention、Chunked Prefill） |
| 减少 TPOT | 优化 Decode（PD 分离、 speculative decoding） |
