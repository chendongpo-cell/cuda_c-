﻿# 第0步：从零开始的工程化上手指南

> 目标：帮 **0 基础** 新人理解"推理优化"到底是做什么的，看懂这个项目里所有的文件是啥、怎么用，并搭建好开发环境。
> 预计阅读：2-3 小时（看完+跟着操作）
> 如果你一天只有 1 小时，分 3 天看完即可。

---

## 目录

1. [这个项目到底是干嘛的？](#1-这个项目到底是干嘛的)
2. [整个 AI 推理链路白话版](#2-整个-ai-推理链路白话版)
3. [项目中每个文件是啥（超简化版）](#3-项目中每个文件是啥超简化版)
4. [环境搭建（Windows 用户必看）](#4-环境搭建windows-用户必看)
5. [动手跑第一个 Python 程序](#5-动手跑第一个-python-程序)
6. [学习顺序建议（0 基础版）](#6-学习顺序建议0-基础版)
7. [常见问题](#7-常见问题)

---

## 1. 这个项目到底是干嘛的？

### 1.1 一句话总结

这个项目教你 **怎么让大模型（比如 ChatGPT）在 GPU 上跑得更快、占更少显存**。

### 1.2 为什么需要优化？

假设你写了一个 Python 程序来运行大模型：

```python
# 这行代码看起来简单，背后要做极其复杂的计算
output = model(input_text)
```

这条简单的代码在底层做了这些事（每个都很慢、很耗显存）：

```
1. Tokenizer：把中文/英文转成数字 ID（"你好" → [125, 340]）
2. Embedding：把数字 ID 转成向量（[125] → [0.3, -0.1, 0.8, ...]）
3. Transformer 层（重复 N 次）：
   a. Attention → 模型"猜"每个词和其他词的关系（最耗时！）
   b. FFN → 对每个词独立做计算
4. Sampling → 从概率分布中选下一个词
5. 循环步骤 3-4，直到生成完整回答
```

**这个项目就是教你如何优化第 3 步（Attention）**，因为这是推理中最慢、最占显存的部分。

### 1.3 你在曙光的工作会做什么？

你在曙光的工作就是把上面这套流程 **从 NVIDIA GPU 移植到国产 DCU 上跑**。

```
原版（NVIDIA GPU）：
  写 CUDA 代码 → 用 nvcc 编译 → 在 A100/H100 上跑
                                          ↓
移植版（DCU 深算一号）：
  把 CUDA 代码转成 HIP 代码 → 用 hipcc 编译 → 在 DCU K100 上跑
```

所以你要学会：
1. **CUDA** — NVIDIA 的 GPU 编程语言（先学这个，因为资料多）
2. **HIP** — AMD/DCU 的 GPU 编程语言（和 CUDA 几乎一样）
3. **推理框架** — vLLM/SGLang（业界主流的大模型推理框架）
4. **系统优化** — 海光 CPU 绑核/NUMA/大页（曙光环境特有）

---

## 2. 整个 AI 推理链路白话版

### 2.1 训练 vs 推理

```
训练（Training）：给模型数据，让它学习 → 几个月，耗电几百万
                    ↓
得到模型权重（一堆数字文件，几个 GB 到几百 GB）
                    ↓
推理（Inference）：用训练好的模型回答问题 → 几秒到几分钟，每个请求
```

**你入职后做的 90% 工作是推理优化**，而不是训练。

### 2.2 一个推理请求的完整旅程

用白话讲清楚整个过程（对照 vLLM 的模块）：

```
你问："中国的首都是什么？"
    ↓
① Tokenizer（分词器）
   把这句话转成数字：[123, 456, 789, ...]
   长知识：Tokenizer 在 CPU 上跑，越快越好
   曙光优化：用海光 CPU 的 AVX 指令加速
   对应文件：docs/13_sugon_hygon_cpu.md
    ↓
② Scheduler（调度器）
   决定当前请求和谁一起算（多请求合并成一批）
   长知识：如果来了 100 个请求，vLLM 会分批处理
   对应文件：docs/07_continuous_batching.md
    ↓
③ PagedAttention（分页注意力）
   模型的核心计算。计算每个词和其他词的关系。
   长知识：vLLM 的核心创新，像操作系统的虚拟内存一样管理显存
   对应文件：docs/06_paged_attention.md
    ↓
④ Sampling（采样）
   根据概率选下一个词 → "北京"
    ↓
⑤ 重复 ③④，直到生成完整回答
   每次生成一个 token，把新的 KV 加到 cache 里
   对应文件：docs/04_attention_kv_cache.md
    ↓
⑥ Detokenizer
   把数字转回文字 → "中国的首都是北京。"
```

### 2.3 核心概念大白话对照表

| 术语 | 大白话 | 类比 |
|------|--------|------|
| GPU / 显卡 | 做海量简单计算的芯片 | 10000 个小学生同时做加减法 |
| CPU | 做复杂逻辑的芯片 | 1 个博士生做高数 |
| CUDA | NVIDIA 的 GPU 编程语言 | 给小学生们发指令的语言 |
| Kernel | 在 GPU 上跑的一个函数 | 一张"所有人同时做 XX"的指令单 |
| Thread | GPU 里的一个计算单元 | 一个小学生 |
| Warp | 32 个线程为一组（同时执行同一条指令） | 32 个小学生齐步走 |
| Shared Memory | 线程块内的共享空间（快！） | 小组共用的白板 |
| Global Memory | 显存（大但慢） | 教室外的储物柜 |
| Bandwidth | 读写速度（推理最常见瓶颈） | 储物柜门能同时打开多少个 |
| Tensor Core | GPU 上专门做矩阵乘法的硬件 | 专门做"九九乘法表"的加速器 |
| FP16 / FP32 | 数字精度，越低越快但精度略差 | 记数字用 2 位小数 vs 7 位小数 |
| Attention | 模型理解词与词关系的机制 | 看到"他"时，知道"他"指谁 |
| KV Cache | 存已算过的 Attention 结果（避免重复计算） | 做过的题目答案记在小本子上 |
| FlashAttention | 一种省显存、更快的 Attention 方法 | 不用把所有草稿纸摊开，算一点扔一点 |

---

## 3. 项目中每个文件是啥（超简化版）

### 3.1 文档文件（docs/ 目录）

按编号从简单到复杂排列：

| 文件 | 讲什么 | 对零基础友好吗 | 曙光的重点 |
|------|--------|:---------:|:---------:|
| [01_cpp17_basics.md](docs/01_cpp17_basics.md) | C++ 基础（RAII、智能指针、模板） | ⭐⭐⭐⭐⭐ | 必须学 |
| [02_cuda_basics.md](docs/02_cuda_basics.md) | CUDA 编程（线程、内存、Kernel） | ⭐⭐⭐⭐ | 先学通，再转 HIP |
| [03_pytorch_extension.md](docs/03_pytorch_extension.md) | PyTorch 自定义算子 | ⭐⭐⭐ | 了解即可 |
| [04_attention_kv_cache.md](docs/04_attention_kv_cache.md) | Attention 原理 + KV Cache | ⭐⭐⭐⭐ | 必须懂 |
| [05_vllm_architecture.md](docs/05_vllm_architecture.md) | vLLM 框架整体架构 | ⭐⭐⭐ | 必须懂 |
| [06_paged_attention.md](docs/06_paged_attention.md) | PagedAttention 源码 | ⭐⭐⭐ | 推理框架核心 |
| [07_continuous_batching.md](docs/07_continuous_batching.md) | 连续批处理调度 | ⭐⭐⭐ | 曙光 DCU 适配重点 |
| [08_sglang_comparison.md](docs/08_sglang_comparison.md) | SGLang 框架对比 | ⭐⭐ | 了解即可 |
| [09_flash_attention.md](docs/09_flash_attention.md) | FlashAttention 原理 | ⭐⭐⭐ | 原理必须懂 |
| [10_quantization.md](docs/10_quantization.md) | 量化技术（INT8/AWQ） | ⭐⭐⭐ | DCU 没有 Tensor Core，量化是关键 |
| [11_kv_cache_optimization.md](docs/11_kv_cache_optimization.md) | KV Cache 优化 | ⭐⭐⭐ | DCU 显存小，优化尤其重要 |
| [13_sugon_hygon_cpu.md](docs/13_sugon_hygon_cpu.md) | 海光 CPU 优化 | ⭐⭐⭐⭐ | **入职必学** |
| [14_sugon_dcu_hip.md](docs/14_sugon_dcu_hip.md) | DCU + HIP 编程 | ⭐⭐⭐⭐ | **入职必学** |

### 3.2 代码文件

| 目录 | 讲什么 | 需要什么环境 |
|------|--------|:---------:|
| [cpp_infra/](cpp_infra/) | C++ 代码（RAII/模板/现代特性） | g++（已安装） |
| [cuda_kernels/](cuda_kernels/) | CUDA Kernel（向量加/归约/矩阵乘） | **需要 CUDA Toolkit（你没装）** |
| [pytorch_ext/](pytorch_ext/) | PyTorch 自定义算子 | Python + PyTorch（已装 CPU 版） |
| [attention_lab/](attention_lab/) | Attention + KV Cache 模拟 | Python |
| [flashattn_triton/](flashattn_triton/) | Triton FlashAttention | 需要 GPU 才能跑 |
| [quant_kernels/](quant_kernels/) | 量化模拟 | Python |
| [minimal_inference_engine/](minimal_inference_engine/) | 手写推理引擎 | Python |

---

## 4. 环境搭建（Windows 用户必看）

### 4.1 你的机器现状

```
OS:        Windows 10
GPU:       NVIDIA T400 4GB  ← 计算能力 7.5，**太老**，很多代码跑不了
Python:    3.10.10
PyTorch:   2.8.0+cpu        ← CPU 版，不能用 CUDA
CUDA:      11.7              ← 驱动支持，但没装 Toolkit
nvcc:      未安装
CMake:     未安装
g++:       已安装（MinGW-w64 15.2.0）
```

**这意味着什么？**

- ✅ 可以编译 C++ 代码（g++ 已装）
- ✅ 可以跑纯 Python 代码（attention_lab/ 中的模拟代码）
- ❌ 不能编译 CUDA 代码（没 nvcc）
- ❌ 不能跑 GPU kernel（PyTorch 是 CPU 版）
- ⚠️ T400 只有 4GB 显存 + 计算能力 7.5 → 即使装了 CUDA，也只能跑小实验

### 4.2 关于远程 GPU 的建议

你说过有远程 GPU 资源。建议：

1. **本地**：用 VS Code 写代码 + 看文档
2. **远程**：通过 SSH 连到有 A100/H100 的服务器
3. **曙光**：入职后会有 DCU 环境

> 当前阶段（0 基础），先 **在本地搭环境跑纯 Python 代码**，远程 GPU 是第 2 个月才需要用的。

### 4.3 Windows 下的 Linux 环境

这个项目大多数代码和命令是 Linux 的（因为推理服务器都是 Linux）。

你目前用的是 Git Bash（在 VS Code 终端里），这是 Windows 上模拟 Linux 命令行的方式。

**后续建议装 WSL2（Windows Subsystem for Linux）**：
- 在 Windows Store 搜索 "Ubuntu" 安装
- 装完后在 VS Code 中按 `F1` → "Remote-WSL: Open Folder in WSL"
- 在 WSL 中你可以用 `apt install` 装 nvcc、cmake 等工具

> 不用急着装 WSL2。第 1 个月用 Git Bash + Python 就够了。

### 4.4 先装可用的 Python 环境

**步骤 1：确保 pip 可用**

```bash
python -m pip install --upgrade pip
```

**步骤 2：安装 PyTorch（CPU 版本已经装了，先不用重装）**

如果你以后想试 CUDA 版，远程 GPU 上装 CUDA 版：

```bash
# 远程 GPU（Linux）上装 CUDA 版 PyTorch
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

**步骤 3：安装需要的 Python 包**

```bash
pip install numpy matplotlib
```

---

## 5. 动手跑第一个 Python 程序

### 5.1 跑 Attention 模拟代码

这是你目前环境唯一能跑的 GPU 相关代码（虽然它在 CPU 上模拟 Attention 的计算逻辑）：

```bash
cd d:/Desktop/fox_projects/cuda_optimize
python attention_lab/standard_attention.py
```

运行后你会看到输出，展示 Attention 计算的流程。

> 如果报错 `ModuleNotFoundError: No module named 'torch'`，先装 PyTorch：
> ```bash
> pip install torch
> ```

### 5.2 跑 KV Cache 模拟代码

```bash
python attention_lab/kv_cache_demo.py
```

这个程序模拟了 **有 KV Cache vs 没有 KV Cache** 的推理循环，你会看到 KV Cache 节省了多少计算量。

### 5.3 跑量化模拟代码

```bash
python quant_kernels/int8_gemm_sim.py
```

这个程序模拟了 INT8 量化（把 FP32 数字降低精度到 INT8 来加速）。

### 5.4 编译 C++ 代码

```bash
cd d:/Desktop/fox_projects/cuda_optimize/cpp_infra/src
g++ -std=c++17 -o raii_demo raii_demo.cpp
./raii_demo
```

---

## 6. 学习顺序建议（0 基础版）

### 阶段 0：先建立整体认知（不建议直接看 md 文档）

1. **先看这个文件（00_getting_started.md）** — 搞懂整个领域在做什么
2. **各个 MD 文档** — 每个文档开头有「目标」和「预计时间」

### 阶段 1：C++ 基础 + 运行环境（第 1-2 周）

```
顺序：docs/01_cpp17_basics.md → 跑 cpp_infra/ 中的代码
目标：能看懂 C++ 代码，能编译运行
重点：RAII、智能指针（推理引擎大量使用）
跳过：做一遍脑子会了就行，不需要全部记住
```

### 阶段 2：Attention 原理（第 3 周）

```
顺序：docs/04_attention_kv_cache.md → 跑 attention_lab/
目标：搞懂 Attention 的输入输出、KV Cache 为什么省计算
重点：
  - QKV 分别是什么
  - Prefill vs Decode 的区别
  - 显存公式：2 × num_layers × num_heads × seq_len × d_head × 2
```

### 阶段 3：CUDA 入门（第 4-6 周）

```
顺序：docs/02_cuda_basics.md → 看 cuda_kernels/ 代码
目标：理解 GPU 编程的基本概念
重点：
  - 线程层次（grid/block/thread）
  - Memory Coalescing（内存合并访问）
  - Shared Memory vs Global Memory
注意：你没 CUDA 环境，先用眼睛看代码理解逻辑
     远程 GPU 上可以编译运行
```

### 阶段 4：vLLM 框架（第 7-8 周）

```
顺序：docs/05_vllm_architecture.md → 06_paged_attention.md → 07_continuous_batching.md
目标：理解 PagedAttention 为什么重要
重点：
  - 逻辑页 → 物理页映射
  - Block Manager
  - Prefix Caching
```

### 阶段 5：曙光专题（第 9-10 周，入职前重点）

```
顺序：docs/13_sugon_hygon_cpu.md → 14_sugon_dcu_hip.md
目标：为入职做准备
重点：
  - HIP 代码怎么写（和 CUDA 几乎一样）
  - CUDA→HIP 迁移步骤
  - DCU 和 A100 的差异（warp=64 等）
  - ROCm 工具链
```

### 阶段 6：高级优化（第 11-12 周）

```
docs/09_flash_attention.md
docs/10_quantization.md
docs/11_kv_cache_optimization.md
```

---

## 7. 常见问题

### Q1: 我什么都不会，能学会吗？

**能。** 这个领域的知识是分层级的，不需要一开始就懂所有东西：

- 第 1 个月：只需要懂 C++ + Attention 原理 + CUDA 基本概念
- 第 2 个月：只需要懂 vLLM 几个核心模块
- 第 3 个月：深入优化

每天的 1 小时，坚持 3 个月，你就能胜任曙光推理优化岗位的入门工作。

### Q2: 我没有 GPU 怎么学？

- **Python 层代码**（attention_lab/、quant_kernels/）可以在 CPU 上跑
- **C++ 代码**（cpp_infra/）不需要 GPU，g++ 就能编译
- **CUDA 代码**（cuda_kernels/）先读代码理解，远程 GPU 上再跑
- **曙光文档**（docs/13、14）是阅读材料，不需要环境

### Q3: 每天 1 小时，我应该先看什么？

```
第 1 天：看完这个文件（00_getting_started.md）
第 2 天：跑 Python 代码（standard_attention.py、kv_cache_demo.py）
第 3 天：通读 docs/01_cpp17_basics.md（先看完，不求全懂）
第 4 天：编译运行 cpp_infra/ 代码
第 5 天：看 docs/04_attention_kv_cache.md
第 6-7 天：重看 docs/02_cuda_basics.md
第 8 天开始：每天看一个文档或跑一段代码
```

### Q5: 我需要装哪些软件？

```
必装（已装）：
  ✅ Python 3.10+（已装）
  ✅ g++（MinGW-w64，已装）

选装（等用到时再装）：
  ⬜ WSL2（用来跑 Linux 命令）
  ⬜ CUDA Toolkit（远程 GPU 上装）
  ⬜ CMake（编译 C++ 项目用，远程 GPU 上装）
  ⬜ nvidia-smi（你电脑上已经有了）
```
