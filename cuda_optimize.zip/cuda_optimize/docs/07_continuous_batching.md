# 第7周：连续批处理与 Scheduler — 推理优化方向

> 目标：深入理解 Continuous Batching（连续批处理）机制和 vLLM Scheduler 的状态管理，这是 vLLM 相对于传统推理系统的核心创新。
> 预计时间：周均 7h（每天 ~1h）

---

## 目录

1. [传统批处理 vs 连续批处理](#1-传统批处理-vs-连续批处理)
2. [调度状态机详解](#2-调度状态机详解)
3. [Block 分配与释放策略](#3-block-分配与释放策略)
4. [V1 Scheduler 源码解读](#4-v1-scheduler-源码解读)
5. [Swap to CPU 机制](#5-swap-to-cpu-机制)
6. [面试考点](#6-面试考点)

---

## 1. 传统批处理 vs 连续批处理

### 1.1 传统批处理（Static Batching）

```
传统推理系统（如 HuggingFace TGI 早期版本）：

时间轴：
  ┌───────等待───────┬───────执行───────┬───────等待───────┬───────┐
  │ Request A 到达    │   Batch 1:      │   Batch 2:      │ ...   │
  │ Request B 到达     │   A, B, C       │   D, E, F       │       │
  │ Request C 到达    │   一起执行        │   一起执行        │       │
  │ ...               │   一起结束        │                  │       │
  └──────────────────┴──────────────────┴──────────────────┘

问题：
  1. Batch 中所有请求必须同时开始、同时结束
  2. 短请求必须等待长请求
  3. 后续请求必须等待当前 batch 完全结束才能加入
  4. GPU 利用率不均衡（短的执行完但还在占用资源）
```

### 1.2 连续批处理（Continuous Batching）

```
vLLM 的连续批处理：

时间轴：
  ┌─────── Step 1 ───────┬─────── Step 2 ───────┬─────── Step 3 ───────┐
  │ A: decode (90% done) │ A: decode (done!)   │ B: decode (继续)     │
  │ B: decode (50% done) │ B: decode (继续)     │ C: decode (继续)     │
  │ C: prefill (new!)    │ C: decode (新)       │ D: prefill (new!)    │
  │                      │ D: prefill (new!)    │ ...                  │
  │                      │ E: prefill (new!)    │                      │
  └──────────────────────┴──────────────────────┴──────────────────────┘

关键特征：
  1. 每步推理可以"换入/换出"请求
  2. 完成的请求立即退出 batch
  3. 新请求立即加入（不需要等 batch 结束）
  4. Prefill 和 Decode 混合执行（prefill 优先）
```

### 1.3 为什么需要混合 Prefill/Decode？

```
纯 Decode 是 memory-bound（计算强度 ≈ 1 FLOP/byte）
但 Prefill 是 compute-bound（计算强度 ≈ S/2 FLOP/byte）

混合的好处：
  每个 step 既有 Prefill（填满计算单元）又有 Decode（利用带宽）
  → 整体 GPU 利用率更高

注意：混合 Prefill/Decode 对 attention 实现有特殊要求
  vLLM 使用 flash_attn_varlen 来处理同一 batch 中不同序列长度
```

---

## 2. 调度状态机详解

### 2.1 V1 Scheduler 三状态

```python
# 文件：vllm/v1/core/scheduler.py
# V1 版本简化了 V0 的复杂调度逻辑

class RequestState(enum.Enum):
    """请求的三种状态"""
    WAITING  = 0   # 等待调度（刚到达 或 preemption 被换出）
    RUNNING  = 1   # 正在执行（占用 GPU 显存）
    FINISHED = 2   # 已完成（等待输出）

# V1 不再有 SWAPPED 状态！
# 简化设计：只在内存不足时 preempt，不 swap 到 CPU
# 如果 GPU 内存不足 → 直接 preempt（drop 一些请求的 KV cache）
```

### 2.2 V0 Scheduler 四状态（了解更多对比）

V0 的完整状态机适配了更复杂的场景：

```
                   ┌──────────────────────────────────────┐
                   │              SCHEDULER                │
                   │                                       │
    Request        │  ┌──────────┐    ┌──────────┐        │
    ──────────►    │  │  WAITING  │───►│  RUNNING  │───►   │────► Finished
                   │  │          │    │          │        │
                   │  └──────────┘    └────┬─────┘        │
                   │       ▲              │               │
                   │       │    preempt   │               │
                   │       │  (换出到CPU) │               │
                   │       │              ▼               │
                   │       │     ┌────────────┐           │
                   │       └─────┤  SWAPPED   │           │
                   │             │ (CPU 显存)  │           │
                   │             └────────────┘           │
                   └──────────────────────────────────────┘
```

### 2.3 调度策略（V1）

```python
# 简化版 V1 Scheduler.schedule() 逻辑

class SchedulerV1:
    def schedule(self) -> SchedulerOutput:
        """
        每步推理前调用，决定本步执行哪些请求

        返回 SchedulerOutput，包含：
        - scheduled_requests: 本步要执行的请求列表
        - num_tokens: 每个请求的 token 数
        - block_tables: 每个请求的 block table
        """
        # 第一步：检查 RUNNING 请求是否还有显存
        #（decode 步骤可能已经分配了新 block）
        running = self._check_running_requests()

        # 第二步：从 WAITING 队列取新请求
        # 直到显存不足或队列为空
        new_requests = []
        while self.waiting_queue:
            req = self.waiting_queue[0]  # peek

            # 检查是否有足够 block
            if self.block_manager.can_allocate(req.num_tokens):
                # 分配 block
                self.block_manager.allocate(req)
                new_requests.append(self.waiting_queue.pop(0))
            else:
                # 显存不足，停止加入新请求
                break

        # 第三步：组装 scheduler output
        all_requests = running + new_requests
        return SchedulerOutput(
            requests=all_requests,
            block_tables=[req.block_table for req in all_requests],
            num_prefill_tokens=sum(
                req.num_prefill_tokens for req in new_requests
            ),
            num_decode_tokens=sum(
                1 for req in running
            ),  # decode 每步 1 token
        )
```

### 2.4 Preemption（请求抢占）

当显存不足时，需要把正在运行的请求"请出去"：

```python
class PreemptionPolicy(enum.Enum):
    """
    V1 只采用 RECOMPUTE 策略（不 swap 到 CPU）
    原因：CPU swap I/O 速度远慢于 GPU → 开销抵消了 batch 收益
    """
    RECOMPUTE = 0  # 释放块，稍后重新计算 KV cache

    # V0 还有：
    SWAP = 1       # 换出到 CPU 显存，后续换回（已废弃）
```

```python
# Preemption 过程
def preempt_request(self, request):
    """
    抢占一个 RUNNING 请求

    时机：有新请求要加入但 GPU 显存不够
    选择：抢占已运行请求中最早的一个（或最后一个 batch 中得分最低的）

    效果：
    1. 释放这个请求的所有 KV cache block
    2. 请求状态回到 WAITING
    3. 请求下次被调度时重新执行 prefill（重新算 KV cache）
    """
    # 1. 释放 KV cache
    request.block_table.free_all()

    # 2. 状态重置
    request.state = RequestState.WAITING

    # 3. 重新放入 waiting 队列（队首，优先调度）
    self.waiting_queue.insert(0, request)

    print(f"Request {request.request_id} preempted (recompute mode)")
```

---

## 3. Block 分配与释放策略

### 3.1 请求生命周期中的 Block 变化

```
请求到达：
  WAITING → 调度器检查 → 分配 block → RUNNING

  block 数:
     │
  256│    ┌──── prefill 分配 256 blocks
     │   ╱  （prompt 4096 tokens / 16 block_size = 256）
     │  ╱
     │ ╱
 16 │╱    ┌──── 已有 256 blocks
     │     │      ───── decode step → 每步可能需要新 block
     │     │
     │     │ 当 256 blocks 用完 → 分配第 257 个 block
     │     │ 当 272 blocks 用完 → 分配第 273 个 block
     │     │ ...
     │     └──── 最多到 max_tokens 个 blocks
     │
     └────────────────────────────────► 时间
      arrive  prefill  decode...    finished
                               → free all blocks
```

### 3.2 显存管理策略选择

```python
class BlockManager:
    def _get_num_available_blocks(self, gpu_memory):
        """
        计算可用的 KV cache block 数量

        两种计算方式：

        方式 1（vLLM 默认）：
          available_memory = gpu_memory * gpu_memory_utilization
          kv_memory = available_memory - model_weight_memory
          num_blocks = kv_memory / block_memory

        方式 2（手动指定）：
          num_blocks = max_num_seqs * max_num_blocks_per_seq
            这会导致预留过多，利用率低
        """
        # vLLM 的实际计算逻辑
        model_weight_size = self._estimate_model_weight()
        total_kv_cache_memory = (
            gpu_memory
            * self.gpu_memory_utilization  # 默认 0.9
            - model_weight_size
        )
        num_blocks = total_kv_cache_memory // self.block_memory
        return num_blocks
```

### 3.3 Batch 中的 Token 数量管理

```python
class SchedulerV1:
    def _check_token_budget(self, new_request, running_requests) -> bool:
        """
        检查加入新请求后，本步的 token 总数是否在预算内

        vLLM 有两个限制：
        1. max_num_seqs: batch 中最多 N 个请求
        2. max_num_batched_tokens: 单步最多处理 M 个 token

        为什么要限制 max_num_batched_tokens？
          - attention 的计算复杂度是 O(S²)（S = bached token per batch）
          - 太大会导致单步时间过长，增加延迟
          - 默认值 = 65536（V1 可配置）
        """
        # 本步的 prefill tokens（新请求的所有 prompt tokens）
        new_prefill = sum(req.num_prefill_tokens for req in [new_request])

        # 本步的 decode tokens（running 请求，每个 1 token）
        running_decode = len(running_requests)

        total_tokens = new_prefill + running_decode
        total_seqs = len(running_requests) + 1

        return (
            total_tokens <= self.max_num_batched_tokens
            and total_seqs <= self.max_num_seqs
        )
```

---

## 4. V1 Scheduler 源码精读

### 4.1 核心文件路径

```
vllm/v1/core/
├── scheduler.py           ← 主调度逻辑（~350 行）
├── block_manager.py       ← Block 管理器
├── block_pool.py          ← Block 对象池化
├── block_table.py         ← Block 映射表
└── config.py              ← 配置
```

### 4.2 Scheduler 核心方法调用链

```python
# 从 LLMEngine 到 Scheduler 的调用链

LLMEngine:
    def run_engine(self):
        while True:
            # 1. 获取新请求（从网络/handle）
            new_requests = self.get_new_requests()

            # 2. 添加请求到调度器
            for req in new_requests:
                self.scheduler.add_request(req)

            # 3. 调度（关键）
            scheduler_output = self.scheduler.schedule()

            # 4. 执行模型
            outputs = self.model_runner.execute(scheduler_output)

            # 5. 更新请求状态（完成/继续）
            self.scheduler.update_from_output(outputs)


Scheduler:
    def schedule(self) -> SchedulerOutput:
        # 调用链:
        # 1. _schedule_running()     ← 处理 running 请求
        # 2. _schedule_new()          ← 尝试加入新请求
        # 3. _schedule_preemption()   ← 如果显存不足，preempt
        # 4. → Build SchedulerOutput

    def _schedule_running(self):
        """检查 running 请求是否需要更多 block"""
        for req in self.running:
            # decode 可能用完了上一个 block
            # 需要检查并分配新 block
            if req.needs_new_block():
                if not self.block_manager.can_allocate(1):
                    # 无空闲 block → 触发 preemption
                    self._schedule_preemption()
                    return
                req.allocate_new_block()

    def _schedule_new(self):
        """从 waiting 队列取新请求"""
        while self.waiting_queue:
            req = self.waiting_queue[0]

            # 需要多少 block
            num_blocks = req.get_num_blocks_needed()

            if not self.block_manager.can_allocate(num_blocks):
                # 显存不足 → 停止
                # (但可以试试 preempt 一些 running 来腾空间)
                if self._should_preempt_for(req):
                    self._preempt_one_running()
                    continue
                break

            # 分配 block
            self.block_manager.allocate(req, num_blocks)
            self.waiting_queue.popleft()
            self.running.append(req)
```

### 4.3 SchedulerOutput 结构

```python
@dataclass
class SchedulerOutput:
    """调度器输出，送入 Model Runner"""
    # 本步执行的请求 ID 列表（按调度顺序）
    scheduled_request_ids: List[str]

    # 每个请求的 token 输入
    input_tokens: List[List[int]]

    # Block Table（每个请求的物理 block 映射）
    block_tables: List[List[int]]

    # 当前 batch 中每个序列的长度
    seq_lens: List[int]

    # Prefill / Decode 标识
    is_prefill: List[bool]

    # 采样参数（temperature 等）
    sampling_params: List[SamplingParams]
```

---

## 5. Swap to CPU 机制

### 5.1 为什么 V1 去掉了 Swap？

```
Swap 到 CPU 的开销分析：

GPU → CPU 带宽：PCIe 4.0 x16: ~32 GB/s
GPU → GPU 带宽（NVLink/NVSwitch）：~600 GB/s ~ 900 GB/s

假设 KV cache 大小 = 2 GB（40层，~4096 tokens）：
  CPU Swap 时间: 2GB / 32GB/s ≈ 62ms
  GPU Prefill 时间: 2GB 的 KV 重新计算 ≈ 取决于计算能力

结论：对大多数模型，重新计算 KV cache 比 Swap 快！
  - Swap 受 PCIe 带宽限制
  - Recompute 利用 GPU 计算能力（fp16 矩阵乘）
  - 所以 V1 移除了 Swap 支持
```

### 5.2 仍保留 Swap 的场景

```
V0 保留 Swap 给这些场景：

1. Offloading：GPU 显存极度不足时，把 KV cache 放到 CPU
   → 适用大批量推理（batch size 很大）
   → 牺牲延迟换取吞吐

2. Speculative Decoding 中的 draft model 切换

3. 多租户场景：不同用户的模型权重切换
```

---

## 6. 面试考点

| 考点 | 重要度 | 说明 |
|------|--------|------|
| Continuous Batching 原理 | ⭐⭐⭐ | 为什么比 static batching 好 |
| Prefill/Decode 混合调度 | ⭐⭐⭐ | 为什么需要混合，如何实现 |
| Preemption 策略 (Recompute vs Swap) | ⭐⭐ | V1 为什么移除了 Swap |
| Scheduler 三状态 | ⭐⭐⭐ | WAITING → RUNNING → FINISHED |
| max_num_seqs vs max_num_batched_tokens | ⭐⭐ | 两个限制的区别 |
| Block 分配时机 | ⭐⭐ | Prefill 一次性分配所有 block vs Decode 按需分配 |
| 显存不足时的处理 | ⭐⭐⭐ | Preemption vs OOM vs 拒绝请求 |
| SchedulerOutput 包含什么 | ⭐ | block_tables, seq_lens, is_prefill |

---

### 本周学习清单

```
Day 1-2: 阅读 vllm/v1/core/scheduler.py 源码全文
Day 3-4: 跟踪 schedule() 方法的调用链（从 add_request 到 SchedulerOutput）
Day 5-6: 理解 Prefill/Decode 混合的策略和限制条件
Day 7: 对比实验 — 不同 max_num_seqs / max_num_batched_tokens 对吞吐的影响
```
