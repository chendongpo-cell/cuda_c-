﻿# SGLang 源码分析与架构详解

> SGLang 是 2024 年崛起的推理框架，在多轮对话、结构化生成、Tree of Thought 等场景下吞吐显著优于 vLLM。代表创新：RadixAttention、前端 DSL、零开销调度。
>
> 学习定位：**理解 SGLang 的设计哲学、RadixAttention 的工程实现、与 vLLM 的核心区别、能读懂关键源码文件**。
>
> 前置知识：[05_vllm_architecture.md](05_vllm_architecture.md)、[06_paged_attention.md](06_paged_attention.md)、[08_sglang_comparison.md](08_sglang_comparison.md)、[20_prefix_caching.md](20_prefix_caching.md)。

---

## 0. SGLang 是什么

SGLang = **S**tructured **G**eneration **Lang**uage，由 LMSYS（Vicuna/Chatbot Arena 那个团队）开发。

核心定位：**针对结构化生成和多轮对话场景优化的推理引擎**。

为什么需要它：
- vLLM 的 PagedAttention + Continuous Batching 优化单请求吞吐
- 但多轮对话、Tree of Thought、JSON 输出等场景，vLLM 的 prefix 复用效率低
- SGLang 的 RadixAttention 天生为这些场景设计

2024-2026 的实测：在多轮对话场景下，SGLang 吞吐比 vLLM 高 30-100%；单轮场景两者接近。

---

## 1. SGLang 的三个核心创新

### 1.1 RadixAttention（核心）

详见 [20_prefix_caching.md](20_prefix_caching.md)。简述：
- 用 Radix Tree 存所有历史 KV Cache
- 新请求在树上找最长匹配
- 支持**任意树形共享**（vLLM APC 只支持线性前缀）

### 1.2 前端 DSL（领域特定语言）

SGLang 提供了一个 Python DSL，让你用 Python 写 prompt 模板，编译时优化：

```python
from sglang import function, gen, user, assistant, set_max_tokens

@function
def multi_turn_qa(s, question1, question2):
    # 第一轮
    s += user(f"Q1: {question1}")
    s += assistant(gen("answer1", max_tokens=100))
    # 第二轮 (复用第一轮的 KV)
    s += user(f"Q2: {question2}")
    s += assistant(gen("answer2", max_tokens=100))
    return s
```

SGLang 编译器看到这个函数：
- 知道 `answer1` 之后的内容会被复用（多轮对话）
- 自动用 RadixAttention 缓存第一轮 KV
- 第二轮只需要算新 token

这是 SGLang 的"杀手锏"：把 prefix 复用从"运行时隐式命中"变成"编译时显式优化"。

### 1.3 零开销调度（Zero-Overhead Scheduler）

vLLM 的调度在 Python 层，每个 step 要做大量 Python 操作（dict 操作、list 操作等），CPU 占用高。

SGLang 用 C++ 实现关键调度路径，Python 只负责 high-level 控制。GPU 利用率更接近 100%。

---

## 2. SGLang 架构总览

```
┌─────────────────────────────────────────────┐
│            Frontend (Python DSL)             │  ← 用户写 prompt 模板
│         sglang/srt/managers/                 │
└──────────────┬──────────────────────────────┘
               │ 编译成 IR
               ▼
┌─────────────────────────────────────────────┐
│           Scheduler (Tokenizer + KV Mgmt)    │  ← 调度 + Radix Tree
│         sglang/srt/managers/scheduler.py     │
└──────────────┬──────────────────────────────┘
               │ 分发到 worker
               ▼
┌─────────────────────────────────────────────┐
│             Model Worker (TP)                │  ← 实际 GPU 推理
│         sglang/srt/model_executor/           │
└─────────────────────────────────────────────┘
```

对应 vLLM：
| SGLang | vLLM |
|--------|------|
| Frontend DSL | OpenAI API |
| Scheduler | LLMEngine + Scheduler |
| Radix Cache | PagedAttention + APC |
| Model Worker | Model Runner + Worker |

---

## 3. 关键源码文件导航

源码地址：`https://github.com/sgl-project/sglang`

### 3.1 顶层结构

```
sglang/
├── sglang/                  # 主代码
│   ├── srt/                 # SGLang Runtime (服务端)
│   │   ├── managers/        # 调度器、tokenizer manager
│   │   ├── model_executor/  # 模型加载与 forward
│   │   ├── layers/          # 自定义层 (attention, quant 等)
│   │   ├── mem_cache/       # RadixAttention / KV Cache
│   │   └── backend/
│   ├── lang/                # 前端 DSL
│   │   ├── interpreter.py   # DSL 解释器
│   │   └── ir.py            # 中间表示
│   └── ...
└── docs/
```

### 3.2 必读源码文件

#### 3.2.1 RadixAttention 实现

**`sglang/srt/mem_cache/radix_cache.py`** — Radix Tree 数据结构

核心类 `RadixCache`：

```python
class TreeNode:
    """Radix Tree 节点"""
    def __init__(self):
        self.children = {}       # 子节点 (按 token id 索引)
        self.parent = None
        self.key = []            # 这个节点存的 token 序列
        self.value = None        # KV Cache 张量
        self.lock_ref = 0        # 有多少请求在用
        self.last_access_time = 0.0  # LRU

class RadixCache:
    def __init__(self):
        self.root = TreeNode()
        self.key_value_kv_cache_pool = ...  # 物理 KV 存储
    
    def match_prefix(self, key_tokens):
        """
        在树上找最长匹配
        返回 (matched_node, matched_length)
        """
        node = self.root
        matched_length = 0
        
        for token in key_tokens:
            if token in node.children:
                child = node.children[token]
                # 比较这个 child 节点的完整 key
                for i, child_token in enumerate(child.key):
                    if matched_length + i < len(key_tokens) and \
                       key_tokens[matched_length + i] == child_token:
                        continue
                    else:
                        # 部分匹配,需要分裂
                        return self._split_node(node, child, i)
                node = child
                matched_length += len(child.key)
            else:
                break
        
        return node, matched_length
    
    def insert(self, key_tokens, value):
        """插入新的 KV Cache 到树中"""
        # 1. 找最长前缀匹配
        # 2. 如果匹配节点需要分裂,先分裂
        # 3. 把新节点挂上去
        # 4. 存 KV value
        ...
    
    def evict(self, num_tokens):
        """LRU 淘汰: 释放 num_tokens 个 token 的空间"""
        # 找 last_access_time 最早且 lock_ref==0 的节点
        # 释放它的 KV 空间
        # 从树中删除
        ...
```

**关键阅读点**：
- `match_prefix` 的分裂逻辑（部分匹配时如何 split 节点）
- `insert` 的合并逻辑（如果只有一个子节点是否合并）
- `evict` 的 LRU 策略

#### 3.2.2 调度器

**`sglang/srt/managers/scheduler.py`** — 核心 Scheduler

```python
class Scheduler:
    def __init__(self, ...):
        self.tree_cache = RadixCache(...)  # RadixAttention
        self.running_queue = deque()        # 正在跑的请求
        self.waiting_queue = deque()        # 等待的请求
        self.req_to_req_pool = {}           # request id -> 物理 slot
    
    def event_loop_overlap(self):
        """主循环: CPU 调度和 GPU 计算重叠"""
        while True:
            # 1. 收到新请求 (from tokenizer_manager)
            self.recv_requests()
            
            # 2. 调度决策
            batch = self.get_next_batch_to_run()
            
            # 3. 发到 GPU 跑 (异步)
            self.run_batch(batch)
            
            # 4. 处理上一轮 GPU 结果 (异步)
            self.process_batch_result(prev_batch)
    
    def get_next_batch_to_run(self):
        """决定这一步跑哪些请求"""
        # 1. 优先处理 running_queue 里的 decode
        # 2. 如果有空间,从 waiting_queue 拿新请求做 prefill
        # 3. 用 RadixCache.match_prefix 查每个新请求能复用多少 KV
        ...
```

**关键阅读点**：
- `event_loop_overlap` 的双缓冲思想（CPU 调度 step N+1 时 GPU 跑 step N）
- `get_next_batch_to_run` 的调度策略

#### 3.2.3 模型执行

**`sglang/srt/model_executor/model_runner.py`** — 模型 forward

```python
class ModelRunner:
    def __init__(self, ...):
        self.model = ...  # 加载的模型
        self.kv_caches = ...  # 物理 KV Cache 存储
    
    def forward(self, batch):
        """执行一个 batch 的前向"""
        # 1. 准备输入 (token ids, positions, attention metadata)
        # 2. 调用 model.forward
        # 3. 更新 KV Cache (通过 RadixCache 引用)
        # 4. 采样 (如果 decode 完成)
        ...
```

#### 3.2.4 Attention Layer

**`sglang/srt/layers/attention/flashinfer.py`** (或其他 backend)

SGLang 支持 multiple attention backends：
- FlashInfer (推荐)
- FlashAttention v2/v3
- Triton (fallback)

每个 backend 都要实现：
- `forward()` 方法：给定 Q, K, V 和 KV cache 指针，算 attention
- `forward_metadata`：构造 attention 需要的 metadata（position ids, seq lens, block table）

#### 3.2.5 前端 DSL

**`sglang/lang/interpreter.py`** — DSL 解释器

```python
class ProgramState:
    """SGLang DSL 的运行时状态"""
    def __init__(self):
        self.messages = []           # 积累的 prompt
        self.variables = {}          # gen() 产生的变量
    
    def __iadd__(self, other):
        """s += 'text' 或 s += user('text') 的实现"""
        # 把 text 加到 messages 里
        ...
    
    def gen(self, name, **kwargs):
        """s += gen('answer', max_tokens=100) 的实现"""
        # 触发一次推理,把结果存到 self.variables[name]
        ...
```

---

## 4. RadixAttention 的工作流程

详细看一次请求怎么走完整流程：

### 4.1 请求到来

```
用户: 多轮对话
[
  {"role": "user", "content": "Hi"},
  {"role": "assistant", "content": "Hello! How can I help?"},
  {"role": "user", "content": "What's 2+2?"}
]
```

### 4.2 Tokenize

```
tokenizer 把对话变成 token 序列:
[BOS, Hi, EOS_user, Hello!, How, can, I, help,?, EOS_assistant, What, ', s, 2, +, 2, ?, EOS_user]
```

### 4.3 RadixCache 匹配

```
RadixCache.match_prefix(tokens) 沿树查找:

                root
                 |
              [BOS, Hi, EOS_user]    ← 节点 A (已缓存, 之前有 "Hi" 请求)
                 |
              [Hello!, How, can, I, help, ?, EOS_assistant]  ← 节点 B (已缓存)
                 |
              [What, ', s]   ← 节点 C (部分匹配? 还是没匹配?)

如果节点 C 完全匹配: 复用整个 KV
如果节点 C 部分匹配: 分裂节点 C, 复用前半部分
如果没节点 C: 只匹配到节点 B, 新算后面的
```

### 4.4 调度

```
Scheduler 看到:
  - 已匹配 KV 长度: M
  - 总 prompt 长度: L
  - 需要新算: L - M 个 token

把这 L - M 个 token 加入 batch, 算 prefill
prefill 完成后, 把新算的 KV 插入 RadixCache
```

### 4.5 Prefill + Decode

```
Prefill: 算 L - M 个新 token, 复用 M 个旧 KV
Decode: 逐个生成新 token, 每步把 KV 写入 RadixCache
```

### 4.6 请求结束

```
请求完成后, RadixCache 里多了 [What, ', s, 2, +, 2, ?, EOS_user, <assistant_response>]
   这部分会在下次对话复用

但 lock_ref 降为 0, 进入 LRU 候选
如果显存紧张, 会被 evict
```

---

## 5. SGLang vs vLLM 架构对比

| 维度 | SGLang | vLLM |
|------|--------|------|
| KV Cache 管理 | Radix Tree | Page Table + Hash (APC) |
| 调度语言 | Python + C++ critical path | 纯 Python |
| 前端 | DSL (编译优化) | OpenAI API |
| Prefix 复用 | 树形任意 | 线性前缀 |
| 调度开销 | 低 (C++ 实现) | 中 (Python 实现) |
| TP 支持 | ✅ | ✅ |
| PP 支持 | ✅ | ✅ |
| EP 支持 | ✅ (MoE 优化) | ✅ |
| 投机解码 | ✅ (EAGLE) | ✅ (EAGLE) |
| 多轮对话吞吐 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| 单轮吞吐 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| 生态成熟度 | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| 文档完整度 | ⭐⭐⭐ | ⭐⭐⭐⭐ |

---

## 6. 部署 SGLang

### 6.1 安装

```bash
pip install "sglang[all]"
```

### 6.2 启动服务

```bash
# 单卡
python -m sglang.launch_server \
    --model-path meta-llama/Llama-3-8B \
    --port 30000

# 多卡 TP
python -m sglang.launch_server \
    --model-path meta-llama/Llama-3-70B \
    --tp 4 \
    --port 30000

# 启用 RadixAttention (默认开启)
python -m sglang.launch_server \
    --model-path meta-llama/Llama-3-8B \
    --enable-radix-cache \
    --port 30000
```

### 6.3 用 DSL 调用

```python
import sglang as sgl

@sgl.function
def multi_turn(s, q1, q2):
    s += sgl.user(f"Q1: {q1}")
    s += sgl.assistant(sgl.gen("a1", max_tokens=100))
    s += sgl.user(f"Q2: {q2}")
    s += sgl.assistant(sgl.gen("a2", max_tokens=100))

# 批量调用
states = multi_turn.run_batch([
    {"q1": "What is AI?", "q2": "Give an example."},
    {"q1": "What is ML?", "q2": "Give an example."},
    {"q1": "What is DL?", "q2": "Give an example."},
])

# SGLang 自动复用 prefix (system prompt 等)
# 第二、三个请求的 q1 部分如果结构相似, 也能部分命中
```

---

## 7. 性能调优

### 7.1 关键参数

| 参数 | 默认 | 调优建议 |
|------|-----|---------|
| `--enable-radix-cache` | True | 多轮对话场景必须开 |
| `--schedule-conservatism` | 0.5 | 高负载调高，减少抢占 |
| `--mem-fraction-static` | 0.9 | KV Cache 比例，越高越省显存 |
| `--max-running-requests` | auto | 根据 GPU 显存手动调 |

### 7.2 监控

SGLang 暴露 Prometheus metrics：

```
sglang:num_running_req         # 正在跑的请求数
sglang:num_used_tokens         # 已用 KV Cache token 数
sglang:cache_hit_rate          # RadixAttention 命中率
sglang:gen_throughput          # 生成吞吐
```

---

## 8. SGLang 适合与不适合的场景

### 8.1 适合

- ✅ 多轮对话（最大优势）
- ✅ Tree of Thought / Beam Search
- ✅ JSON / Structured output
- ✅ Agent 工作流（多次 LLM 调用）
- ✅ Few-shot learning（共享 few-shot examples）
- ✅ MoE 模型（SGLang 的 MoE 优化激进）

### 8.2 不适合 / 优势小

- ❌ 单轮短 prompt（RadixAttention 优势消失）
- ❌ 极端追求生态成熟度（vLLM 更稳）
- ❌ 需要复杂数据流（vLLM 的 processors 生态更丰富）

---

## 9. 学习路径建议

1. **跑 SGLang demo** → 感受多轮对话加速
2. **跑 [09_sglang_analysis/source_notes.py](../09_sglang_analysis/source_notes.py)** → 用源码导航读关键文件
3. **读 `radix_cache.py`** → 理解树形 KV 管理
4. **读 `scheduler.py` 的 `event_loop_overlap`** → 理解零开销调度
5. **对比 vLLM 同类文件** → 理解设计差异
6. **用 DSL 写一个多轮对话应用** → 体验编译优化

---

## 10. 常见误区

1. **"SGLang 一定比 vLLM 快"** — 错。单轮场景两者接近，多轮场景 SGLang 优势大。
2. **"RadixAttention 比线性 APC 总是更好"** — 错。线性 prefix 场景下两者效果一样，Radix 多了树管理开销。
3. **"SGLang 是 vLLM 的替代品"** — 不完全。生态、文档、稳定性 vLLM 仍领先，SGLang 在特定场景更优。
4. **"DSL 必须用"** — 错。SGLang 也支持 OpenAI API 兼容调用。
5. **"RadixAttention 不需要 PagedAttention"** — 错。两者底层都基于 paged KV，RadixAttention 是在 paged 之上的逻辑层。

---

## 11. 延伸阅读

- SGLang 论文：Zheng et al., 2024 "SGLang: Efficient Execution of Structured Language Model Programs"
- SGLang GitHub: `https://github.com/sgl-project/sglang`
- SGLang 文档: `https://docs.sglang.ai/`
- RadixAttention 论文

---

## 12. 速查表

| 概念 | SGLang 实现 | 对应文件 |
|------|------------|---------|
| KV Cache 管理 | RadixCache | `srt/mem_cache/radix_cache.py` |
| 调度 | Scheduler + C++ | `srt/managers/scheduler.py` |
| 模型执行 | ModelRunner | `srt/model_executor/model_runner.py` |
| Attention | FlashInfer backend | `srt/layers/attention/` |
| 前端 DSL | ProgramState | `lang/interpreter.py` |
| 量化 | AWQ/GPTQ/FP8 | `srt/layers/quantization/` |
| 投机解码 | EAGLE | `srt/speculative/` |
| MoE | FusedMoE | `srt/layers/moe/` |
