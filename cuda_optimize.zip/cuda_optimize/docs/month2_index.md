# 第2月：推理框架源码深度实践 — 目录

> 目标：深入理解 vLLM/SGLang 推理框架的核心设计
> 第2月内容不包含 C++ 代码（源码思路为主），但提供详尽的架构分析笔记

| 周次 | 主题 | MD 文件 |
|------|------|---------|
| 第5周 | vLLM 架构总览 | [05_vllm_architecture.md](05_vllm_architecture.md) |
| 第6周 | PagedAttention 核心源码 | [06_paged_attention.md](06_paged_attention.md) |
| 第7周 | 连续批处理与 Scheduler | [07_continuous_batching.md](07_continuous_batching.md) |
| 第8周 | SGLang 与框架对比 | [08_sglang_comparison.md](08_sglang_comparison.md) |

### 第2月学习建议

由于第2月内容不涉及手写代码，建议：
1. **边读边画架构图**：每个组件画 UML 序列图
2. **配合源码仓库阅读**：
   ```bash
   git clone https://github.com/vllm-project/vllm.git
   git clone https://github.com/sgl-project/sglang.git
   ```
3. **部署试用**：
   ```bash
   # vLLM
   pip install vllm
   python -m vllm.entrypoints.openai.api_server --model meta-llama/Llama-3.2-1B

   # SGLang
   pip install sglang
   python -m sglang.launch_server --model meta-llama/Llama-3.2-1B
   ```
