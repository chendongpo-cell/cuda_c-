# MoE 推理优化详解

> 这是 2024-2026 推理系统的主战场。代表模型：Mixtral-8x7B、DeepSeek-V3、Qwen-MoE、GPT-4（据传）。
>
> 学习定位：**搞清楚 MoE 为什么能在不增加推理算力的情况下扩大参数量，以及 MoE 推理相比 Dense 模型多了哪些工程挑战**。
>
> 前置知识：[04_attention_kv_cache.md](04_attention_kv_cache.md)、[15_distributed_inference.md](15_distributed_inference.md) 的 EP 概念。

---

## 0. 一个直觉比喻

 Dense 模型像"全科医生"：每个 token 都要经过所有科室的医生诊断，每个医生都看一遍。

MoE 模型像"分诊医院"：每个 token 进来先看分诊台（router），分诊台决定去看哪几个专科医生（expert），看完就走。

- 优点：医院里医生总数（参数量）可以很大，但每个病人只看 2 个医生（激活参数少）→ 算得快
- 难点：分诊要准、医生负载要均衡、跨科室转诊（路由通信）开销大

---

## 1. MoE 基本结构

### 1.1 Dense FFN 回顾

普通 Transformer 的 FFN 层：

```python
# 标准 FFN (PyTorch)
class FFN(nn.Module):
    def __init__(self, hidden, inter):
        self.w_gate = nn.Linear(hidden, inter)  # 升维
        self.w_down = nn.Linear(inter, hidden)  # 降维
    
    def forward(self, x):
        # x: [batch, seq, hidden]
        h = self.w_gate(x)         # [batch, seq, inter]
        h = act(h)                 # ReLU/SiLU
        return self.w_down(h)      # [batch, seq, hidden]
```

每个 token 都要走完同一个 FFN，算力 = `batch × seq × hidden × inter × 2`。

### 1.2 MoE FFN 结构

把一个大 FFN 换成 N 个小 FFN（专家），每个 token 只走其中 k 个：

```python
# MoE FFN (PyTorch, 简化版)
class MoEFFN(nn.Module):
    def __init__(self, hidden, inter, num_experts, top_k):
        self.num_experts = num_experts  # 专家数,如 8 / 64 / 256
        self.top_k = top_k              # 每个 token 选几个,通常 2
        # N 个专家,每个是一个独立的小 FFN
        self.experts = nn.ModuleList([
            FFN(hidden, inter) for _ in range(num_experts)
        ])
        # Router: 决定每个 token 去哪个专家
        self.router = nn.Linear(hidden, num_experts)
    
    def forward(self, x):
        # x: [batch, seq, hidden]
        b, s, h = x.shape
        
        # 1. 路由打分
        logits = self.router(x)             # [batch, seq, num_experts]
        probs = softmax(logits, dim=-1)     # 概率分布
        
        # 2. 选 top-k 个专家
        topk_probs, topk_idx = probs.topk(self.top_k, dim=-1)
        # topk_idx: [batch, seq, k]  每个位置选的 k 个专家编号
        # topk_probs: [batch, seq, k]  对应概率
        
        # 3. 把 token 送到对应专家计算
        # ... (实现见后,工程上很复杂)
        
        # 4. 加权合并 k 个专家的输出
        output = sum(expert_output_i * topk_probs_i for i in range(k))
        return output
```

### 1.3 关键参数

| 参数 | 典型值 | 含义 |
|------|-------|------|
| `num_experts` | 8 / 64 / 256 | 专家总数 |
| `top_k` | 1 / 2 | 每 token 激活专家数 |
| `inter_size` (每专家) | Dense 的 1/N | 每个专家的 FFN 中间维度 |
| 激活参数 | 总参数 × (k/N) | 实际参与计算的参数 |

**例：Mixtral-8x7B**
- 8 个专家，每个 7B 参数量级
- top_k = 2，每次激活 2 个专家
- 总参数 ≈ 47B（含 attention 等共享部分）
- 激活参数 ≈ 13B
- 推理算力 ≈ 13B Dense 模型，但效果接近 47B Dense

**DeepSeek-V3**
- 256 个 routed expert + 1 个 shared expert
- top_k = 8
- 总参数 671B，激活 37B
- 用 MTP（multi-token prediction）做投机解码

---

## 2. MoE 推理的工程挑战

### 2.1 显存：参数大但激活小

MoE 模型总参数大（要存所有专家权重），但激活算力小。这带来：
- **显存压力大**：DeepSeek-V3 671B FP16 = 1.3TB，单节点 8×H100 320GB 都装不下
- **算力利用率低**：每个 token 只用 k 个专家，其他专家权重闲着但占显存

量化对 MoE 尤其重要：FP8 把 1.3TB 压到 671GB，8×H100 刚好装下。

### 2.2 路由开销

每个 token 要做一次 router 计算 + top-k 选择：
- router 是个小矩阵乘 `[hidden] @ [hidden, num_experts]`
- top-k 选择本身有开销
- 当 num_experts 很大（256），router 也不小

### 2.3 Expert Load Imbalance（专家负载不均）

**问题**：如果 router 倾向于把 token 送给少数"热门"专家，会导致：
- 热门专家成为瓶颈（计算排队）
- 冷门专家闲着（显存浪费）

**训练时**用 auxiliary loss 强制负载均衡。
**推理时**无法改路由，但可以：
- 重组 batch 让专家负载均匀
- 在 EP 部署下，用 expert buffer 缓解

### 2.4 跨专家通信（EP 时）

如果用专家并行（EP），token 要按目标专家发到不同卡：
- 一次 all-to-all 通信
- 通信量 = `batch × seq × hidden × 字节数`
- 大 batch 下通信开销显著

---

## 3. Grouped GEMM — MoE 的核心算子

### 3.1 问题：很多小 GEMM

假设 batch=32, seq=1（decode），top_k=2，num_experts=8：
- 64 个 token 要分到 8 个专家
- 每个专家平均 8 个 token
- 每个专家做 GEMM: `[8, hidden] @ [hidden, inter]`

8 个独立的小 GEMM，每个算力利用率低。

### 3.2 Grouped GEMM

把多个小 GEMM **合并成一次大 GEMM**：

```python
# 朴素做法: for 循环 8 次 GEMM
for expert_idx in range(num_experts):
    tokens_for_this_expert = ...
    output[expert_idx] = expert_weights[expert_idx] @ tokens_for_this_expert

# Grouped GEMM: 一次调用算完所有专家
# 把所有专家的权重 stack 成一个大矩阵
# 用特殊的 index mapping 在一次 GEMM 里完成
output = grouped_gemm(
    tokens_all_experts,    # [total_tokens, hidden]
    weights_all_experts,   # [num_experts, hidden, inter]
    expert_assignment,     # [total_tokens] 每个 token 属于哪个专家
)
```

vLLM/SGLang 都用 Grouped GEMM 算子（CUTLASS 或 Triton 实现）。

### 3.3 Triton 实现（简化版教学）

```python
import triton
import triton.language as tl

# 简化版 grouped GEMM,学习用,真实实现复杂得多
@triton.jit
def grouped_gemm_kernel(
    X_ptr, W_ptr, Y_ptr,           # X: 输入, W: 权重, Y: 输出
    expert_idx_ptr,                 # 每个 token 的专家索引
    N_per_expert_ptr,               # 每个专家的 token 数
    M, K, N,                        # M: token 总数, K: hidden, N: inter
    BLOCK_M: tl.constexpr,
    BLOCK_K: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    # 程序 ID 决定处理哪个 expert 的哪个 block
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    expert_id = tl.program_id(2)
    
    # 计算这个 expert 的 token 范围
    start_m = pid_m * BLOCK_M
    start_n = pid_n * BLOCK_N
    
    # 加载这个 expert 的权重 block
    w_ptrs = W_ptr + expert_id * K * N + start_n * K + tl.arange(0, BLOCK_K)[:, None] + tl.arange(0, BLOCK_N)[None, :] * K
    w = tl.load(w_ptrs, mask=...)
    
    # 累加计算
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k in range(0, K, BLOCK_K):
        x = tl.load(...)  # 加载 X block
        acc += tl.dot(x, w)
    
    # 写回
    tl.store(...)
```

实际 vLLM 用的是 CUTLASS 的 GroupedGEMM 模板，Triton 版性能差一些但更易读。

---

## 4. EP 部署实战

### 4.1 EP 的 token 流向

```
4 卡 EP,8 个专家:
卡 0: expert 0, 1
卡 1: expert 2, 3
卡 2: expert 4, 5
卡 3: expert 6, 7

输入 token 序列 [t0, t1, t2, t3, t4, t5] (batch=6, seq=1)
Router 决定:
  t0 → expert 1 (在卡 0)
  t1 → expert 3 (在卡 1)
  t2 → expert 0 (在卡 0)
  t3 → expert 5 (在卡 2)
  t4 → expert 4 (在卡 2)
  t5 → expert 7 (在卡 3)

all-to-all 通信:
  卡 0 收到 [t0, t2], 算 expert 0, 1
  卡 1 收到 [t1], 算 expert 3
  卡 2 收到 [t3, t4], 算 expert 4, 5
  卡 3 收到 [t5], 算 expert 7

反向 all-to-all: 把结果送回原卡
```

### 4.2 DeepSeek-V3 的部署

- 256 个 routed expert
- 8 卡 EP 每卡 32 个专家
- 加上 TP（每专家内部再切）
- 总并行配置通常是 EP × TP = 64 / 128 / 256

---

## 5. Expert Buffer / Expert Overflow 处理

### 5.1 问题：EP 下专家 token 数不均

batch 内 token 的路由分布不均，某张卡可能收到很多 token，显存或算力扛不住。

### 5.2 Expert Buffer

每张卡维护一个 buffer，超过容量的 token：
- 选项 A：丢弃（影响正确性，不可取）
- 选项 B：排队（增加延迟）
- 选项 C：溢出到 CPU 内存（带宽瓶颈）

vLLM/SGLang 用的是容量限制 + drop（在训练负载下，丢弃少量 token 影响有限）。推理场景下会用动态 batch 调度避免溢出。

---

## 6. MTP（Multi-Token Prediction）— DeepSeek 的投机解码

### 6.1 思路

DeepSeek-V3 训练时就让模型预测**多个未来 token**（不仅下一个）。推理时用这些 MTP 头做 draft，主模型做 verify。

本质：**MTP 头就是模型自带的 draft model**，不需要外接。

### 6.2 与 EAGLE 的区别

| 维度 | EAGLE | DeepSeek MTP |
|------|-------|--------------|
| 训练时是否参与 | 否（后训练） | 是（与主模型联合训练） |
| 草稿准确率 | 高 | 更高（与主模型对齐） |
| 部署复杂度 | 中 | 低（权重已在主模型里） |

---

## 7. vLLM / SGLang 中的 MoE 配置

### 7.1 vLLM 启动 DeepSeek-V3

```bash
vllm serve deepseek-ai/DeepSeek-V3 \
    --tensor-parallel-size 8 \
    --expert-parallel-size 8 \
    --enable-expert-parallel \
    --max-model-len 65536 \
    --gpu-memory-utilization 0.9
```

关键参数：
- `--tensor-parallel-size 8`: TP 切 attention 和每专家内部
- `--expert-parallel-size 8`: EP 切专家到 8 卡
- `--enable-expert-parallel`: 显式启用 EP

### 7.2 SGLang 的 MoE 优化

SGLang 针对 MoE 做了几个优化：
- **Data Parallel Attention**: attention 用 DP（每卡完整算），EP 只切 FFN
- 这避免了 attention 的 TP 通信开销
- DeepSeek-V3 在 SGLang 上吞吐比 vLLM 高 30%+（数据待核实）

---

## 8. 简化 MoE 推理实现（Python 教学版）

```python
import torch
import torch.nn as nn
import torch.nn.functional as F

class SimpleMoE(nn.Module):
    """教学版 MoE FFN,帮助理解流程"""
    
    def __init__(self, hidden, inter, num_experts=8, top_k=2):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k
        
        # Router: 一个线性层,输出每个专家的分数
        self.router = nn.Linear(hidden, num_experts, bias=False)
        
        # 专家权重: 三个矩阵 w1 (gate), w3 (up), w2 (down)
        # 用 3D tensor 存储,shape [num_experts, hidden, inter] 等
        self.w1 = nn.Parameter(torch.randn(num_experts, hidden, inter) * 0.02)
        self.w3 = nn.Parameter(torch.randn(num_experts, hidden, inter) * 0.02)
        self.w2 = nn.Parameter(torch.randn(num_experts, inter, hidden) * 0.02)
    
    def forward(self, x):
        """
        x: [batch, seq, hidden]
        return: [batch, seq, hidden]
        """
        b, s, h = x.shape
        x = x.view(b * s, h)  # 展平成 [token_num, hidden]
        
        # ===== 1. 路由 =====
        router_logits = self.router(x)              # [token_num, num_experts]
        router_probs = F.softmax(router_logits, dim=-1)
        # 选 top-k 专家
        topk_probs, topk_idx = router_probs.topk(self.top_k, dim=-1)
        # topk_idx: [token_num, k]
        # topk_probs: [token_num, k]
        
        # 重新归一化 top-k 概率(让和为1)
        topk_probs = topk_probs / topk_probs.sum(dim=-1, keepdim=True)
        
        # ===== 2. 朴素实现: for 循环每个专家 =====
        # 注意:这是教学版,真实系统用 grouped GEMM
        output = torch.zeros_like(x)
        
        for expert_id in range(self.num_experts):
            # 找出哪些 token 选了这个专家
            # mask: [token_num, k] -> 哪些 (token, k_slot) 选了 expert_id
            mask = (topk_idx == expert_id)
            if not mask.any():
                continue
            
            # 取出这些 token
            token_idx, k_slot = mask.nonzero(as_tuple=True)
            tokens_for_expert = x[token_idx]  # [n, hidden]
            
            # 这个专家的 GEMM (SiLU 激活)
            w1 = self.w1[expert_id]  # [hidden, inter]
            w3 = self.w3[expert_id]  # [hidden, inter]
            w2 = self.w2[expert_id]  # [inter, hidden]
            
            gate = tokens_for_expert @ w1  # [n, inter]
            up = tokens_for_expert @ w3    # [n, inter]
            hidden_act = F.silu(gate) * up  # SiLU(gate) * up
            expert_out = hidden_act @ w2   # [n, hidden]
            
            # 加权(用对应的 top-k 概率)
            weights = topk_probs[token_idx, k_slot].unsqueeze(-1)  # [n, 1]
            weighted_out = expert_out * weights
            
            # 累加到输出
            output.index_add_(0, token_idx, weighted_out)
        
        return output.view(b, s, h)


# 测试
if __name__ == "__main__":
    moe = SimpleMoE(hidden=64, inter=256, num_experts=8, top_k=2).cuda()
    x = torch.randn(2, 10, 64).cuda()  # batch=2, seq=10, hidden=64
    
    with torch.no_grad():
        y = moe(x)
    print(f"输入 shape: {x.shape}")
    print(f"输出 shape: {y.shape}")
    print(f"总参数: {sum(p.numel() for p in moe.parameters()) / 1e6:.1f}M")
    # 总参数大,但每个 token 实际激活参数少
```

**运行后思考**：
- 改 `num_experts` 从 8 到 64，参数量变化？
- 改 `top_k` 从 2 到 4，吞吐变化？
- 用 `nvidia-smi` 看显存占用，验证"参数大但激活小"。

---

## 9. 学习路径建议

1. **理解 MoE 论文**（GShard / Mixtral / DeepSeek-V3 技术报告）
2. **跑通上面的简化 MoE 代码** → 理解路由和加权合并
3. **对比 Dense FFN 和 MoE FFN** 的参数量、算力
4. **读 vLLM 的 `fused_moe.py`** → 看真实 Grouped GEMM
5. **跑 Mixtral-8x7B 推理** → 观察 expert load 分布
6. **读 DeepSeek-V3 技术报告** → 理解 256 专家 + MTP

---

## 10. 常见误区

1. **"MoE 模型推理更快"** — 不完全对。激活参数少所以算力小，但显存占用大，对带宽敏感。
2. **"专家越多越好"** — 错。专家越多路由开销大，负载均衡难，训练也难。
3. **"top_k=1 最快"** — 不一定。k=1 准确率低，k=2 是常用 sweet spot。
4. **"MoE 必须用 EP"** — 错。小 MoE（8 专家）单卡就能跑，EP 是大 MoE 的需求。
5. **"MTP 等于投机解码"** — MTP 是训练时机制，可以用于投机解码，但不是一回事。

---

## 11. 延伸阅读

- GShard 论文（MoE 早期）
- Mixtral 论文
- DeepSeek-V3 技术报告
- vLLM `fused_moe` 源码
- Triton `tutorial-09-persistent-matmul`（grouped GEMM 基础）

---

## 12. 速查表

| 模型 | 专家数 | top_k | 总参数 | 激活参数 |
|------|-------|-------|-------|---------|
| Mixtral-8x7B | 8 | 2 | 47B | 13B |
| DeepSeek-V2 | 160 | 6 | 236B | 21B |
| DeepSeek-V3 | 256 + 1 shared | 8 | 671B | 37B |
| Qwen-MoE-A14B | 60 | 4 | 57B | 14B |
