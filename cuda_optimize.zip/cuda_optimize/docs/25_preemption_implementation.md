﻿# Preemption 实现详解（RECOMPUTE vs SWAP）

> Preemption（抢占）是 vLLM 在 KV Cache 不够时把正在跑的请求踢出 running 队列的机制。理解它对调试 OOM 和延迟尾部队列至关重要。
>
> 学习定位：**理解 preemption 的触发条件、两种策略（RECOMPUTE 和 SWAP）的取舍、在简化引擎里实现它**。
>
> 前置知识：[06_paged_attention.md](06_paged_attention.md)、[07_continuous_batching.md](07_continuous_batching.md)、[18_service_metrics.md](18_service_metrics.md)。

---

## 0. 为什么需要 Preemption

### 0.1 现实场景

你部署了 Llama-3-70B 服务 100 个并发用户：
- KV Cache 容量够装 60 个请求
- 突然来了 80 个请求，60 个进 running，20 个排队
- 某个 running 请求的 context 涨到 4K，KV Cache 占用变多
- 现有 running 请求的 KV 总量超过容量

怎么办？
- 选项 A：拒绝新请求（用户体验差）
- 选项 B：让某些请求"暂停"，把 KV 让出来给更高优先级的（preemption）
- 选项 C：直接 OOM 崩溃（最差）

vLLM 用选项 B：preemption。

### 0.2 Preemption 的核心权衡

抢占一个请求的代价：
- 这个请求的进度被丢失（或暂存）
- 后续恢复时要重算（或换回）
- 用户感知：延迟变长

不抢占的代价：
- OOM 崩溃
- 或新请求无限等待

所以 preemption 是"为了不崩溃而做的有损降级"。

---

## 1. 两种 Preemption 策略

vLLM 支持两种策略，由 `--preemption-mode` 参数控制：

### 1.1 RECOMPUTE（默认）

**做法**：
1. 把请求踢出 running 队列
2. **释放它的所有 KV Cache 物理 block**（归还到 free pool）
3. 把请求放回 waiting 队列头部
4. 等显存空出来后，重新 prefill 这个请求

**优点**：
- 实现简单
- 显存立即释放（彻底）
- 不需要 CPU 内存中转

**缺点**：
- 之前的计算全部丢失
- 恢复时要重新 prefill 整个 prompt
- 长请求恢复延迟高

**适合**：短 prompt 场景，或 preemption 不频繁的场景。

### 1.2 SWAP

**做法**：
1. 把请求踢出 running 队列
2. **把 KV Cache 从 GPU 显存拷贝到 CPU 内存**（pinned memory）
3. 释放 GPU 上的 KV Cache block
4. 把请求放回 waiting 队列
5. 等显存空出来后，把 KV 从 CPU 拷回 GPU，继续 decode

**优点**：
- 之前的计算保留
- 恢复时只需要拷回 KV，不用重新 prefill
- 长请求恢复延迟低

**缺点**：
- 需要额外的 CPU 内存（pinned）
- 拷贝有开销（H2D / D2H 传输）
- 实现复杂

**适合**：长 prompt 场景，或 preemption 频繁的场景。

### 1.3 对比表

| 维度 | RECOMPUTE | SWAP |
|------|-----------|------|
| 显存释放 | 彻底 | 彻底 |
| 计算保留 | ❌ 全部丢失 | ✅ 保留 |
| 恢复开销 | 重新 prefill | H2D 拷贝 |
| CPU 内存需求 | 无 | 大 |
| 实现复杂度 | 低 | 高 |
| 适合场景 | 短 prompt | 长 prompt |
| vLLM 默认 | ✅ | - |

---

## 2. Preemption 触发条件

### 2.1 主动触发：调度时检测

每个调度 step，vLLM 检查：

```python
# 伪代码: 调度器决策
def schedule(self):
    # 1. 计算当前 running 请求需要的 KV 总量
    running_kv_demand = sum(req.kv_length for req in self.running)
    
    # 2. 计算 waiting 中新请求需要的 prefill KV
    new_prefill_demand = ...
    
    # 3. 总需求 vs 总供给
    total_demand = running_kv_demand + new_prefill_demand
    total_supply = self.kv_cache_total_capacity
    
    if total_demand > total_supply:
        # 需要抢占
        self._preempt_some_requests(total_demand - total_supply)
```

### 2.2 抢占对象选择

vLLM 的策略：**抢占最后进来的请求**（LIFO）。

为什么 LIFO：
- 最后进来的请求 prompt 短，recompute 代价小
- 最早进来的请求可能已经生成了很多 token，保留它更划算
- 实现简单

### 2.3 被动触发：突发 OOM

偶尔会发生显存碎片导致的 OOM（即使理论上够用）。vLLM 会 emergency preempt 一些请求避免崩溃。

---

## 3. vLLM Preemption 实现

### 3.1 关键代码位置

- `vllm/core/scheduler.py`：`_preempt` 方法
- `vllm/core/block_manager.py`：物理 block 的分配/释放
- `vllm/worker/worker.py`：SWAP 时的 CPU 内存管理

### 3.2 RECOMPUTE 流程

```python
def _preempt(self, req, num_tokens_to_free):
    """RECOMPUTE 策略"""
    # 1. 释放该请求的所有 KV block
    self.block_manager.free_block_table(req.block_table)
    
    # 2. 重置请求状态
    req.current_length = 0
    req.kv_cache = None
    
    # 3. 把请求放回 waiting 队列头部
    self.waiting.insert(0, req)
    
    # 4. 从 running 队列移除
    self.running.remove(req)
```

### 3.3 SWAP 流程

```python
def _preempt_swap(self, req):
    """SWAP 策略"""
    # 1. 在 CPU 上分配 pinned memory
    cpu_kv = torch.empty(
        req.kv_length, num_layers, num_heads, head_dim,
        dtype=dtype, device="cpu", pin_memory=True,
    )
    
    # 2. 把 GPU KV 拷到 CPU
    for layer_idx in range(num_layers):
        cpu_kv[layer_idx] = self.gpu_kv_cache[layer_idx, req.block_table]
    
    # 3. 释放 GPU block
    self.block_manager.free_block_table(req.block_table)
    req.swap_cpu_kv = cpu_kv
    
    # 4. 把请求放回 waiting (带 swap 标记)
    self.waiting.insert(0, req)
    self.running.remove(req)


def _swap_in(self, req):
    """恢复 SWAP 的请求"""
    # 1. 重新分配 GPU block
    self.block_manager.allocate_block_table(req, req.kv_length)
    
    # 2. 把 CPU KV 拷回 GPU
    for layer_idx in range(num_layers):
        self.gpu_kv_cache[layer_idx, req.block_table] = req.swap_cpu_kv[layer_idx]
    
    # 3. 释放 CPU 内存
    req.swap_cpu_kv = None
    
    # 4. 请求回到 running 队列
    self.running.append(req)
    self.waiting.remove(req)
```

### 3.4 监控 preemption

vLLM 暴露的指标：

```
vllm:num_preemption                  # 累计抢占次数
vllm:num_preemption_rate             # 抢占率
```

如果抢占率高，说明：
- KV Cache 容量不够 → 量化 KV / 增大显存
- 调度策略问题 → 调 `--max-num-seqs`

---

## 4. 简化实现（教学版）

下面是一个简化的 preemption 实现，配合 [10_inference_engine/python/](../10_inference_engine/python/)。

```python
"""
preemption_demo.py — Preemption 两种策略对比

配合 [docs/25_preemption_implementation.md](../docs/25_preemption_implementation.md) 使用。

演示:
    1. 模拟 KV Cache 不够的场景
    2. RECOMPUTE 策略: 丢弃 KV,重新 prefill
    3. SWAP 策略: KV 拷到 CPU,恢复时拷回
    4. 对比两种策略的"恢复延迟"

不依赖真实模型,用假数据演示流程。
"""
```

完整代码见 [10_inference_engine/python/preemption_demo.py](../10_inference_engine/python/preemption_demo.py)。

---

## 5. Preemption 对性能的影响

### 5.1 延迟影响

假设一个请求被抢占后 5 秒恢复：

| 场景 | RECOMPUTE 恢复延迟 | SWAP 恢复延迟 |
|------|-------------------|--------------|
| prompt=100, output=50 | ~50ms (重算 100 token) | ~10ms (拷回) |
| prompt=2000, output=200 | ~500ms (重算 2000 token) | ~50ms (拷回) |
| prompt=10000, output=500 | ~2500ms (重算 10000 token) | ~200ms (拷回) |

**短 prompt RECOMPUTE 够用，长 prompt 必须 SWAP**。

### 5.2 吞吐影响

RECOMPUTE 浪费算力（重新 prefill 等于白做一次）。
SWAP 浪费带宽（H2D 拷贝占用 PCIe）。

两者都有代价，但都比 OOM 强。

### 5.3 P99 延迟影响

被抢占的请求会经历：
- 抢占：被踢出 running
- 等待：在 waiting 排队
- 恢复：recompute 或 swap

整个过程可能几秒，P99 延迟暴涨。

**生产环境要尽量避免 preemption**：
- 留足 KV Cache buffer
- 限制 max_num_seqs 防止过载
- 用量化扩大 KV Cache 容量

---

## 6. 避免 Preemption 的策略

### 6.1 增大 KV Cache 容量

- KV Cache 量化（INT8 / INT4）
- 增大 `--gpu-memory-utilization`（但要留 buffer）
- 用更大显存的 GPU

### 6.2 限制并发

- `--max-num-seqs 32`：限制同时处理的请求数
- 宁可让请求排队，也不要 preemption

### 6.3 调度策略

- `--scheduler-policy fcfs`：先来先服务，避免饥饿
- 限制单请求最大长度 `--max-model-len`

### 6.4 PD 分离

- Prefill 节点和 Decode 节点分开
- 避免 prefill 抢 decode 的资源
- 详见 [15_distributed_inference.md](15_distributed_inference.md)

---

## 7. vLLM Preemption 调参

### 7.1 关键参数

```bash
vllm serve meta-llama/Llama-3-8B \
    --preemption-mode swap \              # 或 recompute (默认)
    --max-num-seqs 32 \                   # 限制并发,减少抢占
    --gpu-memory-utilization 0.9 \        # KV Cache 比例
    --swap-space 16                       # CPU swap 内存 (GB),仅 SWAP 模式
```

### 7.2 调参经验

| 现象 | 调整 |
|------|-----|
| 频繁 preemption | 增大 swap-space / 减小 max-num-seqs |
| 长 prompt 恢复慢 | 用 SWAP 模式 |
| 短 prompt 场景 | 用 RECOMPUTE 模式（默认） |
| 显存碎片严重 | 减小 gpu-memory-utilization |

---

## 8. SGLang 的 Preemption

SGLang 的 preemption 类似但有差异：
- 基于 RadixCache，抢占时优先 evict 不常用的 prefix
- 不需要显式 swap，因为 RadixCache 本身就有 LRU
- 抢占代价更低（只丢 prefix cache，不丢请求进度）

这是 SGLang 在多轮对话场景下 P99 延迟更低的原因之一。

---

## 9. 学习路径建议

1. **跑 [10_inference_engine/python/preemption_demo.py](../10_inference_engine/python/preemption_demo.py)** → 理解两种策略
2. **在 vLLM 触发 preemption**：用小显存 + 大 batch，看 preemption 指标
3. **对比 RECOMPUTE vs SWAP** → 跑长 prompt 场景
4. **读 vLLM `_preempt` 源码** → 看工业实现
5. **给 [10_inference_engine/python/scheduler.py](../10_inference_engine/python/scheduler.py) 加 preemption** → 作为练习

---

## 10. 常见误区

1. **"Preemption 是 bug"** — 错。是设计好的容错机制，避免 OOM。
2. **"SWAP 一定比 RECOMPUTE 快"** — 不一定。短 prompt recompute 更快。
3. **"抢占的请求会丢失进度"** — 错。RECOMPUTE 丢失，SWAP 保留。
4. **"调大 batch 就不需要 preemption"** — 错。batch 大反而更易触发。
5. **"Preemption 不影响用户体验"** — 错。被抢占的请求 P99 延迟暴涨。

---

## 11. 速查表

| 项目 | RECOMPUTE | SWAP |
|------|-----------|------|
| 触发 | KV Cache 不够 | 同 |
| 行为 | 释放 KV,重置请求 | KV 拷到 CPU |
| 恢复 | 重新 prefill | H2D 拷回 |
| 适合 | 短 prompt | 长 prompt |
| CPU 内存需求 | 无 | 大 |
| vLLM 默认 | ✅ | - |
| 切换参数 | `--preemption-mode recompute` | `--preemption-mode swap` |
| 监控指标 | `vllm:num_preemption` | 同 |
