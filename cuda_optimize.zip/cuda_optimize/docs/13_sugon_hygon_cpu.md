# 曙光专篇1：海光 CPU 推理优化 — 中科曙光入职必学

> 目标：掌握海光 CPU 架构特性，学会在海光平台上做推理优化（CPU 侧）。
> 中科曙光的智算集群中，海光 CPU 承担数据预处理、调度编排、轻量推理等任务。
> 预计时间：3 天（作为第0周的补充模块）

---

## 目录

1. [海光 CPU 架构概述](#1-海光-cpu-架构概述)
2. [AVX/AMX 向量加速](#2-avxamx-向量加速)
3. [CPU 亲和性与绑核](#3-cpu-亲和性与绑核)
4. [NUMA 架构与调度优化](#4-numa-架构与调度优化)
5. [HugePage 大页内存](#5-hugepage-大页内存)
6. [推理场景中的应用](#6-推理场景中的应用)
7. [配套实例](#7-配套实例)

---

## 1. 海光 CPU 架构概述

### 1.1 海光 CPU 产品线

海光 CPU（Hygon）基于 x86 架构，兼容 AMD Zen 微架构：

```
海光 7000 系列（服务器）：
  - 最多 32 核/64 线程
  - 支持 AVX2、AVX-512（部分型号）
  - 8 通道 DDR4 内存
  - NUMA 架构（2~4 个 NUMA node）

海光 5000 系列（中端服务器）：
  - 最多 16 核/32 线程
  - 支持 AVX2
  - 4 通道 DDR4 内存

海光 3000 系列（工作站）：
  - 最多 8 核/16 线程
  - 适合开发测试
```

### 1.2 与 Intel/AMD CPU 的兼容性

```
海光 CPU 兼容 Intel/AMD 的主流优化库：
  ✅ OpenVINO（Intel 推理框架）— 可适配
  ✅ OneDNN（原 MKL-DNN）— 原生支持
  ✅ BLAS / LAPACK — 可用
  ⚠️ MKL（Intel Math Kernel Library）— 可能受限
  ✅ AMX（Advanced Matrix Extensions）— 部分型号支持

关键点：推理场景中 CPU 侧的主要工作是
  1. Tokenization / Detokenization
  2. 数据预处理（图像/文本）
  3. 轻量模型推理（小模型在 CPU 上跑）
  4. 调度编排（K8s 调度前处理）
```

### 1.3 推理场景中海光 CPU 的角色

```
在曙光智算集群中，CPU 承担：

┌──────────────────────────────────────────────────────┐
│  Client 请求                                          │
│      ↓                                                │
│  ┌────────────────────────┐                           │
│  │  海光 CPU（调度节点）   │                           │
│  │  ├─ Tokenizer          │ ← CPU 密集（分词器运算）  │
│  │  ├─ 请求排队/限流      │ ← 内存/锁操作             │
│  │  ├─ 数据预处理         │ ← 图像缩放/normalize      │
│  │  └─ 结果后处理         │ ← detokenize + filter     │
│  └──────────┬─────────────┘                           │
│             ↓ 推理请求                                 │
│  ┌────────────────────────┐                           │
│  │  DCU 深算一号（GPU）   │                           │
│  │  ├─ Prefill            │ ← 计算密集型（DCU 执行）  │
│  │  ├─ Decode             │ ← memory-bound             │
│  │  └─ Sampling           │ ← CPU 可能更优            │
│  └────────────────────────┘                           │
└──────────────────────────────────────────────────────┘

CPU 瓶颈点：
  1. Tokenizer 速度（LLaMA tokenizer 在 CPU 上跑）
  2. 请求调度延迟（高并发下锁竞争）
  3. 后处理（beam search 候选排序）
```

---

## 2. AVX/AMX 向量加速

### 2.1 AVX（Advanced Vector Extensions）

AVX 是 x86 CPU 的 SIMD（单指令多数据）指令集：

```
AVX:     128 位寄存器 → 同时处理 4 个 float 或 2 个 double
AVX2:    256 位寄存器 → 同时处理 8 个 float
AVX-512: 512 位寄存器 → 同时处理 16 个 float（海光部分型号支持）

速度提升：
  标量加法:  一次加 1 个数
  AVX2:      一次加 8 个数 → 理论上 8x 加速
  AVX-512:   一次加 16 个数 → 理论上 16x 加速
```

### 2.2 AVX 编程示例

```cpp
// 标量版本：一次计算 1 个 float
void add_arrays_scalar(float* a, float* b, float* c, int n) {
    for (int i = 0; i < n; i++) {
        c[i] = a[i] + b[i];
    }
}

// AVX2 版本：一次计算 8 个 float
#include <immintrin.h>  // Intel 内联函数头文件

void add_arrays_avx2(float* a, float* b, float* c, int n) {
    int i = 0;
    // 每次处理 8 个元素（256 位 / 32 位 = 8）
    for (; i <= n - 8; i += 8) {
        // _mm256_load_ps: 从内存加载 8 个 float 到 AVX 寄存器
        __m256 va = _mm256_load_ps(&a[i]);
        __m256 vb = _mm256_load_ps(&b[i]);
        // _mm256_add_ps: 8 个 float 并行加法
        __m256 vc = _mm256_add_ps(va, vb);
        // _mm256_store_ps: 将结果写回内存
        _mm256_store_ps(&c[i], vc);
    }
    // 处理剩余元素
    for (; i < n; i++) {
        c[i] = a[i] + b[i];
    }
}
```

### 2.3 AMX（Advanced Matrix Extensions）

AMX 是比 AVX 更新的矩阵加速指令（Intel Sapphire Rapids 引入，海光部分型号支持）：

```
AMX 特点：
  - 专门为矩阵乘法设计（GEMM）
  - 寄存器是 tile（瓷砖），不是向量
  - 一次可做 16×64 × 64×16 的矩阵乘
  - 比 AVX-512 再快 4-8x

推理场景：
  CPU 上的 INT8 GEMM（权重量化后的小模型推理）
  比如 7B 模型量化到 INT4/INT8 后在 CPU 上跑
```

### 2.4 在 OneDNN 中使用

实际工程中**不需要手写 AVX**，而是用 OneDNN 库自动优化：

```python
# OneDNN 自动利用 AVX/AMX
# vLLM CPU backend 使用 OneDNN
import torch

# 在 CPU 上运行，OneDNN 自动选择最优指令集
# 环境变量控制：
# export ONEDNN_VERBOSE=1       # 查看使用了什么指令
# export ONEDNN_MAX_CPU_ISA=AVX512  # 限制指令集

# PyTorch 默认使用 OneDNN
model = model.to('cpu')
with torch.no_grad():
    output = model(input_ids)

# 验证是否生效
# 设置 ONEDNN_VERBOSE=1 后运行，日志会显示：
# onednn_verbose,info,engine,host,cpu,runtime,1 processor
# onednn_verbose,exec,gemv,float32,...  ← 实际执行的指令
```

---

## 3. CPU 亲和性与绑核

### 3.1 什么是 CPU 亲和性

CPU 亲和性（Affinity）控制**进程/线程在哪些 CPU 核心上运行**。

```
没有绑核：
  进程 A 可以在任意核心间迁移
  → cache 频繁失效（L1/L2 cache 是每核私有的）
  → 性能下降 30-50%

有绑核：
  进程 A 固定运行在核心 0-3
  → cache 命中率提高
  → 性能稳定
```

### 3.2 Linux taskset 绑核

```bash
# 查看 CPU 拓扑
lscpu
# 输出示例：
# Architecture:        x86_64
# CPU(s):              64
# Thread(s) per core:  2
# Core(s) per socket:  16
# Socket(s):           2          ← 2 路 CPU
# NUMA node(s):        4          ← 4 个 NUMA 节点
# NUMA node0 CPU(s):   0-7,32-39
# NUMA node1 CPU(s):   8-15,40-47
# ...

# 将一个进程绑定到核心 0-3
taskset -c 0-3 python inference.py

# 将进程绑定到 NUMA node 0
numactl --cpunodebind=0 --membind=0 python inference.py

# 查看进程当前绑定的 CPU
taskset -p <PID>
```

### 3.3 vLLM CPU backend 的绑核策略

```python
# vLLM CPU backend（曙光适配版）的绑核策略：
# 1. CPU 推理线程绑定到物理核（避开超线程）
# 2. 每个推理线程独占一个核心
# 3. 预留核心给 OS 和中断处理

# 启动 vLLM CPU 模式
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --device cpu \           # 使用 CPU backend
    --cpu-kvcache-space 8 \  # CPU KV cache 大小（GB）
    --num-cpu-threads 16 \   # 推理线程数（等于物理核数）
    --pipeline-parallel-size 1
```

### 3.4 C++ 代码中绑核

```cpp
// 在 C++ 代码中绑核（不需要 taskset 命令）
// vLLM csrc 的 CPU backend 使用类似代码

#include <sched.h>    // Linux CPU 亲和性 API
#include <pthread.h>  // POSIX 线程

void bind_thread_to_core(int core_id) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);          // 清空集合
    CPU_SET(core_id, &cpuset);  // 添加 core_id 到集合

    pthread_t current_thread = pthread_self();
    int ret = pthread_setaffinity_np(
        current_thread,
        sizeof(cpu_set_t),
        &cpuset
    );
    if (ret != 0) {
        fprintf(stderr, "绑核失败: core %d (errno=%d)\n",
                core_id, errno);
    }
}

// 推理线程池初始化
void init_inference_threads(int num_threads) {
    for (int i = 0; i < num_threads; i++) {
        std::thread t([i]() {
            // 每个线程绑定到不同的核心
            bind_thread_to_core(i);

            // 线程的推理循环
            while (running) {
                // 处理推理请求
            }
        });
        threads.push_back(std::move(t));
    }
}
```

---

## 4. NUMA 架构与调度优化

### 4.1 NUMA 是什么

NUMA（Non-Uniform Memory Access）— 非统一内存访问：

```
Socket 0 (海光 CPU 0)          Socket 1 (海光 CPU 1)
┌─────────────────────┐        ┌─────────────────────┐
│  Core 0  Core 1 ... │        │  Core 16 Core 17 .. │
│  L1/L2 cache   │    │        │  L1/L2 cache   │   │
│  L3 cache (shared) │        │  L3 cache (shared)  │
│         │          │        │         │           │
│   Memory Controller │        │   Memory Controller │
└─────────┼──────────┘        └─────────┼───────────┘
          │                             │
       ┌──┴─────────────────────────────┴──┐
       │      DDR4 Memory (256 GB)         │
       │  (Node 0: 0-127 GB, Node 1: 128-256 GB)
       └──────────────────────────────────┘
```

```
访问延迟对比：
  CPU 0 → 自己的内存（Node 0）:  ~100 ns  ← 快
  CPU 0 → CPU 1 的内存（Node 1）: ~180 ns  ← 慢 80%!
  CPU 0 → CPU 2 的内存（Node 2）: ~250 ns  ← 更远
```

**推理优化关键**：**CPU 和 DCU 如果在同一个 NUMA 节点上，数据传输更快**。

### 4.2 NUMA 感知调度策略

```python
# 推理部署时的 NUMA 调度策略

# 策略 1：推理进程和 DCU 绑定到同一个 NUMA 节点
# DCU 深算一号的 PCIe 连接到某个 NUMA 节点
# 查看 DCU 所在 NUMA 节点：
nvidia-smi topo -m  # NVIDIA GPU
# 对 DCU 用：rocm-smi --showtopo 或 cat /sys/class/drm/card*/device/numa_node

# 策略 2：numactl 绑定
# 假设 DCU 在 NUMA node 0，推理进程也绑定到 node 0
numactl --cpunodebind=0 --membind=0 python inference_server.py

# 策略 3：多实例部署（每个 NUMA node 一个推理实例）
# Node 0: 实例 A，监听端口 8000
numactl --cpunodebind=0 --membind=0 \
    python -m vllm.entrypoints.openai.api_server --port 8000

# Node 1: 实例 B，监听端口 8001
numactl --cpunodebind=1 --membind=1 \
    python -m vllm.entrypoints.openai.api_server --port 8001

# 前端负载均衡：nginx 把请求分发到 8000 和 8001
```

### 4.3 查看 NUMA 拓扑的命令

```bash
# 查看 NUMA 节点信息
numactl --hardware
# available: 4 nodes (0-3)
# node 0 cpus: 0 1 2 3 4 5 6 7 32 33 34 35 36 37 38 39
# node 0 size: 65452 MB
# node 1 cpus: 8 9 10 11 12 13 14 15 40 41 42 43 44 45 46 47
# node 1 size: 65536 MB
# ...

# 查看进程的 NUMA 策略
cat /proc/$(pgrep python)/numa_maps

# 查看当前内存分配在哪个 NUMA 节点
numastat -p $(pgrep python)

# 查看 DCU 所在 NUMA 节点
cat /sys/class/drm/card0/device/numa_node
```

---

## 5. HugePage 大页内存

### 5.1 为什么需要大页

```
标准内存页大小 = 4 KB

模型权重加载：
  模型 7B = 7 × 10^9 个参数 × 2 bytes (FP16) ≈ 14 GB
  14 GB / 4 KB = 3,580,000 个页  ← TLB 完全不够用！

大页 (2MB / 1GB)：
  2MB 大页：14GB / 2MB = 7000 个页 → TLB 命中率大幅提高
  1GB 大页：14GB / 1GB = 14 个页 → 全部在 TLB 中！

性能提升：推理场景中 HugePage 可带来 10-30% 的速度提升
（因为 TLB miss 减少了）
```

### 5.2 配置 HugePage

```bash
# 1. 查看当前大页配置
cat /proc/meminfo | grep Huge
# HugePages_Total:  0        ← 未配置
# Hugepagesize:     2048 kB  ← 每页 2MB

# 2. 配置 2MB 大页（分配 8192 个 = 16 GB）
echo 8192 > /proc/sys/vm/nr_hugepages
# 或者持久化到 /etc/sysctl.conf
echo "vm.nr_hugepages=8192" >> /etc/sysctl.conf

# 3. 配置 1GB 大页（需要内核启动参数）
# 在 GRUB 启动参数中添加：
# default_hugepagesz=1G hugepagesz=1G hugepages=16
# 重启后生效

# 4. 验证配置
cat /proc/meminfo | grep Huge
# HugePages_Total:    8192
# HugePages_Free:     8192
```

### 5.3 在推理框架中启用大页

```python
# vLLM CPU backend 启用 HugePage
# 启动时添加参数：
python -m vllm.entrypoints.openai.api_server \
    --device cpu \
    --use-huge-pages \          # 启用大页
    --cpu-kvcache-space 8       # KV cache 使用大页

# 源码层面（C++ 侧）启用大页
#include <sys/mman.h>

void* allocate_hugepages(size_t size) {
    // 用 mmap 分配 2MB 对齐的内存
    void* ptr = mmap(
        NULL,
        size,
        PROT_READ | PROT_WRITE,
        MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB,
        -1,
        0
    );
    if (ptr == MAP_FAILED) {
        perror("HugePage allocation failed");
        // fallback 到普通内存
        ptr = aligned_alloc(4096, size);
    }
    return ptr;
}

// 释放大页
void free_hugepages(void* ptr, size_t size) {
    munmap(ptr, size);
}
```

---

## 6. 推理场景中的应用

### 6.1 曙光推理集群的 CPU 优化清单

```
部署前必做的 CPU 优化（曙光运维 SRE 必会）：

1. BIOS 设置：开启 Performance Mode，关掉 C-State 节能
2. 内核参数 (/etc/sysctl.conf)：
   vm.nr_hugepages=8192          # 大页
   kernel.numa_balancing=0       # 关闭 NUMA balancing（减少抖动）
   vm.swappiness=1               # 尽量少用 swap
   net.core.somaxconn=65536      # 增大 socket 队列

3. 关闭不必要的服务（减少中断干扰）：
   systemctl stop irqbalance      # 关掉中断平衡（推理线程自己绑核）
   systemctl stop tuned           # 关掉动态调优

4. 推理进程启动命令：
   numactl --cpunodebind=0 --membind=0 \
   taskset -c 0-15,32-47 \       # 只绑物理核
       python inference.py
```

### 6.2 一个典型的曙光推理节点部署脚本

```bash
#!/bin/bash
# 曙光推理节点部署脚本 deploy_inference_node.sh
set -e

echo "=== 曙光推理节点初始化 ==="

# 1. 设置大页
echo "配置 HugePage..."
echo 16384 > /proc/sys/vm/nr_hugepages
echo "vm.nr_hugepages=16384" >> /etc/sysctl.conf

# 2. 设置内核参数
echo "配置内核参数..."
cat >> /etc/sysctl.conf << EOF
kernel.numa_balancing=0
vm.swappiness=1
net.core.somaxconn=65536
net.ipv4.tcp_tw_reuse=1
EOF
sysctl -p

# 3. 关掉 irqbalance
echo "关闭 irqbalance..."
systemctl stop irqbalance || true

# 4. 查看 DCU 所在 NUMA 节点
DCU_NODE=$(cat /sys/class/drm/card0/device/numa_node)
echo "DCU 在 NUMA node: $DCU_NODE"

# 5. 启动 vLLM 推理服务（绑定到 DCU 所在 NUMA 节点）
echo "启动推理服务..."
numactl --cpunodebind=$DCU_NODE --membind=$DCU_NODE \
    python -m vllm.entrypoints.openai.api_server \
        --model /data/models/llama-7b \
        --tensor-parallel-size 4 \
        --gpu-memory-utilization 0.9 \
        --max-num-seqs 32 \
        --port 8000 \
        > /var/log/vllm.log 2>&1 &

echo "部署完成！PID: $!"
```

---

## 7. 配套实例

实例代码目录：[cpp_infra/src/cpu_optimize/](../cpp_infra/src/cpu_optimize/)

```bash
# 编译 CPU 优化示例
cd cpp_infra && mkdir -p build && cd build
cmake .. -DENABLE_CPU_OPTIMIZE=ON
cmake --build .

# AVX2 向量加法示例
./avx_demo

# 绑核示例
./bind_core_demo

# HugePage 分配示例
./hugepage_demo

# 工具命令
lscpu                    # CPU 架构信息
numactl --hardware       # NUMA 拓扑
cat /proc/meminfo | grep Huge  # 大页状态
taskset -p <PID>         # 查看进程绑核
```
