# 第5周：vLLM 架构总览 — 推理优化方向

> 目标：从整体把握 vLLM 的模块划分、核心数据流和执行流程，为深入阅读 PagedAttention 和 Scheduler 源码打基础。
> 预计时间：周均 7h（每天 ~1h）

---

## 目录

1. [vLLM 整体架构图](#1-vllm-整体架构图)
2. [核心模块职责](#2-核心模块职责)
3. [LLMEngine 入口流程](#3-llmengine-入口流程)
4. [vLLM V1 架构变化（2024年重写）](#4-vllm-v1-架构变化)
5. [部署与实验](#5-部署与实验)
6. [面试考点](#6-面试考点)

---

## 1. vLLM 整体架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                      LLM Engine (入口/协调)                      │
│  LLM class → LLMEngine → Output                                    │
└──────────┬──────────────────────────────────────────┬──────────┘
           │                                          │
           ▼                                          ▼
┌──────────────────────┐              ┌──────────────────────────┐
│     Scheduler         │              │      Model Runner        │
│  (调度/批处理)         │              │  (模型执行)              │
│                      │              │                          │
│  Waiting Queue       │              │  GPU Worker              │
│  Running Batch       │─────────────►│    │                     │
│  Swapped Queue       │  GPU ops     │    ├─ Model Forward      │
│                      │              │    ├─ Attention Backend  │
│  Block Manager       │              │    ├─ Sampling            │
│  (显存页管理)         │              │    └─ LoRA (可选)        │
└──────────────────────┘              └──────────────────────────┘
         │                                       │
         ▼                                       ▼
┌──────────────────────┐              ┌──────────────────────────┐
│  Block Manager        │              │  Attention Backends      │
│                      │              │                          │
│  ┌─────────────────┐  │              │  ┌─────────────────────┐ │
│  │ Physical Block   │  │              │  │ flash_attn          │ │
│  │ Allocator        │  │              │  │ (FlashAttention-2) │ │
│  ├─────────────────┤  │              │  ├─────────────────────┤ │
│  │ Logical → Phys   │  │              │  │ flash_attn_varlen   │ │
│  │ Mapping Table    │  │              │  │ (变长序列)          │ │
│  ├─────────────────┤  │              │  ├─────────────────────┤ │
│  │ Prefix Cache     │  │              │  │ paged_attention     │ │
│  │ (自动前缀缓存)    │  │              │  │ (vLLM 自定义 triton)│ │
│  └─────────────────┘  │              │  └─────────────────────┘ │
└──────────────────────┘              └──────────────────────────┘
```

---

## 2. 核心模块职责

### 2.1 LLMEngine — 中央协调器

文件位置：`vllm/v1/engine/engine.py`（V1）或 `vllm/engine/llm_engine.py`

职责：
```
1. 接收请求（prompt + sampling params）
2. 将请求转发给 Scheduler 调度
3. 调用 Model Runner 执行计算
4. 收集输出 tokens，返回给调用方
5. 管理异步/同步模式
```

关键数据结构：
```python
# 每个请求的内部表示
class Request:
    request_id: str          # 唯一标识
    prompt: List[int]        # tokenized prompt
    sampling_params: SamplingParams  # temperature, top_p, top_k, max_tokens
    arrival_time: float      # 到达时间
    state: RequestState      # WAITING / RUNNING / FINISHED
    num_tokens: int          # 已生成的 token 数
    block_ids: List[int]     # 分配的 KV cache block IDs
```

### 2.2 Scheduler — 调度器

文件位置：`vllm/v1/core/scheduler.py`（V1）或 `vllm/core/scheduler.py`（V0）

Scheduler 决定**每步推理执行哪些请求**。

三队列状态机：
```
     ┌──────────┐   足够显存    ┌──────────┐   完成    ┌──────────┐
     │  WAITING  │ ──────────► │  RUNNING  │ ────────► │ FINISHED │
     │  (等待)   │              │  (执行中)  │           │  (完成)   │
     └──────────┘              └──────────┘           └──────────┘
           ▲                        │
           │      显存不足           │
           │  ──────────────────────┤
           │                        ▼
           │                 ┌──────────┐
           └─────────────────┤ SWAPPED  │
                             │ (已换出)  │
                             └──────────┘
```

调度策略（V1 的 simpler 调度逻辑）：
```
每次 schedule 迭代：
1. 将所有 WAITING 请求尝试加入 RUNNING
2. 检查显存（KV cache block）是否足够
3. 如果不足，先 swap out 一些请求到 CPU
4. 将 RUNNING + 新加入的请求组成 batch
5. 执行 model forward
6. 收集输出，更新请求状态
```

### 2.3 Model Runner — 模型执行

文件位置：`vllm/v1/worker/gpu_model_runner.py`

职责：
```
1. 管理模型权重（加载/卸载/量化）
2. 准备 GPU 输入 tensor（将 token ids → embeddings）
3. 执行 model forward pass
4. 调用 attention backend
5. 采样下一个 token
```

关键路径：
```
Input tokens
    → Embedding lookup
    → Transformer layers × N:
        ├─ Attention (调用 attention backend)
        │   ├─ QKV projection (GEMM)
        │   ├─ Attention compute (flash_attn / paged_attn)
        │   └─ Output projection (GEMM)
        └─ FFN:
            ├─ up/gate projection (GEMM)
            └─ down projection (GEMM)
    → LayerNorm
    → LM Head (vocab projection GEMM)
    → Sampling (argmax / top-k / top-p)
```

### 2.4 Attention Backend — 注意力后端

文件位置：`vllm/v1/attention/`（V1） 或 `vllm/attention/`（V0）

vLLM 支持多种 attention 实现：
```
flash_attn          — FlashAttention-2/3 官方实现
flash_attn_varlen   — 变长序列优化版
paged_attention     — vLLM 自定义 PagedAttention kernel（Triton 实现）
```

**选择逻辑**：
```python
# 伪代码：vLLM 选择 attention backend 的逻辑
if use_flash_attn and enable_flash_attn:
    backend = FlashAttentionBackend()
elif use_paged_attn:
    backend = PagedAttentionBackend()
else:
    backend = VanillaAttentionBackend()

# 实际调度策略更复杂，取决于：
# - 是否使用 FlashAttention 库（默认 yes）
# - 是否使用 vLLM block manager（default yes）
# - GPU 架构是否支持（H100 有更好的 backend）
```

---

## 3. LLMEngine 入口流程

### 3.1 请求处理流水线

```python
# 简化版 vLLM 推理循环
class LLMEngine:
    async def add_request(self, prompt, sampling_params):
        """添加请求到调度器"""
        request = Request(
            prompt=tokenizer(prompt),
            sampling_params=sampling_params,
        )
        self.scheduler.add_request(request)

    def step(self) -> List[RequestOutput]:
        """单步推理（核心循环）"""

        # 1. 调度：决定这次推理执行哪些请求
        scheduler_output = self.scheduler.schedule()

        # 2. 准备模型输入
        model_input = self.model_runner.prepare_input(scheduler_output)

        # 3. 执行模型 forward
        hidden_states = self.model_runner.execute_model(model_input)

        # 4. 采样下一个 token
        next_tokens = self.sampler.sample(hidden_states, scheduler_output)

        # 5. 更新 KV cache block 引用
        self.block_manager.update_access_times(next_tokens)

        # 6. 更新请求状态
        outputs = []
        for req_id, token in next_tokens.items():
            request = self.scheduler.requests[req_id]
            request.append_token(token)
            if request.is_finished():
                request.state = RequestState.FINISHED
            outputs.append(RequestOutput(request))

        return outputs
```

### 3.2 执行模式对比

| 模式 | 接口 | 适用场景 | 代码入口 |
|------|------|---------|----------|
| 同步 (sync) | `llm.generate()` | Python SDK、离线推理 | `vllm/entrypoints/llm.py` |
| 异步 (async) | `async for output in llm.generate()` | 高并发离线处理 | 同上 |
| OpenAI API | HTTP POST `/v1/chat/completions` | 在线部署、生产环境 | `vllm/entrypoints/openai/` |

### 3.3 V0 vs V1 关键变化

V1（2024年新架构）的关键改进：

| 特性 | V0 | V1 |
|------|----|----|
| 代码结构 | 单一大文件 `scheduler.py` ~2.5K 行 | `v1/core/` 拆分为 6+ 模块 |
| 调度逻辑 | 复杂的状态机，多条件混合 | 简化的 `schedule()`，状态分解 |
| Block 管理 | `BlockSpaceManager` 耦合调度 | 独立的 `BlockManager` |
| 显存管理 | 静态 page 预留 | 动态分配，行为更可预测 |
| 前缀缓存 | 可选功能 | 默认集成 |
| 多步调度 | 不支持 | 支持 Multi-Step Scheduler |

**V1 核心文件结构**：
```
vllm/v1/core/
├── __init__.py
├── scheduler.py          # 调度器主逻辑
├── block_manager.py      # KV cache 块管理器
├── block_pool.py         # 块池化分配
├── block_table.py        # 逻辑→物理地址映射表
├── config.py             # 调度/显存配置
└── scheduler_utils.py    # 调度工具函数

vllm/v1/engine/
├── __init__.py
├── engine.py             # LLMEngine V1
└── core.py               # 引擎核心逻辑

vllm/v1/worker/
├── __init__.py
├── gpu_model_runner.py   # GPU 模型执行
└── ... (其他 worker 相关)
```

---

## 4. 关键数据结构关系图

```python
# V1 BlockTable / BlockManager 数据结构（简化）

# 逻辑 block 到物理 block 的映射
class LogicalTokenBlock:
    """逻辑上的 token 块（请求看到的连续地址空间）"""
    block_number: int          # 逻辑 block 编号
    block_size: int            # 块大小（通常 16 tokens）
    num_tokens: int            # 实际 token 数

# 物理 block（GPU 显存中的实际位置）
class PhysicalTokenBlock:
    """物理 block（真正的显存地址）"""
    block_id: int              # 物理 block ID
    block_size: int            # 块大小
    ref_count: int             # 引用计数（多少个请求在使用这个 block）
    is_free: bool              # 是否空闲

# Block 分配器
class BlockAllocator:
    """物理 block 分配器"""
    free_blocks: List[int]     # 空闲 block 列表
    total_blocks: int          # 总可用 block 数

# Block 表（每个请求一个）
class BlockTable:
    """逻辑→物理地址映射表"""
    block_ids: List[int]       # 逻辑 block i → 物理 block block_ids[i]
```

---

## 5. 部署与实验

```bash
# 1. 安装
pip install vllm

# 2. 启动 OpenAI API 服务
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen2.5-0.5B-Instruct \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.9 \
    --enforce-eager  # 为了测试 fast，禁用 torch.compile

# 3. 发送请求
curl http://localhost:8000/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "Qwen/Qwen2.5-0.5B-Instruct",
        "messages": [{"role": "user", "content": "Hi!"}],
        "max_tokens": 100
    }'

# 4. 查看运行时统计
# 服务端日志会显示：
# Avg prompt throughput: ... tokens/s
# Avg generation throughput: ... tokens/s
# Running: ... reqs, Waiting: ... reqs

# 5. 性能 Profiling（需要模型权重）
# python -m vllm.entrypoints.openai.api_server \
#     --model /path/to/model \
#     --profiler-result-dir ./profile
```

---

## 6. 面试考点

| 考点 | 重要度 | 说明 |
|------|--------|------|
| vLLM 核心模块分层 | ⭐⭐⭐ | API Server → Engine → Scheduler → Worker → Model Runner |
| V0 vs V1 区别 | ⭐⭐ | 新候选人面试可能直接考 V1 设计思路 |
| GPU Worker 的工作流程 | ⭐⭐ | prepare_input → execute_model → sample_outputs |
| 部署命令参数 | ⭐ | `--max-model-len`, `--gpu-memory-utilization`, `--enforce-eager` |
| Continuous Batching 概念 | ⭐⭐⭐ | Scheduler 如何管理多请求 |
| 为什么需要 Block Manager | ⭐⭐⭐ | 显存碎片、KV cache 动态增长 |
| Attention Backend 选择 | ⭐⭐ | flash_attn vs paged_attn |
| Sampling 策略 | ⭐ | argmax, top-k, top-p, temperature |

---

### 本周学习清单

```
Day 1-2: 阅读 vLLM 仓库结构，画整体架构图
Day 3-4: 部署 vLLM，用 curl 交互测试
Day 5-6: 阅读 LLMEngine.step() 源码流程
Day 7: 阅读 V1 scheduler.py 的 schedule() 方法框架
```
