# FlashAttention 原理与优化详解

## 1. FlashAttention-1/2/3 核心思想

### 1.1 背景：Attention 的计算瓶颈

标准 Attention 的计算公式为：

```
O = softmax(Q @ K^T / sqrt(d)) @ V
```

其中 Q, K, V 的形状为 `[N, d]`（N = 序列长度，d = 头维度）。

标准实现需要：
1. 计算 S = Q @ K^T → shape [N, N]，需要写入 HBM
2. 计算 P = softmax(S) → shape [N, N]，需要写入 HBM
3. 计算 O = P @ V → shape [N, d]，需要写入 HBM

**核心问题**：S 和 P 矩阵的 shape 是 [N, N]，当 N 很大时（例如 8K, 32K），这个中间矩阵无法放入 SRAM（片上高速缓存），必须存储在 HBM（高带宽显存）中。Attention 的计算速度被 HBM 带宽所限制（memory-bound）。

### 1.2 FlashAttention-1 核心思想：IO-Aware Tiling

FlashAttention-1 (Dao et al., 2022) 的核心洞察是：**不要将完整的 S 和 P 矩阵写入 HBM**。通过 tiling（分块计算），让 Q/K/V 的分块在 SRAM 中完成所有计算，最后再将结果写回 HBM。

三个关键技术创新：

**① IO-Aware Tiling（IO 感知的分块）**
- 将 Q, K, V 沿序列维度分块，每个块的大小由 SRAM 容量决定
- 每次只加载一个 Q 块和所有 K/V 块（或反过来）
- 在 SRAM 中完成子矩阵的 attention 计算
- 最后合并所有部分结果

**② Online Softmax（在线 Softmax）**
- 标准 softmax 需要先计算所有元素的 `e^x` 和 `sum(e^x)`，这意味着必须写出完整的 S 矩阵
- Online softmax 通过维护**运行最大值 (running max)** 和**运行和 (running sum)**，可以在分块计算的同时逐步计算出正确的 softmax
- 每个块计算时，根据当前的 running max 对之前的输出进行重缩放

**③ Recomputation（重计算）**
- 反向传播时，不保存中间的 S 和 P 矩阵（它们占 N² 空间）
- 在反向传播时，从 Q, K, V 块在 SRAM 中重新计算 attention
- 虽然增加了计算量，但大幅减少了 HBM 读写

### 1.3 FlashAttention-2 改进

- **减少非矩阵乘运算**：将更多操作融合到矩阵乘法之后
- **调整循环顺序**：外层循环遍历 Q 块，内层循环遍历 K/V 块（与 FA1 相反），更好地利用矩阵乘法单元
- **减少线程同步**：降低 warp-level 同步开销
- **更好的分区策略**：对 Q 块进行并行化处理

### 1.4 FlashAttention-3 改进

- **利用 FP8 低精度计算**：使用硬件 FP8 张量核心加速
- **异步处理**：利用 Tensor Memory Pipeline（TMA）实现数据加载与计算的重叠
- **Block-Sparse Attention**：支持稀疏 attention 模式
- **Warp 级优化**：更精细的 warp 调度

---

## 2. IO 复杂度分析

### 2.1 标准 Attention 的 IO 复杂度

基本操作：
- 读取 Q, K, V 各一次：3 × N × d 个元素
- 写入 S 矩阵：N × N 个元素
- 写入 P 矩阵：N × N 个元素
- 读取 P 矩阵用于 O = P @ V：N × N 个元素
- 写入 O 矩阵：N × d 个元素

假设元素大小为 2 字节（FP16），总 HBM 访问量：
```
Reads:   3Nd + N²    (Q + K + V + P)
Writes:  N² + N² + Nd = 2N² + Nd  (S + P + O)
Total:   3Nd + 3N² + Nd = 3N² + 4Nd
```

当 N >> d 时（长序列），主导项是 **O(N²)**。

### 2.2 FlashAttention 的 IO 复杂度

FlashAttention 的块大小为 B（tile size），满足：一个 Q 块 + 一个 K 块 + 一个 V 块的中间结果能放入 SRAM。

对每个 Q 块（共 N/B 个），需要流式加载所有 K/V 块（共 N/B 个）：
- 每个 Q 块加载次数：1 次（被复用）
- 每个 K/V 块加载次数：N/B 次（每次被不同的 Q 块使用）

总 HBM 访问量：
```
读取 Q:  N × d
读取 K:  (N/B) × N × d = N²d/B
读取 V:  (N/B) × N × d = N²d/B
写入 O:  N × d
（没有中间 S/P 矩阵的读写）
```

当 B 远小于 N 时，总复杂度约为 **O(N²/B)**。

举例对比（N=4096, d=64, B=128, FP16）：

| 操作 | 标准 Attention | FlashAttention |
|------|---------------|----------------|
| HBM 读写 | ~202 MB | ~9.4 MB |
| 加速比 | 1x | ~21x |

### 2.3 IO 复杂度公式推导

标准 Attention 读取 Q, K, V（3Nd）并写出 O（Nd），中间 S 和 P 各 N² 的读写：
```
HBM_standard = 3Nd + N² + N² + N² + Nd = 3N² + 4Nd
```

FlashAttention 的块大小为 B，块数 Tc = N/B：
```
每个 Q 块处理时，加载一次 Q（d×B），遍历所有 K/V 块：
每次加载 K（d×B），加载 V（d×B）
总共遍历 Tc 次
总 K 读取 = Tc × (B×d) × Tc = N × d × N/B = N²d/B
总 V 读取 = N²d/B
总 Q 读取 = Tc × (B×d) = N × d
总 O 写入 = N × d
HBM_flash = 2N²d/B + 2Nd
```

关键结论：**块大小 B 越大（SRAM 越大），IO 复杂度越低**。当 B 接近 N 时退化为标准 Attention。

---

## 3. Tiling 算法分步详解

### 3.1 符号约定

```
Q ∈ ℝ^{N×d}, K ∈ ℝ^{N×d}, V ∈ ℝ^{N×d}
N: 序列长度, d: 头维度, B: 块大小
B_r: Q 块大小 (沿行分块)
B_c: K/V 块大小 (沿列分块)
```

### 3.2 算法步骤

**外层循环**：对 Q 分块，遍历 i = 0 到 N/B_r - 1
**内层循环**：对 K/V 分块，遍历 j = 0 到 N/B_c - 1

```
输入: Q ∈ ℝ^{N×d}, K ∈ ℝ^{N×d}, V ∈ ℝ^{N×d}
输出: O ∈ ℝ^{N×d}

// 初始化输出 O 为零矩阵
O = zeros(N, d)

// 外层循环：遍历 Q 的每个块
for i = 0 to N/B_r - 1:
    Qi = Q[i*B_r : (i+1)*B_r, :]       // 加载 Q 块 [B_r, d]
    
    // 初始化 running max 和 running sum
    m_i = [-inf] * B_r                  // 运行最大值
    l_i = [0] * B_r                     // 运行和
    O_i = zeros(B_r, d)                 // 输出块
    
    // 内层循环：遍历 K, V 的每个块
    for j = 0 to N/B_c - 1:
        Kj = K[j*B_c : (j+1)*B_c, :]   // 加载 K 块 [B_c, d]
        Vj = V[j*B_c : (j+1)*B_c, :]   // 加载 V 块 [B_c, d]
        
        // 1. 计算分块得分矩阵
        S_ij = Qi @ Kj^T / sqrt(d)      // [B_r, B_c]
        
        // 2. Online softmax：更新 running max
        m_i_new = max(m_i, rowmax(S_ij))  // 按行取最大值
        
        // 3. 更新 running sum（需要重缩放）
        //    对之前的 l_i 应用重缩放因子 exp(m_i - m_i_new)
        //    对新来的 S_ij 计算 exp(S_ij - m_i_new) 并累加
        P_ij = exp(S_ij - m_i_new)       // [B_r, B_c], safe softmax
        l_i_new = exp(m_i - m_i_new) * l_i + rowsum(P_ij)
        
        // 4. 更新输出（需要重缩放）
        //    之前的 O_i 由旧的 m_i, l_i 计算得到，需要修正
        O_i = O_i * exp(m_i - m_i_new) / (l_i_new / l_i) ... 
        // 实际上更简洁的写法：
        O_i = (l_i / l_i_new) * exp(m_i - m_i_new) * O_i ... 
        
        // 精确的递推公式：
        // 先对 O_i 做重缩放：O_i ← (l_i / l_i_new) * exp(m_i - m_i_new) * O_i
        // 然后加上新贡献：O_i += P_ij @ Vj
        // 最后再归一化：O_i ← O_i / l_i_new  × 实际上最后统一做
        
        // 更好的实现方式（三行递推）：
        scale = exp(m_i - m_i_new)          // [B_r]
        O_i = O_i * scale.unsqueeze(-1)     // 重缩放旧输出
        O_i += P_ij @ Vj                    // 加入新结果
                                             // 注意这里 P_ij @ Vj 还没有被 l_i_new 归一化
        
        // 更新状态
        m_i = m_i_new
        l_i = l_i_new
    
    // 内层循环结束，对 O_i 做最终归一化
    O_i = O_i / l_i.unsqueeze(-1)
    
    // 写回 O_i 到 HBM
    O[i*B_r : (i+1)*B_r, :] = O_i
```

### 3.3 为什么 Online Softmax 是正确的

**数学推导**：

标准 softmax 对向量 x ∈ ℝⁿ：
```
softmax(x)_i = exp(x_i) / sum_j exp(x_j)
```

令 m = max(x)，safe softmax 等价于：
```
softmax(x)_i = exp(x_i - m) / sum_j exp(x_j - m)
```

现在考虑将 x 分块为 x^{(1)} 和 x^{(2)}：
1. 第一个块到达时，m₁ = max(x^{(1)})
   - P₁ = exp(x^{(1)} - m₁)，l₁ = sum(P₁)

2. 第二个块到达时，m₂ = max(m₁, max(x^{(2)}))
   - 对 P₁ 重缩放：P₁' = exp(x^{(1)} - m₂) = P₁ × exp(m₁ - m₂)
   - P₂ = exp(x^{(2)} - m₂)
   - l₂ = sum(P₁') + sum(P₂) = exp(m₁ - m₂) × l₁ + sum(P₂)

3. 完整的 softmax 结果：
   - 对应 x^{(1)} 的部分：P₁' / l₂
   - 对应 x^{(2)} 的部分：P₂ / l₂

而输出 O = softmax(x) @ V = (1/l₂) × (P₁' @ V₁ + P₂ @ V₂)

递推公式完全等价于标准 softmax，**没有近似误差**。

---

## 4. Online Softmax 详解

### 4.1 为什么需要 Online Softmax

标准 Attention 需要完整计算 S 矩阵才能做 softmax：
```
S = QK^T / sqrt(d)        // 写 HBM
S_max = rowmax(S)          // 读 S，计算每行最大值
P = exp(S - S_max)         // 读写 S
P_sum = rowsum(P)          // 读 P
O = P / P_sum @ V          // 读 P
```

每行数据在 HBM 和 SRAM 之间多次往返。Online softmax 的核心贡献是：**在分块计算 attention 的同时，递推地计算 softmax，无需存储完整的 S/P 矩阵**。

### 4.2 递推公式的数值稳定性

数值稳定性分析：
- 初始 m = -inf, l = 0
- 第一块：m = max(第一块的值)，所有指数值 ≤ 1
- 后续块：m 递增或不变，重缩放因子 exp(old_m - new_m) ≤ 1
- 所有中间值都被控制在合理的范围内，不会溢出

与标准 safe softmax 的数值精度完全相同（均基于 log-sum-exp 技巧）。

### 4.3 算法伪代码实现

```python
def online_softmax_update(m, l, O, S_ij, Vj):
    """
    m: [B_r], 当前运行最大值
    l: [B_r], 当前运行和 (sum of exp)
    O: [B_r, d], 当前部分输出
    S_ij: [B_r, B_c], 当前块的得分
    Vj: [B_c, d], 当前 V 块
    """
    # 新的最大值
    m_new = torch.max(m, S_ij.max(dim=-1))
    
    # 重缩放旧输出并加入新贡献
    # P_ij = exp(S_ij - m_new[:, None])
    # O_new = (l / l_new) * exp(m - m_new) * O + (P_ij @ Vj) / l_new
    
    # 实际上分两步更清晰：
    scale = torch.exp(m - m_new)              # [B_r]
    O = O * scale[:, None]                     # 重缩放旧输出
    
    P_ij = torch.exp(S_ij - m_new[:, None])   # [B_r, B_c]
    l_new = l * scale + P_ij.sum(dim=-1)      # [B_r]
    
    O = O + P_ij @ Vj                         # [B_r, d]
    # 注意：此时 O 还没有被 l_new 归一化
    
    return m_new, l_new, O
```

到所有块处理完毕，对 O 做最终归一化：
```python
O = O / l[:, None]
```

---

## 5. 块大小选择

### 5.1 SRAM 约束下的块大小

块大小 B 由 GPU SRAM 容量决定。以 A100-80GB 为例：
- SRAM（共享内存）：192 KB 每 SM（实际可编程约 164 KB）
- 需要同时存放：Q 块 [B, d], K 块 [B, d], V 块 [B, d], O 块 [B, d]

每个元素 FP16（2 bytes），d = 64 或 128：
```
Q + K + V + O = 4 × B × d × 2 = 8 × B × d
```

对于 d = 64: 8 × B × 64 = 512B ≤ 164KB → B ≤ 328
对于 d = 128: 8 × B × 128 = 1024B ≤ 164KB → B ≤ 164

实际中还需要预留寄存器、中间变量等空间，常见选择：
- d=64: B = 128 或 256
- d=128: B = 64 或 128

### 5.2 块大小与 HBM 访问量的关系

回忆 HBM 访问公式：
```
HBM_IO ≈ 2N²d/B + 2Nd
```

B 增大时，第一项减小，但 B 受 SRAM 限制不能无限增大。

### 5.3 实际选择的权衡

| GPU 架构 | SRAM/SM | 推荐 B (d=64) | 推荐 B (d=128) |
|---------|---------|---------------|----------------|
| V100 (Turing) | 96 KB | 64 | 32 |
| A100 (Ampere) | 192 KB | 128 | 64 |
| H100 (Hopper) | 228 KB | 128 | 64 |

此外还需考虑 warp 调度效率：
- B 最好是 16 的倍数（warp 大小 32 的一半，因为 half-row 分配）
- B 不应太小，否则块数量太多，warp 调度开销增大
- B 不应让共享内存 bank conflict 严重

---

## 6. 面试题

### 6.1 基础知识

**Q1: 标准 Attention 的计算为何在长序列时变慢？**

A: 标准 Attention 需要计算 N×N 的注意力分数矩阵 S 和概率矩阵 P，并将其写入 HBM。当 N 增大时，这部分的显存访问量为 O(N²)，成为性能瓶颈（memory-bound）。FlashAttention 通过分块计算避免了 S 和 P 矩阵的 HBM 读写。

**Q2: 什么是 IO-aware tiling？**

A: IO-aware tiling 是指根据 GPU SRAM（共享内存）的容量来确定分块大小，确保每个计算块的所有输入和中间结果都能放入 SRAM。这样避免了中间矩阵的 HBM 读写，使得计算不再是 HBM 带宽瓶颈。

**Q3: FlashAttention 的 IO 复杂度为什么是 O(N²/B)？**

A: 每个 K/V 块会被所有 Q 块访问一次，所以 K 和 V 各自被读取了 (N/B) 次（每个 Q 块遍历所有 K/V 块一次），每次读取 B×d 个元素。所以 K 和 V 的读取量为 O(N × N/B × d) = O(N²d/B)，忽略 d 和常数项后为 O(N²/B)。

### 6.2 进阶问题

**Q4: Online softmax 会损失精度吗？**

A: 不会。Online softmax 在数学上完全等价于标准 safe softmax，因为所有变换都是通过乘上重缩放因子 exp(old_max - new_max) 完成的，没有近似。数值上也是同样稳定的，因为始终以当前最大值为基准做指数运算。

**Q5: FlashAttention 中重计算 (recomputation) 为什么是有益的？**

A: 反向传播时如果不使用重计算，需要保存 S 和 P 矩阵（O(N²) 空间），这本身就是巨大的 HBM 开销。使用重计算，在反向传播时重新计算 S 和 P 的子块（在 SRAM 中），虽然增加了 FLOPs，但减少了 HBM 读写。在 memory-bound 的场景下，时间开销反而更小。

**Q6: FlashAttention-2 相比 FlashAttention-1 的主要改进是什么？**

A: 1) 循环顺序调整：FA1 外层循环 K/V、内层循环 Q；FA2 外层循环 Q、内层循环 K/V。这使得 Q 块的并行化更高效，减少了线程同步。
2) 更少的非矩阵运算：减少了对 running max/sum 的操作次数。
3) 更好的工作分配：不同 Q 块在不同 warp/thread block 上并行计算。

### 6.3 系统设计

**Q7: 设计一个支持 128K 上下文长度的 Attention 机制，你会如何考虑？**

A: FlashAttention 本身支持长序列（因为它的复杂度是 O(N²/B) 而非 O(N²)），但还需要考虑：
1. 结合稀疏 attention（如窗口 attention + global tokens），进一步降低计算量
2. 使用 ALiBi 或 RoPE 位置编码
3. 考虑使用 Ring Attention 将序列分到多个 GPU 上
4. 对于推理，使用 KV cache 量化（FP8/INT8）减少显存占用
5. 使用 StreamingLLM 等技术，只保留最近的 tokens

**Q8: 如何选择 FlashAttention 的块大小？**

A: 块大小的上限由 SRAM 容量决定（需要同时容纳 Q/K/V/O 块），下限由计算效率决定（块太小则 GPU 计算单元未充分利用）。实际选择还需要考虑 d（头维度）的大小，以及是否使用 FP8（减少一半存储）。建议通过 profiling 选择最优 B。

### 6.4 工程实现

**Q9: 实现 Online Softmax 时需要注意哪些数值问题？**

A: 1) 初始 m 设为 -inf 或一个非常小的负数
2) 计算 exp(S - m) 时，确保 S - m ≤ 0（不会溢出）
3) 重缩放因子 exp(old_m - new_m) 在 old_m 很小时可能为 0，需要处理好数值下溢
4) 更新 l 时，exp(old_m - new_m) * l + sum(exp(S - new_m))，两个项的量级差异不能太大

**Q10: 如何实现 FlashAttention 的反向传播？**

A: 不保存中间的 S 和 P 矩阵。反向传播时：
1. 重新加载 Q/K/V 块
2. 在 SRAM 中重新计算 S 和 P
3. 使用 dO（输出梯度）计算 dQ, dK, dV
4. 利用 softmax 的梯度公式：dP = dO @ V^T, dS = P * (dP - rowsum(dP * P))
