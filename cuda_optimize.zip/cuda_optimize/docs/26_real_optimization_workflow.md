﻿# 真实推理优化工作流：从接到需求到上线

> **定位**：前面 25 篇文档教的是"知识点"，这篇教的是"怎么把知识点串起来干活"。
>
> **读者**：即将入职的推理优化工程师，已经学完前面阶段 1-7 的内容。
>
> **目标**：看完这篇，你知道接到一个优化需求后，从第 1 天到上线那天，每天该干啥、用什么工具、产出什么。
>
> **前置**：[18_service_metrics.md](18_service_metrics.md)、[19_nsight_lab.md](19_nsight_lab.md)。

---

## 0. 先破一个误区

很多人以为推理优化工程师的日常是"写 CUDA kernel"，**错**。真实分布大概是这样：

| 工作类型 | 占比 | 说明 |
|---------|:----:|------|
| 调参 + 配置 | 40% | 改 vLLM/SGLang 启动参数，跑 benchmark 对比 |
| Profiling 定位 | 25% | 用 nsys/ncu 找瓶颈 |
| 写脚本（benchmark/监控/迁移） | 15% | Python 为主 |
| 改框架代码 | 10% | C++/CUDA，几个月才一次 |
| 开会/写文档/线上排查 | 10% | 沟通成本 |

**结论**：你得会写 kernel，但日常 80% 时间在调参、profiling、写脚本。

---

## 1. 完整工作流总览

```
接到需求
   │
   ▼
[阶段 1] 摸底 ─────── 理解需求, 看现状, 定目标
   │
   ▼
[阶段 2] 建基线 ────── 跑 benchmark, 记录当前指标
   │
   ▼
[阶段 3] Profiling ─── 用 nsys/ncu 定位瓶颈
   │
   ▼
[阶段 4] 方案设计 ──── 列候选优化, 评估收益/风险
   │
   ▼
[阶段 5] 实施 ──────── 调参 / 改代码 / 改配置
   │
   ▼
[阶段 6] 验证 ──────── 对比基线, 回归测试
   │
   ▼
[阶段 7] 上线 ──────── 灰度, 监控, 应急回滚
   │
   ▼
[阶段 8] 复盘 ──────── 写文档, 沉淀经验
```

每个阶段的细节下面展开。

---

## 2. 阶段 1：摸底（Day 1）

### 2.1 要搞清楚的 5 个问题

接到需求第一件事不是动手，而是**问清楚**：

1. **优化目标是什么？**
   - 降延迟？(P99 TTFT < 500ms)
   - 提吞吐？(QPS 从 20 → 50)
   - 省显存？(能跑更大模型)
   - 省钱？(同等性能少用卡)

2. **当前指标是多少？**
   - 要历史监控数据，别凭感觉
   - 看最近 7 天的 P50/P99/P999

3. **约束是什么？**
   - 硬件：A100 / H100 / DCU？几张？
   - 模型：哪个模型？量化没？
   - SLO：硬性指标不能破
   - 预算：能改代码还是只能调参？

4. **谁会受影响？**
   - 改了配置会不会影响别的业务？
   - 上线需要谁审批？

5. **deadline？**
   - 决定你能做多少轮迭代

### 2.2 产出物

一份"需求理解文档"，至少包含：
```markdown
# 需求: 优化 Llama-3-8B 推理 P99

## 目标
- P99 TTFT: 800ms → 500ms
- P99 TPOT: 50ms → 30ms
- 吞吐不低于当前

## 现状
- 硬件: 2x A100 80G
- 框架: vLLM 0.6.0
- 模型: Llama-3-8B FP16
- 并发: 峰值 50 QPS

## 约束
- 不能降精度
- 7 天内上线
```

### 2.3 常见坑

- **没问清楚就开干**：优化了半天发现目标是省显存不是降延迟
- **凭感觉定目标**：P99 从 800ms 优化到 200ms（不现实，SLO 都没要求）
- **忽略约束**：改了配置才发现客户不能用新版框架

---

## 3. 阶段 2：建基线（Day 1-2）

### 3.1 为什么要基线

没有基线 = 没法证明你优化了。每次改完都要和基线对比，否则"感觉快了"不算数。

### 3.2 基线要测什么

| 指标 | 怎么测 | 工具 |
|------|--------|------|
| TTFT (P50/P99) | 发请求记首 token 时间 | benchmark 脚本 |
| TPOT (P50/P99) | 记 token 间隔时间 | benchmark 脚本 |
| 吞吐 (tok/s) | 总 token / 总时间 | benchmark 脚本 |
| 显存峰值 | nvidia-smi 采样 | rocm-smi (DCU) |
| GPU 利用率 | nsys profile | nsys / rocprof |
| 各阶段耗时 | nsys timeline | nsys |

### 3.3 真实 benchmark 脚本

见 [10_inference_engine/python/benchmark_serving.py](../10_inference_engine/python/benchmark_serving.py)，这是一个简化版但结构完整的真实 benchmark。

**关键设计**：
- 用 asyncio 并发模拟真实流量
- 流式响应，能分别记 TTFT 和 TPOT
- 多轮跑取统计值（P50/P99）
- 记录每个请求的输入输出长度

跑法：
```bash
# 启动 vLLM 服务
vllm serve meta-llama/Llama-3-8B --port 8000

# 跑基线 benchmark
python benchmark_serving.py \
    --base-url http://localhost:8000/v1 \
    --model meta-llama/Llama-3-8B \
    --num-prompts 200 \
    --request-rate 10 \
    --output baseline.json
```

### 3.4 产出物

`baseline.json`，记录所有指标。后续每次优化都和它对比。

```json
{
  "config": {
    "model": "Llama-3-8B",
    "num_prompts": 200,
    "request_rate": 10
  },
  "results": {
    "ttft_p50_ms": 320,
    "ttft_p99_ms": 810,
    "tpot_p50_ms": 28,
    "tpot_p99_ms": 52,
    "throughput_tok_s": 1850,
    "gpu_memory_peak_gb": 18.5
  }
}
```

### 3.5 常见坑

- **跑太少请求**：50 个请求统计噪声大，至少 200+
- **不预热**：第一次请求会触发 lazy init，要 warmup 10-20 个再开始记数据
- **只看平均值**：P99 才是 SLO 关键，平均会掩盖尾延迟
- **流式和非流式混测**：流式才能测准 TTFT

---

## 4. 阶段 3：Profiling 定位瓶颈（Day 2-4）

### 4.1 Profiling 的层次

```
应用层      ──── PyTorch Profiler (看 op 级耗时)
   │
系统层      ──── nsys / rocprof (看 GPU/CPU/网络 timeline)
   │
Kernel 层   ──── ncu / rocprof (看单 kernel 细节)
   │
硬件层      ──── nvidia-smi dmon (看利用率/显存/功耗)
```

**定位瓶颈的顺序**：从上往下。先用 nsys 看整体，再用 ncu 钻进具体 kernel。

### 4.2 用 nsys 抓系统 timeline

```bash
# 抓 30 秒的 trace
nsys profile \
    --trace=cuda,nvtx,osrt,cudnn,cublas \
    --duration=30 \
    --output=vllm_baseline \
    python benchmark_serving.py --num-prompts 100 ...
```

打开 `vllm_baseline.nsys-reps`（用 Nsight Systems GUI）看：

**看什么**：
1. **GPU idle 段**：GPU 空闲说明在等 CPU 或网络，不是 GPU 瓶颈
2. **长 kernel**：哪个 kernel 占时最长？
3. **H2D/D2H 拷贝**：有没有意外的 host-device 传输？
4. **CUDA stream 利用**：是不是串行了？
5. **NCCL 通信**：TP/PP 的 all-reduce 占比

**典型发现**：
- "GPU 利用率只有 40%，瓶颈在 CPU 调度" → 优化方向不是 kernel
- "某层 attention 占 50% 时间" → 钻进去用 ncu 看
- "每步都有 H2D 拷贝" → 配置问题，应该 pinned memory

### 4.3 用 ncu 抓单 kernel 细节

```bash
# 抓某个 kernel 的详细指标
ncu --set full \
    --kernel-name "regex:.*attention.*" \
    --launch-skip 10 \
    --launch-count 5 \
    --output attention_kernel.ncu-rep \
    python benchmark_serving.py ...
```

打开 `attention_kernel.ncu-rep` 看：

**看什么**：
1. **算术强度** (FLOPs/Byte)：算力瓶颈还是带宽瓶颈？
2. **内存吞吐**：接近 HBM 带宽上限了吗？
3. **occupancy**：SM 利用率，低说明 warp 不够
4. **shared memory 利用率**：bank conflict？
5. **roofline 位置**：在算力线还是带宽线下？

**典型发现**：
- "算术强度 10，但只跑到 20% 峰值算力" → 有别的问题（cache miss？同步？）
- "memory throughput 1.2 TB/s，接近 A100 上限 1.5 TB/s" → 带宽瓶颈，要量化或减少访存
- "occupancy 25%" → block 配置问题，调 block size

### 4.4 用 PyTorch Profiler 看 op 级

```python
from torch.profiler import profile, ProfilerActivity

with profile(
    activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
    record_shapes=True,
) as prof:
    # 跑一段推理
    model.generate(...)

# 打印 top 20 耗时 op
print(prof.key_averages().table(sort_by="cuda_time_total", row_limit=20))
```

### 4.5 产出物

一份"瓶颈分析报告"：

```markdown
# 瓶颈分析

## 系统层 (nsys)
- GPU 利用率: 65% (有 35% idle)
- 主要 idle 段: 每步 decode 之间, 约 5ms, 原因是 CPU 调度延迟
- 最长 kernel: flash_attn_fwd, 占总时间 32%

## Kernel 层 (ncu)
- flash_attn_fwd 算术强度: 50 FLOP/Byte (算力瓶颈)
- 实际算力: 180 TFLOPS (A100 峰值 312 TFLOPS, 58%)
- occupancy: 50% (偏低, 可优化)
- shared memory: 80% 利用, 无 bank conflict

## 结论
- 主瓶颈: flash_attn_fwd 没吃满算力
- 次要瓶颈: CPU 调度有 5ms 空闲
- 优化方向: (1) 换 FA-3 (2) 调 scheduler 参数
```

### 4.6 常见坑

- **只看一个层次**：光看 nsys 不用 ncu，定位不到 kernel 细节
- **profile 时数据量太少**：要跑足够多请求，profile 才有代表性
- **profile 影响性能**：ncu `--set full` 会让 kernel 慢 10x，测吞吐时别开
- **找错瓶颈**：把"占用时间最长的 kernel"当瓶颈，但它可能已经在 roofline 顶点

---

## 5. 阶段 4：方案设计（Day 4-5）

### 5.1 列候选方案

基于 profiling 结论，列出所有可能的优化方案。**不要只列一个**。

例子（针对 "P99 TTFT 800ms 想降到 500ms"）：

| 方案 | 预期收益 | 实施难度 | 风险 |
|------|---------|---------|------|
| A. 调 max-num-seqs | +5% | 低 | 几乎无 |
| B. 开 prefix caching | +15% | 低 | 多轮对话才能受益 |
| C. 量化 KV cache (FP8) | +20% | 中 | 精度损失 |
| D. 换 FlashAttention-3 | +25% | 中 | 硬件要求 H100+ |
| E. PD 分离 | +40% | 高 | 架构改造大 |
| F. 写自定义 attention kernel | +10% | 极高 | 维护成本 |

### 5.2 评估方法

- **预期收益**：从论文/官方 benchmark/历史经验估
- **实施难度**：看代码改动量 + 是否要改框架
- **风险**：精度？稳定性？兼容性？
- **ROI**：收益 / (难度 × 风险)

### 5.3 选择策略

**先摘低垂的果**：
1. 先做 A（调参，1 小时，+5%）
2. 再做 B（开 prefix caching，半天，+15%）
3. 不够再做 C（量化，2 天，+20%）
4. 还不够才考虑 D/E

**不要一上来就写 kernel**（方案 F）。除非前 5 个都不够。

### 5.4 产出物

一份"方案设计文档"，含：
- 候选方案表
- 选定方案 + 理由
- 每个方案的验证指标
- 时间排期

### 5.5 常见坑

- **只准备一个方案**：万一不 work 没有备选
- **预期收益拍脑袋**：要从数据推，不是"我觉得能快 20%"
- **忽略风险**：量化上线后发现精度问题，回滚成本高
- **一次做太多**：同时改 3 个变量，无法定位哪个有效

---

## 6. 阶段 5：实施（Day 5-N）

### 6.1 调参型实施

最常见。改 vLLM 启动参数，跑 benchmark 对比。

```bash
# 方案 A: 调 max-num-seqs
vllm serve meta-llama/Llama-3-8B \
    --max-num-seqs 256 \           # 原来是 128
    --port 8000

# 跑 benchmark
python benchmark_serving.py --num-prompts 200 --output exp_a.json

# 对比基线
python compare_results.py baseline.json exp_a.json
```

**调参的纪律**：
- 一次只改一个参数（否则不知道哪个有效）
- 每次都和基线对比
- 记录每次实验的配置和结果

### 6.2 配置型实施

改 yaml 配置文件，比如 chunked prefill、prefix caching 开关。

```yaml
# vllm 配置
scheduler:
  chunked-prefill: true
  max-num-batched-tokens: 8192

kv-cache:
  dtype: fp8
  enable-prefix-caching: true
```

### 6.3 代码型实施

改框架源码。**这种要特别谨慎**：

1. 先 fork 一份，不要直接改主线
2. 改之前读懂原有代码（用 git blame 看历史）
3. 加单元测试
4. 跑回归测试确保没破坏别的功能
5. 提 PR 让同事 review

```bash
# fork vllm, 改一个 scheduler 逻辑
cd vllm
git checkout -b opt/chunked-prefill-tune

# 改 vllm/core/scheduler.py
# ... 加日志, 调逻辑 ...

# 跑单测
pytest tests/core/test_scheduler.py

# 跑 benchmark 对比
python benchmark_serving.py --output exp_code.json
```

### 6.4 Kernel 型实施

写/改 CUDA kernel。最复杂，参考 [05_attention/cuda/](../05_attention/cuda/) 和 [10_inference_engine/cpp/](../10_inference_engine/cpp/)。

**纪律**：
1. 先写简单版（正确性优先）
2. 用 CPU 朴素版做 ground truth 验证
3. 再优化（tile、shared memory、TensorCore）
4. 每次优化都 benchmark，记录 kernel time
5. 加 ncu 验证是不是真的在 roofline 顶点

### 6.5 产出物

每次实验：
- 改动记录（git commit + diff）
- benchmark 结果 JSON
- 和基线的对比表

### 6.6 常见坑

- **同时改多个变量**：无法归因
- **没记配置**：下周回来忘了当时改了啥
- **代码型不跑单测**：上线破坏别的功能
- **kernel 不验证正确性**：跑得快但结果错

---

## 7. 阶段 6：验证（Day N-2 到 N）

### 7.1 要验证的 3 件事

1. **性能确实提升了**：和基线对比，P99 / 吞吐 / 显存都达标
2. **正确性没坏**：生成质量没降（量化尤其要检查）
3. **没引入新问题**：长时间稳定性、边界 case

### 7.2 正确性验证

```python
# 用一组固定 prompt, 对比优化前后的输出
prompts = [
    "1 + 1 = ",
    "The capital of France is ",
    # ... 50 个 fact-checking prompts
]

# 优化前
vllm serve ... --port 8000  # 原配置
python eval_correctness.py --baseline

# 优化后
vllm serve ... --port 8000  # 新配置
python eval_correctness.py --compare
```

**检查指标**：
- 相同 prompt 的输出是否一致（temperature=0 时应该完全一样）
- fact-checking 正确率
- 长文本生成的连贯性

### 7.3 稳定性验证

跑 2 小时持续压力测试：
```bash
python benchmark_serving.py \
    --num-prompts 10000 \
    --request-rate 20 \
    --duration 7200  # 2 小时
```

看：
- 显存有没有泄漏（曲线持续上涨）
- 延迟有没有退化（开始快后面慢）
- 有没有 OOM / error

### 7.4 回归测试

如果改了代码，跑完整测试套件：
```bash
pytest tests/ -v
```

### 7.5 产出物

- 性能对比报告
- 正确性对比报告
- 稳定性报告

### 7.6 常见坑

- **只测性能不测正确性**：量化后精度掉了不知道
- **测太短**：5 分钟跑没事，2 小时后 OOM
- **没测边界 case**：超长 prompt、空 prompt、并发突增

---

## 8. 阶段 7：上线（Day N 到 N+3）

### 8.1 灰度策略

**不要全量上**。按流量比例逐步放量：

```
Day 1: 5% 流量到新版本, 观察 24h
Day 2: 25% 流量, 观察 24h
Day 3: 50% 流量, 观察 24h
Day 4: 100% 流量
```

### 8.2 监控指标

上线后盯紧这些：

| 指标 | 告警阈值 | 工具 |
|------|---------|------|
| P99 TTFT | > 600ms (SLO) | Prometheus + Grafana |
| P99 TPOT | > 40ms | 同上 |
| 错误率 | > 0.1% | 同上 |
| 显存使用 | > 95% | nvidia-smi exporter |
| GPU 利用率 | < 30% 或 > 95% | DCGM exporter |
| QPS 对比 | 下降 > 10% | 业务监控 |

### 8.3 回滚预案

上线前准备好：
```bash
# 一键回滚脚本
./rollback.sh
# 内容: 切回旧配置 + 重启服务
```

**回滚触发条件**：
- 任何 SLO 破线持续 5 分钟
- 错误率 > 1%
- 显存 OOM

### 8.4 产出物

- 上线 checklist
- 监控 dashboard
- 回滚脚本
- 值班排期（前 3 天有人盯）

### 8.5 常见坑

- **直接全量**：出问题影响所有用户
- **没准备回滚**：出问题手忙脚乱
- **上线就下班**：第一晚没人盯，第二天发现事故
- **监控指标不全**：只看延迟没看错误率

---

## 9. 阶段 8：复盘（Day N+7）

### 9.1 复盘文档

```markdown
# Llama-3-8B P99 优化复盘

## 背景
- 需求: P99 TTFT 800ms → 500ms
- 实际: 优化到 480ms ✅

## 做了什么
1. 调 max-num-seqs 128→256, +5%
2. 开 prefix caching, +12%
3. KV cache FP8 量化, +18%
4. chunked prefill, +8%
- 累计: 800ms → 480ms (-40%)

## 没做什么
- FlashAttention-3: 硬件不支持
- PD 分离: 周期太长, 留下迭代

## 踩的坑
- FP8 量化第一次配置错, 精度掉 5%, 调 scale 后恢复
- max-num-seqs 调太大导致 preemption, 反而变慢

## 经验沉淀
- 调参顺序: 先调度类, 再量化类, 最后 kernel 类
- 量化必须跑正确性验证, 不能只看性能
- preemption 监控要在上线前就加

## 后续
- PD 分离作为下季度项目
- 考虑换 H100 用 FA-3
```

### 9.2 沉淀到团队

- 把监控指标加到团队 dashboard 模板
- 把 benchmark 脚本沉淀到团队工具库
- 给同事做一次技术分享

### 9.3 为什么要复盘

- **避免重复踩坑**：下次有人做类似优化能查到
- **建立个人影响力**：写清楚的复盘会被同事引用
- **绩效材料**：晋升时这是实打实的产出

---

## 10. 完整 Case Study

### 10.1 需求

```
业务方: 客服 LLM 推理 P99 飙到 1.2s, 用户投诉, 7 天内优化到 600ms
现状: Llama-3-8B FP16, 2x A100, vLLM 0.5.x, 峰值 30 QPS
```

### 10.2 Day 1: 摸底 + 基线

```bash
# 跑基线
python benchmark_serving.py --num-prompts 300 --request-rate 30
```

结果：
```
TTFT P50: 380ms    P99: 1180ms ❌
TPOT P50: 35ms     P99: 85ms
吞吐: 1450 tok/s
显存: 72GB / 160GB
```

### 10.3 Day 2: Profiling

```bash
nsys profile --duration=60 python benchmark_serving.py ...
```

发现：
- GPU 利用率 55%，有 45% idle
- idle 段在每步 decode 之间，约 8ms
- flash_attn_fwd 占 35% 时间
- 有 H2D 拷贝（每 10 步一次，很小）

```bash
ncu --set full --kernel-name "flash_attn.*" python benchmark_serving.py
```

发现：
- occupancy 45%（偏低）
- 算术强度 30，跑在带宽线附近
- memory throughput 1.0 TB/s（A100 上限 1.5）

### 10.4 Day 3: 方案设计

| 方案 | 预期 | 难度 | 选 |
|------|------|------|---|
| 升级 vLLM 0.5→0.6 | +10% | 低 | ✅ |
| 调 max-num-seqs | +5% | 低 | ✅ |
| 开 chunked prefill | +15% | 低 | ✅ |
| KV cache FP8 | +20% | 中 | ✅ |
| 开 prefix caching | +10% (客服多轮) | 低 | ✅ |
| 写自定义 kernel | +10% | 极高 | ❌ |

### 10.5 Day 4-6: 实施

逐个实验：

```bash
# 实验 1: 升级 vLLM
pip install vllm==0.6.0
# 跑 benchmark: P99 1180 → 1050ms (-11%)

# 实验 2: 调 max-num-seqs 64→128
vllm serve ... --max-num-seqs 128
# P99 1050 → 980ms (-7%)

# 实验 3: 开 chunked prefill
vllm serve ... --enable-chunked-prefill
# P99 980 → 820ms (-16%)

# 实验 4: KV cache FP8
vllm serve ... --kv-cache-dtype fp8
# P99 820 → 670ms (-18%)
# 但正确性测试: 客服 FAQ 准确率 95% → 93%, 可接受

# 实验 5: 开 prefix caching (客服多轮对话)
vllm serve ... --enable-prefix-caching
# P99 670 → 580ms (-13%)
```

累计：1180ms → 580ms (-51%) ✅ 达标

### 10.6 Day 7: 验证

- 性能：P99 580ms < 600ms ✅
- 正确性：FAQ 准确率 -2%，业务可接受 ✅
- 稳定性：2 小时压测无 OOM ✅

### 10.7 Day 8-10: 灰度上线

```
Day 8:  5% 流量, P99 稳定在 580ms
Day 9:  30% 流量, P99 590ms
Day 10: 100% 流量, P99 585ms
```

### 10.8 Day 14: 复盘

写复盘文档，沉淀经验：
- vLLM 0.5→0.6 升级收益最大（白嫖）
- chunked prefill + KV 量化组合效果显著
- prefix caching 对多轮对话场景特别有效

---

## 11. 工具速查表

### 11.1 Benchmark 工具

| 工具 | 用途 | 命令 |
|------|------|------|
| vLLM benchmark_serving | 服务化 benchmark | `python -m vllm.entrypoints.openai.benchmark` |
| [本项目脚本](../10_inference_engine/python/benchmark_serving.py) | 简化版教学 | `python benchmark_serving.py` |
| lm-eval-harness | 模型质量评测 | `lm_eval --model vllm ...` |
| locust | 通用压测 | 自定义 |

### 11.2 Profiler 工具

| 工具 | 层次 | 命令 |
|------|------|------|
| nsys (NVIDIA) | 系统 timeline | `nsys profile --output=xxx python ...` |
| ncu (NVIDIA) | Kernel 细节 | `ncu --set full --kernel-name=xxx python ...` |
| rocprof (ROCm/DCU) | 两者都有 | `rocprof --stats python ...` |
| PyTorch Profiler | Op 级 | 代码内 `with profile(...)` |
| nvidia-smi dmon | GPU 利用率 | `nvidia-smi dmon -s u` |
| rocm-smi (DCU) | 同上 | `rocm-smi --showuse` |

### 11.3 监控工具

| 工具 | 用途 |
|------|------|
| Prometheus + Grafana | 时序指标存储 + 可视化 |
| vLLM metrics endpoint | `http://localhost:8000/metrics` |
| DCGM exporter | NVIDIA GPU 指标 |
| AMD GPU exporter | DCU 指标 |

### 11.4 调试工具

| 工具 | 用途 |
|------|------|
| cuda-gdb | CUDA 代码调试 |
| rocgdb (ROCm) | HIP 代码调试 |
| py-spy | Python 性能分析 |
| gdb | C++ 调试 |

---

## 12. 常见误区

### 12.1 "优化就是写 kernel"

错。写 kernel 占真实工作 < 10%。大部分是调参 + profiling。

### 12.2 "优化前不看现状"

接到需求就开干，结果基线都没建。**没有基线的优化都是耍流氓**。

### 12.3 "只看平均延迟"

平均 200ms 但 P99 1.2s，用户感知是"偶尔很卡"。**SLO 永远看 P99**。

### 12.4 "一次改多个"

同时调 3 个参数，性能提升 20%，但不知道哪个有效，下次还想复用。**一次只改一个**。

### 12.5 "profile 影响性能无所谓"

ncu `--set full` 让 kernel 慢 10x，测出的吞吐完全不准。**测吞吐时别开重 profile**。

### 12.6 "上线就完事"

没监控没回滚，出问题手忙脚乱。**上线只是开始，盯一周才算完**。

### 12.7 "不复盘"

做完就忘，下次踩同样的坑。**复盘是个人成长的关键**。

---

## 13. 给新人的建议

### 13.1 前 3 个月

- **不要急于写 kernel**：先吃透 vLLM 配置和 profiler
- **每周末跑一次完整 benchmark**：建立"什么改动有什么效果"的直觉
- **读 vLLM issue 区**：看别人踩的坑，比书上学得快

### 13.2 3-12 个月

- **主动接小优化需求**：从调参型开始练手
- **学一个 profiling 工具到精通**：nsys 或 ncu 选一个深入
- **给 vLLM 提一个 PR**：哪怕修文档也算，建立开源贡献

### 13.3 1 年后

- **能独立 handle 一个完整优化需求**：从摸底到上线
- **开始关注分布式 / PD 分离等架构级优化**
- **带新人**：教是最好的学

---

## 14. 学习路径建议

1. **读本文一遍**：建立全局认知
2. **跑 [benchmark_serving.py](../10_inference_engine/python/benchmark_serving.py)**：理解 benchmark 怎么写
3. **学 [19_nsight_lab.md](19_nsight_lab.md)**：掌握 profiler
4. **找一个真实 vLLM 服务**：用本文流程跑一遍 baseline → profile
5. **改一个参数**：完整走一遍"实施→验证"流程
6. **写复盘**：哪怕没上线，也按复盘模板写一份

---

## 15. 速查表

### 优化机会排查清单

```
□ vLLM 版本是不是最新? (升级可能白嫖 10%+)
□ max-num-seqs 合理吗? (太小浪费 GPU, 太大 preemption)
□ gpu-memory-utilization 调到 0.9 了吗?
□ 开了 chunked prefill 吗?
□ 开了 prefix caching 吗? (多轮对话场景)
□ KV cache 量化了吗? (FP8 / INT8)
□ 模型本身量化了吗? (AWQ / GPTQ)
□ preemption 频繁吗? (监控 vllm:num_preemption)
□ 有没有不必要的 H2D 拷贝?
□ CUDA stream 用满了吗?
□ TP / PP 配置合理吗?
□ 长尾请求有特殊处理吗?
```

### 接到需求的第一反应

```
1. 问清目标 (延迟? 吞吐? 显存? SLO 是多少?)
2. 要历史监控数据
3. 跑 baseline benchmark
4. nsys profile 找瓶颈
5. 列候选方案 (至少 3 个)
6. 从低难度方案开始试
7. 每次只改一个变量
8. 验证性能 + 正确性
9. 灰度上线 + 监控
10. 写复盘
```
