﻿# EAGLE 投机解码实战

> 这是 2024-2026 加速比最高的投机解码方案，vLLM 和 SGLang 都原生支持。代表加速比：3-5x。
>
> 学习定位：**理解 EAGLE 的训练流程、推理流程、Tree Attention 实现，能在 vLLM 中启用 EAGLE 并调参**。
>
> 前置知识：[16_speculative_decoding.md](16_speculative_decoding.md)（投机解码基础）、[04_attention_kv_cache.md](04_attention_kv_cache.md)。

---

## 0. 回顾：为什么需要 EAGLE

朴素投机解码的痛点：
- 要单独训练/部署一个 draft 模型
- Draft 模型和 target 模型不同源，接受率低（30-50%）
- KV Cache 在两个模型之间不能共享

EAGLE 的核心改进：**用 target 模型自己的 hidden state 训练一个轻量 draft head**，让 draft 和 target "同源"。

效果：
- 接受率 70-90%
- 加速比 3-5x
- 部署简单（draft head 权重加载到 target 模型里）

---

## 1. EAGLE 原理深入

### 1.1 关键洞察：hidden state 比 token id 信息更丰富

回顾 LLM 的 forward：

```
token_id → embedding → [transformer layers] → hidden_state → LM_head → logits → token_id
```

朴素投机解码的 draft 模型输入是 **token id**，要重新走一遍 embedding + transformer。这有两个问题：
1. Draft 模型的 embedding 和 target 不一样
2. Token id 是离散的，丢失了 target 模型在 hidden state 里累积的信息

EAGLE 的洞察：**直接把 target 模型的 hidden state 喂给 draft head**。这样：
- Draft head 看到的就是 target "思考过程"的精炼
- 不需要重新 embedding
- 信息密度更高 → 接受率更高

### 1.2 EAGLE 架构

```
Target 模型 forward:
  token_t → hidden_t (从倒数第二层取)

Draft head 输入:
  [hidden_{t-1}, hidden_t] + [embedding(token_{t-1}), embedding(token_t)]
  ↓
  Draft transformer (1-2 层, 轻量)
  ↓
  hidden_{t+1}^draft
  ↓
  Draft LM head (和 target 共享)
  ↓
  token_{t+1}^draft (草稿)
```

关键设计：
1. **输入拼接**：hidden state + token embedding 一起喂
2. **Draft transformer**：1-2 层 transformer，参数量约为 target 的 1/100
3. **共享 LM head**：draft 和 target 用同一个 LM head，确保 logits 空间一致
4. **共享 embedding**：draft 和 target 用同一个 embedding table

### 1.3 自回归生成草稿

EAGLE 的 draft head 是真正的自回归模型，可以生成多步：

```
Step 1: 输入 [h_{t-1}, h_t] → draft → h_{t+1}^draft → token_{t+1}^draft
Step 2: 输入 [h_t, h_{t+1}^draft] → draft → h_{t+2}^draft → token_{t+2}^draft
Step 3: 输入 [h_{t+1}^draft, h_{t+2}^draft] → draft → h_{t+3}^draft → token_{t+3}^draft
...
```

每一步用上一步的 draft hidden state 作为输入，自回归推进。这是 EAGLE 比 Medusa 准的关键 —— Medusa 的每个头独立预测，越往后越不准。

### 1.4 Tree Attention 验证

EAGLE 生成的草稿不是线性序列，而是**树形结构**：

```
位置 t+1: 候选 [A, B, C]   (top-3 from draft)
位置 t+2: 每个候选拓展 top-2 → [A-D, A-E, B-F, B-G, C-H, C-I]
位置 t+3: 继续拓展 ...
```

为什么用树而不是线性：
- 草稿 top-1 不一定对，top-2/3 可能才是 target 真正生成的
- 树形并行验证所有路径，一次前向就能算完
- 接受最长合法前缀

**Tree Attention 的实现**：
- 把树展开成一个"虚拟序列"
- 用特殊的因果 mask：每个位置只能看到它的祖先路径
- 一次前向算完所有候选

```
Tree:           展开成序列:    Tree Causal Mask:
   root                         [A, D, E, B, F, G, C, H, I]    1=可见 0=不可见
  / | \                                                      A D E B F G C H I
 A  B  C                                                    A 1 0 0 0 0 0 0 0
/|\ /|\ /|\                                                 D 1 1 0 0 0 0 0 0
D E F G H I                                                  E 1 0 1 0 0 0 0 0
                                                            B 0 0 0 1 0 0 0 0
                                                            F 0 0 0 1 1 0 0 0
                                                            ...
```

### 1.5 EAGLE-2：动态草稿树

EAGLE-1 用固定形状的树（如深度 4，每层 top-3）。EAGLE-2 改进：
- **动态树形**：根据每步 draft 的置信度调整
- 高置信度路径多扩展
- 低置信度路径剪枝

效果：同样的验证开销下，接受长度从 ~3.8 提升到 ~4.5。

---

## 2. EAGLE 训练流程

### 2.1 数据准备

用 target 模型在语料上跑一遍，记录：
- 每个 token 的 hidden state（倒数第二层）
- 每个 token 的下一个 token（ground truth）

```python
# 伪代码: 准备训练数据
def prepare_training_data(target_model, corpus):
    data = []
    for text in corpus:
        token_ids = tokenizer(text, return_tensors="pt").input_ids
        with torch.no_grad():
            outputs = target_model(token_ids, output_hidden_states=True)
        # hidden_states[-2] 是倒数第二层
        hidden = outputs.hidden_states[-2]
        # 每个位置的下一个 token 就是 input_ids[1:]
        for t in range(len(token_ids) - 1):
            data.append({
                "hidden_t": hidden[t],
                "hidden_t_plus_1": hidden[t+1],  # 训练目标
                "token_t": token_ids[t],
                "token_t_plus_1": token_ids[t+1],
            })
    return data
```

### 2.2 训练 draft head

```python
class EagleDraftHead(nn.Module):
    def __init__(self, hidden_size, num_layers=2):
        super().__init__()
        # 1-2 层 transformer
        self.layers = nn.ModuleList([
            TransformerLayer(hidden_size) for _ in range(num_layers)
        ])
        # 共享的 LM head (训练时从 target 复制)
        self.lm_head = None  # 加载 target 的
    
    def forward(self, hidden_history, token_embedding_history):
        # 拼接 hidden 和 token embedding
        x = torch.cat([hidden_history, token_embedding_history], dim=-1)
        x = self.proj(x)  # 降维回 hidden_size
        for layer in self.layers:
            x = layer(x)
        return x  # 输出 hidden_state,再过 lm_head 得到 logits
```

训练 loss：交叉熵，让 draft 预测的下一个 token 和 ground truth 一致。

### 2.3 训练成本

- 数据：1B-10B token 的语料（用 target 跑一遍）
- 训练：单卡 1-3 天（draft head 小）
- 不需要 RL，纯监督学习

---

## 3. vLLM 启用 EAGLE 实战

### 3.1 准备 EAGLE 权重

EGLAE 权重通常是社区训练好的，HuggingFace 上有：

```
yuhuili/EAGLE-LLaMA3-Instruct-8B
yuhuili/EAGLE-Vicuna-7B-v1.3
yuhuili/EAGLE-LLaVA-NeXT-8B
```

### 3.2 启动 vLLM with EAGLE

```bash
vllm serve meta-llama/Llama-3-8B-Instruct \
    --speculative-model "yuhuili/EAGLE-LLaMA3-Instruct-8B" \
    --num-speculative-tokens 4 \
    --speculative-draft-tensor-parallel-size 1 \
    --tensor-parallel-size 1 \
    --port 8000
```

关键参数：
- `--speculative-model`: EAGLE 权重路径
- `--num-speculative-tokens`: 草稿深度（推荐 3-5）
- `--speculative-draft-tensor-parallel-size`: draft head 的 TP 数（通常 1）

### 3.3 监控接受率

vLLM 暴露的指标：

```
vllm:num_speculative_tokens     # 草稿 token 总数
vllm:num_accepted_tokens        # 被接受的 token 数
vllm:speculative_acceptance_rate # 接受率
```

日志里也能看到：

```
INFO: Speculative acceptance rate: 0.78 (7842/10050)
```

### 3.4 调参建议

| 参数 | 调优建议 |
|------|---------|
| `num_speculative_tokens` | 3-5 之间，太小收益少，太大拒绝率高 |
| Draft 模型选择 | 必须和 target 同家族（Llama → EAGLE-LLaMA） |
| Batch 大小 | 小 batch 收益大，大 batch 收益小（target 已经吃满算力） |
| 输出长度 | 长输出收益大（首 token 不受益） |

---

## 4. EAGLE 简化实现（教学版）

下面是一个**纯教学**的 EAGLE 实现，帮助你理解流程。真实系统会优化 100 倍。

```python
"""
EAGLE 简化教学版 - 仅演示流程
真实实现见 vllm/attention/spec_decode/eagle.py
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple


class SimpleEagleDraftHead(nn.Module):
    """
    EAGLE Draft Head 简化版
    
    真实 EAGLE 用 1-2 层 transformer,这里用 1 层简化
    输入: hidden_state + token_embedding (拼接)
    输出: 下一个 hidden_state (再过 LM head 得到 logits)
    """
    
    def __init__(self, hidden_size: int, vocab_size: int):
        super().__init__()
        # 输入投影: 把拼接的 [hidden, embedding] 降维回 hidden_size
        # 输入维度 = 2 * hidden_size (hidden + embedding)
        self.input_proj = nn.Linear(2 * hidden_size, hidden_size, bias=False)
        
        # 简化的 1 层 transformer (真实 EAGLE 用 2 层 + 多头注意力)
        self.attn = nn.MultiheadAttention(hidden_size, num_heads=4, batch_first=True)
        self.norm1 = nn.LayerNorm(hidden_size)
        self.ffn = nn.Sequential(
            nn.Linear(hidden_size, hidden_size * 4),
            nn.GELU(),
            nn.Linear(hidden_size * 4, hidden_size),
        )
        self.norm2 = nn.LayerNorm(hidden_size)
        
        # 共享的 LM head (训练时从 target 复制)
        self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)
    
    def forward(
        self,
        hidden_states: torch.Tensor,        # [seq, hidden]
        token_embeddings: torch.Tensor,     # [seq, hidden]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        返回:
            draft_hidden: 预测的下一个 hidden_state [seq, hidden]
            draft_logits: 预测的下一个 token logits [seq, vocab]
        """
        # 1. 拼接 hidden 和 token embedding
        x = torch.cat([hidden_states, token_embeddings], dim=-1)  # [seq, 2*hidden]
        x = self.input_proj(x)  # [seq, hidden]
        
        # 2. 简化的 transformer 层
        # Self-attention (这里简化,真实 EAGLE 用 causal mask)
        attn_out, _ = self.attn(x, x, x)
        x = self.norm1(x + attn_out)
        
        # FFN
        ffn_out = self.ffn(x)
        x = self.norm2(x + ffn_out)
        
        # 3. 输出 hidden_state
        draft_hidden = x
        
        # 4. 过 LM head 得到 logits
        draft_logits = self.lm_head(draft_hidden)  # [seq, vocab]
        
        return draft_hidden, draft_logits


def eagle_speculative_step(
    target_model,
    draft_head,
    input_ids: torch.Tensor,           # [1, seq_len] 当前已生成
    target_hidden: torch.Tensor,       # [1, seq_len, hidden] target 倒数第二层
    embedding_layer: nn.Embedding,
    draft_length: int = 4,
    top_k: int = 3,
) -> torch.Tensor:
    """
    执行一轮 EAGLE 投机解码
    
    返回: 这轮生成的 token (1 个或多个)
    """
    device = input_ids.device
    batch_size, seq_len = input_ids.shape
    
    # ===== Step 1: Draft head 自回归生成 draft_length 个草稿 token =====
    draft_tokens_list = []
    draft_hidden_list = []
    
    # 初始: 用 target 最后一层的 hidden state
    cur_hidden = target_hidden[:, -1:, :]  # [1, 1, hidden]
    cur_token_emb = embedding_layer(input_ids[:, -1:])  # [1, 1, hidden]
    
    for step in range(draft_length):
        # Draft forward
        with torch.no_grad():
            draft_h, draft_logits = draft_head(cur_hidden, cur_token_emb)
        # draft_h: [1, 1, hidden]
        # draft_logits: [1, 1, vocab]
        
        # 取 top-k 候选 (这里简化只取 top-1,真实 EAGLE 用树)
        next_token = draft_logits[0, -1].argmax().unsqueeze(0).unsqueeze(0)  # [1, 1]
        draft_tokens_list.append(next_token)
        draft_hidden_list.append(draft_h)
        
        # 更新输入
        cur_hidden = draft_h
        cur_token_emb = embedding_layer(next_token)
    
    draft_tokens = torch.cat(draft_tokens_list, dim=1)  # [1, draft_length]
    
    # ===== Step 2: Target 一次前向验证 =====
    # 把 input_ids 和 draft_tokens 拼起来,一次 forward
    verify_input = torch.cat([input_ids, draft_tokens], dim=1)  # [1, seq + draft_length]
    
    with torch.no_grad():
        target_outputs = target_model(verify_input, output_hidden_states=True)
    
    # 取验证位置的 logits (从 seq_len 开始)
    target_logits = target_outputs.logits[:, seq_len-1:-1, :]  # [1, draft_length, vocab]
    target_probs = F.softmax(target_logits, dim=-1)
    
    # 取 target 的 hidden state (供下一轮 EAGLE 用)
    new_target_hidden = target_outputs.hidden_states[-2]  # [1, seq + draft_length, hidden]
    
    # ===== Step 3: 逐个验证 =====
    draft_probs = F.softmax(
        draft_head(torch.cat(draft_hidden_list, dim=1),
                   embedding_layer(draft_tokens))[1],
        dim=-1
    )
    
    accepted_tokens = []
    for i in range(draft_length):
        d_token = draft_tokens[0, i].item()
        p = target_probs[0, i, d_token].item()
        q = draft_probs[0, i, d_token].item()
        
        # 接受概率 = min(1, p/q)
        accept_prob = min(1.0, p / max(q, 1e-8))
        
        if torch.rand(1).item() < accept_prob:
            # 接受
            accepted_tokens.append(d_token)
        else:
            # 拒绝,从 target 重新采样
            corrected = torch.clamp(target_probs[0, i] - draft_probs[0, i], min=0)
            corrected = corrected / corrected.sum()
            new_token = torch.multinomial(corrected, 1).item()
            accepted_tokens.append(new_token)
            break
    
    # 如果所有 draft 都被接受,bonus 多生成一个 (target 在最后一个位置的预测)
    if len(accepted_tokens) == draft_length:
        bonus_token = target_logits[0, -1].argmax().item()
        accepted_tokens.append(bonus_token)
    
    return torch.tensor(accepted_tokens, device=device).unsqueeze(0)
```

**注意**：上面是教学版，省略了：
- Tree attention（实际 EAGLE 用树形并行验证）
- KV Cache 管理（草稿 KV 要单独维护）
- Per-sample 处理（batch 内异步）
- 数值稳定性（log probs 而不是 probs）

---

## 5. EAGLE 性能数据

### 5.1 论文报告数据

| Target 模型 | Draft 模型 | 加速比 | 接受长度 | 场景 |
|------------|----------|-------|---------|------|
| LLaMA-2-7B | EAGLE | 2.7x | 3.16 | MT-bench |
| LLaMA-2-13B | EAGLE | 2.9x | 3.42 | MT-bench |
| LLaMA-2-70B | EAGLE | 3.3x | 3.94 | MT-bench |
| Vicuna-7B | EAGLE-2 | 3.7x | 4.5 | MT-bench |

### 5.2 实际部署数据（参考）

在 A100 80GB 上跑 Llama-3-8B-Instruct：

| 配置 | TPOT | 吞吐 | 显存 |
|------|------|-----|------|
| 普通 decode | 45ms | 22 tok/s | 16GB |
| EAGLE (num_spec=3) | 18ms | 55 tok/s | 18GB |
| EAGLE (num_spec=5) | 14ms | 70 tok/s | 20GB |
| EAGLE-2 (num_spec=4) | 12ms | 80 tok/s | 20GB |

### 5.3 何时收益最大

EAGLE 加速比对**小 batch decode** 最明显：
- batch=1 时加速 3-5x（decode 是 memory-bound，投机能用闲算力）
- batch=32 时加速 1.2-1.5x（target 已经吃满算力，投机没空间）

所以 EAGLE 适合：
- 低延迟单请求场景（聊天助手）
- 中等并发（10-50 用户）
- 长输出场景（首 token 不受益）

---

## 6. EAGLE 与其他方法对比

| 方法 | 需要 draft | 训练成本 | 加速比 | 接受长度 |
|------|---------|---------|-------|---------|
| 朴素 Speculative | ✅ 单独模型 | ❌ | 1.5-2x | 2.0 |
| Medusa | ❌ 多头 | ✅ 训练头 | 2-2.5x | 3.0 |
| EAGLE | ❌ 轻量 draft | ✅ 训练 draft | 3-4x | 3.8 |
| EAGLE-2 | ❌ 轻量 draft | ✅ 训练 draft | 3.5-4.5x | 4.5 |
| Lookahead | ❌ | ❌ | 1.5-2x | - |

EAGLE 在性能和工程复杂度之间是最好的平衡。

---

## 7. 常见问题

### 7.1 EAGLE 没有加速反而变慢

可能原因：
- `num_speculative_tokens` 太大（拒绝率高，浪费算力）
- Draft 模型和 target 不匹配（不同家族）
- Batch 太大（target 已经吃满算力）
- 短输出场景（首 token 不受益，prefill 占比大）

排查：
```bash
# 看接受率
curl http://localhost:8000/metrics | grep speculative
```
接受率 < 30% 说明配置有问题。

### 7.2 EAGLE 显存增加多少

Draft head 通常占 target 的 1-5% 参数。Llama-3-8B 的 EAGLE head 约 200MB。
加上草稿 KV Cache（draft_length × layers × heads × dim），总增加约 1-3 GB。

### 7.3 EAGLE 支持量化模型吗

支持。EAGLE draft head 用 FP16，target 可以是 AWQ/GPTQ 量化。混合精度 OK。

### 7.4 EAGLE 支持多卡吗

支持。`--speculative-draft-tensor-parallel-size` 控制 draft 的 TP 数，可以和 target 不同。

---

## 8. 学习路径建议

1. **跑 vLLM EAGLE demo** → 直观感受加速
2. **跑 [05_attention/python/eagle_speculative_demo.py](../05_attention/python/eagle_speculative_demo.py)** → 理解流程
3. **读 EAGLE 论文** → 理解训练和推理细节
4. **读 vLLM `spec_decode/` 源码** → 看工业实现
5. **对比 EAGLE 和 Medusa** → 用同样模型跑两种方案
6. **调 `num_speculative_tokens`** → 看接受率和加速比变化

---

## 9. 延伸阅读

- EAGLE 论文：Li et al., 2024 "EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty"
- EAGLE-2 论文：2024
- EAGLE GitHub: `https://github.com/SafeAILab/EAGLE`
- vLLM EAGLE 文档: `https://docs.vllm.ai/en/latest/features/spec_decode.html`

---

## 10. 速查表

| 项目 | EAGLE |
|------|-------|
| Draft 模型 | 轻量 transformer (1-2 层) |
| Draft 输入 | hidden_state + token_embedding |
| 共享组件 | LM head + embedding |
| Tree 验证 | ✅ (EAGLE-1 固定树, EAGLE-2 动态树) |
| 训练成本 | 单卡 1-3 天 |
| 加速比 | 3-5x |
| 接受率 | 70-90% |
| 适合场景 | 中小 batch, 长输出 |
| vLLM 支持 | ✅ |
| SGLang 支持 | ✅ |
