"""
fused_relu_matmul_jit.py — JIT 编译版本 fused ReLU + MatMul

和 setup.py 编译的区别：
    setup.py 安装后永久可用
    JIT 编译在每次运行时编译，适合原型验证

用法：
    python fused_relu_matmul_jit.py
"""

import torch
import torch.nn.functional as F
from torch.utils.cpp_extension import load_inline

# CUDA kernel 源码（含朴素 + Tiled 两个版本）
cuda_source = """
// 朴素版本：每个线程算一个元素，无 shared memory
__global__ void fused_relu_matmul_forward_kernel(
    const float* __restrict__ A,
    const float* __restrict__ B,
    float* __restrict__ C,
    int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            float a_val = A[row * K + k];
            float relu_a = a_val > 0.0f ? a_val : 0.0f;
            sum += relu_a * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}

// Tiled 版本：shared memory 分块
__global__ void fused_relu_matmul_tiled_kernel(
    const float* __restrict__ A, const float* __restrict__ B,
    float* __restrict__ C, int M, int K, int N
) {
    __shared__ float As[16][16];
    __shared__ float Bs[16][17];  // +1 padding 避免 bank conflict

    int row = blockIdx.y * 16 + threadIdx.y;
    int col = blockIdx.x * 16 + threadIdx.x;
    float sum = 0.0f;
    int num_tiles = (K + 15) / 16;

    for (int tile = 0; tile < num_tiles; ++tile) {
        if (row < M && tile * 16 + threadIdx.x < K) {
            float a_val = A[row * K + tile * 16 + threadIdx.x];
            As[threadIdx.y][threadIdx.x] = a_val > 0.0f ? a_val : 0.0f;
        } else {
            As[threadIdx.y][threadIdx.x] = 0.0f;
        }
        if (tile * 16 + threadIdx.y < K && col < N) {
            Bs[threadIdx.y][threadIdx.x] = B[(tile * 16 + threadIdx.y) * N + col];
        } else {
            Bs[threadIdx.y][threadIdx.x] = 0.0f;
        }
        __syncthreads();
        for (int k = 0; k < 16; ++k) {
            sum += As[threadIdx.y][k] * Bs[k][threadIdx.x];
        }
        __syncthreads();
    }
    if (row < M && col < N) {
        C[row * N + col] = sum;
    }
}

// 反向：dL/dA = (dL/dC @ B^T) * ReLU'(A)
__global__ void fused_relu_matmul_backward_A_kernel(
    const float* __restrict__ dL_dC, const float* __restrict__ B,
    const float* __restrict__ A, float* __restrict__ dL_dA,
    int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < M && col < K) {
        float sum = 0.0f;
        for (int n = 0; n < N; ++n) {
            sum += dL_dC[row * N + n] * B[col * N + n];
        }
        dL_dA[row * K + col] = sum * (A[row * K + col] > 0.0f ? 1.0f : 0.0f);
    }
}

// 反向：dL/dB = ReLU(A)^T @ dL/dC
__global__ void fused_relu_matmul_backward_B_kernel(
    const float* __restrict__ A, const float* __restrict__ dL_dC,
    float* __restrict__ dL_dB, int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < K && col < N) {
        float sum = 0.0f;
        for (int m = 0; m < M; ++m) {
            float a_val = A[m * K + row];
            sum += (a_val > 0.0f ? a_val : 0.0f) * dL_dC[m * N + col];
        }
        dL_dB[row * N + col] = sum;
    }
}
"""

cpp_source = """
torch::Tensor fused_relu_matmul_forward(torch::Tensor A, torch::Tensor B) {
    int M = A.size(0), K = A.size(1), N = B.size(1);
    auto C = torch::empty({M, N}, A.options());
    dim3 block(16, 16);
    dim3 grid((N + 15) / 16, (M + 15) / 16);
    fused_relu_matmul_forward_kernel<<<grid, block>>>(
        A.data_ptr<float>(), B.data_ptr<float>(), C.data_ptr<float>(), M, K, N);
    return C;
}

torch::Tensor fused_relu_matmul_tiled(torch::Tensor A, torch::Tensor B) {
    int M = A.size(0), K = A.size(1), N = B.size(1);
    auto C = torch::empty({M, N}, A.options());
    dim3 block(16, 16);
    dim3 grid((N + 15) / 16, (M + 15) / 16);
    fused_relu_matmul_tiled_kernel<<<grid, block>>>(
        A.data_ptr<float>(), B.data_ptr<float>(), C.data_ptr<float>(), M, K, N);
    return C;
}

std::vector<torch::Tensor> fused_relu_matmul_backward(
    torch::Tensor A, torch::Tensor B, torch::Tensor dL_dC
) {
    int M = A.size(0), K = A.size(1), N = B.size(1);
    auto dL_dA = torch::empty({M, K}, A.options());
    auto dL_dB = torch::empty({K, N}, B.options());
    dim3 block(16, 16);
    dim3 grid_A((K + 15) / 16, (M + 15) / 16);
    dim3 grid_B((N + 15) / 16, (K + 15) / 16);
    fused_relu_matmul_backward_A_kernel<<<grid_A, block>>>(
        dL_dC.data_ptr<float>(), B.data_ptr<float>(),
        A.data_ptr<float>(), dL_dA.data_ptr<float>(), M, K, N);
    fused_relu_matmul_backward_B_kernel<<<grid_B, block>>>(
        A.data_ptr<float>(), dL_dC.data_ptr<float>(),
        dL_dB.data_ptr<float>(), K, N, M);
    return {dL_dA, dL_dB};
}
"""

# JIT 编译
relu_matmul = load_inline(
    name='fused_relu_matmul_jit',
    cpp_sources=cpp_source,
    cuda_sources=cuda_source,
    functions=['fused_relu_matmul_forward', 'fused_relu_matmul_tiled', 'fused_relu_matmul_backward'],
    verbose=False
)

if __name__ == '__main__':
    M, K, N = 1024, 768, 512
    A = torch.randn(M, K, device='cuda')
    B = torch.randn(K, N, device='cuda')

    # 前向正确性
    C_naive = relu_matmul.fused_relu_matmul_forward(A, B)
    C_tiled = relu_matmul.fused_relu_matmul_tiled(A, B)
    C_ref = torch.mm(F.relu(A), B)

    print(f"Naive vs ref:  max err = {(C_naive - C_ref).abs().max().item():.2e}",
          "PASS" if (C_naive - C_ref).abs().max().item() < 1e-4 else "FAIL")
    print(f"Tiled vs ref:  max err = {(C_tiled - C_ref).abs().max().item():.2e}",
          "PASS" if (C_tiled - C_ref).abs().max().item() < 1e-4 else "FAIL")

    # 反向正确性（检查 grad 计算）
    dL_dC = torch.randn(M, N, device='cuda')
    dA, dB = relu_matmul.fused_relu_matmul_backward(A, B, dL_dC)

    # Torch 参考反向
    A_ref = A.detach().clone().requires_grad_(True)
    B_ref = B.detach().clone().requires_grad_(True)
    C_ref = torch.mm(F.relu(A_ref), B_ref)
    C_ref.backward(dL_dC)

    print(f"dL/dA vs ref:  max err = {(dA - A_ref.grad).abs().max().item():.2e}",
          "PASS" if (dA - A_ref.grad).abs().max().item() < 1e-4 else "FAIL")
    print(f"dL/dB vs ref:  max err = {(dB - B_ref.grad).abs().max().item():.2e}",
          "PASS" if (dB - B_ref.grad).abs().max().item() < 1e-4 else "FAIL")

    # 简单 benchmark
    import time
    for name, fn in [("Naive", relu_matmul.fused_relu_matmul_forward),
                     ("Tiled", relu_matmul.fused_relu_matmul_tiled)]:
        # warmup
        for _ in range(10):
            fn(A, B)
        torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(100):
            fn(A, B)
        torch.cuda.synchronize()
        ms = (time.perf_counter() - start) * 10  # ms per iter
        print(f"{name:5s}: {ms:.2f} ms/iter | "
              f"{2*M*K*N/ms/1e6:.0f} GFLOPs")
