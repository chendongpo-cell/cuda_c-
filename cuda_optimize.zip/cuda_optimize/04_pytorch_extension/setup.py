"""
setup.py — PyTorch C++ CUDA Extension 编译脚本

用法：
    python setup.py install       # 安装到当前 Python 环境
    python setup.py develop       # 开发模式（改代码不用重装）
    pip install -e .              # 同上

前置条件：
    - CUDA Toolkit (nvcc)
    - PyTorch（自动提供 CUDA 工具链）
    - VS Build Tools（Windows）或 g++（Linux）

验证安装：
    python -c "import fused_relu_matmul; print(dir(fused_relu_matmul))"
"""

from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name='fused_relu_matmul',
    ext_modules=[
        CUDAExtension(
            name='fused_relu_matmul',
            sources=['csrc/fused_relu_matmul_kernel.cu'],
            extra_compile_args={
                'cxx': ['-O3'],
                'nvcc': [
                    '-O3',
                    '--use_fast_math',
                    '-lineinfo',
                ]
            }
        )
    ],
    cmdclass={
        'build_ext': BuildExtension
    }
)
