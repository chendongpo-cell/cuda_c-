/*
 * fused_relu_matmul_kernel.cu — fused ReLU + MatMul CUDA kernel
 *
 * 这个文件是 PyTorch C++ Extension 的 CUDA 部分。
 *
 * 功能：
 *   将 ReLU 和 MatMul 融合到一个 kernel 中，减少 global memory 读写。
 *   不使用融合时：T = relu(A), C = T @ B（T 需要写回显存再读回来）
 *   使用融合后：读取 A 时直接在寄存器中做 ReLU，结果立即参与矩阵乘法
 *
 * 推理场景：
 *   vLLM 中的 silu_and_mul、rms_norm 等融合算子都是类似的思路。
 *   融合算子是推理优化最重要的手段之一——减少 kernel launch 和显存访问。
 *
 * 编译：python setup.py install
 */

#include <torch/extension.h>
#include <cuda_runtime.h>

/* ================================================================
 * 1. 朴素 fused ReLU + MatMul Kernel（每个线程算一个元素）
 *
 * C = ReLU(A) @ B     A: [M, K], B: [K, N], C: [M, N]
 *
 * 融合点：读取 A 时立即在寄存器中做 ReLU，结果直接参与累加
 * 不融合则需写 T=ReLU(A) 到显存再读回来，多一次 global memory 读写
 *
 * 问题：B[k * N + col] 是列访问，跨步 N，不合并 ❌
 * ================================================================ */

__global__ void fused_relu_matmul_forward_kernel(
    const float* __restrict__ A,
    const float* __restrict__ B,
    float* __restrict__ C,
    int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            float a_val = A[row * K + k];
            float relu_a = a_val > 0.0f ? a_val : 0.0f;
            sum += relu_a * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}

/* ================================================================
 * 2. Tiled fused ReLU + MatMul（Shared Memory 分块优化）
 *
 * 核心：将 A 和 B 切成 BLOCK_SIZE×BLOCK_SIZE 的 tile，
 *   协同加载到 shared memory，从 shared memory 高速累加。
 *
 * 相比朴素版本：
 *   全局访问从 K 次/元素 → K/BLOCK_SIZE 次/元素
 *   ReLU 在加载 As 时融合，不写中间结果到显存
 *
 * 推理场景：这是 vLLM/SGLang 中 fused kernel 的简化版，
 *   实际用的 cuBLAS 内部有更复杂的寄存器 tiling + warp-level
 * ================================================================ */

template <int BLOCK_SIZE>
__global__ void fused_relu_matmul_tiled_kernel(
    const float* __restrict__ A,
    const float* __restrict__ B,
    float* __restrict__ C,
    int M, int K, int N
) {
    __shared__ float As[BLOCK_SIZE][BLOCK_SIZE];
    __shared__ float Bs[BLOCK_SIZE][BLOCK_SIZE + 1];  // +1 padding 避免 bank conflict

    int row = blockIdx.y * BLOCK_SIZE + threadIdx.y;
    int col = blockIdx.x * BLOCK_SIZE + threadIdx.x;

    float sum = 0.0f;
    int num_tiles = (K + BLOCK_SIZE - 1) / BLOCK_SIZE;

    for (int tile = 0; tile < num_tiles; ++tile) {
        // As 加载时融合 ReLU
        if (row < M && tile * BLOCK_SIZE + threadIdx.x < K) {
            float a_val = A[row * K + tile * BLOCK_SIZE + threadIdx.x];
            As[threadIdx.y][threadIdx.x] = a_val > 0.0f ? a_val : 0.0f;
        } else {
            As[threadIdx.y][threadIdx.x] = 0.0f;
        }

        // Bs 加载
        if (tile * BLOCK_SIZE + threadIdx.y < K && col < N) {
            Bs[threadIdx.y][threadIdx.x] =
                B[(tile * BLOCK_SIZE + threadIdx.y) * N + col];
        } else {
            Bs[threadIdx.y][threadIdx.x] = 0.0f;
        }

        __syncthreads();

        for (int k = 0; k < BLOCK_SIZE; ++k) {
            sum += As[threadIdx.y][k] * Bs[k][threadIdx.x];
        }
        __syncthreads();
    }

    if (row < M && col < N) {
        C[row * N + col] = sum;
    }
}

/* ================================================================
 * 反向 kernel: 计算 dL/dA
 * dL/dA = (dL/dC @ B^T) * ReLU'(A)
 * ReLU'(x) = 1 if x > 0 else 0
 * ================================================================ */

__global__ void fused_relu_matmul_backward_A_kernel(
    const float* __restrict__ dL_dC,
    const float* __restrict__ B,
    const float* __restrict__ A,
    float* __restrict__ dL_dA,
    int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < K) {
        float sum = 0.0f;
        for (int n = 0; n < N; ++n) {
            sum += dL_dC[row * N + n] * B[col * N + n];
        }
        float relu_grad = A[row * K + col] > 0.0f ? 1.0f : 0.0f;
        dL_dA[row * K + col] = sum * relu_grad;
    }
}

/* ================================================================
 * 反向 kernel: 计算 dL/dB
 * dL/dB = ReLU(A)^T @ dL/dC
 * ================================================================ */

__global__ void fused_relu_matmul_backward_B_kernel(
    const float* __restrict__ A,
    const float* __restrict__ dL_dC,
    float* __restrict__ dL_dB,
    int M, int K, int N
) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < K && col < N) {
        float sum = 0.0f;
        for (int m = 0; m < M; ++m) {
            float a_val = A[m * K + row];
            float relu_a = a_val > 0.0f ? a_val : 0.0f;
            sum += relu_a * dL_dC[m * N + col];
        }
        dL_dB[row * N + col] = sum;
    }
}

/* ================================================================
 * C++ Wrapper — pybind11 绑定入口
 * ================================================================ */

static void check_tensors(torch::Tensor A, torch::Tensor B) {
    TORCH_CHECK(A.device().is_cuda(), "A must be CUDA tensor");
    TORCH_CHECK(B.device().is_cuda(), "B must be CUDA tensor");
    TORCH_CHECK(A.dim() == 2 && B.dim() == 2, "Inputs must be 2D");
    TORCH_CHECK(A.size(1) == B.size(0), "Inner dims must match");
    TORCH_CHECK(A.is_contiguous(), "A must be contiguous");
    TORCH_CHECK(B.is_contiguous(), "B must be contiguous");
}

// 朴素版本（逐元素，无 shared memory）
torch::Tensor fused_relu_matmul_forward(
    torch::Tensor A, torch::Tensor B
) {
    check_tensors(A, B);
    int M = A.size(0), K = A.size(1), N = B.size(1);
    auto C = torch::empty({M, N}, A.options());

    dim3 block(16, 16);
    dim3 grid((N + 15) / 16, (M + 15) / 16);
    fused_relu_matmul_forward_kernel<<<grid, block>>>(
        A.data_ptr<float>(), B.data_ptr<float>(),
        C.data_ptr<float>(), M, K, N);
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    return C;
}

// Tiled 版本（shared memory 分块，推荐）
torch::Tensor fused_relu_matmul_tiled(
    torch::Tensor A, torch::Tensor B
) {
    check_tensors(A, B);
    int M = A.size(0), K = A.size(1), N = B.size(1);
    auto C = torch::empty({M, N}, A.options());

    dim3 block(16, 16);
    dim3 grid((N + 15) / 16, (M + 15) / 16);
    fused_relu_matmul_tiled_kernel<16><<<grid, block>>>(
        A.data_ptr<float>(), B.data_ptr<float>(),
        C.data_ptr<float>(), M, K, N);
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    return C;
}

std::vector<torch::Tensor> fused_relu_matmul_backward(
    torch::Tensor A, torch::Tensor B, torch::Tensor dL_dC
) {
    check_tensors(A, B);
    TORCH_CHECK(dL_dC.device().is_cuda(), "dL_dC must be CUDA tensor");
    TORCH_CHECK(dL_dC.is_contiguous(), "dL_dC must be contiguous");

    int M = A.size(0), K = A.size(1), N = B.size(1);
    auto dL_dA = torch::empty({M, K}, A.options());
    auto dL_dB = torch::empty({K, N}, B.options());

    dim3 block(16, 16);
    dim3 grid_A((K + 15) / 16, (M + 15) / 16);
    dim3 grid_B((N + 15) / 16, (K + 15) / 16);

    fused_relu_matmul_backward_A_kernel<<<grid_A, block>>>(
        dL_dC.data_ptr<float>(), B.data_ptr<float>(),
        A.data_ptr<float>(), dL_dA.data_ptr<float>(),
        M, K, N);
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    fused_relu_matmul_backward_B_kernel<<<grid_B, block>>>(
        A.data_ptr<float>(), dL_dC.data_ptr<float>(),
        dL_dB.data_ptr<float>(), K, N, M);
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    return {dL_dA, dL_dB};
}

/* ================================================================
 * pybind11 绑定
 * ================================================================ */

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &fused_relu_matmul_forward,
          "Fused ReLU + MatMul forward (naive)");
    m.def("forward_tiled", &fused_relu_matmul_tiled,
          "Fused ReLU + MatMul forward (tiled, recommended)");
    m.def("backward", &fused_relu_matmul_backward,
          "Fused ReLU + MatMul backward");
}
