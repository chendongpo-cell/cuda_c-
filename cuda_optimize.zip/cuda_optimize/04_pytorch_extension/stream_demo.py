"""
=========================================================================
文件名: stream_demo.py
说明: CUDA Stream/Event 异步执行模式深度演示
功能:
  1. CUDA Stream 基本使用: 多个 stream 并发执行
  2. CUDA Event 用于同步和计时
  3. 异步数据传输 (pinned memory + non_blocking)
  4. 计算和传输重叠: 生产者-消费者模式
  5. 基准测试: stream vs 非 stream
=========================================================================

学习目标:
  - 理解 CUDA Stream 作为异步执行队列的概念
  - 掌握 PyTorch 中 CUDA Stream/Event 的 API
  - 学会使用 pinned memory 实现异步传输
  - 理解计算-传输重叠对吞吐的提升
  - 了解 vLLM 中多 stream 的使用模式
"""

import torch
import time
from typing import List, Tuple, Optional


# =========================================================================
# 1. CUDA Stream 和 Event 基础
# =========================================================================

def stream_basics():
    """
    CUDA Stream 基础演示

    CUDA Stream 是 GPU 上的异步操作队列:
    - 同一 stream 中的操作按提交顺序执行 (FIFO)
    - 不同 stream 中的操作可以并发执行 (需支持)
    - 默认 stream (stream 0) 是所有 CUDA 操作的默认队列

    类比理解:
        CPU: 单线程 = 默认 stream, 多线程 = 多 stream
        Stream 就像一个独立的 GPU 工作线程
    """

    print("=" * 70)
    print("CUDA Stream 基础")
    print("=" * 70)

    if not torch.cuda.is_available():
        print("CUDA 不可用, 跳过演示")
        return

    # ---- 获取当前默认 stream ----
    # 每个 CUDA 设备都有一个默认 stream
    # 所有未指定 stream 的操作都在默认 stream 上执行
    default_stream = torch.cuda.current_stream()
    print(f"默认 stream: {default_stream}")
    print(f"  设备: {default_stream.device}")
    print(f"  stream ID: {default_stream.cuda_stream}")

    # ---- 创建新的 stream ----
    # 创建普通 stream
    s1 = torch.cuda.Stream()                    # 默认优先级 (0)
    s2 = torch.cuda.Stream()                    # 另一个 stream

    # 创建高优先级 stream
    # 优先级范围: -1 (最高) 到 0 (默认)
    # 高优先级 stream 的任务可能被调度器优先执行
    s_high = torch.cuda.Stream(priority=-1)

    print(f"\n普通 stream s1: {s1}")
    print(f"高优先级 stream: {s_high} (priority={s_high.priority})")

    # ---- 使用 stream context ----
    # 方法1: with 语句 (推荐)
    # 在此 context 中的 CUDA 操作都提交到 s1
    with torch.cuda.stream(s1):
        a1 = torch.randn(1000, 1000, device='cuda')
        b1 = torch.randn(1000, 1000, device='cuda')
        c1 = torch.mm(a1, b1)  # 这个 matmul 提交到 s1

    # 方法2: 手动设置 stream (不推荐, 容易出错)
    # torch.cuda.set_stream(s2)
    # a2 = torch.randn(1000, 1000, device='cuda')
    # torch.cuda.set_stream(default_stream)

    # ---- stream 同步 ----
    # 默认情况下, CPU 不会等待 GPU 操作完成
    # 如果需要等待, 可以:
    # 1. 同步指定 stream
    s1.synchronize()
    print(f"\ns1 同步完成")

    # 2. 同步所有 stream (最重度的同步)
    torch.cuda.synchronize()
    print("所有 stream 同步完成")

    # ---- 验证 stream 独立性 ----
    print("\n验证 stream 独立性...")

    # 分配大张量, 确保有足够的计算量
    size = 2000

    # 在多 stream 上执行
    streams = [torch.cuda.Stream() for _ in range(4)]

    for i, s in enumerate(streams):
        with torch.cuda.stream(s):
            # 每个 stream 执行独立的矩阵乘法
            a = torch.randn(size, size, device='cuda')
            b = torch.randn(size, size, device='cuda')
            c = torch.mm(a, b)  # 这是计算密集型操作

    # 等待所有完成
    torch.cuda.synchronize()
    print("所有 stream 上的计算完成")

    # 注意: 真正的并行取决于 GPU 硬件能力
    # 不是所有 GPU 都支持多 stream 真正的并发执行
    # 需要足够的计算资源和独立的硬件队列


# =========================================================================
# 2. CUDA Event 同步和计时
# =========================================================================

def event_demo():
    """
    CUDA Event 演示: 同步和精确计时

    CUDA Event 的作用:
    1. 记录 stream 中某个时间点
    2. 用于 stream 间同步 (类似 barrier)
    3. 精确测量 GPU 端执行时间 (排除 CPU dispatch 开销)

    注意:
        CUDA Event 测量的是 GPU 端的实际执行时间
        比 CPU 端 time.time() 测量更准确
        不受 CPU 调度和上下文切换影响
    """

    print("\n" + "=" * 70)
    print("CUDA Event 同步和计时")
    print("=" * 70)

    if not torch.cuda.is_available():
        print("CUDA 不可用, 跳过演示")
        return

    # ---- 创建 Event ----
    # enable_timing=True 才能用于计时
    # blocking=True 会阻塞 CPU 等待 event (通常不推荐)
    start_event = torch.cuda.Event(enable_timing=True)
    end_event = torch.cuda.Event(enable_timing=True)

    # ---- 精确计时 ----
    print("\n使用 CUDA Event 精确计时:")

    # 记录开始时间点
    start_event.record()

    # 需要测量的操作
    size = 4096
    a = torch.randn(size, size, device='cuda')
    b = torch.randn(size, size, device='cuda')

    # 执行矩阵乘法
    c = torch.mm(a, b)

    # 对结果做 softmax (增加操作数)
    c = torch.softmax(c, dim=1)

    # 记录结束时间点
    end_event.record()

    # 同步等待: 等待 GPU 完成
    torch.cuda.synchronize()

    # 计算耗时 (毫秒)
    elapsed_ms = start_event.elapsed_time(end_event)
    print(f"  矩阵乘法 + softmax: {elapsed_ms:.2f} ms")

    # ---- 与 CPU 计时对比 ----
    print("\nCPU 计时 vs CUDA Event 计时:")
    t0 = time.time()
    c2 = torch.mm(a, b)
    c2 = torch.softmax(c2, dim=1)
    torch.cuda.synchronize()
    t1 = time.time()
    cpu_ms = (t1 - t0) * 1000

    print(f"  CPU time.time(): {cpu_ms:.2f} ms")
    print(f"  CUDA Event:      {elapsed_ms:.2f} ms")
    print(f"  差异: {abs(cpu_ms - elapsed_ms):.2f} ms (CPU 包含 dispatch 开销)")

    # ---- Stream 间同步 ----
    print("\nStream 间同步 (使用 Event):")

    stream_a = torch.cuda.Stream()
    stream_b = torch.cuda.Stream()

    # 创建 event 用于 stream 间通信
    sync_event = torch.cuda.Event()

    # Stream A: 执行计算, 完成后记录 event
    with torch.cuda.stream(stream_a):
        data = torch.randn(3000, 3000, device='cuda')
        result_a = torch.mm(data, data.t())
        sync_event.record()  # 在 stream A 中记录 event

    # Stream B: 等待 Stream A 的 event, 然后使用结果
    # 这建立了 stream A → stream B 的 happens-before 关系
    with torch.cuda.stream(stream_b):
        stream_b.wait_event(sync_event)  # B 等待 A 完成
        # 此时可以安全使用 result_a
        result_b = torch.mm(result_a, result_a)

    # 等待所有完成
    torch.cuda.synchronize()
    print("  Stream A→B 同步完成 ✓")

    # 解释: 不使用 event 的话, stream B 可能在 A 完成前就
    # 读取 result_a, 导致数据竞争


# =========================================================================
# 3. 异步数据传输 (Pinned Memory + non_blocking)
# =========================================================================

def async_transfer_demo():
    """
    异步数据传输演示

    关键概念:
    1. 锁页内存 (Pinned Memory):
       - 物理内存中被锁定、不会被换出到磁盘的页
       - GPU 可以通过 DMA 直接访问, 无需 CPU 中转
       - 是异步传输的前提条件

    2. non_blocking=True:
       - 使 copy_() 操作异步执行
       - 函数立即返回, 传输在后台进行
       - CPU 可以继续执行其他工作

    3. 传输 vs 计算重叠:
       - 在传输数据的同时, GPU 可以执行其他计算
       - 这是提高吞吐量的关键技术
    """

    print("\n" + "=" * 70)
    print("异步数据传输 (Pinned Memory + non_blocking)")
    print("=" * 70)

    if not torch.cuda.is_available():
        print("CUDA 不可用, 跳过演示")
        return

    # ---- 创建 pinned memory ----
    print("\n创建锁页内存...")

    data_size = 1024 * 1024 * 256  # 256M float = 1GB

    # 创建普通 CPU tensor (pageable memory)
    # 这种内存的物理页可以被 OS 换出
    host_regular = torch.randn(data_size)

    # 创建锁页 CPU tensor (pinned memory)
    # 这种内存的物理页被锁定, 不会被换出
    # GPU 可以直接通过 DMA 访问
    host_pinned = torch.randn(data_size).pin_memory()

    # 验证 pinned 状态
    print(f"  普通内存 pinned?: {host_regular.is_pinned()}")   # False
    print(f"  锁页内存 pinned?: {host_pinned.is_pinned()}")    # True

    # 创建 GPU tensor
    gpu_tensor = torch.empty(data_size, device='cuda')

    # ---- 同步传输 vs 异步传输 ----
    print("\n同步传输 vs 异步传输:")

    # 同步传输 (blocking)
    # copy_() 默认 non_blocking=False
    # CPU 会等待传输完成才返回
    t0 = time.time()
    gpu_tensor.copy_(host_pinned, non_blocking=False)  # 同步
    torch.cuda.synchronize()
    t1 = time.time()
    sync_time = (t1 - t0) * 1000
    print(f"  同步传输: {sync_time:.1f} ms")

    # 异步传输 (non-blocking)
    # copy_(non_blocking=True) 立即返回
    # 传输在后台进行, CPU 可以继续工作
    t0 = time.time()
    gpu_tensor.copy_(host_pinned, non_blocking=True)   # 异步, 立即返回
    # CPU 可以在这里做其他工作!
    cpu_work = sum(range(1000000))  # CPU 计算
    torch.cuda.synchronize()        # 等待传输完成
    t1 = time.time()
    async_time = (t1 - t0) * 1000
    print(f"  异步传输 (含 CPU 计算): {async_time:.1f} ms")

    # ---- 传输带宽估算 ----
    print("\n传输带宽估算:")

    data_bytes = data_size * 4  # float32 = 4 bytes
    bandwidth = data_bytes / sync_time * 1000 / 1e9  # GB/s
    print(f"  数据量: {data_bytes / 1e9:.2f} GB")
    print(f"  传输时间: {sync_time:.1f} ms")
    print(f"  估算带宽: {bandwidth:.1f} GB/s")

    # 注意: 实际带宽受 PCIe 版本和 lane 数限制
    # PCIe 4.0 x16: ~32 GB/s
    # PCIe 3.0 x16: ~16 GB/s


# =========================================================================
# 4. 核心: 计算与传输重叠
# =========================================================================

def compute_transfer_overlap():
    """
    计算与传输重叠的完整实现

    这是异步传输的核心应用场景:
    - 双缓冲 (double buffering) 模式
    - 一个 buffer 在 GPU 上计算时
    - 另一个 buffer 正在从 CPU 传输到 GPU
    - 实现流水线: 传输和计算完全重叠

    时间线对比:

    无重叠 (串行):
      Batch 0: [传输]   [计算]
      Batch 1:           [传输]   [计算]
      Batch 2:                    [传输]   [计算]
      Total:  T = 3 * (传输 + 计算)

    有重叠 (流水线):
      Batch 0: [传输]   [计算]
      Batch 1:          [传输]   [计算]
      Batch 2:                   [传输]   [计算]
      Total:  T = 传输 + 3 * 计算
               (第一个传输 + N * 计算)
    节省: (N-1) * 传输时间
    """

    print("\n" + "=" * 70)
    print("计算与传输重叠 (双缓冲流水线)")
    print("=" * 70)

    if not torch.cuda.is_available():
        print("CUDA 不可用, 跳过演示")
        return

    # ---- 配置 ----
    num_batches = 8                # 批次数
    batch_size = 4096             # 矩阵维度
    num_warmup = 3                 # 预热次数

    # ---- 准备数据 ----
    # 创建 pinned memory 池 (预分配, 避免运行时分配)
    # 双缓冲: 需要 2 个 buffer 交替使用
    host_buffers = [
        torch.randn(batch_size, batch_size).pin_memory()
        for _ in range(2)        # 2 = 双缓冲
    ]
    gpu_buffers = [
        torch.empty(batch_size, batch_size, device='cuda')
        for _ in range(2)
    ]

    # 权重矩阵 (在 GPU 上, 固定不变)
    weight = torch.randn(batch_size, batch_size, device='cuda')

    # ---- 创建 stream 和 event ----
    # 传输 stream: 负责 CPU → GPU 数据传输
    transfer_stream = torch.cuda.Stream()
    # 计算 stream: 负责 GPU 上执行矩阵乘法
    compute_stream = torch.cuda.Stream()

    # 每个 buffer 对应一个 event, 用于同步
    transfer_done = [torch.cuda.Event() for _ in range(2)]

    # ---- 预热 ----
    print(f"\n预热 ({num_warmup} 次)...")
    for i in range(num_warmup):
        idx = i % 2  # 交替 buffer

        # 异步传输
        with torch.cuda.stream(transfer_stream):
            gpu_buffers[idx].copy_(
                host_buffers[idx], non_blocking=True
            )
            transfer_done[idx].record()

        # 等待后计算
        with torch.cuda.stream(compute_stream):
            compute_stream.wait_event(transfer_done[idx])
            _ = torch.mm(gpu_buffers[idx], weight)

    torch.cuda.synchronize()
    print("预热完成")

    # ---- 基准: 无重叠 (串行执行) ----
    print("\n基准: 无重叠 (串行)")
    serial_results = []

    if torch.cuda.is_available():
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)
        start_event.record()

        for i in range(num_batches):
            idx = i % 2
            # 同步传输
            gpu_buffers[idx].copy_(host_buffers[idx])
            # 计算 (等待传输完成)
            result = torch.mm(gpu_buffers[idx], weight)
            serial_results.append(result)

        end_event.record()
        torch.cuda.synchronize()
        serial_time = start_event.elapsed_time(end_event)
        print(f"  串行总时间: {serial_time:.1f} ms")
        print(f"  每批平均:   {serial_time / num_batches:.1f} ms")

    # ---- 优化: 有重叠 (流水线) ----
    print("\n优化: 计算与传输重叠 (流水线)")

    if torch.cuda.is_available():
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)
        start_event.record()

        for i in range(num_batches):
            idx = i % 2  # 双缓冲切换

            # Step 1: 在传输 stream 上启动异步拷贝
            # non_blocking=True → 立即返回
            # 传输与上一步的计算可以并行
            with torch.cuda.stream(transfer_stream):
                gpu_buffers[idx].copy_(
                    host_buffers[idx], non_blocking=True
                )
                # 记录传输完成事件
                transfer_done[idx].record()

            # Step 2: 在计算 stream 上等待传输完成
            # 然后执行计算
            with torch.cuda.stream(compute_stream):
                compute_stream.wait_event(transfer_done[idx])
                result = torch.mm(gpu_buffers[idx], weight)

            # 实际流水线执行时序:
            # iter 0: [传输 buffer0] [计算 buffer0]
            # iter 1:                [传输 buffer1] [计算 buffer1]
            # iter 2:                               [传输 buffer0] [计算 buffer0]
            # ...
            # 传输和计算完全重叠!

        end_event.record()
        torch.cuda.synchronize()
        overlap_time = start_event.elapsed_time(end_event)
        print(f"  流水线总时间: {overlap_time:.1f} ms")
        print(f"  每批平均:     {overlap_time / num_batches:.1f} ms")

        # ---- 加速比 ----
        speedup = serial_time / overlap_time
        print(f"\n  加速比: {speedup:.2f}x")
        print(f"  节省时间: {serial_time - overlap_time:.1f} ms ({(1 - overlap_time/serial_time)*100:.1f}%)")
    else:
        overlap_time = 0

    # ---- 理论分析 ----
    print("\n理论分析:")
    print(f"  批次数 N = {num_batches}")
    print(f"  如果传输时间 ≈ 计算时间, 理论上限: ~2x 加速")
    print(f"  如果传输时间 < 计算时间, 加速比接近 (传输+计算)/计算")
    print(f"  如果传输时间 > 计算时间, 受限于 PCIe 带宽")

    return serial_time, overlap_time


# =========================================================================
# 5. 多 Stream 并发计算
# =========================================================================

def multi_stream_compute():
    """
    多 Stream 并发计算演示

    适用场景:
    - 多个独立的小矩阵乘法
    - 不同的计算可以在不同 stream 上并行
    - 需要足够的 GPU 计算资源 (SM 数量)

    不适用场景:
    - 单个大矩阵乘法 (已经被一个 stream 占满 GPU)
    - 有数据依赖的计算
    - 小 batch 推理 (kernel launch 已经是瓶颈)
    """

    print("\n" + "=" * 70)
    print("多 Stream 并发计算")
    print("=" * 70)

    if not torch.cuda.is_available():
        print("CUDA 不可用, 跳过演示")
        return

    num_streams = 4
    matrix_size = 2048
    num_ops = 8  # 总操作数 (每个 stream 分配 num_ops/num_streams 个)

    # ---- 方法 1: 单 stream (串行) ----
    print(f"\n单 stream (串行) — {num_ops} 个 matmul")

    if torch.cuda.is_available():
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)

        start_event.record()
        for _ in range(num_ops):
            a = torch.randn(matrix_size, matrix_size, device='cuda')
            b = torch.randn(matrix_size, matrix_size, device='cuda')
            c = torch.mm(a, b)
        end_event.record()
        torch.cuda.synchronize()
        single_stream_time = start_event.elapsed_time(end_event)
        print(f"  总时间: {single_stream_time:.1f} ms")
        print(f"  平均:   {single_stream_time / num_ops:.1f} ms")

    # ---- 方法 2: 多 stream (并发) ----
    print(f"\n多 stream (并发) — {num_streams} 个 stream, {num_ops} 个 matmul")

    streams = [torch.cuda.Stream() for _ in range(num_streams)]

    if torch.cuda.is_available():
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)

        start_event.record()
        ops_per_stream = num_ops // num_streams

        for s in streams:
            with torch.cuda.stream(s):
                for _ in range(ops_per_stream):
                    a = torch.randn(matrix_size, matrix_size, device='cuda')
                    b = torch.randn(matrix_size, matrix_size, device='cuda')
                    c = torch.mm(a, b)

        end_event.record()
        torch.cuda.synchronize()
        multi_stream_time = start_event.elapsed_time(end_event)
        print(f"  总时间: {multi_stream_time:.1f} ms")
        print(f"  平均:   {multi_stream_time / num_ops:.1f} ms")

        speedup = single_stream_time / multi_stream_time
        print(f"\n  加速比: {speedup:.2f}x")
        print(f"  理想加速比 (4 stream): {min(num_streams, num_ops):.0f}x")

        # 解释结果
        print(f"\n结果分析:")
        if speedup < 1.2:
            print("  - 每个 matmul 已经占满 GPU, 多 stream 无收益")
            print("  - 增加 stream 数量反而增加调度开销")
        elif speedup < 2.0:
            print("  - 部分并行, GPU 资源部分重叠")
            print("  - 可能存在 shared memory 或寄存器压力")
        else:
            print("  - 良好的并行, GPU 资源充分利用")
            print("  - 多个 kernel 同时在 SM 上执行")


# =========================================================================
# 6. 实际应用: Host-Device 数据传输 benchmark
# =========================================================================

def transfer_benchmark():
    """
    数据传输 benchmark: pinned vs pageable, 同步 vs 异步

    用于量化不同传输方式的性能差异
    帮助在实际应用中选择最佳传输策略
    """

    print("\n" + "=" * 70)
    print("数据传输 Benchmark")
    print("=" * 70)

    if not torch.cuda.is_available():
        print("CUDA 不可用, 跳过演示")
        return

    # 测试多种数据大小
    sizes = [
        1024 * 1024,       # 1M → 4MB
        1024 * 1024 * 10,  # 10M → 40MB
        1024 * 1024 * 5,   # 50M → 200MB
        1024 * 1024 * 2,   # 100M → 400MB  (更大的数据可能显存不足)
    ]

    num_trials = 50

    print(f"\n{'数据大小':>12} {'同步(ms)':>12} {'异步(ms)':>12} {'加速比':>10} {'带宽(GB/s)':>12}")
    print("-" * 60)

    for n_elements in sizes:
        data_bytes = n_elements * 4  # float32

        # 创建数据
        host_pinned = torch.randn(n_elements).pin_memory()
        gpu = torch.empty(n_elements, device='cuda')

        # 同步传输
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)

        start.record()
        for _ in range(num_trials):
            gpu.copy_(host_pinned, non_blocking=False)
        end.record()
        torch.cuda.synchronize()
        sync_ms = start.elapsed_time(end) / num_trials

        # 异步传输 (测量实际的传输时间, 不包括 CPU 计算)
        start.record()
        for _ in range(num_trials):
            gpu.copy_(host_pinned, non_blocking=True)
        end.record()
        torch.cuda.synchronize()
        async_ms = start.elapsed_time(end) / num_trials

        # 带宽计算 (使用异步时间, 更准确)
        bandwidth = data_bytes / async_ms * 1000 / 1e9  # GB/s

        speedup = sync_ms / async_ms if async_ms > 0 else 1.0

        size_mb = data_bytes / 1024 / 1024
        print(f"{size_mb:>8.0f} MB {sync_ms:>12.3f} {async_ms:>12.3f} {speedup:>9.2f}x {bandwidth:>11.1f}")

    print("\n结论:")
    print("  1. 异步传输本身带宽与同步相近 (都是 DMA)")
    print("  2. 异步的收益在于 CPU 可以同时做其他工作")
    print("  3. 锁页内存是异步传输的前提")
    print("  4. 实际系统中, 使用异步传输 + 计算重叠可获得 2x+ 吞吐提升")


# =========================================================================
# 7. 完整示例: 带流水线的推理循环
# =========================================================================

def inference_pipeline():
    """
    模拟带流水线的推理循环

    这个示例模拟了 LLM 推理时的数据流:
    1. 从 CPU 读取 batch 数据
    2. 传输到 GPU
    3. 在 GPU 上执行推理
    4. 结果传回 CPU

    使用流水线技术, 将连续 batch 的传输和计算重叠
    """

    print("\n" + "=" * 70)
    print("模拟推理流水线")
    print("=" * 70)

    if not torch.cuda.is_available():
        print("CUDA 不可用, 跳过演示")
        return

    # ---- 模拟推理配置 ----
    batch_size = 4
    seq_len = 512
    hidden_size = 768
    num_layers = 12
    num_batches = 16

    print(f"\n配置:")
    print(f"  batch_size × seq_len × hidden_size = {batch_size} × {seq_len} × {hidden_size}")
    print(f"  transformer layers: {num_layers}")
    print(f"  batches: {num_batches}")

    # ---- 创建模拟模型和数据 ----
    # 模拟一个 transformer layer
    class SimulatedTransformerLayer(torch.nn.Module):
        """模拟的 transformer layer, 包含常用的计算模式"""

        def __init__(self, hidden_size: int):
            super().__init__()
            # self-attention 部分
            self.q_proj = torch.nn.Linear(hidden_size, hidden_size, bias=False)
            self.k_proj = torch.nn.Linear(hidden_size, hidden_size, bias=False)
            self.v_proj = torch.nn.Linear(hidden_size, hidden_size, bias=False)
            self.o_proj = torch.nn.Linear(hidden_size, hidden_size, bias=False)

            # FFN 部分
            self.gate_proj = torch.nn.Linear(hidden_size, hidden_size * 4, bias=False)
            self.up_proj = torch.nn.Linear(hidden_size, hidden_size * 4, bias=False)
            self.down_proj = torch.nn.Linear(hidden_size * 4, hidden_size, bias=False)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            """简化的 transformer layer forward"""
            # Self-attention (简化)
            q = self.q_proj(x)
            k = self.k_proj(x)
            v = self.v_proj(x)
            attn = torch.matmul(q, k.transpose(-2, -1)) / (q.size(-1) ** 0.5)
            attn = torch.softmax(attn, dim=-1)
            attn_out = torch.matmul(attn, v)
            attn_out = self.o_proj(attn_out)
            x = x + attn_out  # residual

            # FFN (简化版 SwiGLU)
            gate = self.gate_proj(x)
            up = self.up_proj(x)
            hidden = torch.silu(gate) * up
            ffn_out = self.down_proj(hidden)
            x = x + ffn_out  # residual

            return x

    # 创建模型
    model = SimulatedTransformerLayer(hidden_size).cuda().eval()

    # 创建 pinned memory 输入输出缓冲区
    input_shape = (batch_size, seq_len, hidden_size)
    pinned_input = torch.zeros(input_shape).pin_memory()
    pinned_output = torch.zeros(input_shape).pin_memory()

    # GPU buffer
    gpu_input = torch.empty(input_shape, device='cuda')
    gpu_output = torch.empty(input_shape, device='cuda')

    # ---- 基准: 串行执行 ----
    print(f"\n基准: 串行执行 (同步传输 + 计算)")
    serial_times = []

    if torch.cuda.is_available():
        for batch_idx in range(num_batches):
            # 模拟生成输入数据
            pinned_input.copy_(torch.randn(input_shape))

            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)

            start.record()

            # 同步传输到 GPU
            gpu_input.copy_(pinned_input)

            # 多次 layer 推理 (模拟多层)
            x = gpu_input
            for _ in range(num_layers):
                x = model(x)

            # 同步传回 CPU
            pinned_output.copy_(x)

            end.record()
            torch.cuda.synchronize()
            serial_times.append(start.elapsed_time(end))

        avg_serial = sum(serial_times) / len(serial_times)
        print(f"  平均每 batch: {avg_serial:.1f} ms")
        print(f"  总时间: {sum(serial_times):.1f} ms")

    # ---- 优化: 流水线 ----
    print(f"\n优化: 流水线 (异步传输 + 计算重叠)")
    pipeline_times = []

    # 创建 stream 和 event
    h2d_stream = torch.cuda.Stream()    # Host → Device
    compute_stream = torch.cuda.Stream() # GPU compute
    d2h_stream = torch.cuda.Stream()    # Device → Host

    h2d_done = torch.cuda.Event()
    compute_done = torch.cuda.Event()

    if torch.cuda.is_available():
        for batch_idx in range(num_batches):
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)

            start.record()

            # Step 1: 异步 H2D 传输
            with torch.cuda.stream(h2d_stream):
                gpu_input.copy_(pinned_input, non_blocking=True)
                h2d_done.record()

            # Step 2: 计算 stream 等待 H2D 完成, 然后计算
            with torch.cuda.stream(compute_stream):
                compute_stream.wait_event(h2d_done)
                x = gpu_input
                for _ in range(num_layers):
                    x = model(x)
                gpu_output.copy_(x)  # 保存结果到输出 buffer
                compute_done.record()

            # Step 3: 异步 D2H 传输
            with torch.cuda.stream(d2h_stream):
                d2h_stream.wait_event(compute_done)
                pinned_output.copy_(gpu_output, non_blocking=True)

            end.record()
            torch.cuda.synchronize()
            pipeline_times.append(start.elapsed_time(end))

        avg_pipeline = sum(pipeline_times) / len(pipeline_times)
        print(f"  平均每 batch: {avg_pipeline:.1f} ms")
        print(f"  总时间: {sum(pipeline_times):.1f} ms")

        # ---- 对比 ----
        speedup = sum(serial_times) / sum(pipeline_times)
        print(f"\n总加速比: {speedup:.2f}x")

        # 流水线的实际收益:
        # 连续 batch 之间, 传输和计算重叠
        # 第一个 batch 的传输 + 后续 batch 的(传输+计算并行)

    # ---- 总结 ----
    print("\n" + "-" * 50)
    print("流水线推理的关键点:")
    print("  1. 使用 pinned memory 实现异步传输")
    print("  2. 使用 3 个 stream: H2D, Compute, D2H")
    print("  3. 使用 Event 实现 stream 间同步")
    print("  4. 连续 batch 的传输和计算重叠")
    print("  5. 双缓冲或三缓冲避免 buffer 冲突")
    print()
    print("  vLLM 中的实际应用:")
    print("    - 请求输入的异步加载")
    print("    - KV cache 的异步管理")
    print("    - 输出 logits 的异步回传")
    print("    - 多 GPU 推理的通信重叠")


# =========================================================================
# 8. 主程序入口
# =========================================================================

if __name__ == "__main__":
    """
    运行所有 CUDA Stream/Event 演示

    使用方法:
        python stream_demo.py

    注意:
        - 需要 CUDA GPU
        - 某些演示需要较大的显存 (建议 8GB+)
        - 结果因 GPU 型号而异
    """
    print("PyTorch 版本:", torch.__version__)
    print("CUDA 可用:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("CUDA 设备:", torch.cuda.get_device_name(0))
        print("显存总量:", torch.cuda.get_device_properties(0).total_memory / 1e9, "GB")
        print("CUDA 版本:", torch.version.cuda)

    # 运行所有演示
    stream_basics()
    event_demo()
    async_transfer_demo()
    compute_transfer_overlap()
    multi_stream_compute()
    transfer_benchmark()
    inference_pipeline()

    print("\n" + "=" * 70)
    print("所有演示完成!")
    print("=" * 70)
