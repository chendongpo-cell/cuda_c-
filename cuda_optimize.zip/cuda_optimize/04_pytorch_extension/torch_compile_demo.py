"""
=========================================================================
文件名: torch_compile_demo.py
说明: torch.compile() 深入理解与性能对比
功能:
  1. torch.compile 与 eager mode 性能对比
  2. 不同后端 (inductor, cudagraphs) 对比
  3. Graph Break 检测与分析
  4. 动态 shape 对编译性能的影响
=========================================================================

学习目标:
  - 理解 torch.compile 的三阶段: Dynamo → Inductor → Triton
  - 理解 Graph Break 的原因和影响
  - 学会使用 torch.compile 优化推理模型
  - 了解 vLLM 中 torch.compile 的使用模式
"""

import torch
import torch.nn as nn
import time
from typing import List, Optional


# =========================================================================
# 1. 测试模型定义
# =========================================================================

class SimpleMLP(nn.Module):
    """
    简单的 MLP 模型, 用于测试 torch.compile

    结构:
        Linear(768 → 3072) → ReLU → Linear(3072 → 768)

    模拟了 Transformer FFN 层的基本结构:
        - hidden_size = 768 (如 BERT-base)
        - intermediate_size = 3072 (4x hidden_size)
    """

    def __init__(self, hidden_size: int = 768, intermediate_size: int = 3072):
        """
        初始化 MLP 层

        参数:
            hidden_size: 隐藏层维度 (默认 768, 如 BERT-base)
            intermediate_size: FFN 中间维度 (默认 3072, 即 4 * hidden_size)
        """
        super().__init__()
        # 第一层线性变换: 将输入从 hidden_size 映射到 intermediate_size
        self.fc1 = nn.Linear(hidden_size, intermediate_size, bias=False)
        # 第二层线性变换: 将中间表示映射回 hidden_size
        self.fc2 = nn.Linear(intermediate_size, hidden_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播

        Args:
            x: 输入张量 [batch_size, seq_len, hidden_size]

        Returns:
            输出张量 [batch_size, seq_len, hidden_size]
        """
        # MLP 标准结构: 升维 → 激活 → 降维
        x = self.fc1(x)         # [B, S, 768] → [B, S, 3072]
        x = torch.relu(x)       # ReLU 激活
        x = self.fc2(x)         # [B, S, 3072] → [B, S, 768]
        return x


class ModelWithControlFlow(nn.Module):
    """
    包含控制流的模型 — 用于演示 Graph Break

    这个模型故意包含 Python 控制流 (if 语句)
    来展示 torch.compile 如何处理(或不处理)控制流

    背景:
        torch.compile 默认无法处理 Python 原生控制流
        每次遇到控制流都会产生 Graph Break
        Graph Break 之间的每个子图独立编译
    """

    def __init__(self, hidden_size: int = 768):
        """
        初始化

        参数:
            hidden_size: 隐藏层维度
        """
        super().__init__()
        self.fc = nn.Linear(hidden_size, hidden_size)

    def forward(self, x: torch.Tensor, use_gate: bool = False) -> torch.Tensor:
        """
        前向传播 (包含控制流)

        参数:
            x: 输入 [batch_size, hidden_size]
            use_gate: 是否使用门控机制 (Python 控制流!)

        返回:
            输出 [batch_size, hidden_size]

        Graph Break 分析:
            use_gate 是 Python bool, 不是 tensor
            torch.compile 无法将这个 if 语句编译到图中
            因此这里会产生 Graph Break
        """
        x = self.fc(x)  # 第1个子图: 可编译

        # ---- GRAPH BREAK 在这里 ----
        # Dynamo 遇到 Python if 控制流
        # 无法将其捕获到 FX Graph 中
        # 因此在这里断裂成两个子图
        if use_gate:
            # 第2个子图 (if 分支)
            x = x * torch.sigmoid(x)
        else:
            # 第2个子图 (else 分支)
            x = torch.relu(x)
        # ---- 图结束 ----

        # 第3个子图: 可编译
        x = self.fc(x)
        return x


# =========================================================================
# 2. torch.compile 基础用法演示
# =========================================================================

def basic_compile_demo():
    """
    torch.compile 基础用法

    演示 torch.compile 的三种模式:
    1. eager: 默认模式, 不编译
    2. inductor: 默认编译器, 生成 Triton kernel
    3. cudagraphs: CUDA Graphs 模式

    关键概念:
        - torch.compile 返回一个可调用对象
        - 首次调用时会触发编译 (有编译开销)
        - 后续调用使用编译后的 kernel
    """

    print("=" * 70)
    print("torch.compile 基础用法演示")
    print("=" * 70)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"设备: {device}")

    # 创建模型和数据
    model = SimpleMLP(hidden_size=768, intermediate_size=3072).to(device)
    x = torch.randn(1, 128, 768, device=device)  # [batch=1, seq=128, dim=768]

    # ---- 模式 1: Eager (基准) ----
    # 这是 PyTorch 的传统执行模式
    # 每个操作独立 launch CUDA kernel
    # 无优化, 作为性能基准
    model_eager = model  # 直接使用原模型

    # ---- 模式 2: torch.compile (默认 backend=inductor) ----
    # Inductor 是 PyTorch 2.x 的默认编译器
    # 它会将模型编译为 Triton kernel
    # 自动进行 kernel fusion 和其他优化
    model_compiled = torch.compile(model)

    # ---- 模式 3: torch.compile (cudagraphs) ----
    # CUDA Graphs backend
    # 将整个模型捕获为一个 CUDA Graph
    # 消除所有 kernel launch 开销
    # 适用于静态 shape 的推理
    model_cudagraphs = torch.compile(model, backend="cudagraphs")

    # ---- 预热 ----
    # 第一次调用 torch.compile 包含编译时间
    # 预热确保后续测量的是执行时间
    print("\n预热中...")
    for _ in range(5):
        _ = model_eager(x)
        _ = model_compiled(x)
    if device.type == 'cuda':
        torch.cuda.synchronize()

    # ---- 性能测试 ----
    print("\n性能对比:")
    num_iters = 100

    def time_model(model_fn, name: str) -> float:
        """
        测量模型执行时间

        参数:
            model_fn: 模型函数
            name:     模型名称

        返回:
            平均执行时间 (毫秒)
        """
        # CUDA 同步确保之前的操作完成
        if device.type == 'cuda':
            torch.cuda.synchronize()

        # 使用 CUDA event 精确计时
        if device.type == 'cuda':
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(num_iters):
                _ = model_fn(x)
            end.record()
            torch.cuda.synchronize()
            elapsed = start.elapsed_time(end) / num_iters
        else:
            t0 = time.time()
            for _ in range(num_iters):
                _ = model_fn(x)
            t1 = time.time()
            elapsed = (t1 - t0) * 1000 / num_iters

        print(f"  {name:30s}: {elapsed:8.3f} ms")
        return elapsed

    t_eager = time_model(model_eager, "Eager (基准)")
    t_inductor = time_model(model_compiled, "torch.compile (inductor)")

    if device.type == 'cuda':
        t_cudagraphs = time_model(model_cudagraphs, "torch.compile (cudagraphs)")
        print(f"\n加速比 (inductor):   {t_eager / t_inductor:.2f}x")
        print(f"加速比 (cudagraphs):  {t_eager / t_cudagraphs:.2f}x")
    else:
        print(f"\n加速比 (inductor):   {t_eager / t_inductor:.2f}x")

    print("\n" + "-" * 50)
    print("关键观察:")
    print("  1. torch.compile 在 GPU 上通常有 1.2~3x 加速")
    print("  2. cudagraphs 在静态 shape 时效果最好")
    print("  3. 首次调用有编译延迟 (预热阶段)")
    print("  4. 加速主要来自 kernel fusion 和减少 launch 开销")


# =========================================================================
# 3. Graph Break 检测
# =========================================================================

def graph_break_demo():
    """
    演示 Graph Break 的检测和分析

    Graph Break 是 torch.compile 中的重要概念:
    - 当 Dynamo 遇到无法捕获的操作时, 图在此处断裂
    - 断裂处的子图分别编译
    - 过多的 graph break 会降低编译收益

    常见导致 Graph Break 的操作:
    1. Python 控制流 (if/for/while)
    2. print() 等副作用操作
    3. 非 PyTorch 库调用 (numpy, random 等)
    4. 动态数据类型变化
    5. 异常处理 (try/except)
    """

    print("\n" + "=" * 70)
    print("Graph Break 检测与分析")
    print("=" * 70)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = ModelWithControlFlow(hidden_size=768).to(device)
    x = torch.randn(1, 768, device=device)

    # ---- 方法 1: 使用 verbose=True 查看编译过程 ----
    # torch.compile(verbose=True) 会打印详细的编译日志
    # 包括 Dynamo 捕获的子图、graph break 位置等
    print("\n方法 1: verbose=True 查看编译日志")
    print("  (编译日志会输出到 stderr)")
    try:
        compiled_model = torch.compile(model, verbose=True)
        _ = compiled_model(x, use_gate=True)  # 触发编译

        if device.type == 'cuda':
            torch.cuda.synchronize()
    except Exception as e:
        print(f"  verbose 模式错误 (非致命): {e}")

    # ---- 方法 2: 使用 torch._dynamo.explain ----
    # torch._dynamo.explain 返回编译的详细分析
    # 包括 graph break 原因、子图数量等
    print("\n方法 2: torch._dynamo.explain()")
    try:
        # 创建模型的副本用于分析
        model_copy = ModelWithControlFlow(hidden_size=768).to(device)
        model_copy.eval()  # 切换到评估模式

        # 使用 explain 分析
        # 返回一个包含诊断信息的对象
        explanation = torch._dynamo.explain(model_copy, x, use_gate=True)

        # 分析结果
        print(f"  Graph break 次数: {explanation.graph_count}")
        print(f"  子图数量: {explanation.graph_count}")
        print(f"  Graph break 原因: {explanation.break_reasons}")
        print(f"  是否无 break (fullgraph): {explanation.graph_count == 1}")

        # 如果存在 graph break, 输出具体原因
        if explanation.break_reasons:
            print("\n  Graph Break 详情:")
            for i, reason in enumerate(explanation.break_reasons):
                print(f"    Break {i+1}: {reason}")

    except Exception as e:
        print(f"  explain 模式错误: {e}")
        print(f"  (此功能需要 PyTorch 2.1+, 且部分版本可能不兼容)")

    # ---- 方法 3: fullgraph=True 模式 ----
    # fullgraph=True 要求整个函数被编译为一张图
    # 如果有 graph break, 会抛出异常
    print("\n方法 3: fullgraph=True (强制无 break)")
    try:
        # 对无控制流的模型使用 fullgraph
        simple_model = SimpleMLP().to(device)
        simple_x = torch.randn(1, 128, 768, device=device)

        # fullgraph=True: 要求完整图, 不能有 break
        compiled_simple = torch.compile(simple_model, fullgraph=True)
        _ = compiled_simple(simple_x)

        if device.type == 'cuda':
            torch.cuda.synchronize()
        print("  无控制流模型: fullgraph 编译成功 ✓")

        # 对有控制流的模型使用 fullgraph
        print("  尝试对有控制流的模型使用 fullgraph...")
        compiled_ctrl = torch.compile(model, fullgraph=True)
        _ = compiled_ctrl(x, use_gate=True)

        if device.type == 'cuda':
            torch.cuda.synchronize()
        print("  (未触发异常 — 可能在当前版本中控制流被 torch.compile 处理)")

    except Exception as e:
        print(f"  fullgraph 编译失败: {e}")
        print(f"  → 说明模型中存在 Graph Break")

    # ---- 总结: 避免 Graph Break 的最佳实践 ----
    print("\n" + "-" * 50)
    print("避免 Graph Break 的最佳实践:")
    print("  1. 将控制流替换为 torch.where 等向量化操作")
    print("     ❌ if x.sum() > 0: y = x * 2")
    print("     ✅ y = x * (2 + (x.sum() > 0).float())")
    print("  2. 将 for 循环改为 torch.stack + 向量化操作")
    print("  3. 避免在热路径中使用 print(), numpy 等")
    print("  4. 使用 torch.Tensor 方法替代 Python 原生操作")
    print("  5. 对于不可避免的控制流, 使用 @torch.compiler.disable")


# =========================================================================
# 4. 动态 Shape 性能影响
# =========================================================================

def dynamic_shape_demo():
    """
    演示动态 shape 对 torch.compile 性能的影响

    背景:
        - LLM 推理涉及多种序列长度 (变长输入)
        - 静态 shape: 编译后的 kernel 是针对固定 shape 优化的
        - 动态 shape: shape 变化可能导致重新编译

    torch.compile 选项:
        - dynamic=False (默认): 静态 shape, 性能最优
        - dynamic=True: 支持动态 shape, 减少重新编译
        - 也可以使用 shape_padding 将变长补齐到固定长度
    """

    print("\n" + "=" * 70)
    print("动态 Shape 对 torch.compile 的影响")
    print("=" * 70)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 创建一个简单的线性层
    # 注意: 我们使用 nn.Linear 而不是 MLP, 因为 MLP 的编译时间较长
    layer = nn.Linear(768, 3072, bias=False).to(device)

    # 编译这个层
    compiled_layer = torch.compile(layer)

    # 不同的 batch_size, 用于模拟变长输入
    # 在实际 LLM 推理中, batch_size 经常变化
    batch_sizes = [1, 2, 4, 8, 1, 2, 4, 8]

    print("\n测试不同 batch_size 对编译性能的影响:")
    print(f"{'batch_size':>12} {'首次耗时(ms)':>15} {'后续耗时(ms)':>15} {'重新编译':>10}")
    print("-" * 55)

    for bs in batch_sizes:
        x = torch.randn(bs, 768, device=device)

        # 首次调用 (可能触发编译)
        if device.type == 'cuda':
            start_event = torch.cuda.Event(enable_timing=True)
            end_event = torch.cuda.Event(enable_timing=True)

            start_event.record()
            _ = compiled_layer(x)
            end_event.record()
            torch.cuda.synchronize()
            first_time = start_event.elapsed_time(end_event)

            # 第二次调用 (应该命中缓存)
            start_event.record()
            _ = compiled_layer(x)
            end_event.record()
            torch.cuda.synchronize()
            second_time = start_event.elapsed_time(end_event)
        else:
            t0 = time.time()
            _ = compiled_layer(x)
            t1 = time.time()
            first_time = (t1 - t0) * 1000

            t0 = time.time()
            _ = compiled_layer(x)
            t1 = time.time()
            second_time = (t1 - t0) * 1000

        # 判断是否重新编译: 首次时间 > 后续时间 * 10 认为触发了编译
        recompile = "是" if first_time > second_time * 10 else "否"

        print(f"{bs:>12} {first_time:>15.3f} {second_time:>15.3f} {recompile:>10}")

    # 使用 dynamic=True 测试
    print("\n使用 dynamic=True:")
    compiled_dynamic = torch.compile(layer, dynamic=True)

    for bs in [1, 4, 1, 4]:
        x = torch.randn(bs, 768, device=device)

        if device.type == 'cuda':
            start_event = torch.cuda.Event(enable_timing=True)
            end_event = torch.cuda.Event(enable_timing=True)
            start_event.record()
            _ = compiled_dynamic(x)
            end_event.record()
            torch.cuda.synchronize()
            t = start_event.elapsed_time(end_event)
        else:
            t0 = time.time()
            _ = compiled_dynamic(x)
            t1 = time.time()
            t = (t1 - t0) * 1000

        print(f"  batch_size={bs:>2}: {t:.3f} ms")

    print("\n" + "-" * 50)
    print("观察结果:")
    print("  1. 首次遇到新 shape 通常会触发重新编译")
    print("  2. 重新编译的开销较大 (可能 100ms+ )")
    print("  3. dynamic=True 减少重新编译, 但 kernel 可能不是最优")
    print("  4. 生产环境常用策略:")
    print("     - shape padding: 统一到固定长度")
    print("     - CUDA Graphs: 录制一次, 重复执行")
    print("     - vLLM 使用多个 CUDA Graph, 每个 shape 一个")


# =========================================================================
# 5. torch.compile 进阶选项
# =========================================================================

def advanced_options_demo():
    """
    演示 torch.compile 的高级配置选项

    这些选项对推理优化很重要:
    - max_autotune: 自动搜索最佳 tile 大小
    - epilogue_fusion: 融合 epilogue 操作 (如 bias add)
    - mode: 预配置的优化模式
    """

    print("\n" + "=" * 70)
    print("torch.compile 高级配置")
    print("=" * 70)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if device.type != 'cuda':
        print("CUDA 不可用, 跳过高级选项演示")
        return

    model = SimpleMLP().to(device)
    x = torch.randn(1, 128, 768, device=device)

    # ---- mode 参数 ----
    # torch.compile 提供预设的优化模式
    modes = {
        "default":    {},                                       # 平衡模式
        "max-autotune": {"mode": "max-autotune"},               # 最大优化, 编译慢
        "reduce-overhead": {"mode": "reduce-overhead"},         # 减少 kernel launch
    }

    print("\n不同 mode 对比:")
    for mode_name, kwargs in modes.items():
        try:
            compiled = torch.compile(model, **kwargs)
            _ = compiled(x)
            torch.cuda.synchronize()
            print(f"  {mode_name:20s}: 编译成功 ✓")
        except Exception as e:
            print(f"  {mode_name:20s}: 编译失败 - {e}")

    # ---- 常见 options ----
    print("\n常用配置说明:")
    print("  mode='max-autotune':")
    print("    - 自动搜索最优的 block/tile 大小")
    print("    - 编译时间显著增加, 但 kernel 性能最优")
    print("    - 适合生产环境部署前的最终优化")
    print()
    print("  mode='reduce-overhead':")
    print("    - 减少小 kernel 的 launch 开销")
    print("    - 对小模型/小 batch 效果明显")
    print("    - 通过 kernel fusion 合并小操作")
    print()
    print("  options={'epilogue_fusion': True}:")
    print("    - 融合 epilogue 操作 (如 bias, activation)")
    print("    - 默认已开启")
    print()
    print("  options={'max_autotune': True}:")
    print("    - 等效于 mode='max-autotune'")
    print("    - 搜索最佳配置")


# =========================================================================
# 6. vLLM 中的 torch.compile 应用
# =========================================================================

def vllm_compile_pattern():
    """
    演示 vLLM 中 torch.compile 的典型使用模式

    vLLM 对 torch.compile 的使用策略:
    1. 对 transformer layer 进行 compile
    2. 使用 CUDA Graphs 固定计算图
    3. 对不同序列长度维护多个 graph

    伪代码模式:
        class VLLMModel:
            def __init__(self):
                # 编译核心 layer
                self.transformer = torch.compile(
                    self.transformer,
                    mode="reduce-overhead",
                    fullgraph=True
                )

            def forward(self, input_ids):
                # 在推理循环中调用编译后的 layer
                # CUDA Graph replay 在此发生
                return self.transformer(input_ids)
    """

    print("\n" + "=" * 70)
    print("vLLM 中的 torch.compile 模式")
    print("=" * 70)

    print("""
典型 vLLM 编译策略:
  1. 只编译性能关键的 transformer layer
  2. 使用 CUDA Graphs 消除 kernel launch 开销
  3. 对常见序列长度分别录制 graph
  4. 变长输入通过 padding 统一到固定长度

代码模式:
    # 在 __init__ 中编译
    self.model = torch.compile(
        self.model,
        mode="reduce-overhead",
        fullgraph=True,
        dynamic=False,        # 静态 shape 性能最优
    )

    # 在推理循环中
    for batch in dataloader:
        # 对 batch 做 padding 到固定长度
        padded_input = pad_to_length(batch, target_len)
        output = self.model(padded_input)  # CUDA graph replay
        # 截取实际输出
        actual_output = output[:, :batch.real_len, :]
    """)


# =========================================================================
# 7. 主程序: 运行所有演示
# =========================================================================

if __name__ == "__main__":
    """
    运行所有 torch.compile 演示

    顺序:
    1. 基础用法: eager vs compile vs cudagraphs
    2. Graph Break 检测
    3. 动态 shape 性能影响
    4. 高级配置选项
    5. vLLM 模式

    注意:
        - 首次运行会触发编译, 可能较慢
        - 结果因 GPU 型号和 PyTorch 版本而异
    """
    print("PyTorch 版本:", torch.__version__)
    print("CUDA 可用:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("CUDA 设备:", torch.cuda.get_device_name(0))
        print("CUDA 版本:", torch.version.cuda)

    # 运行各演示
    basic_compile_demo()

    # Graph break 检测需要较新版本的 PyTorch
    # 在旧版本中可能部分功能不可用
    try:
        graph_break_demo()
    except Exception as e:
        print(f"\nGraph Break 演示出错 (版本兼容问题): {e}")
        print("跳过此演示...")

    dynamic_shape_demo()
    advanced_options_demo()
    vllm_compile_pattern()

    print("\n" + "=" * 70)
    print("所有演示完成!")
    print("=" * 70)
