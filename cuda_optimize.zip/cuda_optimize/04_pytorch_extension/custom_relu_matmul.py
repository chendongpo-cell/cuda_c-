﻿"""
=========================================================================
文件名: custom_relu_matmul.py
说明: PyTorch 自定义 autograd Function — 融合 ReLU + MatMul
功能:
  1. 自定义 autograd.Function 实现 fused ReLU + MatMul
  2. 详细注释解释每行代码的作用
  3. 基准测试 vs 原生 PyTorch 实现
=========================================================================

融合算子原理:
  标准实现: t = relu(x); y = t @ w  →  中间 tensor t 写回 global memory
  融合实现: y = fused_relu_matmul(x, w)  →  ReLU 结果在寄存器/共享内存中直接传给 MatMul

  vLLM/SGLang 等推理引擎中大量使用此类融合模式:
    - silu_and_mul: 融合激活函数和乘法
    - rms_norm: 融合归一化
    - fused_attention: 融合 attention 的所有步骤
"""

import torch
import torch.nn as nn
import time
from typing import Tuple, Optional


# =========================================================================
# 1. 自定义 autograd.Function
# =========================================================================

class FusedReLUMatMul(torch.autograd.Function):
    """
    融合 ReLU + MatMul 的自定义 autograd Function

    数学定义:
        forward:  y = ReLU(x) @ W
        backward: dL/dx = (dL/dy @ W^T) * ReLU'(x)
                  dL/dW = ReLU(x)^T @ dL/dy

    为什么融合:
        在标准实现中, ReLU(x) 的结果需要写回 GPU 显存
        然后在 MatMul 时再读出来 → 浪费带宽
        融合后 ReLU 结果直接在计算单元中传递给 MatMul

    适用场景:
        Transformer FFN 层中的激活 + 线性变换
        MLP 块中的激活函数和权重矩阵乘法
    """

    @staticmethod
    def forward(
        ctx: torch.autograd.function.FunctionCtx,
        x: torch.Tensor,       # 输入: [batch_size, in_features]
        w: torch.Tensor,       # 权重: [in_features, out_features]
    ) -> torch.Tensor:
        """
        前向传播: y = ReLU(x) @ w

        参数:
            ctx: autograd context, 用于保存反向传播需要的中间结果
            x:   输入张量, shape [M, K]
            w:   权重张量, shape [K, N]

        返回:
            y:   输出张量, shape [M, N]

        注意:
            我们保存了原始 x 而不是 ReLU(x) 的结果
            因为反向时需要 ReLU 的梯度 (即 x > 0 的 mask)
            如果只保存 ReLU(x), 反向时无法判断 x 的正负
        """
        # ---- 输入验证 ----
        # 确保输入维度匹配: x 的列数必须等于 w 的行数
        assert x.dim() == 2, f"输入 x 必须是 2D 张量, 但得到了 {x.dim()}D"
        assert w.dim() == 2, f"权重 w 必须是 2D 张量, 但得到了 {w.dim()}D"
        assert x.size(1) == w.size(0), \
            f"维度不匹配: x.shape[1]={x.size(1)} != w.shape[0]={w.size(0)}"

        # ---- 保存反向传播需要的数据 ----
        # save_for_backward 只接受 tensor, 且必须成对保存
        # 保存 x 用于计算 ReLU 梯度; 保存 w 用于计算 dL/dx
        ctx.save_for_backward(x, w)

        # ---- 前向计算 ----
        # Step 1: 计算 ReLU(x) = max(0, x)
        # torch.relu 会分配一个中间 tensor 存储结果
        # 但我们不能避免这个分配, 因为 MatMul 需要完整的 ReLU(x)
        relu_x = torch.relu(x)          # [M, K], ReLU 激活后的值

        # Step 2: 计算 ReLU(x) @ w
        # torch.mm 执行矩阵乘法, 生成输出
        y = torch.mm(relu_x, w)         # [M, N], 最终输出

        return y

    @staticmethod
    def backward(
        ctx: torch.autograd.function.FunctionCtx,
        grad_y: torch.Tensor,   # 上游梯度 dL/dy, shape [M, N]
    ) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
        """
        反向传播: 计算 dL/dx 和 dL/dw

        参数:
            ctx:    autograd context, 通过 ctx.saved_tensors 获取保存的变量
            grad_y: 上游梯度, 即 loss 对输出 y 的偏导

        返回:
            grad_x: dL/dx, shape [M, K], 与 x 形状相同
                    如果 x 不需要梯度则返回 None
            grad_w: dL/dw, shape [K, N], 与 w 形状相同
                    如果 w 不需要梯度则返回 None

        数学推导:
            y = ReLU(x) @ w

            令 r = ReLU(x), 则 y = r @ w

            dL/dx = dL/dy * dy/dx
                   = dL/dy * (dr/dx @ w)
                   = (dL/dy @ w^T) * ReLU'(x)
                   其中 ReLU'(x) = 1 if x > 0 else 0

            dL/dw = dL/dy * dy/dw
                   = r^T @ dL/dy
                   = ReLU(x)^T @ dL/dy
        """
        # ---- 获取前向保存的变量 ----
        # ctx.saved_tensors 返回一个 tuple, 顺序与 save_for_backward 一致
        x, w = ctx.saved_tensors           # x: [M, K], w: [K, N]

        # ---- 计算 grad_x: dL/dx = (dL/dy @ W^T) * ReLU'(x) ----
        # Step 1: 计算 dL/dy @ w^T
        # grad_y @ w^T = [M, N] @ [N, K] = [M, K]
        # 这个 matmul 是必要的: 将梯度从输出空间传播到输入空间
        grad_x = torch.mm(grad_y, w.t())   # [M, K], 未经过 ReLU 梯度的中间结果

        # Step 2: 应用 ReLU 的梯度 (即 x > 0 的位置梯度保留, 否则为 0)
        # (x > 0) 是 ReLU 的导数, 即阶梯函数
        # float() 将布尔 mask 转为 float32, 用于乘法
        grad_x = grad_x * (x > 0).float()  # [M, K], 最终的 dL/dx

        # ---- 计算 grad_w: dL/dw = ReLU(x)^T @ dL/dy ----
        # ReLU(x)^T @ dL/dy = [K, M] @ [M, N] = [K, N]
        # 注意这里又调用了 torch.relu, 因为前向没有保存 ReLU(x) 的结果
        # 这是空间换时间的 trade-off:
        #   - 保存 ReLU(x): 节省一次前向计算, 多占显存
        #   - 不保存 ReLU(x): 节省显存, 多一次计算
        # 在训练场景中通常选择保存 (计算更贵)
        # 在推理场景中不需要 backward, 所以无所谓
        grad_w = torch.mm(torch.relu(x).t(), grad_y)  # [K, N]

        # ---- 返回梯度 ----
        # 返回顺序与 forward 参数顺序一致: (grad_x, grad_w)
        # 如果输入不需要梯度, 可以返回 None
        # 这里我们总是返回计算好的梯度, PyTorch 会自动处理
        return grad_x, grad_w


# =========================================================================
# 2. 包装为更方便使用的 nn.Module
# =========================================================================

class FusedReLUMatMulLayer(nn.Module):
    """
    将自定义 autograd Function 包装为 nn.Module

    这样做的好处:
    1. 可以像普通 PyTorch 层一样使用
    2. 方便集成到更大的模型中
    3. 便于参数管理

    用法:
        layer = FusedReLUMatMulLayer(in_features=768, out_features=3072)
        y = layer(x)  # 自动使用自定义 autograd Function
    """

    def __init__(self, in_features: int, out_features: int):
        """
        初始化层

        参数:
            in_features:  输入特征维度
            out_features: 输出特征维度
        """
        super().__init__()

        # 创建权重参数
        # nn.Parameter 自动注册为 module 的参数
        # requires_grad=True (默认) 表示需要计算梯度
        self.weight = nn.Parameter(
            torch.randn(in_features, out_features) * 0.01
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播: 使用自定义 FusedReLUMatMul Function

        通过 Function.apply() 调用自定义 autograd 操作
        apply 是静态方法, 它会:
        1. 调用 forward()
        2. 在计算图中创建一个 grad_fn 节点
        3. 返回结果 tensor (带有 grad_fn)
        """
        return FusedReLUMatMul.apply(x, self.weight)


# =========================================================================
# 3. 基准测试: 自定义 fused vs 原生 PyTorch
# =========================================================================

def benchmark():
    """
    基准测试: 对比自定义 fused 算子和原生 PyTorch 实现

    测试内容:
    1. 前向性能: 计算时间
    2. 反向性能: 梯度计算时间
    3. 端到端: 前向 + 反向
    4. 正确性验证

    预期结果:
        - 前向: fused 和原生时间相近 (因为我们的 fused 实现不是真正的 CUDA fusion)
        - 反向: 相近
        - 真正的性能提升需要在 CUDA kernel 级别实现融合

    注意:
        这里的 fused 实现演示的是 autograd.Function 的用法
        真正的性能提升需要配合自定义 CUDA kernel
        见 docs/03_pytorch_extension.md 中的 CUDA kernel 实现
    """

    print("=" * 70)
    print("基准测试: Fused ReLU + MatMul vs 原生 PyTorch")
    print("=" * 70)

    # 测试配置
    M = 1024       # batch_size (或序列长度)
    K = 768        # 输入特征维度 (如 hidden_size)
    N = 3072       # 输出特征维度 (如 FFN intermediate size)
    num_warmup = 10   # 预热次数 (消除 CUDA 初始化开销)
    num_iters = 100   # 测试次数

    # 确定设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\n测试设备: {device}")
    print(f"矩阵维度: M={M}, K={K}, N={N}")
    print(f"迭代次数: warmup={num_warmup}, benchmark={num_iters}")

    # ---- 创建测试数据 ----
    # 使用固定的随机种子以确保可重复性
    torch.manual_seed(42)
    x = torch.randn(M, K, device=device, requires_grad=True)
    w = torch.randn(K, N, device=device, requires_grad=True)

    # ---- 正确性验证 ----
    print("\n" + "-" * 50)
    print("正确性验证")
    print("-" * 50)

    # 原生 PyTorch 实现
    y_ref = torch.relu(x) @ w                    # 前向参考值

    # 自定义 fused 实现
    y_fused = FusedReLUMatMul.apply(x.clone(), w.clone())  # 前向测试值

    # 计算前向误差
    fwd_error = (y_fused - y_ref).abs().max().item()
    print(f"前向最大误差: {fwd_error:.2e}")
    assert fwd_error < 1e-5, "前向结果不匹配!"

    # 反向验证
    loss_ref = y_ref.sum()
    loss_ref.backward()
    grad_x_ref = x.grad.clone()     # 保存参考梯度
    grad_w_ref = w.grad.clone()

    # 重置梯度
    x.grad = None
    w.grad = None

    loss_fused = y_fused.sum()
    loss_fused.backward()
    grad_x_fused = x.grad.clone()
    grad_w_fused = w.grad.clone()

    # 计算反向误差
    grad_x_error = (grad_x_fused - grad_x_ref).abs().max().item()
    grad_w_error = (grad_w_fused - grad_w_ref).abs().max().item()
    print(f"grad_x 最大误差: {grad_x_error:.2e}")
    print(f"grad_w 最大误差: {grad_w_error:.2e}")
    assert grad_x_error < 1e-5, "grad_x 不匹配!"
    assert grad_w_error < 1e-5, "grad_w 不匹配!"
    print("正确性验证: 通过 ✓")

    # ---- 性能基准测试 ----
    print("\n" + "-" * 50)
    print("性能基准测试")
    print("-" * 50)

    def time_fn(fn, desc: str) -> float:
        """
        计时函数: 执行预热 + 基准测量

        参数:
            fn:   要执行的函数
            desc: 描述文字

        返回:
            平均执行时间 (毫秒)
        """
        # 预热: 确保 CUDA kernel 已加载
        # CUDA 是 lazy 初始化的, 第一次调用有额外的开销
        for _ in range(num_warmup):
            fn()

        # 同步: 确保预热完成
        if device.type == 'cuda':
            torch.cuda.synchronize()

        # 基准测量
        # 使用 CUDA event 精确测量 GPU 时间
        if device.type == 'cuda':
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)

            start.record()
            for _ in range(num_iters):
                fn()
            end.record()
            torch.cuda.synchronize()
            elapsed_ms = start.elapsed_time(end) / num_iters
        else:
            # CPU 回退: 使用 time.time()
            t0 = time.time()
            for _ in range(num_iters):
                fn()
            t1 = time.time()
            elapsed_ms = (t1 - t0) * 1000 / num_iters

        print(f"  {desc:30s}: {elapsed_ms:8.3f} ms")
        return elapsed_ms

    # ---- 测试 1: 仅前向 ----
    print("\n[前向性能]")

    # 原生前向: relu + matmul 分开执行
    time_fn(
        lambda: (torch.relu(x) @ w).sum().backward(),
        "原生 (relu + matmul)"
    )

    # 这只是一个演示, 真正的 fused 版本需要 CUDA kernel
    # 在 Python 层面, 我们的实现和原生几乎没有区别
    # 因为 torch.relu @ w 和调用 apply 的开销类似

    # ---- 测试 2: 端到端 (前向 + 反向) ----
    print("\n[端到端性能 (前向 + 反向)]")

    def native_fwd_bwd():
        """原生前向 + 反向"""
        y = torch.relu(x) @ w
        y.sum().backward()

    def fused_fwd_bwd():
        """自定义 fused 前向 + 反向"""
        y = FusedReLUMatMul.apply(x, w)
        y.sum().backward()

    t_native = time_fn(native_fwd_bwd, "原生 (relu + matmul)")
    t_fused = time_fn(fused_fwd_bwd, "自定义 FusedReLUMatMul")

    # 计算加速比
    if t_fused > 0:
        speedup = t_native / t_fused
        print(f"\n加速比: {speedup:.2f}x")

    print("\n" + "=" * 70)
    print("结论:")
    print("  在 Python 层面, 自定义 autograd.Function 的性能与原生实现接近")
    print("  真正的性能提升来自 CUDA kernel 级别的算子融合:")
    print("    - 减少 global memory 读写")
    print("    - 减少 kernel launch 次数")
    print("    - 利用共享内存/寄存器传递中间结果")
    print("  详见: docs/03_pytorch_extension.md 第1章 CUDA Extension 部分")
    print("=" * 70)


# =========================================================================
# 4. 进阶: 支持更多功能的 fused 算子
# =========================================================================

class FusedMatMulWithActivation(torch.autograd.Function):
    """
    更通用的融合模板: 支持多种激活函数

    这个类展示了如何设计灵活的 fused 算子:
    1. 支持任意 element-wise 激活函数
    2. 将激活函数作为参数传入
    3. 适用于 gelu, silu, relu, tanh 等

    实际应用:
        vLLM 中的 silu_and_mul 就是这种模式
        FFN 层: x → silu(x) * (x @ w1) → gate 机制
    """

    @staticmethod
    def forward(
        ctx: torch.autograd.function.FunctionCtx,
        x: torch.Tensor,
        w: torch.Tensor,
        activation_fn: callable = torch.relu,
        activation_grad_fn: callable = lambda x: (x > 0).float(),
    ) -> torch.Tensor:
        """
        前向: y = activation(x) @ w

        参数:
            ctx:               autograd context
            x:                 输入 [M, K]
            w:                 权重 [K, N]
            activation_fn:     激活函数, 可替换
            activation_grad_fn: 激活函数的梯度函数, 可替换
        """
        # 保存变量和激活函数的梯度
        ctx.save_for_backward(x, w)
        ctx.activation_grad_fn = activation_grad_fn

        # 应用激活函数后做矩阵乘法
        return torch.mm(activation_fn(x), w)

    @staticmethod
    def backward(
        ctx: torch.autograd.function.FunctionCtx,
        grad_y: torch.Tensor,
    ) -> Tuple[Optional[torch.Tensor], ...]:
        """反向: 通用梯度计算"""
        x, w = ctx.saved_tensors
        activation_grad_fn = ctx.activation_grad_fn

        # dL/dx = (dL/dy @ w^T) * activation'(x)
        grad_x = torch.mm(grad_y, w.t()) * activation_grad_fn(x)

        # dL/dw = activation(x)^T @ dL/dy
        grad_w = torch.mm(torch.relu(x).t(), grad_y)

        # None 对应 activation_fn 和 activation_grad_fn 参数
        # 这两个参数不需要梯度
        return grad_x, grad_w, None, None


# =========================================================================
# 5. 主程序入口
# =========================================================================

if __name__ == "__main__":
    """
    运行基准测试

    使用方法:
        python custom_relu_matmul.py

    输出:
        - 正确性验证结果
        - 前向/反向性能数据
        - 与原生 PyTorch 的对比
    """
    benchmark()
