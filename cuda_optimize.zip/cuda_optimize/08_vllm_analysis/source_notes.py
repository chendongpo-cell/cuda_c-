"""
vllm_source_notes.py — vLLM 源码关键路径笔记
不是可执行程序，而是阅读 vLLM 源码时的路径导航和关键数据结构总结

使用方式：在 IDE 中打开 vLLM 仓库，参照本文件的路径阅读源码
"""

# ================================================================
# vLLM V1 核心源码结构
# ================================================================

# 仓库：https://github.com/vllm-project/vllm
# V1 代码入口：vllm/v1/

"""
vllm/v1/
├── core/                    # 调度器 + Block Manager
│   ├── scheduler.py         # ★ 调度器（~350行）：schedule() 核心方法
│   ├── block_manager.py     # ★ Block 管理器
│   ├── block_pool.py        # Block 池化分配
│   ├── block_table.py       # 逻辑→物理 block 映射
│   └── config.py            # SchedulerConfig 等
│
├── engine/
│   ├── engine.py            # ★ LLMEngine：step() 推理循环
│   └── core.py              # EngineCore：model_runner + scheduler 整合
│
├── worker/
│   ├── gpu_model_runner.py  # ★ GPU 模型执行（prepare_input / execute_model）
│   ├── worker_base.py       # Worker 基类
│   └── ...
│
├── attention/
│   ├── __init__.py          # Attention backend 选择
│   ├── flash_attention.py   # FlashAttention backend
│   ├── flash_attention_varlen.py  # 变长序列 backend
│   └── paged_attention.py   # PagedAttention backend
│
├── sampling/
│   ├── sampler.py           # TopK/TopP/Temperature sampling
│   └── ...
│
└── entrypoints/
    └── openai/
        ├── api_server.py    # OpenAI API 服务入口
        └── chat.py          # Chat 请求处理
"""

# ================================================================
# 关键阅读路径
# ================================================================

# 路径 1：请求完整生命周期
"""
1. api_server.py → /v1/chat/completions endpoint
2. engine.py → add_request()
3. scheduler.py → add_request() / schedule()
4. engine.py → step() 循环
5. gpu_model_runner.py → execute_model()
6. attention backend → forward()
7. sampler.py → sample()
8. scheduler.py → update_from_output()
"""

# 路径 2：Block 生命周期
"""
1. config.py → _compute_num_blocks()
2. block_pool.py → BlockPool.alloc() / free()
3. block_table.py → BlockTable.add_block() / get_physical_block()
4. scheduler.py → schedule() → allocate_new_block()
"""

# 路径 3：调度过程（最重要的代码路径）
"""
scheduler.py:
  def schedule(self):
      1. _schedule_running()     ← 检查 running 请求的 block 需求
      2. _schedule_new()          ← 从 waiting 队列取新请求
      3. _schedule_preemption()   ← 如果显存不足，抢占
      4. → Build SchedulerOutput

  def _schedule_new(self):
      while self.waiting_queue:
          req = self.waiting_queue[0]
          if not self.block_manager.can_allocate(req):
              break
          self.block_manager.allocate(req)
          self.waiting_queue.popleft()
          self.running.append(req)
"""

# ================================================================
# 关键数据结构
# ================================================================

"""
# SchedulerOutput（scheduler.py）
@dataclass
class SchedulerOutput:
    scheduled_request_ids: List[str]
    input_tokens: List[List[int]]
    block_tables: List[List[int]]     # [num_reqs, max_blocks]
    seq_lens: List[int]
    is_prefill: List[bool]

# KVBlockPool（block_pool.py）
class KVBlockPool:
    def alloc(self) -> int:            # 分配一个物理 block
    def free(self, block_id: int):     # 释放
    def get_num_free_blocks(self) -> int:
    def get_total_blocks(self) -> int:

# BlockTable（block_table.py）
class BlockTable:
    def add_block(self, block_id: int):
    def get_cached_block(self, logical_idx: int) -> int:
    def evict(self):
    def free(self):
"""

# ================================================================
# vLLM V0 vs V1 核心差异
# ================================================================

"""
V0: vllm/core/scheduler.py（~2500 行）
  - 复杂的状态机：WAITING/RUNNING/SWAPPED/FINISHED
  - BlockSpaceManager 与 scheduler 耦合
  - 支持 CPU swap（现已证明不高效）

V1: vllm/v1/core/scheduler.py（~350 行）
  - 三状态简化：WAITING/RUNNING/FINISHED
  - BlockManager 独立
  - 不再支持 CPU swap（全部 recompute）
  - 代码更清晰、更可预测
"""

# ================================================================
# 用 curl 测试 vLLM 部署
# ================================================================

"""
# 启动服务
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen2.5-0.5B-Instruct \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.85 \
    --max-num-seqs 32 \
    --enable-chunked-prefill False

# 测试
curl http://localhost:8000/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "Qwen/Qwen2.5-0.5B-Instruct",
        "messages": [{"role": "user", "content": "Hello!"}],
        "max_tokens": 50
    }'

# 查看 metrics（vLLM 提供了 Prometheus metrics）
curl http://localhost:8000/metrics | grep vllm

# 查看运行状态
# 服务端日志会显示：
# Avg prompt throughput: ..., Avg generation throughput: ...
# CPU KV cache usage: ..., GPU KV cache usage: ...
# Running: ..., Waiting: ...
"""

# ================================================================
# 常见性能问题调试
# ================================================================

"""
问题 1：首 token 延迟高
  检查：prefill 阶段是否过慢
  方案：chunked prefill, 更大的 batch size

问题 2：吞吐上不去
  检查：GPU 利用率（nvidia-smi）
  方案：增大 max-num-seqs, 增大 max-model-len

问题 3：OOM（显存不足）
  检查：KV cache 占用 + 模型权重
  方案：降低 gpu-memory-utilization, 开启 prefix caching, 量化

问题 4：调度延迟高
  检查：scheduler.schedule() 耗时
  方案：V1 比 V0 快，升级 V1
"""
