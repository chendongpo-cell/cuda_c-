// ============================================================
// 文件名: string_ops.cpp
// 功能:   实现 StringUtils 命名空间中声明的字符串操作函数
// 说明:   每个函数的实现都包含详细的逐行中文注释
// ============================================================

#include "string_ops.h"  // 包含对应的头文件，确保声明与定义一致
#include <cctype>        // 包含 std::toupper 和 std::tolower 函数所需的头文件

// ============ StringUtils 命名空间 ===开始=== ============
namespace StringUtils {

    // ---------- toUpper 函数实现 ----------
    // 函数功能：将输入字符串中的所有小写字母转换为大写字母
    // 参数 s：常量引用，传入的原始字符串
    // 返回值：转换后的全大写字符串
    std::string toUpper(const std::string& s) {
        std::string result = s;  // 拷贝原字符串到新变量 result 中
        for (char& c : result) { // 使用范围 for 循环遍历 result 中的每一个字符
            c = std::toupper(static_cast<unsigned char>(c)); // 将当前字符转为大写并写回
        }
        return result;           // 返回转换完成后的新字符串
    }

    // ---------- toLower 函数实现 ----------
    // 函数功能：将输入字符串中的所有大写字母转换为小写字母
    // 参数 s：常量引用，传入的原始字符串
    // 返回值：转换后的全小写字符串
    std::string toLower(const std::string& s) {
        std::string result = s;  // 拷贝原字符串到新变量 result 中
        for (char& c : result) { // 使用范围 for 循环遍历 result 中的每一个字符
            c = std::tolower(static_cast<unsigned char>(c)); // 将当前字符转为小写并写回
        }
        return result;           // 返回转换完成后的新字符串
    }

    // ---------- reverse 函数实现 ----------
    // 函数功能：将输入字符串中的字符顺序完全反转
    // 参数 s：常量引用，传入的原始字符串
    // 返回值：字符顺序反转后的新字符串
    std::string reverse(const std::string& s) {
        std::string result = s;  // 拷贝原字符串到新变量 result 中
        int n = result.length(); // 获取字符串长度并保存到变量 n 中
        for (int i = 0; i < n / 2; i++) { // 只需要遍历前半部分字符
            // 交换对称位置上的两个字符：第 i 个与第 n-1-i 个
            char temp = result[i];              // 将左侧字符暂存到 temp
            result[i] = result[n - 1 - i];      // 将右侧字符赋值到左侧位置
            result[n - 1 - i] = temp;           // 将暂存的左侧字符赋值到右侧位置
        }
        return result;           // 返回反转完成后的新字符串
    }

    // ---------- length 函数实现 ----------
    // 函数功能：获取输入字符串的字符个数
    // 参数 s：常量引用，传入的字符串
    // 返回值：字符串的长度，类型为 size_t（无符号整型）
    size_t length(const std::string& s) {
        return s.length();       // 直接调用 std::string 的成员函数 length() 并返回结果
    }

}  // namespace StringUtils 结束
// ============ StringUtils 命名空间 ===结束=== ============
