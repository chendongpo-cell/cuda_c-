// ============================================================
// 文件名: math_ops.h
// 功能:   声明 Math 命名空间中的数学运算函数与常量
// 说明:   将数学运算封装在独立命名空间中，便于代码复用
// ============================================================

#ifndef MATH_OPS_H     // 头文件保护宏开始：如果未定义 MATH_OPS_H
#define MATH_OPS_H     // 定义 MATH_OPS_H，防止重复包含

// 定义 Math 命名空间，包含基础的数学运算函数与常量
namespace Math {

    // 圆周率常量，精确到 15 位小数
    const double PI = 3.141592653589793;

    // 加法函数声明：返回两个整数的和
    int add(int a, int b);

    // 减法函数声明：返回两个整数的差
    int subtract(int a, int b);

    // 乘法函数声明：返回两个整数的积
    int multiply(int a, int b);

    // 除法函数声明：返回两个整数的商
    // 注意：当 b 为 0 时会触发除零错误，调用者需自行确保除数不为零
    int divide(int a, int b);

}  // namespace Math 结束

#endif  // MATH_OPS_H 头文件保护宏结束
