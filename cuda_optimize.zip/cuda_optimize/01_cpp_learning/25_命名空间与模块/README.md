# 25 - 命名空间与模块 (Namespaces & Modules)

## 什么是命名空间？

命名空间（namespace）是 C++ 用于组织代码的一种机制，它**将全局作用域划分为独立的区域**，每个区域有自己的名称。

```cpp
namespace MyNamespace {
    int value;
    void func() { }
}
```

访问命名空间中的成员使用 `::`（作用域解析运算符）：

```cpp
MyNamespace::value = 42;
MyNamespace::func();
```

## 为什么需要命名空间？

### 1. 防止名称冲突 (Name Collision)

大型项目中，不同模块可能定义同名函数或变量。如果没有命名空间，会导致**重定义错误**。

```cpp
// 两个库都定义了 log() 函数
// LibA::log()  vs  LibB::log()   →  和谐共存
```

### 2. 逻辑分组

将相关的函数、类、变量放在同一个命名空间中，提高代码可读性和维护性。

## 定义命名空间

```cpp
namespace Math {
    const double PI = 3.14159;
    int add(int a, int b) { return a + b; }
}
```

## 嵌套命名空间 (Nested Namespaces)

命名空间可以嵌套，形成层次结构：

```cpp
namespace Company {
    namespace Department {
        namespace Project {
            void doWork();
        }
    }
}
```

C++17 支持更简洁的语法：

```cpp
namespace Company::Department::Project {
    void doWork();
}
```

访问：`Company::Department::Project::doWork()`

## using 指令 (using directive)

`using namespace` 将整个命名空间的名称引入当前作用域：

```cpp
using namespace std;     // 引入 std 所有名称
cout << "Hello";         // 可以直接写，不需要 std::
```

**警告**：在头文件中使用 `using namespace` 是不良实践，会将命名空间强加给所有包含该头文件的源文件。

## using 声明 (using declaration)

只引入特定的名称：

```cpp
using std::cout;         // 只引入 cout
using std::endl;         // 只引入 endl
cout << "Hello" << endl; // 合法，但其他 std 成员仍需 std::
```

比 `using namespace` 更受推荐。

## 匿名命名空间 (Anonymous Namespace)

没有名称的命名空间，其成员仅在当前编译单元（translation unit）中可见，相当于文件内部的 `static`：

```cpp
namespace {
    int internalVar = 0;
    void internalFunc() { }
}
```

等价于 C 语言中的 `static int internalVar;`，是 C++ 推荐的"文件内部链接"方式。

## 命名空间别名 (Namespace Alias)

为长命名空间取简短别名：

```cpp
namespace VeryLongNamespaceName {
    void func() {}
}
namespace VL = VeryLongNamespaceName;  // 别名
VL::func();                            // 简洁访问
```

## 模块 (Modules) — C++20 新特性 (简要介绍)

C++20 引入了模块（modules）作为头文件的现代替代方案：

```cpp
// math.cppm — 模块接口文件
export module math;
export int add(int a, int b) { return a + b; }

// main.cpp
import math;
int main() { return add(1, 2); }
```

**模块的优势**：
- 更快的编译速度
- 更好的隔离性（不泄露宏、私有实现）
- 更清晰的接口/实现分离

> 注意：本教程重点在命名空间，模块是 C++20 特性，需要编译器支持 `-std=c++20`。

## 最佳实践

| 做法 | 推荐？ |
|---|---|
| 源文件中使用 `using namespace std;` | 可以，但谨慎 |
| 头文件中使用 `using namespace std;` | **绝不** |
| 使用 `using std::cout;` | 推荐 |
| 始终使用 `std::` 前缀 | 最安全（大型项目推荐） |
| 使用命名空间别名 | 推荐（简化长命名空间） |
