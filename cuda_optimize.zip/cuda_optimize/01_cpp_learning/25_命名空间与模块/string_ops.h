// ============================================================
// 文件名: string_ops.h
// 功能:   声明 StringUtils 命名空间中的字符串操作函数
// 说明:   将字符串处理工具封装在独立命名空间中
// ============================================================

#ifndef STRING_OPS_H   // 头文件保护宏开始：如果未定义 STRING_OPS_H
#define STRING_OPS_H   // 定义 STRING_OPS_H，防止重复包含

#include <string>      // 包含 std::string 类型定义，用于函数参数与返回值

// 定义 StringUtils 命名空间，包含常用的字符串处理函数
namespace StringUtils {

    // 将字符串转换为全大写形式
    // 参数 s：输入的原字符串（常量引用，避免拷贝）
    // 返回值：转换后的全大写字符串
    std::string toUpper(const std::string& s);

    // 将字符串转换为全小写形式
    // 参数 s：输入的原字符串（常量引用，避免拷贝）
    // 返回值：转换后的全小写字符串
    std::string toLower(const std::string& s);

    // 反转字符串中的字符顺序
    // 参数 s：输入的原字符串（常量引用，避免拷贝）
    // 返回值：反转后的新字符串
    std::string reverse(const std::string& s);

    // 获取字符串的字符数量（长度）
    // 参数 s：输入的字符串（常量引用，避免拷贝）
    // 返回值：字符串的字符个数，size_t 类型
    size_t length(const std::string& s);

}  // namespace StringUtils 结束

#endif  // STRING_OPS_H 头文件保护宏结束
