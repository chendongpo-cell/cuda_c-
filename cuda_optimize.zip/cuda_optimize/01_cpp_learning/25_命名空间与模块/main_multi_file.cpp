// 多文件演示：不同命名空间拆分为独立.h/.cpp文件，展示工程级代码组织
// 文件名: main_multi_file.cpp
// 功能:   演示如何在一个项目中包含并使用多个命名空间头文件
// 演示内容:
//   1. 通过 using 声明引入 std::cout 和 std::endl
//   2. 使用命名空间别名简化长命名空间的调用
//   3. 分别调用 Math、StringUtils、Utils 三个命名空间中的函数
//   4. 展示同名函数在不同命名空间中不会冲突
// 编译命令: g++ -std=c++17 main_multi_file.cpp math_ops.cpp string_ops.cpp utils_ns.cpp -o main_multi_file

#include <iostream>      // 标准输入输出头文件，提供 cout、endl 等
#include "math_ops.h"    // 包含 Math 命名空间的头文件，获得数学运算函数声明
#include "string_ops.h"  // 包含 StringUtils 命名空间的头文件，获得字符串处理函数声明
#include "utils_ns.h"    // 包含 Utils 命名空间的头文件，获得工具函数声明

// ==== using 声明：精确引入需要的符号 ====
// 使用 using 声明将 std::cout 引入当前作用域
// 这样在代码中就可以直接写 cout 而不必写 std::cout
using std::cout;         // 声明使用 std::cout，后续可直接使用 cout
using std::endl;         // 声明使用 std::endl，后续可直接使用 endl
// 注意：我们故意没有 using namespace std; 这样可以演示 std::string 仍需加前缀

// ==== 主函数：程序入口 ====
int main() {
    // ========== 第一部分：使用 Utils 命名空间中的函数 ==========
    cout << endl;                              // 输出一个空行，让输出更清晰
    Utils::printHeader("多文件命名空间演示");  // 调用 Utils 命名空间中的 printHeader 打印带边框的标题
    Utils::printSeparator();                   // 调用 Utils 命名空间中的 printSeparator 打印分隔线
    Utils::logMessage("程序开始运行...");      // 调用 Utils 命名空间中的 logMessage 打印日志消息

    // ========== 第二部分：使用 Math 命名空间中的函数 ==========
    cout << endl;                              // 输出一个空行分隔不同演示章节
    Utils::printHeader("Math 命名空间演示");   // 打印 "Math 命名空间演示" 标题

    // 通过命名空间限定符 Math:: 来调用 Math 空间中的 add 函数
    int sum = Math::add(15, 25);               // 调用 Math::add，计算 15 + 25 的结果
    cout << "Math::add(15, 25) = " << sum << endl; // 输出加法结果

    // 通过命名空间限定符 Math:: 来调用 Math 空间中的 subtract 函数
    int diff = Math::subtract(100, 37);        // 调用 Math::subtract，计算 100 - 37 的结果
    cout << "Math::subtract(100, 37) = " << diff << endl; // 输出减法结果

    // 通过命名空间限定符 Math:: 来调用 Math 空间中的 multiply 函数
    int prod = Math::multiply(7, 8);           // 调用 Math::multiply，计算 7 * 8 的结果
    cout << "Math::multiply(7, 8) = " << prod << endl; // 输出乘法结果

    // 通过命名空间限定符 Math:: 来调用 Math 空间中的 divide 函数
    int quot = Math::divide(99, 4);            // 调用 Math::divide，计算 99 / 4 的结果
    cout << "Math::divide(99, 4) = " << quot << endl; // 输出除法结果（向零取整）

    // 访问 Math 命名空间中的常量 PI
    cout << "Math::PI = " << Math::PI << endl; // 输出圆周率常量的值

    // ========== 第三部分：使用 StringUtils 命名空间中的函数 ==========
    cout << endl;                              // 输出一个空行分隔不同演示章节
    Utils::printHeader("StringUtils 命名空间演示"); // 打印 "StringUtils 命名空间演示" 标题

    // 准备一个测试字符串用于演示各种字符串操作
    std::string testStr = "Hello, World!";     // 创建一个测试用的字符串，注意 std:: 前缀不可省略

    // 调用 StringUtils::toUpper 将字符串转换为全大写
    std::string upper = StringUtils::toUpper(testStr);  // 调用 toUpper 函数
    cout << "StringUtils::toUpper(\"" << testStr << "\") = " << upper << endl; // 输出大写结果

    // 调用 StringUtils::toLower 将字符串转换为全小写
    std::string lower = StringUtils::toLower(testStr);  // 调用 toLower 函数
    cout << "StringUtils::toLower(\"" << testStr << "\") = " << lower << endl; // 输出小写结果

    // 调用 StringUtils::reverse 将字符串反转
    std::string rev = StringUtils::reverse(testStr);    // 调用 reverse 函数
    cout << "StringUtils::reverse(\"" << testStr << "\") = " << rev << endl; // 输出反转结果

    // 调用 StringUtils::length 获取字符串长度
    size_t len = StringUtils::length(testStr);          // 调用 length 函数
    cout << "StringUtils::length(\"" << testStr << "\") = " << len << endl; // 输出长度结果

    // ========== 第四部分：同名函数不冲突演示 ==========
    cout << endl;                              // 输出一个空行分隔不同演示章节
    Utils::printHeader("同名函数不冲突演示");  // 打印标题

    // Math 命名空间和 StringUtils 命名空间中都有同名函数
    // 但由于它们分别位于不同的命名空间中，彼此完全独立，不会产生冲突
    // 下面的例子展示了即使函数名相同，通过命名空间限定可以区分调用

    // Math::add 执行整数加法
    int mathResult = Math::add(5, 3);          // 调用 Math::add，结果是 5 + 3 = 8
    cout << "Math::add(5, 3) = " << mathResult << endl; // 输出 Math 版本的 add 结果

    // 注意：StringUtils 中也有 add 吗？没有。这里展示的是 namespace 保护机制
    // 但为了演示，我们展示 length 在不同命名空间中的不同含义
    // Math 中有 PI 常量，StringUtils 中有 length 函数，互不干扰
    cout << "Math::PI 的值是: " << Math::PI << endl;    // Math 命名空间中的常量
    cout << "StringUtils::length(\"ABC\") = "
         << StringUtils::length("ABC") << endl;          // StringUtils 命名空间中的函数

    // ========== 第五部分：命名空间别名演示 ==========
    cout << endl;                              // 输出一个空行分隔不同演示章节
    Utils::printHeader("命名空间别名演示");    // 打印标题

    // 为 Math 命名空间创建别名 M
    // 当命名空间名称较长或在代码中频繁使用时，别名可以大幅简化代码
    namespace M = Math;                        // 将 Math 命名空间起别名为 M

    // 使用别名 M 来代替 Math:: 进行调用
    cout << "通过别名 M::add(10, 20) = " << M::add(10, 20) << endl; // 使用别名调用 Math::add

    // 为 StringUtils 命名空间创建别名 StrUtil
    // 别名可以在局部作用域中定义，也可以全局定义
    namespace StrUtil = StringUtils;           // 将 StringUtils 命名空间起别名为 StrUtil

    // 使用别名 StrUtil 来代替 StringUtils:: 进行调用
    cout << "通过别名 StrUtil::toUpper(\"test\") = "
         << StrUtil::toUpper("test") << endl;  // 使用别名调用 StringUtils::toUpper

    // 为 Utils 命名空间创建别名 U
    namespace U = Utils;                       // 将 Utils 命名空间起别名为 U

    // 使用别名 U 来代替 Utils:: 进行调用
    U::logMessage("通过别名 U::logMessage 输出日志"); // 使用别名调用 Utils::logMessage

    // ========== 第六部分：程序结束 ==========
    cout << endl;                              // 输出一个空行分隔不同演示章节
    Utils::printSeparator();                   // 打印分隔线表示程序即将结束
    Utils::logMessage("程序运行结束");          // 输出结束日志消息

    return 0;                                   // 程序正常退出，返回 0 表示成功
}
