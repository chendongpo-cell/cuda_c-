// ============================================================
// 文件名: utils_ns.h
// 功能:   声明 Utils 命名空间中的通用工具函数
// 说明:   将控制台工具函数封装在独立命名空间中
// ============================================================

#ifndef UTILS_NS_H     // 头文件保护宏开始：如果未定义 UTILS_NS_H
#define UTILS_NS_H     // 定义 UTILS_NS_H，防止重复包含

#include <string>      // 包含 std::string 类型定义，用于 logMessage 的参数

// 定义 Utils 命名空间，包含控制台输出相关的通用工具函数
namespace Utils {

    // 打印带装饰边框的标题行
    // 参数 title：要显示的标题文本
    // 功能：输出一个格式化的标题，包含上下分隔线
    void printHeader(const std::string& title);

    // 打印一条分隔线
    // 功能：输出由等号组成的视觉分隔线，用于美化控制台输出
    void printSeparator();

    // 打印带时间戳风格的日志消息
    // 参数 message：要输出的日志文本内容
    // 功能：模拟 [LOG] 前缀的日志输出格式
    void logMessage(const std::string& message);

}  // namespace Utils 结束

#endif  // UTILS_NS_H 头文件保护宏结束
