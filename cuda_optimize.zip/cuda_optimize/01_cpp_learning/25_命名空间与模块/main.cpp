/*
 * 文件名: main.cpp
 * 功能:   演示 C++ 命名空间的各种用法
 * 编译:   g++ -std=c++17 main.cpp -o main
 *
 * 包含:
 *   1. 定义多个命名空间 (Math, String, Utils)
 *   2. 同名函数在不同命名空间中不冲突
 *   3. 嵌套命名空间
 *   4. using 声明 (using std::cout)
 *   5. using 指令 (using namespace)
 *   6. 命名空间别名
 *   7. 匿名命名空间
 */

#include <iostream>   // 标准输入输出头文件
#include <string>     // 字符串头文件
#include <vector>     // 向量容器头文件

// ============ 第1部分: 定义多个独立命名空间 ============

// 定义 Math 命名空间，包含数学相关的函数
namespace Math {
    // 命名空间内的常量
    const double PI = 3.141592653589793;        // 圆周率常量

    // 命名空间内的函数: 加法
    int add(int a, int b) {
        return a + b;                           // 返回两数之和
    }

    // 命名空间内的函数: 减法
    int subtract(int a, int b) {
        return a - b;                           // 返回两数之差
    }

    // 与 String 命名空间同名的函数，但不冲突，因为在不同命名空间中
    int getLength() {
        return 10;                              // 返回一个固定数字
    }
}                                               // namespace Math 结束，无需分号

// 定义 String 命名空间，包含字符串相关的函数
namespace String {
    // 命名空间内的函数: 获取字符串长度
    int getLength(const std::string& s) {
        return s.length();                      // 调用 string::length() 返回实际长度
    }

    // 命名空间内的函数: 将字符串转为大写
    std::string toUpper(const std::string& s) {
        std::string result = s;                 // 复制原字符串
        for (char& c : result) {                // 遍历每个字符
            if (c >= 'a' && c <= 'z') {         // 如果是小写字母
                c = c - 'a' + 'A';              // 转为大写字母 (ASCII 码运算)
            }
        }
        return result;                          // 返回转换后的字符串
    }

    // 与 Math 命名空间同名的函数，但行为不同
    int add(int a, int b) {
        return a + b + 100;                     // 加 100，演示同名不同行为
    }
}                                               // namespace String 结束

// 定义 Utils 命名空间，包含工具函数
namespace Utils {
    // 工具函数: 打印数组内容
    void printArray(const int arr[], int size) {
        std::cout << "[ ";                      // 打印左括号
        for (int i = 0; i < size; i++) {        // 遍历数组
            std::cout << arr[i];                // 打印每个元素
            if (i < size - 1) {                 // 如果不是最后一个元素
                std::cout << ", ";              // 打印逗号分隔
            }
        }
        std::cout << " ]" << std::endl;         // 打印右括号并换行
    }
}

// ============ 第2部分: 嵌套命名空间 ============

// 演示嵌套命名空间 — C++17 简洁语法
namespace Company::Department::Project {
    // 这个函数位于 Company::Department::Project 命名空间中
    void doWork() {
        std::cout << "正在 Company::Department::Project 中工作..." << std::endl;
    }
}

// 传统方式的嵌套命名空间 (兼容 C++17 之前的编译器)
namespace Company {
    namespace Department {
        void meeting() {
            std::cout << "正在 Company::Department 开会..." << std::endl;
        }
    }
}

// ============ 第3部分: 匿名命名空间 ============

// 匿名命名空间: 其中的名称只在当前文件可见 (文件内部链接)
namespace {
    // 这个函数只能在本文件中使用，其他 .cpp 文件无法链接到它
    void internalHelper() {
        std::cout << "(这是一个内部辅助函数，仅当前文件可见)" << std::endl;
    }

    // 这个变量也只能在本文件中使用
    int internalCounter = 0;
}

// ============ 第4部分: 主函数 ============

// 使用 using 声明: 只引入 std::cout 和 std::endl
// 这样就不用每次都写 std::cout 和 std::endl，但其他 std 成员仍需 std::
using std::cout;       // 声明使用 std::cout
using std::endl;       // 声明使用 std::endl

// 注意: 这里故意没有 using namespace std;
// 这样能演示 std::string 等仍需加 std:: 前缀

int main() {
    // ============ 演示1: 使用命名空间限定 :: 访问成员 ============
    cout << "=== 1. 通过 :: 访问命名空间成员 ===" << endl;

    // 通过 Math:: 访问 Math 命名空间中的函数
    int sum = Math::add(10, 20);               // 调用 Math 命名空间的 add
    cout << "Math::add(10, 20) = " << sum << endl;

    // 通过 String:: 访问 String 命名空间中的函数
    int len = String::getLength("Hello");       // 调用 String 命名空间的 getLength
    cout << "String::getLength(\"Hello\") = " << len << endl;

    // 调用 Utils 命名空间的工具函数
    int arr[] = {1, 2, 3, 4, 5};               // 测试数组
    cout << "Utils::printArray: ";
    Utils::printArray(arr, 5);                  // 调用 Utils 的打印函数

    cout << endl;

    // ============ 演示2: 同名函数不冲突 ============
    cout << "=== 2. 同名函数在不同命名空间中不冲突 ===" << endl;

    int result1 = Math::add(5, 3);             // Math::add 直接相加
    int result2 = String::add(5, 3);           // String::add 加 100

    cout << "Math::add(5, 3)   = " << result1 << endl;    // 输出 8
    cout << "String::add(5, 3) = " << result2 << endl;    // 输出 108

    int mathLen = Math::getLength();           // Math::getLength 返回固定值 10
    int strLen  = String::getLength("ABC");    // String::getLength 返回实际长度 3
    cout << "Math::getLength()          = " << mathLen << endl;
    cout << "String::getLength(\"ABC\") = " << strLen << endl;

    cout << endl;

    // ============ 演示3: 嵌套命名空间 ============
    cout << "=== 3. 嵌套命名空间 ===" << endl;

    // 通过完整的嵌套路径访问命名空间中的函数
    Company::Department::Project::doWork();     // 访问三层嵌套的函数
    Company::Department::meeting();             // 访问两层嵌套的函数

    cout << endl;

    // ============ 演示4: using 声明 ============
    cout << "=== 4. using 声明 (using std::cout) ===" << endl;

    // 我们在文件开头使用了 using std::cout 和 using std::endl
    // 所以可以直接使用 cout 和 endl，不需要写 std::
    // 但 std::string 没有 using 声明，所以仍需 std::
    std::string msg = "Hello, Namespace!";      // std::string 需要加 std::
    cout << "消息: " << msg << endl;            // cout 和 endl 可直接用

    cout << endl;

    // ============ 演示5: using 指令 (using namespace) ============
    cout << "=== 5. using 指令 (using namespace) ===" << endl;

    {
        // 在局部作用域中使用 using 指令
        // 将 Math 命名空间中的所有名称引入当前代码块
        using namespace Math;

        // 现在可以不加 Math:: 直接使用 Math 中的名称
        cout << "PI = " << PI << endl;          // 直接访问 Math::PI
        cout << "add(100, 200) = " << add(100, 200) << endl;  // 直接访问 Math::add

        // 注意: 如果在同一作用域同时 using namespace Math 和 String
        // 调用 add 会产生二义性错误！这里只有 Math，所以安全
    }
    // 离开代码块后，using namespace Math 的效果消失

    cout << endl;

    // ============ 演示6: 命名空间别名 ============
    cout << "=== 6. 命名空间别名 ===" << endl;

    // 为长命名空间创建短别名
    // Company::Department::Project 太长了
    namespace CDP = Company::Department::Project;  // 别名 CDP

    // 使用别名访问，代码更简洁
    CDP::doWork();                               // 等价于上面完整的调用

    // 另一个别名示例
    namespace Str = String;                      // 为 String 取别名 Str
    cout << "Str::toUpper(\"hello\") = "
         << Str::toUpper("hello") << endl;       // 通过别名调用

    cout << endl;

    // ============ 演示7: 匿名命名空间 ============
    cout << "=== 7. 匿名命名空间 ===" << endl;

    // 调用匿名命名空间中的函数和变量
    internalHelper();                            // 调用匿名命名空间中的函数
    internalCounter++;                           // 修改匿名命名空间中的变量
    internalCounter++;
    cout << "internalCounter = " << internalCounter << endl;

    cout << endl;

    // ============ 演示8: 避免冲突的最佳实践 ============
    cout << "=== 8. 最佳实践: 显式限定 ===" << endl;

    // 大型项目中推荐显式使用命名空间前缀，避免二义性
    // 这样代码意图清晰，不会因为 using 导致意外重名
    cout << "Math::add(1,2) = "   << Math::add(1, 2)   << endl;
    cout << "String::add(1,2) = " << String::add(1, 2) << endl;

    // 也可以配合 using 声明精确控制
    using Math::PI;                              // 只引入 PI，不引入其他
    cout << "PI (via using Math::PI) = " << PI << endl;

    return 0;                                    // 程序正常退出
}
