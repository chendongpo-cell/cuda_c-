// ============================================================
// 文件名: main.cpp
// 说明: 变量与数据类型 —— 声明、初始化、sizeof、类型转换
// 演示内容: int, float, double, char, bool, const, 类型转换
// 编译命令: g++ main.cpp -o main -std=c++17
// ============================================================

// 包含输入输出流头文件，用于 cout 输出
#include <iostream>

// 使用标准命名空间，方便直接使用 cout、endl 等
using namespace std;

// main 函数 —— 程序从这里开始执行
int main() {
    // ==========================================================
    // 1. 整型 (int) —— 存储整数，不包含小数部分
    // ==========================================================
    // 声明并初始化一个整型变量 age，赋值为 25
    int age = 25;
    // 使用 cout 输出 age 的值，endl 换行
    cout << "年龄: " << age << endl;

    // 声明一个整型变量 score，使用列表初始化（C++11 推荐方式）
    int score{90};
    // 输出 score 的值
    cout << "分数: " << score << endl;

    // ==========================================================
    // 2. 单精度浮点型 (float) —— 存储小数，精度较低（约7位）
    // ==========================================================
    // 声明并初始化一个 float 变量
    // 注意: 小数默认是 double 类型，加 f 后缀表示 float
    float temperature = 36.5f;
    // 输出温度值
    cout << "体温: " << temperature << "°C" << endl;

    // ==========================================================
    // 3. 双精度浮点型 (double) —— 存储小数，精度高（约15位）
    // ==========================================================
    // 声明并初始化一个 double 变量（默认小数类型）
    double pi = 3.14159265358979;
    // 输出圆周率，可以看到 double 的高精度
    cout << "圆周率: " << pi << endl;

    // 声明并初始化另一个 double 变量，表示价格
    double price = 99.99;
    // 输出价格
    cout << "价格: ￥" << price << endl;

    // ==========================================================
    // 4. 字符型 (char) —— 存储单个字符
    // ==========================================================
    // 声明并初始化一个 char 变量，存储字符 'A'
    // 注意: char 使用单引号，而不是双引号
    char grade = 'A';
    // 输出字符变量的值
    cout << "成绩等级: " << grade << endl;

    // char 本质上存储的是 ASCII 码（整数）
    // 声明并初始化一个 char 变量，直接使用 ASCII 码值（65 对应 'A'）
    char asciiChar = 65;
    // 输出 ASCII 码对应的字符，会显示 'A'
    cout << "ASCII 码 65 对应的字符: " << asciiChar << endl;

    // ==========================================================
    // 5. 布尔型 (bool) —— 存储 true（真）或 false（假）
    // ==========================================================
    // 声明并初始化一个 bool 变量，赋值为 true
    bool isStudent = true;
    // 输出布尔值，true 会显示为 1，false 会显示为 0
    cout << "是否学生: " << isStudent << endl;

    // 声明并初始化一个 bool 变量，赋值为 false
    bool hasGraduated = false;
    // 输出布尔值，显示为 0
    cout << "是否毕业: " << hasGraduated << endl;

    // 使用 boolalpha 让布尔值显示为 true/false 而不是 1/0
    cout << "是否学生(boolalpha): " << boolalpha << isStudent << endl;
    cout << "是否毕业(boolalpha): " << hasGraduated << endl;

    // ==========================================================
    // 6. 常量 (const) —— 值不能被修改的变量
    // ==========================================================
    // 声明一个 double 类型的常量 PI
    // const 表示这个变量的值一旦设定就不能再改变
    const double PI = 3.14159;
    // 输出常量的值
    cout << "常量 PI: " << PI << endl;

    // 下面这行代码如果取消注释会报错，因为不能修改 const 变量
    // PI = 3.14;  // 错误！不能修改常量

    // ==========================================================
    // 7. sizeof 运算符 —— 获取变量或类型占用的字节数
    // ==========================================================
    // sizeof 是运算符，不是函数，返回 size_t 类型的值
    // 用法: sizeof(类型) 或 sizeof 变量
    cout << "----------------------------------------" << endl;
    cout << "各数据类型占用的字节数:" << endl;
    cout << "sizeof(int):     " << sizeof(int) << " 字节" << endl;
    cout << "sizeof(float):   " << sizeof(float) << " 字节" << endl;
    cout << "sizeof(double):  " << sizeof(double) << " 字节" << endl;
    cout << "sizeof(char):    " << sizeof(char) << " 字节" << endl;
    cout << "sizeof(bool):    " << sizeof(bool) << " 字节" << endl;

    // sizeof 也可以直接作用于变量，效果相同
    cout << "sizeof(age):     " << sizeof(age) << " 字节（变量 age）" << endl;

    // ==========================================================
    // 8. 隐式类型转换（自动转换）
    // ==========================================================
    cout << "----------------------------------------" << endl;
    cout << "隐式类型转换:" << endl;

    // int 自动转换为 double（安全转换，不会丢失数据）
    int intVal = 42;
    // 将 int 赋值给 double，编译器自动完成转换
    double doubleVal = intVal;
    // 输出转换结果，42 变成了 42.0
    cout << "int " << intVal << " → double: " << doubleVal << endl;

    // char 自动转换为 int（char 本质是 ASCII 码）
    char charVal = 'B';
    // 将 char 赋值给 int，得到字符 'B' 的 ASCII 码值
    int asciiVal = charVal;
    // 输出转换结果，'B' 的 ASCII 码是 66
    cout << "char '" << charVal << "' → int: " << asciiVal << endl;

    // bool 自动转换为 int（true=1, false=0）
    bool boolVal = true;
    // 将 bool 赋值给 int
    int boolToInt = boolVal;
    // 输出转换结果，true 转换为 1
    cout << "bool " << boolVal << " → int: " << boolToInt << endl;

    // 浮点数转整数时的截断（小数部分被丢弃）
    double largeDouble = 99.99;
    // double 转 int，小数部分被截断，结果为 99（不是四舍五入）
    int truncated = largeDouble;
    // 输出结果，显示 99 而不是 100
    cout << "double " << largeDouble << " → int: " << truncated
         << "（小数部分被截断！）" << endl;

    // ==========================================================
    // 9. 显式类型转换（强制转换）
    // ==========================================================
    cout << "----------------------------------------" << endl;
    cout << "显式类型转换:" << endl;

    double a = 10.7;
    double b = 3.2;

    // C 风格强制转换: (目标类型)表达式
    // 将 double 强制转为 int，小数部分被截断
    int cStyle = (int)a / (int)b;
    // 输出: 10 / 3 = 3（两个 int 相除，结果为 int）
    cout << "C 风格 (int)a / (int)b = " << cStyle << endl;

    // 函数风格强制转换: 目标类型(表达式)
    int funcStyle = int(a) / int(b);
    // 输出和上面一样的结果
    cout << "函数风格 int(a) / int(b) = " << funcStyle << endl;

    // C++ 风格转换: static_cast<目标类型>(表达式)
    // static_cast 在编译时进行类型检查，更安全
    int cppStyle = static_cast<int>(a) / static_cast<int>(b);
    // 输出同样的结果
    cout << "C++ static_cast<int>(a) / static_cast<int>(b) = "
         << cppStyle << endl;

    // 演示为什么需要类型转换: 整数除法的问题
    int x = 5;
    int y = 2;
    // 两个 int 相除，结果还是 int，5/2=2（小数部分被丢弃）
    int result1 = x / y;
    cout << "整数除法: " << x << " / " << y << " = " << result1 << endl;

    // 解决方法: 将其中一个转换为 double，除法结果就是 double
    double result2 = static_cast<double>(x) / y;
    // 输出正确结果: 5.0 / 2 = 2.5
    cout << "浮点除法: " << x << " / " << y << " = " << result2 << endl;

    // ==========================================================
    // 10. 综合示例 —— 学生信息
    // ==========================================================
    cout << "----------------------------------------" << endl;
    cout << "综合示例 —— 学生信息:" << endl;

    // 定义多个变量来存储一个学生的各项信息
    string name = "张三";                    // 姓名（string 类型，需要 #include <string>）
    int studentAge = 20;                     // 年龄（整型）
    double studentScore = 92.5;              // 成绩（双精度浮点）
    char studentGrade = 'A';                 // 等级（字符型）
    bool isPassing = true;                   // 是否及格（布尔型）

    // 综合输出所有信息
    cout << "姓名: " << name << endl;
    cout << "年龄: " << studentAge << endl;
    cout << "成绩: " << studentScore << endl;
    cout << "等级: " << studentGrade << endl;
    cout << "是否及格: " << isPassing << endl;

    // 程序结束，返回 0 表示成功
    return 0;
}
