# 21 - STL迭代器与算法 (STL Iterators & Algorithms)

## 什么是迭代器？

**迭代器（Iterator）** 是一种抽象的设计模式，它提供了一种统一的方式来访问容器中的元素，而不需要暴露容器内部的实现细节。

在 C++ STL 中，迭代器是连接**容器（Containers）** 和**算法（Algorithms）** 的**桥梁**：
- 容器负责存储数据
- 算法负责处理数据
- 迭代器负责在两者之间传递数据

**为什么需要迭代器？**

如果不使用迭代器，每种容器都需要自己实现一套遍历和操作的接口：
- `vector` 用 `[]` + `size()`
- `list` 需要专门的方法
- `map` 又完全不同

迭代器统一了这些操作，使得**同一个算法可以在不同的容器上工作**：

```cpp
std::vector<int> v = {3, 1, 4, 1, 5};
std::list<int>   l = {3, 1, 4, 1, 5};

// 使用同样的 std::sort 处理 vector
std::sort(v.begin(), v.end());

// list 不支持随机访问，所以不能用 std::sort
// 但可以用 std::find 在任意容器中查找
auto it1 = std::find(v.begin(), v.end(), 4);
auto it2 = std::find(l.begin(), l.end(), 4);
```

## 迭代器分类

迭代器根据功能由弱到强分为 5 类：

### 1. 输入迭代器 (Input Iterator)
- 只能**读取**元素（一次读取，单向移动）
- 支持 `++iter`、`*iter`（读取）、`==`/`!=`
- 常用于从输入流读取数据

### 2. 输出迭代器 (Output Iterator)
- 只能**写入**元素（一次写入，单向移动）
- 支持 `++iter`、`*iter = value`
- 常用于将数据写入输出流

### 3. 前向迭代器 (Forward Iterator)
- 兼具输入和输出迭代器的功能
- 可以多次遍历同一个序列
- `forward_list`、`unordered_set` 的迭代器属于这一类

### 4. 双向迭代器 (Bidirectional Iterator)
- 在前向迭代器基础上增加了**反向移动**能力
- 支持 `--iter`
- `list`、`set`、`map` 的迭代器属于这一类

### 5. 随机访问迭代器 (Random Access Iterator)
- 功能最强的迭代器
- 支持所有迭代器操作 + **随机访问**
- 支持 `iter + n`、`iter - n`、`iter[n]`、`iter1 - iter2`
- 支持所有比较操作：`<`、`>`、`<=`、`>=`
- `vector`、`deque`、`array` 的迭代器属于这一类

## begin() / end()

每个 STL 容器都提供 `begin()` 和 `end()` 成员函数：
- `begin()`：返回指向**第一个元素**的迭代器
- `end()`：返回指向**最后一个元素之后**的迭代器（**哨兵，不指向有效元素**）

```
容器:  [10] [20] [30] [40] [50]
       ^                        ^
       |                        |
    begin()                   end()
```

遍历的一般模式：
```cpp
for (auto it = container.begin(); it != container.end(); ++it) {
    // 使用 *it 访问当前元素
}
```

## const_iterator

当你不希望通过迭代器修改元素时，使用 const_iterator：
- `cbegin()` / `cend()`：C++11 引入，返回 const_iterator
- 不能通过 const_iterator 修改元素值

## 反向迭代器 (Reverse Iterator)

反向遍历容器：
- `rbegin()`：返回指向**最后一个元素**的反向迭代器
- `rend()`：返回指向**第一个元素之前**的反向迭代器
- 使用 `++` 运算符会向**前**移动

## STL 算法概览

STL 提供了大量通用算法，涵盖排序、查找、计数、变换等操作。

### 非修改序列算法 (Non-modifying)
| 算法 | 功能 |
|------|------|
| `find` | 查找指定值，返回迭代器 |
| `count` | 统计指定值的出现次数 |
| `for_each` | 对每个元素执行操作 |
| `all_of / any_of / none_of` | 判断是否全部/任一/无元素满足条件 |

### 修改序列算法 (Modifying)
| 算法 | 功能 |
|------|------|
| `copy` | 复制元素到另一个容器 |
| `fill` | 用指定值填充范围 |
| `transform` | 对每个元素进行变换 |
| `replace` | 替换指定值 |

### 排序及相关操作 (Sorting)
| 算法 | 功能 |
|------|------|
| `sort` | 排序（随机访问迭代器） |
| `stable_sort` | 稳定排序 |
| `partial_sort` | 部分排序 |
| `nth_element` | 将第 n 个元素放到正确位置 |
| `binary_search` | 二分查找（要求已排序） |
| `lower_bound / upper_bound` | 二分查找边界 |

### 数值算法 (Numeric)
| 算法 | 功能 |
|------|------|
| `accumulate` | 累加/累积 |
| `inner_product` | 内积 |
| `partial_sum` | 部分和 |
| `adjacent_difference` | 相邻差 |

## 迭代器失效 (Iterator Invalidation)

当容器被修改时，已有的迭代器可能会失效：
- `vector`：插入/删除可能导致重新分配，**所有迭代器失效**
- `list`：插入/删除不会导致其他迭代器失效（被删除元素的迭代器除外）
- `map/set`：插入/删除不会导致其他迭代器失效
