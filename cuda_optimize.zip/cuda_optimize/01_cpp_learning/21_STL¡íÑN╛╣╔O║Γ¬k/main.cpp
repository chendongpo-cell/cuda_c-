#include <iostream>     // 包含输入输出流头文件，用于 std::cout
#include <vector>       // 包含 vector 容器头文件
#include <list>         // 包含 list 容器头文件
#include <algorithm>    // 包含 STL 算法头文件，如 sort, find, count, for_each 等
#include <numeric>      // 包含数值算法头文件，如 accumulate
#include <iterator>     // 包含迭代器相关工具，如 std::ostream_iterator
#include <string>       // 包含字符串头文件，用于 std::string

// 辅助函数：用于 std::for_each 中输出元素
// 这是一个普通函数，接受一个 const int& 参数
void printElement(const int& value) {
    // 输出值和一个空格
    std::cout << value << " ";
}

// 辅助函数：判断一个数是否为偶数
bool isEven(int value) {
    // 如果 value 除以 2 的余数为 0，则是偶数
    return value % 2 == 0;
}

int main() {
    // ========== 准备数据 ==========

    // 创建一个包含 10 个整数的 vector
    // 这是我们的主要测试数据
    std::vector<int> numbers = {5, 2, 8, 1, 9, 3, 7, 4, 6, 0};

    // 输出原始数据
    std::cout << "原始数据: ";
    for (const auto& val : numbers) {
        // 使用普通范围 for 循环输出
        std::cout << val << " ";
    }
    std::cout << std::endl;
    std::cout << std::endl;

    // ========== 1. 迭代器基础演示 ==========

    // 输出标题
    std::cout << "===== 1. 迭代器基础演示 =====" << std::endl;

    // 1.1 使用 begin() 和 end() 遍历容器
    // begin() 返回指向第一个元素的迭代器
    // end() 返回指向最后一个元素之后位置的迭代器（哨兵）
    std::cout << "使用 begin/end 正向遍历: ";
    for (auto it = numbers.begin(); it != numbers.end(); ++it) {
        // *it 解引用迭代器，获取指向的元素值
        std::cout << *it << " ";
    }
    std::cout << std::endl;

    // 1.2 使用 const_iterator（cbegin/cend）
    // const_iterator 不允许通过它修改元素值，只读访问
    // cbegin() 和 cend() 是 C++11 引入的
    std::cout << "使用 cbegin/cend（只读）: ";
    for (auto it = numbers.cbegin(); it != numbers.cend(); ++it) {
        // *it 返回 const 引用，不能修改
        std::cout << *it << " ";
        // *it = 100;  // 这行会编译错误！const_iterator 不能修改元素
    }
    std::cout << std::endl;

    // 1.3 使用反向迭代器（rbegin/rend）
    // rbegin() 返回指向最后一个元素的反向迭代器
    // rend() 返回指向第一个元素之前位置的反向迭代器
    // 使用 ++ 会向容器的开头方向移动
    std::cout << "使用 rbegin/rend 反向遍历: ";
    for (auto it = numbers.rbegin(); it != numbers.rend(); ++it) {
        // 从最后一个元素到第一个元素遍历
        std::cout << *it << " ";
    }
    std::cout << std::endl;

    // 1.4 使用 list 的迭代器（双向迭代器）
    // list 的迭代器是双向迭代器，不支持 + n 运算
    std::list<int> myList = {100, 200, 300, 400, 500};
    std::cout << "list 双向迭代器遍历: ";
    for (auto it = myList.begin(); it != myList.end(); ++it) {
        // list 的迭代器支持 ++ 和 -- 操作
        std::cout << *it << " ";
    }
    std::cout << std::endl;

    // 反向遍历 list
    std::cout << "list 反向遍历: ";
    for (auto it = myList.rbegin(); it != myList.rend(); ++it) {
        std::cout << *it << " ";
    }
    std::cout << std::endl;

    std::cout << std::endl;

    // ========== 2. STL 算法演示 ==========

    // 先复制一份原始数据用于算法演示
    // 因为有些算法（如 sort）会修改容器内容
    std::vector<int> data = numbers;

    // ===== 2.1 std::sort 排序 =====

    // 输出标题
    std::cout << "===== 2.1 std::sort =====" << std::endl;

    // sort 对范围内的元素进行升序排序
    // 需要随机访问迭代器，因此不能用于 list
    // 时间复杂度 O(n log n)
    std::sort(data.begin(), data.end());
    // 输出排序后的结果
    std::cout << "升序排序: ";
    for (const auto& val : data) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 使用 sort 的第三个参数：自定义比较函数（降序）
    // std::greater<int>() 是 STL 提供的比较函数对象
    std::sort(data.begin(), data.end(), std::greater<int>());
    std::cout << "降序排序: ";
    for (const auto& val : data) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 恢复升序，为后面的算法做准备
    std::sort(data.begin(), data.end());

    std::cout << std::endl;

    // ===== 2.2 std::find 查找 =====

    // 输出标题
    std::cout << "===== 2.2 std::find =====" << std::endl;

    // find 在范围内查找第一个等于指定值的元素
    // 返回指向该元素的迭代器
    // 如果没找到，返回 end()
    auto findResult = std::find(data.begin(), data.end(), 5);
    // 检查是否找到
    if (findResult != data.end()) {
        // findResult 指向的元素值为 5
        // std::distance 计算两个迭代器之间的距离（即索引位置）
        size_t index = std::distance(data.begin(), findResult);
        std::cout << "找到 5，位于索引: " << index << std::endl;
    } else {
        std::cout << "未找到 5" << std::endl;
    }

    // 查找不存在的值
    auto findNotFound = std::find(data.begin(), data.end(), 99);
    if (findNotFound == data.end()) {
        // find 返回 end() 表示没有找到
        std::cout << "99 不在 data 中" << std::endl;
    }

    std::cout << std::endl;

    // ===== 2.3 std::count 计数 =====

    // 输出标题
    std::cout << "===== 2.3 std::count =====" << std::endl;

    // count 统计范围内等于指定值的元素个数
    // 遍历整个范围，时间复杂度 O(n)
    int countOfThree = static_cast<int>(std::count(data.begin(), data.end(), 3));
    std::cout << "3 出现的次数: " << countOfThree << std::endl;

    // 在原始未排序的 numbers 中计数
    int countOfOne = static_cast<int>(std::count(numbers.begin(), numbers.end(), 1));
    std::cout << "1 在原始数据中出现的次数: " << countOfOne << std::endl;

    // count_if 使用自定义条件计数
    // 统计偶数的个数，isEven 是我们定义的判断函数
    int evenCount = static_cast<int>(
        std::count_if(data.begin(), data.end(), isEven)
    );
    std::cout << "偶数个数: " << evenCount << std::endl;

    std::cout << std::endl;

    // ===== 2.4 std::for_each 遍历执行 =====

    // 输出标题
    std::cout << "===== 2.4 std::for_each =====" << std::endl;

    // for_each 对范围内的每个元素执行指定的函数
    // 第三个参数可以传函数指针、函数对象或 lambda 表达式
    std::cout << "std::for_each 输出: ";
    std::for_each(data.begin(), data.end(), printElement);
    std::cout << std::endl;

    // 使用 lambda 表达式（C++11）的 for_each
    // lambda 是匿名的函数对象，语法：[捕获列表](参数列表){函数体}
    std::cout << "lambda + for_each 输出: ";
    std::for_each(data.begin(), data.end(),
        // 这是一个 lambda 表达式
        [](const int& val) {
            // 输出值乘以 2 的结果
            std::cout << val * 2 << " ";
        }
    );
    std::cout << std::endl;

    // for_each 也可以修改元素（通过引用）
    std::cout << "每个元素加 10 后: ";
    std::for_each(data.begin(), data.end(),
        // 使用引用捕获，可以修改原始数据
        [](int& val) {
            // 将每个元素增加 10
            val += 10;
        }
    );
    // 输出修改后的结果
    std::for_each(data.begin(), data.end(), printElement);
    std::cout << std::endl;
    // 恢复数据
    std::for_each(data.begin(), data.end(), [](int& val) { val -= 10; });

    std::cout << std::endl;

    // ===== 2.5 std::accumulate 累加 =====

    // 输出标题
    std::cout << "===== 2.5 std::accumulate =====" << std::endl;

    // accumulate 对范围内的元素进行累加（或累积操作）
    // 第一个参数：起始迭代器
    // 第二个参数：结束迭代器
    // 第三个参数：初始值
    // 返回所有元素加初始值的和
    int sum = std::accumulate(data.begin(), data.end(), 0);
    std::cout << "所有元素的和: " << sum << std::endl;

    // 自定义累积操作：计算乘积
    // 使用 lambda 作为第四个参数指定操作
    int product = std::accumulate(data.begin(), data.end(), 1,
        // lambda 实现乘法累积
        [](int total, int current) {
            // total 是当前的累积结果，current 是当前元素
            return total * current;
        }
    );
    std::cout << "所有元素的乘积: " << product << std::endl;

    // 注意：如果从 0 开始累积求积，结果会始终为 0
    // 所以初始值给了 1

    std::cout << std::endl;

    // ===== 2.6 std::copy 复制 =====

    // 输出标题
    std::cout << "===== 2.6 std::copy =====" << std::endl;

    // 创建一个空的目标 vector
    std::vector<int> destination;

    // 使用 std::copy 将 data 的所有元素复制到 destination
    // 但 destination 目前为空，直接复制会出问题
    // 可以使用 std::back_inserter 自动在尾部插入
    std::copy(data.begin(), data.end(), std::back_inserter(destination));
    // std::back_inserter 返回一个特殊的输出迭代器
    // 每次赋值时自动调用 push_back 插入元素

    // 输出复制后的目标 vector
    std::cout << "复制后的目标容器: ";
    std::for_each(destination.begin(), destination.end(), printElement);
    std::cout << std::endl;

    // 使用 std::copy 和 ostream_iterator 直接输出到控制台
    // std::ostream_iterator 是一个输出迭代器，写入到流中
    std::cout << "使用 ostream_iterator 输出: ";
    std::copy(data.begin(), data.end(),
              std::ostream_iterator<int>(std::cout, " "));
    std::cout << std::endl;

    // 使用 copy_if 带条件复制
    // 只复制偶数到另一个容器
    std::vector<int> evens;
    std::copy_if(data.begin(), data.end(),
                 std::back_inserter(evens),
                 isEven);  // 条件：是偶数
    std::cout << "只复制偶数: ";
    std::copy(evens.begin(), evens.end(),
              std::ostream_iterator<int>(std::cout, " "));
    std::cout << std::endl;

    std::cout << std::endl;

    // ===== 2.7 std::binary_search 二分查找 =====

    // 输出标题
    std::cout << "===== 2.7 std::binary_search =====" << std::endl;

    // binary_search 在已排序的范围内执行二分查找
    // 时间复杂度 O(log n)
    // 注意：范围必须已排序！否则结果是未定义的

    // data 目前是升序排序过的，所以可以使用
    bool found = std::binary_search(data.begin(), data.end(), 5);
    if (found) {
        // binary_search 返回 bool，表示值是否存在
        std::cout << "二分查找：5 存在" << std::endl;
    }

    // 查找不存在的值
    bool notFound = std::binary_search(data.begin(), data.end(), 99);
    if (!notFound) {
        std::cout << "二分查找：99 不存在" << std::endl;
    }

    // 使用 lower_bound 和 upper_bound
    // lower_bound 返回第一个 >= 指定值的元素位置
    // upper_bound 返回第一个 > 指定值的元素位置
    auto lower = std::lower_bound(data.begin(), data.end(), 5);
    auto upper = std::upper_bound(data.begin(), data.end(), 5);
    if (lower != data.end()) {
        std::cout << "lower_bound(5) 指向值: " << *lower
                  << "，索引: " << std::distance(data.begin(), lower)
                  << std::endl;
    }
    if (upper != data.end()) {
        std::cout << "upper_bound(5) 指向值: " << *upper
                  << "，索引: " << std::distance(data.begin(), upper)
                  << std::endl;
    }

    // equal_range 同时获取 lower_bound 和 upper_bound
    auto range = std::equal_range(data.begin(), data.end(), 5);
    std::cout << "值 5 的出现范围: ["
              << std::distance(data.begin(), range.first) << ", "
              << std::distance(data.begin(), range.second) << ")"
              << std::endl;

    std::cout << std::endl;

    // ========== 3. 综合示例：多种迭代器和算法的组合使用 ==========

    // 输出标题
    std::cout << "===== 3. 综合示例 =====" << std::endl;

    // 创建一个字符串 vector
    std::vector<std::string> words = {"hello", "world", "cplusplus", "stl", "iterator"};

    // 使用 std::max_element 找到最长的字符串
    // max_element 返回范围内最大元素的迭代器
    // 使用 lambda 自定义比较规则
    auto longest = std::max_element(words.begin(), words.end(),
        // 比较两个字符串的长度
        [](const std::string& a, const std::string& b) {
            // 如果 a 的长度小于 b 的长度，则 a < b
            return a.size() < b.size();
        }
    );
    // 输出最长的字符串
    if (longest != words.end()) {
        std::cout << "最长的单词: " << *longest
                  << " (长度: " << longest->size() << ")" << std::endl;
    }

    // 使用 std::transform 将所有字符串转为大写
    // transform 对范围内的每个元素应用函数，结果写入输出迭代器
    std::vector<std::string> upperWords;
    std::transform(words.begin(), words.end(),
                   std::back_inserter(upperWords),
                   // 将字符串转为大写的 lambda
                   [](std::string s) {
                       // 遍历字符串的每个字符
                       for (auto& c : s) {
                           // 使用 std::toupper 将字符转为大写
                           c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
                       }
                       // 返回转换后的字符串
                       return s;
                   }
    );

    // 输出转换后的结果
    std::cout << "转为大写: ";
    std::copy(upperWords.begin(), upperWords.end(),
              std::ostream_iterator<std::string>(std::cout, " "));
    std::cout << std::endl;

    // 使用 std::any_of 检查是否有任何单词包含字母 'x'
    // any_of 检查范围内是否有任何元素满足条件
    bool hasX = std::any_of(words.begin(), words.end(),
        // 检查字符串中是否包含字符 'x' 或 'X'
        [](const std::string& s) {
            // find 查找字符，返回位置迭代器
            // 不等于 npos 表示找到了
            return s.find('x') != std::string::npos ||
                   s.find('X') != std::string::npos;
        }
    );
    std::cout << "是否有单词包含 'x'? " << (hasX ? "是" : "否") << std::endl;

    // 使用 std::all_of 检查所有单词是否都包含字母 'e'
    bool allHaveE = std::all_of(words.begin(), words.end(),
        [](const std::string& s) {
            // 检查字符串中是否包含字符 'e' 或 'E'
            return s.find('e') != std::string::npos ||
                   s.find('E') != std::string::npos;
        }
    );
    std::cout << "所有单词都包含 'e'? " << (allHaveE ? "是" : "否") << std::endl;

    std::cout << std::endl;

    // ========== 结束 ==========

    std::cout << "===== STL 迭代器与算法演示结束 =====" << std::endl;

    // main 函数返回 0 表示程序正常结束
    return 0;
}
