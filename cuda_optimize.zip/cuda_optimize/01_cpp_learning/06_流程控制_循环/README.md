# 06 流程控制——循环

## 1. 直观理解

### 为什么要循环？

计算机最大的优势就是能**不厌其烦地重复**做一件事。循环就是告诉计算机"重复执行这段代码"的方式。

```
Python 思维：
for item in list:   # 遍历每个元素
    process(item)

C++ 思维：
for (int i = 0; i < n; i++) {  // 索引从 0 到 n-1
    process(arr[i]);
}
```

---

## 2. 语法速查

### for 循环

```cpp
for (初始化; 条件; 更新) {
    // 循环体
}
```

执行顺序：初始化 → 判断条件 → 执行循环体 → 执行更新 → 判断条件 → ...

```cpp
for (int i = 0; i < 10; i++) {
    cout << i << " ";
}
// 输出: 0 1 2 3 4 5 6 7 8 9
```

### while 循环

```cpp
while (条件) {
    // 循环体（可能一次都不执行）
}
```

```cpp
int i = 0;
while (i < 10) {
    cout << i++;
}
```

### do-while 循环

```cpp
do {
    // 循环体（至少执行一次）
} while (条件);
```

### 范围-based for 循环（C++11）

```cpp
int arr[] = {1, 2, 3, 4, 5};
for (int x : arr)           // 只读遍历
    cout << x;
for (int& x : arr)          // 可修改遍历
    x *= 2;
for (const auto& x : arr)   // 只读 + 自动类型 + 避免拷贝
    cout << x;
```

### break 和 continue

- `break`：立即退出**整个循环**
- `continue`：跳过本次迭代的剩余部分，进入下一次迭代

---

## 3. 底层原理

### 三种循环的等价关系

三种循环可以互相转换，编译后几乎是一样的跳转指令：

```cpp
// for 循环
for (初始化; 条件; 更新) { 循环体 }

// 等价于 while 循环
初始化;
while (条件) {
    循环体;
    更新;
}
```

```cpp
// while 循环
while (条件) { 循环体 }

// 等价于 for 循环
for (; 条件; ) { 循环体 }
```

选择哪个更多是**可读性**问题：
- `for`：循环次数已知
- `while`：靠条件控制，次数未知
- `do-while`：至少执行一次

### 循环的汇编结构

一个简单的 `for` 循环在汇编层面长这样：

```asm
; for (int i = 0; i < 10; i++) { body; }
    mov eax, 0          ; i = 0
.loop_start:
    cmp eax, 10         ; 比较 i < 10
    jge .loop_end       ; 如果 i >= 10，跳转到结束
    ; ... 循环体 ...
    inc eax             ; i++
    jmp .loop_start     ; 回到循环开始
.loop_end:
```

本质就三条：**比较、条件跳转、递增**。CPU 的分支预测器会在循环末尾的跳转处预测"继续循环"（即跳回 .loop_start），只有最后一次预测错——所以循环的分支预测命中率极高。

### `++i` vs `i++` 在循环中的性能

```cpp
for (int i = 0; i < n; i++)   // i++：创建临时对象（对 int 无差别，对迭代器有）
for (int i = 0; i < n; ++i)   // ++i：不创建临时对象，理论上更快
```

对内置类型 `int`，编译器会优化成完全相同的代码。但对**迭代器**（`std::vector<int>::iterator`），`i++` 确实会产生一次不必要的拷贝。所以习惯用 `++i`。

### 范围-based for 的本质

```cpp
for (int x : arr) { ... }

// 等价于：
auto&& __range = arr;
auto __begin = begin(__range);   // 或 __range.begin()
auto __end = end(__range);
for (; __begin != __end; ++__begin) {
    int x = *__begin;
    // ...
}
```

范围-based for 是通过 `begin()` / `end()` 函数和迭代器协议实现的。只要你的类型提供了 `begin()` 和 `end()`（返回可比较、可解引用、可递增的对象），就能用范围-based for。

### 循环展开（Loop Unrolling）

编译器可能会把你的循环展开来减少跳转指令：

```cpp
// 你写的：
for (int i = 0; i < 4; i++)
    arr[i] = 0;

// 编译器可能自动变成：
arr[0] = 0;
arr[1] = 0;
arr[2] = 0;
arr[3] = 0;
// 省掉了 4 次 i++ 和 4 次条件判断的跳转
```

编译器比大多数人懂何时展开——除非你非常明确，否则不要手动干预（不要用 `#pragma unroll` 除非 profiling 证明你需要）。

---

## 4. 深入细节

### 缓存友好的循环嵌套（i-j-k 顺序）

这是性能优化的经典问题——遍历二维数组时，`i-j` 顺序相差巨大：

```cpp
int arr[1000][1000];

// 快：按行遍历（内存连续，缓存命中率高）
for (int i = 0; i < 1000; i++)
    for (int j = 0; j < 1000; j++)
        arr[i][j] = 0;    // 地址: arr + i*1000*4 + j*4 → 连续访问

// 慢：按列遍历（每次跳 4000 字节，大量 cache miss）
for (int j = 0; j < 1000; j++)
    for (int i = 0; i < 1000; i++)
        arr[i][j] = 0;    // 地址: arr + i*1000*4 + j*4 → 跳跃 4000B
```

> C/C++ 的二维数组是**行优先（Row-Major）**存储。`arr[i][j]` 的地址 = `arr + (i * COLS + j) * sizeof(element)`。相邻的 j 在内存中是相邻的。

这个原理在 CUDA 编程中同样至关重要——决定了你的 kernel 是 memory-bound 还是 compute-bound。

### 不要在循环中做不必要的工作

```cpp
// 不好：每次循环都调用 size()
for (int i = 0; i < vec.size(); i++)   // size() 可能被调用 N 次！

// 好：size 存起来
const int n = vec.size();
for (int i = 0; i < n; i++)

// 对 std::vector::size() 来说，编译器通常能优化掉（内联 + 常量传播），
// 但对复杂的容器操作不要依赖编译器
```

### 循环中的浮点累积误差

```cpp
float sum = 0.0f;
for (int i = 0; i < 10000000; i++)
    sum += 0.1f;           // 累积 1000 万次加 0.1
// sum 不是 1,000,000.0！浮点精度丢失

// 如果需要精确累加，用 double 或专门的累加技术（Kahan 求和算法）
```

---

## 5. C++ vs Python 对照

```python
# Python
for i in range(10):          # 0 到 9
    print(i)

for item in my_list:         # 遍历元素（"范围-based"）
    print(item)

for i, item in enumerate(my_list):  # 同时要索引和元素
    print(i, item)

while condition:             # while 循环
    do_something()
```

```cpp
// C++
for (int i = 0; i < 10; i++)      // Python range(10) 的对应
    cout << i;

for (int item : my_vector)        // 遍历元素
    cout << item;

for (size_t i = 0; i < vec.size(); i++)  // 同时要索引和元素
    cout << i << vec[i];

while (condition)                  // while 循环
    doSomething();
```

| 方面 | Python | C++ |
|------|--------|-----|
| 遍历哲学 | "遍历元素"优先（for-in） | "遍历索引"优先（C 遗留），C++11 后也有 for-in |
| range | `range(n)` 惰性生成 | 不存在，用 `for (int i=0; i<n; i++)` |
| 遍历自定义容器 | 实现 `__iter__` / `__next__` | 实现 `begin()` / `end()` |
| 循环中修改容器 | 可能导致 RuntimeError | 可能导致迭代器失效（UB） |
| 性能 | 解释执行，循环开销大 | 编译后接近纯汇编，几乎没有额外开销 |

---

## 6. 练习与思考

### 基础练习

1. 用 `for` 循环输出 1 到 100 中所有 3 的倍数
2. 用 `while` 循环计算一个正整数的位数
3. 用范围-based for 遍历数组并找出最大/最小值
4. 用嵌套循环打印九九乘法表

### 思考题

5. 写代码测试二维数组按行遍历 vs 按列遍历的速度差异（至少 1000×1000），用 `chrono` 计时
6. `for (auto x : vec)` 和 `for (const auto& x : vec)` 有什么区别？什么时候用哪个？
7. 如果在循环中不断调用 `vec.push_back()` 会导致什么？（提示：迭代器失效、reallocation）
8. 循环中的 `break` 跳出多重循环——C++ 没有直接的 `break 2`，你有哪些办法？
