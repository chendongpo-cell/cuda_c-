// ============================================================
// 文件名: main.cpp
// 说明: 运算符与表达式 —— 全面演示各类运算符
// 演示内容: 算术、关系、逻辑、位运算、赋值、自增自减、优先级
// 编译命令: g++ main.cpp -o main -std=c++17
// ============================================================

// 包含输入输出流头文件，提供 cout 输出功能
#include <iostream>

// 使用标准命名空间，方便直接使用 cout、endl 等
using namespace std;

// main 函数 —— 程序入口
int main() {
    // ==========================================================
    // 1. 算术运算符
    // ==========================================================
    cout << "========== 1. 算术运算符 ==========" << endl;

    // 定义两个整数用于演示算术运算
    int a = 15;
    int b = 4;

    // 加法: + 运算符将两个操作数相加
    int sum = a + b;
    // 输出加法结果: 15 + 4 = 19
    cout << a << " + " << b << " = " << sum << endl;

    // 减法: - 运算符将两个操作数相减
    int diff = a - b;
    // 输出减法结果: 15 - 4 = 11
    cout << a << " - " << b << " = " << diff << endl;

    // 乘法: * 运算符将两个操作数相乘
    int product = a * b;
    // 输出乘法结果: 15 * 4 = 60
    cout << a << " * " << b << " = " << product << endl;

    // 整数除法: 两个整数相除，结果还是整数，小数部分被截断
    // 15 / 4 = 3.75，但整数除法结果为 3
    int quotient = a / b;
    // 输出整数除法结果
    cout << a << " / " << b << " = " << quotient << "（整数除法，截断小数）" << endl;

    // 浮点除法: 只要有一个操作数是浮点数，结果就是浮点数
    double floatQuotient = 15.0 / 4;
    // 输出浮点除法结果: 15.0 / 4 = 3.75
    cout << "15.0 / 4 = " << floatQuotient << "（浮点除法）" << endl;

    // 取模运算符: % 返回两个整数相除的余数
    // 15 ÷ 4 = 3 余 3，所以 15 % 4 = 3
    int remainder = a % b;
    // 输出取模（求余数）结果
    cout << a << " % " << b << " = " << remainder << "（余数）" << endl;

    cout << endl;

    // ==========================================================
    // 2. 关系运算符（比较运算符）
    // ==========================================================
    cout << "========== 2. 关系运算符 ==========" << endl;

    int x = 10;
    int y = 20;

    // 等于: == 判断两个值是否相等
    // 注意: 是 ==（两个等号），不是 =（一个等号是赋值）
    bool isEqual = (x == y);
    // 输出: 10 == 20 的结果是 false（0）
    cout << x << " == " << y << " : " << isEqual << "（false）" << endl;

    // 不等于: != 判断两个值是否不相等
    bool isNotEqual = (x != y);
    // 输出: 10 != 20 的结果是 true（1）
    cout << x << " != " << y << " : " << isNotEqual << "（true）" << endl;

    // 小于: < 判断左边是否小于右边
    bool isLess = (x < y);
    // 输出: 10 < 20 的结果是 true（1）
    cout << x << " < " << y << " : " << isLess << endl;

    // 大于: > 判断左边是否大于右边
    bool isGreater = (x > y);
    // 输出: 10 > 20 的结果是 false（0）
    cout << x << " > " << y << " : " << isGreater << endl;

    // 小于等于: <= 判断左边是否小于或等于右边
    bool isLessOrEqual = (x <= y);
    // 输出: 10 <= 20 的结果是 true（1）
    cout << x << " <= " << y << " : " << isLessOrEqual << endl;

    // 大于等于: >= 判断左边是否大于或等于右边
    int sameX = 10;
    bool isGreaterOrEqual = (x >= sameX);
    // 输出: 10 >= 10 的结果是 true（1），因为相等也满足 >=
    cout << x << " >= " << sameX << " : " << isGreaterOrEqual << endl;

    cout << endl;

    // ==========================================================
    // 3. 逻辑运算符
    // ==========================================================
    cout << "========== 3. 逻辑运算符 ==========" << endl;

    bool condition1 = true;   // 第一个条件为真
    bool condition2 = false;  // 第二个条件为假

    // 逻辑与 &&: 两边都为 true 结果才为 true
    bool andResult = condition1 && condition2;
    // 输出: true && false = false（0），因为至少有一个是 false
    cout << "true && false = " << andResult << endl;

    // 逻辑或 ||: 至少一边为 true 结果就为 true
    bool orResult = condition1 || condition2;
    // 输出: true || false = true（1），因为有一个是 true
    cout << "true || false = " << orResult << endl;

    // 逻辑非 !: 取反，true 变 false，false 变 true
    bool notResult = !condition1;
    // 输出: !true = false（0）
    cout << "!true = " << notResult << endl;

    // 更实际的示例: 判断一个数字是否在某个范围内
    int num = 15;
    // 判断 num 是否在 10 到 20 之间（包含边界）
    // 需要同时满足 num >= 10 和 num <= 20
    bool inRange = (num >= 10) && (num <= 20);
    // 输出: 15 在 10~20 范围内: true（1）
    cout << num << " 在 10~20 范围内: " << inRange << endl;

    // 判断一个数字是否超出范围（小于 10 或大于 20）
    bool outOfRange = (num < 10) || (num > 20);
    // 输出: 15 超出 10~20 范围: false（0）
    cout << num << " 超出 10~20 范围: " << outOfRange << endl;

    cout << endl;

    // ==========================================================
    // 4. 赋值运算符
    // ==========================================================
    cout << "========== 4. 赋值运算符 ==========" << endl;

    int value = 10;  // 基本赋值: = 将右边的值赋给左边的变量
    cout << "初始值: " << value << endl;

    // +=: 等价于 value = value + 5，将 value 加 5 后再赋给 value
    value += 5;
    cout << "value += 5  → " << value << endl;

    // -=: 等价于 value = value - 3
    value -= 3;
    cout << "value -= 3  → " << value << endl;

    // *=: 等价于 value = value * 2
    value *= 2;
    cout << "value *= 2  → " << value << endl;

    // /=: 等价于 value = value / 3（整数除法）
    value /= 3;
    cout << "value /= 3  → " << value << endl;

    // %=: 等价于 value = value % 4（取余数）
    value %= 4;
    cout << "value %= 4  → " << value << endl;

    cout << endl;

    // ==========================================================
    // 5. 自增和自减运算符
    // ==========================================================
    cout << "========== 5. 自增/自减 ==========" << endl;

    int counter = 5;

    // 后置自增: counter++，先使用当前值，然后再加 1
    // 先输出 counter 的当前值（5），然后 counter 变为 6
    cout << "counter++: " << counter++ << "（先输出，后自增）" << endl;
    cout << "现在 counter = " << counter << endl;

    // 前置自增: ++counter，先加 1，然后再使用新值
    // counter 先变为 7，然后输出 7
    cout << "++counter: " << ++counter << "（先自增，后输出）" << endl;

    // 后置自减: counter--，先使用当前值，然后再减 1
    int back = counter--;
    // back 得到的是 counter 减 1 之前的值
    cout << "back = counter--, back = " << back << ", counter = " << counter << endl;

    // 前置自减: --counter，先减 1，然后再使用新值
    back = --counter;
    // back 得到的是 counter 减 1 之后的值
    cout << "back = --counter, back = " << back << ", counter = " << counter << endl;

    cout << endl;

    // ==========================================================
    // 6. 位运算符（按二进制位操作）
    // ==========================================================
    cout << "========== 6. 位运算符 ==========" << endl;

    unsigned char m = 5;   // 二进制: 0000 0101
    unsigned char n = 3;   // 二进制: 0000 0011

    // 按位与 &: 对应位都为 1 时结果为 1，否则为 0
    // 0000 0101 & 0000 0011 = 0000 0001 = 1
    int bitAnd = m & n;
    cout << (int)m << " & " << (int)n << " = " << bitAnd << endl;

    // 按位或 |: 对应位至少有一个为 1 时结果为 1
    // 0000 0101 | 0000 0011 = 0000 0111 = 7
    int bitOr = m | n;
    cout << (int)m << " | " << (int)n << " = " << bitOr << endl;

    // 按位异或 ^: 对应位不同时结果为 1，相同时为 0
    // 0000 0101 ^ 0000 0011 = 0000 0110 = 6
    int bitXor = m ^ n;
    cout << (int)m << " ^ " << (int)n << " = " << bitXor << endl;

    // 按位取反 ~: 0 变 1，1 变 0（结果会是很大的数，因为有符号位）
    int bitNot = ~m;
    cout << "~" << (int)m << " = " << bitNot << endl;

    // 左移 <<: 二进制位向左移动，右侧补 0，相当于乘以 2^n
    // 0000 0101 << 1 = 0000 1010 = 10（相当于 5 * 2 = 10）
    int leftShift = m << 1;
    cout << (int)m << " << 1 = " << leftShift << "（相当于乘以 2）" << endl;

    // 右移 >>: 二进制位向右移动，左侧补 0，相当于除以 2^n
    // 0000 0101 >> 1 = 0000 0010 = 2（相当于 5 / 2 = 2，整数除法）
    int rightShift = m >> 1;
    cout << (int)m << " >> 1 = " << rightShift << "（相当于除以 2）" << endl;

    cout << endl;

    // ==========================================================
    // 7. 逗号运算符
    // ==========================================================
    cout << "========== 7. 逗号运算符 ==========" << endl;

    // 逗号运算符会依次执行多个表达式，返回最后一个表达式的值
    // 先执行 a = 1，再执行 b = 2，最后表达式结果是 3
    int commaResult = (a = 1, b = 2, 3);
    // 输出: commaResult = 3（逗号表达式最后一个值）
    cout << "逗号表达式结果: " << commaResult << endl;
    cout << "a = " << a << ", b = " << b << endl;

    cout << endl;

    // ==========================================================
    // 8. 运算符优先级演示
    // ==========================================================
    cout << "========== 8. 运算符优先级 ==========" << endl;

    // 不加括号时，* 的优先级高于 +，所以先算乘法再算加法
    // 3 + 4 * 5 = 3 + 20 = 23
    int noParen = 3 + 4 * 5;
    cout << "3 + 4 * 5 = " << noParen << "（先算乘法）" << endl;

    // 加括号改变计算顺序
    // (3 + 4) * 5 = 7 * 5 = 35
    int withParen = (3 + 4) * 5;
    cout << "(3 + 4) * 5 = " << withParen << "（括号内先算）" << endl;

    // 混合优先级示例
    // ! 优先级高于 &&，&& 优先级高于 ||
    // true || false && false → true || (false && false) → true || false → true
    bool logicPrio = true || false && false;
    cout << "true || false && false = " << logicPrio << endl;

    // 用括号明确意图: (true || false) && false → true && false → false
    bool logicPrioWithParen = (true || false) && false;
    cout << "(true || false) && false = " << logicPrioWithParen << endl;

    cout << endl;

    // ==========================================================
    // 9. 三元运算符 ?:
    // ==========================================================
    cout << "========== 9. 三元运算符 ==========" << endl;

    int score = 75;

    // 三元运算符: 条件 ? 条件为真时的值 : 条件为假时的值
    // 如果 score >= 60，输出"及格"，否则输出"不及格"
    string result = (score >= 60) ? "及格" : "不及格";
    // 输出: 分数 75 → 及格
    cout << "分数 " << score << " → " << result << endl;

    // 三元运算符的嵌套使用（不推荐，可读性差）
    int gradeScore = 85;
    // 如果 >= 90 为优秀，>= 60 为及格，否则为不及格
    string level = (gradeScore >= 90) ? "优秀"
                 : (gradeScore >= 60) ? "及格"
                 : "不及格";
    // 输出: 85 → 及格
    cout << "分数 " << gradeScore << " → " << level << endl;

    // 程序结束，返回 0 表示正常结束
    return 0;
}
