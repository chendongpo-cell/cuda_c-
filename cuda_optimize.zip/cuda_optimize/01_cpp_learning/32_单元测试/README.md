# 32 单元测试

## 概述

单元测试（Unit Testing）是对软件中的最小可测试单元（通常是函数或方法）进行验证的实践。C++ 中最流行的单元测试框架是 Google Test（也称为 gtest）。

---

## 1. 为什么需要单元测试？

### 单元测试的好处
- **尽早发现 Bug**：在开发阶段就捕获问题，降低修复成本
- **保证代码质量**：促使开发者写出更模块化、可测试的代码
- **重构安全网**：修改代码后运行测试，确保没有破坏已有功能
- **文档作用**：测试用例本身就是代码的使用示例
- **回归测试**：防止旧 Bug 重新出现

---

## 2. Google Test (gtest) 简介

Google Test 是 Google 开发的 C++ 测试框架，被广泛应用于 C++ 项目中。

### 基本概念
| 概念 | 说明 |
|------|------|
| Test Suite | 一组相关的测试用例 |
| Test Case | 单个测试函数 |
| Assertion | 验证条件的宏 |
| Test Fixture | 测试夹具，为多个测试提供共享的配置 |

### 常用断言宏

**基本断言**：
| 断言 | 验证条件 |
|------|----------|
| `EXPECT_TRUE(condition)` | condition 为 true |
| `EXPECT_FALSE(condition)` | condition 为 false |
| `EXPECT_EQ(a, b)` | a == b |
| `EXPECT_NE(a, b)` | a != b |
| `EXPECT_LT(a, b)` | a < b |
| `EXPECT_LE(a, b)` | a <= b |
| `EXPECT_GT(a, b)` | a > b |
| `EXPECT_GE(a, b)` | a >= b |

**致命断言**（失败时立即终止当前测试）：
| 断言 | 对应 EXPECT 版本 |
|------|------------------|
| `ASSERT_TRUE(condition)` | EXPECT_TRUE |
| `ASSERT_EQ(a, b)` | EXPECT_EQ |
| `ASSERT_NE(a, b)` | EXPECT_NE |
| ... | ... |

**字符串断言**：
| 断言 | 验证条件 |
|------|----------|
| `EXPECT_STREQ(a, b)` | C 风格字符串相等 |
| `EXPECT_STRNE(a, b)` | C 风格字符串不等 |
| `EXPECT_STRCASEEQ(a, b)` | 忽略大小写相等 |

**异常断言**：
| 断言 | 验证条件 |
|------|----------|
| `EXPECT_THROW(statement, exception_type)` | 抛出指定异常 |
| `EXPECT_ANY_THROW(statement)` | 抛出任意异常 |
| `EXPECT_NO_THROW(statement)` | 不抛出异常 |

---

## 3. TEST 宏

最基本的测试定义方式，用于编写独立的测试用例。

```cpp
#include <gtest/gtest.h>

// TEST(TestSuiteName, TestName)
TEST(MathTest, Addition) {
    EXPECT_EQ(2 + 2, 4);
    EXPECT_EQ(0 + 5, 5);
}

TEST(MathTest, Subtraction) {
    EXPECT_EQ(5 - 3, 2);
    EXPECT_EQ(0 - 5, -5);
}
```

---

## 4. TEST_F 宏与 Test Fixture

当多个测试需要相同的设置（setup）和清理（teardown）时，使用 TEST_F。

```cpp
class CalculatorTest : public ::testing::Test {
protected:
    Calculator calc;

    void SetUp() override {
        // 每个 TEST_F 执行前的初始化代码
        calc.clear();
    }

    void TearDown() override {
        // 每个 TEST_F 执行后的清理代码
    }
};

TEST_F(CalculatorTest, AddTwoNumbers) {
    EXPECT_EQ(calc.add(2, 3), 5);
}
```

### SetUp / TearDown 执行顺序
```
Test body (TEST_F 内容)
  ↑
TearDown()
  ↑
SetUp()
  ↑
构造函数
```

---

## 5. 自定义测试框架

如果 Google Test 未安装，可以编写一个轻量级的自定义测试框架。一个简单的测试框架通常包含：

- **断言宏**：验证条件，失败时记录错误
- **测试注册**：自动注册测试用例
- **测试运行器**：执行所有测试并输出结果

```cpp
// 简单断言宏示例
#define EXPECT_EQ(a, b) \
    do { \
        auto _a = (a); \
        auto _b = (b); \
        if (_a != _b) { \
            std::cerr << "FAILED: " << #a << " == " << #b \
                      << " (expected " << _b << ", got " << _a << ")" << std::endl; \
            success = false; \
        } \
    } while(0)
```

---

## 6. 测试最佳实践

### 1. 单一职责
每个测试只测试一个功能点，一个断言失败时能清楚知道问题在哪。

### 2. 测试命名
使用清晰的命名：`TestClassName_MethodName_ExpectedBehavior`

### 3. AAA 模式
```
Arrange（准备）：设置测试数据和前置条件
Act（执行）：调用被测试的方法
Assert（断言）：验证结果是否符合预期
```

### 4. 避免依赖
测试之间应相互独立，不依赖执行顺序。

### 5. 测试边界条件
- 空值 / 零值
- 最大值 / 最小值
- 异常输入

### 6. 代码覆盖率
- 语句覆盖：每条语句至少执行一次
- 分支覆盖：每个条件分支至少执行一次
- 路径覆盖：每条可能路径至少执行一次

---

## 7. 示例项目结构

```
项目根目录/
├── CMakeLists.txt
├── src/
│   ├── calculator.h
│   └── calculator.cpp
└── tests/
    ├── CMakeLists.txt
    ├── main.cpp          # gtest 入口
    └── calculator_test.cpp
```

### CMake 集成示例
```cmake
# tests/CMakeLists.txt
find_package(GTest REQUIRED)
add_executable(unit_tests calculator_test.cpp main.cpp)
target_link_libraries(unit_tests GTest::GTest GTest::Main)
```

---

## 8. 测试驱动开发 (TDD)

TDD 的开发流程：
1. **红**（Red）：先写一个失败的测试
2. **绿**（Green）：编写最简代码让测试通过
3. **重构**（Refactor）：优化代码，保持测试通过

```
[写测试] → [测试失败] → [写代码] → [测试通过] → [重构]
    ↑                                        |
    └────────────────────────────────────────┘
```

---

## 总结

- 单元测试是保证代码质量的重要手段
- Google Test 是 C++ 中最常用的测试框架
- TEST 宏用于独立测试，TEST_F 用于需要夹具的测试
- 没有框架时也可以自己写轻量级测试框架
- 遵循 AAA 模式编写清晰的测试用例
- 测试边界条件和异常情况
