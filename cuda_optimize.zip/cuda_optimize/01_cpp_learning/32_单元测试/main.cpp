#include <iostream>     // 标准输入输出流库，用于控制台输出
#include <string>       // 字符串库，用于 std::string
#include <vector>       // 向量容器库，用于存储测试结果
#include <functional>   // 函数对象库，用于 std::function
#include <cmath>        // 数学库，用于 std::isnan 等

// ====================================================================
// 简易测试框架（从零搭建，不依赖 Google Test）
//
// 如果系统中安装了 Google Test，可以使用 gtest 替代本框架
// 但为了演示单元测试的原理，这里手动实现一个轻量级测试框架
//
// 本框架包含：
//   1. 断言宏：EXPECT_EQ, EXPECT_NE, EXPECT_TRUE, EXPECT_FALSE
//   2. 测试注册：自动将测试用例注册到全局列表
//   3. 测试运行器：执行所有测试并输出详细的测试报告
// ====================================================================

// 前向声明 TestCase 结构体
struct TestCase;

// 全局测试注册表：存储所有注册的测试用例
// 使用函数返回局部 static 变量的方式确保全局唯一实例
static std::vector<TestCase>& getTestRegistry() {
    static std::vector<TestCase> registry;  // 全局唯一的测试注册表
    return registry;
}

// 测试用例结构体
// 存储每个测试用例的名称和对应的测试函数
struct TestCase {
    std::string suiteName;              // 测试套件名称
    std::string testName;               // 测试用例名称
    std::function<void()> testFunc;     // 测试函数（可调用对象）
};

// 测试注册器类
// 在静态初始化阶段自动将测试用例注册到全局注册表
class TestRegistrar {
public:
    // 构造函数：在创建时自动注册测试用例
    TestRegistrar(const std::string& suite, const std::string& name,
                  std::function<void()> func) {
        // 将测试用例添加到全局注册表
        getTestRegistry().push_back({suite, name, std::move(func)});
    }
};

// ========== 断言宏定义 ==========

// 全局测试结果状态
static bool g_currentTestPassed = true;  // 当前测试是否通过
static int g_totalTests = 0;             // 总测试数
static int g_passedTests = 0;            // 通过的测试数
static int g_failedTests = 0;            // 失败的测试数

// 输出测试失败信息
static void recordFailure(const std::string& file, int line,
                          const std::string& expr, const std::string& msg) {
    // 标记当前测试为失败
    g_currentTestPassed = false;
    // 输出失败信息：文件名、行号、表达式和详细消息
    std::cerr << "    [失败] " << file << ":" << line << std::endl;
    std::cerr << "      表达式: " << expr << std::endl;
    std::cerr << "      信息: " << msg << std::endl;
}

// EXPECT_TRUE 宏：验证条件为 true
#define EXPECT_TRUE(condition) \
    do { \
        if (!(condition)) { \
            /* 条件为 false，记录失败 */ \
            recordFailure(__FILE__, __LINE__, #condition, \
                          "期望为 true，实际为 false"); \
        } \
    } while(0)

// EXPECT_FALSE 宏：验证条件为 false
#define EXPECT_FALSE(condition) \
    do { \
        if ((condition)) { \
            /* 条件为 true，记录失败 */ \
            recordFailure(__FILE__, __LINE__, #condition, \
                          "期望为 false，实际为 true"); \
        } \
    } while(0)

// EXPECT_EQ 宏：验证两个值相等
#define EXPECT_EQ(a, b) \
    do { \
        auto _a = (a);  /* 计算左值 */ \
        auto _b = (b);  /* 计算右值 */ \
        if (_a != _b) { \
            /* 不相等，记录失败并显示期望值和实际值 */ \
            recordFailure(__FILE__, __LINE__, #a " == " #b, \
                          "期望: " + std::to_string(_b) + \
                          ", 实际: " + std::to_string(_a)); \
        } \
    } while(0)

// EXPECT_NE 宏：验证两个值不相等
#define EXPECT_NE(a, b) \
    do { \
        auto _a = (a);  /* 计算左值 */ \
        auto _b = (b);  /* 计算右值 */ \
        if (_a == _b) { \
            /* 相等，记录失败 */ \
            recordFailure(__FILE__, __LINE__, #a " != " #b, \
                          "两个值都是: " + std::to_string(_a)); \
        } \
    } while(0)

// EXPECT_THROW 宏：验证表达式抛出指定类型的异常
#define EXPECT_THROW(statement, exception_type) \
    do { \
        bool _caught = false; \
        try { \
            statement;  /* 执行可能抛出异常的语句 */ \
        } catch (const exception_type&) { \
            _caught = true;  /* 捕获到期望的异常类型 */ \
        } catch (...) { \
            /* 捕获到其他类型的异常 */ \
        } \
        if (!_caught) { \
            recordFailure(__FILE__, __LINE__, #statement, \
                          "期望抛出 " #exception_type " 类型异常，但未抛出"); \
        } \
    } while(0)

// EXPECT_NO_THROW 宏：验证表达式不抛出任何异常
#define EXPECT_NO_THROW(statement) \
    do { \
        try { \
            statement;  /* 执行语句 */ \
        } catch (...) { \
            /* 捕获到任何异常都算失败 */ \
            recordFailure(__FILE__, __LINE__, #statement, \
                          "期望不抛出异常，但实际抛出了异常"); \
        } \
    } while(0)

// 辅助宏：将两个 Token 拼接（用于生成唯一变量名）
#define CONCAT_(a, b) a ## b
#define CONCAT(a, b) CONCAT_(a, b)

// TEST 宏：定义一个测试用例
// 在静态初始化阶段自动注册到全局测试注册表
#define TEST(suite, name) \
    static void CONCAT(test_, CONCAT(suite, CONCAT(_, name)))(); \
    static TestRegistrar CONCAT(registrar_, CONCAT(suite, CONCAT(_, name))) = \
        TestRegistrar(#suite, #name, \
            CONCAT(test_, CONCAT(suite, CONCAT(_, name)))); \
    static void CONCAT(test_, CONCAT(suite, CONCAT(_, name)))()

// ========== 测试运行器 ==========

// 运行所有已注册的测试用例
static int runAllTests() {
    // 获取全局测试注册表
    auto& registry = getTestRegistry();
    // 输出测试开始信息
    std::cout << "========================================" << std::endl;
    std::cout << "  单元测试运行器 - 开始执行测试" << std::endl;
    std::cout << "  共 " << registry.size() << " 个测试用例" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << std::endl;

    // 遍历所有注册的测试并执行
    std::string currentSuite = "";  // 当前测试套件名称

    for (size_t i = 0; i < registry.size(); ++i) {
        const auto& testCase = registry[i];

        // 如果切换了测试套件，输出套件名称
        if (testCase.suiteName != currentSuite) {
            currentSuite = testCase.suiteName;
            std::cout << "--- 测试套件: " << currentSuite << " ---" << std::endl;
        }

        // 输出测试用例名称
        std::cout << "  测试: " << testCase.testName << " ... ";

        // 重置当前测试状态
        g_currentTestPassed = true;
        g_totalTests++;

        try {
            // 执行测试函数
            testCase.testFunc();
        } catch (const std::exception& e) {
            // 捕获测试中未处理的 C++ 异常
            g_currentTestPassed = false;
            std::cerr << std::endl;
            std::cerr << "    [异常] 未捕获的异常: " << e.what() << std::endl;
        } catch (...) {
            // 捕获测试中未处理的非 C++ 异常
            g_currentTestPassed = false;
            std::cerr << std::endl;
            std::cerr << "    [异常] 未捕获的未知异常" << std::endl;
        }

        // 根据测试结果输出 PASSED 或 FAILED
        if (g_currentTestPassed) {
            std::cout << "PASSED" << std::endl;
            g_passedTests++;
        } else {
            std::cout << "FAILED" << std::endl;
            g_failedTests++;
        }
    }

    // 输出测试总结
    std::cout << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "  测试完成" << std::endl;
    std::cout << "  总计: " << g_totalTests << std::endl;
    std::cout << "  通过: " << g_passedTests << std::endl;
    std::cout << "  失败: " << g_failedTests << std::endl;
    std::cout << "========================================" << std::endl;

    // 如果有失败的测试，返回非零值
    return g_failedTests > 0 ? 1 : 0;
}

// ========== Calculator 类：被测试的目标类 ==========

// Calculator 是一个简单的计算器类，包含基本的算术运算
// 我们将通过单元测试来验证它的每个方法是否工作正确
class Calculator {
public:
    // 默认构造函数
    Calculator() {
        // 初始化内存中的计算结果
        lastResult_ = 0.0;
    }

    // 加法：返回 a + b 的结果
    double add(double a, double b) {
        lastResult_ = a + b;  // 保存最后计算结果
        return lastResult_;
    }

    // 减法：返回 a - b 的结果
    double subtract(double a, double b) {
        lastResult_ = a - b;  // 保存最后计算结果
        return lastResult_;
    }

    // 乘法：返回 a * b 的结果
    double multiply(double a, double b) {
        lastResult_ = a * b;  // 保存最后计算结果
        return lastResult_;
    }

    // 除法：返回 a / b 的结果
    // 当除数为 0 时，抛出 std::invalid_argument 异常
    double divide(double a, double b) {
        if (b == 0.0) {
            // 除零错误，抛出异常
            throw std::invalid_argument("除数不能为零");
        }
        lastResult_ = a / b;  // 保存最后计算结果
        return lastResult_;
    }

    // 幂运算：返回 a 的 b 次方
    double power(double base, double exp) {
        lastResult_ = std::pow(base, exp);  // 使用标准库的 pow 函数
        return lastResult_;
    }

    // 取模运算：返回 a % b 的结果（仅用于整数）
    int modulo(int a, int b) {
        if (b == 0) {
            // 除零错误，抛出异常
            throw std::invalid_argument("模数不能为零");
        }
        lastResult_ = static_cast<double>(a % b);  // 保存结果
        return a % b;
    }

    // 获取上次计算的结果
    double getLastResult() const {
        return lastResult_;
    }

    // 清空上次计算的结果
    void clear() {
        lastResult_ = 0.0;
    }

private:
    double lastResult_;  // 存储上一次计算的结果
};

// ========== 定义测试用例 ==========

// ========== 测试套件: CalculatorAddTest ==========

TEST(CalculatorAddTest, PositiveNumbers) {
    // 测试两个正数相加
    // Arrange（准备）
    Calculator calc;

    // Act（执行）和 Assert（断言）
    EXPECT_EQ(calc.add(2.0, 3.0), 5.0);       // 2 + 3 = 5
    EXPECT_EQ(calc.add(0.5, 0.25), 0.75);     // 0.5 + 0.25 = 0.75
    EXPECT_EQ(calc.add(100, 200), 300);        // 100 + 200 = 300
}

TEST(CalculatorAddTest, NegativeNumbers) {
    // 测试负数相加
    Calculator calc;

    EXPECT_EQ(calc.add(-2.0, -3.0), -5.0);     // -2 + (-3) = -5
    EXPECT_EQ(calc.add(-5.0, 3.0), -2.0);       // -5 + 3 = -2
    EXPECT_EQ(calc.add(5.0, -3.0), 2.0);        // 5 + (-3) = 2
}

TEST(CalculatorAddTest, Zero) {
    // 测试与零相加的边界情况
    Calculator calc;

    EXPECT_EQ(calc.add(0.0, 0.0), 0.0);         // 0 + 0 = 0
    EXPECT_EQ(calc.add(5.0, 0.0), 5.0);         // 5 + 0 = 5
    EXPECT_EQ(calc.add(0.0, 5.0), 5.0);         // 0 + 5 = 5
}

// ========== 测试套件: CalculatorSubtractTest ==========

TEST(CalculatorSubtractTest, PositiveNumbers) {
    // 测试正数相减
    Calculator calc;

    EXPECT_EQ(calc.subtract(5.0, 3.0), 2.0);    // 5 - 3 = 2
    EXPECT_EQ(calc.subtract(10.0, 5.5), 4.5);   // 10 - 5.5 = 4.5
    EXPECT_EQ(calc.subtract(1.0, 0.5), 0.5);    // 1 - 0.5 = 0.5
}

TEST(CalculatorSubtractTest, NegativeResults) {
    // 测试结果为负数的情况
    Calculator calc;

    EXPECT_EQ(calc.subtract(3.0, 5.0), -2.0);    // 3 - 5 = -2
    EXPECT_EQ(calc.subtract(-3.0, 5.0), -8.0);    // -3 - 5 = -8
    EXPECT_EQ(calc.subtract(3.0, -5.0), 8.0);     // 3 - (-5) = 8
}

TEST(CalculatorSubtractTest, Zero) {
    // 测试与零相减的边界情况
    Calculator calc;

    EXPECT_EQ(calc.subtract(5.0, 0.0), 5.0);     // 5 - 0 = 5
    EXPECT_EQ(calc.subtract(0.0, 5.0), -5.0);    // 0 - 5 = -5
    EXPECT_EQ(calc.subtract(0.0, 0.0), 0.0);     // 0 - 0 = 0
}

// ========== 测试套件: CalculatorMultiplyTest ==========

TEST(CalculatorMultiplyTest, PositiveNumbers) {
    // 测试正数相乘
    Calculator calc;

    EXPECT_EQ(calc.multiply(2.0, 3.0), 6.0);      // 2 * 3 = 6
    EXPECT_EQ(calc.multiply(2.5, 4.0), 10.0);     // 2.5 * 4 = 10
    EXPECT_EQ(calc.multiply(0.5, 0.5), 0.25);     // 0.5 * 0.5 = 0.25
}

TEST(CalculatorMultiplyTest, NegativeNumbers) {
    // 测试负数相乘
    Calculator calc;

    EXPECT_EQ(calc.multiply(-2.0, 3.0), -6.0);    // -2 * 3 = -6
    EXPECT_EQ(calc.multiply(-2.0, -3.0), 6.0);    // -2 * -3 = 6
    EXPECT_EQ(calc.multiply(2.0, -3.0), -6.0);    // 2 * -3 = -6
}

TEST(CalculatorMultiplyTest, Zero) {
    // 测试乘以零的边界情况
    Calculator calc;

    EXPECT_EQ(calc.multiply(5.0, 0.0), 0.0);      // 5 * 0 = 0
    EXPECT_EQ(calc.multiply(0.0, 5.0), 0.0);      // 0 * 5 = 0
    EXPECT_EQ(calc.multiply(0.0, 0.0), 0.0);      // 0 * 0 = 0
}

TEST(CalculatorMultiplyTest, LargeNumbers) {
    // 测试大数相乘
    Calculator calc;

    EXPECT_EQ(calc.multiply(1000000.0, 1000000.0), 1e12);  // 100万 * 100万 = 1e12
}

// ========== 测试套件: CalculatorDivideTest ==========

TEST(CalculatorDivideTest, PositiveNumbers) {
    // 测试正数相除
    Calculator calc;

    EXPECT_EQ(calc.divide(6.0, 3.0), 2.0);        // 6 / 3 = 2
    EXPECT_EQ(calc.divide(10.0, 4.0), 2.5);       // 10 / 4 = 2.5
    EXPECT_EQ(calc.divide(1.0, 3.0), 1.0 / 3.0);  // 1 / 3 ≈ 0.333...
}

TEST(CalculatorDivideTest, NegativeNumbers) {
    // 测试负数相除
    Calculator calc;

    EXPECT_EQ(calc.divide(-6.0, 3.0), -2.0);      // -6 / 3 = -2
    EXPECT_EQ(calc.divide(6.0, -3.0), -2.0);      // 6 / -3 = -2
    EXPECT_EQ(calc.divide(-6.0, -3.0), 2.0);      // -6 / -3 = 2
}

TEST(CalculatorDivideTest, DivisionByZero) {
    // 测试除零异常
    Calculator calc;

    // 验证除零时会抛出 std::invalid_argument 异常
    EXPECT_THROW(calc.divide(5.0, 0.0), std::invalid_argument);
    EXPECT_THROW(calc.divide(0.0, 0.0), std::invalid_argument);
    EXPECT_THROW(calc.divide(-5.0, 0.0), std::invalid_argument);
}

TEST(CalculatorDivideTest, DivideBySelf) {
    // 测试除以自身的特殊情况
    Calculator calc;

    EXPECT_EQ(calc.divide(5.0, 5.0), 1.0);        // 5 / 5 = 1
    EXPECT_EQ(calc.divide(-3.0, -3.0), 1.0);      // -3 / -3 = 1
}

TEST(CalculatorDivideTest, ZeroDivided) {
    // 测试零除以非零数
    Calculator calc;

    EXPECT_EQ(calc.divide(0.0, 5.0), 0.0);        // 0 / 5 = 0
    EXPECT_EQ(calc.divide(0.0, -5.0), 0.0);        // 0 / -5 = 0
}

// ========== 测试套件: CalculatorEdgeCasesTest ==========

TEST(CalculatorEdgeCasesTest, VeryLargeNumbers) {
    // 测试极端大数的运算
    Calculator calc;
    double large = 1e15;  // 10 的 15 次方

    EXPECT_EQ(calc.add(large, large), 2e15);       // 大数加法
    EXPECT_EQ(calc.multiply(large, 2.0), 2e15);    // 大数乘法
}

TEST(CalculatorEdgeCasesTest, VerySmallNumbers) {
    // 测试极端小数的运算（浮点数精度）
    Calculator calc;
    double small = 1e-10;  // 10 的负 10 次方

    EXPECT_EQ(calc.add(small, small), 2e-10);      // 小数加法
    EXPECT_EQ(calc.divide(small, 2.0), 5e-11);     // 小数除法
}

TEST(CalculatorEdgeCasesTest, FloatingPointPrecision) {
    // 测试浮点数精度相关的边界情况
    Calculator calc;

    // 0.1 + 0.2 在浮点数中不等于 0.3（经典精度问题）
    // 这里我们用误差范围来判断
    double result = calc.add(0.1, 0.2);
    // 验证结果非常接近 0.3（差值小于 1e-10）
    EXPECT_TRUE(std::abs(result - 0.3) < 1e-10);
}

TEST(CalculatorEdgeCasesTest, ChainedOperations) {
    // 测试链式操作和 getLastResult
    Calculator calc;

    calc.add(5.0, 3.0);             // 5 + 3 = 8
    EXPECT_EQ(calc.getLastResult(), 8.0);  // 验证最后结果为 8

    calc.subtract(calc.getLastResult(), 2.0);  // 8 - 2 = 6
    EXPECT_EQ(calc.getLastResult(), 6.0);      // 验证最后结果为 6
}

TEST(CalculatorEdgeCasesTest, NoThrowForValidOperations) {
    // 验证有效操作不会抛出异常
    Calculator calc;

    EXPECT_NO_THROW(calc.add(1.0, 2.0));        // 加法不抛异常
    EXPECT_NO_THROW(calc.subtract(5.0, 3.0));   // 减法不抛异常
    EXPECT_NO_THROW(calc.multiply(2.0, 3.0));   // 乘法不抛异常
    EXPECT_NO_THROW(calc.divide(6.0, 2.0));     // 合法除法不抛异常
}

TEST(CalculatorEdgeCasesTest, ModuloOperation) {
    // 测试取模运算
    Calculator calc;

    EXPECT_EQ(calc.modulo(10, 3), 1);            // 10 % 3 = 1
    EXPECT_EQ(calc.modulo(10, 5), 0);            // 10 % 5 = 0
    EXPECT_EQ(calc.modulo(7, 2), 1);             // 7 % 2 = 1
    EXPECT_THROW(calc.modulo(10, 0), std::invalid_argument);  // 模零抛出异常
}

TEST(CalculatorEdgeCasesTest, ClearFunction) {
    // 测试 clear 方法
    Calculator calc;

    calc.add(100.0, 200.0);                     // 执行加法
    EXPECT_EQ(calc.getLastResult(), 300.0);      // 结果为 300

    calc.clear();                                // 清空结果
    EXPECT_EQ(calc.getLastResult(), 0.0);        // 结果归零
}

// ========== 主函数 ==========

int main() {
    // 输出程序标题
    std::cout << "========== 单元测试演示 ==========" << std::endl;
    std::cout << "被测试类: Calculator" << std::endl;
    std::cout << "测试框架: 自建轻量级测试框架" << std::endl;
    std::cout << "（如果安装了 Google Test，可切换使用 gtest）" << std::endl;
    std::cout << std::endl;

    // 运行所有已注册的测试用例
    int result = runAllTests();

    // 输出测试完成信息
    std::cout << std::endl;
    std::cout << "Calculator 类的测试覆盖了以下方法:" << std::endl;
    std::cout << "  - add() 加法: 正数、负数、零" << std::endl;
    std::cout << "  - subtract() 减法: 正数、负数、零" << std::endl;
    std::cout << "  - multiply() 乘法: 正数、负数、零、大数" << std::endl;
    std::cout << "  - divide() 除法: 正数、负数、零、除零异常" << std::endl;
    std::cout << "  - modulo() 取模: 正常值、模零异常" << std::endl;
    std::cout << "  - getLastResult() / clear(): 状态管理" << std::endl;
    std::cout << "  - 边界情况: 大数、小数、浮点精度、链式操作" << std::endl;

    // 以测试结果作为程序返回值
    return result;
}
