# 23 - 智能指针 (Smart Pointers)

## 为什么需要智能指针？

### 传统指针的问题

在传统 C++ 中，使用 `new`/`delete` 手动管理内存容易导致以下问题：

1. **内存泄漏**：忘记 `delete`，导致内存无法回收
2. **悬空指针**：`delete` 后继续使用指针
3. **重复释放**：多次 `delete` 同一块内存
4. **异常不安全**：异常发生时，`delete` 语句不会执行

```cpp
// 传统手动管理的问题示例
void func() {
    int* p = new int(42);
    doSomething();     // 如果这里抛出异常，delete 不会执行！
    delete p;          // 可能永远不会执行到这行
}
```

### 智能指针的解决方案

智能指针是一个**类**，它**包装了原始指针**，利用 **RAII（Resource Acquisition Is Initialization）** 机制自动管理内存：
- 创建时获取资源（内存）
- 析构时自动释放资源（内存）
- 拷贝和赋值控制所有权

C++11 引入了三种智能指针，定义在 `<memory>` 头文件中。

## unique_ptr（独占所有权）

`unique_ptr` 是**独占所有权**的智能指针：
- 同一时刻**只能有一个** `unique_ptr` 指向一个对象
- **不能拷贝**，只能**移动**（转移所有权）
- 离开作用域时自动释放对象
- 几乎没有性能开销

```cpp
std::unique_ptr<int> p1(new int(42));
std::unique_ptr<int> p2 = p1;              // 错误！不能拷贝
std::unique_ptr<int> p3 = std::move(p1);   // 正确！移动所有权

// p1 现在为空，p3 拥有对象
```

**使用场景**：独占资源的场景，如：工厂方法的返回值、容器中的元素等。

## shared_ptr（共享所有权）

`shared_ptr` 是**共享所有权**的智能指针：
- 多个 `shared_ptr` 可以指向**同一个**对象
- 使用**引用计数**跟踪所有者数量
- 当最后一个 `shared_ptr` 被销毁时，自动释放对象
- 有轻微的性能开销（维护引用计数的原子操作）

```cpp
std::shared_ptr<int> p1(new int(42));
std::shared_ptr<int> p2 = p1;   // 引用计数变为 2

// 当 p1 和 p2 都离开作用域时，内存自动释放
```

**引用计数的工作原理**：
```
p1 = make_shared<int>(42)
    [对象: 42] 引用计数: 1

p2 = p1
    [对象: 42] 引用计数: 2

p1.reset()  // p1 放弃所有权
    [对象: 42] 引用计数: 1

p2.reset()  // p2 放弃所有权
    [对象: 42] 引用计数: 0 -> 自动删除
```

## weak_ptr（弱引用 / 观察者）

`weak_ptr` **不增加引用计数**，它是对 `shared_ptr` 管理对象的**弱引用**：
- 不影响对象的生命周期
- 不能直接访问对象（没有 `operator*` 和 `operator->`）
- 通过 `lock()` 方法获取一个 `shared_ptr` 来访问对象
- 用于**打破循环引用**

```cpp
std::shared_ptr<int> sp(new int(42));
std::weak_ptr<int> wp = sp;   // 引用计数仍为 1

if (auto locked = wp.lock()) {  // 获取 shared_ptr
    std::cout << *locked;       // 访问对象
} else {
    std::cout << "对象已被释放";
}
```

### 循环引用问题

循环引用是指两个或多个 `shared_ptr` 互相引用，导致引用计数永远不会降为 0：

```cpp
struct Node {
    std::shared_ptr<Node> next;
};

auto a = std::make_shared<Node>();
auto b = std::make_shared<Node>();

a->next = b;  // a 持有 b
b->next = a;  // b 持有 a
// 形成循环引用！a 和 b 的引用计数都是 2
// 离开作用域后计数变为 1，不会被释放
```

解决方法：使用 `weak_ptr` 打破循环：

```cpp
struct Node {
    std::weak_ptr<Node> next;  // 使用 weak_ptr
};

auto a = std::make_shared<Node>();
auto b = std::make_shared<Node>();

a->next = b;  // b 的引用计数不变
b->next = a;  // a 的引用计数不变
// 离开作用域后自动释放！
```

## make_unique / make_shared

C++14 引入了 `std::make_unique`，C++11 有 `std::make_shared`：

```cpp
// 推荐使用 make_* 函数，而不是直接 new
auto p1 = std::make_unique<int>(42);
auto p2 = std::make_shared<int>(42);
```

**优点**：
1. **异常安全**：避免 `new` 和智能指针构造之间的异常泄漏
2. **更高效**（`make_shared`）：内存分配和引用计数放在一起，减少一次分配
3. **代码简洁**：不需要写 `new` 和类型名

## std::enable_shared_from_this

当需要从一个类内部返回指向 `this` 的 `shared_ptr` 时使用：

```cpp
class MyClass : public std::enable_shared_from_this<MyClass> {
public:
    std::shared_ptr<MyClass> getShared() {
        return shared_from_this();
    }
};
```

**注意**：必须在对象已经被 `shared_ptr` 管理时才能调用 `shared_from_this()`。

## 如何选择？

| 场景 | 使用 |
|------|------|
| 独占对象 | `unique_ptr` |
| 多个所有者共享 | `shared_ptr` |
| 观察者，不控制生命周期 | `weak_ptr` |
| 需要打破循环引用 | `weak_ptr` |
| 创建智能指针 | `make_unique` / `make_shared` |
| 类内部获取自己的 shared_ptr | `enable_shared_from_this` |

## 最佳实践

1. **优先使用 `unique_ptr`**：默认情况下使用独占所有权，效率最高
2. **只在需要共享时使用 `shared_ptr`**：引用计数有开销
3. **使用 `make_*` 函数创建智能指针**：异常安全且高效
4. **避免循环引用**：使用 `weak_ptr` 打破循环
5. **不要混用原始指针和智能指针**：容易导致误 delete
6. **不要使用 `auto_ptr`**：C++17 已弃用，用 `unique_ptr` 替代
