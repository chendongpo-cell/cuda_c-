#include <iostream>     // 包含输入输出流头文件，用于 std::cout
#include <memory>       // 包含智能指针头文件，用于 std::unique_ptr, std::shared_ptr, std::weak_ptr
#include <string>       // 包含字符串头文件，用于 std::string
#include <vector>       // 包含 vector 容器头文件

// ========== 辅助类：用于演示构造函数和析构函数 ==========

/**
 * 一个简单的辅助类
 * 在构造和析构时输出信息，帮助我们观察智能指针的生命周期管理
 */
class Resource {
private:
    // 资源的名称
    std::string name;

public:
    // 构造函数：接受一个名称参数
    explicit Resource(const std::string& n) : name(n) {
        // 输出构造信息，显示哪个资源被创建了
        std::cout << "  [构造] Resource(" << name << ") 被创建" << std::endl;
    }

    // 析构函数：当对象被销毁时自动调用
    ~Resource() {
        // 输出析构信息，显示哪个资源被销毁了
        std::cout << "  [析构] Resource(" << name << ") 被销毁" << std::endl;
    }

    // 显示资源信息
    void show() const {
        // 输出资源的名称
        std::cout << "  Resource: " << name << std::endl;
    }

    // 获取资源名称
    std::string getName() const {
        // 返回资源的名称
        return name;
    }
};

// ========== 演示循环引用的辅助结构 ==========

// 前置声明 Node 结构体
struct Node;

/**
 * 带 shared_ptr 的节点（会导致循环引用问题）
 */
struct SharedNode {
    // 节点名称
    std::string name;
    // 使用 shared_ptr 指向下一个节点
    // 这可能导致循环引用，内存无法释放！
    std::shared_ptr<SharedNode> next;

    // 构造函数
    explicit SharedNode(const std::string& n) : name(n) {
        std::cout << "  [构造] SharedNode(" << name << ")" << std::endl;
    }

    // 析构函数
    ~SharedNode() {
        std::cout << "  [析构] SharedNode(" << name << ")" << std::endl;
    }
};

/**
 * 带 weak_ptr 的节点（避免循环引用问题）
 */
struct WeakNode {
    // 节点名称
    std::string name;
    // 使用 weak_ptr 指向下一个节点
    // weak_ptr 不增加引用计数，不会导致循环引用
    std::weak_ptr<WeakNode> next;

    // 构造函数
    explicit WeakNode(const std::string& n) : name(n) {
        std::cout << "  [构造] WeakNode(" << name << ")" << std::endl;
    }

    // 析构函数
    ~WeakNode() {
        std::cout << "  [析构] WeakNode(" << name << ")" << std::endl;
    }

    // 显示节点信息
    void show() const {
        std::cout << "  Node: " << name;
        // 尝试访问下一个节点
        // lock() 返回一个 shared_ptr，如果指向的对象还存在
        if (auto sp = next.lock()) {
            // 下一个节点存在
            std::cout << " -> " << sp->name;
        } else {
            // 下一个节点已被释放
            std::cout << " -> (null)";
        }
        std::cout << std::endl;
    }
};

int main() {
    std::cout << "===== 智能指针演示 =====\n" << std::endl;

    // ========== 1. unique_ptr（独占所有权） ==========

    std::cout << "===== 1. unique_ptr 演示 =====" << std::endl;

    // 1.1 创建 unique_ptr
    // 使用 std::make_unique 创建（C++14 引入）
    // make_unique 在堆上分配一个 Resource 对象并返回 unique_ptr
    std::cout << "创建 unique_ptr<Resource>:" << std::endl;
    auto uPtr1 = std::make_unique<Resource>("First");

    // 使用 -> 运算符访问成员函数
    uPtr1->show();

    // 使用 * 运算符解引用，获取原始对象
    (*uPtr1).show();

    // 1.2 unique_ptr 不能被拷贝
    // 下面这行代码会编译错误（取消注释可以看到）：
    // auto uPtr2 = uPtr1;  // 错误！unique_ptr 不能拷贝

    // 1.3 unique_ptr 可以移动所有权
    // 使用 std::move 将所有权从 uPtr1 转移到 uPtr2
    std::cout << "移动所有权:" << std::endl;
    std::unique_ptr<Resource> uPtr2 = std::move(uPtr1);

    // 移动后 uPtr1 变为空（nullptr）
    if (uPtr1) {
        // uPtr1 不为空时执行的代码
        std::cout << "  uPtr1 不为空" << std::endl;
    } else {
        // uPtr1 为空，因为所有权已经转移了
        std::cout << "  移动后 uPtr1 为空" << std::endl;
    }

    // uPtr2 持有对象
    uPtr2->show();

    // 1.4 获取原始指针（不涉及所有权转移）
    // get() 返回原始指针，但 unique_ptr 仍然拥有所有权
    // 注意：不要 delete 这个原始指针！
    Resource* rawPtr = uPtr2.get();
    std::cout << "原始指针地址: " << rawPtr << std::endl;

    // 1.5 释放所有权
    // release() 释放所有权，返回原始指针
    // unique_ptr 变为空，调用者需要手动管理返回的原始指针
    Resource* releasedPtr = uPtr2.release();
    std::cout << "release 后 uPtr2 为空: " << (uPtr2 ? "否" : "是") << std::endl;

    // 使用 releasedPtr 访问对象
    std::cout << "释放后的指针仍指向: ";
    releasedPtr->show();

    // 必须手动 delete，否则内存泄漏！
    delete releasedPtr;

    // 1.6 reset：重置 unique_ptr
    std::cout << "使用 reset:" << std::endl;
    auto uPtr3 = std::make_unique<Resource>("Temp");
    uPtr3->show();
    // reset 会删除当前管理的对象，并可选地接管新对象
    uPtr3.reset(new Resource("Replacement"));
    // 此时 "Temp" 已经被销毁
    uPtr3->show();
    // 不传参数 reset 会删除对象并使指针为空
    uPtr3.reset();
    std::cout << "reset 后 uPtr3 为空: " << (uPtr3 ? "否" : "是") << std::endl;

    // 1.7 unique_ptr 离开作用域时自动释放
    std::cout << "创建一个临时对象（会在作用域结束时自动释放）:" << std::endl;
    {
        // 进入内部作用域
        auto tempPtr = std::make_unique<Resource>("ScopeTest");
        tempPtr->show();
        // 内部作用域结束时，tempPtr 自动析构，释放 Resource
        std::cout << "  离开内部作用域..." << std::endl;
    }
    std::cout << "  已经离开内部作用域, Resource 已被自动释放" << std::endl;

    std::cout << std::endl;

    // ========== 2. shared_ptr（共享所有权） ==========

    std::cout << "===== 2. shared_ptr 演示 =====" << std::endl;

    // 2.1 创建 shared_ptr
    // 使用 std::make_shared 创建（更高效）
    std::cout << "创建 shared_ptr:" << std::endl;
    auto sPtr1 = std::make_shared<Resource>("Shared1");

    // 访问对象
    sPtr1->show();

    // 2.2 shared_ptr 可以拷贝
    // 拷贝会增加引用计数
    std::cout << "拷贝 shared_ptr:" << std::endl;
    auto sPtr2 = sPtr1;     // 引用计数从 1 变为 2
    auto sPtr3 = sPtr2;     // 引用计数从 2 变为 3

    // 2.3 查看引用计数
    // use_count() 返回当前 shared_ptr 的数量
    std::cout << "sPtr1 的引用计数: " << sPtr1.use_count() << std::endl;
    std::cout << "sPtr2 的引用计数: " << sPtr2.use_count() << std::endl;

    // 2.4 释放一个 shared_ptr 的所有权
    // reset 会减少引用计数
    std::cout << "sPtr3.reset() 释放所有权:" << std::endl;
    sPtr3.reset();          // 引用计数从 3 变为 2
    std::cout << "sPtr1 的引用计数: " << sPtr1.use_count() << std::endl;

    // 2.5 创建新的 shared_ptr（独立对象）
    std::cout << "创建另一个独立对象:" << std::endl;
    auto sPtr4 = std::make_shared<Resource>("Shared2");

    // 2.6 用 vector 存储 shared_ptr
    std::cout << "shared_ptr 放入 vector:" << std::endl;
    std::vector<std::shared_ptr<Resource>> resourceVec;

    // 将 sPtr1 和 sPtr4 添加到 vector
    // 这会增加引用计数
    resourceVec.push_back(sPtr1);   // sPtr1 的引用计数变为 3
    resourceVec.push_back(sPtr4);   // sPtr4 的引用计数变为 2

    std::cout << "  sPtr1 引用计数: " << sPtr1.use_count() << std::endl;
    std::cout << "  sPtr4 引用计数: " << sPtr4.use_count() << std::endl;

    // 清空 vector 会减少引用计数
    std::cout << "清空 vector:" << std::endl;
    resourceVec.clear();
    std::cout << "  sPtr1 引用计数: " << sPtr1.use_count() << std::endl;  // 应为 2
    std::cout << "  sPtr4 引用计数: " << sPtr4.use_count() << std::endl;  // 应为 1

    // 2.7 shared_ptr 离开作用域时自动释放
    std::cout << "sPtr1 和 sPtr2 会在此处结束后释放 Shared1" << std::endl;

    std::cout << std::endl;

    // ========== 3. weak_ptr（弱引用、打破循环引用） ==========

    std::cout << "===== 3. weak_ptr 演示 =====" << std::endl;

    // 3.1 创建 weak_ptr
    std::cout << "创建 weak_ptr:" << std::endl;
    auto sharedRes = std::make_shared<Resource>("WeakDemo");
    // weak_ptr 从 shared_ptr 创建
    // weak_ptr 不会增加引用计数！
    std::weak_ptr<Resource> weakRes = sharedRes;

    std::cout << "  sharedRes 引用计数: " << sharedRes.use_count() << std::endl;  // 仍为 1
    std::cout << "  weakRes 的 use_count: " << weakRes.use_count() << std::endl;  // 显示 1（但弱引用不影响）

    // 3.2 通过 lock() 访问 weak_ptr 指向的对象
    // lock() 返回一个 shared_ptr
    // 如果对象还存在，返回有效的 shared_ptr
    // 如果对象已被释放，返回空的 shared_ptr
    std::cout << "通过 lock() 访问:" << std::endl;
    if (auto locked = weakRes.lock()) {
        // lock() 成功，可以安全访问对象
        std::cout << "  lock 成功, ";
        locked->show();
        std::cout << "  临时 shared_ptr 的引用计数: " << locked.use_count() << std::endl;
    } else {
        // 对象已被释放
        std::cout << "  对象已被释放" << std::endl;
    }

    // 3.3 检查 weak_ptr 是否已过期
    // expired() 检查管理的对象是否已被释放
    std::cout << "weakRes 已过期? " << (weakRes.expired() ? "是" : "否") << std::endl;

    // 3.4 当 shared_ptr 释放对象后，weak_ptr 自动变为空
    std::cout << "释放 sharedRes:" << std::endl;
    sharedRes.reset();      // 释放对象
    std::cout << "  weakRes 已过期? " << (weakRes.expired() ? "是" : "否") << std::endl;

    // 此时 lock() 返回空
    if (auto locked = weakRes.lock()) {
        // 对象已释放，不会执行到这里
        std::cout << "  lock 成功" << std::endl;
    } else {
        // 对象已释放，lock 返回空
        std::cout << "  lock 失败，对象已释放" << std::endl;
    }

    std::cout << std::endl;

    // ========== 4. 循环引用演示 ==========

    std::cout << "===== 4. 循环引用演示 =====" << std::endl;

    // 4.1 使用 shared_ptr 导致循环引用（内存泄漏！）
    std::cout << "shared_ptr 循环引用（会导致内存泄漏）:" << std::endl;
    {
        // 进入内部作用域
        auto nodeA = std::make_shared<SharedNode>("A");
        auto nodeB = std::make_shared<SharedNode>("B");

        // 形成循环引用：A 指向 B，B 指向 A
        nodeA->next = nodeB;    // B 的引用计数从 1 变为 2
        nodeB->next = nodeA;    // A 的引用计数从 1 变为 2

        // 输出引用计数
        std::cout << "  nodeA 引用计数: " << nodeA.use_count() << std::endl;  // 2
        std::cout << "  nodeB 引用计数: " << nodeB.use_count() << std::endl;  // 2

        std::cout << "  离开作用域..." << std::endl;
        // nodeA 和 nodeB 离开作用域时
        // 各自的引用计数减 1，变为 1
        // 但因为还有循环引用，引用计数不为 0
        // 所以对象不会被释放！内存泄漏！
    }
    std::cout << "  已离开作用域，但 SharedNode A 和 B 没有被析构（内存泄漏！）" << std::endl;

    std::cout << std::endl;

    // 4.2 使用 weak_ptr 打破循环引用（正确做法）
    std::cout << "weak_ptr 打破循环引用（正确做法）:" << std::endl;
    {
        // 进入内部作用域
        auto nodeC = std::make_shared<WeakNode>("C");
        auto nodeD = std::make_shared<WeakNode>("D");

        // 使用 weak_ptr 建立引用
        // weak_ptr 不增加引用计数！
        nodeC->next = nodeD;    // D 的引用计数不变（仍是 1）
        nodeD->next = nodeC;    // C 的引用计数不变（仍是 1）

        // 输出引用计数
        std::cout << "  nodeC 引用计数: " << nodeC.use_count() << std::endl;  // 1
        std::cout << "  nodeD 引用计数: " << nodeD.use_count() << std::endl;  // 1

        // 通过 weak_ptr 访问下一个节点
        std::cout << "  通过 weak_ptr 访问:" << std::endl;
        nodeC->show();
        nodeD->show();

        std::cout << "  离开作用域..." << std::endl;
        // nodeC 和 nodeD 离开作用域时
        // 引用计数从 1 减为 0
        // 对象被自动释放！
    }
    std::cout << "  已离开作用域，WeakNode C 和 D 都被正确析构！" << std::endl;

    std::cout << std::endl;

    // ========== 5. enable_shared_from_this ==========

    std::cout << "===== 5. enable_shared_from_this 演示 =====" << std::endl;

    /**
     * 演示类：继承 enable_shared_from_this
     * 当需要在类内部返回指向自己的 shared_ptr 时使用
     */
    struct SelfShared : public std::enable_shared_from_this<SelfShared> {
        // 数据
        int value;

        // 构造函数
        explicit SelfShared(int v) : value(v) {
            std::cout << "  [构造] SelfShared(" << value << ")" << std::endl;
        }

        // 析构函数
        ~SelfShared() {
            std::cout << "  [析构] SelfShared(" << value << ")" << std::endl;
        }

        // 返回指向自身的 shared_ptr
        // 注意：必须保证对象已经被 shared_ptr 管理
        std::shared_ptr<SelfShared> getShared() {
            // shared_from_this() 返回当前对象的 shared_ptr
            // 不会重新创建，而是共享已有的引用计数
            return shared_from_this();
        }

        // 获取当前引用计数
        int getRefCount() {
            // use_count() 是 shared_ptr 的成员函数
            // 这里通过 shared_from_this() 获取 shared_ptr 后再调用 use_count
            return shared_from_this().use_count();
        }
    };

    // 创建 SelfShared 对象，必须使用 shared_ptr 管理
    auto selfObj = std::make_shared<SelfShared>(42);

    // 在类外部获取 shared_ptr
    std::cout << "  selfObj 引用计数: " << selfObj.use_count() << std::endl;  // 1

    // 通过成员函数获取 shared_ptr
    auto sameObj = selfObj->getShared();
    std::cout << "  调用 getShared 后引用计数: " << selfObj.use_count() << std::endl;  // 2

    // 验证是同一个对象
    std::cout << "  selfObj.get() == sameObj.get()? "
              << (selfObj.get() == sameObj.get() ? "是" : "否") << std::endl;

    std::cout << std::endl;

    // ========== 6. 类型转换与自定义删除器 ==========

    std::cout << "===== 6. 类型转换与自定义删除器 =====" << std::endl;

    // 6.1 智能指针之间的类型转换
    // shared_ptr 支持 dynamic_pointer_cast, static_pointer_cast 等

    // 6.2 自定义删除器
    // 有时候需要在释放资源时执行特殊操作
    std::cout << "自定义删除器:" << std::endl;
    {
        // 创建一个 unique_ptr 并指定自定义删除器
        // 删除器是一个 lambda，在释放资源时调用
        auto customDeleter = [](Resource* p) {
            // 在删除 Resource 之前输出一条消息
            std::cout << "  [自定义删除器] 正在删除 Resource(" << p->getName() << ")..." << std::endl;
            // 执行实际的删除操作
            delete p;
            std::cout << "  [自定义删除器] 删除完成" << std::endl;
        };

        // 创建 unique_ptr 时传入自定义删除器
        // 注意：自定义删除器是 unique_ptr 类型的一部分
        std::unique_ptr<Resource, decltype(customDeleter)> customPtr(
            new Resource("CustomDel"), customDeleter
        );
        customPtr->show();
        // 离开作用域时会调用 customDeleter 来释放资源
        std::cout << "  离开作用域..." << std::endl;
    }
    std::cout << "  已离开作用域" << std::endl;

    std::cout << std::endl;

    // ========== 结束 ==========

    std::cout << "===== 智能指针演示结束 =====" << std::endl;

    // main 函数返回 0 表示程序正常结束
    return 0;
}
