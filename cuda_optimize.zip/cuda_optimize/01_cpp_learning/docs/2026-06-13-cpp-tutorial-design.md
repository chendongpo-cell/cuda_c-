# C++ 从入门到常用框架 — 完整学习教程设计

## 概述

本教程是 C++ 零基础学习者的完整学习路径，覆盖从基础语法到常用框架的全部知识点。共 **35 个知识点**，每个知识点独立文件夹，包含 Markdown 知识介绍和带逐行详细注释的 C++ 示例代码。

## 目标

- 零基础可学，每行代码都有详细中文注释
- 每个知识点独立，可跳跃学习，但推荐按编号顺序
- 使用 VS Code 直接在目录树中浏览
- 知识点编号从 01 到 35，按阶段分组

## 目录结构

```
d:\Desktop\fox_projects\c++_projects\
├── README.md                    # 总索引页
├── STAGE1_基础语法.md            # 第一阶段概览
├── STAGE2_面向对象.md            # 第二阶段概览
├── STAGE3_进阶特性.md            # 第三阶段概览
├── STAGE4_现代C++.md            # 第四阶段概览
├── STAGE5_工程实践.md            # 第五阶段概览
│
├── 01_HelloWorld/
│   ├── README.md                # 知识点介绍
│   └── main.cpp                 # 带逐行注释的示例代码
│
├── 02_变量与数据类型/
│   ├── README.md
│   └── main.cpp
│
├── 03_运算符与表达式/
│   ├── README.md
│   └── main.cpp
│
├── 04_输入输出流/
│   ├── README.md
│   └── main.cpp
│
├── 05_流程控制_条件分支/
│   ├── README.md
│   └── main.cpp
│
├── 06_流程控制_循环/
│   ├── README.md
│   └── main.cpp
│
├── 07_数组与字符串/
│   ├── README.md
│   └── main.cpp
│
├── 08_函数基础/
│   ├── README.md
│   └── main.cpp
│
├── 09_指针入门/
│   ├── README.md
│   └── main.cpp
│
├── 10_动态内存管理/
│   ├── README.md
│   └── main.cpp
│
├── 11_类与对象/
│   ├── README.md
│   └── main.cpp
│
├── 12_构造函数与析构函数/
│   ├── README.md
│   └── main.cpp
│
├── 13_封装与友元/
│   ├── README.md
│   └── main.cpp
│
├── 14_继承/
│   ├── README.md
│   └── main.cpp
│
├── 15_多态与虚函数/
│   ├── README.md
│   └── main.cpp
│
├── 16_运算符重载/
│   ├── README.md
│   └── main.cpp
│
├── 17_类型转换/
│   ├── README.md
│   └── main.cpp
│
├── 18_异常处理/
│   ├── README.md
│   └── main.cpp
│
├── 19_模板基础/
│   ├── README.md
│   └── main.cpp
│
├── 20_STL容器/
│   ├── README.md
│   └── main.cpp
│
├── 21_STL迭代器与算法/
│   ├── README.md
│   └── main.cpp
│
├── 22_函数对象与Lambda/
│   ├── README.md
│   └── main.cpp
│
├── 23_智能指针/
│   ├── README.md
│   └── main.cpp
│
├── 24_文件操作/
│   ├── README.md
│   └── main.cpp
│
├── 25_命名空间与模块/
│   ├── README.md
│   └── main.cpp
│
├── 26_预处理与宏/
│   ├── README.md
│   └── main.cpp
│
├── 27_多线程基础/
│   ├── README.md
│   └── main.cpp
│
├── 28_C++11_14新特性/
│   ├── README.md
│   └── main.cpp
│
├── 29_C++17_20新特性/
│   ├── README.md
│   └── main.cpp
│
├── 30_右值与移动语义/
│   ├── README.md
│   └── main.cpp
│
├── 31_设计模式/
│   ├── README.md
│   └── main.cpp
│
├── 32_单元测试/
│   ├── README.md
│   └── main.cpp
│
├── 33_CMake构建系统/
│   ├── README.md
│   ├── main.cpp
│   └── CMakeLists.txt
│
├── 34_Qt框架入门/
│   ├── README.md
│   └── main.cpp
│
├── 35_Boost库入门/
│   ├── README.md
│   └── main.cpp
```

## 每个知识点的文件规范

### README.md 格式

```markdown
# 知识点名称

## 1. 什么是 [知识点]

基础知识介绍...

## 2. 核心概念

### 2.1 概念一
说明...

### 2.2 概念二
说明...

## 3. 代码示例说明

示例代码演示了什么...

## 4. 注意事项

- 注意点1
- 注意点2

## 5. 练习建议

- 练习1
- 练习2
```

### main.cpp 格式

- 使用 `//` 单行注释，每行关键代码上方都有注释
- 注释解释"为什么这样做"而非"做了什么"
- 代码中包含多个小示例，用注释分隔
- 代码可直接编译运行

## 前端浏览方式

使用 VS Code 直接打开根目录，左侧目录树按编号排序显示所有知识点。根目录的 `README.md` 作为总入口，各阶段有独立的概览 Markdown 文件。

## 实现顺序

1. 第一阶段（01-10）：基础语法
2. 第二阶段（11-18）：面向对象
3. 第三阶段（19-27）：进阶特性
4. 第四阶段（28-32）：现代 C++
5. 第五阶段（33-35）：工程实践与框架
6. 根目录 README.md 和各阶段概览文件
