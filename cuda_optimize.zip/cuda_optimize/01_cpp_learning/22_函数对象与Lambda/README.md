# 22 - 函数对象与Lambda (Functors & Lambdas)

## 函数对象 (Functor)

**函数对象（Function Object，又称 Functor）** 是指重载了 `operator()` 的类或结构体的实例。这种对象可以像函数一样被调用。

### 为什么需要函数对象？

1. **可以保存状态**：普通函数不能保存状态，而函数对象可以拥有成员变量
2. **可以被内联优化**：函数对象通常比函数指针有更好的性能
3. **可以包含类型信息**：不同的函数对象是不同的类型，便于模板编程
4. **可以组合和定制**：更灵活的行为定制

**基本示例：**
```cpp
class Adder {
private:
    int base;  // 保存状态
public:
    Adder(int b) : base(b) {}
    int operator()(int x) const {
        return base + x;
    }
};

Adder add5(5);
int result = add5(10);  // 结果 = 15
```

### 函数对象 vs 函数指针

```cpp
// 函数指针
bool compare(int a, int b) { return a < b; }
std::sort(v.begin(), v.end(), compare);

// 函数对象
struct Less {
    bool operator()(int a, int b) { return a < b; }
};
std::sort(v.begin(), v.end(), Less());

// Lambda 表达式（C++11）
std::sort(v.begin(), v.end(), [](int a, int b) { return a < b; });
```

## Lambda 表达式

**Lambda 表达式** 是 C++11 引入的一种创建**匿名函数对象**的便捷方式。它可以在需要函数对象的地方直接定义一个临时的、可调用的对象。

### 基本语法

```cpp
[capture](parameters) -> return_type { body }
```

| 部分 | 说明 | 是否必须 |
|------|------|---------|
| `[capture]` | 捕获列表，指定如何访问外部变量 | **必须** |
| `(parameters)` | 参数列表 | 可选（可省略） |
| `-> return_type` | 返回类型 | 可选（可自动推导） |
| `{ body }` | 函数体 | **必须** |

每个部分都可以简化：
- 无参数时 `(parameters)` 可以省略：`[]{ return 42; }`
- 返回类型可自动推导：`[](int x){ return x * 2; }`

### 捕获列表 (Capture Clause)

捕获列表定义了 lambda 如何访问其**所在作用域**的变量：

| 捕获方式 | 语法 | 说明 |
|---------|------|------|
| 按值捕获 | `[x]` | 捕获 x 的副本，lambda 内部不能修改（除非 mutable） |
| 按引用捕获 | `[&x]` | 捕获 x 的引用，可以修改 x |
| 全部按值 | `[=]` | 所有变量按值捕获 |
| 全部按引用 | `[&]` | 所有变量按引用捕获 |
| 混合捕获 | `[=, &x]` | x 按引用捕获，其他按值 |
| 混合捕获 | `[&, x]` | x 按值捕获，其他按引用 |
| 捕获 this | `[this]` | 捕获当前对象的指针（访问成员变量） |
| C++17 复制 *this | `[*this]` | 捕获当前对象的副本 |

### mutable 修饰符

默认情况下，按值捕获的变量在 lambda 内部是 **const** 的，不能修改。添加 `mutable` 关键字后可以修改副本（但不会影响原始变量）：

```cpp
int count = 0;
auto lambda = [count]() mutable {
    count++;  // OK，修改的是副本
};
```

### 泛型 Lambda (Generic Lambda)

C++14 引入，参数可以使用 `auto` 类型推导：

```cpp
auto generic = [](auto a, auto b) {
    return a + b;
};

int r1 = generic(1, 2);       // int + int
double r2 = generic(1.5, 2.5); // double + double
std::string r3 = generic(std::string("a"), std::string("b")); // 字符串拼接
```

## std::function (函数包装器)

`std::function` 是 C++11 引入的通用多态函数包装器，可以存储、复制和调用任何可调用对象（函数、函数对象、lambda）。

```cpp
#include <functional>

std::function<int(int, int)> func;

func = [](int a, int b) { return a + b; };  // 存储 lambda
func = myFunction;                           // 存储函数指针
func = MyFunctor();                          // 存储函数对象

int result = func(1, 2);  // 调用
```

## Lambda 的本质

Lambda 本质上是一个**编译器自动生成的匿名函数对象**：

```cpp
// 这个 lambda:
auto lambda = [x](int y) { return x + y; };

// 编译器会生成类似这样的代码:
class __AnonymousLambda {
private:
    int x;  // 捕获的变量成为成员变量
public:
    __AnonymousLambda(int x_) : x(x_) {}
    auto operator()(int y) const {
        return x + y;
    }
};
auto lambda = __AnonymousLambda(x);
```

## 何时使用何种方式？

| 场景 | 推荐方式 |
|------|---------|
| 简单的回调函数 | Lambda |
| 需要保存状态的比较器 | 函数对象 |
| 需要类型擦除 | std::function |
| 算法中自定义操作 | Lambda |
| 需要在多处复用的逻辑 | 函数对象或普通函数 |
