#include <iostream>     // 包含输入输出流头文件，用于 std::cout
#include <vector>       // 包含 vector 容器头文件
#include <algorithm>    // 包含 STL 算法头文件，用于 sort, for_each 等
#include <functional>   // 包含 std::function 头文件，用于函数包装器
#include <string>       // 包含字符串头文件，用于 std::string

// ========== 1. 函数对象（Functor）演示 ==========

/**
 * 函数对象类：用于比较大小
 * 重载了 operator()，使对象可以像函数一样被调用
 */
class Comparator {
private:
    // 私有成员变量，记录比较模式
    // true = 升序，false = 降序
    bool ascending;

public:
    // 构造函数，接受一个 bool 参数指定排序方向
    // 默认参数为 true，即默认升序
    explicit Comparator(bool asc = true) : ascending(asc) {
        // 初始化列表将参数 asc 赋给成员 ascending
    }

    // 重载 operator()，使对象可以像函数一样被调用
    // 接受两个 int 参数，返回 bool 值
    // const 修饰符表示这个调用操作不会修改对象的状态
    bool operator()(int a, int b) const {
        // 如果 ascending 为 true，返回 a < b（升序）
        // 如果 ascending 为 false，返回 a > b（降序）
        if (ascending) {
            // 升序比较
            return a < b;
        } else {
            // 降序比较
            return a > b;
        }
    }

    // 设置排序方向
    void setAscending(bool asc) {
        // 修改 ascending 成员变量的值
        ascending = asc;
    }

    // 获取当前的排序方向
    bool isAscending() const {
        // 返回 ascending 成员变量的值
        return ascending;
    }
};

/**
 * 函数对象类：累加器（演示函数对象保持状态的能力）
 * 每次调用都会累加传入的值
 */
class Accumulator {
private:
    // 私有成员变量，保存累加的结果
    int total;

public:
    // 构造函数，初始化 total 为 0
    Accumulator() : total(0) {
        // 初始化列表将 total 设置为 0
    }

    // 重载 operator()：累加值到 total，并返回累加后的结果
    // 注意：这个函数不是 const 的，因为会修改成员变量 total
    int operator()(int value) {
        // 将传入的 value 累加到 total
        total += value;
        // 返回累加后的结果
        return total;
    }

    // 获取当前的累加值
    int getTotal() const {
        // 返回当前的 total 值
        return total;
    }
};

/**
 * 函数对象类：检查是否在指定范围内
 * 演示带有状态和条件判断的函数对象
 */
class InRange {
private:
    // 范围的下限
    int low;
    // 范围的上限
    int high;

public:
    // 构造函数，设置范围的下限和上限
    InRange(int l, int h) : low(l), high(h) {
        // 初始化列表设置 low 和 high
    }

    // 重载 operator()：检查 value 是否在 [low, high] 范围内
    bool operator()(int value) const {
        // 如果 value >= low 且 value <= high，返回 true
        return value >= low && value <= high;
    }
};

// ========== 2. Lambda 表达式演示 ==========

// 普通辅助函数，用于演示 std::function 可以存储普通函数
void sayHello(const std::string& name) {
    // 输出问候语
    std::cout << "Hello, " << name << "!" << std::endl;
}

int main() {
    // ========== 1. 函数对象（Functor）演示 ==========

    // 输出标题
    std::cout << "===== 1. 函数对象（Functor）演示 =====" << std::endl;

    // 1.1 使用函数对象作为排序比较器

    // 创建一个包含随机数字的 vector
    std::vector<int> numbers = {5, 2, 8, 1, 9, 3, 7, 4, 6};

    // 创建一个升序比较器对象
    // Comparator 对象重载了 operator()，可以像函数一样使用
    Comparator ascComp(true);       // ascComp 是一个升序比较器

    // 使用 std::sort 算法排序
    // 第三个参数传入函数对象 ascComp
    std::sort(numbers.begin(), numbers.end(), ascComp);
    // 输出升序排序结果
    std::cout << "升序排序（通过函数对象）: ";
    for (const auto& val : numbers) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 创建一个降序比较器对象
    Comparator descComp(false);     // descComp 是一个降序比较器
    std::sort(numbers.begin(), numbers.end(), descComp);
    std::cout << "降序排序（通过函数对象）: ";
    for (const auto& val : numbers) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 1.2 使用带有状态的函数对象

    // 创建累加器对象
    Accumulator acc;

    // 多次调用累加器，每次传入一个值
    // 累加器内部会维护 total 状态
    std::cout << "累加器演示:" << std::endl;
    std::cout << "  acc(10) = " << acc(10) << std::endl;     // total 变为 10
    std::cout << "  acc(20) = " << acc(20) << std::endl;     // total 变为 30
    std::cout << "  acc(30) = " << acc(30) << std::endl;     // total 变为 60
    std::cout << "  最终 total = " << acc.getTotal() << std::endl;  // 输出 60

    // 1.3 使用函数对象配合 count_if

    // 恢复原始序列
    numbers = {5, 2, 8, 1, 9, 3, 7, 4, 6};

    // 创建一个 InRange 对象，检查值是否在 [3, 7] 范围内
    InRange rangeChecker(3, 7);

    // 使用 std::count_if 统计范围内满足条件的元素个数
    int countInRange = static_cast<int>(
        std::count_if(numbers.begin(), numbers.end(), rangeChecker)
    );
    std::cout << "在 [3, 7] 范围内的元素个数: " << countInRange << std::endl;

    // 1.4 函数对象作为模板参数

    // 直接创建临时函数对象作为 sort 的比较器
    // Comparator() 创建临时对象（默认升序）
    std::sort(numbers.begin(), numbers.end(), Comparator());
    std::cout << "临时函数对象排序: ";
    for (const auto& val : numbers) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    std::cout << std::endl;

    // ========== 2. Lambda 表达式演示 ==========

    // 输出标题
    std::cout << "===== 2. Lambda 表达式演示 =====" << std::endl;

    // 2.1 基本 Lambda

    // 最简单的 lambda：不接受参数，不捕获变量，直接返回一个值
    // [] 是捕获列表（空表示不捕获任何外部变量）
    // {} 中是函数体
    auto simpleLambda = [] {
        // lambda 的函数体
        std::cout << "这是最简单的 lambda!" << std::endl;
    };
    // 调用 lambda
    simpleLambda();

    // 带参数的 lambda
    // (int a, int b) 是参数列表
    // -> int 是返回类型（此处可以省略，因为编译器能自动推导）
    auto addLambda = [](int a, int b) -> int {
        // 返回 a 和 b 的和
        return a + b;
    };
    // 调用 lambda 并输出结果
    std::cout << "addLambda(3, 4) = " << addLambda(3, 4) << std::endl;

    // 省略返回类型（自动推导）
    auto multiplyLambda = [](int a, int b) {
        // 返回 a 和 b 的乘积
        // 编译器自动推导返回类型为 int
        return a * b;
    };
    std::cout << "multiplyLambda(5, 6) = " << multiplyLambda(5, 6) << std::endl;

    std::cout << std::endl;

    // 2.2 捕获外部变量

    // 按值捕获 [=]
    int base = 100;
    int offset = 50;

    // [=] 表示按值捕获所有外部变量
    // lambda 内部会创建 base 和 offset 的副本
    auto captureByValue = [=] {
        // 使用 base 和 offset 的副本
        // 注意：不能修改这些副本的值（除非加 mutable）
        return base + offset;
    };
    std::cout << "按值捕获: base + offset = " << captureByValue() << std::endl;

    // 按引用捕获 [&]
    // [&] 表示按引用捕获所有外部变量
    // lambda 内部操作的是原始变量
    auto captureByRef = [&] {
        // 通过引用修改外部变量
        // 这会改变 base 和 offset 的原始值
        base += 10;
        offset += 5;
        return base + offset;
    };
    std::cout << "按引用捕获前: base = " << base << ", offset = " << offset << std::endl;
    std::cout << "按引用捕获结果: " << captureByRef() << std::endl;
    std::cout << "按引用捕获后: base = " << base << ", offset = " << offset << std::endl;

    // 混合捕获：特定变量按值，其他按引用
    int a = 10;
    int b = 20;
    int c = 30;

    // [=, &c] 表示 c 按引用捕获，其他变量按值捕获
    auto mixedCapture = [=, &c] {
        // c 是按引用捕获的，可以修改
        c = 100;
        // a 和 b 是按值捕获的，不能修改（除非 mutable）
        // a = 50;  // 这行会编译错误
        return a + b + c;
    };
    std::cout << "混合捕获结果: " << mixedCapture() << std::endl;
    std::cout << "混合捕获后 c = " << c << std::endl;

    // mutable 关键字：允许修改按值捕获的副本
    int counter = 0;
    auto mutableLambda = [counter]() mutable {
        // 即使 counter 是按值捕获的，mutable 允许修改副本
        ++counter;
        return counter;
    };
    std::cout << "mutable lambda 第一次调用: " << mutableLambda() << std::endl;  // 输出 1
    std::cout << "mutable lambda 第二次调用: " << mutableLambda() << std::endl;  // 输出 2
    std::cout << "原始 counter 值不变: " << counter << std::endl;               // 输出 0

    std::cout << std::endl;

    // 2.3 Lambda 与 STL 算法结合

    // 恢复原始序列
    std::vector<int> vec = {5, 2, 8, 1, 9, 3, 7, 4, 6};

    // 使用 lambda 作为 std::sort 的比较器
    // 直接定义 lambda 参数，不需要创建单独的函数或函数对象
    std::sort(vec.begin(), vec.end(),
        // 这是一个匿名 lambda 作为比较器
        [](int x, int y) {
            // 降序排列
            return x > y;
        }
    );
    std::cout << "lambda 降序排序: ";
    for (const auto& val : vec) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 使用 lambda 作为 std::for_each 的操作
    std::cout << "lambda for_each 输出: ";
    std::for_each(vec.begin(), vec.end(),
        // lambda 输出每个元素
        [](int val) {
            std::cout << val << " ";
        }
    );
    std::cout << std::endl;

    // 使用 lambda 配合 std::find_if 查找第一个偶数
    // find_if 查找第一个满足条件的元素
    auto evenIt = std::find_if(vec.begin(), vec.end(),
        // lambda 判断是否是偶数
        [](int val) {
            // 如果 val 能被 2 整除，返回 true
            return val % 2 == 0;
        }
    );
    if (evenIt != vec.end()) {
        // 找到了第一个偶数
        std::cout << "第一个偶数是: " << *evenIt << std::endl;
    }

    // 使用 lambda 配合捕获进行条件统计
    int threshold = 5;
    int countAbove = static_cast<int>(
        std::count_if(vec.begin(), vec.end(),
            // lambda 捕获 threshold，判断是否大于阈值
            [threshold](int val) {
                // 如果 val 大于 threshold，返回 true
                return val > threshold;
            }
        )
    );
    std::cout << "大于 " << threshold << " 的元素个数: " << countAbove << std::endl;

    std::cout << std::endl;

    // 2.4 泛型 Lambda（C++14）

    // C++14 允许使用 auto 作为 lambda 的参数类型
    // 编译器会为每个不同的参数类型生成对应的模板实例化

    // 泛型 lambda：可以接受任意类型的参数
    auto genericLambda = [](auto a, auto b) {
        // 返回 a + b 的结果
        // 要求类型 T 支持 operator+
        return a + b;
    };

    // 用 int 调用
    std::cout << "泛型 lambda int: " << genericLambda(10, 20) << std::endl;
    // 用 double 调用
    std::cout << "泛型 lambda double: " << genericLambda(3.14, 2.71) << std::endl;
    // 用 string 调用
    std::cout << "泛型 lambda string: " << genericLambda(std::string("Hello, "), std::string("World!")) << std::endl;

    // 可以指定部分 auto 参数，部分具体类型
    auto mixedGeneric = [](auto a, int b) {
        // a 是泛型，b 固定为 int
        return a * b;
    };
    std::cout << "混合泛型 lambda: " << mixedGeneric(2.5, 3) << std::endl;

    std::cout << std::endl;

    // 2.5 std::function 包装器

    // std::function 是一个通用的可调用对象包装器
    // 它可以存储函数、函数对象、lambda 等

    // 创建一个 std::function 对象
    // 模板参数签名：int(int, int) 表示接受两个 int，返回 int
    std::function<int(int, int)> func;

    // 存储一个 lambda
    func = [](int x, int y) {
        return x + y;
    };
    std::cout << "std::function 存 lambda: func(3, 4) = " << func(3, 4) << std::endl;

    // 存储另一个 lambda（不同的行为）
    func = [](int x, int y) {
        return x * y;
    };
    std::cout << "std::function 换 lambda: func(3, 4) = " << func(3, 4) << std::endl;

    // 存储函数对象
    Comparator comp(true);   // 升序比较器
    // 注意：这里需要匹配签名 int(int, int)，而 Comparator 的 operator()
    // 返回 bool，bool 可以隐式转换为 int
    std::function<bool(int, int)> compFunc;

    // 存储函数对象
    compFunc = comp;
    std::cout << "std::function 存函数对象: compFunc(3, 4) = " << (compFunc(3, 4) ? "true" : "false") << std::endl;

    // 存储普通函数
    // std::function<void(const std::string&)> 签名匹配 sayHello
    std::function<void(const std::string&)> helloFunc;
    helloFunc = sayHello;   // 存储普通函数指针
    helloFunc("Alice");     // 调用，输出 Hello, Alice!

    // 存储一个捕获了变量的 lambda
    int multiplier = 10;
    std::function<int(int)> timesFunc;
    timesFunc = [multiplier](int x) {
        // lambda 捕获了 multiplier，乘以 x
        return x * multiplier;
    };
    std::cout << "std::function 存捕获 lambda: timesFunc(7) = " << timesFunc(7) << std::endl;

    // std::function 作为函数参数
    // 定义一个 lambda，接受一个 std::function 参数
    auto applyFunc = [](std::function<int(int, int)> f, int x, int y) {
        // 调用传入的函数对象
        return f(x, y);
    };

    // 传入加法 lambda
    int result1 = applyFunc([](int x, int y) { return x + y; }, 10, 20);
    std::cout << "applyFunc（加法）: " << result1 << std::endl;

    // 传入乘法 lambda
    int result2 = applyFunc([](int x, int y) { return x * y; }, 10, 20);
    std::cout << "applyFunc（乘法）: " << result2 << std::endl;

    std::cout << std::endl;

    // ========== 结束 ==========

    std::cout << "===== 函数对象与Lambda演示结束 =====" << std::endl;

    // main 函数返回 0 表示程序正常结束
    return 0;
}
