# 29 C++17/20 新特性

## 概述

C++17 和 C++20 是现代 C++ 发展的重要里程碑。C++17 主要提升了语言表达力和标准库功能，C++20 则被称为"一次大爆炸"，引入了概念（concepts）、协程（coroutines）、范围库（ranges）等重大特性。

---

## 1. if/switch 带初始化语句 (C++17)

可以在 `if` 或 `switch` 的条件表达式中同时声明变量：

```cpp
if (auto it = map.find(key); it != map.end()) {
    // it 在此作用域内可用
}
// it 在此作用域外不可用
```

**优点**：缩小变量作用域，提高代码可读性和安全性。

---

## 2. 结构化绑定 (Structured Bindings, C++17)

将 pair、tuple 或结构体的成员一次性解包到多个变量中：

```cpp
std::pair<int, std::string> p = {1, "hello"};
auto [id, name] = p;  // id=1, name="hello"
```

**支持的类型**：数组、tuple-like 类型、所有非静态 public 数据成员的结构体。

---

## 3. if constexpr (C++17)

编译期条件分支，模板元编程的利器：

```cpp
template<typename T>
auto getValue(T t) {
    if constexpr (std::is_pointer_v<T>) {
        return *t;    // 指针类型走这个分支
    } else {
        return t;     // 非指针类型走这个分支
    }
}
```

**关键点**：未被选中的分支在编译期被丢弃，不会生成代码。

---

## 4. std::optional (C++17)

表示一个值"可能存在也可能不存在"：

```cpp
std::optional<int> findValue(bool flag) {
    if (flag) return 42;
    return std::nullopt;  // 表示无值
}
```

**优点**：比使用特殊值（如 -1、nullptr）更安全、语义更清晰。

---

## 5. std::variant (C++17)

类型安全的联合体，可以存储多种类型中的一种：

```cpp
std::variant<int, double, std::string> v = 42;
v = 3.14;        // 现在存储的是 double
v = "hello";     // 现在存储的是 string
```

**优点**：与传统的 union 不同，variant 知道当前存储的是哪种类型。

---

## 6. std::any (C++17)

可以存储任意类型的单个值（类型擦除）：

```cpp
std::any a = 42;
a = std::string("hello");
int val = std::any_cast<int>(a);  // 错误！当前存储的是 string
```

---

## 7. 折叠表达式 (Fold Expressions, C++17)

对可变参数模板中的所有参数应用二元运算符：

```cpp
template<typename... Args>
auto sum(Args... args) {
    return (... + args);  // 一元左折叠：((arg1 + arg2) + arg3) ...
}
```

**四种形式**：`(... op args)`、`(args op ...)`、`(init op ... op args)`、`(args op ... op init)`

---

## 8. Concepts 和 requires (C++20)

为模板参数定义约束条件，提供比 SFINAE 更友好的编译期检查：

```cpp
template<typename T>
concept Numeric = std::is_arithmetic_v<T>;

template<Numeric T>
T add(T a, T b) { return a + b; }
```

**优点**：更清晰的错误信息、更直观的语法。

---

## 9. 飞船运算符 <=> (Spaceship Operator, C++20)

三路比较运算符，一次定义所有比较操作：

```cpp
struct Point {
    int x, y;
    auto operator<=>(const Point&) const = default;
    // 自动生成 ==, !=, <, <=, >, >=
};
```

---

## 10. std::span (C++20)

对连续内存区域的非拥有视图，类似于 `std::string_view` 但用于数组：

```cpp
void process(std::span<int> data) {
    for (auto& elem : data) {
        elem *= 2;
    }
}
```

---

## 总结

| 特性 | 版本 | 作用 |
|------|------|------|
| if/switch 带初始化 | C++17 | 缩小变量作用域 |
| 结构化绑定 | C++17 | 解包复合类型 |
| if constexpr | C++17 | 编译期条件分支 |
| std::optional | C++17 | 可选值 |
| std::variant | C++17 | 类型安全联合体 |
| std::any | C++17 | 类型擦除容器 |
| 折叠表达式 | C++17 | 参数包操作 |
| Concepts | C++20 | 模板约束 |
| <=> 运算符 | C++20 | 三路比较 |
| std::span | C++20 | 内存视图 |
