#include <iostream>     // 标准输入输出流库，用于控制台输出
#include <string>       // 字符串库，用于 std::string
#include <vector>       // 向量容器库，用于演示 structured bindings
#include <map>          // 映射容器库，用于演示 if with initializer
#include <optional>     // 可选值库，用于演示 std::optional
#include <variant>      // 类型安全联合体库，用于演示 std::variant
#include <any>          // 类型擦除容器库，用于演示 std::any
#include <tuple>        // 元组库，用于演示结构化绑定与 tuple
#include <array>        // 固定大小数组库，用于演示结构化绑定

// ========== 1. 演示 if/switch 带初始化语句 (C++17) ==========

// 定义一个函数，用于在 map 中查找某个键是否存在
void demoIfWithInitializer() {
    std::cout << "===== 1. if 带初始化语句 (C++17) =====" << std::endl;

    // 创建一个 map 容器，存储姓名和对应的分数
    std::map<std::string, int> scores = {
        {"Alice", 95},     // Alice 的分数是 95
        {"Bob", 87},       // Bob 的分数是 87
        {"Charlie", 92}    // Charlie 的分数是 92
    };

    // 使用 if 带初始化语句：在 if 条件中声明迭代器变量 it
    // it 的生命周期仅限于 if 语句块内，不会泄漏到外部作用域
    if (auto it = scores.find("Alice"); it != scores.end()) {
        // 如果找到了 "Alice"，则输出她的分数
        std::cout << "Alice 的分数是: " << it->second << std::endl;
    } else {
        // 如果没有找到，输出提示信息
        std::cout << "未找到 Alice" << std::endl;
    }
    // 注意：it 在这里已经不可见了，这就是带初始化语句的优势
    // 传统写法需要将 it 定义在 if 外面，会污染外部作用域

    // 使用 switch 带初始化语句：在 switch 条件中声明变量
    switch (auto value = 2; value) {
        case 1:  // 如果 value == 1
            std::cout << "value 是 1" << std::endl;
            break;
        case 2:  // 如果 value == 2
            std::cout << "value 是 2" << std::endl;
            break;
        default:  // 其他情况
            std::cout << "value 是其他值" << std::endl;
            break;
    }
    // value 在这里已经不可见了，不会泄漏到外部作用域
    std::cout << std::endl;
}

// ========== 2. 演示结构化绑定 (Structured Bindings, C++17) ==========

// 定义一个简单的结构体，用于演示结构化绑定
struct Point {
    double x;  // x 坐标
    double y;  // y 坐标
    double z;  // z 坐标
};

// 演示结构化绑定的各种用法
void demoStructuredBindings() {
    std::cout << "===== 2. 结构化绑定 (C++17) =====" << std::endl;

    // 演示 1：绑定到数组
    int arr[] = {10, 20, 30};              // 一个包含三个整数的数组
    auto [a, b, c] = arr;                  // 将数组的三个元素分别绑定到 a, b, c
    std::cout << "数组解包: a=" << a << ", b=" << b << ", c=" << c << std::endl;

    // 演示 2：绑定到 pair（常见于 map 遍历）
    std::pair<int, std::string> person = {1, "张三"};  // 一个 pair：ID 和姓名
    auto [id, name] = person;                          // 将 pair 的两个字段解包
    std::cout << "pair 解包: id=" << id << ", name=" << name << std::endl;

    // 演示 3：绑定到 tuple
    auto tuple = std::make_tuple(100, 3.14, "hello");  // 创建一个包含三种不同类型的元组
    auto [i, d, s] = tuple;                            // 将 tuple 的三个元素解包
    std::cout << "tuple 解包: i=" << i << ", d=" << d << ", s=" << s << std::endl;

    // 演示 4：绑定到结构体
    Point p{1.5, 2.5, 3.5};              // 创建一个 Point 对象
    auto [px, py, pz] = p;               // 将结构体的三个成员解包
    std::cout << "结构体解包: x=" << px << ", y=" << py << ", z=" << pz << std::endl;

    // 演示 5：使用引用绑定，可以修改原对象
    auto& [rx, ry, rz] = p;              // 使用引用绑定，避免拷贝
    rx = 99.9;                           // 修改引用会影响到原对象 p
    std::cout << "修改后 p.x = " << p.x << " (通过引用修改)" << std::endl;

    // 演示 6：在 range-based for 循环中使用结构化绑定
    std::map<std::string, int> scores = {{"Alice", 95}, {"Bob", 87}};
    for (const auto& [key, value] : scores) {  // 遍历 map，直接解包为 key 和 value
        std::cout << key << " -> " << value << std::endl;
    }

    std::cout << std::endl;
}

// ========== 3. 演示 if constexpr (C++17) ==========

// 模板函数：根据类型的不同执行不同的分支
// 使用 if constexpr 在编译期进行条件判断
template<typename T>
auto getValue(T t) {
    // if constexpr 是编译期条件分支，未选中的分支不会被实例化
    if constexpr (std::is_pointer_v<T>) {
        // 如果 T 是指针类型，解引用并返回值
        return *t;
    } else if constexpr (std::is_same_v<T, std::string>) {
        // 如果 T 是 std::string 类型，返回字符串的长度（转换为 double 以保持返回值一致）
        return static_cast<double>(t.length());
    } else {
        // 其他类型直接返回值本身
        return t;
    }
}

// 演示 if constexpr 的编译期特性
void demoIfConstexpr() {
    std::cout << "===== 3. if constexpr (C++17) =====" << std::endl;

    int x = 42;                    // 普通的 int 变量
    int* ptr = &x;                 // 指向 x 的指针
    std::string str = "hello";     // 字符串

    // 调用 getValue 函数，T 被推导为 int，走 else 分支
    std::cout << "getValue(42) = " << getValue(x) << std::endl;

    // 调用 getValue 函数，T 被推导为 int*，走指针分支
    std::cout << "getValue(&x) = " << getValue(ptr) << std::endl;

    // 调用 getValue 函数，T 被推导为 std::string，走字符串分支
    std::cout << "getValue(\"hello\") 的长度 = " << getValue(str) << std::endl;

    // 注意：如果没有 if constexpr，下面这行代码会导致编译错误
    // 因为 getValue(ptr) 版本也会尝试编译 else 分支，而 int 不支持 .length()
    // if constexpr 保证了未被选中的分支不会被编译

    std::cout << std::endl;
}

// ========== 4. 演示 std::optional (C++17) ==========

// 模拟一个除法函数，当除数为 0 时返回空值
// std::optional 可以表示"可能有值，也可能没有值"
std::optional<double> safeDivide(double a, double b) {
    if (b == 0.0) {
        // 除数为 0，返回空值（std::nullopt）
        return std::nullopt;
    }
    // 正常返回除法结果
    return a / b;
}

// 从字符串中解析整数的函数
std::optional<int> parseInt(const std::string& str) {
    try {
        // 尝试将字符串转换为整数
        size_t pos = 0;
        int result = std::stoi(str, &pos);
        // 如果成功转换且使用了所有字符，返回结果
        if (pos == str.length()) {
            return result;
        }
        return std::nullopt;  // 部分字符未使用，视为解析失败
    } catch (...) {
        // 转换失败，返回空值
        return std::nullopt;
    }
}

void demoOptional() {
    std::cout << "===== 4. std::optional (C++17) =====" << std::endl;

    // 测试 safeDivide 函数
    auto result1 = safeDivide(10.0, 3.0);    // 正常的除法
    auto result2 = safeDivide(10.0, 0.0);    // 除数为 0

    // 使用 has_value() 检查是否有值
    if (result1.has_value()) {
        std::cout << "10 / 3 = " << result1.value() << std::endl;
    }

    // 使用 value_or() 在无值时提供默认值
    std::cout << "10 / 0 = " << result2.value_or(-1.0) << " (返回默认值 -1)" << std::endl;

    // 直接使用 operator bool 判断
    if (result2) {
        std::cout << "result2 有值" << std::endl;
    } else {
        std::cout << "result2 无值（除数为零）" << std::endl;
    }

    // 测试 parseInt 函数
    auto num1 = parseInt("123");      // 合法数字
    auto num2 = parseInt("abc");      // 非法字符串
    auto num3 = parseInt("123abc");   // 部分合法

    std::cout << "parseInt(\"123\") = " << num1.value_or(-1) << std::endl;
    std::cout << "parseInt(\"abc\") = " << (num2 ? std::to_string(num2.value()) : "解析失败") << std::endl;
    std::cout << "parseInt(\"123abc\") = " << (num3 ? std::to_string(num3.value()) : "解析失败") << std::endl;

    std::cout << std::endl;
}

// ========== 5. 演示 std::variant (C++17) ==========

// 定义一个 variant，可以存储 int, double 或 std::string 中的一种类型
using VarType = std::variant<int, double, std::string>;

// 辅助函数：访问 variant 中的值
struct VariantPrinter {
    // 重载 operator() 用于处理 int 类型
    void operator()(int value) const {
        std::cout << "int: " << value << std::endl;
    }
    // 重载 operator() 用于处理 double 类型
    void operator()(double value) const {
        std::cout << "double: " << value << std::endl;
    }
    // 重载 operator() 用于处理 std::string 类型
    void operator()(const std::string& value) const {
        std::cout << "string: " << value << std::endl;
    }
};

void demoVariant() {
    std::cout << "===== 5. std::variant (C++17) =====" << std::endl;

    // 创建一个 variant，初始存储 int 类型
    VarType v = 42;
    // 使用 std::visit 和 VariantPrinter 访问 variant 中的值
    std::cout << "variant 当前值 (int): ";
    std::visit(VariantPrinter{}, v);

    // 修改 variant，现在存储 double 类型
    v = 3.14159;
    std::cout << "variant 当前值 (double): ";
    std::visit(VariantPrinter{}, v);

    // 修改 variant，现在存储 string 类型
    v = std::string("Hello, Variant!");
    std::cout << "variant 当前值 (string): ";
    std::visit(VariantPrinter{}, v);

    // 使用 index() 获取当前存储的类型索引
    std::cout << "当前类型索引: " << v.index() << " (0=int, 1=double, 2=string)" << std::endl;

    // 使用 std::get_if 安全地获取值
    if (auto* strPtr = std::get_if<std::string>(&v)) {
        // 如果当前存储的是 string 类型，则输出其长度
        std::cout << "字符串长度为: " << strPtr->length() << std::endl;
    }

    // 使用 std::get 获取值（如果类型不匹配会抛出 std::bad_variant_access 异常）
    try {
        // 尝试以 int 类型获取 variant 的值（当前是 string，会抛出异常）
        int wrongType = std::get<int>(v);
        // 避免编译器警告"未使用的变量"，用 (void) 抑制
        (void)wrongType;
    } catch (const std::bad_variant_access& e) {
        // 捕获类型不匹配异常
        std::cout << "类型访问错误: " << e.what() << std::endl;
    }

    // 使用 Lambda 表达式访问 variant（更简洁的方式）
    std::cout << "使用 Lambda 访问: ";
    std::visit([](auto&& arg) {
        // 使用 decltype 和 if constexpr 根据类型打印不同信息
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, int>) {
            std::cout << "整数: " << arg << std::endl;
        } else if constexpr (std::is_same_v<T, double>) {
            std::cout << "浮点数: " << arg << std::endl;
        } else if constexpr (std::is_same_v<T, std::string>) {
            std::cout << "字符串: " << arg << std::endl;
        }
    }, v);

    std::cout << std::endl;
}

// ========== 6. 演示 std::any (C++17) ==========

// std::any 可以存储任意类型的值（类型擦除）
void demoAny() {
    std::cout << "===== 6. std::any (C++17) =====" << std::endl;

    // 创建一个 std::any 对象，初始存储 int
    std::any a = 42;
    std::cout << "std::any 存储 int: " << std::any_cast<int>(a) << std::endl;

    // 修改为存储 std::string
    a = std::string("Hello, Any!");
    std::cout << "std::any 存储 string: " << std::any_cast<std::string>(a) << std::endl;

    // 修改为存储 double
    a = 3.14159;
    std::cout << "std::any 存储 double: " << std::any_cast<double>(a) << std::endl;

    // 使用 has_value() 检查是否包含值
    std::cout << "是否有值: " << (a.has_value() ? "是" : "否") << std::endl;

    // 使用 type() 获取当前存储值的类型信息
    std::cout << "存储的类型: " << a.type().name() << std::endl;

    // 清空 any 对象
    a.reset();
    std::cout << "reset 后是否有值: " << (a.has_value() ? "是" : "否") << std::endl;

    // any_cast 失败时会抛出 std::bad_any_cast 异常
    a = 100;  // 重新存储 int
    try {
        // 尝试以错误的类型获取值（预期会抛出异常）
        auto value = std::any_cast<double>(a);
        // 避免编译器警告"未使用的变量"
        (void)value;
    } catch (const std::bad_any_cast& e) {
        std::cout << "any_cast 错误: " << e.what() << std::endl;
    }

    // 使用 any_cast 的指针版本（不会抛异常，失败返回 nullptr）
    int* ptr = std::any_cast<int>(&a);
    if (ptr) {
        std::cout << "指针版 any_cast 成功: " << *ptr << std::endl;
    }

    std::cout << std::endl;
}

// ========== 7. 演示折叠表达式 (Fold Expressions, C++17) ==========

// 一元左折叠：(... op args) 展开为 ((arg1 + arg2) + arg3) ...
template<typename... Args>
auto sumLeft(Args... args) {
    // 使用一元左折叠计算所有参数的和
    return (... + args);  // 展开为 ((arg1 + arg2) + arg3 + ...)
}

// 一元右折叠：(args op ...) 展开为 (arg1 + (arg2 + arg3)) ...
template<typename... Args>
auto sumRight(Args... args) {
    // 使用一元右折叠计算所有参数的和
    return (args + ...);  // 展开为 (arg1 + (arg2 + (arg3 + ...)))
}

// 使用折叠表达式输出所有参数（逗号运算符版）
template<typename... Args>
void printAll(Args... args) {
    // 使用折叠表达式结合逗号运算符，逐个输出参数
    // (... , std::cout << args) 展开为 ((std::cout << arg1), (std::cout << arg2), ...)
    (std::cout << ... << args) << std::endl;  // 这是另一种形式：二元左折叠
}

// 检查所有参数是否都满足某个条件
template<typename... Args>
bool allTrue(Args... args) {
    // 使用 && 折叠：检查所有参数是否都为 true
    return (... && args);  // 展开为 (arg1 && arg2 && arg3 && ...)
}

// 检查是否至少有一个参数满足条件
template<typename... Args>
bool anyTrue(Args... args) {
    // 使用 || 折叠：检查是否存在至少一个 true
    return (... || args);  // 展开为 (arg1 || arg2 || arg3 || ...)
}

void demoFoldExpressions() {
    std::cout << "===== 7. 折叠表达式 (C++17) =====" << std::endl;

    // 测试 sumLeft 和 sumRight
    std::cout << "sumLeft(1, 2, 3, 4, 5) = " << sumLeft(1, 2, 3, 4, 5) << std::endl;
    std::cout << "sumRight(1, 2, 3, 4, 5) = " << sumRight(1, 2, 3, 4, 5) << std::endl;

    // 测试 printAll
    std::cout << "printAll: ";
    printAll(1, 2, 3, 4, 5);

    // 测试 allTrue 和 anyTrue
    std::cout << "allTrue(true, true, false) = " << (allTrue(true, true, false) ? "true" : "false") << std::endl;
    std::cout << "anyTrue(true, true, false) = " << (anyTrue(true, true, false) ? "true" : "false") << std::endl;
    std::cout << "allTrue(true, true, true) = " << (allTrue(true, true, true) ? "true" : "false") << std::endl;

    std::cout << std::endl;
}

// ========== 主函数 ==========

int main() {
    // 输出程序标题
    std::cout << "========== C++17 新特性演示 ==========" << std::endl;
    std::cout << "编译标准: C++17 (g++ -std=c++17)" << std::endl;
    std::cout << std::endl;

    // 依次演示各个 C++17 特性
    demoIfWithInitializer();      // 演示 if/switch 带初始化语句
    demoStructuredBindings();     // 演示结构化绑定
    demoIfConstexpr();            // 演示 if constexpr
    demoOptional();               // 演示 std::optional
    demoVariant();                // 演示 std::variant
    demoAny();                    // 演示 std::any
    demoFoldExpressions();        // 演示折叠表达式

    // 输出总结信息
    std::cout << "========== 演示完成 ==========" << std::endl;
    std::cout << "演示了以下 C++17 特性:" << std::endl;
    std::cout << "  1. if/switch 带初始化语句" << std::endl;
    std::cout << "  2. 结构化绑定 (Structured Bindings)" << std::endl;
    std::cout << "  3. if constexpr 编译期条件分支" << std::endl;
    std::cout << "  4. std::optional 可选值" << std::endl;
    std::cout << "  5. std::variant 类型安全联合体" << std::endl;
    std::cout << "  6. std::any 类型擦除容器" << std::endl;
    std::cout << "  7. 折叠表达式 (Fold Expressions)" << std::endl;

    return 0;  // 程序正常退出
}
