#include <iostream>     // 标准输入输出流库，用于控制台输出
#include <string>       // 字符串库，用于 std::string
#include <vector>       // 向量容器库，用于存储观察者列表
#include <memory>       // 智能指针库，用于 std::unique_ptr, std::make_unique
#include <mutex>        // 互斥锁库，用于线程安全的单例
#include <thread>       // 线程库，用于演示多线程环境下的单例
#include <chrono>       // 时间库，用于线程休眠

// ========== 1. 单例模式 (Singleton) - 线程安全版本 ==========

// Logger 类是一个单例日志记录器，保证整个程序中只有一个实例
// 使用 Meyers' Singleton（函数局部 static 变量）实现线程安全
class Logger {
private:
    // 私有构造函数：禁止外部直接创建 Logger 实例
    Logger() {
        std::cout << "  [Logger] 单例实例被创建" << std::endl;
    }

    // 禁止拷贝构造和拷贝赋值
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

public:
    // 获取单例实例的唯一全局访问点
    // 使用函数局部 static 变量：
    // C++11 保证函数内 static 变量的初始化是线程安全的
    static Logger& getInstance() {
        static Logger instance;  // 第一次调用时创建，之后复用同一个实例
        return instance;
    }

    // 日志输出方法
    void log(const std::string& message) {
        // 在实际项目中，这里通常会写入文件或网络
        std::cout << "  [LOG] " << message << std::endl;
    }
};

// 演示单例模式：在多线程环境下调用
void demoWorker(int id) {
    // 多个线程同时调用 getInstance()，但只创建一个实例
    Logger::getInstance().log("线程 " + std::to_string(id) + " 正在工作");
    // 模拟一些工作
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

void demoSingleton() {
    std::cout << "===== 1. 单例模式 (Singleton) =====" << std::endl;
    std::cout << "--- 演示单一线程 ---" << std::endl;

    // 第一次调用 getInstance() 会创建实例
    Logger::getInstance().log("程序启动");

    // 第二次调用 getInstance() 返回同一个实例
    Logger::getInstance().log("程序运行中");

    // 演示多线程环境：创建多个线程同时访问单例
    std::cout << "--- 多线程环境（演示线程安全）---" << std::endl;
    std::vector<std::thread> threads;  // 存储线程对象
    for (int i = 1; i <= 5; ++i) {
        // 创建线程，每个线程调用 demoWorker
        threads.emplace_back(demoWorker, i);
    }

    // 等待所有线程执行完毕
    for (auto& t : threads) {
        t.join();  // 等待线程结束
    }

    std::cout << std::endl;
}

// ========== 2. 工厂方法模式 (Factory Method) ==========

// 抽象产品类：形状
// 定义了所有形状都需要实现的接口
class Shape {
public:
    // 纯虚函数：绘制形状，由具体子类实现
    virtual void draw() const = 0;
    // 虚析构函数：确保派生类析构时正确释放资源
    virtual ~Shape() = default;
};

// 具体产品类：圆形
class Circle : public Shape {
public:
    // 实现 draw 方法，绘制圆形
    void draw() const override {
        std::cout << "  [Circle] 绘制圆形: O" << std::endl;
    }
};

// 具体产品类：正方形
class Square : public Shape {
public:
    // 实现 draw 方法，绘制正方形
    void draw() const override {
        std::cout << "  [Square] 绘制正方形: []" << std::endl;
    }
};

// 具体产品类：三角形
class Triangle : public Shape {
public:
    // 实现 draw 方法，绘制三角形
    void draw() const override {
        std::cout << "  [Triangle] 绘制三角形: /\\" << std::endl;
    }
};

// 形状工厂类：根据传入的类型创建对应的形状对象
// 将对象的创建和使用解耦
class ShapeFactory {
public:
    // 工厂方法：根据形状类型名称创建对应的 Shape 对象
    // 返回 std::unique_ptr<Shape> 自动管理内存
    static std::unique_ptr<Shape> createShape(const std::string& type) {
        if (type == "circle") {
            // 创建圆形对象
            return std::make_unique<Circle>();
        } else if (type == "square") {
            // 创建正方形对象
            return std::make_unique<Square>();
        } else if (type == "triangle") {
            // 创建三角形对象
            return std::make_unique<Triangle>();
        } else {
            // 不支持的形状类型，返回空指针
            return nullptr;
        }
    }
};

void demoFactory() {
    std::cout << "===== 2. 工厂方法模式 (Factory) =====" << std::endl;

    // 通过工厂创建不同的形状对象，客户端不需要知道具体的形状类
    std::vector<std::string> shapeTypes = {"circle", "square", "triangle", "hexagon"};

    for (const auto& type : shapeTypes) {
        // 让工厂创建指定类型的形状
        auto shape = ShapeFactory::createShape(type);
        if (shape) {
            // 创建成功，调用 draw 方法
            // 注意：客户端通过 Shape 接口操作，不知道具体类型
            std::cout << "创建形状: " << type << std::endl;
            shape->draw();
        } else {
            // 创建失败，提示不支持的形状
            std::cout << "不支持的形状类型: " << type << std::endl;
        }
    }

    std::cout << std::endl;
}

// ========== 3. 观察者模式 (Observer) ==========

// 前向声明 Subject 类，因为 Observer 的 update 方法需要 Subject 参数
class Subject;

// 抽象观察者接口
// 所有观察者都需要实现 update 方法，用于接收主题的通知
class Observer {
public:
    // 当被观察者状态变化时，会调用此方法
    // message 是主题发送的通知消息
    virtual void update(const std::string& message) = 0;
    // 虚析构函数
    virtual ~Observer() = default;
};

// 主题（被观察者）类
// 维护观察者列表，当状态变化时通知所有注册的观察者
class Subject {
private:
    // 存储所有注册的观察者指针列表
    std::vector<Observer*> observers_;
    // 主题的状态信息
    std::string state_;

public:
    // 注册观察者：将观察者添加到通知列表中
    void attach(Observer* observer) {
        observers_.push_back(observer);
        std::cout << "  [Subject] 注册了一个观察者，当前共 " << observers_.size() << " 个观察者" << std::endl;
    }

    // 注销观察者：从通知列表中移除观察者
    void detach(Observer* observer) {
        // 遍历查找并移除指定的观察者
        for (auto it = observers_.begin(); it != observers_.end(); ++it) {
            if (*it == observer) {
                observers_.erase(it);  // 移除找到的观察者
                std::cout << "  [Subject] 移除了一个观察者" << std::endl;
                break;
            }
        }
    }

    // 设置主题状态并通知所有观察者
    void setState(const std::string& newState) {
        state_ = newState;  // 更新状态
        std::cout << "  [Subject] 状态变更为: " << state_ << std::endl;
        notifyObservers();  // 通知所有观察者
    }

    // 获取当前状态
    std::string getState() const {
        return state_;
    }

private:
    // 通知所有注册的观察者：遍历观察者列表并调用 update 方法
    void notifyObservers() {
        for (auto* observer : observers_) {
            observer->update(state_);  // 每个观察者收到状态更新通知
        }
    }
};

// 具体观察者类：用户 A
class UserA : public Observer {
private:
    std::string name_;  // 观察者名称

public:
    // 构造函数，设置观察者名称
    UserA() : name_("用户A") {}

    // 接收通知的处理方法
    void update(const std::string& message) override {
        std::cout << "  [" << name_ << "] 收到通知: " << message << std::endl;
        // 用户 A 对特定消息做额外处理
        if (message.find("紧急") != std::string::npos) {
            std::cout << "  [" << name_ << "] 这是紧急消息，立即处理！" << std::endl;
        }
    }
};

// 具体观察者类：用户 B
class UserB : public Observer {
private:
    std::string name_;  // 观察者名称

public:
    // 构造函数，设置观察者名称
    UserB() : name_("用户B") {}

    // 接收通知的处理方法
    void update(const std::string& message) override {
        std::cout << "  [" << name_ << "] 收到通知: " << message << std::endl;
        // 用户 B 只关心包含"更新"的消息
        if (message.find("更新") != std::string::npos) {
            std::cout << "  [" << name_ << "] 检测到更新，记录日志" << std::endl;
        }
    }
};

// 具体观察者类：用户 C
class UserC : public Observer {
private:
    std::string name_;  // 观察者名称

public:
    // 构造函数，设置观察者名称
    UserC() : name_("用户C") {}

    // 接收通知的处理方法
    void update(const std::string& message) override {
        std::cout << "  [" << name_ << "] 收到通知: " << message << std::endl;
        // 用户 C 记录所有通知
        std::cout << "  [" << name_ << "] 已存档消息" << std::endl;
    }
};

void demoObserver() {
    std::cout << "===== 3. 观察者模式 (Observer) =====" << std::endl;

    // 创建主题（被观察者）
    Subject subject;

    // 创建三个观察者
    UserA userA;
    UserB userB;
    UserC userC;

    // 注册观察者：将观察者添加到主题的通知列表
    subject.attach(&userA);  // 用户 A 订阅
    subject.attach(&userB);  // 用户 B 订阅
    subject.attach(&userC);  // 用户 C 订阅

    // 主题状态变化，自动通知所有观察者
    std::cout << "--- 第一次状态变更 ---" << std::endl;
    subject.setState("系统更新通知");

    std::cout << "--- 第二次状态变更 ---" << std::endl;
    subject.setState("紧急：服务器维护");

    // 移除一个观察者，然后再次通知
    subject.detach(&userB);  // 用户 B 取消订阅

    std::cout << "--- 移除用户B后第三次状态变更 ---" << std::endl;
    subject.setState("普通公告");

    std::cout << std::endl;
}

// ========== 4. 策略模式 (Strategy) ==========

// 策略接口：定义了所有策略必须实现的算法接口
class Strategy {
public:
    // 执行算法：对两个整数执行某种操作
    virtual int execute(int a, int b) const = 0;
    // 获取策略名称
    virtual std::string getName() const = 0;
    // 虚析构函数
    virtual ~Strategy() = default;
};

// 具体策略类：加法策略
class AddStrategy : public Strategy {
public:
    // 执行加法运算
    int execute(int a, int b) const override {
        return a + b;
    }
    // 返回策略名称
    std::string getName() const override {
        return "加法(+)";
    }
};

// 具体策略类：减法策略
class SubtractStrategy : public Strategy {
public:
    // 执行减法运算
    int execute(int a, int b) const override {
        return a - b;
    }
    // 返回策略名称
    std::string getName() const override {
        return "减法(-)";
    }
};

// 具体策略类：乘法策略
class MultiplyStrategy : public Strategy {
public:
    // 执行乘法运算
    int execute(int a, int b) const override {
        return a * b;
    }
    // 返回策略名称
    std::string getName() const override {
        return "乘法(*)";
    }
};

// 具体策略类：除法策略
class DivideStrategy : public Strategy {
public:
    // 执行除法运算（注意：未处理除零的情况，仅用于演示）
    int execute(int a, int b) const override {
        if (b == 0) {
            // 除零错误处理
            std::cout << "  [错误] 除数不能为零！" << std::endl;
            return 0;
        }
        return a / b;
    }
    // 返回策略名称
    std::string getName() const override {
        return "除法(/)";
    }
};

// 上下文类：使用策略的对象
// 可以在运行时切换不同的策略
class Calculator {
private:
    // 当前使用的策略
    const Strategy* strategy_;

public:
    // 构造函数：设置初始策略
    explicit Calculator(const Strategy* strategy)
        : strategy_(strategy) {}

    // 运行时切换策略
    void setStrategy(const Strategy* strategy) {
        strategy_ = strategy;
        std::cout << "  [Calculator] 切换策略为: " << strategy_->getName() << std::endl;
    }

    // 使用当前策略执行计算
    int calculate(int a, int b) {
        if (!strategy_) {
            std::cout << "  [Calculator] 未设置策略！" << std::endl;
            return 0;
        }
        std::cout << "  [Calculator] 使用 " << strategy_->getName() << " 运算: ";
        int result = strategy_->execute(a, b);
        std::cout << a << " 和 " << b << " 的结果 = " << result << std::endl;
        return result;
    }
};

void demoStrategy() {
    std::cout << "===== 4. 策略模式 (Strategy) =====" << std::endl;

    // 创建各种策略对象
    AddStrategy add;              // 加法策略
    SubtractStrategy subtract;    // 减法策略
    MultiplyStrategy multiply;    // 乘法策略
    DivideStrategy divide;        // 除法策略

    // 创建计算器上下文，初始使用加法策略
    Calculator calc(&add);
    std::cout << "--- 初始策略: 加法 ---" << std::endl;
    calc.calculate(10, 5);  // 10 + 5 = 15

    // 运行时切换策略为减法
    std::cout << "--- 切换为减法 ---" << std::endl;
    calc.setStrategy(&subtract);
    calc.calculate(10, 5);  // 10 - 5 = 5

    // 运行时切换策略为乘法
    std::cout << "--- 切换为乘法 ---" << std::endl;
    calc.setStrategy(&multiply);
    calc.calculate(10, 5);  // 10 * 5 = 50

    // 运行时切换策略为除法
    std::cout << "--- 切换为除法 ---" << std::endl;
    calc.setStrategy(&divide);
    calc.calculate(10, 5);  // 10 / 5 = 2
    calc.calculate(10, 0);  // 触发除零错误处理

    std::cout << std::endl;
}

// ========== 5. RAII 模式演示 ==========

// RAII Wrapper 类：封装动态数组的内存管理
// 在构造函数中获取资源（分配内存），在析构函数中释放资源（释放内存）
class IntArrayRAII {
private:
    int* data_;         // 指向动态分配的数组
    size_t size_;       // 数组的大小

public:
    // 构造函数：获取资源（分配内存）
    IntArrayRAII(size_t size) : size_(size) {
        // 在构造函数中获取资源
        data_ = new int[size_];
        // 初始化所有元素为 0
        for (size_t i = 0; i < size_; ++i) {
            data_[i] = 0;
        }
        std::cout << "  [RAII] 构造函数：分配了 " << size_ << " 个整数的数组" << std::endl;
    }

    // 析构函数：释放资源（释放内存）
    // 当对象离开作用域时，析构函数自动被调用
    ~IntArrayRAII() {
        // 在析构函数中释放资源
        delete[] data_;
        std::cout << "  [RAII] 析构函数：释放了 " << size_ << " 个整数的数组" << std::endl;
    }

    // 禁止拷贝
    IntArrayRAII(const IntArrayRAII&) = delete;
    IntArrayRAII& operator=(const IntArrayRAII&) = delete;

    // 设置数组元素
    void set(size_t index, int value) {
        if (index < size_) {
            data_[index] = value;
        }
    }

    // 获取数组元素
    int get(size_t index) const {
        if (index < size_) {
            return data_[index];
        }
        return -1;
    }

    // 获取数组大小
    size_t size() const {
        return size_;
    }
};

// 演示 RAII：资源在作用域结束时自动释放
void demoRAII() {
    std::cout << "===== 5. RAII 模式 =====" << std::endl;

    std::cout << "--- 进入作用域 ---" << std::endl;
    {
        // RAII 对象在栈上创建，构造函数分配资源
        IntArrayRAII arr(10);

        // 使用数组
        arr.set(0, 42);                     // 设置第一个元素为 42
        arr.set(1, 100);                    // 设置第二个元素为 100
        std::cout << "  arr[0] = " << arr.get(0) << std::endl;
        std::cout << "  arr[1] = " << arr.get(1) << std::endl;

        // 即使发生异常，离开作用域时析构函数也会被调用
        std::cout << "  --- 即将离开作用域，析构函数会自动释放资源 ---" << std::endl;
    }
    // 在这里 arr 已经离开作用域，析构函数自动被调用，内存被释放
    std::cout << "--- 已离开作用域，资源已被自动释放 ---" << std::endl;

    std::cout << std::endl;
}

// ========== 主函数 ==========

int main() {
    // 输出程序标题
    std::cout << "========== C++ 设计模式演示 ==========" << std::endl;
    std::cout << std::endl;

    // 依次演示各种设计模式
    demoSingleton();    // 演示单例模式（线程安全）
    demoFactory();      // 演示工厂方法模式
    demoObserver();     // 演示观察者模式
    demoStrategy();     // 演示策略模式
    demoRAII();         // 演示 RAII 模式

    // 输出总结信息
    std::cout << "========== 演示完成 ==========" << std::endl;
    std::cout << "演示了以下设计模式:" << std::endl;
    std::cout << "  1. 单例模式 (Singleton) - 线程安全" << std::endl;
    std::cout << "  2. 工厂方法模式 (Factory Method)" << std::endl;
    std::cout << "  3. 观察者模式 (Observer)" << std::endl;
    std::cout << "  4. 策略模式 (Strategy)" << std::endl;
    std::cout << "  5. RAII 资源管理" << std::endl;

    return 0;  // 程序正常退出
}
