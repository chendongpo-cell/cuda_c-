# 31 设计模式

## 概述

设计模式（Design Patterns）是软件工程中针对常见问题的可重用解决方案。在 C++ 中，设计模式结合语言特性（如 RAII、模板、多态）可以编写出高效、可维护的代码。

---

## 1. 单例模式 (Singleton)

确保一个类只有一个实例，并提供全局访问点。

### 适用场景
- 日志系统、配置管理器、线程池、数据库连接池

### C++ 实现要点
- 构造函数私有化（禁止外部创建）
- 删除拷贝构造和赋值运算符
- 线程安全的双重检查锁定（C++11 起可使用 Meyers' Singleton）

### 线程安全版本（Meyers' Singleton）
```cpp
class Singleton {
public:
    static Singleton& getInstance() {
        static Singleton instance;  // C++11 保证函数局部 static 变量初始化是线程安全的
        return instance;
    }
private:
    Singleton() = default;                          // 私有构造函数
    Singleton(const Singleton&) = delete;           // 禁止拷贝
    Singleton& operator=(const Singleton&) = delete; // 禁止赋值
};
```

### 饿汉式 vs 懒汉式
| 方式 | 优点 | 缺点 |
|------|------|------|
| 饿汉式 | 实现简单，天然线程安全 | 程序启动就创建，可能浪费资源 |
| 懒汉式 | 按需创建，节省资源 | 需要处理线程安全 |

---

## 2. 工厂方法模式 (Factory Method)

定义一个创建对象的接口，让子类决定实例化哪个类。

### 适用场景
- 当不知道具体要创建什么类型的对象时
- 当创建逻辑比较复杂时

```cpp
// 抽象产品
class Shape {
public:
    virtual void draw() const = 0;
    virtual ~Shape() = default;
};

// 具体产品
class Circle : public Shape {
    void draw() const override { /* ... */ }
};

// 工厂
class ShapeFactory {
public:
    std::unique_ptr<Shape> createShape(const std::string& type) {
        if (type == "circle") return std::make_unique<Circle>();
        if (type == "square") return std::make_unique<Square>();
        return nullptr;
    }
};
```

---

## 3. 观察者模式 (Observer)

定义一对多的依赖关系，当一个对象状态改变时，所有依赖它的对象都得到通知并自动更新。

### 适用场景
- 事件处理系统、MVC 架构、消息推送

```cpp
// 观察者接口
class Observer {
public:
    virtual void update(const std::string& message) = 0;
    virtual ~Observer() = default;
};

// 主题（被观察者）
class Subject {
    std::vector<Observer*> observers_;
public:
    void attach(Observer* obs) { observers_.push_back(obs); }
    void notify(const std::string& msg) {
        for (auto* obs : observers_) {
            obs->update(msg);
        }
    }
};
```

---

## 4. 策略模式 (Strategy)

定义一系列算法，将它们封装起来，并使它们可以互相替换。

### 适用场景
- 需要在运行时切换算法
- 避免使用大量条件语句（if-else / switch）

```cpp
// 策略接口
class Strategy {
public:
    virtual int execute(int a, int b) = 0;
    virtual ~Strategy() = default;
};

// 具体策略
class AddStrategy : public Strategy {
    int execute(int a, int b) override { return a + b; }
};

class MultiplyStrategy : public Strategy {
    int execute(int a, int b) override { return a * b; }
};

// 上下文
class Context {
    std::unique_ptr<Strategy> strategy_;
public:
    void setStrategy(std::unique_ptr<Strategy> s) { strategy_ = std::move(s); }
    int executeStrategy(int a, int b) { return strategy_->execute(a, b); }
};
```

---

## 5. RAII (Resource Acquisition Is Initialization)

RAII 不是 GoF 设计模式，而是 C++ 特有的资源管理技术，是 C++ 中最核心的设计理念之一。

### 核心思想
- **资源获取即初始化**：在构造函数中获取资源，在析构函数中释放资源
- 利用栈对象的生命周期自动管理资源

### 常见应用
| 资源类型 | RAII 封装 |
|----------|-----------|
| 动态内存 | `std::unique_ptr`, `std::shared_ptr` |
| 文件句柄 | `std::fstream` |
| 互斥锁 | `std::lock_guard`, `std::unique_lock` |
| 网络连接 | 自定义 RAII 包装类 |

### 示例：文件操作的 RAII 包装
```cpp
class FileGuard {
    FILE* file_;
public:
    FileGuard(const char* filename) {
        file_ = std::fopen(filename, "r");
    }
    ~FileGuard() {
        if (file_) std::fclose(file_);
    }
    // 禁止拷贝和移动（或正确实现）
};
```

---

## 设计模式之间的关系

```
创建型模式（如何创建对象）
  ├── Singleton  - 全局唯一实例
  └── Factory    - 解耦对象的创建和使用

结构型模式（如何组合类/对象）  
  ├── Adapter    - 接口转换
  ├── Proxy      - 代理控制访问
  └── Decorator  - 动态添加职责

行为型模式（如何交互和分配职责）
  ├── Observer   - 发布-订阅
  ├── Strategy   - 算法族封装
  └── Command    - 请求封装
```

---

## 最佳实践

1. **优先使用组合而非继承**（Favor composition over inheritance）
2. **遵循 SOLID 原则**
3. **充分利用 C++ 的 RAII 机制**
4. **使用智能指针管理对象生命周期**
5. **不要过度设计**——只在确实需要时使用设计模式
