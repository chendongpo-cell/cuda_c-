/*
 * 文件名: main.cpp
 * 功能:   演示 C++ 文件操作的各种用法
 * 编译:   g++ -std=c++17 main.cpp -o main
 *
 * 包含:
 *   1. 写入文本文件 (ofstream)
 *   2. 按行读取文本文件 (getline)
 *   3. 追加到文件末尾 (app 模式)
 *   4. 二进制写入结构体数据
 *   5. 二进制读取结构体数据
 *   6. 错误检查
 */

#include <iostream>   // 标准输入输出头文件，用于 cout / cerr / endl
#include <fstream>    // 文件流头文件，提供 ifstream / ofstream / fstream
#include <string>     // 字符串头文件，提供 std::string
#include <cstring>    // C 风格字符串头文件，提供 strcpy

using namespace std;  // 使用 std 命名空间，避免每次都写 std::

// 定义一个简单的 Person 结构体，用于二进制读写演示
struct Person {
    char name[32];   // 姓名 (固定长度 C 风格字符串，便于二进制读写)
    int  age;        // 年龄
    double height;   // 身高 (米)
};

// 函数声明: 写入文本文件
void demoWriteText();
// 函数声明: 读取文本文件
void demoReadText();
// 函数声明: 追加到文本文件
void demoAppendText();
// 函数声明: 二进制写入
void demoBinaryWrite();
// 函数声明: 二进制读取
void demoBinaryRead();

int main() {
    // ============ 第1步: 演示写入文本文件 ============
    cout << "=== 1. 写入文本文件 ===" << endl;
    demoWriteText();          // 调用写入文本文件函数

    // ============ 第2步: 演示读取文本文件 ============
    cout << "\n=== 2. 读取文本文件 ===" << endl;
    demoReadText();           // 调用读取文本文件函数

    // ============ 第3步: 演示追加到文件 ============
    cout << "\n=== 3. 追加到文本文件 ===" << endl;
    demoAppendText();         // 调用追加到文件函数

    // ============ 第4步: 演示二进制写入 ============
    cout << "\n=== 4. 二进制写入 ===" << endl;
    demoBinaryWrite();        // 调用二进制写入函数

    // ============ 第5步: 演示二进制读取 ============
    cout << "\n=== 5. 二进制读取 ===" << endl;
    demoBinaryRead();         // 调用二进制读取函数

    return 0;                 // main 函数返回 0，表示程序成功结束
}

// 函数定义: 向文本文件写入内容
void demoWriteText() {
    // 创建一个 ofstream (输出文件流) 对象，打开文件用于写入
    // 默认模式是 ios::out，如果文件已存在则清空
    ofstream fout("students.txt");

    // 检查文件是否成功打开
    if (!fout.is_open()) {               // is_open() 返回 bool，判断文件是否打开成功
        cerr << "错误: 无法创建文件 students.txt!" << endl;  // cerr 是标准错误输出
        return;                          // 打开失败，提前返回
    }

    // 向文件中写入数据
    fout << "姓名: 张三" << endl;         // 使用 << 操作符写入字符串，endl 换行
    fout << "年龄: 20" << endl;           // 可以写入数字，自动转为文本
    fout << "成绩: 95.5" << endl;         // 写入浮点数

    fout << "姓名: 李四" << endl;         // 写入第二条记录
    fout << "年龄: 22" << endl;
    fout << "成绩: 88.0" << endl;

    fout << "姓名: 王五" << endl;         // 写入第三条记录
    fout << "年龄: 21" << endl;
    fout << "成绩: 92.3" << endl;

    // 关闭文件 (显式关闭是个好习惯)
    fout.close();                        // close() 关闭文件，刷新缓冲区

    cout << "成功写入 students.txt" << endl;  // 提示写入成功
}

// 函数定义: 从文本文件按行读取内容
void demoReadText() {
    // 创建一个 ifstream (输入文件流) 对象，打开文件用于读取
    ifstream fin("students.txt");

    // 检查文件是否成功打开
    if (!fin.is_open()) {                // 如果文件不存在或无法打开
        cerr << "错误: 无法打开文件 students.txt!" << endl;
        return;                          // 提前退出函数
    }

    string line;                         // 用于存储每行文本的字符串变量
    int lineNum = 0;                     // 记录行号

    // 使用 getline() 按行读取文件
    // getline(流, 字符串) 读取一行，直到遇到换行符
    // 当到达文件末尾时，getline 返回 false，循环结束
    while (getline(fin, line)) {
        lineNum++;                       // 每读一行，行号加 1
        cout << "第 " << lineNum << " 行: " << line << endl;  // 打印行号和内容
    }

    // 检查是否因为错误而终止
    if (fin.bad()) {                     // bad() 返回 true 表示流已损坏
        cerr << "警告: 读取过程中发生不可恢复的错误!" << endl;
    } else if (fin.eof()) {              // eof() 返回 true 表示正常到达文件末尾
        cout << "已到达文件末尾，共读取 " << lineNum << " 行" << endl;
    } else if (fin.fail()) {             // fail() 返回 true 表示格式错误等
        cerr << "警告: 读取过程中发生格式错误!" << endl;
    }

    fin.close();                         // 关闭文件
}

// 函数定义: 追加内容到文本文件末尾
void demoAppendText() {
    // 使用 ios::app 模式打开文件
    // app = append，写入位置始终在文件末尾，不会清空原有内容
    ofstream fout("students.txt", ios::app);

    // 检查文件是否成功打开
    if (!fout.is_open()) {
        cerr << "错误: 无法打开 students.txt 进行追加!" << endl;
        return;
    }

    // 追加新的数据到文件末尾
    fout << "姓名: 赵六" << endl;         // 在原有内容后追加
    fout << "年龄: 23" << endl;              // 追加年龄
    fout << "成绩: 97.8" << endl;
    fout << "--- 分隔线 ---" << endl;     // 追加一条分隔线

    fout.close();                         // 关闭文件

    cout << "成功追加内容到 students.txt" << endl;
}

// 函数定义: 以二进制格式写入结构体数据
void demoBinaryWrite() {
    // 使用 ios::binary 模式打开文件
    // binary 模式不会对数据进行任何转换，原样写入
    ofstream fout("people.dat", ios::binary);

    // 检查文件是否成功打开
    if (!fout.is_open()) {
        cerr << "错误: 无法创建文件 people.dat!" << endl;
        return;
    }

    // 创建三个 Person 结构体对象
    Person p1;                           // 第一个人
    strcpy(p1.name, "Alice");            // strcpy 复制 C 风格字符串到 name 数组
    p1.age = 25;                         // 设置年龄
    p1.height = 1.68;                    // 设置身高

    Person p2;                           // 第二个人
    strcpy(p2.name, "Bob");
    p2.age = 30;
    p2.height = 1.82;

    Person p3;                           // 第三个人
    strcpy(p3.name, "Charlie");
    p3.age = 28;
    p3.height = 1.75;

    // write(地址, 字节数) — 将内存块原样写入文件
    // reinterpret_cast<const char*>(&p1) 将结构体指针转为 char* 指针
    // sizeof(p1) 返回结构体占用的字节数
    fout.write(reinterpret_cast<const char*>(&p1), sizeof(Person));
    fout.write(reinterpret_cast<const char*>(&p2), sizeof(Person));
    fout.write(reinterpret_cast<const char*>(&p3), sizeof(Person));

    fout.close();                         // 关闭文件

    cout << "成功写入 3 条二进制记录到 people.dat" << endl;
    cout << "每条记录大小: " << sizeof(Person) << " 字节" << endl;
}

// 函数定义: 从二进制文件读取结构体数据
void demoBinaryRead() {
    // 以二进制模式打开文件用于读取
    ifstream fin("people.dat", ios::binary);

    // 检查文件是否成功打开
    if (!fin.is_open()) {
        cerr << "错误: 无法打开文件 people.dat!" << endl;
        return;
    }

    Person p;                            // 用于存储每次读取的人物数据
    int count = 0;                       // 记录读取了多少条记录

    cout << "读取二进制文件内容:" << endl;

    // 循环读取，每次读一个 Person 结构体
    // read(地址, 字节数) 从文件读取指定字节到内存中
    // 当 read 失败 (到达文件末尾) 时循环结束
    while (fin.read(reinterpret_cast<char*>(&p), sizeof(Person))) {
        count++;                         // 成功读取一条记录，计数器加 1
        // 输出读取到的数据
        cout << "  第 " << count << " 条: "
             << "姓名 = " << p.name
             << ", 年龄 = " << p.age
             << ", 身高 = " << p.height << " 米" << endl;
    }

    if (fin.eof()) {                     // 判断是否正常读到文件末尾
        cout << "共读取 " << count << " 条记录" << endl;
    } else if (fin.fail()) {             // 如果没到末尾但读取失败
        cerr << "读取到部分数据后发生错误" << endl;
    }

    fin.close();                         // 关闭文件
}
