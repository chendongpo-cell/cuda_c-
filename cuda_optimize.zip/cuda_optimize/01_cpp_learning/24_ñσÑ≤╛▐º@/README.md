# 24 - 文件操作 (File Operations)

## 概述

C++ 通过标准库 `<fstream>` 提供文件读写功能，包含三个核心类：

| 类 | 用途 |
|---|---|
| `ifstream` | 输入文件流 — 从文件读取数据 |
| `ofstream` | 输出文件流 — 向文件写入数据 |
| `fstream` | 文件流 — 同时支持读写 |

所有文件流类都继承自 `iostream`，因此你可以像使用 `cin`/`cout` 一样使用 `>>` 和 `<<` 操作符。

## 打开与关闭文件

### 打开文件

```cpp
ifstream fin("data.txt");           // 构造时打开
ofstream fout;                      
fout.open("output.txt");            // 先构造，后打开
fstream fio("data.bin", ios::in | ios::out | ios::binary);
```

### 关闭文件

```cpp
fin.close();   // 显式关闭
```

当文件流对象离开作用域时，析构函数会自动关闭文件，但显式关闭是良好习惯。

## 文件模式 (File Modes)

定义在 `std::ios` 命名空间中，可用 `|` 组合：

| 模式 | 作用 |
|---|---|
| `ios::in` | 读模式 |
| `ios::out` | 写模式（默认清空文件） |
| `ios::app` | 追加模式（写入到文件末尾） |
| `ios::ate` | 打开后定位到文件末尾 |
| `ios::trunc` | 清空文件内容 |
| `ios::binary` | 以二进制模式打开 |

### 常见组合

- 文本写入：`ofstream fout("file.txt");` 等价于 `ios::out`
- 文本追加：`ofstream fout("file.txt", ios::app);`
- 二进制读写：`fstream fio("file.bin", ios::in | ios::out | ios::binary);`

## 读取文本文件

### 1. `>>` 操作符 — 按空格/换行分隔

```cpp
string word;
while (fin >> word) { ... }
```

跳过空白字符，适合读取单词或数字。

### 2. `getline()` — 按行读取

```cpp
string line;
while (getline(fin, line)) { ... }
```

保留行内空格，直到遇到换行符。

### 3. `get()` — 按字符读取

```cpp
char ch;
while (fin.get(ch)) { ... }
```

逐个字符读取，包括空白字符。

## 写入文本文件

```cpp
ofstream fout("output.txt");
fout << "Hello, world!" << endl;
fout << "Age: " << 25 << endl;
```

## 二进制文件操作

二进制读写使用 `read()` 和 `write()` 成员函数，参数为 `char*` 指针和字节数：

```cpp
// 写入二进制
struct Person { char name[32]; int age; };
Person p = {"Alice", 30};
ofstream fout("data.bin", ios::binary);
fout.write(reinterpret_cast<const char*>(&p), sizeof(p));

// 读取二进制
ifstream fin("data.bin", ios::binary);
Person p2;
fin.read(reinterpret_cast<char*>(&p2), sizeof(p2));
```

**注意**：二进制文件不可移植（字节序、结构体填充等问题），但在同一平台高效。

## 错误检查

| 方法 | 含义 |
|---|---|
| `fin.good()` | 流状态正常 |
| `fin.fail()` | 上次操作失败（如类型不匹配） |
| `fin.bad()` | 流损坏（不可恢复） |
| `fin.eof()` | 到达文件末尾 |
| `fin.is_open()` | 文件是否成功打开 |

### 推荐的检查模式

```cpp
if (!fin.is_open()) {
    cerr << "无法打开文件！" << endl;
    return;
}
if (fin.fail()) {
    cerr << "读取数据失败！" << endl;
}
```

## 注意事项

1. **路径问题**：Windows 用 `\\` 或 `/`，Linux/macOS 用 `/`
2. **中文字符**：文本文件编码需一致（UTF-8 vs GBK）
3. **二进制兼容性**：不同平台的结构体大小可能不同
4. **资源管理**：RAII 思想 — 让析构函数自动关闭文件
5. **性能**：频繁读写小数据时，考虑使用缓冲区
