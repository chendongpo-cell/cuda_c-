# C++ 面试题 —— 进阶篇

> 对应知识点：模板（第 19 课）+ STL（第 20~22 课）+ 智能指针（第 23 课）+ 文件操作（第 24 课）+ 命名空间/预处理/多线程（第 25~27 课）+ 综合项目（第 36 课）
> 难度：⭐⭐⭐ 适合中级面试

---

## 目录

1. [模板](#1-模板)
2. [STL 容器](#2-stl-容器)
3. [STL 迭代器与算法](#3-stl-迭代器与算法)
4. [Lambda 表达式](#4-lambda-表达式)
5. [智能指针](#5-智能指针)
6. [文件操作](#6-文件操作)
7. [命名空间与预处理](#7-命名空间与预处理)
8. [多线程](#8-多线程)
9. [综合项目实战题](#9-综合项目实战题)

---

## 1. 模板

### 题 1：函数模板和类模板有什么区别？写出一个简单的示例。

**考察点**：模板基础、泛型编程

**参考答案**：

函数模板是对函数的泛化，类模板是对类的泛化。编译器根据实际使用生成具体代码（模板实例化）。

```cpp
// === 函数模板 ===
template <typename T>
T max(T a, T b) {
    return a > b ? a : b;
}

// 使用
int i = max(3, 5);          // T 推导为 int
double d = max(3.14, 2.71); // T 推导为 double
// 显式指定类型
auto s = max<std::string>("hello", "world");

// === 类模板 ===
template <typename T>
class Box {
    T value;
public:
    Box(T v) : value(v) {}
    T get() const { return value; }
    void set(T v) { value = v; }
};

// 使用
Box<int> intBox(42);
Box<std::string> strBox("hello");

// 模板不支持分离编译！
// 模板的声明和实现通常都在 .h 文件中（或 .h + .tpp）
// 因为实例化时需要看到完整定义
```

**提示**：模板的"两阶段编译"——第一阶段检查模板语法但不检查依赖类型的具体操作，第二阶段在实例化时检查具体类型的合法性。

---

### 题 2：什么是模板特化（specialization）和偏特化（partial specialization）？

**考察点**：模板特化、模板偏特化

**参考答案**：

- **全特化（full specialization）**：为某个特定的类型提供专门的实现
- **偏特化（partial specialization）**：限制模板参数的某些特性，但不完全固定（仅类模板支持）

```cpp
// 主模板
template <typename T>
class Box {
public:
    static std::string info() { return "通用版本"; }
};

// 全特化：为 bool 提供专门实现
template <>
class Box<bool> {
public:
    static std::string info() { return "bool 特化版本（压缩存储）"; }
};

// 偏特化：为指针类型提供专门实现（仅类模板支持！函数模板不支持偏特化）
template <typename T>
class Box<T*> {
public:
    static std::string info() { return "指针特化版本"; }
};

// 使用
Box<int>::info();    // "通用版本"
Box<bool>::info();   // "bool 特化版本（压缩存储）"
Box<int*>::info();   // "指针特化版本"

// 函数模板不支持偏特化，但可以用重载达到类似效果
template <typename T>
void func(T t) { /* 通用 */ }

void func(bool t) { /* 函数重载，不是特化 */ }  // OK
```

**提示**：面试中常问"为什么函数模板不支持偏特化？"——因为函数重载已经可以覆盖偏特化的需求，不需要增加语言复杂度。

---

### 题 3：什么是 SFINAE（Substitution Failure Is Not An Error）？

**考察点**：模板元编程、编译期检测

**参考答案**：

SFINAE：在模板参数推导时，如果某个替换导致非法类型/表达式，不视为编译错误，而是将该模板从重载集合中移除。

```cpp
// 典型应用：enable_if
#include <type_traits>

// 只对整数类型启用
template <typename T>
typename std::enable_if<std::is_integral_v<T>, void>::type
printType(T value) {
    std::cout << "整数类型: " << value << std::endl;
}

// 只对浮点类型启用
template <typename T>
typename std::enable_if<std::is_floating_point_v<T>, void>::type
printType(T value) {
    std::cout << "浮点类型: " << value << std::endl;
}

int a = 42;
double b = 3.14;
printType(a);   // 调用第一个版本："整数类型: 42"
printType(b);   // 调用第二个版本："浮点类型: 3.14"

// C++17 之后可以用 if constexpr 替代 SFINAE
template <typename T>
void printTypeV2(T value) {
    if constexpr (std::is_integral_v<T>) {
        std::cout << "整数: " << value << std::endl;
    } else if constexpr (std::is_floating_point_v<T>) {
        std::cout << "浮点: " << value << std::endl;
    } else {
        std::cout << "其他类型" << std::endl;
    }
}
```

**提示**：SFINAE 是模板元编程的基石，`if constexpr`（C++17）在大多数场景可以替代 SFINAE，代码更简洁。

---

## 2. STL 容器

### 题 4：`std::vector` 的扩容机制是怎样的？push_back 的时间复杂度？

**考察点**：vector 内部实现、均摊复杂度

**参考答案**：

```cpp
// vector 在内存中连续存储元素
// 当 capacity 不足时，重新分配更大的内存块，把旧元素搬过去

std::vector<int> v;
std::cout << v.capacity();   // 0
v.push_back(1);              // capacity = 1
v.push_back(2);              // capacity = 2（1→2 扩容）
v.push_back(3);              // capacity = 4（2→4 扩容）
v.push_back(4);              // capacity = 4（不扩容）
v.push_back(5);              // capacity = 8（4→8 扩容）

// 扩容步骤：
// 1. 申请新内存（通常为当前容量的 1.5~2 倍）
// 2. 将旧元素拷贝/移动到新内存
// 3. 销毁旧对象，释放旧内存

// push_back 的均摊（amortized）时间复杂度是 O(1)
// 大多数 push_back 是 O(1)，偶尔扩容是 O(n)，分摊到每次操作依然是 O(1)
```

**重要细节**：
- GCC 的扩容系数是 2（每次翻倍）
- MSVC 的扩容系数是 1.5
- 扩容时如果元素移动构造函数标记为 `noexcept`，会用移动而非拷贝，性能更好
- 可以用 `reserve()` 预分配容量，避免多次扩容

---

### 题 5：`std::vector` 和 `std::list` 各有什么优缺点？如何选择？

**考察点**：序列容器选择、内存布局

**参考答案**：

```cpp
// vector：连续内存，动态数组
std::vector<int> vec = {1, 2, 3, 4, 5};
vec[2];              // O(1)：随机访问
vec.push_back(6);    // O(1) 均摊
vec.insert(vec.begin() + 1, 99);  // O(n)：中间插入需要移动元素

// list：双向链表，不连续内存
std::list<int> lst = {1, 2, 3, 4, 5};
// lst[2];           // 不支持随机访问！没有 operator[]
lst.push_back(6);    // O(1)
auto it = lst.begin();
++it;                // 必须逐个遍历到目标位置
lst.insert(it, 99);  // O(1)：找到位置后，插入本身很快
```

| 特性 | vector | list |
|------|--------|------|
| 内存布局 | 连续 | 节点分散 |
| 随机访问 | O(1) | O(n) |
| 中间插入/删除 | O(n) | O(1)（需找到位置） |
| 两端插入 | O(1) | O(1) |
| 额外开销 | 低 | 高（每个元素多存前后指针） |
| 缓存友好 | 是 | 否 |

**如何选择**：
- 需要随机访问 → `vector`
- 频繁在中间插入/删除 → `list`
- 不确定 → 默认用 `vector`（绝大多数场景它都够用）

---

### 题 6：`std::map` 和 `std::unordered_map` 有什么区别？

**考察点**：有序 vs 无序容器、红黑树 vs 哈希表

**参考答案**：

```cpp
// map：红黑树实现，按键排序
std::map<int, std::string> orderedMap;
orderedMap[3] = "three";
orderedMap[1] = "one";
orderedMap[2] = "two";
for (const auto& [k, v] : orderedMap) {
    std::cout << k << ":" << v << " ";  // 1:one 2:two 3:three（有序！）
}

// unordered_map：哈希表实现，无序
std::unordered_map<int, std::string> hashMap;
hashMap[3] = "three";
hashMap[1] = "one";
hashMap[2] = "two";
for (const auto& [k, v] : hashMap) {
    std::cout << k << ":" << v << " ";  // 顺序不确定（取决于哈希值）
}
```

| 特性 | map | unordered_map |
|------|-----|---------------|
| 底层结构 | 红黑树（平衡二叉搜索树） | 哈希表 |
| 元素有序 | 是（按 key 升序） | 否 |
| 查找 | O(log n) | O(1) 均摊，最坏 O(n) |
| 插入 | O(log n) | O(1) 均摊 |
| 需要 | operator< | 哈希函数 + operator== |
| 内存 | 较少（节点固定开销） | 较多（哈希表 + 链表） |

**如何选择**：
- 需要元素有序（如范围查询、排序遍历）→ `map`
- 只要求按键精确查找 → `unordered_map`（通常更快）
- 自定义类型做 key：`map` 需要 `operator<`，`unordered_map` 需要 `std::hash` 特化

---

### 题 7：迭代器失效的场景有哪些？（以 vector 为例）

**考察点**：迭代器失效、容器操作安全

**参考答案**：

```cpp
std::vector<int> v = {1, 2, 3, 4, 5};

// 场景 1：插入导致扩容 → 所有迭代器失效
auto it = v.begin();       // 指向元素 1
v.push_back(6);            // 可能扩容，it 失效！
// *it;                    // 危险！未定义行为

// 场景 2：中间插入 → 插入点之后的所有迭代器失效
auto it2 = v.begin() + 2;  // 指向元素 3
v.insert(v.begin() + 1, 99);  // 元素后移，it2 失效

// 场景 3：删除元素 → 删除点之后的所有迭代器失效
auto it3 = v.begin() + 1;
v.erase(v.begin());        // it3 失效

// 正确做法：利用返回值更新迭代器
for (auto it = v.begin(); it != v.end(); ) {
    if (*it % 2 == 0) {
        it = v.erase(it);  // erase 返回下一个有效的迭代器
    } else {
        ++it;
    }
}
```

**不同容器的失效规则**：

| 容器 | 插入时 | 删除时 |
|------|--------|--------|
| vector | 全部失效（如果扩容） | 删除点之后失效 |
| list | 不失效 | 仅被删元素失效 |
| map/unordered_map | 不失效 | 仅被删元素失效 |
| deque | 两端不失效 | 两端不失效 |

---

### 题 8：`std::array` 和 C 风格数组有什么区别？

**考察点**：现代 C++ 数组、安全封装

**参考答案**：

```cpp
// C 风格数组
int arr1[5] = {1, 2, 3, 4, 5};
int size1 = sizeof(arr1) / sizeof(arr1[0]);  // 需要手动算大小
// arr1 传递给函数时会退化为指针

// std::array（C++11）
#include <array>
std::array<int, 5> arr2 = {1, 2, 3, 4, 5};
arr2.size();                      // 直接获取大小
arr2.at(10);                      // 越界检查（抛出异常）
arr2[2];                          // 不检查越界（速度快）

// 可以复制
std::array<int, 5> arr3 = arr2;   // OK！C 风格数组不能直接复制

// 作为参数时保持大小信息
void processArray(const std::array<int, 5>& arr);  // 类型自带大小
void processCArray(int* arr, int size);             // 需要额外传大小
```

| 特性 | C 风格数组 | std::array |
|------|-----------|------------|
| 大小 | 编译期固定 | 编译期固定 |
| 可复制 | 否 | 是 |
| 退化为指针 | 是 | 否 |
| 越界检查 | 无 | at() 有 |
| 迭代器支持 | 无 | 有 |
| 性能 | 无额外开销 | 无额外开销！ |

**提示**：`std::array` 和 C 风格数组的性能完全相同（没有堆分配开销），但更安全、更方便。

---

## 3. STL 迭代器与算法

### 题 9：STL 迭代器有哪些类型？它们之间的关系是什么？

**考察点**：迭代器分类、层次结构

**参考答案**：

STL 迭代器分为 5 类，从弱到强：

```
输入迭代器 ← 前向迭代器 ← 双向迭代器 ← 随机访问迭代器
输出迭代器 ← 前向迭代器 ← 双向迭代器 ← 随机访问迭代器
                                        ↓
                                   连续迭代器（C++17）
```

| 迭代器类型 | 支持的操作 | 示例容器 |
|-----------|-----------|---------|
| 输入迭代器 | 只读、++ | 从 cin 读数据 |
| 输出迭代器 | 只写、++ | 写入 cout |
| 前向迭代器 | 读写、++ | forward_list |
| 双向迭代器 | 读写、++/-- | list、set、map |
| 随机访问迭代器 | 读写、++/--、+、-、[] | vector、deque、array |

```cpp
// 不同容器提供的迭代器类型
std::vector<int>::iterator it1;           // 随机访问
std::map<int, int>::iterator it2;         // 双向
std::list<int>::iterator it3;             // 双向
std::forward_list<int>::iterator it4;     // 前向

// 根据迭代器类型选择合适的算法
std::sort(v.begin(), v.end());            // sort 需要随机访问迭代器
// std::sort(l.begin(), l.end());         // 编译错误！list 没有随机访问迭代器
l.sort();                                  // list 有自己的 sort 方法
```

---

### 题 10：`std::sort` 的底层实现是什么？什么容器不能使用 `std::sort`？

**考察点**：排序算法、迭代器要求

**参考答案**：

`std::sort` 通常实现为 **IntroSort**（内省排序）—— 一种混合排序算法：

1. 快速排序（quicksort）为主——平均 O(n log n)
2. 递归深度超过 log n 时切换到堆排序（heapsort）——避免快排退化到 O(n²)
3. 当子数组长度小于某个阈值（通常是 16）时，用插入排序（insertionsort）——小数组更高效

```cpp
#include <algorithm>
#include <vector>

// 默认升序
std::vector<int> v = {5, 3, 1, 4, 2};
std::sort(v.begin(), v.end());       // → {1, 2, 3, 4, 5}

// 降序
std::sort(v.begin(), v.end(), std::greater<int>());

// 自定义比较（Lambda）
std::sort(v.begin(), v.end(),
    [](int a, int b) { return a > b; });

// 不能使用 std::sort 的容器：
std::list<int> lst = {5, 3, 1, 4, 2};
// std::sort(lst.begin(), lst.end());  // 编译错误！list 是双向迭代器
lst.sort();                            // list 有自己的 sort 方法（归并排序）
```

**排序要求**：
- 需要随机访问迭代器（`vector`、`deque`、`array` 可以，`list`、`forward_list` 不行）
- 不稳定的排序（相等元素不保证保持原顺序）
- 需要 `operator<` 或自定义比较器

---

### 题 11：`std::find` 和 `std::binary_search` / `std::lower_bound` 有什么区别？

**考察点**：线性查找 vs 二分查找、算法选择

**参考答案**：

```cpp
#include <algorithm>
#include <vector>

std::vector<int> v = {1, 3, 5, 7, 9, 11};

// std::find —— 线性查找，O(n)
auto it = std::find(v.begin(), v.end(), 5);
if (it != v.end()) {
    std::cout << "找到: " << *it << std::endl;
}
// 不需要排序，适用于任何容器

// std::binary_search —— 二分查找，O(log n)，但要求排序！
bool found = std::binary_search(v.begin(), v.end(), 5);
// 要求：范围已排序（否则结果未定义）

// std::lower_bound —— 二分查找第一个 >= 目标的位置
auto lb = std::lower_bound(v.begin(), v.end(), 5);
// lb 指向第一个 >= 5 的元素（即 5 本身）
if (lb != v.end() && *lb == 5) {
    std::cout << "找到元素 5" << std::endl;
}

// std::upper_bound —— 第一个 > 目标的位置
auto ub = std::upper_bound(v.begin(), v.end(), 5);
// ub 指向 7
```

| 算法 | 时间复杂度 | 要求排序 | 用途 |
|------|-----------|---------|------|
| find | O(n) | 否 | 少量数据/未排序数据 |
| binary_search | O(log n) | 是 | 判断元素是否存在 |
| lower_bound | O(log n) | 是 | 找到插入位置/范围查询 |
| upper_bound | O(log n) | 是 | 范围上界 |

---

## 4. Lambda 表达式

### 题 12：Lambda 表达式的语法是什么？捕获列表中的 `[]`、`[=]`、`[&]` 分别表示什么？

**考察点**：Lambda 语法、捕获方式

**参考答案**：

```cpp
// Lambda 的基本语法：
// [捕获列表](参数列表) -> 返回值类型 { 函数体 }

// 各种捕获方式：
int x = 10, y = 20;

auto l1 = []() { return 42; };         // 不捕获任何外部变量
auto l2 = [x]() { return x; };         // 按值捕获 x（只读）
auto l3 = [&x]() { x++; };             // 按引用捕获 x（可修改）
auto l4 = [=]() { return x + y; };     // 按值捕获所有外部变量
auto l5 = [&]() { x++; y++; };         // 按引用捕获所有外部变量
auto l6 = [=, &y]() { return x + y; }; // y 按引用，其他按值
auto l7 = [&, x]() { y += x; };        // x 按值，其他按引用
auto l8 = [x, y]() mutable { x++; y++; }; // 按值但允许修改（修改的是副本）

// 应用：按工资排序
std::sort(employees.begin(), employees.end(),
    [](const Employee& a, const Employee& b) {
        return a.calcSalary() > b.calcSalary();  // 降序
    }
);

// 应用：按类型过滤
auto typeFilter = [&type](const auto& emp) {
    return emp->getType() == type;
};
```

**提示**：按值捕获的变量在 Lambda 对象创建时就完成了复制（快照），按引用捕获则是在调用时读取实际值。

---

### 题 13：Lambda 表达式和函数对象（functor）有什么关系？

**考察点**：可调用对象、语法糖

**参考答案**：

Lambda 本质上是**匿名函数对象的语法糖**——编译器会将每个 Lambda 转换为一个独一无二的函数对象（functor）。

```cpp
// Lambda 形式
auto isEven = [](int n) { return n % 2 == 0; };

// 等价于编译器生成的函数对象：
class SomeUniqueName {
public:
    bool operator()(int n) const {
        return n % 2 == 0;
    }
};
SomeUniqueName isEven;

// 带捕获的 Lambda
int threshold = 10;
auto isAbove = [threshold](int n) { return n > threshold; };

// 等价于：
class AnotherName {
    int threshold;      // 捕获的变量成为成员
public:
    AnotherName(int t) : threshold(t) {}
    bool operator()(int n) const {
        return n > threshold;
    }
};
AnotherName isAbove(threshold);

// 使用场景对比
std::vector<int> v = {1, 2, 3, 4, 5, 6};

// Lambda（简洁）
v.erase(std::remove_if(v.begin(), v.end(),
    [](int n) { return n % 2 == 0; }
), v.end());

// 传统函数对象（冗长）
struct IsEven {
    bool operator()(int n) const { return n % 2 == 0; }
};
v.erase(std::remove_if(v.begin(), v.end(), IsEven()), v.end());
```

**提示**：C++11 之前没有 Lambda，都用函数对象。Lambda 的引入大大简化了 STL 算法的使用。

---

## 5. 智能指针

### 题 14：`std::unique_ptr`、`std::shared_ptr`、`std::weak_ptr` 分别是什么？各自的应用场景？

**考察点**：智能指针、所有权语义

**参考答案**：

```cpp
// === unique_ptr：独占所有权 ===
// 轻量级、无额外开销、不能拷贝（可以移动）
std::unique_ptr<int> up1 = std::make_unique<int>(42);
// std::unique_ptr<int> up2 = up1;     // 编译错误！不能拷贝
std::unique_ptr<int> up3 = std::move(up1);  // 可以移动，转移所有权
// up1 现在是 nullptr

// 典型场景：工厂函数返回独占资源
std::unique_ptr<Employee> createEmployee(const std::string& type) {
    if (type == "正式员工") {
        return std::make_unique<FullTimeEmployee>(...);
    }
    return nullptr;
}

// === shared_ptr：共享所有权 ===
// 引用计数管理（额外开销：控制块）
std::shared_ptr<Employee> sp1 = std::make_shared<FullTimeEmployee>(...);
{
    std::shared_ptr<Employee> sp2 = sp1;  // 引用计数 +1
    // sp1.use_count() == 2
}
// sp2 离开作用域，引用计数 -1，sp1.use_count() == 1

// 典型场景：多个消费者共享同一资源
std::vector<std::shared_ptr<Employee>> employees;
employees.push_back(sp1);  // 引用计数 +1

// === weak_ptr：弱引用，解决循环引用 ===
// 不增加引用计数，不能直接访问，需要 lock() 获取 shared_ptr
std::weak_ptr<Employee> wp = sp1;
if (auto locked = wp.lock()) {  // 检查对象是否还存在
    locked->displayInfo();
} else {
    std::cout << "对象已释放" << std::endl;
}

// 典型场景：父子关系中，父持有子的 shared_ptr，子持有父的 weak_ptr
// 避免循环引用导致内存泄漏
```

**性能对比**：
| 智能指针 | 大小 | 开销 | 适用 |
|---------|------|------|------|
| unique_ptr | 8 字节（64位） | 无（与裸指针相同） | 独占所有权 |
| shared_ptr | 16 字节 | 控制块（引用计数等） | 共享所有权 |
| weak_ptr | 16 字节 | 与控制块关联 | 打破循环引用 |

---

### 题 15：`make_shared` 和直接 `new` 创建 shared_ptr 有什么区别？

**考察点**：内存分配、性能、异常安全

**参考答案**：

```cpp
// 方式一：直接 new + shared_ptr 构造
std::shared_ptr<Employee> sp1(new FullTimeEmployee("张三", 8000, 2000));

// 方式二：make_shared（推荐）
auto sp2 = std::make_shared<FullTimeEmployee>("张三", 8000, 2000);
```

| 对比项 | make_shared | new + shared_ptr |
|-------|-------------|-----------------|
| 内存分配 | 1 次（对象 + 控制块一起） | 2 次（对象 + 控制块分开） |
| 内存效率 | 更高（控制块和对象在同一内存块） | 较低 |
| 异常安全 | 安全 | 不安全（见下方说明） |
| 自定义 deleter | 不支持 | 支持 |

```cpp
// 异常安全问题
processEmployees(
    std::shared_ptr<Employee>(new FullTimeEmployee("张三", 8000, 2000)),
    std::shared_ptr<Employee>(new PartTimeEmployee("李四", 50, 80))
);
// 如果 new PartTimeEmployee 抛出异常，先 new 的 FullTimeEmployee 会泄露！
// make_shared 不会有这个问题
```

---

### 题 16：什么是循环引用？如何用 weak_ptr 解决？

**考察点**：循环引用、内存泄漏

**参考答案**：

```cpp
// 循环引用示例：两个对象互相持有 shared_ptr
struct Node {
    std::shared_ptr<Node> next;
    ~Node() { std::cout << "Node 析构" << std::endl; }
};

auto a = std::make_shared<Node>();
auto b = std::make_shared<Node>();
a->next = b;    // b 引用计数 = 2（a->next + b）
b->next = a;    // a 引用计数 = 2（b->next + a）
// 离开作用域时：
// a 销毁 → a 引用计数 = 1（b->next 还在）
// b 销毁 → b 引用计数 = 1（a->next 还在）
// 引用计数永远到不了 0！内存泄漏！

// 解决方案：将其中一个改为 weak_ptr
struct SafeNode {
    std::shared_ptr<SafeNode> next;
    std::weak_ptr<SafeNode> prev;  // 使用 weak_ptr
    ~SafeNode() { std::cout << "SafeNode 析构" << std::endl; }
};

auto c = std::make_shared<SafeNode>();
auto d = std::make_shared<SafeNode>();
c->next = d;    // d 引用计数 = 1
d->prev = c;    // c 引用计数 = 1（weak_ptr 不增加引用计数！）
// 离开作用域时都可以正确析构
```

**提示**：实际项目中典型的循环引用场景是"父子结构"——父对象持有子的 `shared_ptr`，子对象持有父的 `weak_ptr`。

---

## 6. 文件操作

### 题 17：C++ 中文件读写的基本流程是什么？`ifstream` 和 `ofstream` 如何使用？

**考察点**：文件流、状态检查、异常处理

**参考答案**：

```cpp
#include <fstream>
#include <iostream>
#include <string>

// === 写入文件 ===
void writeToFile(const std::string& filename) {
    std::ofstream outFile(filename);  // 创建 ofstream，默认覆盖模式
    
    if (!outFile.is_open()) {         // 检查文件是否成功打开
        std::cerr << "无法打开文件: " << filename << std::endl;
        return;
    }
    
    outFile << "Hello, World!" << std::endl;
    outFile << 42 << " " << 3.14 << std::endl;
    // ofstream 析构时自动关闭文件（RAII）
}

// === 读取文件 ===
void readFromFile(const std::string& filename) {
    std::ifstream inFile(filename);
    
    if (!inFile) {                    // ifstream 也支持 operator bool
        std::cerr << "无法打开文件" << std::endl;
        return;
    }
    
    std::string line;
    while (std::getline(inFile, line)) {  // 逐行读取
        std::cout << line << std::endl;
    }
    
    if (inFile.bad()) {               // 发生严重错误（非 EOF）
        std::cerr << "读取文件时发生错误" << std::endl;
    }
}

// === 文件打开模式 ===
// std::ios::in     —— 读取（ifstream 默认）
// std::ios::out    —— 写入（ofstream 默认，覆盖）
// std::ios::app    —— 追加写入
// std::ios::binary —— 二进制模式
// std::ios::trunc  —— 写入前清空文件
std::ofstream logFile("log.txt", std::ios::app);  // 追加模式
```

**文件状态检查**：
| 方法 | 含义 |
|------|------|
| `is_open()` | 文件是否成功打开 |
| `good()` | 流状态是否正常 |
| `fail()` | 上次操作是否失败（如类型不匹配） |
| `bad()` | 是否发生严重错误 |
| `eof()` | 是否到达文件末尾 |
| `clear()` | 重置流状态 |

---

### 题 18：二进制文件和文本文件读写的区别？

**考察点**：文本模式 vs 二进制模式

**参考答案**：

```cpp
#include <fstream>

// 文本模式写入（默认）
std::ofstream txtOut("data.txt");
txtOut << 1000;  // 写入字符 "1000" → 4 个字节
// 数字 1000 被转换成字符串 "1000"

// 二进制模式写入
std::ofstream binOut("data.bin", std::ios::binary);
int value = 1000;
binOut.write(reinterpret_cast<const char*>(&value), sizeof(value));
// 直接写入内存中的二进制表示 → 4 个字节（与内存一致）

// 二进制读取
std::ifstream binIn("data.bin", std::ios::binary);
int readValue;
binIn.read(reinterpret_cast<char*>(&readValue), sizeof(readValue));
std::cout << readValue;  // 1000

// 二进制模式下，换行符不会转换（\n 保持为 \n）
// 文本模式下，Windows 上的 \n 可能被转换为 \r\n
```

| 特性 | 文本模式 | 二进制模式 |
|------|---------|-----------|
| 数据格式 | 可读的字符序列 | 内存中的原始字节 |
| 换行符 | 平台相关（\n → \r\n） | 不转换 |
| 适合 | 配置文件、日志、CSV | 图片、压缩包、序列化数据 |
| 操作 | `>>`、`<<`、`getline` | `read`、`write` |

---

## 7. 命名空间与预处理

### 题 19：头文件保护宏 `#ifndef` / `#define` / `#endif` 的作用是什么？`#pragma once` 有什么区别？

**考察点**：头文件保护、预处理

**参考答案**：

两种方式都防止头文件被多次包含导致重复定义错误。

```cpp
// 方式一：传统宏保护
#ifndef EMPLOYEE_H        // 如果未定义 EMPLOYEE_H
#define EMPLOYEE_H        // 定义 EMPLOYEE_H

class Employee { ... };

#endif                    // 结束条件编译

// 方式二：#pragma once（更简洁）
#pragma once               // 编译器保证只包含一次

class Employee { ... };
```

| 特性 | #ifndef/#define/#endif | #pragma once |
|------|----------------------|-------------|
| 标准化 | 是（C++ 标准） | 否（编译器扩展） |
| 通用性 | 所有编译器 | 主流编译器都支持（GCC/Clang/MSVC） |
| 出错几率 | 可能拼写宏名、重复 | 不可能出错 |
| 复杂场景 | 可做条件编译 | 不能 |

**提示**：现代 C++ 项目大多使用 `#pragma once`，因为它更简单。但在需要最大移植性时使用传统宏保护。

---

### 题 20：`static` 关键字在 C++ 中有哪些不同含义？

**考察点**：static 的多重含义、作用域

**参考答案**：

`static` 在 C++ 中有 4 种不同用法：

```cpp
// 1. 静态局部变量：函数调用间保持值不变
void counter() {
    static int count = 0;    // 只初始化一次
    count++;
    std::cout << count;
}
counter();  // 输出 1
counter();  // 输出 2（值跨函数调用保持）

// 2. 静态全局变量/函数：只在当前 .cpp 文件可见（内部链接）
// file1.cpp
static int fileLocalVar = 42;   // 其他 .cpp 不可见

// 3. 静态成员变量：属于类，不属于对象
class Employee {
    static int nextId;          // 声明
    int id;
};
int Employee::nextId = 1000;    // 必须在 .cpp 中定义

// 4. 静态成员函数：不依赖对象实例，只能访问静态成员
class Math {
public:
    static double sqrt(double x) { return std::sqrt(x); }
};
Math::sqrt(9.0);  // 无需对象，直接通过类名调用
```

**提示**：C++11 之后，可以用 `inline` 静态变量（`inline static int nextId = 1000;`，C++17）直接在头文件中定义。

---

## 8. 多线程

### 题 21：C++11 中如何创建和启动线程？`std::thread` 的基本用法是什么？

**考察点**：线程创建、可调用对象

**参考答案**：

```cpp
#include <thread>
#include <iostream>

// 方式一：传入函数
void worker(int id) {
    std::cout << "线程 " << id << " 开始工作" << std::endl;
}

// 方式二：传入 Lambda
std::thread t2([]() {
    std::cout << "Lambda 线程" << std::endl;
});

// 方式三：传入函数对象
class Task {
public:
    void operator()(int n) {
        std::cout << "Task with " << n << std::endl;
    }
};

int main() {
    std::thread t1(worker, 1);       // 启动线程执行 worker(1)
    std::thread t3(Task(), 42);       // 启动线程执行临时对象的 operator()
    
    // 必须选择 join 或 detach！
    t1.join();    // 等待 t1 完成（阻塞）
    t2.join();
    t3.join();
    // 或者 t1.detach();  // 让线程后台运行（不再可控）
    
    return 0;
} // 如果 thread 析构时既没 join 也没 detach，程序会终止！
```

**注意事项**：
- 线程函数通过值传递参数：即使参数是引用，也会被复制。需要用 `std::ref` 传递引用
- `thread` 对象销毁前必须 `join()` 或 `detach()`，否则 `std::terminate()` 被调用
- 线程数量不应超过 `std::thread::hardware_concurrency()`（硬件支持的并发线程数）

---

### 题 22：什么是数据竞争？如何用 `std::mutex` 保护共享数据？

**考察点**：线程安全、互斥锁、RAII 锁

**参考答案**：

```cpp
#include <thread>
#include <mutex>
#include <vector>

// 共享数据
int counter = 0;
std::mutex mtx;  // 互斥锁

void unsafeIncrement() {
    for (int i = 0; i < 100000; ++i) {
        counter++;  // 数据竞争！多个线程同时读写 counter
    }
}

void safeIncrement() {
    for (int i = 0; i < 100000; ++i) {
        // 方式一：手动 lock/unlock（不推荐，容易忘记 unlock）
        mtx.lock();
        counter++;
        mtx.unlock();
        
        // 方式二：lock_guard（推荐，RAII 自动解锁）
        std::lock_guard<std::mutex> lock(mtx);
        counter++;
    }  // lock_guard 析构时自动释放锁
}

// 更灵活的场景：unique_lock（支持手动解锁、延迟加锁）
void flexibleLock() {
    std::unique_lock<std::mutex> lock(mtx);  // 自动加锁
    // ... 对共享数据的操作 ...
    lock.unlock();  // 提前解锁，让其他线程执行
    // ... 不需要锁的操作 ...
    lock.lock();    // 再次加锁
}
```

**提示**：优先使用 `std::lock_guard`（简单场景）或 `std::unique_lock`（需要灵活控制时），避免直接调 `lock()`/`unlock()`。

---

### 题 23：什么是死锁？如何避免？

**考察点**：死锁条件、预防策略

**参考答案**：

死锁：两个或多个线程互相等待对方释放资源，导致所有相关线程都永远阻塞。

```cpp
std::mutex mtx1, mtx2;

// 死锁场景：两个线程以不同顺序加锁
void thread1() {
    std::lock_guard<std::mutex> lock1(mtx1);
    // ... 一些工作 ...
    std::lock_guard<std::mutex> lock2(mtx2);  // 等待 mtx2
    // 如果 thread2 已锁住 mtx2 在等待 mtx1 → 死锁！
}

void thread2() {
    std::lock_guard<std::mutex> lock2(mtx2);
    // ... 一些工作 ...
    std::lock_guard<std::mutex> lock1(mtx1);  // 等待 mtx1
    // 如果 thread1 已锁住 mtx1 在等待 mtx2 → 死锁！
}

// 解决方案一：固定加锁顺序（总是先锁 mtx1 再锁 mtx2）
void safeThread2() {
    std::lock_guard<std::mutex> lock1(mtx1);  // 先锁 mtx1
    std::lock_guard<std::mutex> lock2(mtx2);  // 再锁 mtx2
    // 与 thread1 顺序一致，不会死锁
}

// 解决方案二：std::lock 同时锁多个（C++11）
void safeLock() {
    std::lock(mtx1, mtx2);  // 同时锁住两个互斥量
    std::lock_guard<std::mutex> lock1(mtx1, std::adopt_lock);  // 接管锁
    std::lock_guard<std::mutex> lock2(mtx2, std::adopt_lock);
    // 已经锁住，lock_guard 只负责解锁
}
```

---

### 题 24：`std::atomic` 是什么？什么场景下可以替代 mutex？

**考察点**：原子操作、CAS、锁自由编程

**参考答案**：

`std::atomic` 提供不可中断的原子操作，对简单类型的并发访问比 mutex 更高效。

```cpp
#include <atomic>
#include <thread>

// 使用 atomic 替代 mutex
std::atomic<int> counter{0};  // 原子变量

void increment() {
    for (int i = 0; i < 100000; ++i) {
        counter++;  // 原子操作，无数据竞争
    }
}

// 更复杂的原子操作
std::atomic<int> value{10};

int expected = 10;
int desired = 20;
// CAS（Compare-And-Swap）：如果当前值 == expected，设为 desired
bool success = value.compare_exchange_weak(expected, desired);

// 原子操作 vs mutex
```

| 特性 | std::atomic | std::mutex |
|------|-------------|------------|
| 开销 | 极低（CPU 指令级） | 较高（系统调用） |
| 适用数据 | 简单类型（int、bool、指针等） | 任意类型和复杂操作 |
| 多变量原子性 | 不支持 | 支持（一个锁保护多个变量） |

**提示**：对于简单的计数器、标志位、共享指针等，用 `atomic`；对于复杂数据结构或需要多步一致操作时，用 `mutex`。

---

## 9. 综合项目实战题

### 题 25：在员工管理系统中，为什么要用 `shared_ptr` 而不是裸指针管理员工对象？

**考察点**：智能指针与裸指针权衡、多态容器

**参考答案**：

```cpp
// 员工管理系统中的核心数据结构：
std::vector<std::shared_ptr<Employee>> employees;
std::map<int, std::shared_ptr<Employee>> employeeIndex;

// 如果用裸指针：
// std::vector<Employee*> employees;
// 问题：
// 1. 谁负责 delete？加入 vector 的人？从 vector 移除的人？
// 2. 如果抛异常，delete 可能永远不会执行
// 3. map 中存储同样的裸指针，删除时需要确保两边同步

// 用 shared_ptr 的优势：
// 1. 自动内存管理——最后一个 shared_ptr 销毁时自动释放
// 2. 多态支持——通过基类指针管理派生类对象
// 3. 索引与容器共享所有权——vector 和 map 各持一个 shared_ptr
// 4. 异常安全——RAII 机制保证异常发生时资源不泄露

// 为什么不直接存对象（std::vector<Employee>）？
// - 对象切片（object slicing）：存储 Employee 会丢失派生类信息
// - 需要多态行为，必须通过指针/引用操作
```

---

### 题 26：员工管理系统中 `FileManager::createEmployee` 用到了什么设计模式？有什么好处？

**考察点**：静态工厂方法、设计模式的识别

**参考答案**：

```cpp
class FileManager {
public:
    // 静态工厂方法（Static Factory Method）
    static std::shared_ptr<Employee> createEmployee(
        const std::string& type,
        const std::vector<std::string>& fields)
    {
        if (type == "正式员工") {
            return std::make_shared<FullTimeEmployee>(
                fields[2],                     // name
                std::stod(fields[3]),          // baseSalary
                std::stod(fields[4])           // bonus
            );
        } else if (type == "兼职员工") {
            return std::make_shared<PartTimeEmployee>(
                fields[2],                     // name
                std::stod(fields[4]),          // hourlyRate
                std::stoi(fields[5])           // hoursWorked
            );
        } else if (type == "经理") {
            return std::make_shared<Manager>(
                fields[2],                     // name
                std::stod(fields[3]),          // baseSalary
                fields[4],                     // department
                std::stoi(fields[5]),          // teamSize
                std::stod(fields[6])           // performanceBonus
            );
        }
        return nullptr;
    }
};
```

**好处**：
1. **封装对象创建逻辑**——所有派生类的创建集中在一处
2. **调用方不依赖具体类型**——只需提供类型名称字符串
3. **新增类型只需加一个分支**——符合开闭原则的"对扩展开放"
4. **与多态配合**——返回基类指针，调用方统一处理

---

### 题 27：员工管理系统中的文件读写存在哪些异常风险？如何保证数据不丢失？

**考察点**：异常、数据完整性、防御性编程

**参考答案**：

```cpp
// 异常风险分析：
// 1. 文件打不开——权限不足、磁盘路径不存在
// 2. 写入中断——磁盘空间满、写入过程中程序崩溃
// 3. 格式错误——文件损坏、手动修改导致的格式不合法
// 4. 数值转换异常——std::stod 遇到非数字字符串

// 防御措施（FileManager 中的实现）：
bool FileManager::saveAll(const std::vector<std::shared_ptr<Employee>>& employees) {
    std::ofstream outFile(filePath);
    if (!outFile.is_open()) {
        std::cerr << "无法打开文件进行写入" << std::endl;
        return false;
    }

    try {
        for (const auto& emp : employees) {
            emp->saveToFile(outFile persons);  // 多态写入
        }

        if (outFile.good()) {
            return true;
        }
        return false;
    }
    catch (const std::exception& e) {
        std::cerr << "保存异常: " << e.what() << std::endl;
        return false;
    }
}

// 更健壮的方案（可选的改进）：
// 1. 先写入临时文件，写入成功后再重命名
//    → 防止写入过程中崩溃导致原文件损坏
// 2. 定期自动保存
// 3. 写入后读回验证（checksum/文件大小检查）
```

---

### 题 28：项目中用到了多种 STL 容器（vector、map），各承担什么角色？为什么选择它们？

**考察点**：容器选择、权衡

**参考答案**：

```cpp
class EmployeeManager {
private:
    // 1. std::vector —— 主存储容器
    // 选择原因：
    //   - 保证插入顺序
    //   - 内存连续、缓存友好
    //   - 遍历效率最高
    //   - range-based for 自然支持
    std::vector<std::shared_ptr<Employee>> employees;

    // 2. std::map —— ID 索引
    // 选择原因：
    //   - O(log n) 的 ID 查找（vs vector 的 O(n)遍历）
    //   - 自动按 ID 排序
    //   - 红黑树平衡保证稳定性能
    std::map<int, std::shared_ptr<Employee>> employeeIndex;

public:
    // 查找时用 map
    std::shared_ptr<Employee> findById(int id) {
        auto it = employeeIndex.find(id);
        return it != employeeIndex.end() ? it->second : nullptr;
    }

    // 遍历时用 vector
    void displayAll() const {
        for (const auto& emp : employees) {
            emp->displayInfo();
        }
    }
};

// 能否统一用一种容器？
// 只用 vector：findById 需要 O(n) 遍历，员工多时性能差
// 只用 map：失去插入顺序，遍历时不是添加顺序
// 所以：vector（主存储，保序）+ map（索引，加速查找）= 两者优点兼得
```

---

### 题 29：项目中的多态是如何实现的？如果新增一种员工类型需要修改哪些代码？

**考察点**：多态、开闭原则、可扩展性

**参考答案**：

```cpp
// 当前体系：
// Employee（抽象基类）
//   ├── FullTimeEmployee
//   ├── PartTimeEmployee
//   └── Manager

// 多态调用点（以下代码无需修改）：
// 1. displayAll() 中调用 emp->displayInfo()
// 2. 工资统计中调用 emp->calcSalary()
// 3. sortBySalary() 中比较 emp->calcSalary()
// 4. saveToFile() 中调用 emp->saveToFile(outFile)

// 如果要新增一种员工类型（如 Intern），需要修改：
// 1. 新建 Intern.h 和 Intern.cpp（继承 Employee，实现所有纯虚函数）—— 正常开发
// 2. FileManager::createEmployee 中增加 "实习生" 分支 —— 需要修改
// 3. 如果有类型选择菜单，菜单中增加选项 —— 可选

// 新增 Intern 后，所有多态调用点自动生效：
// emp->calcSalary()      → Intern 的计算逻辑
// emp->displayInfo()     → Intern 的显示格式
// emp->getType()         → "实习生"
```

**结论**：系统设计遵循了**开闭原则**——对扩展开放（新增 Intern 容易），对修改封闭（已有代码几乎不用改）。

---

### 题 30：项目中用了哪些 C++11/14/17 特性？

**考察点**：现代 C++ 特性的实际应用

**参考答案**：

| 特性 | 使用位置 | 作用 |
|------|---------|------|
| `auto` 类型推导 | EmployeeManager 中大量使用 | 简化迭代器、Lambda 参数类型 |
| `override` | 所有派生类 | 显式标记重写，编译器检查 |
| `nullptr` | findById 返回值 | 替代 NULL |
| 智能指针（shared_ptr） | 整个项目 | 自动内存管理 |
| 范围 for 循环 | displayAll、findByName | 简洁遍历容器 |
| Lambda 表达式 | displayByType、sortBySalary | 过滤条件、比较函数 |
| `= default` | 虚析构函数 | 明确表示采用编译器默认实现 |
| `noexcept` | （建议使用） | 移动操作的安全保证 |
| `constexpr` | （建议使用） | 编译期常量 |

```cpp
// 项目中体现的具体代码：

// auto + range-based for
for (const auto& emp : employees) {
    emp->displayInfo();
}

// Lambda + std::sort
std::sort(employees.begin(), employees.end(),
    [](const auto& a, const auto& b) {
        return a->calcSalary() > b->calcSalary();
    }
);

// Lambda + filter
auto typeFilter = [&type](const auto& emp) {
    return emp->getType() == type;
};

// shared_ptr + make_shared
employees.push_back(std::make_shared<FullTimeEmployee>("张三", 8000, 2000));

// override 关键字
double calcSalary() const override;
void displayInfo() const override;
```

---

> 进阶篇结束，现代特性与工程篇请移步 [C++_面试题_现代特性与工程篇.md](C++_面试题_现代特性与工程篇.md)
