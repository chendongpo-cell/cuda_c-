// 12_构造函数与析构函数 / main.cpp
// 本程序演示 C++ 中构造函数与析构函数的基本用法

// 包含输入输出流头文件
#include <iostream>
// 包含字符串头文件
#include <string>
// 使用标准命名空间
using namespace std;

// 定义一个名为 Person 的类，用于演示构造函数和析构函数
class Person {
// private 成员只能在类内部访问
private:
    // 私有成员变量：姓名
    string name;
    // 私有成员变量：年龄
    int age;

// public 成员可以在类外部访问
public:
    // ---- 构造函数 ----

    // 默认构造函数：没有参数，在创建对象时自动调用
    // 如果没有定义任何构造函数，编译器会自动生成一个默认构造函数
    Person() {
        // 设置默认值
        name = "未知";
        age = 0;
        // 输出提示信息，让我们可以看到构造函数被调用了
        cout << "调用默认构造函数：Person()" << endl;
    }

    // 带参构造函数：接受两个参数，用于初始化成员变量
    // 构造函数的参数列表可以为成员变量提供初始值
    Person(string n, int a) {
        // 将参数值赋给成员变量
        name = n;
        age = a;
        // 输出提示信息
        cout << "调用带参构造函数：Person(string, int) -- " << name << endl;
    }

    // 拷贝构造函数：用已有的 Person 对象来初始化新对象
    // 参数是 const 引用，避免修改原对象，同时避免无限递归
    Person(const Person& other) {
        // 从其他对象拷贝数据
        name = other.name;
        age = other.age;
        // 输出提示信息
        cout << "调用拷贝构造函数：拷贝 " << other.name << endl;
    }

    // ---- 析构函数 ----

    // 析构函数：在对象销毁时自动调用
    // 函数名是 "~" 加类名，没有参数，没有返回值
    // 一个类只能有一个析构函数
    ~Person() {
        // 输出提示信息，让我们可以看到析构函数被调用了
        cout << "调用析构函数：销毁 " << name << " 的对象" << endl;
    }

    // ---- 成员函数 ----

    // 设置姓名
    void setName(string n) {
        name = n;
    }

    // 获取姓名（const 方法，保证可以被 const 对象调用）
    string getName() const {
        return name;
    }

    // 显示个人信息（const 方法）
    void introduce() const {
        cout << "大家好，我叫 " << name << "，今年 " << age << " 岁。" << endl;
    }
};

// 全局函数：参数是 Person 对象（值传递，会触发拷贝构造函数）
void printPerson(Person p) {
    // 调用对象的 introduce 方法
    cout << "打印个人信息：" << endl;
    p.introduce();
    // 函数结束时，参数 p 会被销毁，调用析构函数
}

// 全局函数：参数是 Person 的引用（不会触发拷贝构造函数）
void printPersonRef(const Person& p) {
    // 引用传递不会创建新对象，所以不会调用拷贝构造函数
    cout << "通过引用打印：" << p.getName() << endl;
    // 函数结束时，不会销毁传入的对象，因为只是引用
}

// 主函数
int main() {
    // 使用默认构造函数创建对象
    // 这会在栈上分配 Person 对象，并调用默认构造函数
    cout << "--- 创建对象1（默认构造函数）---" << endl;
    Person p1;

    // 使用带参构造函数创建对象
    // 传入字符串和整数作为参数
    cout << endl << "--- 创建对象2（带参构造函数）---" << endl;
    Person p2("张三", 25);

    // 使用拷贝构造函数创建对象
    // 用已经存在的 p2 对象初始化 p3
    cout << endl << "--- 创建对象3（拷贝构造函数）---" << endl;
    Person p3 = p2;

    // 调用成员函数
    cout << endl << "--- 调用成员函数 ---" << endl;
    p1.introduce();
    p2.introduce();
    p3.introduce();

    // 使用 new 在堆上创建对象（动态分配）
    // new 会调用相应的构造函数
    cout << endl << "--- 动态创建对象 ---" << endl;
    Person* p4 = new Person("李四", 30);

    // 调用堆上对象的成员函数
    p4->introduce();

    // 使用 delete 释放堆上对象的内存
    // delete 会调用对象的析构函数，然后释放内存
    cout << "准备释放堆上对象：" << endl;
    delete p4;

    // 演示值传递和引用传递的区别
    cout << endl << "--- 值传递（触发拷贝构造函数）---" << endl;
    // 这里会拷贝一个临时对象传递给函数
    printPerson(p2);

    cout << endl << "--- 引用传递（不触发拷贝构造函数）---" << endl;
    // 引用传递不会创建新对象，效率更高
    printPersonRef(p2);

    // 使用初始化列表语法创建对象
    // C++11 开始支持这种统一的初始化语法
    cout << endl << "--- 使用初始化列表语法 ---" << endl;
    Person p5{"王五", 28};
    p5.introduce();

    // 主函数结束，栈上对象 p1, p2, p3, p5 会被自动销毁
    // 销毁顺序与创建顺序相反（后创建的先销毁）
    cout << endl << "--- 主函数结束，自动销毁栈上对象 ---" << endl;

    return 0;
}
