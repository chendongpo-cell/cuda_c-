# 08 函数基础

## 1. 直观理解

### 函数 = 命名的代码块 + 输入 + 输出

函数把一段代码打包成一个可重复使用的单元。从"数学函数"的角度理解最直观：

```
输入 (参数) → [函数体: 处理] → 输出 (返回值)

f(x, y) = x + y
add(3, 5) → 8
```

但在 C++ 中，函数远不止"输入→输出"这么简单。它是程序组织的基石，也是编译器优化的关键单元。

---

## 2. 语法速查

### 函数定义

```cpp
返回值类型 函数名(参数列表) {
    // 函数体
    return 返回值;
}

// 例：
int add(int a, int b) {
    return a + b;
}

double average(double x, double y) {
    return (x + y) / 2.0;
}

void sayHello() {          // void = 无返回值
    cout << "Hello!";
    // 不需要 return（也可以写 return;）
}
```

### 声明 vs 定义

```cpp
// 声明（Declaration）—— 告诉编译器函数签名
int add(int a, int b);

// 定义（Definition）—— 包含函数体
int add(int a, int b) {
    return a + b;
}
```

### 参数传递

```cpp
// 传值（默认）—— 函数内修改不影响外部
void inc(int x) { x++; }           // x 是副本

// 传引用 —— 函数内修改影响外部
void inc(int& x) { x++; }          // x 是原变量的别名

// 传 const 引用 —— 避免拷贝，但不能修改
void print(const std::string& s) { cout << s; }
```

### 函数重载

```cpp
int  max(int a, int b)    { return a > b ? a : b; }
double max(double a, double b) { return a > b ? a : b; }
// 同名，参数类型不同 → 编译器根据调用时的参数类型自动选择
```

### 默认参数

```cpp
void greet(const std::string& name = "游客") {
    cout << "你好, " << name << "!";
}

greet();           // "你好, 游客!"
greet("小明");     // "你好, 小明!"
```

**规则**：默认参数必须从右向左连续设置。`void f(int a=1, int b)` 是错的。

---

## 3. 底层原理

### 调用约定（Calling Convention）

每次函数调用，CPU 需要完成一系列工作——这套规则称为**调用约定**：

#### x86-64 上的典型调用约定（System V AMD64 / Microsoft x64）

1. **传参**：前几个参数通过寄存器传递（快），多余的压栈
2. **`call` 指令**：把返回地址压栈，跳转到函数代码
3. **函数序言（Prologue）**：
   ```asm
   push rbp           ; 保存调用者的栈帧基址
   mov rbp, rsp       ; 建立自己的栈帧基址
   sub rsp, N         ; 为局部变量分配栈空间
   ```
4. **函数体执行**
5. **函数尾声（Epilogue）**：
   ```asm
   mov rsp, rbp       ; 恢复栈指针
   pop rbp            ; 恢复调用者的栈帧基址
   ret                ; 弹出返回地址并跳回
   ```

整个过程的栈帧结构（回顾 [内存模型](../docs/00_内存模型.md)）：

```
调用者栈帧      ← rbp (调用者的)
返回地址
旧的 rbp        ← rbp (当前函数的)
局部变量
...             ← rsp
```

### 传值 vs 传引用的本质

```cpp
// 传值 —— 把值复制到寄存器或栈上
void byValue(BigObject obj) { ... }
// 调用 byValue(x) 时：完整的 BigObject 拷贝！可能很昂贵

// 传引用 —— 传递的是地址（一个指针，8 字节）
void byRef(const BigObject& obj) { ... }
// 调用 byRef(x) 时：只传了 x 的地址（8 字节），没有拷贝对象本身
```

经验法则：
- **基本类型**（`int`、`double`、`char`）→ 传值（指针反而更慢）
- **大对象**（`std::string`、`std::vector`、自定义类）→ 传 `const &`
- **需要修改的参数**→ 传引用 `&`

### `inline` 的真实含义

新手常以为 `inline` 是"把函数内联展开"。实际上：

```cpp
inline int add(int a, int b) { return a + b; }
```

`inline` 的关键作用是**豁免 ODR 规则**——允许同一个函数的定义出现在多个翻译单元中而不报 "multiple definition" 错误。

- 现代编译器**自己决定**是否内联——`inline` 关键字基本不影响这个决定
- 你写 `inline` 的场合：在**头文件**中定义函数（因为头文件会被多个 `.cpp` include）
- 编译器真正内联的依据：函数体小、不递归、热路径 → 自动内联

### 递归的栈消耗

```cpp
int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);  // 每次递归调用都分配一个栈帧
}
// factorial(100000) → 栈溢出！
```

每次递归调用都会在栈上压入一个新的栈帧。如果递归深度过大（通常超过几万层），就会栈溢出。尾递归优化（编译器把尾递归转成循环）可以避免这个问题：

```cpp
// 尾递归形式（编译器可能优化成循环）：
int factorial_tail(int n, int acc = 1) {
    if (n <= 1) return acc;
    return factorial_tail(n - 1, n * acc);  // 递归调用是最后一条语句
}
```

---

## 4. 深入细节

### 函数指针

函数名本身可以退化为函数指针：

```cpp
int add(int a, int b) { return a + b; }

int (*funcPtr)(int, int) = add;   // funcPtr 是指向 add 的指针
// 也可用 auto：auto funcPtr = add; 或 auto funcPtr = &add;

int result = funcPtr(3, 5);        // 通过指针调用（等价于 add(3,5)）
```

函数指针的实际应用——回调：

```cpp
void forEach(int* arr, size_t n, void (*callback)(int&)) {
    for (size_t i = 0; i < n; i++)
        callback(arr[i]);
}

forEach(arr, 5, [](int& x) { x *= 2; });  // 配合 lambda
```

### `std::function` ——万能函数包装器

```cpp
#include <functional>

std::function<int(int, int)> f;

f = add;                              // 包装普通函数
f = [](int a, int b) { return a*b; }; // 包装 lambda
f = std::multiplies<int>();           // 包装函数对象

int result = f(3, 4);                 // 调用，结果是 12
```

**代价**：`std::function` 有类型擦除的开销（内部是虚函数调用或类似机制），比直接调用函数指针慢。性能敏感场景避免在热循环中使用。

### `[[nodiscard]]` ——C++17 的返回值检查

```cpp
[[nodiscard]] int computeValue() {
    return 42;
}

computeValue();  // 编译器警告！忽略了返回值（你可能忘了用）
int x = computeValue();  // OK
```

防止忘记使用返回值（常见于错误码模式）。

### 函数重载决议（简要）

```cpp
void f(int);
void f(double);
void f(int, int);

f(42);       // 调用 f(int)
f(3.14);     // 调用 f(double)
f(1, 2);     // 调用 f(int, int)
f('A');      // 调用 f(int) —— char 被提升为 int
```

重载决议的基本规则（简化）：
1. 找完全匹配的
2. 通过类型提升匹配（char→int, float→double）
3. 通过隐式转换匹配
4. 如果多个候选都不优于其他 → **歧义错误（ambiguous）**

---

## 5. C++ vs Python 对照

```python
# Python
def add(a, b):
    return a + b

def greet(name="游客"):      # 默认参数（注意可变默认参数的坑）
    print(f"你好, {name}!")

# Python 传引用？int 不可变，list 可变 —— 行为由对象类型决定
# Python 不支持函数重载（同名函数后者覆盖前者）
# Python 用 Type Hints + @overload 装饰器模拟重载
```

```cpp
// C++
int add(int a, int b) {
    return a + b;
}

void greet(const std::string& name = "游客") {
    cout << "你好, " << name << "!";
}

// C++ 传值或传引用——由参数类型决定，程序员明确控制
// C++ 原生支持函数重载
```

| 方面 | Python | C++ |
|------|--------|-----|
| 参数传递 | 引用传递（但不可变对象"看起来"像传值） | 可选传值或传引用（程序员控制） |
| 返回值 | 可返回任意类型（包括 None） | 固定类型，`void` = 无返回 |
| 重载 | 不支持（靠默认参数和 `*args`） | 原生支持 |
| 默认参数 | 支持（注意 mutable default 的坑） | 支持（从右向左） |
| 调用开销 | 大（解释器查名字、构建栈帧） | 小（几条 CPU 指令，或完全内联掉） |
| 内联 | 无（解释器不保证） | 编译器自动（或 `inline` 提示） |

---

## 6. 练习与思考

### 基础练习

1. 实现 `max(int, int)`、`max(double, double)`、`max(int, int, int)` 三个重载版本
2. 实现一个函数 `swap(int&, int&)` 交换两个整数的值
3. 实现一个递归函数计算斐波那契数列，观察 n=50 时的执行时间

### 思考题

4. 传引用和传值除了性能差异，在语义上有什么不同？（提示：修改是否影响外部）
5. 什么情况下传 `const&` 比传值**更慢**？（提示：小对象 + 间接访问）
6. 函数指针和 `std::function` 的区别是什么？各适合什么场景？
7. 尾递归为什么编译器能优化成循环？写一个例子并用 `objdump -d` 看汇编验证
