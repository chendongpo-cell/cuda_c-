// ============================================================
// utils.h —— 工具函数头文件
// 本文件包含各种工具函数的声明（也叫"函数原型"）
// .h 头文件的作用是声明接口，告诉其他 .cpp 文件"这里有这些函数可以用"
// ============================================================

// 头文件保护宏：防止同一个头文件被多次包含导致重复定义错误
// 如果 UTILS_H 还没有被定义过，就往下执行
#ifndef UTILS_H
// 定义 UTILS_H，下次再包含这个文件时就不会再执行了
#define UTILS_H

// 引入 string 头文件，因为下面的函数参数中用到了 std::string 类型
#include <string>

// ============================================================
// 函数声明（函数原型）
// 声明告诉编译器"这些函数存在，但实现在别的 .cpp 文件里"
// ============================================================

/**
 * max - 求两个整数的最大值（函数重载版本1）
 * @param a: 第一个整数
 * @param b: 第二个整数
 * @return: a 和 b 中较大的那个值
 */
int max(int a, int b);

/**
 * max - 求两个浮点数的最大值（函数重载版本2）
 * 函数名相同，但参数类型不同——这就是"函数重载"
 * @param a: 第一个浮点数
 * @param b: 第二个浮点数
 * @return: a 和 b 中较大的那个值
 */
double max(double a, double b);

/**
 * max - 求三个整数的最大值（函数重载版本3）
 * 函数名相同，参数个数不同——也是函数重载的一种
 * @param a: 第一个整数
 * @param b: 第二个整数
 * @param c: 第三个整数
 * @return: a、b、c 中最大的那个值
 */
int max(int a, int b, int c);

/**
 * swapByRef - 通过引用交换两个整数的值
 * @param x: 第一个整数的引用
 * @param y: 第二个整数的引用
 * 注意：参数是引用类型，函数内修改 x 和 y 就等于修改原始变量
 */
void swapByRef(int& x, int& y);

/**
 * factorial - 计算非负整数的阶乘（递归方式）
 * @param n: 要计算阶乘的非负整数
 * @return: n 的阶乘（n! = n * (n-1) * ... * 1）
 */
int factorial(int n);

/**
 * greet - 向用户问好
 * @param name: 用户的名字，默认为 "游客"
 * 演示带有默认参数的函数
 */
void greet(std::string name = "游客");

/**
 * printScore - 打印学生成绩
 * @param name: 学生姓名（必选参数）
 * @param score: 成绩（默认值为 0）
 * @param subject: 科目（默认值为 "未知科目"）
 * 演示多个默认参数的用法，注意默认参数必须从右向左连续定义
 */
void printScore(std::string name, int score = 0, std::string subject = "未知科目");

// 头文件保护宏结束
#endif // UTILS_H
