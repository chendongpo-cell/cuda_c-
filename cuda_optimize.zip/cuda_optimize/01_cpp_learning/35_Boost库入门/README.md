# 35_Boost库入门

## 什么是 Boost？

Boost 是一套高质量的、开源的、经同行评审的 C++ 库集合。它由 Boost 社区开发维护，被誉为"下一代 C++ 标准库的试验场"。许多 Boost 库后来被纳入 C++ 标准库（C++11、C++14、C++17、C++20）。

Boost 当前包含 160+ 个独立的库，覆盖从数学计算到网络编程的广泛领域。

## Boost vs STL

| 对比维度 | Boost | STL（标准库） |
|---------|-------|---------------|
| 发展方式 | 社区驱动，独立演进 | 标准化委员会，随 C++ 标准发布 |
| 更新速度 | 快速迭代，每年发布新版本 | 每 3 年随新标准发布 |
| 兼容性 | 支持较旧的编译器 | 要求较新的编译器支持 |
| 争议性功能 | 允许试验性设计 | 经过充分讨论和打磨 |
| 部分内容 | 最终可能进入标准库 | 已经是标准的一部分 |

## 常用 Boost 库

### boost::shared_ptr（C++11 之前的智能指针）

在 C++11 引入 `std::shared_ptr` 之前，Boost 提供了共享所有权的智能指针。C++11 标准库的 `shared_ptr` 直接源自 Boost 版本。

```cpp
#include <boost/shared_ptr.hpp>
boost::shared_ptr<int> ptr(new int(42));
```

### boost::lexical_cast（类型转换）

提供类似 `std::stringstream` 的字符串与数值之间的类型转换，使用更简洁：

```cpp
int n = boost::lexical_cast<int>("123");           // 字符串转整数
std::string s = boost::lexical_cast<std::string>(3.14);  // 浮点数转字符串
```

C++17 中的 `std::from_chars` 和 `std::to_chars` 实现了类似功能，但 `lexical_cast` 使用更方便。

### boost::filesystem（文件系统操作）

提供可移植的文件和路径操作，C++17 已将其大部分功能纳入 `std::filesystem`：

```cpp
boost::filesystem::path p("C:/test");
bool exists = boost::filesystem::exists(p);
boost::filesystem::directory_iterator it(p);
```

### boost::asio（网络编程）

异步 I/O 库，支持网络编程、串口通信等。Asio 的设计理念是"异步操作 + 回调函数"。`boost::asio` 也是 C++20 中 `std::execution` 的灵感来源之一。

```cpp
boost::asio::io_context io;
boost::asio::ip::tcp::socket socket(io);
```

### boost::regex（正则表达式）

正则表达式库，功能与 `std::regex` 类似：

```cpp
boost::regex re("\\d+");
bool match = boost::regex_match("123", re);
```

C++11 标准库已包含 `std::regex`，但某些实现（如 GCC 4.8 之前）存在 bug，Boost 版本更稳定。

### boost::format（字符串格式化）

提供类似 Python 的 `%` 格式化或 C 的 `printf` 风格的字符串格式化：

```cpp
std::string s = boost::format("Hello %s, age = %d") % "Alice" % 30;
```

### boost::variant（类型安全的联合体）

在 C++17 引入 `std::variant` 之前，Boost 提供了类型安全的联合体。它可以存储多种预定义类型中的一种，且是类型安全的。

```cpp
boost::variant<int, double, std::string> v;
v = 42;                    // 存储 int
v = 3.14;                  // 存储 double
v = "hello";               // 存储 string
```

C++17 之后应优先使用 `std::variant`。

## 如何安装 Boost

### Windows
- 从 https://www.boost.org 下载预编译二进制或源码
- 或使用 vcpkg：`vcpkg install boost`

### Linux
```bash
sudo apt install libboost-all-dev  # Debian/Ubuntu
sudo dnf install boost-devel        # Fedora
```

### macOS
```bash
brew install boost
```

## Boost 版本命名

Boost 版本号格式为 X.Y.Z：
- X：主版本号，重大更新
- Y：次版本号，新特性和库
- Z：补丁版本，bug 修复

当前最新稳定版约为 1.87.x（2025-2026 年）。

## 在 CMake 中使用 Boost

```cmake
find_package(Boost REQUIRED COMPONENTS filesystem regex)
add_executable(my_app main.cpp)
target_link_libraries(my_app Boost::filesystem Boost::regex)
```
