// ============================================================
// 35_Boost库入门 - Boost 库示例程序
//
// 编译说明：
// 本系统可能未安装 Boost 库。如果未安装，代码无法编译。
// 本文件作为学习参考代码，展示了 Boost 四个核心库的使用。
//
// Boost 安装方式：
//   Linux (Debian/Ubuntu): sudo apt install libboost-all-dev
//   Linux (Fedora):        sudo dnf install boost-devel
//   macOS:                 brew install boost
//   Windows (vcpkg):       vcpkg install boost
//
// 编译命令（如果已安装 Boost）：
//   g++ main.cpp -o boost_demo -lboost_system -lboost_filesystem
//
// 如果使用 CMake，在 CMakeLists.txt 中添加：
//   find_package(Boost REQUIRED COMPONENTS filesystem system)
//   target_link_libraries(my_app Boost::filesystem Boost::system)
//
// 该程序演示了以下 Boost 功能：
// 1. boost::lexical_cast - 字符串与数值的相互转换
// 2. boost::format - 格式化字符串输出
// 3. boost::filesystem - 文件和目录操作
// 4. boost::variant - 类型安全的联合体（C++11/14 替代方案）
// ============================================================

// 包含标准库头文件
#include <iostream>   // 用于控制台输入输出
#include <string>     // 使用 std::string 字符串类型
#include <vector>     // 使用 std::vector 动态数组

// 包含 Boost 库头文件
// lexical_cast 位于 boost/lexical_cast.hpp
#include <boost/lexical_cast.hpp>  // 类型转换库：string <-> 数值

// format 位于 boost/format.hpp
#include <boost/format.hpp>        // 字符串格式化库

// filesystem 相关头文件
#include <boost/filesystem.hpp>    // 文件系统操作库

// variant 位于 boost/variant.hpp
#include <boost/variant.hpp>       // 类型安全联合体库

/**
 * main - Boost 库演示程序入口
 * 演示四个常用的 Boost 库功能：
 *    1. boost::lexical_cast
 *    2. boost::format
 *    3. boost::filesystem
 *    4. boost::variant
 *
 * @return: 程序退出码，0 表示成功
 */
int main()
{
    // ========================================================
    // 第一部分：boost::lexical_cast 演示
    // 功能：在字符串和数值类型之间进行安全的转换
    // 如果转换失败，会抛出 boost::bad_lexical_cast 异常
    // C++11 之后可以使用 std::to_string 和 std::stoi 替代
    // ========================================================

    // 使用 std::cout 打印分区标题
    std::cout << "===== boost::lexical_cast 演示 =====" << std::endl;

    // 示例 1：将字符串转换为整数
    // lexical_cast 模板参数为目标类型，函数参数为源值
    std::string str_num = "12345";                                // 定义一个数字字符串
    int int_val = boost::lexical_cast<int>(str_num);              // 将字符串 "12345" 转换为整数 12345

    // 打印转换结果
    std::cout << "字符串 \"" << str_num << "\" 转换为整数: ";      // 输出提示信息
    std::cout << int_val << std::endl;                             // 输出转换结果

    // 示例 2：将字符串转换为浮点数
    std::string str_float = "3.14159";                             // 定义一个浮点数字符串
    double double_val = boost::lexical_cast<double>(str_float);    // 转换为 double 类型

    // 打印双精度浮点数结果
    std::cout << "字符串 \"" << str_float << "\" 转换为 double: ";  // 输出提示
    std::cout << double_val << std::endl;                           // 输出 3.14159

    // 示例 3：反向转换 - 将数值转换为字符串
    int original = 2024;                                           // 定义一个整数
    std::string back_to_str = boost::lexical_cast<std::string>(original);  // 转换为字符串

    // 打印整数转字符串的结果
    std::cout << "整数 " << original << " 转换回字符串: \"";        // 输出提示
    std::cout << back_to_str << "\"" << std::endl;                  // 输出 "2024"

    // 示例 4：异常处理 - 转换无效字符串会抛异常
    try {
        // 尝试将非数字字符串 "hello" 转换为 int
        // 这会导致 boost::bad_lexical_cast 异常
        int bad = boost::lexical_cast<int>("hello");
        // 如果转换成功则打印（实际上不会执行到这里）
        std::cout << "转换成功: " << bad << std::endl;
    } catch (const boost::bad_lexical_cast &e) {
        // catch 块捕获转换异常并打印错误信息
        // what() 方法返回描述错误的字符串
        std::cout << "捕获异常（非法转换）: " << e.what() << std::endl;
    }

    // 输出空行分隔不同的演示部分
    std::cout << std::endl;

    // ========================================================
    // 第二部分：boost::format 演示
    // 功能：类似 Python 的 % 格式化或 C 的 printf
    // 使用 % 操作符将参数传入格式字符串中的占位符
    // C++20 之后可以使用 std::format 代替
    // ========================================================

    // 打印分区标题
    std::cout << "===== boost::format 演示 =====" << std::endl;

    // 示例 1：基本格式化 - 使用位置参数
    // boost::format 的构造参数是格式字符串
    // %1% 表示第一个参数，%2% 表示第二个参数，以此类推
    std::string name = "Alice";                                     // 姓名
    int age = 30;                                                   // 年龄
    double height = 1.75;                                           // 身高（米）

    // 构建格式化字符串，使用 %1%、%2%、%3% 作为占位符
    // 然后使用 % 操作符依次传入实际参数
    boost::format fmt1("姓名: %1%, 年龄: %2%, 身高: %3%米");
    fmt1 % name;        // %1% 被替换为 name ("Alice")
    fmt1 % age;         // %2% 被替换为 age (30)
    fmt1 % height;      // %3% 被替换为 height (1.75)

    // str() 方法返回最终的字符串
    std::cout << "位置参数格式化: " << fmt1.str() << std::endl;

    // 示例 2：链式调用 - 更简洁的写法
    // 可以直接连续使用 % 操作符，不用每次都写 fmt 变量名
    std::string result_str = (boost::format("计算结果: %1% + %2% = %3%")
                              % 10                                // %1% = 10
                              % 20                                // %2% = 20
                              % (10 + 20)).str();                 // %3% = 30

    // 打印链式格式化的结果
    std::cout << "链式格式化: " << result_str << std::endl;

    // 示例 3：printf 风格格式化
    // 使用 %s（字符串）、%d（整数）、%f（浮点数）等占位符
    // 类似于 C 语言的 printf 格式，但更安全
    boost::format fmt3("printf 风格: %s 得分为 %d 分, 正确率 %.1f%%");
    fmt3 % "张三";      // %s 被替换为 "张三"
    fmt3 % 85;          // %d 被替换为 85
    fmt3 % 85.0;        // %.1f 被替换为 85.0（一位小数）

    // 打印 printf 风格的格式化结果
    std::cout << fmt3.str() << std::endl;

    // 输出空行分隔
    std::cout << std::endl;

    // ========================================================
    // 第三部分：boost::filesystem 演示
    // 功能：可移植的文件系统操作（路径、文件遍历等）
    // C++17 之后可以使用 std::filesystem 替代
    // 注意：目录路径中的分隔符使用 /，Boost 会自动转换为
    // 平台对应的分隔符（Windows 是 \，Linux 是 /）
    // ========================================================

    // 打印分区标题
    std::cout << "===== boost::filesystem 演示 =====" << std::endl;

    // 使用 boost::filesystem 命名空间
    // 为了代码可读性，这里使用完全限定名
    namespace fs = boost::filesystem;                             // 创建命名空间别名

    // 示例 1：路径操作
    // 使用当前路径构造 path 对象
    fs::path current_path = fs::current_path();                   // 获取当前工作目录

    // 打印当前路径的绝对路径字符串
    std::cout << "当前工作目录: " << current_path.string() << std::endl;

    // 示例 2：检查路径是否存在、是文件还是目录
    // exists() 检查路径是否存在
    if (fs::exists(current_path)) {                               // 如果当前路径存在
        // is_directory() 检查是否为目录
        if (fs::is_directory(current_path)) {                     // 如果是目录
            std::cout << current_path.filename().string();        // 获取目录名
            std::cout << " 是一个目录" << std::endl;               // 打印类型信息
        }
        // is_regular_file() 检查是否为普通文件
        if (fs::is_regular_file(current_path)) {                  // 如果是普通文件
            std::cout << current_path.filename().string();        // 获取文件名
            std::cout << " 是一个普通文件" << std::endl;           // 打印类型信息
        }
    }

    // 示例 3：用目录迭代器遍历当前目录
    // directory_iterator 遍历目录中的每个条目
    // 注意：这里限制最多遍历 5 个文件防止输出过多
    std::cout << "当前目录下的内容（最多显示前5个）:" << std::endl;  // 打印提示

    int file_count = 0;                                           // 计数器，限制显示数量
    fs::directory_iterator end_iter;                              // 默认构造的迭代器是结束迭代器

    // 遍历当前目录
    for (fs::directory_iterator dir_iter(current_path);
         dir_iter != end_iter && file_count < 5;                  // 最多遍历 5 个
         ++dir_iter) {                                            // 递增迭代器到下一个条目

        // 获取当前条目的路径
        fs::path entry_path = dir_iter->path();                   // 获取文件/目录的路径

        // 检查当前条目是文件还是目录
        if (fs::is_regular_file(entry_path)) {                    // 如果是普通文件
            std::cout << "  [文件] ";                              // 标记为文件
        } else if (fs::is_directory(entry_path)) {                // 如果是目录
            std::cout << "  [目录] ";                              // 标记为目录
        } else {                                                  // 其他类型
            std::cout << "  [其他] ";                              // 标记为其他
        }

        // 打印文件名（不包括路径前缀）
        std::cout << entry_path.filename().string() << std::endl;

        // 递增文件计数器
        ++file_count;                                             // 计数器加 1
    }

    // 输出空行分隔
    std::cout << std::endl;

    // ========================================================
    // 第四部分：boost::variant 演示
    // 功能：类型安全的联合体，可以存储多种预定义类型中的一种
    // 与 C 语言 union 不同，variant 知道当前存储的是什么类型
    // C++17 之后可以使用 std::variant 替代
    // ========================================================

    // 打印分区标题
    std::cout << "===== boost::variant 演示 =====" << std::endl;

    // 定义一个 variant 类型，可以存储 int、double 或 std::string
    // boost::variant<类型1, 类型2, 类型3, ...>
    boost::variant<int, double, std::string> my_variant;          // 声明 variant 变量

    // 示例 1：存储整数
    my_variant = 42;                                              // 赋值为整数 42

    // 使用 boost::get<T>() 提取 variant 中存储的值
    // boost::get<int>() 返回 int& 引用
    std::cout << "variant 存储整数: ";                             // 输出提示
    std::cout << boost::get<int>(my_variant) << std::endl;        // 输出 42

    // 示例 2：存储浮点数（同一个变量可以存储不同类型）
    my_variant = 3.14159;                                         // 赋值为 double 类型

    std::cout << "variant 存储浮点数: ";                           // 输出提示
    std::cout << boost::get<double>(my_variant) << std::endl;     // 输出 3.14159

    // 示例 3：存储字符串
    my_variant = std::string("Hello Boost!");                     // 赋值为字符串

    std::cout << "variant 存储字符串: ";                           // 输出提示
    std::cout << boost::get<std::string>(my_variant) << std::endl; // 输出 "Hello Boost!"

    // 示例 4：类型检查
    // which() 方法返回当前存储类型的索引（按声明顺序，从 0 开始）
    // 对于 boost::variant<int, double, std::string>:
    //   which() == 0 表示存储的是 int
    //   which() == 1 表示存储的是 double
    //   which() == 2 表示存储的是 std::string
    my_variant = 100;                                             // 再次赋值为整数

    // 使用 switch 根据类型索引输出当前存储的值
    switch (my_variant.which()) {                                 // which() 获取类型索引
        case 0:  // 类型 0 是 int
            std::cout << "当前类型: int, 值 = ";
            std::cout << boost::get<int>(my_variant) << std::endl;
            break;                                                // 跳出 switch
        case 1:  // 类型 1 是 double
            std::cout << "当前类型: double, 值 = ";
            std::cout << boost::get<double>(my_variant) << std::endl;
            break;                                                // 跳出 switch
        case 2:  // 类型 2 是 std::string
            std::cout << "当前类型: string, 值 = ";
            std::cout << boost::get<std::string>(my_variant) << std::endl;
            break;                                                // 跳出 switch
        default: {                                                // 默认分支
            std::cout << "未知类型" << std::endl;                   // 打印未知
            break;
        }
    }

    // 输出空行分隔
    std::cout << std::endl;

    // ========================================================
    // 程序结束
    // ========================================================

    // 打印结束提示信息
    std::cout << "所有 Boost 演示完成！" << std::endl;

    // 返回 0 表示程序成功执行
    return 0;
}
