# C++ 面试题 —— 现代特性与工程篇

> 对应知识点：C++11/14 新特性（第 28 课）+ C++17/20 新特性（第 29 课）+ 右值与移动语义（第 30 课）+ 设计模式（第 31 课）+ 单元测试（第 32 课）+ CMake（第 33 课）+ Qt（第 34 课）+ Boost（第 35 课）
> 难度：⭐⭐⭐⭐ 适合中高级面试

---

## 目录

1. [C++11/14 新特性](#1-c1114-新特性)
2. [C++17/20 新特性](#2-c1720-新特性)
3. [右值与移动语义](#3-右值与移动语义)
4. [设计模式](#4-设计模式)
5. [单元测试](#5-单元测试)
6. [CMake 构建系统](#6-cmake-构建系统)
7. [Qt 与 Boost 框架](#7-qt-与-boost-框架)

---

## 1. C++11/14 新特性

### 题 1：`auto` 关键字在 C++11 中的作用是什么？有什么使用限制？

**考察点**：类型推导、auto 用法

**参考答案**：

`auto` 让编译器根据初始化表达式自动推导变量类型，C++11 之前表示"自动存储期"，C++11 改为类型推导。

```cpp
// 基本用法
auto i = 42;                    // int
auto d = 3.14;                  // double
auto s = "hello";               // const char*
auto v = std::vector<int>{1,2}; // std::vector<int>

// 引用和 const
const auto& ref = v[0];         // const int&
auto* ptr = &i;                 // int*

// 简化复杂类型
// 没有 auto 时：
std::vector<std::map<int, std::string>>::iterator it1 = container.begin();

// 有 auto 时：
auto it2 = container.begin();   // 类型自动推导

// Lambda 类型只能用 auto 接收（Lambda 类型没有名字）
auto lambda = [](int x) { return x * 2; };

// auto 的限制：
// 1. 必须初始化（推导依据）
// auto x;     // 错误！无法推断

// 2. 不能用于函数参数（C++14 之前）
// void func(auto x) { }  // C++14 前错误，C++20 可以（简写模板）

// 3. 不能用于非静态成员变量
struct S {
    // auto a = 10;  // 错误
};
```

**提示**：`auto` 会忽略引用和 cv 限定符（除非显式写 `auto&` 或 `const auto`）。

---

### 题 2：`decltype` 和 `auto` 有什么区别？

**考察点**：decltype vs auto、类型推导规则

**参考答案**：

```cpp
int x = 42;
const int& rx = x;

// auto：忽略引用和顶层 const
auto a1 = x;     // int（auto 推导为 int）
auto a2 = rx;    // int（auto 忽略引用和 const）

// decltype：精确推导，保留引用和 const
decltype(x)  d1 = x;  // int
decltype(rx) d2 = x;  // const int&（保留引用和 const！）

// 关键区别：处理表达式的方式
int arr[5];
auto a3 = arr;          // int*（退化为指针）
decltype(arr) d3;       // int[5]（数组类型，不退化）

int* p = &x;
auto a4 = *p;           // int
decltype(*p) d4 = x;    // int&（解引用返回左值引用！）

// 典型应用：auto + decltype → 返回值后置
template <typename T, typename U>
auto add(T t, U u) -> decltype(t + u) {
    return t + u;
}

// C++14 简化：直接 auto 推导返回值
template <typename T, typename U>
auto add(T t, U u) {
    return t + u;
}
```

| 特性 | auto | decltype |
|------|------|----------|
| 推导依据 | 初始化表达式 | 任意表达式 |
| 引用保留 | 不保留 | 保留 |
| const 保留 | 不保留 | 保留 |
| 数组退化 | 退化为指针 | 保留数组 |

---

### 题 3：C++11 中的范围 for 循环（range-based for）是如何工作的？

**考察点**：范围 for、内部实现、自定义容器支持

**参考答案**：

```cpp
// C++11 范围 for 循环
std::vector<int> v = {1, 2, 3, 4, 5};

// 简洁形式
for (int x : v) {
    std::cout << x << " ";
}

// 推荐形式：const 引用避免拷贝
for (const auto& x : v) {
    std::cout << x << " ";
}

// 可修改
for (auto& x : v) {
    x *= 2;
}

// 编译器内部展开为：
{
    auto&& __range = v;
    auto __begin = __range.begin();
    auto __end = __range.end();
    for (; __begin != __end; ++__begin) {
        int x = *__begin;  // 或 auto& x = *__begin
        // 循环体
    }
}

// 让自定义容器支持范围 for
class MyContainer {
    int* data;
    size_t size;
public:
    int* begin() { return data; }
    int* end()   { return data + size; }
    const int* begin() const { return data; }
    const int* end() const   { return data + size; }
};

MyContainer mc;
for (const auto& item : mc) {  // OK：因为提供了 begin()/end()
    // ...
}
```

**提示**：在范围 for 中**不要修改容器大小**（增删元素），会导致迭代器失效。

---

### 题 4：`nullptr` 和 `NULL` 有什么区别？为什么 C++11 引入 `nullptr`？

**考察点**：空指针、类型安全

**参考答案**：

```cpp
// C++98 中的 NULL
#define NULL 0           // 通常是 0 或 ((void*)0)
// 问题：NULL 其实是整数 0，不是真正的指针类型

void func(int);
void func(char*);

func(NULL);     // 调用 func(int)！因为 NULL 被展开为 0
func(nullptr);  // 调用 func(char*)！nullptr 是真正的空指针类型

// nullptr 的类型是 std::nullptr_t
std::nullptr_t n = nullptr;  // 合法的类型

// 模板推导时也有区别
template <typename T>
void process(T t) {}

process(NULL);    // T = int（或者 unsigned long long）
process(nullptr); // T = std::nullptr_t

// nullptr 可以被隐式转换为任何指针类型和 bool
int* p1 = nullptr;    // OK：转换为 int*
char* p2 = nullptr;   // OK：转换为 char*
if (p1 == nullptr) {} // OK：比较

int n = nullptr;      // 错误！不能转换为非 bool 整数
```

**提示**：现代 C++ 中**永远使用 `nullptr`**，不要再用 `NULL` 或 `0` 表示空指针。

---

### 题 5：`constexpr` 关键字的作用是什么？和 `const` 有什么区别？

**考察点**：编译期常量、编译期计算

**参考答案**：

`constexpr` 表示值**可能在编译期计算**，C++11 的 `constexpr` 限制较多（只能有一条 return 语句），C++14/17 大幅放宽。

```cpp
// constexpr 函数（C++14 版本——可以有循环和分支）
constexpr int factorial(int n) {
    int result = 1;
    for (int i = 2; i <= n; ++i) {
        result *= i;
    }
    return result;
}

// 编译期计算
constexpr int c1 = factorial(5);  // 编译期计算为 120
int arr[factorial(3)];            // OK：编译期常量，数组大小 6

// 运行时也可以调用
int n;
std::cin >> n;
int c2 = factorial(n);            // 运行时计算

// constexpr vs const
const int getConst() { return 42; }       // 运行时函数
// int arr2[getConst()];                   // 错误！不是编译期常量

constexpr int getConstexpr() { return 42; } // 编译期可计算
int arr3[getConstexpr()];                   // OK
```

| 特性 | const | constexpr |
|------|-------|-----------|
| 含义 | 运行时不可修改 | 可能在编译期计算 |
| 编译期常量 | 不保证 | 保证（如果参数是编译期常量） |
| 函数声明 | 不表示编译期 | 可在编译期执行 |
| 适用对象 | 变量、成员函数 | 变量、函数、构造函数（C++14） |

---

## 2. C++17/20 新特性

### 题 6：C++17 的结构化绑定（structured bindings）是什么？

**考察点**：C++17 特性、解构赋值

**参考答案**：

结构化绑定允许将数组/元组/结构体的成员一次性绑定到多个变量。

```cpp
// 1. 绑定数组
int arr[3] = {1, 2, 3};
auto [a, b, c] = arr;  // a=1, b=2, c=3（拷贝）
auto& [x, y, z] = arr; // x, y, z 是 arr 的引用
x = 10;                 // arr[0] 变为 10

// 2. 绑定 tuple/pair
std::map<int, std::string> mp;
// 传统写法
for (const auto& pair : mp) {
    std::cout << pair.first << ": " << pair.second << std::endl;
}

// C++17 结构化绑定
for (const auto& [key, value] : mp) {
    std::cout << key << ": " << value << std::endl;
}

auto [id, name] = std::make_pair(1001, "张三");
std::cout << id << ", " << name << std::endl;  // 1001, 张三

// 3. 绑定结构体
struct Employee {
    int id;
    std::string name;
    double salary;
};

Employee e = {1001, "张三", 8000.0};
auto [empId, empName, empSalary] = e;

// 4. 绑定返回值
auto getEmployee() -> std::tuple<int, std::string, double>;
auto [id2, name2, salary2] = getEmployee();
```

**提示**：结构化绑定声明必须用 `auto`，不能混用已有的变量名。

---

### 题 7：C++17 的 `if constexpr` 有什么作用？解决了什么问题？

**考察点**：编译期条件分支、模板简化

**参考答案**：

`if constexpr` 在编译期根据常量表达式选择执行哪个分支，**未选择的分支不会被实例化**——解决了 SFINAE 的复杂性问题。

```cpp
#include <type_traits>
#include <vector>
#include <list>

// 不用 if constexpr（传统 SFINAE 方式，复杂且难以阅读）
template <typename T>
auto getSize(const T& container) -> decltype(container.size()) {
    return container.size();
}

// 用 if constexpr（C++17，简洁明了）
template <typename T>
void printInfo(const T& container) {
    if constexpr (std::is_same_v<T, std::vector<int>>) {
        std::cout << "vector，容量: " << container.capacity() << std::endl;
    } else if constexpr (std::is_same_v<T, std::list<int>>) {
        std::cout << "list，不支持 capacity" << std::endl;
    } else {
        std::cout << "其他容器" << std::endl;
    }
}

// 关键特性：未选中的分支不实例化
template <typename T>
void process(T value) {
    if constexpr (std::is_pointer_v<T>) {
        std::cout << "指针，值: " << *value << std::endl;  // 只有 T 是指针时才编译
    } else {
        std::cout << "非指针，值: " << value << std::endl;
    }
}

int x = 42;
process(x);    // T = int，走 else 分支
process(&x);   // T = int*，走 if 分支
```

---

### 题 8：C++20 的 concept（概念）是什么？和模板有什么区别？

**考察点**：C++20 概念、约束模板

**参考答案**：

Concept 是 C++20 引入的模板约束机制，为模板参数提供明确的条件检查，代替了 SFINAE 的复杂写法。

```cpp
#include <concepts>

// 定义一个 concept：可哈希的类型
template <typename T>
concept Hashable = requires(T t) {
    { std::hash<T>{}(t) } -> std::convertible_to<std::size_t>;
};

// 使用 concept 约束模板参数
template <Hashable T>
void hashAndPrint(const T& value) {
    std::cout << std::hash<T>{}(value) << std::endl;
}

// 其他常见 concept
template <typename T>
concept Printable = requires(std::ostream& os, T t) {
    os << t;  // T 必须支持 <<
};

// 更简洁的写法
template <std::integral T>
T add(T a, T b) {    // 只接受整数类型
    return a + b;
}

// 传统模板 vs concept
// 传统写法（SFINAE）：
template <typename T, typename = std::enable_if_t<std::is_integral_v<T>>>
T oldAdd(T a, T b) { return a + b; }

// concept 写法：
template <std::integral T>
T newAdd(T a, T b) { return a + b; }

// auto + concept（C++20 缩写）
std::integral auto multiply(std::integral auto a, std::integral auto b) {
    return a * b;
}
```

**提示**：concept 的**错误信息更友好**——传统模板出错时全是内部实例化痕迹，concept 直接告诉你是哪个约束不满足。

---

### 题 9：C++17 的 `std::optional` 是用来解决什么问题的？

**考察点**：可选值、避免魔数

**参考答案**：

`std::optional` 表示一个值"可能存在也可能不存在"，完美替代"魔法数"（如 -1、nullptr、空字符串等）表示不存在的做法。

```cpp
#include <optional>

// 问题：传统方式用特殊值表示"不存在"
int findEmployeeId_old(const std::string& name) {
    // 查找...
    if (notFound) {
        return -1;  // -1 表示不存在，但 -1 也可能是合法 ID！
    }
    return 1001;
}

// 更好：用 optional 明确表示"可能有值也可能没有"
std::optional<int> findEmployeeId(const std::string& name) {
    // 查找...
    if (notFound) {
        return std::nullopt;  // 明确表示"没有值"
    }
    return 1001;  // 有值
}

// 使用
auto result = findEmployeeId("张三");
if (result) {                              // 检查是否有值
    std::cout << "ID: " << *result;         // 解引用获取值
    std::cout << "ID: " << result.value();  // 或使用 value()
} else {
    std::cout << "未找到";
}

// value_or：有值返回值，无值返回默认值
int id = result.value_or(0);  // 找到返回 ID，否则返回 0

// 其他适用场景：解析配置项
std::optional<int> parsePort(const std::string& config) {
    // 尝试解析端口号
    if (success) return port;
    return std::nullopt;
}
```

---

### 题 10：`std::variant` 和 `std::any` 有什么区别？

**考察点**：类型安全的联合体、类型擦除

**参考答案**：

```cpp
#include <variant>
#include <any>

// std::variant：类型安全的 union，只能存储指定类型中的一种
std::variant<int, double, std::string> v;

v = 42;                    // 存储 int
v = 3.14;                  // 存储 double
v = "hello";               // 存储 string

// 安全访问：如果类型不匹配，抛出异常
try {
    int i = std::get<int>(v);     // 如果 v 当前不是 int，抛 std::bad_variant_access
} catch (const std::bad_variant_access& e) {
    std::cerr << e.what() << std::endl;
}

// 安全访问：使用 get_if（不抛异常）
if (auto* p = std::get_if<double>(&v)) {
    std::cout << "当前存储的是 double: " << *p << std::endl;
}

// std::any：可以存储任何类型（完全类型擦除）
std::any a;
a = 42;                    // 存储 int
a = 3.14;                  // 存储 double
a = std::string("hello");  // 存储 string（注意是 string，不是 const char*）

// 取出时必须知道确切类型
try {
    int i = std::any_cast<int>(a);  // 如果 a 当前不是 int，抛异常
} catch (const std::bad_any_cast& e) {
    std::cerr << e.what() << std::endl;
}

// 检查类型
if (a.type() == typeid(std::string)) {
    auto s = std::any_cast<std::string>(a);
}
```

| 特性 | std::variant | std::any |
|------|-------------|----------|
| 存储限制 | 仅限指定的类型集合 | 任意类型 |
| 栈上大小 | 最大类型的大小+判别式 | 视实现而定 |
| 堆分配 | 否 | 可能（大对象时） |
| 类型安全 | 编译期检查类型是否在集合中 | 运行期检查 |
| 性能 | 高（无堆分配） | 中等 |

---

## 3. 右值与移动语义

### 题 11：什么是左值、右值、左值引用、右值引用？

**考察点**：值类别、引用类型

**参考答案**：

```cpp
// 左值（lvalue）：有内存地址，可以取地址的表达式
// 右值（rvalue）：临时对象、字面量，没有持久地址

int x = 42;       // x 是左值，42 是右值
int* p = &x;      // OK：可以对左值取地址
// int* p2 = &42; // 错误：不能对右值取地址

// 左值引用（T&）：绑定到左值
int& ref = x;     // OK
// int& ref2 = 42; // 错误！不能绑定右值到左值引用
const int& cref = 42;  // OK：const 左值引用可以绑定到右值（延长生命周期）

// 右值引用（T&&）：绑定到右值
int&& rref = 42;        // OK：绑定到字面量
int&& rref2 = x + 1;    // OK：绑定到临时结果
// int&& rref3 = x;     // 错误！不能绑定左值到右值引用

// std::move：将左值转为右值引用（实际什么都不做，只是类型转换）
int&& rref4 = std::move(x);  // OK：告诉编译器"可以把这个左值当右值处理"
```

| 类型 | 表示法 | 能否绑定左值 | 能否绑定右值 |
|------|--------|------------|------------|
| 左值引用 | `T&` | 能 | 不能 |
| const 左值引用 | `const T&` | 能 | 能 |
| 右值引用 | `T&&` | 不能 | 能 |

---

### 题 12：什么是移动语义？移动构造函数和拷贝构造函数有什么区别？

**考察点**：移动语义、资源转移

**参考答案**：

移动语义允许将资源从一个对象"偷"到另一个对象，避免昂贵的深拷贝。

```cpp
#include <vector>
#include <string>
#include <cstring>

class String {
    char* data;
    size_t size;
public:
    // 构造函数
    String(const char* str) {
        size = strlen(str);
        data = new char[size + 1];
        memcpy(data, str, size + 1);
    }

    // 拷贝构造函数：深拷贝
    String(const String& other)
        : size(other.size)
    {
        data = new char[size + 1];
        memcpy(data, other.data, size + 1);
        std::cout << "拷贝构造（深拷贝）" << std::endl;
    }

    // 移动构造函数：偷资源
    String(String&& other) noexcept
        : data(other.data), size(other.size)  // 直接拿对方的指针
    {
        other.data = nullptr;   // 将源对象置为空
        other.size = 0;
        std::cout << "移动构造（偷资源）" << std::endl;
    }

    ~String() { delete[] data; }
};

// 使用
String s1("Hello, World!");
String s2 = s1;             // 拷贝构造（s1 仍然有效）

String s3 = std::move(s1);  // 移动构造（s1.data 变为 nullptr）

std::vector<String> v;
v.push_back(String("temp"));  // 临时对象 → 移动构造（如果移动构造是 noexcept）
```

| 特性 | 拷贝构造函数 | 移动构造函数 |
|------|-------------|-------------|
| 参数 | `const T&` | `T&&` |
| 源对象状态 | 不变 | 有效但未指定（通常为空） |
| 资源处理 | 复制一份 | 偷取（转移所有权） |
| 性能 | O(n) | O(1) |
| noexcept | 通常不标注 | 应该标注 |

---

### 题 13：`std::move` 和 `std::forward` 分别做了什么？

**考察点**：移动、完美转发

**参考答案**：

```cpp
#include <utility>

// === std::move ===
// 功能：无条件将左值转为右值引用（方便匹配移动构造函数）
// 本质：static_cast<T&&>(lvalue)

std::string s1 = "hello";
std::string s2 = std::move(s1);  // 告诉编译器：允许"偷" s1 的资源

// move 之后，s1 处于有效但未定义的状态
// s1 仍然可以被析构、赋值，但不能假设它有特定内容

// === std::forward ===
// 功能：条件性转发——如果传入的是左值就返回左值引用，右值就返回右值引用
// 用于完美转发（perfect forwarding）

template <typename T>
void wrapper(T&& arg) {
    // T&& 是"转发引用"（forwarding reference）
    // 如果传入左值，T = int&，T&& = int&（引用折叠）
    // 如果传入右值，T = int， T&& = int&&
    
    // 如果直接用 arg，总是左值（有名字）
    // forward 恢复 arg 的原始值类别
    process(std::forward<T>(arg));
}

void process(int& x)  { std::cout << "左值" << std::endl; }
void process(int&& x) { std::cout << "右值" << std::endl; }

int x = 42;
wrapper(x);      // 传入左值，输出 "左值"
wrapper(42);     // 传入右值，输出 "右值"
// 如果没有 forward，会两次都输出 "左值"（因为 arg 本身是左值）

// 不用 forward 会丢失右值性：
template <typename T>
void badWrapper(T&& arg) {
    process(arg);     // arg 永远是左值（有名字），总是调用左值版本
}
```

| 函数 | 作用 | 条件 |
|------|------|------|
| `std::move` | 左值 → 右值（无条件） | 不需要条件 |
| `std::forward` | 恢复原始值类别 | 基于模板参数的推导结果 |

**提示**："移动后源对象仍有效但状态未定义"——可以对它赋值，但不要假设它的内容。

---

### 题 14：什么是引用折叠（reference collapsing）？和完美转发有什么关系？

**考察点**：引用折叠规则、模板类型推导

**参考答案**：

引用折叠是 C++ 在模板参数推导中处理"引用的引用"的规则：

```
T&  &  → T&
T&  && → T&
T&& &  → T&
T&& && → T&&
```

**规则**：只要出现一个左值引用，结果就是左值引用；两个都是右值引用才是右值引用。

```cpp
template <typename T>
void func(T&& param);  // 注意：T&& 不是右值引用，是"转发引用"

// 当传入左值时：
int x = 42;
func(x);    // T = int&（T 被推导为左值引用）
            // T&& = int& && → int&（引用折叠后是左值引用）
            // 所以 param 的类型是 int&

// 当传入右值：
func(42);   // T = int
            // T&& = int&&（没有折叠，就是右值引用）
            // 所以 param 的类型是 int&&

// 这就是完美转发的核心原理：
template <typename T>
void forwarder(T&& arg) {
    // arg 的类型根据传入参数自动匹配：
    // 传入左值 → arg 是左值引用
    // 传入右值 → arg 是右值引用
    target(std::forward<T>(arg));  // forward 利用 T 的类型信息恢复原始类别
}
```

**提示**：只有模板参数 `T&&` 和 `auto&&` 是"转发引用"，写死的类型如 `int&&` 是纯粹的右值引用。

---

## 4. 设计模式

### 题 15：单例模式（Singleton）在 C++ 中的正确实现方式是什么？

**考察点**：设计模式、线程安全、C++11 静态局部变量

**参考答案**：

```cpp
class Singleton {
private:
    Singleton() = default;                           // 私有构造
    ~Singleton() = default;
    Singleton(const Singleton&) = delete;             // 禁止拷贝
    Singleton& operator=(const Singleton&) = delete;  // 禁止赋值

public:
    // C++11 起，静态局部变量的初始化是线程安全的
    // 编译器会自动加锁，无需手动加锁
    static Singleton& getInstance() {
        static Singleton instance;  // 第一次使用时才创建
        return instance;
    }

    void doSomething() {
        // 业务逻辑
    }
};

// 使用
Singleton::getInstance().doSomething();
```

**为什么这样实现**：
- C++11 保证静态局部变量的初始化是线程安全的
- 懒加载（lazy initialization）：第一次使用时才创建
- 无需显式加锁（比"double-checked locking"模式简单且安全）
- 不能拷贝、不能赋值

---

### 题 16：工厂方法模式（Factory Method）和简单工厂模式的区别？

**考察点**：创建型模式、开闭原则

**参考答案**：

```cpp
// === 简单工厂（Simple Factory）===
// 把对象的创建集中到一个函数里，但添加新产品需要修改工厂函数
class EmployeeFactory {
public:
    static std::shared_ptr<Employee> create(const std::string& type) {
        if (type == "正式员工") return std::make_shared<FullTimeEmployee>(...);
        if (type == "兼职员工") return std::make_shared<PartTimeEmployee>(...);
        if (type == "经理")     return std::make_shared<Manager>(...);
        return nullptr;
    }
};
// 缺点：新增类型需要修改 EmployeeFactory（违反开闭原则）

// === 工厂方法（Factory Method）===
// 定义创建对象的接口，让子类决定实例化哪个类
class Creator {
public:
    virtual std::shared_ptr<Employee> createEmployee() = 0;
    virtual ~Creator() = default;
};

class FullTimeCreator : public Creator {
public:
    std::shared_ptr<Employee> createEmployee() override {
        return std::make_shared<FullTimeEmployee>(...);
    }
};

class PartTimeCreator : public Creator {
public:
    std::shared_ptr<Employee> createEmployee() override {
        return std::make_shared<PartTimeEmployee>(...);
    }
};

// 新增类型只需要新增 Creator 子类，不需要修改已有代码
class InternCreator : public Creator {
    std::shared_ptr<Employee> createEmployee() override {
        return std::make_shared<Intern>(...);
    }
};
```

| 特性 | 简单工厂 | 工厂方法 |
|------|---------|---------|
| 复杂度 | 低 | 中 |
| 开闭原则 | 违反 | 符合 |
| 适用场景 | 类型少、不常变 | 类型多、频繁扩展 |

---

### 题 17：观察者模式（Observer）在什么场景下使用？给出一个 C++ 示例。

**考察点**：行为型模式、发布-订阅

**参考答案**：

观察者模式：定义一对多的依赖关系，当一个对象状态变化时，所有依赖它的对象自动收到通知。

```cpp
#include <vector>
#include <memory>
#include <algorithm>

// 观察者接口
class Observer {
public:
    virtual void update(const std::string& message) = 0;
    virtual ~Observer() = default;
};

// 被观察者（主题）
class Subject {
    std::vector<std::shared_ptr<Observer>> observers;
public:
    void attach(const std::shared_ptr<Observer>& obs) {
        observers.push_back(obs);
    }

    void detach(const std::shared_ptr<Observer>& obs) {
        observers.erase(
            std::remove(observers.begin(), observers.end(), obs),
            observers.end()
        );
    }

    void notify(const std::string& message) {
        for (const auto& obs : observers) {
            obs->update(message);
        }
    }
};

// 具体观察者
class HRNotify : public Observer {
    std::string name;
public:
    HRNotify(const std::string& n) : name(n) {}
    void update(const std::string& message) override {
        std::cout << "[" << name << "] 收到通知: " << message << std::endl;
    }
};

// 使用
int main() {
    Subject salarySystemModified;

    auto hr1 = std::make_shared<HRNotify>("HR张三");
    auto hr2 = std::make_shared<HRNotify>("HR李四");

    salarySystem.attach(hr1);
    salarySystem.attach(hr2);

    salarySystem.notify("员工张三的工资已更新");
    // [HR张三] 收到通知: 员工张三的工资已更新
    // [HR李四] 收到通知: 员工张三的工资已更新

    return 0;
}
```

**实际应用**：
- Qt 的信号槽机制就是观察者模式的一种实现
- GUI 中的事件处理
- 股票/新闻订阅系统
- 员工管理系统中"工资变更 → 通知财务部门"

---

## 5. 单元测试

### 题 18：什么是单元测试？Google Test 的基本用法是什么？

**考察点**：测试框架、断言、测试夹具

**参考答案**：

单元测试：对程序中最小的可测试单元（通常是函数或类）进行验证，确保其行为符合预期。

```cpp
#include <gtest/gtest.h>

// 待测试的函数
int add(int a, int b) { return a + b; }

// 最简单的测试用例
TEST(MathTest, Add) {
    EXPECT_EQ(add(1, 2), 3);       // 相等检查（非致命）
    EXPECT_EQ(add(-1, 1), 0);
    EXPECT_EQ(add(0, 0), 0);
}

// 更丰富的断言
TEST(StringTest, Compare) {
    std::string s1 = "hello";
    std::string s2 = "hello";

    EXPECT_EQ(s1, s2);                     // 相等
    EXPECT_NE(s1, "world");                // 不等
    EXPECT_TRUE(s1 == "hello");            // 为真
    EXPECT_FALSE(s1.empty());              // 为假
    EXPECT_STREQ(s1.c_str(), "hello");     // C 字符串相等
}

// 测试夹具（Test Fixture）：共享设置和清理
class EmployeeManagerTest : public ::testing::testAll {
protected:
    EmployeeManager manager;  // 每个 TEST_F 共用

    void SetUp() override {
        // 在每个测试前执行
        manager.addEmployee(std::make_shared<FullTimeEmployee>("张三", 8000, 2000));
        manager.addEmployee(std::make_shared<PartTimeEmployee>("李四", 50, 80));
    }

    void TearDown() override {
        // 在每个测试后执行
    }
};

TEST_F(EmployeeManagerTest, InitialCount) {
    EXPECT_EQ(manager.getCount(), 2);
}

TEST_F(EmployeeManagerTest, FindById) {
    auto emp = manager.findById(1000bed);
    ASSERT_NE(emp, nullptr);     // ASSERT 失败则后续不执行
    EXPECT_EQ(emp->getName(), "张三");
}

// main 函数
int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
```

**常用断言**：
| 断言 | 检查条件 |
|------|---------|
| `EXPECT_TRUE(cond)` | cond 为 true |
| `EXPECT_EQ(a, b)` | a == b |
| `EXPECT_NE(a, b)` | a != b |
| `EXPECT_LT(a, b)` | a < b |
| `ASSERT_NE(p, nullptr)` | p != nullptr（失败后跳过后续） |
| `EXPECT_THROW(expr, type)` | expr 抛出 type 类型异常 |

---

### 题 19：TDD（测试驱动开发）是什么？和传统开发流程有什么区别？

**考察点**：测试驱动开发、开发流程

**参考答案**：

**TDD 三步曲（Red-Green-Refactor）**：

```
1. RED：写一个会失败的测试（先定义期望的行为）
2. GREEN：写恰好让测试通过的最简代码
3. REFACTOR：重构代码，保持测试通过
```

```cpp
// 第一步：先写测试（RED）
TEST(SalaryTest, ManagerSalary) {
    Manager mgr("王五", 15000, "技术部", 10, 5000);
    // 经理公式：15000 + 5000 * (1 + 10 * 0.05) = 15000 + 7500 = 22500
    EXPECT_DOUBLE_EQ(mgr.calcSalary(), 22500.0);
}
// 此时编译通常能通过，但测试应该失败（因为还没实现）

// 第二步：写最简实现（GREEN）
// Manager::calcSalary() 实现...
double Manager::calcSalary() const {
    return baseSalary + performanceBonus * (1 + teamSize * 0.05);
}
// 测试通过

// 第三步：重构（REFACTOR）
// 优化代码、提取变量等，确保测试仍然通过
```

| 特点 | TDD | 传统开发 |
|------|-----|---------|
| 测试时机 | 先写测试再编码 | 后写测试或不写 |
| 覆盖率 | 自然很高 | 可能遗漏 |
| 设计质量 | 从调用方角度设计接口 | 从实现方角度 |
| 重构信心 | 高（有测试兜底） | 低（怕改坏） |
| 初始速度 | 慢 | 快 |

---

## 6. CMake 构建系统

### 题 20：CMake 的基本用法是什么？`CMakeLists.txt` 中常见的命令有哪些？

**考察点**：构建系统、CMake 语法

**参考答案**：

```cmake
# CMakeLists.txt 示例（对应综合项目）
cmake_minimum_required(VERSION 3.10)      # 指定 CMake 最低版本

project(EmployeeManagementSystem          # 项目名称
    VERSION 1.0.0                         # 项目版本
    LANGUAGES CXX                         # 编程语言
)

set(CMAKE_CXX_STANDARD 17)                # 设置 C++ 标准
set(CMAKE_CXX_STANDARD_REQUIRED ON)       # 强制要求，不允许降级
set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -Wall -Wextra")  # 编译选项

# 添加可执行文件
add_executable(${PROJECT_NAME}
    src/main.cpp
    src/Employee.cpp
    src/EmployeeManager.cpp
    # ...
)

# 添加头文件搜索路径
target_include_directories(${PROJECT_NAME} PRIVATE
    ${PROJECT_SOURCE_DIR}/include
)

# 添加库依赖（如果用了外部库）
target_link_libraries(${PROJECT_NAME}
    PRIVATE
    Threads::Threads           # 多线程库
)
```

**常用 CMake 命令**：

| 命令 | 作用 |
|------|------|
| `add_executable` | 生成可执行文件 |
| `add_library` | 生成库（静态/动态） |
| `target_include_directories` | 添加头文件搜索路径 |
| `target_link_libraries` | 链接库 |
| `find_package` | 查找外部依赖包 |
| `add_subdirectory` | 添加子目录 |
| `set` | 设置变量 |
| `option` | 设置编译选项 |
| `message` | 打印信息 |

**构建命令**：
```bash
# 推荐：out-of-source build
mkdir build && cd build
cmake ..            # 配置
cmake --build .     # 编译
# 或
make                # Linux 上
```

---

### 题 21：静态库和动态库有什么区别？CMake 中如何创建？

**考察点**：库的类型、链接方式

**参考答案**：

```cmake
# 创建静态库（.a / .lib）
add_library(my_lib STATIC
    src/Employee.cpp
    src/EmployeeManager.cpp
)

# 创建动态库（.so / .dll + .lib）
add_library(my_lib SHARED
    src/Employee.cpp
    src/EmployeeManager.cpp
)

# 指定 API 导出（Windows 上动态库需要）
# 头文件中：
#ifdef MYLIB_EXPORTS
#define MYLIB_API __declspec(dllexport)
#else
#define MYLIB_API __declspec(dllimport)
#endif

class MYLIB_API Employee {
    // ...
};

# CMake 中自动定义导出宏：
target_compile_definitions(my_lib PRIVATE MYLIB_EXPORTS)
```

| 特性 | 静态库（.a/.lib） | 动态库（.so/.dll） |
|------|-----------------|------------------|
| 链接时机 | 编译期 | 加载期/运行期 |
| 最终大小 | 被复制到可执行文件 | 独立文件，运行时加载 |
| 启动速度 | 快（无需加载） | 稍慢（需加载动态库） |
| 更新 | 需要重新链接 | 替换 .dll 即可 |
| 多个进程 | 每个进程有一份拷贝 | 内存中共享一份代码 |

---

## 7. Qt 与 Boost 框架

### 题 22：Qt 的信号槽（Signal & Slot）机制是什么？和回调函数有什么区别？

**考察点**：Qt 核心机制、观察者模式

**参考答案**：

```cpp
// Qt 信号槽：当某个事件发生时，信号自动发射，连接该信号的槽会被调用

#include <QObject>
#include <QPushButton>

// 自定义类必须继承 QObject 并包含 Q_OBJECT 宏
class Counter : public QObject {
    Q_OBJECT
private:
    int value = 0;
public:
    // 槽函数（处理信号的函数）
public slots:
    void increment() {
        value++;
        emit valueChanged(value);  // 发射信号
    }

    // 信号（声明即可，不需要实现）
signals:
    void valueChanged(int newValue);
};

// 使用
Counter counter;
QPushButton button("加一");

// 连接：按钮点击 → 计数器增加
QObject::connect(&button, &QPushButton::clicked,
                 &counter, &Counter::increment);

// Lambda 槽（Qt5 起支持）
QObject::connect(&button, &QPushButton::clicked, [&counter]() {
    // 响应点击事件
});
```

| 特性 | 信号槽 | 传统回调 |
|------|--------|---------|
| 类型安全 | 是（参数不匹配编译报错） | 否（void* 易出错） |
| 松耦合 | 是（发送者不需要知道接收者） | 否 |
| 线程安全 | 支持跨线程调用 | 需手动处理 |
| 性能 | 稍慢（MOC 生成代码） | 快（直接函数调用） |

---

### 题 23：Boost 库中你常用的组件有哪些？

**考察点**：Boost 库、实用组件

**参考答案**：

```cpp
#include <boost/smart_ptr.hpp>      // 智能指针（C++11 之前）
#include <boost/filesystem.hpp>     // 文件系统操作（C++17 已纳入标准）
#include <boost/lexical_cast.hpp>   // 字符串和数值互转
#include <boost/algorithm/string.hpp> // 字符串算法

// 1. boost::filesystem（C++17 前很实用）
boost::filesystem::path p("data/employees.dat");
if (boost::filesystem::exists(p)) {
    std::cout << "文件大小: " << boost::filesystem::file_size(p) << std::endl;
}
// C++17 后可以用 std::filesystem

// 2. boost::lexical_cast（安全的字符串/数值转换）
int i = boost::lexical_cast<int>("42");
double d = boost::lexical_cast<double>("3.14");
std::string s = boost::lexical_cast<std::string>(42);
// 比 atoi 安全，比 stringstream 简洁

// 3. boost::algorithm（字符串工具）
std::string str = " Hello World ";
boost::trim(str);                           // 去除空格
boost::to_upper(str);                       // 转大写
std::vector<std::string> parts;
boost::split(parts, "a,b,c", boost::is_any_of(","));  // 分割

// 4. boost::asio（网络编程）
boost::asio::io_context io;
boost::asio::ip::tcp::socket sock(io);
```

**提示**：很多 Boost 组件后来被 C++17/20 标准采纳（filesystem、optional、variant、any 等）。能用标准库的就用标准库，减少第三方依赖。

---

### 题 24：Qt 中 `QObject` 的父子对象管理机制是怎样的？

**考察点**：Qt 内存管理、对象树

**参考答案**：

```cpp
#include <QObject>
#include <QLabel>

// Qt 的对象树：当父对象销毁时，自动销毁所有子对象
// 避免手动管理内存泄漏

QWidget* window = new QWidget();         // 创建顶级窗口
QLabel* label = new QLabel("Hello");     // 创建标签

// 将 label 设为 window 的子对象
// 方式一：显式设置父对象
label->setParent(window);

// 方式二：构造函数传父对象（推荐）
QLabel* label2 = new QLabel("World", window);

// 当 window 被删除时，label 和 label2 自动被删除
delete window;
// 不需要 delete label, label2

// 对象树遍历
const QObjectList& children = window->children();
for (QObject* child : children) {
    if (QLabel* label = qobject_cast<QLabel*>(child)) {
        // 找到了 QLabel 子对象
    }
}

// 避免重复删除
// 如果已经通过父子关系管理，不要手动 delete 子对象
QLabel* subLabel = new QLabel("sub", label);  // 子对象的子对象
// 只需要 delete window → 自动释放所有嵌套子对象
```

**提示**：Qt 的对象树是其内存管理的基础，也是观察者模式的一种体现。

---

### 题 25：你如何看待现代 C++ 的发展趋势？C++ 学习路径的建议？

**考察点**：C++ 全局观、学习建议

**参考答案**：

**C++ 发展三大趋势**：

1. **从"手动"到"自动"**
   - 裸指针 → 智能指针
   - 手动资源管理 → RAII
   - malloc/free → 容器 + 智能指针

2. **从"复杂"到"简洁"**
   - C 风格数组 → std::array/std::vector
   - 手动类型声明 → auto
   - 传统继承 → 模板 + concept
   - 重复代码 → Lambda + 算法

3. **从"C with Classes"到"现代 C++"**
   - C++11 是分水岭：移动语义、智能指针、Lambda
   - C++17 是实用化：if constexpr、结构化绑定、filesystem
   - C++20 是革命性：concept、range、协程

**学习路径建议**：

```
           C++ 学习路线图
               ↓
      第一阶段：基础语法（01~10）
      ┌─ 变量、循环、函数、指针
      │
      第二阶段：面向对象（11~18）
      ┌─ 类、继承、多态、异常
      │
      第三阶段：进阶特性（19~27）
      ┌─ 模板、STL、智能指针
      │
      第四阶段：现代 C++（28~32）
      ┌─ 移动语义、C++17/20
      │
      第五阶段：工程实践（33~35）
      ┌─ CMake、Qt、Boost
      │
      └→ 综合项目（36）：实践落地
```

**核心建议**：
1. 不要一上来就学 C++20 新特性——基础不牢地动山摇
2. 多写代码——C++ 是"看不会"的语言
3. 学习阅读 STL 源码——最好的学习资料
4. 注意区分"老 C++"和"现代 C++"——面试官更看重现代 C++ 的能力

---

> 三篇面试题至此全部完成！祝你学习顺利，面试成功！
