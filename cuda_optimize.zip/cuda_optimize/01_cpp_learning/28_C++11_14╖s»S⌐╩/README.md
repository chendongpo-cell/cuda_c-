# 28 C++11/14 新特性

## 概述

C++11 被公认为"现代 C++"的起点，它带来了大量革命性的语言特性和标准库改进。C++14 则是在 C++11 基础上的一次小幅增强。本章将系统介绍这些关键新特性。

---

## 1. auto 关键字 — 自动类型推导

`auto` 让编译器根据初始化表达式自动推断变量类型，极大地简化了代码编写。

```cpp
auto i = 42;        // int
auto d = 3.14;      // double
auto s = "hello";   // const char*
```

**优点**：减少冗长的类型声明，尤其在迭代器和模板中非常有用。

---

## 2. decltype — 获取表达式的类型

`decltype` 用于获取表达式的类型，而不实际计算该表达式。

```cpp
int x = 10;
decltype(x) y = 20;   // y 的类型是 int
```

**与 auto 的区别**：`auto` 推导时会忽略引用和顶层 const，而 `decltype` 会完整保留类型信息。

---

## 3. nullptr — 空指针字面量

在 C++11 之前，空指针用 `NULL`（实际上是整数 0）表示，容易导致类型混淆。

```cpp
void f(int);      // #1
void f(char*);    // #2

f(NULL);    // 调用 #1（因为 NULL 是 0）
f(nullptr); // 调用 #2（nullptr 是真正的空指针类型）
```

`nullptr` 的类型是 `std::nullptr_t`，可以隐式转换为任何指针类型，但不能转换为整数。

---

## 4. 基于范围的 for 循环 (Range-based for loop)

简化遍历容器元素的语法。

```cpp
std::vector<int> v = {1, 2, 3, 4, 5};
for (int x : v) {
    // 遍历 v 中的每个元素
}
for (auto& x : v) {
    x *= 2;  // 通过引用修改元素
}
```

---

## 5. override 和 final

- **override**：显式标记派生类中重写的虚函数，让编译器检查是否真的覆盖了基类虚函数。
- **final**：阻止类被继承，或阻止虚函数被进一步重写。

```cpp
struct Base {
    virtual void foo();
};
struct Derived : Base {
    void foo() override;  // 编译器确保正确重写
};
struct FinalClass final {
    // 此类不能被继承
};
```

---

## 6. default 和 delete 关键字

- `= default`：显式要求编译器生成默认版本的特殊成员函数。
- `= delete`：禁止某个函数被调用。

```cpp
struct A {
    A() = default;           // 使用编译器生成的默认构造函数
    A(const A&) = delete;    // 禁止拷贝构造
};
```

---

## 7. 枚举类 (enum class) — 强类型枚举

传统 `enum` 存在作用域污染和隐式整数转换问题。

```cpp
enum class Color { Red, Green, Blue };
Color c = Color::Red;        // 必须作用域限定
int i = Color::Red;          // 错误！不能隐式转换
```

**优点**：强作用域、无隐式转换、可指定底层类型。

---

## 8. constexpr — 编译时常量

`constexpr` 告诉编译器表达式可以在编译期求值，提高运行时性能。

```cpp
constexpr int square(int x) {
    return x * x;
}
int arr[square(5)];  // 编译期确定数组大小
```

C++14 放宽了 `constexpr` 函数的限制，允许在函数内使用局部变量、循环和条件分支。

---

## 9. std::array — 固定大小数组

`std::array` 是一个封装了固定大小数组的容器，兼具 C 数组的性能和 STL 容器的接口。

```cpp
std::array<int, 5> arr = {1, 2, 3, 4, 5};
arr.size();       // 5
arr[0];           // 访问元素
```

---

## 10. std::tuple — 元组

`std::tuple` 是固定大小的异质值集合。

```cpp
auto t = std::make_tuple(42, 3.14, "hello");
int i = std::get<0>(t);       // 42
double d = std::get<1>(t);    // 3.14
```

---

## 11. chrono 库 — 时间处理

`<chrono>` 库提供了精确的时间点和时间间隔处理。

```cpp
auto start = std::chrono::high_resolution_clock::now();
// ... 执行代码 ...
auto end = std::chrono::high_resolution_clock::now();
auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
```

---

## 总结

C++11/14 让 C++ 变得更现代、更安全、更易用。掌握这些特性是成为现代 C++ 开发者的第一步。

| 特性 | 引入版本 | 核心作用 |
|------|---------|---------|
| auto | C++11 | 自动类型推导 |
| decltype | C++11 | 获取表达式类型 |
| nullptr | C++11 | 类型安全的空指针 |
| range-for | C++11 | 简化遍历 |
| override/final | C++11 | 虚函数控制 |
| default/delete | C++11 | 函数控制 |
| enum class | C++11 | 强类型枚举 |
| constexpr | C++11 | 编译期计算 |
| std::array | C++11 | 固定大小数组 |
| std::tuple | C++11 | 异质值集合 |
| chrono | C++11 | 时间处理 |
