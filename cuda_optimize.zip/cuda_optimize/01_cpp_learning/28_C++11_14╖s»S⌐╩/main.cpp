#include <iostream>   // 标准输入输出流库，用于控制台输出
#include <vector>
#include <algorithm>  // 使用 std::sort 排序算法     // 向量容器库，用于演示 range-based for
#include <array>      // 固定大小数组库，用于演示 std::array
#include <tuple>      // 元组库，用于演示 std::tuple
#include <chrono>     // 时间库，用于演示 chrono 计时
#include <string>     // 字符串库，用于演示 decltype
#include <map>        // 映射容器库，用于演示 auto 在迭代器中的应用

// ========== 1. 演示 override 和 final ==========

// 定义一个基类 Base
struct Base {
    // 虚函数 foo，允许派生类重写
    virtual void foo() const {
        std::cout << "Base::foo()" << std::endl;
    }
    // 虚函数 bar
    virtual void bar() const {
        std::cout << "Base::bar()" << std::endl;
    }
};

// 派生类 Derived，继承自 Base
struct Derived : Base {
    // 使用 override 关键字显式标记重写，编译器会检查是否真的覆盖了基类的虚函数
    void foo() const override {
        std::cout << "Derived::foo()" << std::endl;
    }
    // 如果写错函数签名（比如漏掉 const），编译器会报错，避免了难以发现的 bug
    // void bar() override { }  // 如果去掉 const，无法通过编译
};

// 被 final 标记的类，不能被继承
struct FinalClass final {
    void show() const {
        std::cout << "FinalClass::show()" << std::endl;
    }
};
// struct Derived2 : FinalClass {};  // 错误！FinalClass 是 final 的，不可继承

// ========== 2. 演示 = default 和 = delete ==========

// 定义一个带有 default/delete 的类
class MyClass {
public:
    // = default 告诉编译器生成默认构造函数
    MyClass() = default;

    // 拷贝构造函数被 = delete 禁止，尝试拷贝会导致编译错误
    MyClass(const MyClass&) = delete;

    // 赋值运算符被 = delete 禁止
    MyClass& operator=(const MyClass&) = delete;

    // 普通成员函数，用于输出信息
    void greet() const {
        std::cout << "Hello from MyClass" << std::endl;
    }
};

// ========== 3. 演示 enum class（强类型枚举）==========

// 传统的 enum（不推荐）：名称会泄漏到外层作用域
enum OldColor { OLD_RED, OLD_GREEN, OLD_BLUE };
// 这里可以直接写 OLD_RED，不需要 OldColor::OLD_RED

// 使用 enum class（强类型枚举）：名称不会泄漏到外层作用域
enum class Color { Red, Green, Blue };
enum class TrafficLight { Red, Yellow, Green };
// 注意：Color::Red 和 TrafficLight::Red 不会冲突，因为它们在各自的作用域内

// ========== 4. 演示 constexpr（编译期常量）==========

// constexpr 函数可以在编译期求值
// 计算阶乘的 constexpr 版本
constexpr int factorial(int n) {
    // C++14 允许 constexpr 函数中使用局部变量和循环
    int result = 1;
    for (int i = 2; i <= n; ++i) {
        result *= i;
    }
    return result;
}

// constexpr 函数的另一个例子：判断是否为闰年
constexpr bool isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

// ========== 5. 演示 chrono 计时 ==========

// 一个简单的计时函数模板，用于测量某个操作的执行时间
template<typename Func>
void measureTime(const std::string& label, Func func) {
    // 获取高精度时钟的当前时间点（开始时间）
    auto start = std::chrono::high_resolution_clock::now();

    // 执行传入的函数
    func();

    // 获取高精度时钟的当前时间点（结束时间）
    auto end = std::chrono::high_resolution_clock::now();

    // 计算时间差，并转换为微秒
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);

    // 输出耗时信息
    std::cout << label << " 耗时: " << duration.count() << " 微秒" << std::endl;
}

// ========== 主函数 ==========

int main() {
    // ====================================================================
    // 1. auto 关键字演示：编译器自动推导变量类型
    // ====================================================================
    std::cout << "===== 1. auto 自动类型推导 =====" << std::endl;

    auto i = 42;                    // int 类型，编译器自动推导为 int
    auto d = 3.14159;               // double 类型，编译器自动推导为 double
    auto s = "Hello, C++11!";       // const char* 类型
    auto v = std::vector<int>{1, 2, 3, 4, 5};  // std::vector<int> 类型

    std::cout << "auto i = " << i << " (int)" << std::endl;
    std::cout << "auto d = " << d << " (double)" << std::endl;
    std::cout << "auto s = " << s << " (const char*)" << std::endl;

    // auto 在迭代器中特别有用，可以避免写冗长的迭代器类型
    std::map<std::string, int> scores = {{"Alice", 95}, {"Bob", 87}, {"Charlie", 92}};
    // 传统写法需要写：std::map<std::string, int>::iterator it = scores.begin();
    // auto 可以大大简化：
    for (auto it = scores.begin(); it != scores.end(); ++it) {
        // it->first 是键（string），it->second 是值（int）
        std::cout << it->first << " 的分数: " << it->second << std::endl;
    }

    // auto& 用于引用，可以修改容器中的元素
    for (auto& kv : scores) {
        kv.second += 5;  // 每人加 5 分
    }
    std::cout << "加分后 Alice 的分数: " << scores["Alice"] << std::endl;

    std::cout << std::endl;

    // ====================================================================
    // 2. decltype 演示：获取表达式的类型，而不实际求值
    // ====================================================================
    std::cout << "===== 2. decltype 类型查询 =====" << std::endl;

    int x = 10;
    const int cx = x;
    const int& crx = x;

    // decltype(x)       -> int
    // decltype(cx)      -> const int
    // decltype(crx)     -> const int&
    // decltype((x))     -> int&（括号中的 x 是表达式）

    decltype(x) y = 20;             // y 的类型是 int
    decltype(cx) cy = 30;           // cy 的类型是 const int
    decltype(3.14 + 100) mixed = 0; // mixed 的类型是 double（int+double=double）

    std::cout << "decltype(x) y = " << y << " (int)" << std::endl;
    std::cout << "decltype(cx) cy = " << cy << " (const int)" << std::endl;
    std::cout << "decltype(3.14+100) mixed = " << mixed << " (double)" << std::endl;

    // decltype 配合 auto 用于函数返回值类型推导（尾置返回类型）
    // 这是 C++11 中常用的技巧，用于模板编程
    auto add = [](auto a, auto b) -> decltype(a + b) {
        return a + b;
    };
    std::cout << "add(5, 3) = " << add(5, 3) << std::endl;
    std::cout << "add(2.5, 1.5) = " << add(2.5, 1.5) << std::endl;

    std::cout << std::endl;

    // ====================================================================
    // 3. nullptr 演示：类型安全的空指针
    // ====================================================================
    std::cout << "===== 3. nullptr 空指针 =====" << std::endl;

    // nullptr 的类型是 std::nullptr_t，可以隐式转换为任意指针类型
    int* p1 = nullptr;      // 正确的做法：使用 nullptr 初始化指针
    char* p2 = nullptr;     // nullptr 可以赋值给任意类型指针
    double* p3 = nullptr;   // 也是合法的

    // nullptr 不能隐式转换为整数，这是与 NULL 的关键区别
    // bool b = nullptr;     // 有些编译器允许，但不推荐
    // int n = nullptr;      // 错误！nullptr 不能转换为整数

    if (p1 == nullptr) {
        std::cout << "p1 是空指针 (nullptr)" << std::endl;
    }

    // 在函数重载场景中，nullptr 的优势明显
    auto f = [](int) { std::cout << "调用 f(int)" << std::endl; };
    auto g = [](char*) { std::cout << "调用 f(char*)" << std::endl; };

    // 如果使用 NULL 重载会调用 int 版本，因为 NULL 本质是 0
    // f(NULL);     // 调用 int 版本
    // f(nullptr);  // 不能这样用，这里只是演示概念

    std::cout << std::endl;

    // ====================================================================
    // 4. 基于范围的 for 循环 (range-based for loop)
    // ====================================================================
    std::cout << "===== 4. 基于范围的 for 循环 =====" << std::endl;

    // 遍历数组
    int arr[] = {10, 20, 30, 40, 50};
    std::cout << "遍历数组: ";
    for (int val : arr) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 遍历 vector，使用 auto& 修改元素
    std::vector<int> nums = {1, 2, 3, 4, 5};
    for (auto& n : nums) {
        n *= 2;  // 通过引用修改原容器中的元素
    }
    std::cout << "翻倍后的 vector: ";
    for (const auto& n : nums) {
        std::cout << n << " ";
    }
    std::cout << std::endl;

    // 使用 auto&&（通用引用）遍历，适用于任何容器
    std::cout << "使用 auto&& 遍历: ";
    for (auto&& n : nums) {
        std::cout << n << " ";
    }
    std::cout << std::endl;

    std::cout << std::endl;

    // ====================================================================
    // 5. override 和 final 演示
    // ====================================================================
    std::cout << "===== 5. override 和 final =====" << std::endl;

    // 通过基类指针调用虚函数，展示多态
    Base* ptr = new Derived();
    ptr->foo();  // 调用 Derived::foo()，因为 foo 被 override
    ptr->bar();  // 调用 Base::bar()
    delete ptr;

    // final 类的使用
    FinalClass fc;
    fc.show();

    std::cout << std::endl;

    // ====================================================================
    // 6. = default 和 = delete 演示
    // ====================================================================
    std::cout << "===== 6. default 和 delete =====" << std::endl;

    MyClass obj1;           // 使用 =default 生成的默认构造函数
    // MyClass obj2(obj1);  // 错误！拷贝构造函数被 =delete
    // MyClass obj3 = obj1; // 错误！拷贝构造函数被 =delete
    obj1.greet();
    std::cout << "MyClass 对象创建成功（拷贝被禁止）" << std::endl;

    // = delete 还可以用于禁止某些重载
    // 例如，禁止接受 double 参数的函数
    auto onlyInt = [](int) { std::cout << "只接受整数" << std::endl; };
    // 注意：lambda 不能直接 =delete，这里只是概念演示

    std::cout << std::endl;

    // ====================================================================
    // 7. enum class（强类型枚举）演示
    // ====================================================================
    std::cout << "===== 7. enum class 强类型枚举 =====" << std::endl;

    // 使用 enum class 时必须带上作用域
    Color myColor = Color::Blue;
    TrafficLight light = TrafficLight::Green;

    // 枚举值不能隐式转换为整数
    // int val = myColor;   // 错误！不能隐式转换
    int val = static_cast<int>(myColor);  // 必须显式转换
    std::cout << "Color::Blue 的整数值: " << val << std::endl;

    // switch 语句中使用 enum class
    switch (myColor) {
        case Color::Red:
            std::cout << "颜色是红色" << std::endl;
            break;
        case Color::Green:
            std::cout << "颜色是绿色" << std::endl;
            break;
        case Color::Blue:
            std::cout << "颜色是蓝色" << std::endl;
            break;
    }

    // 传统 enum 的问题：名称冲突
    // 如果同时有 enum A { Red }; 和 enum B { Red }; 会编译错误
    // 但 enum class 不会：Color::Red 和 TrafficLight::Red 是不同的

    std::cout << std::endl;

    // ====================================================================
    // 8. constexpr（编译期常量）演示
    // ====================================================================
    std::cout << "===== 8. constexpr 编译期常量 =====" << std::endl;

    // factorial(5) 在编译期求值，结果用于初始化数组大小
    constexpr int fact5 = factorial(5);
    std::cout << "5! = " << fact5 << std::endl;

    // constexpr 变量可以用在需要编译期常量的地方
    int fib[factorial(4)];  // 24 个元素的数组，编译期确定大小
    std::cout << "fib 数组大小: " << sizeof(fib) / sizeof(fib[0]) << std::endl;

    // constexpr 判断闰年
    constexpr bool year2024 = isLeapYear(2024);
    constexpr bool year2025 = isLeapYear(2025);
    std::cout << "2024 年" << (year2024 ? "是" : "不是") << "闰年" << std::endl;
    std::cout << "2025 年" << (year2025 ? "是" : "不是") << "闰年" << std::endl;

    std::cout << std::endl;

    // ====================================================================
    // 9. std::array（固定大小数组）演示
    // ====================================================================
    std::cout << "===== 9. std::array 固定大小数组 =====" << std::endl;

    // std::array 是 C++11 引入的固定大小数组容器
    std::array<int, 5> myArray = {100, 200, 300, 400, 500};

    // 具有 STL 容器的标准接口
    std::cout << "std::array 大小: " << myArray.size() << std::endl;
    std::cout << "第一个元素: " << myArray.front() << std::endl;
    std::cout << "最后一个元素: " << myArray.back() << std::endl;

    // 可以使用 range-based for 遍历
    std::cout << "遍历 myArray: ";
    for (const auto& elem : myArray) {
        std::cout << elem << " ";
    }
    std::cout << std::endl;

    // at() 方法带边界检查
    try {
        int val = myArray.at(10);  // 抛出 std::out_of_range 异常
    } catch (const std::out_of_range& e) {
        std::cout << "at() 边界检查捕获到异常: " << e.what() << std::endl;
    }

    std::cout << std::endl;

    // ====================================================================
    // 10. std::tuple（元组）演示
    // ====================================================================
    std::cout << "===== 10. std::tuple 元组 =====" << std::endl;

    // 创建元组，包含不同类型的数据
    auto person = std::make_tuple("张三", 28, 175.5);
    // 也可以直接构造
    // std::tuple<std::string, int, double> person("张三", 28, 175.5);

    // 使用 std::get 按索引访问元组元素
    std::cout << "姓名: " << std::get<0>(person) << std::endl;
    std::cout << "年龄: " << std::get<1>(person) << std::endl;
    std::cout << "身高: " << std::get<2>(person) << std::endl;

    // C++14 引入：按类型获取元组元素（仅当类型唯一时可用）
    // std::tuple<int, double, std::string> t(1, 2.0, "hello");
    // std::cout << std::get<double>(t);  // C++14 特性

    // 使用 std::tie 解包元组
    std::string name;
    int age;
    double height;
    std::tie(name, age, height) = person;
    std::cout << "解包后 - 姓名: " << name << ", 年龄: " << age << ", 身高: " << height << std::endl;

    // 合并两个元组（C++14）
    auto tuple1 = std::make_tuple(1, 2.0);
    auto tuple2 = std::make_tuple("abc", 'x');
    // auto merged = std::tuple_cat(tuple1, tuple2);  // 可用于合并

    std::cout << std::endl;

    // ====================================================================
    // 11. chrono 库计时演示
    // ====================================================================
    std::cout << "===== 11. chrono 计时 =====" << std::endl;

    // 测量一个简单循环的执行时间
    measureTime("100万次循环", []() {
        volatile long long sum = 0;  // volatile 防止编译器优化掉循环
        for (int i = 0; i < 1000000; ++i) {
            sum += i;
        }
    });

    // 更复杂的时间测量：向量排序
    std::vector<int> sortVec;
    for (int i = 10000; i > 0; --i) {
        sortVec.push_back(i);
    }

    measureTime("对10000个元素排序", [&sortVec]() {
        std::sort(sortVec.begin(), sortVec.end());
    });

    // chrono 时间点示例
    auto now = std::chrono::system_clock::now();
    // 将时间点转换为 time_t 以便显示
    std::time_t now_time = std::chrono::system_clock::to_time_t(now);
    std::cout << "当前系统时间: " << std::ctime(&now_time);

    // 时间间隔示例
    std::chrono::seconds fiveSeconds(5);                 // 5 秒
    std::chrono::milliseconds ms(500);                   // 500 毫秒
    std::chrono::microseconds us = ms;                   // 毫秒可隐式转换为微秒
    std::cout << "500 毫秒 = " << us.count() << " 微秒" << std::endl;

    // 时间运算
    auto total = fiveSeconds + ms;  // 5.5 秒
    std::cout << "5秒 + 500毫秒 = " << total.count() << " 毫秒" << std::endl;

    std::cout << std::endl;

    // ====================================================================
    // 总结输出
    // ====================================================================
    std::cout << "===== C++11/14 新特性演示完成 =====" << std::endl;
    std::cout << "演示了以下特性:" << std::endl;
    std::cout << "  1. auto 自动类型推导" << std::endl;
    std::cout << "  2. decltype 类型查询" << std::endl;
    std::cout << "  3. nullptr 空指针" << std::endl;
    std::cout << "  4. 基于范围的 for 循环" << std::endl;
    std::cout << "  5. override 和 final" << std::endl;
    std::cout << "  6. =default 和 =delete" << std::endl;
    std::cout << "  7. enum class 强类型枚举" << std::endl;
    std::cout << "  8. constexpr 编译期常量" << std::endl;
    std::cout << "  9. std::array 固定大小数组" << std::endl;
    std::cout << "  10. std::tuple 元组" << std::endl;
    std::cout << "  11. chrono 时间库" << std::endl;

    return 0;  // 程序正常退出
}
