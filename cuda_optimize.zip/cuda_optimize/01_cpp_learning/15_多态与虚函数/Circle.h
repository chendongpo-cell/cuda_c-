// ============================================================
// Circle.h —— Circle 派生类头文件
// 圆形类，继承自 Shape，实现了纯虚函数 draw()
// ============================================================

#ifndef CIRCLE_H  // 防止头文件被重复包含
#define CIRCLE_H

#include "Shape.h"  // 包含基类 Shape 的头文件

// ============================================================
// Circle 类：公有继承自 Shape
// 表示一个圆形形状，拥有半径属性
// ============================================================
class Circle : public Shape {
public:
    // 构造函数：接收名称和半径
    // 调用基类 Shape 的构造函数来初始化名称部分
    // 参数 name：圆的名称，参数 radius：圆的半径
    Circle(const string& name, double radius);

    // 析构函数：销毁 Circle 对象时释放资源
    // 使用 override 关键字表明重写了基类的虚析构（虽然不是纯虚）
    ~Circle() override;

    // 重写基类的纯虚函数 draw()
    // override 关键字让编译器检查签名是否与基类匹配
    void draw() const override;

    // 获取圆的面积：Circle 特有的成员函数
    // 注意：这个函数不在基类 Shape 中，不能通过 Shape 指针调用
    // 返回值：double 类型的面积值
    double getArea() const;

private:
    // 圆的半径私有成员变量
    double radius;
};

#endif  // CIRCLE_H 头文件保护宏结束
