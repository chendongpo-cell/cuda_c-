// ============================================================
// Triangle.h —— Triangle 派生类头文件
// 三角形类，继承自 Shape，实现了纯虚函数 draw()
// ============================================================

#ifndef TRIANGLE_H  // 防止头文件被重复包含
#define TRIANGLE_H

#include "Shape.h"  // 包含基类 Shape 的头文件

// ============================================================
// Triangle 类：公有继承自 Shape
// 表示一个三角形形状，拥有底边和高属性
// ============================================================
class Triangle : public Shape {
public:
    // 构造函数：接收名称、底边和高
    // 调用基类 Shape 的构造函数来初始化名称部分
    // 参数 name：三角形的名称，参数 base：底边长度，参数 height：高度
    Triangle(const string& name, double base, double height);

    // 析构函数：销毁 Triangle 对象时释放资源
    // override 关键字表明重写了基类的虚析构函数
    ~Triangle() override;

    // 重写基类的纯虚函数 draw()
    // 展示三角形的绘制行为，输出名称、底边和高度信息
    void draw() const override;

private:
    // 三角形的底边长度私有成员变量
    double base;
    // 三角形的高度私有成员变量
    double height;
};

#endif  // TRIANGLE_H 头文件保护宏结束
