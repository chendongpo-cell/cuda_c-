// ============================================================
// Rectangle.h —— Rectangle 派生类头文件
// 矩形类，继承自 Shape，实现了纯虚函数 draw()
// ============================================================

#ifndef RECTANGLE_H  // 防止头文件被重复包含
#define RECTANGLE_H

#include "Shape.h"  // 包含基类 Shape 的头文件

// ============================================================
// Rectangle 类：公有继承自 Shape
// 表示一个矩形形状，拥有宽度和高度属性
// ============================================================
class Rectangle : public Shape {
public:
    // 构造函数：接收名称、宽度和高度
    // 调用基类 Shape 的构造函数来初始化名称部分
    // 参数 name：矩形的名称，参数 width：宽度，参数 height：高度
    Rectangle(const string& name, double width, double height);

    // 析构函数：销毁 Rectangle 对象时释放资源
    // override 关键字表明重写了基类的虚析构函数
    ~Rectangle() override;

    // 重写基类的纯虚函数 draw()
    // 展示矩形的绘制行为，输出名称、宽度和高度信息
    void draw() const override;

    // 获取矩形的面积：Rectangle 特有的成员函数
    // 返回值：double 类型的面积值（宽 × 高）
    double getArea() const;

private:
    // 矩形的宽度私有成员变量
    double width;
    // 矩形的高度私有成员变量
    double height;
};

#endif  // RECTANGLE_H 头文件保护宏结束
