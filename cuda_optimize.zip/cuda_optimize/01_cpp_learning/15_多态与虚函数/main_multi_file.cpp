// 多文件演示：多态体系拆分为多个.h/.cpp
// 本文件用#include包含各个头文件，实现与原始main.cpp相同的功能
// 每一个步骤都有详细的中文注释解释其作用

// 包含输入输出流头文件，用于控制台输入输出
#include <iostream>
// 包含字符串头文件，用于使用 std::string 类型
#include <string>

// 包含自定义的 Shape 抽象基类头文件
#include "Shape.h"
// 包含自定义的 Circle 派生类头文件
#include "Circle.h"
// 包含自定义的 Rectangle 派生类头文件
#include "Rectangle.h"
// 包含自定义的 Triangle 派生类头文件
#include "Triangle.h"

// 使用标准命名空间，避免每次写 std:: 前缀
using namespace std;

// ============================================================
// 全局函数：通过基类引用展示多态
// 参数 shape：Shape 类型的引用，可以接受任何 Shape 派生类的对象
// 函数内部通过基类引用调用虚函数，表现出的实际行为取决于传入的对象类型
// ============================================================
void displayShapeInfo(const Shape& shape) {
    // 调用虚函数 draw() —— 运行时多态
    // 虽然参数类型是 const Shape&，但实际调用的是派生类的 draw() 版本
    // 这是通过虚函数表（vtable）实现的动态绑定机制
    cout << "--- 显示形状信息 ---" << endl;
    shape.draw();
    cout << "--------------------" << endl;
}

// ============================================================
// 主函数：演示多态的多种使用方式
// 和原来的 main.cpp 逻辑完全一致，展示多文件项目结构下的多态用法
// ============================================================
int main() {
    // 输出程序标题，标明这是多文件版本的演示
    cout << "========== 多态与虚函数 演示（多文件版）==========" << endl;
    cout << endl;

    // ========== 第一部分：通过基类指针实现多态 ==========
    cout << "【第一部分：基类指针实现多态】" << endl;

    // 创建派生类对象的指针，但赋值给基类指针 Shape*
    // 这是多态的关键：基类指针可以指向任何派生类对象
    // 这样我们就可以用统一的接口操作不同类型的对象
    Shape* shape1 = new Circle("小圆", 5.0);       // 基类指针指向 Circle 对象
    Shape* shape2 = new Rectangle("大方", 10.0, 20.0); // 基类指针指向 Rectangle 对象
    Shape* shape3 = new Triangle("三角", 6.0, 8.0);   // 基类指针指向 Triangle 对象

    // 通过基类指针调用虚函数 draw()
    // 虽然三个指针类型都是 Shape*，但实际调用的是各自派生类的 draw()
    // 这就是"多态"的含义：相同的调用语句，不同的执行结果
    shape1->draw();  // 实际调用 Circle::draw()
    shape2->draw();  // 实际调用 Rectangle::draw()
    shape3->draw();  // 实际调用 Triangle::draw()

    cout << endl;

    // 通过基类指针删除派生类对象
    // 由于 Shape 的析构函数是 virtual 的，会先调用派生类析构，再调用基类析构
    // 如果不加 virtual 关键字，这里只会调用 Shape 的析构函数，造成内存泄漏
    delete shape1;  // 先调用 ~Circle()，再调用 ~Shape()
    delete shape2;  // 先调用 ~Rectangle()，再调用 ~Shape()
    delete shape3;  // 先调用 ~Triangle()，再调用 ~Shape()

    cout << endl;

    // ========== 第二部分：通过基类引用实现多态 ==========
    cout << "【第二部分：基类引用实现多态】" << endl;

    // 创建栈上的派生类对象
    Circle circle("大圆", 10.0);       // 创建一个圆形对象
    Rectangle rect("长条", 5.0, 15.0); // 创建一个矩形对象

    // 通过基类引用调用虚函数——引用同样可以实现多态
    // 引用和指针一样，可以指向派生类对象并调用正确的虚函数
    Shape& ref1 = circle;  // 基类引用绑定到 Circle 对象
    Shape& ref2 = rect;    // 基类引用绑定到 Rectangle 对象

    ref1.draw();  // 实际调用 Circle::draw()
    ref2.draw();  // 实际调用 Rectangle::draw()

    cout << endl;

    // ========== 第三部分：函数参数中的多态 ==========
    cout << "【第三部分：函数参数中的多态】" << endl;

    // 将派生类对象传递给接受基类引用的函数
    // 函数内部通过基类引用调用虚函数，表现出多态行为
    displayShapeInfo(circle);   // 传入 Circle 对象，调用 Circle::draw()
    displayShapeInfo(rect);     // 传入 Rectangle 对象，调用 Rectangle::draw()

    // ========== 第四部分：验证派生类特有的函数 ==========
    cout << "【第四部分：派生类特有函数】" << endl;

    // 直接通过派生类对象调用其特有函数（不是多态，就是普通调用）
    // 这些函数只能通过派生类指针或对象调用，不能通过基类指针调用
    cout << "Circle 的面积: " << circle.getArea() << endl;
    cout << "Rectangle 的面积: " << rect.getArea() << endl;

    // 注意：下面这种写法会出错（取消注释可验证）
    // Shape* p = &circle;
    // p->getArea();  // 编译错误！Shape 类没有 getArea() 函数

    cout << endl;

    // ========== 第五部分：不能实例化抽象类 ==========
    cout << "【第五部分：抽象类不能实例化】" << endl;
    cout << "Shape 是抽象类（含有纯虚函数），不能直接创建 Shape 对象。" << endl;
    // 如果取消下面这行的注释，编译器会报错：
    // Shape s("无名");  // 错误！不能实例化抽象类
    cout << endl;

    // 主函数返回 0，表示程序正常结束
    cout << "========== 程序结束 ==========" << endl;
    return 0;
}
