// ============================================================
// 15_多态与虚函数 main.cpp
// 演示：虚函数、纯虚函数、抽象类、虚析构函数、运行时多态
// ============================================================

// 包含输入输出流头文件，用于控制台输入输出
#include <iostream>
// 包含字符串头文件，用于使用 std::string 类型
#include <string>

// 使用标准命名空间，避免每次写 std:: 前缀
using namespace std;

// ============================================================
// 基类 Shape（抽象类）
// 包含纯虚函数，因此不能被实例化，只能作为接口/基类使用
// ============================================================
class Shape {
public:
    // 构造函数：初始化形状的名称
    // 参数 name：形状的名称字符串
    Shape(const string& name) : name(name) {
        // 输出构造信息，方便观察对象生命周期
        cout << "Shape 构造函数: " << name << endl;
    }

    // 虚析构函数：使用 virtual 关键字
    // 为什么需要虚析构函数？当通过基类指针删除派生类对象时，
    // 如果析构函数不是虚函数，派生类的析构函数不会被调用，
    // 导致派生类中分配的资源无法释放，造成内存泄漏。
    virtual ~Shape() {
        cout << "Shape 析构函数: " << name << endl;
    }

    // 纯虚函数 draw()：声明为 "= 0"
    // 纯虚函数在基类中没有实现，要求所有派生类必须提供自己的实现
    // 这样每个派生类可以有不同的绘制行为——这就是多态的核心
    virtual void draw() const = 0;

    // 普通成员函数：获取形状的名称
    // 这个函数不是虚函数，因此不参与运行时多态
    string getName() const { return name; }

private:
    // 私有成员变量：存储形状的名称
    string name;
};

// ============================================================
// 派生类 Circle（圆形）
// 继承自 Shape，必须实现 draw() 纯虚函数
// ============================================================
class Circle : public Shape {
public:
    // 构造函数：传入名称和半径
    // 调用基类 Shape 的构造函数来初始化名称
    Circle(const string& name, double radius)
        : Shape(name), radius(radius) {
        cout << "Circle 构造函数: " << name << endl;
    }

    // 析构函数：当 Circle 对象被销毁时调用
    // 由于基类析构函数是虚函数，通过基类指针删除时也会调用此析构函数
    ~Circle() override {
        cout << "Circle 析构函数: " << getName() << endl;
    }

    // 重写（override）基类的纯虚函数 draw()
    // 使用 override 关键字显式标明这是重写，让编译器帮我们检查签名是否匹配
    void draw() const override {
        // 输出圆形的绘制信息
        cout << "绘制圆形: " << getName()
             << " (半径 = " << radius << ")" << endl;
    }

    // 获取面积：Circle 特有的函数，不在基类中
    // 注意：这个函数不能通过 Shape 指针调用
    double getArea() const {
        // 圆的面积 = π × r²
        return 3.14159 * radius * radius;
    }

private:
    // 圆的半径
    double radius;
};

// ============================================================
// 派生类 Rectangle（矩形）
// 继承自 Shape，必须实现 draw() 纯虚函数
// ============================================================
class Rectangle : public Shape {
public:
    // 构造函数：传入名称、宽度和高度
    Rectangle(const string& name, double width, double height)
        : Shape(name), width(width), height(height) {
        cout << "Rectangle 构造函数: " << name << endl;
    }

    // 析构函数
    ~Rectangle() override {
        cout << "Rectangle 析构函数: " << getName() << endl;
    }

    // 重写纯虚函数 draw()
    void draw() const override {
        // 输出矩形的绘制信息
        cout << "绘制矩形: " << getName()
             << " (宽 = " << width << ", 高 = " << height << ")" << endl;
    }

    // 获取面积：Rectangle 特有的函数
    double getArea() const {
        // 矩形面积 = 宽 × 高
        return width * height;
    }

private:
    // 矩形的宽度和高度
    double width;
    double height;
};

// ============================================================
// 派生类 Triangle（三角形）
// 另一个 Shape 的派生类，进一步展示多态的灵活性
// ============================================================
class Triangle : public Shape {
public:
    // 构造函数：传入名称、底边和高
    Triangle(const string& name, double base, double height)
        : Shape(name), base(base), height(height) {
        cout << "Triangle 构造函数: " << name << endl;
    }

    // 析构函数
    ~Triangle() override {
        cout << "Triangle 析构函数: " << getName() << endl;
    }

    // 重写纯虚函数 draw()
    void draw() const override {
        // 输出三角形的绘制信息
        cout << "绘制三角形: " << getName()
             << " (底 = " << base << ", 高 = " << height << ")" << endl;
    }

private:
    // 三角形的底边和高
    double base;
    double height;
};

// ============================================================
// 全局函数：通过基类引用展示多态
// 参数 shape：Shape 类型的引用，可以接受任何 Shape 派生类的对象
// ============================================================
void displayShapeInfo(const Shape& shape) {
    // 调用虚函数 draw() —— 运行时多态
    // 虽然参数类型是 const Shape&，但实际调用的是派生类的 draw() 版本
    // 这是通过 vptr -> vtable 实现的动态绑定
    cout << "--- 显示形状信息 ---" << endl;
    shape.draw();
    cout << "--------------------" << endl;
}

// ============================================================
// 主函数：演示多态的多种使用方式
// ============================================================
int main() {
    // 输出程序标题
    cout << "========== 多态与虚函数 演示 ==========" << endl;
    cout << endl;

    // ========== 第一部分：通过基类指针实现多态 ==========
    cout << "【第一部分：基类指针实现多态】" << endl;

    // 创建派生类对象的指针，但赋值给基类指针 Shape*
    // 这是多态的关键：基类指针可以指向任何派生类对象
    Shape* shape1 = new Circle("小圆", 5.0);       // 基类指针指向 Circle 对象
    Shape* shape2 = new Rectangle("大方", 10.0, 20.0); // 基类指针指向 Rectangle 对象
    Shape* shape3 = new Triangle("三角", 6.0, 8.0);   // 基类指针指向 Triangle 对象

    // 通过基类指针调用虚函数 draw()
    // 虽然三个指针类型都是 Shape*，但实际调用的是各自派生类的 draw()
    // 这就是"多态"的含义：同一个调用语句，不同的行为
    shape1->draw();  // 实际调用 Circle::draw()
    shape2->draw();  // 实际调用 Rectangle::draw()
    shape3->draw();  // 实际调用 Triangle::draw()

    cout << endl;

    // 通过基类指针删除派生类对象
    // 由于 Shape 的析构函数是 virtual 的，会先调用派生类析构，再调用基类析构
    // 如果不加 virtual，这里只会调用 Shape 的析构函数，造成内存泄漏
    delete shape1;  // 先调用 ~Circle()，再调用 ~Shape()
    delete shape2;  // 先调用 ~Rectangle()，再调用 ~Shape()
    delete shape3;  // 先调用 ~Triangle()，再调用 ~Shape()

    cout << endl;

    // ========== 第二部分：通过基类引用实现多态 ==========
    cout << "【第二部分：基类引用实现多态】" << endl;

    // 创建栈上的派生类对象
    Circle circle("大圆", 10.0);
    Rectangle rect("长条", 5.0, 15.0);

    // 通过基类引用调用虚函数——同样实现多态
    // 引用和指针一样，可以指向派生类对象并调用正确的虚函数
    Shape& ref1 = circle;  // 基类引用绑定到 Circle 对象
    Shape& ref2 = rect;    // 基类引用绑定到 Rectangle 对象

    ref1.draw();  // 实际调用 Circle::draw()
    ref2.draw();  // 实际调用 Rectangle::draw()

    cout << endl;

    // ========== 第三部分：函数参数中的多态 ==========
    cout << "【第三部分：函数参数中的多态】" << endl;

    // 将派生类对象传递给接受基类引用的函数
    // 函数内部通过基类引用调用虚函数，表现出多态行为
    displayShapeInfo(circle);   // 传入 Circle 对象
    displayShapeInfo(rect);     // 传入 Rectangle 对象

    // ========== 第四部分：验证派生类特有的函数 ==========
    cout << "【第四部分：派生类特有函数】" << endl;

    // 直接通过派生类对象调用其特有函数（不是多态，就是普通调用）
    // 这些函数只能通过派生类指针/对象调用，不能通过基类指针调用
    cout << "Circle 的面积: " << circle.getArea() << endl;
    cout << "Rectangle 的面积: " << rect.getArea() << endl;

    // 注意：下面这种写法会出错（取消注释可验证）
    // Shape* p = &circle;
    // p->getArea();  // 编译错误！Shape 类没有 getArea() 函数

    cout << endl;

    // ========== 第五部分：不能实例化抽象类 ==========
    cout << "【第五部分：抽象类不能实例化】" << endl;
    cout << "Shape 是抽象类（含有纯虚函数），不能直接创建 Shape 对象。" << endl;
    // 如果取消下面这行的注释，编译器会报错：
    // Shape s("无名");  // 错误！不能实例化抽象类
    cout << endl;

    // 主函数返回 0，表示程序正常结束
    cout << "========== 程序结束 ==========" << endl;
    return 0;
}
