# 33_CMake构建系统

## 什么是 CMake？

CMake 是一个跨平台的开源构建系统生成器。它不直接编译代码，而是生成特定平台的原生构建文件（如 Makefile、Visual Studio 解决方案、Xcode 项目等）。CMake 使用名为 `CMakeLists.txt` 的配置文件来描述项目的构建过程。

## 为什么使用构建系统？

手动编译大型 C++ 项目非常繁琐且容易出错。构建系统带来以下好处：

- **自动化**：一键编译整个项目
- **跨平台**：同一套配置可在 Windows、Linux、macOS 上工作
- **依赖管理**：自动处理文件之间的依赖关系
- **可扩展性**：轻松添加新源文件、库和外部依赖
- **构建类型**：轻松切换 Debug 和 Release 模式

## CMakeLists.txt 结构

### cmake_minimum_required

指定 CMake 的最低版本要求：

```cmake
cmake_minimum_required(VERSION 3.10)
```

### project

定义项目名称和使用的语言：

```cmake
project(MyProject VERSION 1.0 LANGUAGES CXX)
```

### add_executable

从源文件创建可执行文件：

```cmake
add_executable(my_app main.cpp)
```

### add_library

从源文件创建库（静态或动态）：

```cmake
add_library(my_library STATIC math.cpp)
```

库类型：`STATIC`（静态库 .lib/.a）、`SHARED`（动态库 .dll/.so）、`MODULE`（插件）。

## 目标（Targets）

现代 CMake 的核心概念是**目标（Target）**。可执行文件和库都是目标。目标具有**属性**，例如：

- 包含目录（include directories）
- 链接的库（linked libraries）
- 编译定义（compile definitions）
- 编译选项（compile options）

## 变量

使用 `set` 命令定义变量，使用 `${}` 引用：

```cmake
set(SOURCES main.cpp helper.cpp)
add_executable(my_app ${SOURCES})
```

常用内置变量：

- `CMAKE_CXX_STANDARD`：C++ 标准版本
- `CMAKE_BUILD_TYPE`：构建类型
- `PROJECT_SOURCE_DIR`：项目源码根目录
- `PROJECT_BINARY_DIR`：项目构建目录

## 子目录（add_subdirectory）

将项目组织成多个子目录：

```cmake
add_subdirectory(math)
```

每个子目录拥有自己的 `CMakeLists.txt`，父目录可以引用子目录中定义的目标。

## find_package

查找并导入外部库：

```cmake
find_package(OpenCV REQUIRED)
```

`REQUIRED` 表示如果找不到库则报错。CMake 提供了大量的 FindXXX.cmake 模块。

## 常用命令

### target_include_directories

为目标添加头文件搜索路径：

```cmake
target_include_directories(my_app PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
```

作用域说明：
- `PRIVATE`：仅当前目标使用
- `PUBLIC`：当前目标和链接者都使用
- `INTERFACE`：仅链接者使用

### target_link_libraries

将目标与其他目标链接：

```cmake
target_link_libraries(my_app PRIVATE math_lib)
```

## 构建类型

- `Debug`：包含调试信息，无优化
- `Release`：开启优化，无调试信息
- `RelWithDebInfo`：开启优化，包含调试信息
- `MinSizeRel`：优化体积

配置构建类型：

```bash
cmake -DCMAKE_BUILD_TYPE=Debug ..
```

## 现代 CMake 最佳实践

1. **使用 target-based 命令**：优先使用 `target_include_directories` 而不是 `include_directories`
2. **使用 PRIVATE/PUBLIC/INTERFACE**：精确控制依赖传递
3. **指定 C++ 标准**：使用 `set(CMAKE_CXX_STANDARD 17)` 或 `target_compile_features()`
4. **不要使用全局命令**：避免 `include_directories`、`add_definitions` 等全局命令
5. **使用 find_package**：不要手写路径查找外部库
6. **分离构建目录**：在单独的 build 目录中构建，保持源码干净
7. **使用 Generator Expressions**：根据配置或平台条件性地设置属性

## 构建本示例项目

```bash
# 在项目根目录下
mkdir build && cd build
cmake ..
cmake --build .

# 或指定构建类型
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build .
```
