#ifndef MATH_FUNCTIONS_H  // 头文件保护宏：防止头文件被重复包含
#define MATH_FUNCTIONS_H  // 定义头文件保护宏

// ============================================================
// Math 库的头文件
// 声明了两个基本的数学运算函数：加法和减法
// 这些函数将被主程序调用展示 CMake 库链接功能
// ============================================================

/**
 * add - 计算两个整数的和
 * @param a: 第一个加数
 * @param b: 第二个加数
 * @return: a + b 的结果
 *
 * 示例：add(3, 5) 返回 8
 */
int add(int a, int b);  // 加法函数声明

/**
 * subtract - 计算两个整数的差
 * @param a: 被减数
 * @param b: 减数
 * @return: a - b 的结果
 *
 * 示例：subtract(10, 3) 返回 7
 */
int subtract(int a, int b);  // 减法函数声明

#endif  // MATH_FUNCTIONS_H 结束头文件保护宏
