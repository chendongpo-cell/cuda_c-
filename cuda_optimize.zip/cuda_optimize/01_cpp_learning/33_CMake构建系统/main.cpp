// ============================================================
// 33_CMake构建系统 - 主程序
//
// 本程序演示如何使用 CMake 构建一个包含自定义库的项目。
// 我们创建了一个 Math 静态库（包含 add 和 subtract 函数），
// 然后在这里调用这些库函数。
//
// 构建方式：
//   cd build
//   cmake ..
//   cmake --build .
//   ./33_CMake
// ============================================================

// 包含输入输出流头文件，用于控制台打印
#include <iostream>
// 包含自定义的 Math 库头文件，使用双引号表示本地头文件
#include "math_functions.h"

/**
 * main - 程序入口函数
 * 演示如何调用自己编写的数学库中的函数。
 * 展示 add 和 subtract 两个函数的使用方法。
 *
 * @return: 程序退出码，0 表示成功执行
 */
int main()
{
    // ===== 变量声明部分 =====
    // 定义两个整数变量用于计算演示
    int num1 = 50;     // 第一个操作数，赋值为 50
    int num2 = 20;     // 第二个操作数，赋值为 20

    // ===== 加法演示 =====
    // 调用 Math 库中的 add 函数计算两数之和
    int sum = add(num1, num2);  // sum 将保存 num1 + num2 的结果，即 70

    // 使用 std::cout 打印加法结果到控制台
    // std::endl 用于输出换行符并刷新输出缓冲区
    std::cout << "加法演示：" << std::endl;        // 打印标题行
    std::cout << num1 << " + " << num2 << " = ";   // 打印算式前半部分：50 + 20 =
    std::cout << sum << std::endl;                  // 打印结果：70
    std::cout << std::endl;                         // 打印一个空行用于分隔

    // ===== 减法演示 =====
    // 调用 Math 库中的 subtract 函数计算两数之差
    int diff = subtract(num1, num2);  // diff 将保存 num1 - num2 的结果，即 30

    // 打印减法结果到控制台
    std::cout << "减法演示：" << std::endl;        // 打印标题行
    std::cout << num1 << " - " << num2 << " = ";   // 打印算式前半部分：50 - 20 =
    std::cout << diff << std::endl;                 // 打印结果：30
    std::cout << std::endl;                         // 打印一个空行用于分隔

    // ===== 连续运算演示 =====
    // 演示如何组合使用库中的多个函数
    // 先计算 add(100, 200) = 300，然后计算 subtract(300, 50) = 250
    int result = subtract(add(100, 200), 50);  // 函数嵌套调用：先加后减

    // 打印组合运算的结果
    std::cout << "组合运算演示：" << std::endl;     // 打印标题行
    std::cout << "(100 + 200) - 50 = ";             // 打印算式
    std::cout << result << std::endl;                // 打印结果：250
    std::cout << std::endl;                         // 打印空行

    // ===== 负数结果演示 =====
    // 当被减数小于减数时，结果可能为负数
    int negative_result = subtract(10, 100);  // 10 - 100 = -90

    // 打印负数结果
    std::cout << "负数结果演示：" << std::endl;     // 打印标题行
    std::cout << "10 - 100 = ";                     // 打印算式
    std::cout << negative_result << std::endl;       // 打印结果：-90
    std::cout << std::endl;                         // 打印空行

    // ===== 程序结束 =====
    // 打印一条分隔线表示程序执行完毕
    std::cout << "程序执行完毕！" << std::endl;     // 打印结束提示

    // 返回 0 表示程序成功执行
    // 非零返回值通常表示发生了错误
    return 0;
}
