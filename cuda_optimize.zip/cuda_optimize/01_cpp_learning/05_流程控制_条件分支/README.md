# 05 流程控制——条件分支

## 1. 直观理解

### 程序的"岔路口"

默认情况下，程序从上到下逐行执行。条件分支语句让你能够根据**运行时的条件**选择不同的代码路径——就像路上的岔口：

```
        ┌── 条件为 true? ──→ 执行代码块 A
        │
程序 ──┤
        │
        └── 条件为 false? ──→ 执行代码块 B
```

---

## 2. 语法速查

### if / else if / else

```cpp
if (条件) {
    // 条件为 true 时执行
} else if (另一个条件) {
    // 上一个条件为 false 且本条件为 true 时执行
} else {
    // 以上条件都为 false 时执行
}
```

### switch

```cpp
switch (整型表达式) {
    case 值1:
        // 匹配值1时执行
        break;
    case 值2:
    case 值3:          // 值2 和 值3 走相同的逻辑（fall-through）
        break;
    default:
        // 都不匹配时执行
        break;
}
```

### 三元运算符

```cpp
变量 = (条件) ? 值1 : 值2;     // 条件为 true 取值1，否则取值2
```

### C++ 中的"假值"

以下值在条件判断中被视为 `false`：
- `false`
- `0`（整数零）、`0.0`（浮点零）
- `nullptr`、`NULL`
- `'\0'`（空字符）

**其他一切值都被视为 `true`**（非零即真）。注意：这和 Python 不同（Python 的空列表、空字符串也是 false）。

---

## 3. 底层原理

### `if` 条件的本质——隐式类型转换

`if (x)` 实际上对 `x` 进行了隐式转换，期望得到一个 `bool`：

```cpp
if (42)       { ... }   // int → bool（非零→true）
if (ptr)      { ... }   // 指针 → bool（非空→true）
if (myObj)    { ... }   // 如果 myObj 定义了 operator bool，调用它
```

对于自定义类型，可以实现 `operator bool()` 来让对象能用于条件判断：

```cpp
class FileHandle {
    bool valid;
public:
    operator bool() const { return valid; }
};

FileHandle f = openFile("data.txt");
if (f) { /* 文件打开成功 */ }  // 自动调用 operator bool()
```

### `switch` 的跳转表优化

当 `case` 值密集且连续时，编译器会生成**跳转表（Jump Table）**——一个查找表，直接通过索引跳转到对应代码块：

```asm
; switch(x) 的跳转表示例
; 如果 x 在 [0, N] 范围内，直接 jmp [table + x * 8]
```

这意味着：
- `switch`（跳转表）→ O(1) 跳转，适合**密集的整型匹配**
- `if-else` 链 → 逐个比较，适合**稀疏条件或范围判断**
- 现代编译器很聪明——如果 if-else 链的条件是密集整型，也可能自动优化成跳转表

### `[[likely]]` / `[[unlikely]]` ——C++20 的分支预测提示

```cpp
if (unlikely(error_occurred)) {  // 告诉编译器：这个分支不常走
    handleError();
}

if (likely(ptr != nullptr)) {    // 告诉编译器：这个分支常走
    ptr->process();
}
```

这些属性指导编译器优化代码布局（把 unlikely 的分支指令放远一些，减少指令缓存的浪费）。注意这只是**提示**，编译器不一定遵从。

### `if constexpr` ——C++17 的编译期分支

```cpp
template<typename T>
auto getValue(T t) {
    if constexpr (std::is_pointer_v<T>) {
        return *t;          // T 是指针，解引用
    } else {
        return t;           // T 不是指针，直接返回
    }
}
```

`if constexpr` 的条件在**编译时**求值，不满足条件的分支**完全不会被编译**（不是优化掉，是根本不存在于编译产物中）。这对模板编程极其重要——普通的 `if` 要求两个分支都有合法的类型，`if constexpr` 不要求。

---

## 4. 深入细节

### 为什么 `switch` 表达式必须是整型？

`switch` 的底层是跳转表或二分查找，需要快速的**相等比较**。整型（`int`、`char`、`enum`）的比较是单条 CPU 指令，而浮点数有精度问题、字符串需要遍历比较——这些不适合跳转表。

### Fall-through ——特性而非 bug

`case` 末尾不加 `break` 会继续执行下一个 `case`，这被称为 fall-through：

```cpp
switch (month) {
    case 12:
    case 1:
    case 2:
        cout << "冬季";    // 12、1、2 月都输出"冬季"
        break;
}
```

如果你**故意** fall-through，可以用 C++17 的 `[[fallthrough]]` 属性告诉编译器"这不是 bug"：

```cpp
switch (x) {
    case 1:
        doSomething();
        [[fallthrough]];   // 明确告诉编译器：故意的
    case 2:
        doMore();
        break;
}
```

### `else` 的"悬挂"问题（Dangling Else）

```cpp
if (cond1)
    if (cond2)
        doA();
else                     // 这个 else 属于哪个 if？
    doB();
```

答案：**else 始终属于最近的未配对 if**（即 `if (cond2)`）。但别依赖读者的记忆力——**总是加花括号**：

```cpp
if (cond1) {
    if (cond2) {
        doA();
    }
} else {
    doB();
}
```

### 分支预测对性能的影响

现代 CPU 使用**分支预测（Branch Prediction）**来猜测条件跳转的方向。预测正确 → 流水线继续平滑运行；预测错误 → 流水线清空，浪费 10-20 个时钟周期。

```cpp
// 对分支预测友好的代码——排序后的数组
sort(arr, arr + N);
for (int i = 0; i < N; i++)
    if (arr[i] > threshold)   // arr 排好序了，前半 false 后半 true
        count++;               // 分支预测命中率很高 → 快！

// 分支预测不友好——随机数据
// 条件随机 true/false → 预测命中率 ≈ 50% → 每次预测错都清空流水线
```

这解释了为什么同样的循环，排序后的数据跑得更快。

---

## 5. C++ vs Python 对照

```python
# Python：缩进就是花括号
if x > 0:
    print("正数")
elif x < 0:
    print("负数")
else:
    print("零")

# Python 没有 switch（Python 3.10+ 有 match-case）
# Python 的三元：a if cond else b
max_val = a if a > b else b
```

```cpp
// C++：花括号定义作用域
if (x > 0) {
    cout << "正数";
} else if (x < 0) {
    cout << "负数";
} else {
    cout << "零";
}
```

| 方面 | Python | C++ |
|------|--------|-----|
| 代码块分隔 | 缩进 | 花括号 `{}` |
| falsy 值 | `False/None/0/""/[]/{}/set()` 等 | `false/0/0.0/nullptr` 等（少很多） |
| switch | 3.10+ 的 `match-case` | 原生 `switch` |
| 三元 | `a if c else b` | `c ? a : b` |
| 编译期分支 | 无 | `if constexpr` |
| 分支预测 | 无控制 | `[[likely]]` / `[[unlikely]]` |
| 赋值在条件中 | 语法不允许 | 合法但有风险 `if (x = 5)` |

---

## 6. 练习与思考

### 基础练习

1. 根据分数（0-100）输出等级：90+ A，80+ B，70+ C，60+ D，其余 F
2. 用 `switch` 实现一个简单计算器（根据输入的运算符 `+`/`-`/`*`/`/` 执行对应运算）
3. 用三元运算符求三个数的最大值

### 思考题

4. 在什么情况下，`if-else` 链比 `switch` 更高效？（提示：条件稀疏且不均匀分布）
5. `if (x = 5)` 这个 bug 为什么在 C++ 中允许存在？设计上有什么合理性？
6. 如何用 `switch` 实现范围判断（如 0-10、11-20、21-30 三个区间）？（提示：除法）
7. 分支预测对排序数组 vs 随机数组的性能差异到底有多大？写代码用 `chrono` 测量
