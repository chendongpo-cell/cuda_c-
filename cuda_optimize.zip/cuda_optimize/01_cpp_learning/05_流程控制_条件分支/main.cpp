// ============================================================
// 文件名: main.cpp
// 说明: 流程控制 —— 条件分支
// 演示内容: if-else 成绩评级、switch 菜单系统、三元运算符
// 编译命令: g++ main.cpp -o main -std=c++17
// ============================================================

// 包含输入输出流头文件，提供 cout 和 cin
#include <iostream>
// 包含字符串头文件，提供 string 类型
#include <string>
// 使用标准命名空间，简化代码书写
using namespace std;

// main 函数 —— 程序入口
int main() {
    // ==========================================================
    // 示例 1: if-else 判断成绩等级
    // 功能: 根据用户输入的分数（0-100），输出对应的等级
    // ==========================================================
    cout << "========== 示例 1: 成绩等级判断 (if-else) ==========" << endl;

    // 声明一个整型变量用于存储用户输入的分数
    int score;
    // 提示用户输入分数
    cout << "请输入你的分数（0-100）: ";
    // 从键盘读取用户输入的分数
    cin >> score;

    // 第一步: 先检查输入是否合法（在 0-100 范围内）
    // 如果分数小于 0 或大于 100，说明输入不合法
    if (score < 0 || score > 100) {
        // 条件为 true，说明输入不合法
        cout << "错误：分数必须在 0 到 100 之间！" << endl;
    }
    // else if 链: 从上到下依次判断，遇到第一个为 true 的条件就执行对应的代码块
    // 判断是否为优秀（90 分及以上）
    else if (score >= 90) {
        cout << "等级: A（优秀）" << endl;
    }
    // 判断是否为良好（80-89 分）
    else if (score >= 80) {
        cout << "等级: B（良好）" << endl;
    }
    // 判断是否为中等（70-79 分）
    else if (score >= 70) {
        cout << "等级: C（中等）" << endl;
    }
    // 判断是否为及格（60-69 分）
    else if (score >= 60) {
        cout << "等级: D（及格）" << endl;
    }
    // 以上条件都不满足，说明分数低于 60 分
    else {
        cout << "等级: F（不及格）" << endl;
    }

    // 使用嵌套 if 进一步细分
    // 先判断是否及格，再在及格的基础上细分
    if (score >= 60 && score <= 100) {
        // 外层 if 条件为 true，表示及格
        // 内层 if 进一步判断是否达到 95 分以上
        if (score >= 95) {
            cout << "评语: 非常优秀，继续保持！" << endl;
        }
        // 内层 else if: 是否在 60-94 之间
        else if (score >= 60) {
            cout << "评语: 已通过，继续加油！" << endl;
        }
    } else {
        // 外层 if 的 else: 分数不在 60-100 范围内
        // 可能是低于 60 分，也可能是输入错误
        if (score >= 0 && score < 60) {
            cout << "评语: 需要努力复习！" << endl;
        }
        // 如果是负数或超过 100，前面已经有错误提示了
    }

    // 清理输入缓冲区中的换行符，为后面的 getline 做准备
    cin.ignore(1000, '\n');

    cout << endl;

    // ==========================================================
    // 示例 2: switch 实现菜单系统
    // 功能: 显示一个功能菜单，根据用户选择执行不同操作
    // ==========================================================
    cout << "========== 示例 2: 菜单系统 (switch) ==========" << endl;

    // 显示菜单选项给用户
    cout << "===== 学生管理系统 =====" << endl;
    cout << "1. 查询成绩" << endl;
    cout << "2. 修改密码" << endl;
    cout << "3. 查看个人信息" << endl;
    cout << "4. 退出系统" << endl;
    cout << "========================" << endl;

    // 声明变量用于存储用户的选择
    int choice;
    // 提示用户输入选择
    cout << "请输入你的选择（1-4）: ";
    // 读取用户输入的选择
    cin >> choice;

    // switch 语句: 根据 choice 的值跳转到对应的 case
    // switch 后面的表达式必须是整型（int、char、short、long、enum）
    switch (choice) {
        // case 1: 当 choice == 1 时执行这里
        case 1:
            cout << "正在查询成绩..." << endl;
            // 这里可以放更多查询成绩的代码
            // break 用于跳出 switch 语句，防止"穿透"到下一个 case
            break;

        // case 2: 当 choice == 2 时执行这里
        case 2:
            cout << "正在修改密码..." << endl;
            // 这里可以放修改密码的代码
            break;

        // case 3: 当 choice == 3 时执行这里
        case 3:
            cout << "正在查看个人信息..." << endl;
            // 这里可以放查看个人信息的代码
            break;

        // case 4: 当 choice == 4 时执行这里
        case 4:
            cout << "感谢使用，再见！" << endl;
            break;

        // default: 当没有任何 case 匹配时执行这里
        // default 是可选的，但建议加上以处理意外输入
        default:
            cout << "错误：无效的选择，请输入 1-4 之间的数字！" << endl;
            // default 的 break 不是必须的，但加上是好习惯
            break;
    }

    cout << endl;

    // ==========================================================
    // 示例 3: switch 的 fall-through（穿透）特性
    // 功能: 根据输入的分数等级输出评价
    // ==========================================================
    cout << "========== 示例 3: switch fall-through ==========" << endl;

    // 声明用于存储等级字符的变量
    char grade;
    // 提示用户输入等级
    cout << "请输入你的等级（A/B/C/D/F）: ";
    // 读取用户输入的等级字符
    cin >> grade;

    // 使用 switch 判断等级
    // fall-through 特性: 如果 case 末尾没有 break，会继续执行下一个 case
    switch (grade) {
        // case 'A' 没有 break，所以会"穿透"到 case 'B'
        case 'A':
        case 'B':
            // 输入 A 或 B 都会执行这里的代码
            cout << "表现优秀或良好！" << endl;
            break;  // break 在这里阻止继续穿透到 case 'C'

        case 'C':
            cout << "成绩中等。" << endl;
            break;

        case 'D':
            cout << "刚刚及格。" << endl;
            break;

        case 'F':
            cout << "不及格，需要补考。" << endl;
            break;

        // 处理小写字母输入
        case 'a':
        case 'b':
        case 'c':
        case 'd':
        case 'f':
            cout << "请输入大写字母（A/B/C/D/F）！" << endl;
            break;

        // 处理所有其他输入
        default:
            cout << "无效的等级！" << endl;
            break;
    }

    cout << endl;

    // ==========================================================
    // 示例 4: 三元运算符 ?:
    // 功能: 简化二选一的逻辑判断
    // ==========================================================
    cout << "========== 示例 4: 三元运算符 ==========" << endl;

    // 声明一个变量用于测试
    int number = 7;

    // 使用 if-else 判断奇偶（代码较长）
    if (number % 2 == 0) {
        cout << number << " 是偶数（使用 if-else）" << endl;
    } else {
        cout << number << " 是奇数（使用 if-else）" << endl;
    }

    // 使用三元运算符实现同样的功能（更简洁）
    // 语法: (条件) ? 条件为 true 时的值 : 条件为 false 时的值
    // 这里判断 number % 2 == 0 是否为 true
    // 如果为 true，结果为 "偶数"；如果为 false，结果为 "奇数"
    string parity = (number % 2 == 0) ? "偶数" : "奇数";
    // 输出三元运算符判断的结果
    cout << number << " 是" << parity << "（使用三元运算符）" << endl;

    // 三元运算符的另一个例子: 判断是否成年
    int personAge = 20;
    // 条件: personAge >= 18
    // true → "成年人", false → "未成年人"
    string ageStatus = (personAge >= 18) ? "成年人" : "未成年人";
    cout << personAge << " 岁是" << ageStatus << endl;

    // 使用三元运算符求两个数的最大值
    int a = 45;
    int b = 78;
    // 比较 a 和 b，返回较大的那个
    int maxVal = (a > b) ? a : b;
    cout << a << " 和 " << b << " 中较大的是: " << maxVal << endl;

    // 三元运算符也可以嵌套使用（但不推荐，可读性差）
    int testScore = 75;
    // 嵌套的三元: (score >= 90) ? "优秀" : (score >= 60) ? "及格" : "不及格"
    string level = (testScore >= 90) ? "优秀"
                 : (testScore >= 60) ? "及格"
                 : "不及格";
    cout << "分数 " << testScore << " 的等级是: " << level << endl;

    cout << endl;

    // ==========================================================
    // 示例 5: 综合案例 —— 简易计算器
    // 功能: 输入两个数和运算符，计算结果
    // ==========================================================
    cout << "========== 示例 5: 简易计算器 ==========" << endl;

    // 定义两个双精度浮点数用于存储操作数
    double num1, num2;
    // 定义字符变量用于存储运算符
    char op;

    // 提示用户输入第一个数字
    cout << "请输入第一个数字: ";
    // 读取第一个数字
    cin >> num1;
    // 提示用户输入运算符
    cout << "请输入运算符（+ - * /）: ";
    // 读取运算符
    cin >> op;
    // 提示用户输入第二个数字
    cout << "请输入第二个数字: ";
    // 读取第二个数字
    cin >> num2;

    // 使用 switch 判断用户输入的运算符
    // 根据不同的运算符执行不同的计算
    switch (op) {
        // 加法运算
        case '+':
            cout << num1 << " + " << num2 << " = " << (num1 + num2) << endl;
            break;

        // 减法运算
        case '-':
            cout << num1 << " - " << num2 << " = " << (num1 - num2) << endl;
            break;

        // 乘法运算
        case '*':
            cout << num1 << " * " << num2 << " = " << (num1 * num2) << endl;
            break;

        // 除法运算（需要特殊处理除数为 0 的情况）
        case '/':
            // 使用 if 检查除数是否为 0
            // 除数不能为 0，否则会导致程序崩溃
            if (num2 != 0) {
                // 除数不为 0，安全进行除法运算
                cout << num1 << " / " << num2 << " = " << (num1 / num2) << endl;
            } else {
                // 除数为 0，输出错误提示
                cout << "错误：除数不能为 0！" << endl;
            }
            break;

        // 处理无效的运算符输入
        default:
            cout << "错误：无效的运算符！请使用 +、-、* 或 /" << endl;
            break;
    }

    // 程序结束，返回 0 表示正常结束
    return 0;
}
