// Box.h — 类模板头文件
// 重要：模板的完整实现必须放在头文件中
// 原因：模板不是普通的函数/类，而是一个"蓝图"。编译器在编译期遇到 Box<int> 这样的使用时
//       需要看到完整的模板定义才能生成具体的代码。如果把实现放在.cpp中，编译器在编译.cpp时
//       看不到具体的使用场景（如 Box<int>），而在编译 main.cpp 时又看不到实现，导致链接错误。
//       所以模板的声明和实现必须放在同一个头文件中（或者将实现放在 .tpp 文件中再 #include）。

#ifndef BOX_H  // 头文件保护宏开始，防止头文件被重复包含
#define BOX_H  // 定义 BOX_H 宏，表示该头文件已被包含

#include <iostream>   // 包含输入输出流头文件，用于 std::cout
#include <cstddef>    // 包含 size_t 类型定义

// ========== 类模板 Box ==========

/**
 * 类模板：一个可以存储任意类型值的盒子
 * T 是类型参数，代表盒子存储的数据类型
 * 模板实现必须在头文件中，因为编译期实例化时需要看到完整定义
 */
template <typename T>  // template 关键字声明模板，typename T 声明类型参数
class Box {
private:
    // 私有成员变量，类型为 T，用于存储值
    T value;

public:
    // 构造函数：初始化 value
    // : value(v) 是初始化列表，直接初始化成员变量，效率更高
    Box(const T& v) : value(v) {
        // 构造函数体为空，初始化工作已在初始化列表中完成
    }

    // 设置值：将新值赋给 value
    void setValue(const T& v) {
        // 将传入的参数 v 赋给成员变量 value
        value = v;
    }

    // 获取值：返回 value 的常引用，避免拷贝开销
    const T& getValue() const {
        // const 修饰符表示这个函数不会修改对象的状态
        // 返回 const 引用，调用者不能通过返回值修改 value
        return value;
    }

    // 显示值：将 value 输出到控制台
    void display() const {
        // std::cout 是标准输出流
        // << 是流插入运算符
        // std::endl 输出换行并刷新缓冲区
        std::cout << "Box contains: " << value << std::endl;
    }
};

// ========== 非类型模板参数 FixedArray ==========

/**
 * 类模板：固定大小的数组
 * T 是类型参数，Size 是非类型模板参数（编译期常量，size_t 类型）
 * 非类型模板参数必须是整数类型、枚举类型、指针或引用
 * 完整实现放在头文件中，原因同上：模板必须在编译期可见完整定义
 */
template <typename T, size_t Size>  // T 是类型，Size 是编译期整型常量
class FixedArray {
private:
    // 使用非类型模板参数 Size 来指定数组大小
    // 这是在编译期就确定的大小
    T data[Size];

public:
    // 构造函数：将所有元素初始化为默认值
    // 使用初始化列表将 data 所有元素初始化为 T() 即默认值
    FixedArray() : data{} {
        // 空构造函数体，初始化已在初始化列表中完成
        // 使用 data{} 会将所有元素值初始化为 0 或默认构造
    }

    // 获取数组的大小
    // constexpr 表示返回值是编译期常量
    constexpr size_t size() const {
        // 返回非类型模板参数 Size 的值
        return Size;
    }

    // 重载 [] 运算符，实现类似普通数组的访问方式
    // 返回引用，以便可以通过 [] 修改元素值
    T& operator[](size_t index) {
        // 返回指定索引位置的元素引用
        // 注意：没有进行边界检查，越界访问会导致未定义行为
        return data[index];
    }

    // const 版本的 [] 运算符重载
    // 用于 const 对象，返回 const 引用，不能修改
    const T& operator[](size_t index) const {
        // 返回指定索引位置的元素 const 引用
        return data[index];
    }

    // 显示所有元素
    void display() const {
        // 输出数组内容
        std::cout << "FixedArray (size=" << Size << "): [";
        // 遍历数组中的每个元素
        for (size_t i = 0; i < Size; ++i) {
            // 输出当前元素
            std::cout << data[i];
            // 如果不是最后一个元素，输出逗号和空格
            if (i < Size - 1) {
                std::cout << ", ";
            }
        }
        // 输出结束的方括号和换行
        std::cout << "]" << std::endl;
    }
};

#endif // BOX_H 头文件保护宏结束
