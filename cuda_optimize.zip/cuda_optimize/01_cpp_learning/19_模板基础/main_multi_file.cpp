// main_multi_file.cpp — 多文件模板演示主程序
// 多文件演示：模板的实现必须放在 .h 文件中（或在 .tpp 文件中包含），因为模板在编译期实例化
// 编译器在编译 main_multi_file.cpp 时遇到 Box<int>、myMax(10, 20) 等模板使用，
// 需要立即看到模板的完整定义以生成具体的函数/类代码。
// 如果实现放在单独的 .cpp 文件中，编译器在编译那个 .cpp 时不知道要生成哪些实例，
// 在链接阶段就会报 "undefined reference" 错误。

#include <iostream>   // 包含输入输出流头文件，用于 std::cout
#include <string>     // 包含字符串头文件，用于 std::string

#include "Box.h"           // 包含 Box 类模板和 FixedArray 类模板（完整实现都在该头文件中）
#include "BoxBool.h"       // 包含 Box<bool> 模板特化（完整实现在该头文件中）
#include "my_functions.h"  // 包含函数模板 myMax、mySwap、add（完整实现都在该头文件中）

// ========== 主函数 ==========
// 所有内容与原始 main.cpp 演示一致，只是将模板定义拆分到了多个头文件中

int main() {
    // ===== 函数模板演示 =====

    // 输出函数模板演示的标题
    std::cout << "===== 函数模板演示 =====" << std::endl;

    // 调用 myMax 函数模板（定义在 my_functions.h 中）
    // 编译器自动推导 T 为 int，因为两个实参都是 int 类型
    int maxInt = myMax(10, 20);  // myMax<int> 被实例化，返回 int 类型的最大值
    // 输出 int 类型的最大值
    std::cout << "myMax(10, 20) = " << maxInt << std::endl;

    // 调用 myMax 函数模板（定义在 my_functions.h 中）
    // 编译器自动推导 T 为 double，因为两个实参都是 double 类型
    double maxDouble = myMax(3.14, 2.71);  // myMax<double> 被实例化，返回 double 类型的最大值
    // 输出 double 类型的最大值
    std::cout << "myMax(3.14, 2.71) = " << maxDouble << std::endl;

    // 调用 myMax 函数模板（定义在 my_functions.h 中）
    // 编译器自动推导 T 为 std::string，因为两个实参都是 std::string 类型
    std::string maxStr = myMax(std::string("apple"), std::string("banana"));
    // myMax<std::string> 被实例化，按字符串字典序比较
    // 输出字符串类型的最大值（按字典序比较，"banana" > "apple"）
    std::cout << "myMax(apple, banana) = " << maxStr << std::endl;

    // 显式指定模板参数类型（定义在 my_functions.h 中）
    // 使用尖括号 <double> 明确告诉编译器 T 的类型为 double
    double explicitMax = myMax<double>(100, 3.14);
    // 注意：100 是 int 类型，但会被隐式转换为 double，然后参与比较
    std::cout << "myMax<double>(100, 3.14) = " << explicitMax << std::endl;

    // 输出一个空行，分隔不同的演示部分
    std::cout << std::endl;

    // 调用 mySwap 函数模板（定义在 my_functions.h 中）
    // 交换两个 int 变量的值
    int x = 10, y = 20;  // 定义两个 int 变量并初始化
    // 输出交换前的值
    std::cout << "交换前: x = " << x << ", y = " << y << std::endl;
    // 调用 mySwap 模板函数交换 x 和 y（引用传递，直接修改 x 和 y 的值）
    mySwap(x, y);  // mySwap<int> 被实例化，交换两个 int 变量的值
    // 输出交换后的值
    std::cout << "交换后: x = " << x << ", y = " << y << std::endl;

    // 交换两个 double 变量的值
    double dx = 1.23, dy = 4.56;  // 定义两个 double 变量并初始化
    // 输出交换前的值
    std::cout << "交换前: dx = " << dx << ", dy = " << dy << std::endl;
    // 调用 mySwap 模板函数，T 自动推导为 double
    mySwap(dx, dy);  // mySwap<double> 被实例化，交换两个 double 变量的值
    // 输出交换后的值
    std::cout << "交换后: dx = " << dx << ", dy = " << dy << std::endl;

    // 输出一个空行，分隔不同的演示部分
    std::cout << std::endl;

    // 调用 add 函数模板（定义在 my_functions.h 中），有两个类型参数
    // T1 推导为 int，T2 推导为 double，返回类型由 decltype 推导为 double
    auto sum = add(10, 3.14);  // add<int, double> 被实例化，返回 double 类型的结果
    // 输出不同类型相加的结果
    std::cout << "add(10, 3.14) = " << sum << std::endl;

    // 输出一个空行，分隔不同的演示部分
    std::cout << std::endl;

    // ===== 类模板演示 =====

    // 输出类模板演示的标题
    std::cout << "===== 类模板演示 =====" << std::endl;

    // 创建 Box<int> 对象，T 被替换为 int
    // 类模板必须显式指定类型参数（不能像函数模板那样自动推导）
    Box<int> intBox(42);  // 使用 int 实例化 Box 模板，创建 Box<int> 对象并初始化为 42
    // 调用 display 方法显示内容
    intBox.display();  // 输出 "Box contains: 42"
    // 调用 setValue 修改值
    intBox.setValue(100);  // 将 Box<int> 内部的值修改为 100
    // 调用 getValue 获取值并输出
    std::cout << "修改后 getValue() = " << intBox.getValue() << std::endl;

    // 创建 Box<std::string> 对象，T 被替换为 std::string
    Box<std::string> strBox("Hello, Templates!");  // 使用 std::string 实例化 Box 模板
    // 调用 display 方法显示内容
    strBox.display();  // 输出 "Box contains: Hello, Templates!"

    // 输出一个空行，分隔不同的演示部分
    std::cout << std::endl;

    // ===== 模板特化演示 =====

    // 输出模板特化演示的标题
    std::cout << "===== 模板特化演示 =====" << std::endl;

    // 创建普通的 Box<double> 对象（使用 Box.h 中的泛模板）
    Box<double> dblBox(3.14159);  // double 没有特化，使用通用的 Box<T> 模板
    // 调用 display 显示内容
    dblBox.display();  // 输出 "Box contains: 3.14159"

    // 创建 Box<bool> 特化版本对象（使用 BoxBool.h 中的特化模板）
    // 编译器会使用 BoxBool.h 中特化的 Box<bool> 版本，而非 Box.h 中的通用版本
    Box<bool> boolBox(true);  // bool 有全特化，使用 Box<bool> 特化版本
    // 调用特化版本的 display
    boolBox.display();  // 输出 "Box contains: true"
    // 修改值并获取
    boolBox.setValue(false);  // 调用特化版本的 setValue，内部用 unsigned char 存储
    // 输出修改后的值
    std::cout << "修改后 getValue() = " << (boolBox.getValue() ? "true" : "false") << std::endl;

    // 输出一个空行，分隔不同的演示部分
    std::cout << std::endl;

    // ===== 非类型模板参数演示 =====

    // 输出非类型模板参数演示的标题
    std::cout << "===== 非类型模板参数演示 =====" << std::endl;

    // 创建长度为 5 的 int 类型 FixedArray（定义在 Box.h 中）
    // Size 非类型模板参数在编译期被确定为 5
    FixedArray<int, 5> intArray;  // 实例化 FixedArray<int, 5>，包含 5 个 int 元素

    // 使用重载的 [] 运算符给数组元素赋值
    for (size_t i = 0; i < intArray.size(); ++i) {  // 遍历数组的每个元素
        // 给第 i 个元素赋值 i * 10
        intArray[i] = static_cast<int>(i * 10);  // static_cast 将 size_t 转换为 int
    }

    // 显示数组内容
    intArray.display();  // 输出 "FixedArray (size=5): [0, 10, 20, 30, 40]"

    // 创建长度为 3 的 double 类型 FixedArray
    FixedArray<double, 3> dblArray;  // 实例化 FixedArray<double, 3>，包含 3 个 double 元素
    // 通过 [] 运算符赋值
    dblArray[0] = 1.1;  // 给第 0 个元素赋值 1.1
    dblArray[1] = 2.2;  // 给第 1 个元素赋值 2.2
    dblArray[2] = 3.3;  // 给第 2 个元素赋值 3.3
    // 显示数组内容
    dblArray.display();  // 输出 "FixedArray (size=3): [1.1, 2.2, 3.3]"

    // 获取数组大小（非 constexpr 版本，通过运行时调用）
    // 注意：在 C++11 中，constexpr 非静态成员函数限制较多，这里使用普通调用
    size_t arrSize = intArray.size();  // 运行时调用 size() 获取数组大小
    // 输出数组大小
    std::cout << "intArray 的大小: " << arrSize << std::endl;  // 输出 5

    // 输出一个空行，分隔不同的演示部分
    std::cout << std::endl;

    // ===== 总结输出 =====

    // 输出程序结束的标题
    std::cout << "===== 模板基础演示结束 =====" << std::endl;

    // 如果编译链接成功，说明多文件模板项目结构正确
    // Box.h、BoxBool.h、my_functions.h 中的模板定义在编译期被成功实例化
    std::cout << "多文件模板项目结构运行成功！" << std::endl;
    std::cout << "模板定义分别在 Box.h、BoxBool.h、my_functions.h 中" << std::endl;
    std::cout << "所有模板实现都在头文件中，编译期实例化无链接错误" << std::endl;

    // main 函数返回 0 表示程序正常结束
    return 0;
}
