// BoxBool.h — 模板特化头文件
// 该头文件包含 Box<bool> 的全特化版本
// 模板特化也必须放在头文件中，因为特化也是在编译期选择的，编译器需要看到特化定义

#ifndef BOXBOOL_H  // 头文件保护宏开始，防止头文件被重复包含
#define BOXBOOL_H  // 定义 BOXBOOL_H 宏，表示该头文件已被包含

#include "Box.h"   // 包含基模板 Box 的定义，特化需要基于基模板

// ========== 模板全特化 Box<bool> ==========

/**
 * 类模板全特化：为 bool 类型提供专门的实现
 * template <> 表示这是一个特化版本，没有类型参数
 * 针对 Box<bool>，我们使用更节省空间的方式存储
 * 注意：template <> 中的尖括号是空的，表示这是一个全特化（没有剩余的类型参数）
 */
template <>          // 空模板参数列表，表示全特化
class Box<bool> {    // 特化 Box<bool>，为 bool 类型定制实现
private:
    // 对于 bool 类型，我们用一个 unsigned char 来存储
    // 使用 unsigned char（1字节）而不是直接使用 bool
    // 这样更清楚地展示了特化可以改变内部实现细节
    unsigned char data;

public:
    // 特化版本的构造函数
    // 注意：特化的构造函数不需要 template 前缀
    Box(const bool& v) {
        // 将 bool 值存储到 data 中
        // 如果 v 为 true，data 赋值为 1，否则赋值为 0
        data = v ? 1 : 0;
    }

    // 特化版本的设置值函数
    void setValue(const bool& v) {
        // 将 bool 值转换为 0 或 1 存储
        data = v ? 1 : 0;
    }

    // 特化版本的获取值函数
    const bool getValue() const {
        // 将存储的值转换回 bool 类型返回
        // data != 0 这个表达式的结果就是 bool 类型
        return data != 0;
    }

    // 特化版本的显示函数
    void display() const {
        // 使用三元运算符将 bool 值转换为 "true" 或 "false" 字符串
        // data != 0 为真时输出 "true"，否则输出 "false"
        std::cout << "Box contains: " << (data != 0 ? "true" : "false") << std::endl;
    }
};

#endif // BOXBOOL_H 头文件保护宏结束
