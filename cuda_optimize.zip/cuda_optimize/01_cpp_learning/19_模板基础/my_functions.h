// my_functions.h — 函数模板头文件
// 重要：函数模板的完整实现必须放在头文件中
// 原因与类模板相同：函数模板在编译期实例化，编译器需要在每个使用函数模板的翻译单元中
// 看到完整的模板定义。如果把实现放在 .cpp 文件中，会导致链接错误（undefined reference）。
// 所以函数模板的声明和实现必须都放在头文件中。

#ifndef MY_FUNCTIONS_H  // 头文件保护宏开始，防止头文件被重复包含
#define MY_FUNCTIONS_H  // 定义 MY_FUNCTIONS_H 宏，表示该头文件已被包含

#include <string>  // 包含字符串头文件，虽然本头文件不直接使用，但调用方可能会用到

// ========== 函数模板 ==========

/**
 * 函数模板：返回两个值中的较大者
 * template 关键字声明这是一个模板
 * typename T 声明了一个类型参数 T，T 可以是任意类型
 * 编译器会根据调用时传入的实际类型自动生成对应的函数代码
 * 函数模板的实现必须在头文件中，因为编译期实例化时需要看到完整定义
 */
template <typename T>  // template 关键字声明模板，T 是类型参数
T myMax(T a, T b) {    // 函数模板：比较两个值并返回较大的一个
    // 如果 a 大于 b，返回 a，否则返回 b
    // 注意：T 类型必须支持 operator> 比较操作
    return a > b ? a : b;  // 三元运算符，a > b 为真时返回 a，否则返回 b
}

/**
 * 函数模板：交换两个变量的值
 * 通过引用传递参数，这样函数内部可以修改外部变量的值
 * T 是类型参数，可以匹配任意类型
 * 实现放在头文件中，原因同上
 */
template <typename T>  // template 关键字声明模板，T 是类型参数
void mySwap(T& a, T& b) {  // 通过引用传递，直接修改外部变量
    // 创建一个临时变量 temp，类型为 T，初始化为 a 的值
    T temp = a;    // 将 a 的值拷贝到临时变量中
    // 将 b 的值赋给 a
    a = b;         // a 现在持有 b 原来的值
    // 将 temp（原来 a 的值）赋给 b
    b = temp;      // b 现在持有 a 原来的值
    // 至此 a 和 b 的值完成了交换
}

/**
 * 函数模板：两个不同类型值相加
 * T1 和 T2 是两个不同的类型参数
 * 使用 C++11 的尾置返回类型语法，decltype 自动推导返回类型
 * 实现放在头文件中，原因同上
 */
template <typename T1, typename T2>  // 两个类型参数 T1 和 T2
auto add(T1 a, T2 b) -> decltype(a + b) {  // 尾置返回类型，auto 占位 + decltype 推导
    // C++11 的尾置返回类型语法，decltype 自动推导表达式 a + b 的结果类型
    // 例如：int + double = double
    // 再例如：int + int = int
    return a + b;  // 返回 a 和 b 的和，类型由 decltype 自动推导
}

#endif // MY_FUNCTIONS_H 头文件保护宏结束
