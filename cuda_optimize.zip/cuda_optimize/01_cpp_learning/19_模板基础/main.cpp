#include <iostream>   // 包含输入输出流头文件，用于 std::cout
#include <string>     // 包含字符串头文件，用于 std::string

// ========== 函数模板 ==========

/**
 * 函数模板：返回两个值中的较大者
 * template 关键字声明这是一个模板
 * typename T 声明了一个类型参数 T，T 可以是任意类型
 * 编译器会根据调用时传入的实际类型自动生成对应的函数代码
 */
template <typename T>
T myMax(T a, T b) {
    // 如果 a 大于 b，返回 a，否则返回 b
    // 注意：T 类型必须支持 operator> 比较操作
    return a > b ? a : b;
}

/**
 * 函数模板：交换两个变量的值
 * 通过引用传递参数，这样函数内部可以修改外部变量的值
 * T 是类型参数，可以匹配任意类型
 */
template <typename T>
void mySwap(T& a, T& b) {
    // 创建一个临时变量 temp，类型为 T，初始化为 a 的值
    T temp = a;
    // 将 b 的值赋给 a
    a = b;
    // 将 temp（原来 a 的值）赋给 b
    b = temp;
    // 至此 a 和 b 的值完成了交换
}

// 函数模板也可以有多个类型参数
// 这个函数接受两种可能不同类型的参数，返回 decltype 推导的公共类型
template <typename T1, typename T2>
auto add(T1 a, T2 b) -> decltype(a + b) {
    // C++11 的尾置返回类型语法，decltype 自动推导表达式 a + b 的结果类型
    // 例如：int + double = double
    return a + b;
}

// ========== 类模板 ==========

/**
 * 类模板：一个可以存储任意类型值的盒子
 * T 是类型参数，代表盒子存储的数据类型
 */
template <typename T>
class Box {
private:
    // 私有成员变量，类型为 T，用于存储值
    T value;

public:
    // 构造函数：初始化 value
    // : value(v) 是初始化列表，直接初始化成员变量
    Box(const T& v) : value(v) {
        // 构造函数体为空，初始化工作已在初始化列表中完成
    }

    // 设置值：将新值赋给 value
    void setValue(const T& v) {
        // 将传入的参数 v 赋给成员变量 value
        value = v;
    }

    // 获取值：返回 value 的常引用，避免拷贝开销
    const T& getValue() const {
        // const 修饰符表示这个函数不会修改对象的状态
        // 返回 const 引用，调用者不能通过返回值修改 value
        return value;
    }

    // 显示值：将 value 输出到控制台
    void display() const {
        // std::cout 是标准输出流
        // << 是流插入运算符
        // std::endl 输出换行并刷新缓冲区
        std::cout << "Box contains: " << value << std::endl;
    }
};

// ========== 模板全特化 ==========

/**
 * 类模板全特化：为 bool 类型提供专门的实现
 * template <> 表示这是一个特化版本，没有类型参数
 * 针对 Box<bool>，我们使用更节省空间的方式存储
 */
template <>
class Box<bool> {
private:
    // 对于 bool 类型，我们用一个 unsigned char 来存储 8 个 bool 值
    // 这里简化演示，只存储一个 bool 值
    // 使用 unsigned char（1字节）而不是直接使用 bool
    unsigned char data;

public:
    // 特化版本的构造函数
    Box(const bool& v) {
        // 将 bool 值存储到 data 中
        // 如果 v 为 true，data 赋值为 1，否则赋值为 0
        data = v ? 1 : 0;
    }

    // 特化版本的设置值函数
    void setValue(const bool& v) {
        // 将 bool 值转换为 0 或 1 存储
        data = v ? 1 : 0;
    }

    // 特化版本的获取值函数
    const bool getValue() const {
        // 将存储的值转换回 bool 类型返回
        // data != 0 这个表达式的结果就是 bool 类型
        return data != 0;
    }

    // 特化版本的显示函数
    void display() const {
        // 使用三元运算符将 bool 值转换为 "true" 或 "false" 字符串
        // data != 0 为真时输出 "true"，否则输出 "false"
        std::cout << "Box contains: " << (data != 0 ? "true" : "false") << std::endl;
    }
};

// ========== 非类型模板参数 ==========

/**
 * 类模板：固定大小的数组
 * Size 是非类型模板参数，它是一个编译期常量值（size_t 类型）
 * 非类型模板参数必须是整数类型、枚举类型、指针或引用
 */
template <typename T, size_t Size>
class FixedArray {
private:
    // 使用非类型模板参数 Size 来指定数组大小
    // 这是在编译期就确定的大小
    T data[Size];

public:
    // 构造函数：将所有元素初始化为默认值
    // 使用初始化列表将 data 所有元素初始化为 T() 即默认值
    FixedArray() : data{} {
        // 空构造函数体，初始化已在初始化列表中完成
        // 使用 data{} 会将所有元素值初始化为 0 或默认构造
    }

    // 获取数组的大小
    // constexpr 表示返回值是编译期常量
    constexpr size_t size() const {
        // 返回非类型模板参数 Size 的值
        return Size;
    }

    // 重载 [] 运算符，实现类似普通数组的访问方式
    // 返回引用，以便可以通过 [] 修改元素值
    T& operator[](size_t index) {
        // 返回指定索引位置的元素引用
        // 注意：没有进行边界检查，越界访问会导致未定义行为
        return data[index];
    }

    // const 版本的 [] 运算符重载
    // 用于 const 对象，返回 const 引用，不能修改
    const T& operator[](size_t index) const {
        // 返回指定索引位置的元素 const 引用
        return data[index];
    }

    // 显示所有元素
    void display() const {
        // 输出数组内容
        std::cout << "FixedArray (size=" << Size << "): [";
        // 遍历数组中的每个元素
        for (size_t i = 0; i < Size; ++i) {
            // 输出当前元素
            std::cout << data[i];
            // 如果不是最后一个元素，输出逗号和空格
            if (i < Size - 1) {
                std::cout << ", ";
            }
        }
        // 输出结束的方括号和换行
        std::cout << "]" << std::endl;
    }
};

// ========== 主函数 ==========

int main() {
    // ===== 函数模板演示 =====

    // 输出标题
    std::cout << "===== 函数模板演示 =====" << std::endl;

    // 调用 myMax 函数模板
    // 编译器自动推导 T 为 int
    int maxInt = myMax(10, 20);
    // 输出 int 类型的最大值
    std::cout << "myMax(10, 20) = " << maxInt << std::endl;

    // 调用 myMax 函数模板
    // 编译器自动推导 T 为 double
    double maxDouble = myMax(3.14, 2.71);
    // 输出 double 类型的最大值
    std::cout << "myMax(3.14, 2.71) = " << maxDouble << std::endl;

    // 调用 myMax 函数模板
    // 编译器自动推导 T 为 std::string
    std::string maxStr = myMax(std::string("apple"), std::string("banana"));
    // 输出字符串类型的最大值（按字典序比较）
    std::cout << "myMax(apple, banana) = " << maxStr << std::endl;

    // 显式指定模板参数类型
    // 使用尖括号 <double> 明确告诉编译器 T 的类型为 double
    double explicitMax = myMax<double>(100, 3.14);
    // 注意：100 是 int 类型，但会被隐式转换为 double
    std::cout << "myMax<double>(100, 3.14) = " << explicitMax << std::endl;

    std::cout << std::endl;

    // 调用 mySwap 函数模板
    // 交换两个 int 变量的值
    int x = 10, y = 20;
    // 输出交换前的值
    std::cout << "交换前: x = " << x << ", y = " << y << std::endl;
    // 调用 mySwap 模板函数交换 x 和 y
    mySwap(x, y);
    // 输出交换后的值
    std::cout << "交换后: x = " << x << ", y = " << y << std::endl;

    // 交换两个 double 变量的值
    double dx = 1.23, dy = 4.56;
    // 输出交换前的值
    std::cout << "交换前: dx = " << dx << ", dy = " << dy << std::endl;
    // 调用 mySwap 模板函数，T 自动推导为 double
    mySwap(dx, dy);
    // 输出交换后的值
    std::cout << "交换后: dx = " << dx << ", dy = " << dy << std::endl;

    std::cout << std::endl;

    // 调用 add 函数模板，有两个类型参数
    // T1 推导为 int, T2 推导为 double, 返回类型为 double
    auto sum = add(10, 3.14);
    // 输出不同类型相加的结果
    std::cout << "add(10, 3.14) = " << sum << std::endl;

    std::cout << std::endl;

    // ===== 类模板演示 =====

    // 输出标题
    std::cout << "===== 类模板演示 =====" << std::endl;

    // 创建 Box<int> 对象，T 被替换为 int
    // 类模板必须显式指定类型参数（不能推导）
    Box<int> intBox(42);
    // 调用 display 方法显示内容
    intBox.display();
    // 调用 setValue 修改值
    intBox.setValue(100);
    // 调用 getValue 获取值并输出
    std::cout << "修改后 getValue() = " << intBox.getValue() << std::endl;

    // 创建 Box<std::string> 对象，T 被替换为 std::string
    Box<std::string> strBox("Hello, Templates!");
    // 调用 display 方法显示内容
    strBox.display();

    std::cout << std::endl;

    // ===== 模板特化演示 =====

    // 输出标题
    std::cout << "===== 模板特化演示 =====" << std::endl;

    // 创建普通的 Box<double> 对象
    Box<double> dblBox(3.14159);
    // 调用 display 显示内容
    dblBox.display();

    // 创建 Box<bool> 特化版本对象
    // 编译器会使用上面特化的 Box<bool> 版本，而非通用版本
    Box<bool> boolBox(true);
    // 调用特化版本的 display
    boolBox.display();
    // 修改值并获取
    boolBox.setValue(false);
    // 输出修改后的值
    std::cout << "修改后 getValue() = " << (boolBox.getValue() ? "true" : "false") << std::endl;

    std::cout << std::endl;

    // ===== 非类型模板参数演示 =====

    // 输出标题
    std::cout << "===== 非类型模板参数演示 =====" << std::endl;

    // 创建长度为 5 的 int 类型 FixedArray
    // Size 非类型模板参数在编译期被确定为 5
    FixedArray<int, 5> intArray;

    // 使用重载的 [] 运算符给数组元素赋值
    for (size_t i = 0; i < intArray.size(); ++i) {
        // 给第 i 个元素赋值 i * 10
        intArray[i] = static_cast<int>(i * 10);
    }

    // 显示数组内容
    intArray.display();

    // 创建长度为 3 的 double 类型 FixedArray
    FixedArray<double, 3> dblArray;
    // 通过 [] 运算符赋值
    dblArray[0] = 1.1;
    dblArray[1] = 2.2;
    dblArray[2] = 3.3;
    // 显示数组内容
    dblArray.display();

    // 获取数组大小（运行时调用）
    size_t arrSize = intArray.size();
    // 输出数组大小
    std::cout << "intArray 的大小: " << arrSize << std::endl;

    std::cout << std::endl;

    // ===== 总结输出 =====

    std::cout << "===== 模板基础演示结束 =====" << std::endl;

    // main 函数返回 0 表示程序正常结束
    return 0;
}
