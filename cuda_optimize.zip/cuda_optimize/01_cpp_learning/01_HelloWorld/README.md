# 01 Hello World — 第一个 C++ 程序

## 1. 直观理解

### C++ 程序是什么？

C++ 是一种**编译型**语言。这意味着你写的文本代码（`.cpp`）必须经过**编译器**翻译成 CPU 能直接执行的机器码（`.exe` / 可执行文件），才能运行。

这和 Python 完全不同——Python 是**解释型**语言，由解释器逐行读取并执行你的代码，不需要提前编译。

```
Python 方式:
  python main.py  →  Python 解释器直接读取执行

C++ 方式:
  main.cpp  →  编译(g++)  →  main.exe  →  运行 main.exe
```

### 最简单的程序长什么样？

```cpp
#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
```

每个部分都是必须的吗？我们逐一拆解。

---

## 2. 语法速查

### 程序骨架

```cpp
#include <iostream>           // 包含标准输入输出头文件

int main() {                  // 主函数——程序入口
    // 你的代码写在这里
    return 0;                  // 返回 0 告诉操作系统"程序正常结束"
}
```

### 输出文本

```cpp
std::cout << "文本";                       // 输出字符串
std::cout << "你好" << "世界";             // 连续输出多个内容
std::cout << 42;                            // 输出数字
std::cout << std::endl;                     // 换行并刷新缓冲区
std::cout << "\n";                          // 只换行，不刷新缓冲区（更快）
```

### 转义字符

| 转义序列 | 含义 |
|----------|------|
| `\n` | 换行（newline） |
| `\t` | 水平制表符（Tab） |
| `\\` | 反斜杠本身 |
| `\"` | 双引号 |
| `\'` | 单引号 |

### 编译和运行

```bash
g++ main.cpp -o main -std=c++17    # 编译
./main                              # Linux/macOS 运行
main.exe                            # Windows 运行
```

| 编译器 | 命令 | 平台 |
|--------|------|------|
| GCC | `g++` | Windows (MinGW), Linux |
| Clang | `clang++` | macOS, Linux |
| MSVC | `cl.exe` | Windows (Visual Studio) |

---

## 3. 底层原理

### `cout` 不是关键字——它是一个全局对象

新手常以为 `cout` 是 C++ 的"输出关键字"（类似 Python 的 `print`）。**不是的**。

`cout` 是 `std::ostream` 类的**全局对象**，在程序启动时由 C++ 运行时库自动创建。`std::ostream` 是输出流类，管理着向输出设备（控制台）写入数据的缓冲区和状态。

```cpp
// cout 的本质（简化版）：
namespace std {
    ostream cout;  // 全局 ostream 对象，程序启动时构造
}
```

所以 `std::cout` 的含义是：**命名空间 `std` 中的对象 `cout`**。`std::` 不是可有可无的前缀，它表示这个对象属于标准库命名空间。

### `<<` 不是语法——它是重载的运算符

`<<` 本来是**左移运算符**（位运算），但 `std::ostream` 类对它进行了**运算符重载**，让它变成了"流插入运算符"。

关键细节——`operator<<` 的返回值是 `ostream&`（自身的引用）：

```cpp
// 简化版实现（理解本质用）：
class ostream {
public:
    ostream& operator<<(const char* str) {
        // 把 str 写入缓冲区...
        return *this;  // 返回自己的引用！
    }

    ostream& operator<<(int val) {
        // 把 val 格式化成字符串写入缓冲区...
        return *this;
    }
};
```

因为每次都返回 `*this`（自己的引用），所以可以**链式调用**：

```cpp
cout << "A" << "B" << "C";

// 实际执行过程：
// ((cout << "A") << "B") << "C"
//   ↓
// (cout << "B")     ← 第一次 << 返回 cout 的引用
//   ↓
// cout << "C"       ← 第二次 << 返回 cout 的引用
```

每次 `<<` 操作都返回 `cout` 自身的引用，下一个 `<<` 就能继续往同一个流对象写数据。

### `endl` = `\n` + `flush()`

```cpp
std::cout << std::endl;

// 等价于：
std::cout << '\n';
std::cout.flush();  // 强制把缓冲区内容立即写入控制台
```

- `\n`：只写一个换行符到缓冲区，不保证立即显示
- `endl`：写换行符 + **刷新缓冲区**（调用系统调用，把数据真正写出去）

刷新缓冲区是有系统调用开销的。循环中大量使用 `endl` 会让程序明显变慢：

```cpp
// 慢：每次循环都刷新
for (int i = 0; i < 1000000; i++)
    cout << i << endl;

// 快：只在最后刷新
for (int i = 0; i < 1000000; i++)
    cout << i << '\n';
cout << flush;
```

### `using namespace std;` ——方便但危险

```cpp
using namespace std;  // 把 std 命名空间里的所有名字"拉"到全局
```

这让你可以直接写 `cout` 而不是 `std::cout`，很方便。但问题在于：**你不知道 std 里到底有多少名字**。随着代码量增长，很容易和你自己的变量/函数名冲突。

```cpp
using namespace std;

int count = 0;   // 如果头文件某个版本加了 std::count → 冲突！
int max = 100;   // std::max 是函数模板 → 冲突！
```

**建议**：学习阶段用 `using namespace std;` 减少打字，写正式项目时用 `std::` 前缀或按需导入：

```cpp
using std::cout;
using std::endl;
using std::cin;
// 只导入需要的几个名字，不污染全局命名空间
```

### 编译的 4 个阶段（以 Hello World 为例）

```
main.cpp
  │
  ▼ ① 预处理（Preprocess）
  │   #include <iostream> → 把 iostream 的完整内容（几千行）粘贴进来
  │   输出：main.i（预处理后的纯 C++ 代码）
  │
  ▼ ② 编译（Compile）
  │   语法分析、类型检查，生成汇编代码
  │   输出：main.s（汇编代码）
  │
  ▼ ③ 汇编（Assemble）
  │   把汇编翻译成机器码
  │   输出：main.o（目标文件，二进制）
  │
  ▼ ④ 链接（Link）
  │   把 main.o + libstdc++.a（标准库）合并成一个可执行文件
  │   输出：main.exe（可执行文件）
```

> 详见 [编译链接模型](../docs/00_编译链接模型.md)

---

## 4. 深入细节

### `main()` 函数的完整签名

标准 C++ 的 `main()` 有两种合法形式：

```cpp
int main() { ... }                       // 不接受参数
int main(int argc, char* argv[]) { ... } // 接受命令行参数
```

- `argc`：命令行参数的数量（包括程序名本身，至少为 1）
- `argv`：参数内容，`argv[0]` 是程序名，`argv[1]` 是第一个参数...

```cpp
#include <iostream>
int main(int argc, char* argv[]) {
    std::cout << "程序名: " << argv[0] << std::endl;
    std::cout << "参数个数: " << argc << std::endl;
    for (int i = 1; i < argc; i++)
        std::cout << "参数" << i << ": " << argv[i] << std::endl;
    return 0;
}

// 执行: ./program hello world
// 输出:
//   程序名: ./program
//   参数个数: 3
//   参数1: hello
//   参数2: world
```

### 什么是头文件？iostrem 里有什么？

`<iostream>` 是 C++ 标准库头文件。它里面**声明**了 `std::cout`、`std::cin`、`std::cerr`、`std::clog` 等流对象，以及 `std::endl`、`std::flush` 等操纵符。

头文件本质上是**声明**的集合，对应的**实现**在预编译好的标准库（`libstdc++.a` / `libstdc++.so`）中——链接阶段自动连接。

### `#include <iostream>` vs `#include "myheader.h"`

| 写法 | 查找顺序 |
|------|---------|
| `#include <file>` | 先在系统头文件目录查找，再在 `-I` 指定的目录查找 |
| `#include "file"` | 先在当前文件所在目录查找，再按 `<>` 的方式查找 |

> 系统头文件用 `<>`，自己的头文件用 `""`。

---

## 5. C++ vs Python 对照

```python
# Python
print("Hello, World!")
# 解释器直接执行，不需要编译
# print 是内置函数
# 不需要 main()、不需要 return 0
```

```cpp
// C++
#include <iostream>
int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
// 需要编译后运行
// cout 不是关键字，是库提供的全局对象
// << 是重载的运算符
// main() 必须存在，return 0 表示正常结束
```

关键差异：

| 方面 | Python | C++ |
|------|--------|-----|
| 执行方式 | 解释执行（即时） | 编译后执行 |
| 输出 | `print()` 内置函数 | `cout` 流对象 + `<<` 运算符 |
| 程序入口 | 脚本文件任意位置 | 必须是 `main()` 函数 |
| 错误检测 | 运行时 | 编译时 + 运行时 |
| 文件对应 | `.py` 一个文件 | `.cpp` + `.h`，编译后生成 `.exe` |

---

## 6. 练习与思考

### 基础练习

1. 修改 Hello World 程序，输出你的名字和年龄，年龄用数字输出
2. 使用 `\t` 排版输出以下表格：
   ```
   商品     单价    数量
   苹果     5.5     3
   香蕉     3.0     5
   ```
3. 分别用 `endl` 和 `\n` 输出 100 行文字，感受速度差异（用 `time` 命令测量）

### 思考题

4. 如果把 `#include <iostream>` 删掉会发生什么？试试看什么编译错误
5. 如果把 `return 0;` 删掉会发生什么？（提示：`main()` 是唯一允许省略 return 的函数，C++ 标准规定编译器会自动插入 `return 0;`）
6. 为什么 `std::cout << "A" << "B" << "C";` 能连续输出？画图解释链式调用过程
7. 如果 `using namespace std;` 写在 `main()` 函数**里面**，和写在外面有什么区别？（提示：作用域不同）
