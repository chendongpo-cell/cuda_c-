// 13_封装与友元 / main.cpp
// 本程序演示 C++ 中封装与友元的概念和用法

// 包含输入输出流头文件
#include <iostream>
// 包含字符串头文件
#include <string>
// 使用标准命名空间
using namespace std;

// 前向声明类，友元声明需要提前知道类的存在
class BankAccount;

// 定义一个全局友元函数，它可以访问 BankAccount 的私有成员
// 这个函数用于演示友元函数的使用
void showBalance(const BankAccount& account);

// 定义一个 BankAccount 类，演示封装特性
class BankAccount {
// 私有成员：只能在类内部访问
// 这是封装的体现 -- 隐藏内部实现细节
private:
    // 私有成员变量：账户持有人姓名
    string ownerName;
    // 私有成员变量：账户余额
    double balance;
    // 私有成员变量：账户号码（内部使用）
    string accountNumber;

    // 私有成员函数：生成账户号码
    // 外部无法调用，仅在类内部使用
    string generateAccountNumber() {
        // 简单模拟生成一个随机账户号码
        return "AC" + to_string(rand() % 100000);
    }

// 受保护成员：类内部和子类可以访问，外部不可以
protected:
    // 受保护的成员变量：账户类型
    string accountType;

// 公有成员：任何地方都可以访问
public:
    // ---- 友元声明 ----

    // 声明全局函数为友元，使其可以访问本类的私有成员
    friend void showBalance(const BankAccount& account);

    // 声明另一个类为友元类，使 Manager 类的所有成员函数都可以访问本类的私有成员
    friend class Manager;

    // ---- 构造函数 ----

    // 带参构造函数，初始化账户
    BankAccount(string name, double initialBalance, string type) {
        // 初始化私有成员变量
        ownerName = name;
        balance = initialBalance;
        accountType = type;
        // 调用私有函数生成账户号码
        accountNumber = generateAccountNumber();
        cout << "创建账户成功！" << endl;
    }

    // ---- 公有接口（封装的核心） ----

    // Getter 函数：获取账户持有人姓名
    // 通过公有函数暴露私有数据，这是封装的标准做法
    string getOwnerName() {
        return ownerName;
    }

    // Getter 函数：获取当前余额（只读，不能直接修改）
    double getBalance() {
        return balance;
    }

    // Setter 函数：存款（通过受控的方式修改余额）
    // 函数内部可以添加验证逻辑，保证数据的安全性
    bool deposit(double amount) {
        // 验证存款金额必须大于 0
        if (amount <= 0) {
            cout << "存款金额必须大于 0！" << endl;
            return false;
        }
        // 更新余额
        balance += amount;
        cout << "存款成功！当前余额：" << balance << endl;
        return true;
    }

    // Setter 函数：取款（同样包含验证逻辑）
    bool withdraw(double amount) {
        // 验证取款金额必须大于 0
        if (amount <= 0) {
            cout << "取款金额必须大于 0！" << endl;
            return false;
        }
        // 验证余额是否充足
        if (amount > balance) {
            cout << "余额不足！当前余额：" << balance << endl;
            return false;
        }
        // 更新余额
        balance -= amount;
        cout << "取款成功！当前余额：" << balance << endl;
        return true;
    }

    // 显示账户信息（公开的接口）
    void displayInfo() {
        // 只显示部分信息，隐藏敏感的账户号码
        cout << "账户持有人：" << ownerName << endl;
        cout << "账户类型：" << accountType << endl;
        cout << "当前余额：" << balance << " 元" << endl;
        // 注意：accountNumber 没有对外暴露
    }
};

// 全局友元函数的实现
// 该函数被声明为 BankAccount 的友元，因此可以访问其私有成员
void showBalance(const BankAccount& account) {
    // 作为友元函数，可以直接访问 account 的私有成员 balance
    // 普通函数是不能访问 account.balance 的
    cout << "（友元函数访问私有成员）" << account.ownerName;
    cout << " 的账户余额为：" << account.balance << " 元" << endl;

    // 还可以访问 accountNumber 这个私有成员
    cout << "（友元函数访问私有成员）账户号码为：" << account.accountNumber << endl;
}

// 定义一个 Manager 类，作为 BankAccount 的友元类
class Manager {
public:
    // 管理员可以查看账户的详细信息（包括私有成员）
    void viewAccountDetails(const BankAccount& account) {
        // 作为友元类，Manager 的所有成员函数都可以访问 BankAccount 的私有成员
        cout << "===== 管理员查看账户详情 =====" << endl;
        cout << "持有人：" << account.ownerName << endl;
        cout << "余额：" << account.balance << " 元" << endl;
        cout << "账户号码：" << account.accountNumber << endl;
        cout << "账户类型：" << account.accountType << endl;
        cout << "================================" << endl;
    }

    // 管理员可以强制修改余额（特殊权限）
    void forceSetBalance(BankAccount& account, double newBalance) {
        // 直接访问私有成员并修改
        account.balance = newBalance;
        cout << "管理员已将余额修改为：" << account.balance << " 元" << endl;
    }
};

// 定义一个简单的 Student 类，演示标准的封装实践
class Student {
// 所有成员变量都设为私有
private:
    // 私有成员变量：姓名
    string name;
    // 私有成员变量：年龄
    int age;
    // 私有成员变量：分数
    double score;

// 公有接口
public:
    // 构造函数
    Student(string n, int a, double s) {
        name = n;
        // 使用 setter 进行赋值，可以包含验证
        setAge(a);
        setScore(s);
    }

    // Getter：获取姓名
    string getName() {
        return name;
    }

    // Setter：设置姓名
    void setName(string n) {
        name = n;
    }

    // Getter：获取年龄
    int getAge() {
        return age;
    }

    // Setter：设置年龄（包含验证逻辑）
    void setAge(int a) {
        // 年龄必须在 0 到 150 之间
        if (a >= 0 && a <= 150) {
            age = a;
        } else {
            cout << "年龄不合法！" << endl;
            age = 0;
        }
    }

    // Getter：获取分数
    double getScore() {
        return score;
    }

    // Setter：设置分数（包含验证逻辑）
    void setScore(double s) {
        // 分数必须在 0 到 100 之间
        if (s >= 0 && s <= 100) {
            score = s;
        } else {
            cout << "分数不合法！" << endl;
            score = 0;
        }
    }

    // 显示学生信息
    void display() {
        cout << "学生：" << name << "，年龄：" << age << "，分数：" << score << endl;
    }
};

// 主函数
int main() {
    // ---- 演示封装 ----
    cout << "===== 演示封装 =====" << endl;

    // 创建 BankAccount 对象
    BankAccount account("张三", 1000.0, "储蓄账户");

    // 通过公有接口操作数据
    cout << endl << "--- 通过公有接口操作 ---" << endl;
    // 调用 deposit 存款
    account.deposit(500);
    // 调用 withdraw 取款
    account.withdraw(200);
    // 尝试非法取款（余额不足）
    account.withdraw(2000);

    // 通过 Getter 获取数据
    cout << endl << "--- 通过 Getter 获取数据 ---" << endl;
    cout << "持有人：" << account.getOwnerName() << endl;
    cout << "当前余额：" << account.getBalance() << " 元" << endl;

    // 显示账户信息
    cout << endl << "--- 显示账户信息 ---" << endl;
    account.displayInfo();

    // ---- 演示友元函数 ----
    cout << endl << "===== 演示友元函数 =====" << endl;
    // 友元函数可以访问私有成员
    showBalance(account);

    // ---- 演示友元类 ----
    cout << endl << "===== 演示友元类 =====" << endl;
    // 创建 Manager 对象
    Manager mgr;
    // 管理员查看账户详情
    mgr.viewAccountDetails(account);
    // 管理员强制修改余额
    mgr.forceSetBalance(account, 99999.99);

    // ---- 演示标准的封装实践 ----
    cout << endl << "===== 演示 Getter/Setter 封装 =====" << endl;

    // 创建 Student 对象
    Student stu("李四", 20, 85.5);
    stu.display();

    // 尝试设置不合法的年龄
    cout << "尝试设置不合法年龄：";
    stu.setAge(200);
    cout << "当前年龄：" << stu.getAge() << endl;

    // 尝试设置不合法的分数
    cout << "尝试设置不合法分数：";
    stu.setScore(105);
    cout << "当前分数：" << stu.getScore() << endl;

    // 合法修改
    stu.setAge(21);
    stu.setScore(90.0);
    cout << "合法修改后：";
    stu.display();

    return 0;
}
