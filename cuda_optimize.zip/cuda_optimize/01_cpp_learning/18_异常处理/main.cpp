// ============================================================
// 18_异常处理 main.cpp
// 演示：try/catch/throw、自定义异常类、标准异常、多级捕获、noexcept
// ============================================================

// 包含输入输出流头文件，用于控制台输入输出
#include <iostream>
// 包含字符串头文件，用于使用 std::string 类型
#include <string>
// 包含 stdexcept 头文件，用于使用标准异常类（如 runtime_error）
#include <stdexcept>
// 包含 vector 头文件，用于演示 RAII 与异常安全
#include <vector>

// 使用标准命名空间，避免每次写 std:: 前缀
using namespace std;

// ============================================================
// 自定义异常类：DivisionByZeroException（除零异常）
// 继承自 std::exception，也可以直接继承自 std::runtime_error
// 建议：总是从 std::exception 派生自定义异常类
// ============================================================
class DivisionByZeroException : public exception {
public:
    // 构造函数：接收错误信息字符串
    // 参数 msg：描述错误原因的消息
    DivisionByZeroException(const string& msg) : message(msg) {
        // 构造函数体为空，初始化在初始化列表中完成
    }

    // 重写基类的 what() 方法
    // what() 是 exception 类提供的虚函数，返回异常的描述信息
    // noexcept 关键字保证这个函数不会抛出异常
    // const char* 返回 C 风格字符串
    const char* what() const noexcept override {
        // 返回存储的错误消息的 C 风格字符串
        return message.c_str();
    }

private:
    // 存储异常的描述信息
    string message;
};

// ============================================================
// 自定义异常类：InvalidInputException（无效输入异常）
// 继承自 std::runtime_error，更方便，因为 runtime_error 已经实现了 what()
// ============================================================
class InvalidInputException : public runtime_error {
public:
    // 构造函数：直接将消息传递给 runtime_error 的构造函数
    // runtime_error 会自动存储并管理这个消息
    // 参数 msg：描述错误原因的消息
    InvalidInputException(const string& msg) : runtime_error(msg) {
        // 构造函数体为空
    }
};

// ============================================================
// 辅助函数：打印分隔线
// ============================================================
void printSection(const string& title) {
    cout << endl;
    cout << "==========================================" << endl;
    cout << "  " << title << endl;
    cout << "==========================================" << endl;
}

// ============================================================
// 除法函数：可能抛出除零异常
// 参数 a：被除数（分子）
// 参数 b：除数（分母）
// 返回值：a / b 的结果
// 注意：这个函数声明了可能抛出异常（没有 noexcept 关键字）
// ============================================================
double divide(double a, double b) {
    // 检查除数是否为零
    if (b == 0.0) {
        // 如果除数为零，抛出自定义的 DivisionByZeroException 异常
        // throw 语句会立即退出当前函数
        throw DivisionByZeroException("除数不能为零！");
    }
    // 正常情况返回除法结果
    return a / b;
}

// ============================================================
// 函数：验证输入范围
// 参数 value：要验证的值
// 参数 min：允许的最小值（包含）
// 参数 max：允许的最大值（包含）
// 参数 name：值的名称（用于错误消息）
// 如果值超出范围，抛出 InvalidInputException 异常
// ============================================================
void validateRange(int value, int min, int max, const string& name) {
    // 检查值是否小于最小值
    if (value < min) {
        // 值太小，抛出异常
        throw InvalidInputException(name + " 的值 " + to_string(value)
                                     + " 小于最小值 " + to_string(min));
    }
    // 检查值是否大于最大值
    if (value > max) {
        // 值太大，抛出异常
        throw InvalidInputException(name + " 的值 " + to_string(value)
                                     + " 大于最大值 " + to_string(max));
    }
    // 值在有效范围内，函数正常返回（不抛异常）
    cout << name << " = " << value << " 在有效范围 [" << min << ", " << max << "] 内" << endl;
}

// ============================================================
// noexcept 函数示例：获取数组元素
// noexcept 关键字保证这个函数不会抛出异常
// 参数 arr：整数数组（C 风格数组的引用）
// 参数 size：数组大小
// 参数 index：要访问的索引
// 返回值：对应索引的元素值
// 注意：这个函数不进行边界检查，如果越界则是未定义行为
// ============================================================
int getElementSafe(const int arr[], size_t /*size*/, size_t index) noexcept {
    // 注意：noexcept 函数如果内部抛出异常，程序会调用 std::terminate()
    // 所以 noexcept 函数内部必须确保不抛出异常
    // 这里不进行边界检查直接返回（确保了不抛异常，但调用方需保证 index 有效）
    return arr[index];
}

// ============================================================
// 函数：模拟资源分配（演示 RAII 与异常安全）
// 这个函数可能抛出异常
// ============================================================
class ResourceManager {
public:
    // 构造函数：模拟分配资源
    // 参数 id：资源的标识符
    ResourceManager(int id) : id(id) {
        // 输出资源分配信息
        cout << "  [ResourceManager] 分配资源 #" << id << endl;
    }

    // 析构函数：模拟释放资源
    // 析构函数默认是 noexcept 的，不应该抛出异常
    ~ResourceManager() {
        // 输出资源释放信息
        cout << "  [ResourceManager] 释放资源 #" << id << endl;
    }

private:
    // 资源的标识符
    int id;
};

// ============================================================
// 函数：使用 RAII 对象演示异常安全
// 即使函数中抛出异常，已创建的 RAII 对象也会被自动销毁
// ============================================================
void demonstrateRAII() {
    cout << "进入 demonstrateRAII 函数" << endl;

    // 创建 RAII 资源管理对象（在栈上）
    ResourceManager res1(1);
    ResourceManager res2(2);

    // 使用 vector（也是 RAII 类，自动管理内存）
    vector<int> numbers = {10, 20, 30};
    cout << "  vector 大小为: " << numbers.size() << endl;

    // 故意抛出一个异常
    cout << "  准备抛出异常..." << endl;
    throw runtime_error("demonstrateRAII 中发生错误！");

    // 下面的代码不会被执行，因为上面已经抛出了异常
    // 但是 res1、res2 和 numbers 的析构函数都会被自动调用（栈展开）
    cout << "  这行不会被执行" << endl;
}

// ============================================================
// 主函数
// ============================================================
int main() {
    // 输出程序标题
    cout << "========== 异常处理 演示 ==========" << endl;

    // ============================================================
    // 第一部分：基本的 try/catch/throw
    // ============================================================
    printSection("基本的 try / catch / throw");

    // 使用 try 块包裹可能抛出异常的代码
    try {
        // 在 try 块中调用可能抛出异常的函数
        cout << "调用 divide(10, 2): ";
        double result = divide(10.0, 2.0);  // 正常情况，不会抛出异常
        cout << result << endl;

        // 这次调用会抛出异常，因为除数为零
        cout << "调用 divide(10, 0): ";
        double badResult = divide(10.0, 0.0);  // 这行会抛出异常
        // 下面的代码不会被执行，因为上面已经抛出了异常
        cout << badResult << endl;

        cout << "这行不会被执行" << endl;
    }
    // catch 块捕获指定类型的异常
    // 使用 const 引用捕获，避免拷贝和对象切片
    catch (const DivisionByZeroException& e) {
        // 调用异常的 what() 方法获取错误描述
        cout << "捕获到除零异常: " << e.what() << endl;
    }

    // 继续执行后续代码（异常已被处理，程序不会终止）
    cout << "异常已处理，程序继续执行..." << endl;

    // ============================================================
    // 第二部分：多级 catch（捕获不同类型的异常）
    // ============================================================
    printSection("多级 catch 块");

    try {
        // 调用 divide 函数，这次传递 0 作为除数
        cout << "调用 divide(5, 0): " << endl;
        double result = divide(5.0, 0.0);
        cout << "结果: " << result << endl;  // 不会执行
    }
    // 首先捕获 DivisionByZeroException 类型的异常
    catch (const DivisionByZeroException& e) {
        cout << "捕获 DivisionByZeroException: " << e.what() << endl;
    }
    // 然后捕获更通用的 exception 类型（基类）
    catch (const exception& e) {
        cout << "捕获 exception: " << e.what() << endl;
    }
    // 最后是 catch-all（捕获任意异常）
    // 注意：catch-all 应该放在最后
    catch (...) {
        // 三个点表示捕获任何类型的异常
        cout << "捕获到未知类型的异常" << endl;
    }

    // ============================================================
    // 第三部分：范围验证（自定义异常类 InvalidInputException）
    // ============================================================
    printSection("范围验证与自定义异常");

    // 测试 1：值在有效范围内（不会抛出异常）
    try {
        cout << "测试 1: 年龄 = 25，范围 [0, 150]" << endl;
        validateRange(25, 0, 150, "年龄");
    } catch (const InvalidInputException& e) {
        // 捕获 InvalidInputException
        cout << "无效输入: " << e.what() << endl;
    }

    // 测试 2：值超出最大范围（会抛出异常）
    try {
        cout << endl << "测试 2: 年龄 = 200，范围 [0, 150]" << endl;
        validateRange(200, 0, 150, "年龄");
    } catch (const InvalidInputException& e) {
        // 捕获异常并输出错误信息
        cout << "无效输入: " << e.what() << endl;
    }

    // ============================================================
    // 第四部分：栈展开（Stack Unwinding）与 RAII
    // 当异常抛出时，所有栈上的对象都会被自动销毁（析构函数被调用）
    // 然后异常才被 catch 块捕获
    // ============================================================
    printSection("栈展开与 RAII");

    // 使用 try 块调用 demonstrateRAII 函数
    // 该函数中会抛出异常，但函数中创建的 RAII 对象会被自动销毁
    try {
        // 调用演示 RAII 的函数
        demonstrateRAII();
    } catch (const runtime_error& e) {
        // 捕获异常
        cout << "捕获到 runtime_error: " << e.what() << endl;
    }

    // 注意：上面的 try 块执行后，demonstrateRAII 函数中的
    // ResourceManager 对象和 vector 都会被自动析构，
    // 即使函数中途抛出了异常。这就是 RAII 的力量。
    cout << "RAII 演示完成，所有资源已自动释放" << endl;

    // ============================================================
    // 第五部分：noexcept 说明符
    // ============================================================
    printSection("noexcept 说明符");

    // 调用 noexcept 函数（安全的情况）
    int arr[] = {100, 200, 300, 400, 500};
    size_t arrSize = 5;

    // 正常调用，index 在有效范围内
    cout << "arr[2] = " << getElementSafe(arr, arrSize, 2) << endl;
    // 输出: 300

    // 注意：如果越界调用 noexcept 函数，行为是未定义的
    // 不会抛出异常，但可能访问非法内存
    cout << "注意：noexcept 函数如果越界访问不会抛异常，而是未定义行为" << endl;

    // 演示 noexcept 运算符（编译时检查表达式是否 noexcept）
    cout << "divide(1.0, 2.0) 是否 noexcept? " << boolalpha << noexcept(divide(1.0, 2.0)) << endl;
    cout << "getElementSafe 是否 noexcept? " << boolalpha << noexcept(getElementSafe(arr, arrSize, 0)) << endl;
    // noexcept 运算符是编译时检查，不会实际调用函数

    // ============================================================
    // 第六部分：使用标准异常类（std::runtime_error）
    // ============================================================
    printSection("标准异常类");

    try {
        // 创建一个 runtime_error 异常并抛出
        cout << "抛出一个 std::runtime_error..." << endl;
        throw runtime_error("这是一个标准运行时错误！");
    } catch (const runtime_error& e) {
        // 捕获 runtime_error 并使用 what() 获取消息
        cout << "捕获 runtime_error: " << e.what() << endl;
    }

    // 演示标准异常类的继承层次
    cout << endl << "标准异常类的捕获顺序：" << endl;
    cout << "  更具体的异常应放在前面，更通用的放在后面" << endl;

    try {
        // 抛出一个 out_of_range 异常（它是 logic_error 的子类）
        // out_of_range 通常用于报告下标越界
        throw out_of_range("vector 下标越界！");
    }
    // 先捕获子类（更具体）
    catch (const out_of_range& e) {
        cout << "捕获 out_of_range: " << e.what() << endl;
    }
    // 再捕获父类（更通用）
    catch (const logic_error& e) {
        cout << "捕获 logic_error: " << e.what() << endl;
    }
    // 最后捕获最通用的 exception
    catch (const exception& e) {
        cout << "捕获 exception: " << e.what() << endl;
    }

    // ============================================================
    // 第七部分：异常捕获的顺序很重要
    // ============================================================
    printSection("catch 块的匹配顺序");

    try {
        // 抛出一个 invalid_argument 异常
        throw invalid_argument("无效参数示例");
    }
    // 注意：如果把 catch(exception) 放在前面，
    // 它会匹配所有继承自 exception 的异常类型
    // 所以更具体的 catch 必须放在更前面
    catch (const invalid_argument& e) {
        cout << "捕获 invalid_argument（具体）: " << e.what() << endl;
    }
    catch (const logic_error& e) {
        cout << "捕获 logic_error（较通用）: " << e.what() << endl;
    }
    catch (const exception& e) {
        cout << "捕获 exception（最通用）: " << e.what() << endl;
    }

    // ============================================================
    // 第八部分：重新抛出异常（rethow）
    // ============================================================
    printSection("重新抛出异常（rethow）");

    // 有时 catch 块不想完全处理异常，而是记录日志后重新抛出
    // 让外层的 catch 块继续处理
    try {
        try {
            // 内层 try 块：抛出一个异常
            cout << "内层 try 块：抛出一个异常" << endl;
            throw runtime_error("内部错误");
        }
        catch (const runtime_error& e) {
            // 内层 catch：记录日志，然后重新抛出
            cout << "  内层 catch：记录日志: " << e.what() << endl;
            cout << "  内层 catch：重新抛出异常..." << endl;
            // 使用不带参数的 throw 重新抛出当前异常
            // 注意：throw; 而不是 throw e;（后者会创建一个新的异常对象）
            throw;
        }
    }
    catch (const runtime_error& e) {
        // 外层 catch：处理重新抛出的异常
        cout << "外层 catch：捕获到重新抛出的异常: " << e.what() << endl;
    }

    // ============================================================
    // 结束
    // ============================================================
    cout << endl;
    cout << "========== 程序结束 ==========" << endl;

    // 程序正常返回
    return 0;
}
