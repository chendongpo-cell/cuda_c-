# 18_异常处理

## 一、什么是异常

**异常（Exception）** 是程序在运行时遇到错误或特殊情况时，用来传递错误信息的一种机制。

C++ 的异常处理提供了一种 **结构化** 的方式来分离 **正常逻辑** 和 **错误处理逻辑**，让代码更清晰、更健壮。

---

## 二、基本语法：try / catch / throw

### 2.1 三个关键字

| 关键字 | 作用 |
|--------|------|
| `try` | 包含可能抛出异常的代码块 |
| `catch` | 捕获并处理特定类型的异常 |
| `throw` | 抛出异常（可以是任何类型的对象） |

### 2.2 基本流程

```cpp
try {
    // 可能出错的代码
    if (出错条件) {
        throw SomeException("错误信息");
    }
} catch (const SomeException& e) {
    // 处理异常
    cout << e.what() << endl;
}
```

**执行流程：**
1. `try` 块中抛出异常 → 立即退出 `try` 块
2. 按顺序匹配 `catch` 块（类型匹配）
3. 匹配成功后执行对应的 `catch` 块
4. 执行完 `catch` 后，继续执行后续代码

---

## 三、捕获方式的区别

### 3.1 按值捕获 vs 按引用捕获

```cpp
catch (SomeException e)      // 按值捕获：会拷贝异常对象（可能发生切片）
catch (const SomeException& e) // 按引用捕获：推荐，避免拷贝和切片
```

**推荐使用 const 引用捕获**，原因：
- 避免不必要的拷贝
- 避免对象切片（派生类异常被按值捕获时会丢失派生信息）

### 3.2 多个 catch 块

```cpp
try {
    // ...
} catch (const std::runtime_error& e) {
    // 处理 runtime_error
} catch (const std::exception& e) {
    // 处理其他标准异常
} catch (...) {
    // 处理任意异常（catch-all）
}
```

**注意：** `catch` 块按顺序匹配，应该将更具体的异常类型放在前面，更通用的放在后面。

---

## 四、标准异常类

C++ 标准库提供了一系列异常类，都继承自 `std::exception`：

```
std::exception
├── std::logic_error
│   ├── std::invalid_argument
│   ├── std::domain_error
│   ├── std::length_error
│   └── std::out_of_range
├── std::runtime_error
│   ├── std::range_error
│   ├── std::overflow_error
│   └── std::underflow_error
└── std::bad_alloc (new 分配失败)
    └── std::bad_cast (dynamic_cast 失败)
```

所有标准异常都提供 `what()` 方法返回错误描述字符串。

---

## 五、noexcept 说明符（C++11）

### 5.1 语法

```cpp
void func() noexcept;            // 承诺永不抛出异常
void func() noexcept(false);     // 可能抛出异常
```

### 5.2 作用

- **承诺**：告诉编译器该函数不会抛出异常
- **优化**：编译器可以进行更好的优化
- **约束**：如果 noexcept 函数内部抛出异常，程序会直接调用 `std::terminate()`

### 5.3 使用场景

- 析构函数默认是 `noexcept` 的
- 移动构造函数和移动赋值运算符通常标记为 `noexcept`
- 简单的基础操作（如 getter/setter）应标记为 `noexcept`

---

## 六、异常安全级别

当一段代码抛出异常时，程序的状态应该保持在一种合理的状态。异常安全分为三个级别：

| 级别 | 说明 |
|------|------|
| **基本保证** | 抛出异常后，资源不泄漏，对象处于有效但不确定的状态 |
| **强保证** | 抛出异常后，状态回滚到操作之前（类似事务） |
| **不抛保证** | 承诺永不抛出异常（noexcept） |

---

## 七、最佳实践

1. **使用自定义异常类**：从 `std::exception` 派生，而不是抛基本类型
2. **按 const 引用捕获**：避免拷贝和切片
3. **不要在析构函数中抛出异常**：析构函数默认 noexcept，抛出会导致 terminate
4. **RAII 管理资源**：使用智能指针、vector 等自动管理资源
5. **只对异常情况使用异常**：不要用异常控制正常流程
6. **不需要捕获所有异常**：如果不知道如何处理，让上层去处理
