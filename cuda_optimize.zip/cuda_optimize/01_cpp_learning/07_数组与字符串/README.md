# 07 数组与字符串

## 1. 直观理解

### 数组 = 连续内存块

数组是 C++ 中最基础的批量数据存储方式。它的本质是**一段连续的内存**，所有元素紧挨着排列，没有任何间隔。

```cpp
int arr[5] = {10, 20, 30, 40, 50};

// 内存布局（假设 arr 起始地址 = 0x1000）：
// 地址      内容
// 0x1000   10      ← arr[0]
// 0x1004   20      ← arr[1]
// 0x1008   30      ← arr[2]
// 0x100C   40      ← arr[3]
// 0x1010   50      ← arr[4]
// 每个 int 占 4 字节，arr[i] 的地址 = &arr[0] + i * sizeof(int)
```

因为内存连续，数组有两个关键性质：
- **随机访问 O(1)**：`arr[i]` 通过 `首地址 + i × sizeof(元素)` 直接定位
- **缓存友好**：遍历数组时 CPU 预取相邻元素到缓存

### 字符串的两种形态

C++ 中有两种字符串：
1. **C 风格字符串**：`char[]`，以 `\0` 结尾——来自 C 语言的遗产
2. **`std::string`**：C++ 标准库类——安全、方便、功能丰富

---

## 2. 语法速查

### 一维数组

```cpp
int arr[5] = {10, 20, 30, 40, 50};   // 声明并全部初始化
int arr2[] = {1, 2, 3};              // 自动推导大小
int arr3[5] = {1, 2};                // 部分初始化：{1,2,0,0,0}
int arr4[5] = {0};                   // 全部初始化为 0
```

### 二维数组

```cpp
int matrix[2][3] = {
    {1, 2, 3},
    {4, 5, 6}
};
// 内存布局（行优先）：1 2 3 4 5 6（连续！）
// matrix[i][j] = *(matrix + i*3 + j)
```

### `std::array`（C++11）——推荐替代 C 数组

```cpp
#include <array>
std::array<int, 5> arr = {1, 2, 3, 4, 5};
arr.size();      // 5（知道自己的大小！）
arr.at(3);       // 边界检查（越界抛异常）
arr.front();     // 第一个元素
arr.back();      // 最后一个元素
```

### C 风格字符串

```cpp
char str1[] = "Hello";              // 自动加 \0，大小为 6
char str2[10] = "Hi";               // 剩余位置用 \0 填充
const char* str3 = "World";         // 指向只读字符串字面量

// C 字符串函数（需要 <cstring>）
strlen(str);       // 长度（不含 \0）
strcpy(dst, src);  // 复制（危险！不检查大小）
strcat(dst, src);  // 拼接（危险！不检查大小）
strcmp(a, b);      // 比较：0=相等，负=a<b，正=a>b
```

### `std::string`（推荐）

```cpp
#include <string>
std::string s = "Hello";
s += " World";           // 拼接
s.length();              // 长度
s.substr(0, 5);          // 子串
s.find("World");         // 查找
s == "Hello";            // 直接比较（不用 strcmp！）
s[0];                    // 访问字符（无边界检查）
s.at(0);                 // 访问字符（有边界检查）
```

---

## 3. 底层原理

### 数组名退化为指针

C++ 中数组名在绝大多数表达式中会**隐式转换（退化）为首元素的指针**：

```cpp
int arr[5] = {1, 2, 3, 4, 5};

int* p = arr;        // arr 退化为 &arr[0]（隐式的！）
arr + 1;             // arr 退化为指针，+1 指向 arr[1]
func(arr);           // 传递的是指针，不是整个数组的拷贝
```

**两个例外——不退化为指针的情况**：

```cpp
sizeof(arr);         // 20（5 个 int × 4 字节）——返回整个数组的大小！
&arr;                // int(*)[5]（指向整个数组的指针，不是 int**）
                     // &arr + 1 会跳过整个数组（+20 字节）
```

### 数组越界为什么是未定义行为

```cpp
int arr[5] = {1, 2, 3, 4, 5};
arr[10] = 42;  // UB！
// 没有运行时边界检查，arr[10] = *(arr + 10)
// 直接往 arr+40 字节的地址写入 42
// 这个地址可能是其他变量、返回地址、未映射的内存...
```

C 数组不存储自己的长度——`arr` 只是一个地址，没有"5 个元素"这个元信息。这就是为什么 `std::array` 和 `std::vector` 更好。

### `\0` 终止符的历史与危险

C 语言中字符串没有单独存储长度，而是用一个特殊字符 `\0`（ASCII 码 0）标记结尾：

```
char str[] = "Hi";
内存：'H'  'i'  '\0'  ??  ??  ...
```

所有 C 字符串函数（`strlen`、`strcpy`、`strcat`）都通过 `\0` 来判断字符串结束。如果 `\0` 丢失——**缓冲区溢出**，函数会一直读/写到内存中碰巧遇到 `\0` 为止。

```cpp
char dst[5];
strcpy(dst, "Hello, World!");  // 写越界了！dst 只有 5 字节，
                                 // 但 "Hello, World!" 需要 14 字节（含 \0）
// 这就是臭名昭著的缓冲区溢出漏洞的根源
```

`strncpy` 看似安全，实则也有坑——如果源字符串长度 >= n，它不会在末尾加 `\0`：

```cpp
char dst[5];
strncpy(dst, "HelloWorld", 4);
dst[4] = '\0';  // 必须手动加！
```

### `std::string` 的 SSO（Small String Optimization）

短字符串（通常 ≤ 15 个字符）不会分配堆内存，而是直接存在 `std::string` 对象内部：

```cpp
std::string s = "hi";  // 短字符串，不分配堆内存
// string 对象内部有一个 16 字节的小缓冲区（SSO buffer）
// "hi" 直接存在那里，避免堆分配的开销

std::string big(1000, 'x'); // 长字符串——在堆上分配
```

SSO 大幅提升了短字符串操作的性能。这也是为什么 `std::string` 在很多场景下比 C 风格字符串还快。

---

## 4. 深入细节

### Unicode / UTF-8 基本概念

C++ 的 `char` 是 1 字节，只能存 ASCII。对于中文等多字节字符，需要编码：

```cpp
std::string s = "你好";  // UTF-8 编码
s.length();              // 6（每个中文字符在 UTF-8 中占 3 字节！）
s[0];                    // 第一个 UTF-8 字节，不是"你"

// 如果需要按字符（而非字节）操作：
#include <codecvt>        // C++11（但已弃用）
// 实际项目通常用第三方库（ICU、utf8cpp）或 C++20 的 char8_t
```

```cpp
char8_t* u8str = u8"你好";        // C++20：UTF-8 字面量
char16_t* u16str = u"你好";       // UTF-16
char32_t* u32str = U"你好";       // UTF-32
```

> 对于推理优化，字符串处理不是核心——但了解编码避免踩坑。

### C 数组作为函数参数

```cpp
// 这三种写法完全等价——都退化为指针：
void func1(int arr[]);
void func2(int arr[10]);   // 10 只是文档提示，编译器不检查！
void func3(int* arr);

// 所以 sizeof(arr) 在函数内部返回的是指针大小（8 字节），不是数组大小！
```

如果必须传递数组大小，有三种方式：
```cpp
void func(int* arr, size_t size);                    // 方式 1：同时传大小
template<size_t N> void func(int (&arr)[N]);          // 方式 2：模板推导
void func(std::array<int, 10>& arr);                  // 方式 3：用 std::array
void func(std::vector<int>& arr);                     // 方式 4：用 std::vector
```

---

## 5. C++ vs Python 对照

```python
# Python
arr = [1, 2, 3, 4, 5]     # list，可动态增长
arr.append(6)
len(arr)                   # 5

matrix = [[1,2],[3,4]]     # list of lists（非连续内存！）

s = "Hello"
s += " World"              # 新字符串（不可变）
len(s)                     # 11
"World" in s               # True
```

```cpp
// C++
int arr[5] = {1, 2, 3, 4, 5};  // C 数组，固定大小，不可增长
// arr 不能 .append()——大小固定
sizeof(arr) / sizeof(arr[0]);  // 5（只能这样算！）

std::vector<int> vec = {1,2,3,4,5};  // 这才是 Python list 的对应
vec.push_back(6);

std::string s = "Hello";
s += " World";              // 原地修改（可变）
s.length();                 // 11
```

| 方面 | Python | C++ |
|------|--------|-----|
| 动态数组 | `list`（原生支持） | `std::vector` |
| 固定数组 | 无（tuple 不可变但不是数组） | C 数组 / `std::array` |
| 多维数组 | list of lists（不连续内存） | 连续内存（行优先） |
| 字符串 | 不可变，Unicode 原生支持 | `std::string`（可变）或 C 字符串 |
| 越界 | `IndexError` 异常 | UB（C 数组）/ `std::out_of_range`（at()） |
| 边界检查 | 自动 | 手动（`operator[]` 不检查，`.at()` 检查） |
| 长度 | `len()` | `sizeof` 技巧 / `.size()` / `.length()` |

---

## 6. 练习与思考

### 基础练习

1. 创建一个 10 个元素的数组，用 `for` 循环逆序输出
2. 用 `std::array` 替代 C 数组，实现求平均值
3. 实现一个函数，接收 C 风格字符串，返回反转后的 `std::string`
4. 比较 `strcmp` 和 `std::string::operator==` 的用法差异

### 思考题

5. 为什么 `sizeof(arr) / sizeof(arr[0])` 能算数组长度，但在函数参数里就失效了？
6. `&arr` 和 `&arr[0]` 的值相同但类型不同，分别是什么类型？（提示：`int(*)[N]` vs `int*`）
7. 用 `strncpy` 复制字符串有哪些坑？写代码展示一种安全的用法
8. `std::string` 的 SSO 在不同编译器上阈值不同（MSVC 15 字节，GCC 15 字节，Clang 22 字节）——写代码测试你的编译器上 SSO 阈值是多少？

> 参考阅读：[内存模型](../docs/00_内存模型.md) —— 数组在栈/堆上的内存布局
