// ============================================================
// 07_数组与字符串 —— 主示例代码
// 演示：一维数组、二维数组、C风格字符串、范围for循环
// 编译方式：g++ -std=c++17 main.cpp -o main
// ============================================================

// 引入输入输出流库，用于控制台输入输出
#include <iostream>
// 引入 C 风格字符串处理函数库（strlen, strcpy, strcmp 等）
#include <cstring>
// 引入标准命名空间，方便使用 cout、endl 等
using namespace std;

// 程序的主函数，所有 C++ 程序的入口
int main() {
    // ============================================================
    // 第一部分：一维数组的声明、初始化和遍历
    // ============================================================
    // 打印分隔线，让输出更清晰
    cout << "===== 一维数组 =====" << endl;

    // 方式一：声明一个能存放 5 个整数的数组，并完全初始化
    int numbers[5] = {10, 20, 30, 40, 50};
    // 方式二：声明时不指定大小，编译器根据初始化列表自动推导
    int scores[] = {95, 87, 92, 78, 88, 91};

    // 使用 sizeof 计算数组占用的总字节数，除以单个元素大小得到元素个数
    // sizeof(numbers) 返回整个数组的字节数（这里是 5 * 4 = 20 字节）
    // sizeof(numbers[0]) 返回第一个元素占用的字节数（这里是 4 字节）
    int numCount = sizeof(numbers) / sizeof(numbers[0]);
    // 输出数组元素个数
    cout << "numbers 数组有 " << numCount << " 个元素: ";

    // 用 for 循环遍历数组，从下标 0 到 numCount - 1
    for (int i = 0; i < numCount; i++) {
        // 输出数组中的每个元素
        cout << numbers[i] << " ";
    }
    // 输出换行
    cout << endl;

    // 计算 scores 数组的元素个数
    int scoreCount = sizeof(scores) / sizeof(scores[0]);
    // 初始化一个变量来保存总分
    int total = 0;
    // 遍历 scores 数组，累加每个元素的值
    for (int i = 0; i < scoreCount; i++) {
        // 将当前元素的值加到 total 上
        total += scores[i];
    }
    // 计算平均值，注意将 total 转换为 double 类型再做除法，否则会丢失小数部分
    double average = (double)total / scoreCount;
    // 输出总分和平均分
    cout << "成绩总分: " << total << ", 平均分: " << average << endl;

    // ============================================================
    // 第二部分：查找数组中的最大值和最小值
    // ============================================================
    // 打印提示
    cout << "===== 数组最大值和最小值 =====" << endl;

    // 定义一个整型数组
    int data[] = {34, 67, 12, 89, 45, 23, 90, 11};
    // 计算数组元素个数
    int dataCount = sizeof(data) / sizeof(data[0]);
    // 假设第一个元素既是最大值也是最小值（初始化）
    int maxVal = data[0];
    int minVal = data[0];

    // 从第二个元素（下标 1）开始遍历
    for (int i = 1; i < dataCount; i++) {
        // 如果当前元素比 maxVal 大，更新最大值
        if (data[i] > maxVal) {
            maxVal = data[i];
        }
        // 如果当前元素比 minVal 小，更新最小值
        if (data[i] < minVal) {
            minVal = data[i];
        }
    }
    // 输出最大值和最小值
    cout << "最大值: " << maxVal << ", 最小值: " << minVal << endl;

    // ============================================================
    // 第三部分：范围-based for 循环（C++11 特性）
    // ============================================================
    // 打印提示
    cout << "===== 范围-based for 循环 =====" << endl;

    // 定义一个数组
    int values[] = {2, 4, 6, 8, 10};
    // 计算数组元素个数
    int valCount = sizeof(values) / sizeof(values[0]);
    // 输出数组的内容
    cout << "原始数组: ";
    // 使用范围-based for 循环遍历数组（只读，x 是每个元素的副本）
    for (int x : values) {
        // 输出 x 的值
        cout << x << " ";
    }
    cout << endl;

    // 使用范围-based for 循环配合引用（&）来修改数组元素
    // int &x 中的 & 表示引用，修改 x 就等于修改原数组中的元素
    for (int &x : values) {
        // 每个元素乘以 2
        x = x * 2;
    }

    // 输出修改后的数组内容
    cout << "每个元素乘以 2 后: ";
    for (int x : values) {
        cout << x << " ";
    }
    cout << endl;

    // ============================================================
    // 第四部分：二维数组（矩阵）
    // ============================================================
    // 打印提示
    cout << "===== 二维数组（矩阵） =====" << endl;

    // 声明并初始化一个 3 行 4 列的二维数组
    // 可以理解为 3 个一维数组，每个一维数组有 4 个元素
    int matrix[3][4] = {
        {1,  2,  3,  4},   // 第 0 行
        {5,  6,  7,  8},   // 第 1 行
        {9, 10, 11, 12}    // 第 2 行
    };

    // 用嵌套 for 循环遍历二维数组
    // 外层循环遍历行
    for (int row = 0; row < 3; row++) {
        // 内层循环遍历列
        for (int col = 0; col < 4; col++) {
            // 输出 matrix[row][col] 的值，并用 \t 对齐
            cout << matrix[row][col] << "\t";
        }
        // 每行结束后换行
        cout << endl;
    }

    // 计算矩阵所有元素的和
    int matrixSum = 0;
    // 外层循环遍历行
    for (int row = 0; row < 3; row++) {
        // 内层循环遍历列
        for (int col = 0; col < 4; col++) {
            // 累加每个元素
            matrixSum += matrix[row][col];
        }
    }
    // 输出矩阵所有元素的总和
    cout << "矩阵所有元素之和: " << matrixSum << endl;

    // ============================================================
    // 第五部分：C 风格字符串（字符数组）
    // ============================================================
    // 打印提示
    cout << "===== C 风格字符串 =====" << endl;

    // 方式一：用字符串字面量初始化字符数组
    // 编译器会自动在末尾添加 '\0'（空字符）
    char greeting[] = "Hello, C++!";
    // 输出字符串
    cout << "字符串内容: " << greeting << endl;
    // 使用 strlen 获取字符串长度（不包括 '\0'）
    cout << "字符串长度: " << strlen(greeting) << endl;

    // 方式二：逐个字符初始化（必须手动添加 '\0'）
    char str[6] = {'W', 'o', 'r', 'l', 'd', '\0'};
    // 输出这个字符数组形式的字符串
    cout << "另一个字符串: " << str << endl;

    // ============================================================
    // 第六部分：strcpy 和 strcat 的使用
    // ============================================================
    // 打印提示
    cout << "===== strcpy 和 strcat 字符串操作 =====" << endl;

    // 定义一个字符数组作为目标缓冲区，大小要足够大
    char buffer[50] = {0};  // 全部初始化为 0（即空字符）
    // 定义源字符串
    char source[] = "Hello";

    // strcpy(destination, source)：将 source 复制到 destination
    strcpy(buffer, source);
    // 输出复制后的结果
    cout << "strcpy 后: " << buffer << endl;

    // strcat(destination, source)：将 source 追加到 destination 末尾
    strcat(buffer, " World");
    // 输出追加后的结果
    cout << "strcat 后: " << buffer << endl;

    // ============================================================
    // 第七部分：strcmp 字符串比较
    // ============================================================
    // 打印提示
    cout << "===== strcmp 字符串比较 =====" << endl;

    // 定义两个要比较的字符串
    char s1[] = "apple";
    char s2[] = "banana";
    char s3[] = "apple";

    // strcmp 返回 0 表示两个字符串相等
    int result1 = strcmp(s1, s3);
    cout << "strcmp(\"apple\", \"apple\") = " << result1 << " (相等)" << endl;

    // strcmp 返回负数表示第一个字符串小于第二个（按字典序）
    int result2 = strcmp(s1, s2);
    cout << "strcmp(\"apple\", \"banana\") = " << result2 << " (apple < banana)" << endl;

    // strcmp 返回正数表示第一个字符串大于第二个
    int result3 = strcmp(s2, s1);
    cout << "strcmp(\"banana\", \"apple\") = " << result3 << " (banana > apple)" << endl;

    // ============================================================
    // 第八部分：遍历 C 风格字符串的两种方式
    // ============================================================
    // 打印提示
    cout << "===== 遍历 C 风格字符串 =====" << endl;

    // 定义一个字符串
    char text[] = "C++";
    // 用 strlen 得到长度，然后按下标遍历
    cout << "方式一（下标遍历）: ";
    // strlen(text) 返回字符串的长度（不含 '\0'）
    for (int i = 0; i < (int)strlen(text); i++) {
        // 输出每个字符
        cout << text[i];
    }
    cout << endl;

    // 用指针遍历，直到遇到 '\0'
    cout << "方式二（指针遍历）: ";
    // 定义一个 char 指针 p，指向字符串的第一个字符
    char *p = text;
    // 当指针指向的内容不是 '\0' 时继续循环
    while (*p != '\0') {
        // 输出当前指针指向的字符
        cout << *p;
        // 指针移动到下一个位置
        p++;
    }
    cout << endl;

    // 程序正常结束，返回 0 表示成功
    return 0;
}
