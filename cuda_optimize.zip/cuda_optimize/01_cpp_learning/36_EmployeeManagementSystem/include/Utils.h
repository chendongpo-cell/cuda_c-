// ============================================================
// Utils.h —— 工具函数头文件
// 提供项目中通用的辅助函数：输入验证、格式化、日期时间等
// ============================================================

// 头文件保护宏：防止重复包含
#ifndef UTILS_H
#define UTILS_H

#include <string>       // 字符串类型
#include <vector>       // 向量容器
#include <limits>       // std::numeric_limits，用于输入验证
#include <iostream>     // 输入输出流
#include <sstream>      // 字符串流，用于格式化
#include <iomanip>      // 输入输出格式控制
#include <ctime>        // 时间日期函数

// 使用 ems 命名空间组织所有项目代码
namespace ems {

// ============================================================
// 输入工具函数
// ============================================================

/**
 * getInput - 读取用户输入的整数，带范围验证和错误处理
 * @param prompt: 提示用户输入的文字
 * @param min: 允许的最小值（包含）
 * @param max: 允许的最大值（包含）
 * @return: 用户输入的有效整数
 *
 * 这个函数展示了异常处理和输入流状态检查的典型用法。
 * 如果用户输入了非数字内容，会清空输入缓冲区并提示重新输入。
 */
int getInput(const std::string& prompt, int min, int max);

/**
 * getInput - 读取用户输入的浮点数，带范围验证
 * @param prompt: 提示文字
 * @param min: 允许的最小值
 * @param max: 允许的最大值
 * @return: 用户输入的有效浮点数
 */
double getInput(const std::string& prompt, double min, double max);

/**
 * getInput - 读取用户输入的非空字符串
 * @param prompt: 提示文字
 * @return: 用户输入的非空字符串
 */
std::string getInput(const std::string& prompt);

/**
 * getInput - 读取用户输入的单个字符
 * @param prompt: 提示文字
 * @return: 用户输入的第一个字符
 */
char getChar(const std::string& prompt);

// ============================================================
// 格式化工具函数
// ============================================================

/**
 * formatSalary - 将工资格式化为带两位小数的字符串
 * @param salary: 要格式化的工资数值
 * @return: 格式化后的字符串，如 "12,500.00"
 */
std::string formatSalary(double salary);

/**
 * fmtTime - 获取当前时间的字符串表示
 * @return: 格式化的时间字符串，如 "2026-06-13 15:30:00"
 */
std::string fmtTime();

// ============================================================
// 字符串工具函数（模板函数）
// 使用模板是因为它不依赖具体类型，可以处理多种字符串容器
// ============================================================

/**
 * split - 将字符串按分隔符分割为字符串向量
 * @param str: 要分割的原始字符串
 * @param delimiter: 分隔符
 * @return: 分割后的字符串向量
 */
std::vector<std::string> split(const std::string& str, char delimiter);

/**
 * trim - 去除字符串首尾的空白字符（空格、制表符、换行等）
 * @param str: 要处理的字符串
 * @return: 去除首尾空白后的字符串
 */
std::string trim(const std::string& str);

// ============================================================
// 显示工具函数
// ============================================================

/**
 * printHeader - 打印带边框的标题
 * @param title: 标题文字
 * @param width: 边框总宽度，默认 60
 *
 * 示例输出：
 * ============================================================
 * =                    员工管理系统                      =
 * ============================================================
 */
void printHeader(const std::string& title, int width = 60);

/**
 * printSeparator - 打印分隔线
 * @param ch: 分隔符字符，默认 '='
 * @param width: 分隔线总宽度，默认 60
 */
void printSeparator(char ch = '=', int width = 60);

/**
 * waitForEnter - 暂停程序，等待用户按回车键继续
 * 用于分页显示时让用户有足够时间阅读信息
 */
void waitForEnter();

} // namespace ems

#endif // UTILS_H
