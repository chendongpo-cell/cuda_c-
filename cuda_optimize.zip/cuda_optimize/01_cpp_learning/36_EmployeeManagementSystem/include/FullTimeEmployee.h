#ifndef FULLTIMEEMPLOYEE_H   // 防止头文件被重复包含，如果未定义 FULLTIMEEMPLOYEE_H 则编译以下内容
#define FULLTIMEEMPLOYEE_H   // 定义 FULLTIMEEMPLOYEE_H 宏，标记此头文件已被包含

#include "Employee.h"         // 包含基类 Employee 的头文件，因为 FullTimeEmployee 继承自 Employee
#include <string>             // 包含 string 头文件，用于 std::string 类型的返回值

namespace ems {              // 进入 ems（Employee Management System）命名空间，避免与其他项目的类名冲突

// 正式员工类 FullTimeEmployee，继承自抽象基类 Employee
// 正式员工是公司中最为常见的员工类型，除了基本工资外，还享有固定的奖金（bonus）
class FullTimeEmployee : public Employee {  // public 继承，保持基类的接口对外可见
private:
    // 奖金（单位：元）
    // 正式员工在基本工资之上，每月/每年享有固定额度的奖金，
    // 这是正式员工与兼职员工的主要区别之一。
    double bonus;

public:
    // 构造函数：初始化正式员工的所有属性
    // 参数：
    //   name       - 员工姓名
    //   baseSalary - 基本工资（元）
    //   bonus      - 奖金（元）
    // 构造函数中调用基类 Employee 的构造函数来初始化姓名和基本工资，
    // 然后用自己的初始化列表来初始化 bonus。
    FullTimeEmployee(const std::string& name, double baseSalary, double bonus);

    // 重写基类的纯虚函数 calcSalary，计算正式员工的实际工资
    // 正式员工的工资计算公式：工资 = 基本工资 + 奖金
    // 之所以这样设计，是因为正式员工的收入构成为"保底 + 固定奖励"，
    // 比兼职员工（通常只有时薪）更稳定。
    double calcSalary() const override;

    // 重写基类的纯虚函数 displayInfo，在控制台显示正式员工的完整信息
    // 显示内容包括：员工编号、姓名、员工类型、基本工资、奖金、总工资。
    // override 关键字确保此函数确实重写了基类的虚函数，
    // 如果基类签名发生变化，编译器会报错，避免"想重写但实际成了重载"的陷阱。
    void displayInfo() const override;

    // 重写基类的纯虚函数 getType，返回员工类型的中文描述
    // 返回值 "正式员工" 用于界面展示和文件序列化时的类型标识。
    std::string getType() const override;

    // 重写基类的 saveToFile 虚函数，将正式员工的数据写入文件
    // 先调用基类的 saveToFile 写入通用字段（类型、ID、姓名、基本工资），
    // 再追加本类特有的字段（奖金），字段之间用逗号分隔。
    // 文件格式示例：正式员工,1,张三,8000,2000
    void saveToFile(std::ofstream& out) const override;
};

} // namespace ems          // 退出 ems 命名空间

#endif // FULLTIMEEMPLOYEE_H  // 结束头文件的条件编译保护
