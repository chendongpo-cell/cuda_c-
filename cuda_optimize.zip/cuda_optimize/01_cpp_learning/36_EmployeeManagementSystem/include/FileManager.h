// ============================================================
// FileManager.h —— 文件管理器类的头文件
// 本类负责 Employee 管理系统的全部数据持久化工作，
// 包括从文件保存和加载员工数据。
// 文件存储是主要方式，MySQL 连接代码作为可选方案（需注释取消）。
// ============================================================

#ifndef FILEMANAGER_H  // 防止头文件被重复包含
#define FILEMANAGER_H

#include <string>       // std::string，用于存储文件路径和字符串数据
#include <vector>       // std::vector，用于存储员工对象的容器
#include <memory>       // std::shared_ptr，用于智能指针管理 Employee 对象的生命周期
#include "Employee.h"   // Employee 基类，所有员工类型的抽象接口

namespace ems {         // 进入 ems（Employee Management System）命名空间

// ============================================================
// FileManager 类声明
// 功能：管理员工数据的文件读写操作，支持：
//   1. 保存所有员工到文件（saveAll）
//   2. 从文件加载所有员工（loadAll）
//   3. 根据类型字符串动态创建具体的 Employee 对象（createEmployee，静态工厂方法）
// 数据文件格式为 CSV 风格（逗号分隔），每条记录占一行。
// ============================================================
class FileManager {
private:
    std::string filePath;               // 数据文件的完整路径，由构造函数指定或使用默认值
    static const std::string DATA_DIR;  // 数据目录的路径常量，所有数据文件存放在此目录下

public:
    // ============================================================
    // 构造函数
    // 默认构造函数：使用默认文件路径（DATA_DIR + "employees.dat"）
    // 带参构造函数：使用指定的文件路径
    // ============================================================
    FileManager();                                              // 默认构造函数，使用系统默认路径
    explicit FileManager(const std::string& filePath);          // 带参构造函数，用户指定路径

    // ============================================================
    // saveAll —— 将所有员工数据保存到文件
    // 遍历员工容器，对每个员工调用其多态的 saveToFile() 方法，
    // 将数据按 CSV 格式写入文件。每条记录末尾写入换行符。
    // 参数：employees —— 存储 shared_ptr<Employee> 的 vector 容器
    // 返回：true 表示保存成功，false 表示保存失败（文件无法打开等）
    // ============================================================
    bool saveAll(const std::vector<std::shared_ptr<Employee>>& employees);

    // ============================================================
    // loadAll —— 从文件中加载所有员工数据
    // 逐行读取文件，每行代表一个员工的完整数据。
    // 使用逗号分割每行字段，根据第一个字段（类型名）调用
    // createEmployee() 构造对应的派生类对象。
    // 文件格式示例：
    //   正式员工,1000,张三,8000.00,2000.00
    //   兼职员工,1001,李四,0,50.00,80
    //   经理,1002,王五,15000.00,技术部,10,5000.00
    // 返回：存储 shared_ptr<Employee> 的 vector 容器
    // ============================================================
    std::vector<std::shared_ptr<Employee>> loadAll();

    // ============================================================
    // createEmployee —— 静态工厂方法
    // 根据类型字符串创建对应的 Employee 派生类对象。
    // 使用 shared_ptr 管理返回对象的生命周期。
    // 参数：
    //   type   —— 员工类型字符串（如 "正式员工"、"兼职员工"、"经理"）
    //   fields —— 包含该员工所有字段的字符串向量（已按逗号分割）
    // 返回：指向 Employee 派生类对象的 shared_ptr
    // 说明：
    //   fields 向量的内容顺序如下（不含第0个类型字段）：
    //   正式员工：id, name, baseSalary, bonus
    //   兼职员工：id, name, baseSalary(0), hourlyRate, hoursWorked
    //   经理：id, name, baseSalary, department, teamSize, performanceBonus
    // ============================================================
    static std::shared_ptr<Employee> createEmployee(const std::string& type,
                                                     const std::vector<std::string>& fields);

    // ============================================================
    // 【可选】MySQL 数据库连接方法
    //
    // 以下方法提供了 MySQL 数据库存储的备选方案。
    // 如果需要使用数据库而非文件存储，请取消注释以下方法声明，
    // 并在 FileManager.cpp 中提供对应的实现。
    //
    // 【前提条件】
    // 1. 安装 MySQL Connector/C++ 库
    //    方式一（vcpkg，推荐）：vcpkg install mysql-connector-cpp
    //    方式二（Linux apt）：sudo apt install libmysqlcppconn-dev
    //    方式三（手动）：从 MySQL 官网下载 Connector/C++ 并配置包含路径和库路径
    // 2. 在 CMakeLists.txt 或编译命令中添加链接选项：-lmysqlcppconn
    // 3. 确保 MySQL 服务正在运行，并且以下配置信息与实际环境一致：
    //    - 主机地址：localhost（或实际 IP）
    //    - 端口：3306
    //    - 数据库名：ems_db
    //    - 用户名：root
    //    - 密码：（请根据实际环境修改）
    //
    // 【数据库表结构（参考）】
    // CREATE TABLE employees (
    //     id INT PRIMARY KEY,
    //     name VARCHAR(100) NOT NULL,
    //     type VARCHAR(20) NOT NULL COMMENT '员工类型：正式员工/兼职员工/经理',
    //     base_salary DECIMAL(10,2) NOT NULL,
    //     bonus DECIMAL(10,2) DEFAULT NULL COMMENT '正式员工专用：奖金',
    //     hourly_rate DECIMAL(10,2) DEFAULT NULL COMMENT '兼职员工专用：时薪',
    //     hours_worked INT DEFAULT NULL COMMENT '兼职员工专用：工作小时数',
    //     department VARCHAR(50) DEFAULT NULL COMMENT '经理专用：部门名',
    //     team_size INT DEFAULT NULL COMMENT '经理专用：团队人数',
    //     performance_bonus DECIMAL(10,2) DEFAULT NULL COMMENT '经理专用：绩效奖金'
    // );
    //
    // ============================================================
    // bool saveToMySQL(const std::vector<std::shared_ptr<Employee>>& employees);
    // std::vector<std::shared_ptr<Employee>> loadFromMySQL();
};

} // namespace ems

#endif // FILEMANAGER_H
