#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include <iostream>
#include <fstream>

namespace ems {

// 抽象基类 Employee：所有员工类型的顶层接口
// 使用抽象类而非具体类，是因为"员工"本身是一个模糊概念，
// 只有具体类型的员工（经理、工程师等）才有实际的工资计算逻辑。
class Employee {
protected:
    int id;                     // 员工编号，构造时由 nextId 自动分配，不可更改
    std::string name;           // 员工姓名，允许通过 setName() 修改
    double baseSalary;          // 基本工资（单位：元），不同岗位以此为基数计算最终工资

    static int nextId;          // 静态计数器，每创建一个 Employee 子类实例就自增一次，
                                // 确保每个员工获得全局唯一的 ID（只要不溢出 int 范围）

public:
    // 构造函数：接受姓名和基本工资，ID 由 nextId++ 自动分配
    // 之所以不在参数中传入 ID，是因为自增机制可以避免上层调用者传入重复 ID，
    // 降低使用本类的出错概率。
    Employee(const std::string& name, double baseSalary)
        : id(nextId++), name(name), baseSalary(baseSalary) {}

    // 虚析构函数：必须为虚函数，否则通过基类指针 delete 派生类对象时
    // 不会正确调用派生类的析构函数，从而导致资源泄漏。
    virtual ~Employee() = default;

    // 纯虚函数：计算工资 —— 每种员工类型的薪资公式不同，
    // 强制子类实现，避免出现"忘记实现"导致调用无意义的默认返回值。
    virtual double calcSalary() const = 0;

    // 纯虚函数：显示员工全部信息（ID、姓名、类型、工资等）
    // 用于控制台输出和调试，子类应输出更丰富的信息。
    virtual void displayInfo() const = 0;

    // 纯虚函数：返回员工类型名称（如 "Manager"、"Engineer"）
    // 用于文件序列化时区分不同员工类型，以及 UI 展示。
    virtual std::string getType() const = 0;

    // 虚函数：将员工数据以文本格式写入文件
    // 默认实现写入通用字段（类型、ID、姓名、基本工资），
    // 子类如果有多余字段应该重写此函数，先调用父类版本再写入自己的字段。
    virtual void saveToFile(std::ofstream& out) const {
        out << getType() << "," << id << "," << name << "," << baseSalary;
    }

    // ---- getters ----
    int getId() const { return id; }
    std::string getName() const { return name; }
    double getBaseSalary() const { return baseSalary; }

    // ---- setters ----
    // 员工姓名允许修改（如员工改名或录入错误时纠正）。
    void setName(const std::string& newName) { name = newName; }
    // 基本工资允许调整（如年度调薪）。
    void setBaseSalary(double newBaseSalary) { baseSalary = newBaseSalary; }

    // 友元函数：重载 << 运算符，使 Employee 对象可以像基本类型一样直接输出到流。
    // 友元而非成员函数，是因为左操作数是 ostream 而非 Employee，
    // 这样做符合标准库的习惯用法（cout << emp;）。
    friend std::ostream& operator<<(std::ostream& os, const Employee& emp) {
        os << "[Employee] ID: " << emp.id
           << ", Name: " << emp.name
           << ", Type: " << emp.getType()
           << ", BaseSalary: " << emp.baseSalary;
        return os;
    }
};

} // namespace ems

#endif // EMPLOYEE_H
