// ============================================================
// EmployeeManager.cpp —— 员工管理核心类实现文件
// 实现 EmployeeManager.h 中声明的所有方法
//
// 本文件是员工管理系统的"业务逻辑层"，负责：
// - 员工容器的增、删、改、查操作
// - 多种方式的员工信息展示
// - 工资统计与排序
// - 文件读写委托
// ============================================================

// 引入对应的头文件，编译器需要看到类的完整声明才能实现成员函数
#include "EmployeeManager.h"
// 引入算法库，用于 std::sort、std::for_each 等算法
#include <algorithm>
// 引入字符串库，用于字符串比较操作（tolower 转换等）
#include <cctype>
// 引入输入输出流库，用于控制台输出
#include <iostream>

// ============================================================
// 使用 ems 命名空间
// 此命名空间包含了 Employee、EmployeeManager 等类
// ============================================================
namespace ems {

// ============================================================
// 构造函数 —— EmployeeManager()
//
// 功能：初始化一个空的员工管理器对象
// 参数：无
// 返回值：无
//
// 说明：
// - employees 和 employeeIndex 在类初始化时自动构造为空状态
// - fileManager 默认构造，不需要手动初始化
// - 此处不需要任何额外操作，因此函数体为空
// ============================================================
EmployeeManager::EmployeeManager() {
    // 构造函数体为空，所有成员变量已通过各自的默认构造函数完成初始化
    // std::vector 默认为空，std::map 默认为空，FileManager 默认构造
}

// ============================================================
// addEmployee —— 向系统添加一名新员工
//
// 功能：将员工对象加入 employees 向量，同时更新 employeeIndex 索引
// 参数：
//   emp —— 待添加的员工对象的 std::shared_ptr<Employee> 智能指针
// 返回值：void
//
// 设计细节：
// - push_back 会将 emp 的拷贝加入 vector 末尾（shared_ptr 的拷贝使引用计数 +1）
// - 索引插入使用 map 的 [] 运算符，以员工 ID 为键
// - 之所以同时更新 vector 和 map，是为了保证两种数据结构的同步
// ============================================================
void EmployeeManager::addEmployee(std::shared_ptr<Employee> emp) {
    // 步骤一：将员工对象的共享指针添加到 employees 向量的末尾
    // push_back 是 std::vector 的方法，在数组尾部添加新元素
    // 如果 vector 的容量不足，会自动重新分配更大的内存空间
    employees.push_back(emp);

    // 步骤二：在 employeeIndex 映射表中建立 ID 到员工对象的关联
    // map 的 [] 运算符：如果键不存在则创建新条目，如果已存在则覆盖
    // emp->getId() 通过多态调用 Employee 的 getId() 方法获取员工编号
    // 这样后续可以通过 findById 方法快速查找，无需遍历整个 vector
    employeeIndex[emp->getId()] = emp;
}

// ============================================================
// removeEmployee —— 根据员工编号移除指定员工
//
// 功能：从 employees 向量中删除指定 ID 的员工，然后重建索引
// 参数：
//   id —— 要删除的员工编号（int 类型）
// 返回值：
//   bool —— 删除成功返回 true，未找到指定 ID 返回 false
//
// 设计细节：
// - 使用 std::find_if 配合 Lambda 表达式查找匹配 ID 的员工
// - 找到后用 vector::erase 移除元素
// - 删除后调用 rebuildIndex 重建 map 索引，保持数据一致性
// - 之所以不直接更新 map，是因为 erase 会使元素位置改变，
//   重建索引是最简单可靠的同步方式
// ============================================================
bool EmployeeManager::removeEmployee(int id) {
    // 步骤一：使用 std::find_if 算法在 employees 向量中查找指定 ID 的员工
    // std::find_if 接受一个范围（begin 到 end）和一个谓词（Lambda 表达式）
    // Lambda 表达式 [id](const auto& emp) 捕获外部变量 id，接受一个员工指针参数
    // 返回第一个使 Lambda 返回 true 的迭代器
    auto it = std::find_if(employees.begin(), employees.end(),
        [id](const auto& emp) {
            // Lambda 函数体：比较当前员工的 ID 与目标 ID 是否相等
            // emp->getId() 通过多态调用 Employee 的 getId() 方法
            return emp->getId() == id;
        }
    );

    // 步骤二：判断是否找到了匹配的员工
    // 如果迭代器等于 employees.end()，说明遍历了整个向量都没找到匹配项
    if (it == employees.end()) {
        // 未找到指定 ID 的员工，返回 false 表示删除失败
        return false;
    }

    // 步骤三：从 employees 向量中移除该元素
    // vector::erase 接受一个迭代器参数，删除该位置的元素
    // 删除后，该位置之后的所有元素会向前移动，vector 的大小减 1
    // 注意：erase 会使后续迭代器失效，但我们已经用完了 it，所以没问题
    employees.erase(it);

    // 步骤四：重建 map 索引
    // 由于 vector 中元素的位置发生了变化（删除点之后的元素前移），
    // 我们需要重新建立 employeeIndex 以确保它反映最新的 employees 状态
    // 注意：map 是按 key（ID）排序的红黑树，与 vector 中的位置无关，
    // 但我们无法通过简单的删除来同步，因为不知道被删元素是否在 map 中，
    // 所以最安全的方式是重建整个索引
    rebuildIndex();

    // 删除成功，返回 true
    return true;
}

// ============================================================
// updateEmployee —— 更新指定员工的基本信息
//
// 功能：根据员工编号查找员工，然后更新其姓名和基本工资
// 参数：
//   id         —— 要更新的员工编号
//   name       —— 新的员工姓名
//   baseSalary —— 新的基本工资
// 返回值：
//   bool —— 更新成功返回 true，未找到指定 ID 返回 false
//
// 设计细节：
// - 使用 employeeIndex 快速定位员工对象（O(log n) 时间）
// - 通过智能指针修改对象的 setName 和 setBaseSalary
// - 不需要重建索引，因为 ID 没有变化
// ============================================================
bool EmployeeManager::updateEmployee(int id, const std::string& name, double baseSalary) {
    // 步骤一：通过 employeeIndex 查找指定 ID 的员工
    // map::find 返回一个迭代器，指向键值对 (pair<const int, shared_ptr<Employee>>)
    // 如果未找到，find 返回 employeeIndex.end()
    auto it = employeeIndex.find(id);

    // 步骤二：检查是否找到了该员工
    if (it == employeeIndex.end()) {
        // 未找到指定 ID 的员工，返回 false 表示更新失败
        return false;
    }

    // 步骤三：获取员工的共享指针（迭代器的 second 成员是值，即 shared_ptr<Employee>）
    auto emp = it->second;

    // 步骤四：调用 Employee 类的 setName 方法更新员工姓名
    // setName 是 Employee 的公有 setter 方法，会修改内部的 name 成员变量
    // 由于 C++ 的多态机制，无论实际类型是什么，都会调用正确的 setName
    emp->setName(name);

    // 步骤五：调用 Employee 类的 setBaseSalary 方法更新基本工资
    // setBaseSalary 是 Employee 的公有 setter 方法，会修改内部的 baseSalary 成员变量
    // 注意：更新基本工资后，下次调用 calcSalary() 时会基于新工资计算
    emp->setBaseSalary(baseSalary);

    // 更新成功，返回 true
    return true;
}

// ============================================================
// findById —— 根据员工编号快速查找员工
//
// 功能：利用 employeeIndex 映射表实现 O(log n) 时间复杂度的查找
// 参数：
//   id —— 要查找的员工编号
// 返回值：
//   std::shared_ptr<Employee> —— 找到返回员工共享指针，未找到返回 nullptr
//
// 设计细节：
// - 使用 map 索引而非遍历 vector，大幅提升查找效率
// - 当系统中有大量员工时，O(log n) 与 O(n) 的差异非常明显
// - 返回 shared_ptr 而不是引用，因为调用方可能需要独立拥有对象的所有权
// ============================================================
std::shared_ptr<Employee> EmployeeManager::findById(int id) {
    // 步骤一：在 employeeIndex 映射表中查找指定 ID
    // map::find 使用红黑树的二分查找，时间复杂度为 O(log n)
    auto it = employeeIndex.find(id);

    // 步骤二：检查查找结果
    if (it != employeeIndex.end()) {
        // 找到了：返回该员工的共享指针
        // it->first 是键（ID），it->second 是值（shared_ptr<Employee>）
        return it->second;
    }

    // 未找到：返回空指针 nullptr
    // 调用方在接收到 nullptr 后应进行判空处理，避免解引用空指针
    return nullptr;
}

// ============================================================
// findByName —— 根据姓名模糊查找员工
//
// 功能：遍历 employees 向量，查找姓名中包含指定关键字的员工
//       支持大小写不敏感的字符串比较
// 参数：
//   name —— 要查找的姓名关键字
// 返回值：
//   std::vector<std::shared_ptr<Employee>> —— 所有姓名匹配的员工列表
//                                           未找到时返回空 vector
//
// 设计细节：
// - 遍历整个 vector，逐一比较姓名
// - 使用 std::string::find 实现"包含"语义而非"完全相等"
// - 将两个字符串都转为小写再比较，实现大小写不敏感
// - 返回 vector 而非单个指针，因为可能有多人同名
// ============================================================
std::vector<std::shared_ptr<Employee>> EmployeeManager::findByName(const std::string& name) {
    // 步骤一：创建一个空的 vector 用于存储查找结果
    std::vector<std::shared_ptr<Employee>> result;

    // 步骤二：将搜索关键字转换为小写，用于不区分大小写的比较
    // 先拷贝一份 name 到 searchLower 变量中
    std::string searchLower = name;
    // 使用 range-based for 循环遍历字符串中的每一个字符
    // ::tolower 是 C 标准库函数，将字符转为小写
    // 注意：这里使用引用 char& c 是为了能够修改原字符串中的字符
    for (char& c : searchLower) {
        // 将当前字符转换为小写形式
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }

    // 步骤三：遍历 employees 向量，逐一匹配员工姓名
    // 使用 range-based for 循环（C++11 特性），语法简洁
    // 每次迭代从 employees 中取出一个员工共享指针赋值给 emp
    for (const auto& emp : employees) {
        // 步骤四：获取当前员工的姓名并转为小写
        // emp->getName() 返回员工的姓名（std::string）
        std::string empName = emp->getName();
        // 将员工姓名也转为小写，实现大小写不敏感比较
        for (char& c : empName) {
            c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        }

        // 步骤五：检查员工姓名中是否包含搜索关键字
        // std::string::find 返回关键字第一次出现的位置
        // 如果未找到，返回 std::string::npos（一个特殊的大值）
        // 如果 find 返回值不等于 npos，说明姓名中包含关键字
        if (empName.find(searchLower) != std::string::npos) {
            // 匹配成功：将当前员工加入结果 vector
            result.push_back(emp);
        }
    }

    // 步骤六：返回结果 vector（可能为空）
    // 这里使用了"返回值优化"（RVO），编译器会避免不必要的拷贝
    return result;
}

// ============================================================
// displayAll —— 显示所有员工的信息
//
// 功能：遍历 employees 向量，调用每个员工的 displayInfo() 方法
//       利用 C++ 多态机制，每个员工显示其类型特有的信息
// 参数：无
// 返回值：void
//
// 设计细节：
// - 使用 range-based for 循环遍历容器
// - 通过基类指针调用虚函数 displayInfo()，触发动态绑定
// - 不同类型的员工会输出不同的内容格式
// ============================================================
void EmployeeManager::displayAll() const {
    // 步骤一：输出标题行，提示用户即将显示所有员工信息
    std::cout << "========== 所有员工信息 ==========" << std::endl;

    // 步骤二：遍历 employees 向量
    // 使用 const auto& 避免拷贝，同时保持只读语义（const 成员函数只能调用 const 操作）
    // 这里的 auto 被推导为 std::shared_ptr<const Employee> 的引用
    for (const auto& emp : employees) {
        // 步骤三：调用当前员工的 displayInfo() 方法
        // 由于 displayInfo 被声明为 virtual，这里会触发动态绑定
        // 如果 emp 指向 FullTimeEmployee，则调用 FullTimeEmployee::displayInfo()
        // 如果 emp 指向 Manager，则调用 Manager::displayInfo()
        // 如果 emp 指向 PartTimeEmployee，则调用 PartTimeEmployee::displayInfo()
        // 这就是"多态"的威力：同一行代码对不同类型对象产生不同行为
        emp->displayInfo();

        // 步骤四：在每个员工信息后打印一条分隔线，使输出更清晰
        // 方便用户区分不同员工的信息块
        std::cout << "------------------------" << std::endl;
    }
}

// ============================================================
// displayByType —— 按类型过滤显示员工
//
// 功能：遍历 employees 向量，仅显示类型名称与指定类型匹配的员工
//       使用 Lambda 表达式作为过滤筛选条件
// 参数：
//   type —— 要显示的员工类型名称字符串
// 返回值：void
//
// 设计细节：
// - 使用 range-based for 循环遍历
// - 调用 getType() 多态方法获取每个员工的类型名称
// - 仅当类型匹配时才调用 displayInfo() 显示
// - 展示 Lambda 表达式在实际业务场景中的典型应用
// ============================================================
void EmployeeManager::displayByType(const std::string& type) const {
    // 步骤一：输出标题，提示用户即将按类型显示员工
    std::cout << "========== " << type << " 信息 ==========" << std::endl;

    // 步骤二：定义 Lambda 表达式作为过滤条件
    // Lambda 表达式格式：[捕获列表](参数列表) -> 返回值类型 { 函数体 }
    // 这里捕获了外部变量 type，接受一个 shared_ptr<Employee> 参数
    // 返回 bool 类型：true 表示该员工匹配指定类型
    auto typeFilter = [&type](const std::shared_ptr<Employee>& emp) -> bool {
        // Lambda 函数体：比较员工的类型名称是否与指定类型相同
        // emp->getType() 是多态方法，返回员工的实际类型名称字符串
        return emp->getType() == type;
    };

    // 步骤三：遍历 employees 向量，使用 Lambda 过滤
    for (const auto& emp : employees) {
        // 步骤四：调用 Lambda 表达式判断当前员工是否匹配指定类型
        if (typeFilter(emp)) {
            // 类型匹配：调用 displayInfo() 显示该员工的信息
            // 由于多态，即使是同一类型的员工，也会正确显示各自的详细信息
            emp->displayInfo();
            // 打印分隔线，使输出格式整齐
            std::cout << "------------------------" << std::endl;
        }
    }
}

// ============================================================
// getTotalSalary —— 计算所有员工的总工资
//
// 功能：遍历所有员工，累加每个员工的 calcSalary() 返回值
// 参数：无
// 返回值：double —— 所有员工工资的总和
//
// 设计细节：
// - 使用 range-based for 循环遍历
// - calcSalary() 是多态方法，会根据实际对象类型计算不同的工资
// - 正式员工工资 = 基本工资 + 奖金
// - 经理工资 = 基本工资 + 绩效奖金 × (1 + 团队人数 × 5%)
// - 兼职员工工资 = 时薪 × 工作小时数
// ============================================================
double EmployeeManager::getTotalSalary() const {
    // 步骤一：初始化总工资变量为 0.0
    // 使用 double 类型以保证精度
    double total = 0.0;

    // 步骤二：遍历 employees 向量，累加每个员工的工资
    // const auto& 避免拷贝，保持只读语义
    for (const auto& emp : employees) {
        // 调用 calcSalary() 多态方法计算当前员工的工资
        // 并累加到 total 变量中
        // calcSalary() 是 const 成员函数（在 Employee 中声明为 const）
        // 因此可以在 const 成员函数中调用
        total += emp->calcSalary();
    }

    // 步骤三：返回累加得到的总工资
    return total;
}

// ============================================================
// getAverageSalary —— 计算所有员工的平均工资
//
// 功能：用总工资除以员工数量得到平均工资
// 参数：无
// 返回值：double —— 平均工资
//
// 设计细节：
// - 调用 getTotalSalary() 获取总工资，避免代码重复
// - 调用 getCount() 获取员工数量
// - 处理员工数量为 0 的边界情况，避免除以零
// ============================================================
double EmployeeManager::getAverageSalary() const {
    // 步骤一：获取员工总数
    // getCount() 返回 employees.size()，类型为 size_t（无符号整数）
    size_t count = getCount();

    // 步骤二：检查是否有员工
    if (count == 0) {
        // 员工数量为 0，直接返回 0.0 避免除以零错误
        // 在实际项目中，也可以考虑抛出异常或返回特殊值
        return 0.0;
    }

    // 步骤三：计算平均工资 = 总工资 / 员工数量
    // 注意：getTotalSalary() 返回 double 类型
    // static_cast<double>(count) 将 size_t 转为 double 避免整数除法
    // 但这里 count 被赋值给 double 的返回值，所以不需要显式转换
    double average = getTotalSalary() / static_cast<double>(count);

    // 步骤四：返回计算出的平均工资
    return average;
}

// ============================================================
// getHighestPaid —— 获取工资最高的员工
//
// 功能：遍历所有员工，比较每个员工的 calcSalary() 返回值
//       返回工资最高的员工对象
// 参数：无
// 返回值：
//   std::shared_ptr<Employee> —— 工资最高的员工的共享指针
//   如果员工数量为 0，返回 nullptr
//
// 设计细节：
// - 使用迭代遍历方式逐个比较工资
// - 仅记录工资最高的员工，不修改容器顺序
// - 时间复杂度 O(n)，空间复杂度 O(1)
// ============================================================
std::shared_ptr<Employee> EmployeeManager::getHighestPaid() const {
    // 步骤一：检查 employees 向量是否为空
    if (employees.empty()) {
        // 如果没有员工，返回 nullptr
        // 调用方需要对 nullptr 做判空处理
        return nullptr;
    }

    // 步骤二：假设第一个员工的工资最高
    // 使用 employees.front() 获取第一个元素的迭代方式
    auto highest = employees.front();

    // 步骤三：遍历剩余的员工，找出真正工资最高的
    // 从 employees.begin() + 1 开始（跳过已假设为最高的第一个员工）
    // 但为代码简洁，直接从 begin() 开始遍历也可以（多一次无用比较）
    for (const auto& emp : employees) {
        // 比较当前员工的工资与当前最高工资
        // calcSalary() 是多态方法，自动计算正确的工资
        if (emp->calcSalary() > highest->calcSalary()) {
            // 当前员工的工资更高，更新最高工资员工
            highest = emp;
        }
    }

    // 步骤四：返回工资最高的员工
    return highest;
}

// ============================================================
// sortBySalary —— 按工资降序排序
//
// 功能：使用 std::sort 算法，配合 Lambda 表达式作为比较器
//       按 calcSalary() 的返回值从高到低排列员工
// 参数：无
// 返回值：void
//
// 设计细节：
// - std::sort 需要随机访问迭代器，std::vector 满足此要求
// - 使用 Lambda 表达式定义"降序"的比较逻辑
// - 排序后调用 rebuildIndex 重建 map 索引
// - 排序复杂度 O(n log n)
// ============================================================
void EmployeeManager::sortBySalary() {
    // 步骤一：使用 std::sort 对 employees 向量进行排序
    // std::sort(first, last, comp) 需要三个参数：
    //   - first: 起始迭代器（employees.begin()）
    //   - last: 结束迭代器（employees.end()）
    //   - comp: 比较函数（Lambda 表达式）
    std::sort(employees.begin(), employees.end(),
        // Lambda 表达式：定义两个员工的比较规则
        // 捕获列表为空 []，不需要捕获外部变量
        // 参数列表是两个 Employee 共享指针的常量引用
        // 返回值是 bool 类型
        [](const std::shared_ptr<Employee>& a, const std::shared_ptr<Employee>& b) -> bool {
            // 降序排列：a 的工资大于 b 的工资时返回 true
            // 这样工资高的员工会排在前面
            // calcSalary() 是多态方法，正确计算各自的实际工资
            return a->calcSalary() > b->calcSalary();
        }
    );

    // 步骤二：排序完成后重建 map 索引
    // 虽然排序不改变员工的 ID 和对象本身，只改变 vector 中的位置顺序
    // 但 rebuildIndex 可以确保 map 与 vector 完全同步
    // 这里调用 rebuildIndex 主要是为了防御性编程，保持代码一致性
    rebuildIndex();
}

// ============================================================
// loadFromFile —— 从文件加载员工数据
//
// 功能：将文件操作委托给 FileManager 对象
//       FileManager 负责解析文件格式并创建相应的员工对象
// 参数：无
// 返回值：
//   bool —— 加载成功返回 true，失败（如文件不存在或格式错误）返回 false
//
// 设计细节：
// - 遵循"单一职责原则"，文件解析逻辑由 FileManager 处理
// - EmployeeManager 只关心业务层面的结果（成功或失败）
// ============================================================
bool EmployeeManager::loadFromFile() {
    // 委托给 fileManager 的 loadAll 方法
    // FileManager::loadAll() 从文件读取所有员工数据并返回一个新的 vector
    // 返回的 vector 中包含新创建的各派生类员工对象（shared_ptr）
    std::vector<std::shared_ptr<Employee>> loaded = fileManager.loadAll();

    // 清空当前容器和索引，用加载的数据替换
    employees.clear();
    employeeIndex.clear();

    // 将加载的员工逐个添加到管理器中
    for (auto& emp : loaded) {
        employees.push_back(emp);
        employeeIndex[emp->getId()] = emp;
    }

    // 加载成功（即使加载了 0 个员工也算成功，非首次运行时可能文件为空）
    return true;
}

// ============================================================
// saveToFile —— 将员工数据保存到文件
//
// 功能：将当前所有员工的数据序列化并写入文件
//       文件操作委托给 FileManager 对象处理
// 参数：无
// 返回值：
//   bool —— 保存成功返回 true，失败（如磁盘空间不足或无写入权限）返回 false
//
// 设计细节：
// - 遵循"单一职责原则"，文件写入逻辑由 FileManager 处理
// - EmployeeManager 提供 employees 容器数据，FileManager 负责写入
// ============================================================
bool EmployeeManager::saveToFile() {
    // 委托给 fileManager 的 saveToFile 方法
    // fileManager.saveToFile() 内部会遍历 employees 容器，
    // 调用每个员工的 saveToFile() 方法将数据写入文件
    // 文件的格式由 FileManager 统一管理
    return fileManager.saveAll(employees);
}

// ============================================================
// getCount —— 获取员工数量
//
// 功能：返回当前 employees 向量中的员工总数
// 参数：无
// 返回值：size_t —— 员工数量（无符号整数）
//
// 设计细节：
// - 直接返回 employees.size()，时间复杂度 O(1)
// - std::vector::size() 返回 size_t 类型
// ============================================================
size_t EmployeeManager::getCount() const {
    // 调用 employees 向量的 size() 方法获取当前员工数量
    // std::vector::size() 返回容器中的元素个数，时间复杂度为常数 O(1)
    // 因为 vector 内部维护了一个计数器记录元素总数
    return employees.size();
}

// ============================================================
// getAll —— 获取所有员工的常量引用
//
// 功能：返回 employees 向量的常量引用，供外部代码遍历访问
// 参数：无
// 返回值：
//   const std::vector<std::shared_ptr<Employee>>&
//   employees 的常量引用，不允许通过此引用修改容器内容
//
// 设计细节：
// - 返回常量引用可以避免不必要的 vector 拷贝
// - 如果返回 vector 值类型，会导致整个容器的深拷贝，性能开销大
// - 常量引用保证了封装性：外部可以读取但不能修改
// ============================================================
const std::vector<std::shared_ptr<Employee>>& EmployeeManager::getAll() const {
    // 返回 employees 成员的常量引用
    // const 限定符确保调用方不能通过此引用修改 employees 的内容
    // 这既保证了性能（无需拷贝），又保证了封装性（只读访问）
    return employees;
}

// ============================================================
// rebuildIndex —— 重建员工索引
//
// 功能：清空 employeeIndex 映射表，然后遍历 employees 向量
//       重新为每个员工建立 ID 到共享指针的映射
// 参数：无
// 返回值：void（私有方法，仅在类内部调用）
//
// 设计细节：
// - 先 clear() 清空 map，再逐个 insert
// - 在 removeEmployee 等修改 vector 的操作后调用
// - 因为在 vector 中删除元素后，map 中的指针仍然指向有效对象
//   （shared_ptr 引用计数 > 0），但 map 中的条目数量与 vector 不同步
// - 重建是最简单可靠的同步策略
// ============================================================
void EmployeeManager::rebuildIndex() {
    // 步骤一：清空 employeeIndex 映射表
    // std::map::clear() 移除 map 中的所有键值对
    // 清空后，map 的大小变为 0
    // 注意：由于 map 中存储的是 shared_ptr，clear 会减少被指向对象的引用计数
    // 但 employees 向量中仍然持有这些 shared_ptr，所以对象不会被销毁
    employeeIndex.clear();

    // 步骤二：遍历 employees 向量，为每个员工重新建立映射
    // 使用 range-based for 循环，每次取出一个员工的共享指针
    for (const auto& emp : employees) {
        // 步骤三：将当前员工的 ID 和共享指针插入 map
        // map 的 [] 运算符会根据 ID 创建或覆盖键值对
        // emp->getId() 获取员工的唯一编号
        // emp 是 shared_ptr<Employee>，指向员工对象
        employeeIndex[emp->getId()] = emp;
    }

    // 重建完成后，employeeIndex 中的键值对数量应该与 employees 中的元素数量一致
    // 如果数量不一致，说明存在 bug（正常情况下不会发生）
}

} // namespace ems             // 退出 ems 命名空间
