// ============================================================
// PartTimeEmployee.cpp —— 兼职员工类实现文件
// 实现 PartTimeEmployee 头文件中声明的所有成员函数
// ============================================================
#include "PartTimeEmployee.h"   // 引入本类的头文件
#include <iostream>             // 引入输入输出流，用于 displayInfo 的格式化输出
#include <iomanip>

using namespace std;            // 使用标准命名空间
using namespace ems;            // 使用员工管理系统命名空间

// ============================================================
// 构造函数
// 功能：创建兼职员工对象，初始化所有成员变量
// 参数：
//   name       —— 员工姓名，传递给基类 Employee 的构造函数
//   hourlyRate —— 时薪（元/小时）
//   hoursWorked —— 工作小时数
// 说明：兼职员工没有固定底薪，因此基类初始化时 baseSalary 传 0
// ============================================================
PartTimeEmployee::PartTimeEmployee(const string& name, double hourlyRate, int hoursWorked)
    : Employee(name, 0.0)       // 调用基类 Employee(name, baseSalary=0)，兼职无底薪
{
    // 使用 this 指针初始化本类的成员变量
    this->hourlyRate   = hourlyRate;     // 设置时薪
    this->hoursWorked  = hoursWorked;    // 设置工作小时数
}

// ============================================================
// calcSalary —— 计算兼职员工工资
// 覆盖基类 Employee 的纯虚函数 calcSalary
// 兼职员工工资按小时计算：兼职工资 = 时薪 × 工时
// 注意：不调用基类的 calcSalary（因为基类不提供默认实现）
// 返回：double 类型的兼职工资金额
// ============================================================
double PartTimeEmployee::calcSalary() const
{
    // 兼职员工工资 = 时薪 × 工作小时数
    // 示例：时薪 50 元，工作 80 小时，则工资 = 50 × 80 = 4000 元
    return hourlyRate * hoursWorked;
}

// ============================================================
// displayInfo —— 显示兼职员工完整信息
// 覆盖基类 Employee 的虚函数 displayInfo
// 输出格式包含：姓名、员工类型、时薪、工时、本月工资
// ============================================================
void PartTimeEmployee::displayInfo() const
{
    // 直接输出公共字段（员工编号和姓名），因为基类 Employee::displayInfo() 是纯虚函数没有实现
    // 不调用基类版本，因为基类没有提供默认实现
    cout << "员工编号: " << id << endl;
    cout << "员工姓名: " << name << endl;
    cout << "员工类型:  " << getType()        << endl;   // 显示员工类型："兼职员工"
    cout << "时薪:      " << hourlyRate       << " 元/小时" << endl;   // 显示每小时的薪资
    cout << "工作小时:  " << hoursWorked      << " 小时"   << endl;   // 显示本月工作总时长
    cout << "本月工资:  " << calcSalary()      << " 元"     << endl;   // 显示计算出的本月工资
    cout << "------------------------"                      << endl;   // 输出分隔线，美化显示
}

// ============================================================
// getType —— 获取员工类型名称
// 覆盖基类 Employee 的纯虚函数 getType
// 返回：字符串 "兼职员工"，用于在系统中标识该员工的用工类型
// ============================================================
string PartTimeEmployee::getType() const
{
    // 返回中文类型名称，便于用户界面显示
    return "兼职员工";
}

// ============================================================
// saveToFile —— 将兼职员工数据保存到文件
// 覆盖基类 Employee 的虚函数 saveToFile
// 按特定格式写入所有字段，以便后续可以从文件恢复数据
// 参数：ofs —— 输出文件流（ofstream）的引用
// ============================================================
void PartTimeEmployee::saveToFile(ofstream& ofs) const
{
    // 首先调用基类的 saveToFile，写入公共字段（类型、ID、姓名、基本工资）
    // 基类会写入：getType() + "," + id + "," + name + "," + baseSalary
    // 注意：兼职员工的基本工资固定为 0
    Employee::saveToFile(ofs);

    // 追加写入兼职员工特有的数据字段（时薪和工作小时数）
    // 格式说明：所有字段在同一行，用逗号分隔（CSV 格式）
    // 完整格式示例：兼职员工,1001,李四,0,50.00,80
    // 基类已经写入了前4个字段，这里追加第5、6个字段
    ofs << "," << hourlyRate  << "," << hoursWorked << endl;
}

// ============================================================
// setHourlyRate —— 设置时薪
// 功能：修改兼职员工的时薪标准
// 参数：rate —— 新的时薪数值（单位：元/小时）
// 返回：无
// ============================================================
void PartTimeEmployee::setHourlyRate(double rate)
{
    // 将传入的 rate 参数赋值给成员变量 hourlyRate
    hourlyRate = rate;
}

// ============================================================
// setHoursWorked —— 设置工作小时数
// 功能：修改兼职员工的工作小时数
// 参数：hours —— 新的工作小时数（单位：小时）
// 返回：无
// ============================================================
void PartTimeEmployee::setHoursWorked(int hours)
{
    // 将传入的 hours 参数赋值给成员变量 hoursWorked
    hoursWorked = hours;
}

// ============================================================
// getHourlyRate —— 获取时薪（常成员函数）
// 功能：返回兼职员工的当前时薪
// const 修饰符保证该函数不会修改对象的状态
// 返回：double 类型的时薪数值
// ============================================================
double PartTimeEmployee::getHourlyRate() const
{
    // 直接返回成员变量 hourlyRate 的值
    return hourlyRate;
}

// ============================================================
// getHoursWorked —— 获取工作小时数（常成员函数）
// 功能：返回兼职员工的当前工作小时数
// const 修饰符保证该函数不会修改对象的状态
// 返回：int 类型的工作小时数
// ============================================================
int PartTimeEmployee::getHoursWorked() const
{
    // 直接返回成员变量 hoursWorked 的值
    return hoursWorked;
}
