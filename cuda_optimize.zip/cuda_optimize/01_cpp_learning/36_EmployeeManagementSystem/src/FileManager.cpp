// ============================================================
// FileManager.cpp —— 文件管理器类的实现文件
// 实现 FileManager 类中声明的所有成员函数，包括：
//   1. saveAll()   —— 将所有员工数据保存到文件
//   2. loadAll()   —— 从文件中加载所有员工数据
//   3. createEmployee() —— 静态工厂方法，根据类型字符串创建对象
// ============================================================

#include "FileManager.h"        // FileManager 类的头文件
#include "FullTimeEmployee.h"   // 正式员工类，用于 createEmployee 中构造对象
#include "PartTimeEmployee.h"   // 兼职员工类，用于 createEmployee 中构造对象
#include "Manager.h"            // 经理类，用于 createEmployee 中构造对象
#include "Utils.h"              // 工具函数，使用 split() 进行字符串分割

#include <fstream>              // std::ifstream / std::ofstream，文件读写操作
#include <iostream>             // std::cerr，用于输出错误信息
#include <sstream>              // std::istringstream，用于字符串解析
#include <stdexcept>            // std::exception，异常处理

namespace ems {                 // 进入 ems 命名空间

// ============================================================
// 静态成员变量 DATA_DIR 的定义与初始化
// 数据目录的默认路径，所有员工数据文件默认存放在此目录下。
// 如果目录不存在，调用 saveAll() 时会自动创建（取决于文件流的行为）。
// 注意：此路径可以根据项目实际部署位置进行调整。
// ============================================================
const std::string FileManager::DATA_DIR = "data/";

// ============================================================
// 默认构造函数
// 使用默认的数据目录和文件名构造 FileManager 对象。
// 文件路径为：data/employees.dat
// 调用方也可以通过 setter 或带参构造函数自定义路径。
// ============================================================
FileManager::FileManager()
    : filePath(DATA_DIR + "employees.dat")  // 默认文件路径：data/employees.dat
{
    // 构造函数体为空——所有初始化已在初始化列表中完成
}

// ============================================================
// 带参构造函数
// 使用用户指定的文件路径构造 FileManager 对象。
// 参数：filePath —— 数据文件的完整或相对路径
// explicit 关键字防止隐式类型转换，避免 string 被误当作 FileManager 使用。
// ============================================================
FileManager::FileManager(const std::string& filePath)
    : filePath(filePath)  // 使用用户传入的文件路径
{
    // 构造函数体为空——所有初始化已在初始化列表中完成
}

// ============================================================
// saveAll —— 将所有员工数据保存到文件
//
// 功能说明：
//   遍历员工容器中的每一个员工对象，利用 C++ 的多态特性，
//   对每个员工调用其对应的 saveToFile() 方法，将数据写入文件。
//   由于 saveToFile() 是虚函数，无论容器中存储的是哪种具体类型
//   （FullTimeEmployee、PartTimeEmployee、Manager），
//   都会正确调用该类型的版本，写入包含该类型特有字段的完整数据行。
//
// 文件格式说明（CSV 风格，逗号分隔）：
//   每条员工记录占一行（独占一行），字段之间用逗号（,）分隔。
//   不同员工类型的具体字段格式如下：
//
//   正式员工（FullTimeEmployee）：
//     格式：正式员工,ID,姓名,基本工资,奖金
//     示例：正式员工,1000,张三,8000.00,2000.00
//
//   兼职员工（PartTimeEmployee）：
//     格式：兼职员工,ID,姓名,0,时薪,工作小时数
//     示例：兼职员工,1001,李四,0,50.00,80
//     注意：兼职员工无底薪，baseSalary 字段固定为 0
//
//   经理（Manager）：
//     格式：经理,ID,姓名,基本工资,部门,团队人数,绩效奖金
//     示例：经理,1002,王五,15000.00,技术部,10,5000.00
//
// 参数：
//   employees —— 包含所有员工 shared_ptr 的 vector 容器
// 返回：
//   true  —— 保存成功
//   false —— 保存失败（文件无法打开、写入过程中发生异常等）
// ============================================================
bool FileManager::saveAll(const std::vector<std::shared_ptr<Employee>>& employees) {
    // 尝试以输出模式打开文件（ios::out 表示写入模式，会覆盖已有内容）
    // 使用 std::ofstream 而不是 FILE*，因为 ofstream 是 RAII 类型，
    // 离开作用域时自动关闭文件，无需手动管理资源。
    std::ofstream outFile(filePath);

    // 检查文件是否成功打开
    if (!outFile.is_open()) {
        // 文件打开失败，向标准错误输出错误信息
        // 使用 std::cerr 而不是 std::cout，确保错误信息不受重定向影响
        std::cerr << "错误：无法打开文件进行写入：" << filePath << std::endl;
        return false;  // 返回 false 表示保存失败
    }

    // 使用 try-catch 块包裹写入逻辑，捕获可能发生的任何异常
    // 例如：磁盘空间不足、写入权限变更等不可预见的运行时错误
    try {
        // 遍历员工容器中的每一个员工对象
        for (const auto& emp : employees) {
            // 检查智能指针是否为空（理论上不应为空，但防御性编程是好的习惯）
            if (emp) {
                // 调用员工对象的 saveToFile() 方法写入数据到文件
                // 由于 saveToFile() 是虚函数，这里会发生动态绑定，
                // 自动调用具体派生类的版本，写入包含特有字段的数据。
                // 基类 Employee 的 saveToFile() 负责写入通用字段：
                //   getType() + "," + id + "," + name + "," + baseSalary
                // 派生类的 saveToFile() 负责追加特有字段和换行符。
                emp->saveToFile(outFile);
            }
        }

        // 所有数据已经成功写入，检查文件流状态
        if (outFile.good()) {
            return true;  // 文件流状态良好，返回 true 表示保存成功
        } else {
            // 文件流状态异常（如写入中断），输出错误信息
            std::cerr << "错误：写入文件过程中发生异常：" << filePath << std::endl;
            return false;  // 返回 false 表示保存失败
        }
    }
    // 捕获标准异常（如 std::bad_alloc 内存不足等）
    catch (const std::exception& e) {
        // 输出异常信息到标准错误
        std::cerr << "错误：保存文件时发生异常：" << e.what() << std::endl;
        return false;  // 返回 false 表示保存失败
    }
    // 捕获非标准异常（如未知错误）
    catch (...) {
        // 输出未知错误信息
        std::cerr << "错误：保存文件时发生未知异常。" << std::endl;
        return false;  // 返回 false 表示保存失败
    }
}

// ============================================================
// loadAll —— 从文件中加载所有员工数据
//
// 功能说明：
//   打开指定的数据文件，逐行读取内容。每行代表一个员工的所有数据，
//   字段之间用逗号（,）分隔。使用 split() 工具函数将每行分割成
//   字符串向量 fields，其中 fields[0] 是员工类型名称，
//   后续字段是具体数据。然后调用 createEmployee() 静态工厂方法，
//   根据类型和字段向量动态创建对应的派生类对象。
//
// 文件格式要求（与 saveAll 输出的格式一致）：
//   正式员工,1000,张三,8000.00,2000.00
//   兼职员工,1001,李四,0,50.00,80
//   经理,1002,王五,15000.00,技术部,10,5000.00
//
// 容错处理：
//   1. 如果文件不存在，返回空的 vector（非错误情况）
//   2. 如果某行数据格式不正确，跳过该行并输出警告
//   3. 如果某行的类型字符串无法识别，跳过该行并输出警告
//   4. 如果类型字符串匹配但字段数不足，跳过该行并输出警告
//
// 返回：
//   包含所有成功解析的员工对象的 shared_ptr 向量
//   如果文件为空或读取失败，返回空向量（不是 nullptr）
// ============================================================
std::vector<std::shared_ptr<Employee>> FileManager::loadAll() {
    // 创建空的员工容器，用于存储从文件加载的员工对象
    std::vector<std::shared_ptr<Employee>> employees;

    // 尝试以输入模式打开文件（ios::in 表示读取模式）
    std::ifstream inFile(filePath);

    // 检查文件是否成功打开
    if (!inFile.is_open()) {
        // 文件不存在或无法打开——这不是错误，可能是首次运行还没有数据文件
        // 直接返回空的员工容器，由上层调用方处理（例如展示空列表）
        return employees;
    }

    // 临时变量：存储从文件中读取的每一行文本
    std::string line;

    // 使用 std::getline 逐行读取文件内容
    // 当读到文件末尾（EOF）时，getline 返回 false，循环结束
    while (std::getline(inFile, line)) {
        // 跳过空行（文件中可能存在的空行或尾随换行符）
        if (line.empty()) {
            continue;
        }

        // 使用工具函数 split() 将当前行按逗号分隔成字段向量
        // 例如："正式员工,1000,张三,8000.00,2000.00"
        // 会被分割为：["正式员工", "1000", "张三", "8000.00", "2000.00"]
        std::vector<std::string> fields = split(line, ',');

        // 检查是否至少有一个字段（类型字段）
        // 如果 fields 为空，说明这一行是空行或格式错误
        if (fields.empty()) {
            continue;  // 跳过空行
        }

        // 提取第一个字段作为员工类型名称
        // 例如："正式员工"、"兼职员工"、"经理"
        const std::string& type = fields[0];

        // 根据类型验证最少字段数量
        // 不同员工类型至少需要的字段数不同：
        //   正式员工：类型 + id + name + baseSalary + bonus = 5 个字段
        //   兼职员工：类型 + id + name + baseSalary(0) + hourlyRate + hoursWorked = 6 个字段
        //   经理：类型 + id + name + baseSalary + department + teamSize + performanceBonus = 7 个字段
        size_t minFields = 0;  // 当前类型要求的最小字段数

        // 根据类型名称判断需要的最少字段数
        if (type == "正式员工") {
            minFields = 5;  // 类型 + id + name + baseSalary + bonus
        } else if (type == "兼职员工") {
            minFields = 6;  // 类型 + id + name + baseSalary + hourlyRate + hoursWorked
        } else if (type == "经理") {
            minFields = 7;  // 类型 + id + name + baseSalary + department + teamSize + performanceBonus
        } else {
            // 无法识别的员工类型，输出警告并跳过当前行
            std::cerr << "警告：无法识别的员工类型 \"" << type
                      << "\"，跳过该行：" << line << std::endl;
            continue;  // 继续读取下一行
        }

        // 检查当前行的字段数量是否满足该类型的最低要求
        if (fields.size() < minFields) {
            // 字段数不足，输出警告并跳过当前行
            std::cerr << "警告：字段数不足（需要 " << minFields
                      << " 个，实际 " << fields.size()
                      << " 个），跳过该行：" << line << std::endl;
            continue;  // 继续读取下一行
        }

        // 调用静态工厂方法创建对应的员工对象
        // createEmployee() 根据类型和字段向量构造具体的派生类对象
        // 并返回 shared_ptr<Employee>
        std::shared_ptr<Employee> emp = createEmployee(type, fields);

        // 检查 createEmployee 是否返回了有效的对象
        if (emp) {
            // 创建成功，将对象添加到员工容器中
            employees.push_back(emp);
        } else {
            // 创建失败（例如字段解析出错），输出警告并跳过当前行
            std::cerr << "警告：无法创建员工对象，跳过该行：" << line << std::endl;
        }
    }

    // 返回成功加载的所有员工对象
    return employees;
}

// ============================================================
// createEmployee —— 静态工厂方法
//
// 功能说明：
//   根据类型字符串和字段向量，动态创建对应的 Employee 派生类对象。
//   这是静态工厂方法模式（Static Factory Method）的典型应用：
//   通过一个静态方法集中管理所有员工对象的创建逻辑，外部调用方
//   无需关心具体的派生类名称和构造参数，只需提供类型标识和数据字段。
//
//   优点：
//   1. 封装变化：新增员工类型时只需修改此方法（添加一个 if-else 分支）
//   2. 统一入口：所有反序列化操作都通过此方法进行，便于维护
//   3. 解耦调用方：调用方只需处理字符串，不依赖具体的派生类头文件
//
// 参数说明：
//   type   —— 员工类型字符串，用于确定创建哪种派生类
//             取值范围："正式员工"、"兼职员工"、"经理"
//   fields —— 包含所有字段的字符串向量（第一个元素是类型本身）
//             fields[0] = type（类型）
//             fields[1] = id（员工编号）
//             fields[2] = name（员工姓名）
//             fields[3] = baseSalary（基本工资）
//             fields[4..] = 各派生类的特有字段（参见下面的详细说明）
//
// 字段映射（fields 索引从 0 开始计数）：
//
//   正式员工（FullTimeEmployee）：
//     fields[0] = "正式员工"     （类型，已通过 type 参数传入）
//     fields[1] = id            （员工编号，int）
//     fields[2] = name          （员工姓名，string）
//     fields[3] = baseSalary    （基本工资，double）
//     fields[4] = bonus         （奖金，double）
//     构造函数参数顺序：name, baseSalary, bonus
//
//   兼职员工（PartTimeEmployee）：
//     fields[0] = "兼职员工"     （类型）
//     fields[1] = id            （员工编号，int）
//     fields[2] = name          （员工姓名，string）
//     fields[3] = baseSalary    （基本工资，此处固定为 0）
//     fields[4] = hourlyRate    （时薪，double）
//     fields[5] = hoursWorked   （工作小时数，int）
//     构造函数参数顺序：name, hourlyRate, hoursWorked
//
//   经理（Manager）：
//     fields[0] = "经理"         （类型）
//     fields[1] = id            （员工编号，int）
//     fields[2] = name          （员工姓名，string）
//     fields[3] = baseSalary    （基本工资，double）
//     fields[4] = department    （部门名称，string）
//     fields[5] = teamSize      （团队人数，int）
//     fields[6] = performanceBonus（绩效奖金，double）
//     构造函数参数顺序：name, baseSalary, department, teamSize, performanceBonus
//
// 关于员工 ID 的特殊处理：
//   从文件读取时，fields[1] 存储了员工原有的 ID。
//   但是基类 Employee 的构造函数会自动分配 nextId++ 的新 ID。
//   为了保持从文件加载的员工 ID 不变，我们采用的策略是：
//   先创建对象（此时 ID 是 nextId 自动分配的），然后利用 Employee 的
//   id 是 protected 成员的特性——等等，id 是 protected 的，且没有 setter。
//   所以我们需要另一种方式：直接让构造函数接收 id 参数。
//
//   不过当前 Employee 的构造函数是 Employee(name, baseSalary)，
//   并不接收 id 参数。因此从文件加载后，员工的 ID 会重新分配，
//   而不是保持原文件中的 ID 值。
//
//   【改进建议】
//   如果需要保持文件中的 ID，可以在 Employee 类中添加一个
//   setter 方法 setId(int id)，或者在构造函数中增加一个
//   带 id 参数的重载版本。这里我们保持现有设计，不修改基类。
//
// 返回：
//   指向 Employee 派生类对象的 shared_ptr
//   如果类型无法识别或字段解析失败，返回 nullptr
// ============================================================
std::shared_ptr<Employee> FileManager::createEmployee(const std::string& type,
                                                       const std::vector<std::string>& fields) {
    // 使用 try-catch 块包裹创建逻辑，捕获可能发生的所有异常
    // 例如：std::stod 解析失败时抛出 std::invalid_argument
    //       或 std::out_of_range（数值超出 double 范围）
    try {
        // ============================================================
        // 分支 1：创建正式员工（FullTimeEmployee）
        // 需要的字段：id(忽略), name, baseSalary, bonus
        // ============================================================
        if (type == "正式员工") {
            // 检查字段数量是否足够（需要至少 5 个字段）
            if (fields.size() < 5) {
                // 字段数不足，返回 nullptr 表示创建失败
                return nullptr;
            }

            // 从 fields 向量中提取构造参数
            // fields[1] = id（员工编号，暂时忽略，因为 Employee 会自动分配新 ID）
            // fields[2] = name（员工姓名）
            // fields[3] = baseSalary（基本工资，从字符串转换为 double）
            // fields[4] = bonus（奖金，从字符串转换为 double）
            const std::string& name = fields[2];
            double baseSalary = std::stod(fields[3]);  // 将字符串转换为 double
            double bonus = std::stod(fields[4]);        // 将字符串转换为 double

            // 使用 make_shared 创建 FullTimeEmployee 对象
            // make_shared 比直接 new 更高效（一次内存分配代替两次）
            // 参数顺序对应 FullTimeEmployee 的构造函数：(name, baseSalary, bonus)
            return std::make_shared<FullTimeEmployee>(name, baseSalary, bonus);
        }

        // ============================================================
        // 分支 2：创建兼职员工（PartTimeEmployee）
        // 需要的字段：id(忽略), name, baseSalary(0), hourlyRate, hoursWorked
        // 注意：兼职员工没有底薪，baseSalary 固定为 0，但不从文件中读取
        // ============================================================
        else if (type == "兼职员工") {
            // 检查字段数量是否足够（需要至少 6 个字段）
            if (fields.size() < 6) {
                // 字段数不足，返回 nullptr 表示创建失败
                return nullptr;
            }

            // 从 fields 向量中提取构造参数
            // fields[1] = id（员工编号，暂时忽略）
            // fields[2] = name（员工姓名）
            // fields[3] = baseSalary（基本工资，兼职员工固定为 0，忽略此值）
            // fields[4] = hourlyRate（时薪，从字符串转换为 double）
            // fields[5] = hoursWorked（工作小时数，从字符串转换为 int）
            const std::string& name = fields[2];
            double hourlyRate = std::stod(fields[4]);  // 将字符串转换为 double
            int hoursWorked = std::stoi(fields[5]);     // 将字符串转换为 int

            // 使用 make_shared 创建 PartTimeEmployee 对象
            // 参数顺序对应 PartTimeEmployee 的构造函数：(name, hourlyRate, hoursWorked)
            // 注意：PartTimeEmployee 内部会将 baseSalary 设置为 0
            return std::make_shared<PartTimeEmployee>(name, hourlyRate, hoursWorked);
        }

        // ============================================================
        // 分支 3：创建经理（Manager）
        // 需要的字段：id(忽略), name, baseSalary, department, teamSize, performanceBonus
        // ============================================================
        else if (type == "经理") {
            // 检查字段数量是否足够（需要至少 7 个字段）
            if (fields.size() < 7) {
                // 字段数不足，返回 nullptr 表示创建失败
                return nullptr;
            }

            // 从 fields 向量中提取构造参数
            // fields[1] = id（员工编号，暂时忽略）
            // fields[2] = name（员工姓名）
            // fields[3] = baseSalary（基本工资，从字符串转换为 double）
            // fields[4] = department（部门名称）
            // fields[5] = teamSize（团队人数，从字符串转换为 int）
            // fields[6] = performanceBonus（绩效奖金，从字符串转换为 double）
            const std::string& name = fields[2];
            double baseSalary = std::stod(fields[3]);          // 将字符串转换为 double
            const std::string& department = fields[4];
            int teamSize = std::stoi(fields[5]);               // 将字符串转换为 int
            double performanceBonus = std::stod(fields[6]);    // 将字符串转换为 double

            // 使用 make_shared 创建 Manager 对象
            // 参数顺序对应 Manager 的构造函数：
            //   (name, baseSalary, department, teamSize, performanceBonus)
            return std::make_shared<Manager>(name, baseSalary, department,
                                              teamSize, performanceBonus);
        }

        // ============================================================
        // 分支 4：无法识别的员工类型
        // 如果 type 不是上述三种已知类型之一，返回 nullptr
        // ============================================================
        else {
            // 无法识别的类型，输出警告
            std::cerr << "警告：不支持的员工类型：" << type << std::endl;
            return nullptr;  // 返回空指针表示创建失败
        }
    }
    // ============================================================
    // 异常处理：捕获数值转换异常
    // std::stod 和 std::stoi 在无法转换时会抛出 std::invalid_argument
    // 或 std::out_of_range 异常
    // ============================================================
    catch (const std::invalid_argument& e) {
        // 字符串无法转换为数值（如 "abc" 无法转为 double）
        std::cerr << "错误：字段解析失败（无效的数字格式）：" << e.what() << std::endl;
        return nullptr;  // 返回空指针表示创建失败
    }
    catch (const std::out_of_range& e) {
        // 数值超出 double 或 int 的范围
        std::cerr << "错误：字段解析失败（数字超出范围）：" << e.what() << std::endl;
        return nullptr;  // 返回空指针表示创建失败
    }
    catch (const std::exception& e) {
        // 捕获其他标准异常
        std::cerr << "错误：创建员工对象时发生异常：" << e.what() << std::endl;
        return nullptr;  // 返回空指针表示创建失败
    }
    catch (...) {
        // 捕获非标准异常（兜底）
        std::cerr << "错误：创建员工对象时发生未知异常。" << std::endl;
        return nullptr;  // 返回空指针表示创建失败
    }
}

} // namespace ems
