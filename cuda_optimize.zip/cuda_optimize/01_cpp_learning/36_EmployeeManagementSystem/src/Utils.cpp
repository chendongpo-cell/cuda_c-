// ============================================================
// Utils.cpp —— 工具函数实现
// 实现 Utils.h 中声明的所有辅助函数
// ============================================================

#include "Utils.h"

// 使用 ems 命名空间
namespace ems {

// ============================================================
// getInput - 整数输入（带范围验证）
// 这个函数演示了：
// 1. 异常处理（try/catch）
// 2. 输入流状态检查（fail/clear/ignore）
// 3. 递归调用（输入无效时重新调用）
// 4. 条件循环（do-while）
// ============================================================
int getInput(const std::string& prompt, int min, int max) {
    // 定义一个变量存储用户输入的值
    int value = 0;
    // 标记输入是否有效
    bool valid = false;

    // 使用 do-while 循环，至少执行一次
    do {
        // 输出提示信息给用户
        // std::cout << prompt 会显示提示文字
        std::cout << prompt;
        // 从标准输入读取一个整数
        std::cin >> value;

        // 检查输入流是否出错（比如用户输入了字母而不是数字）
        if (std::cin.fail()) {
            // 输入的不是数字，清空错误状态标志
            std::cin.clear();
            // 忽略缓冲区中所有字符直到遇到换行符
            // std::numeric_limits<std::streamsize>::max() 表示"忽略无限个字符"
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            // 提示用户输入格式错误
            std::cout << "输入格式错误！请输入一个整数。" << std::endl;
        } else {
            // 清除输入缓冲区中剩余的字符（包括换行符）
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            // 检查输入的值是否在指定范围内
            if (value >= min && value <= max) {
                // 值有效，设置标志为 true，退出循环
                valid = true;
            } else {
                // 值超出范围，提示用户
                std::cout << "输入超出范围！请输入 " << min << " 到 " << max << " 之间的值。" << std::endl;
            }
        }
    } while (!valid);  // 当输入无效时继续循环

    // 返回验证通过的用户输入
    return value;
}

// ============================================================
// getInput - 浮点数输入（重载版本）
// 与整数版本逻辑相同，但处理 double 类型
// ============================================================
double getInput(const std::string& prompt, double min, double max) {
    double value = 0.0;
    bool valid = false;

    do {
        std::cout << prompt;
        std::cin >> value;

        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "输入格式错误！请输入一个数字。" << std::endl;
        } else {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            if (value >= min && value <= max) {
                valid = true;
            } else {
                std::cout << "输入超出范围！请输入 " << min << " 到 " << max << " 之间的值。" << std::endl;
            }
        }
    } while (!valid);

    return value;
}

// ============================================================
// getInput - 字符串输入（重载版本）
// 使用 getline 读取一行，可以包含空格
// ============================================================
std::string getInput(const std::string& prompt) {
    // 定义字符串变量存储用户输入
    std::string input;

    // 无限循环，直到输入合法才 break 退出
    while (true) {
        std::cout << prompt;
        // 使用 getline 读取一整行（包括中间的空格）
        std::getline(std::cin, input);

        // 去除输入字符串首尾的空白字符
        input = trim(input);

        // 检查输入是否为空
        if (input.empty()) {
            std::cout << "输入不能为空，请重新输入。" << std::endl;
        } else {
            // 输入有效，退出循环
            break;
        }
    }

    return input;
}

// ============================================================
// getChar - 读取单个字符输入
// ============================================================
char getChar(const std::string& prompt) {
    std::string input = getInput(prompt);
    // 返回第一个字符
    return input.empty() ? '\n' : input[0];
}

// ============================================================
// formatSalary - 格式化工资为货币格式
// 使用 stringstream 进行格式化，展示 C++ 的格式化能力
// ============================================================
std::string formatSalary(double salary) {
    // 创建字符串流对象，用于构建格式化后的字符串
    std::ostringstream oss;
    // 设置固定小数位数为 2 位
    oss << std::fixed << std::setprecision(2) << salary;
    return oss.str();
}

// ============================================================
// fmtTime - 获取当前时间的字符串表示
// 使用 C 标准库的 time 函数，展示 C/C++ 混合编程
// ============================================================
std::string fmtTime() {
    // 获取当前时间戳（从 1970-01-01 到现在的秒数）
    std::time_t now = std::time(nullptr);
    // 将时间戳转换为本地时间的结构体
    std::tm* localTime = std::localtime(&now);

    // 创建字符数组存储格式化后的时间字符串
    char buffer[20];
    // 使用 strftime 格式化时间为 "YYYY-MM-DD HH:MM:SS" 格式
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localTime);

    return std::string(buffer);
}

// ============================================================
// split - 字符串分割函数
// 使用 stringstream 逐词读取，按分隔符分割
// ============================================================
std::vector<std::string> split(const std::string& str, char delimiter) {
    // 创建字符串流，将 str 的内容放入流中
    std::istringstream stream(str);
    // 创建字符串向量，存储分割后的结果
    std::vector<std::string> result;
    // 临时变量，存储每次读取到的片段
    std::string segment;

    // 使用 getline 从流中读取，直到遇到分隔符
    // 第三个参数指定分隔符
    while (std::getline(stream, segment, delimiter)) {
        // 将分割出的片段添加到结果向量中
        result.push_back(segment);
    }

    return result;
}

// ============================================================
// trim - 去除字符串首尾空白
// 演示 STL 算法和字符串操作
// ============================================================
std::string trim(const std::string& str) {
    // 如果字符串为空，直接返回
    if (str.empty()) {
        return str;
    }

    // find_first_not_of: 找到第一个不是空白字符的位置
    // " \t\n\r\f\v" 包含所有常见的空白字符
    size_t start = str.find_first_not_of(" \t\n\r\f\v");
    // 如果全是空白字符，返回空字符串
    if (start == std::string::npos) {
        return "";
    }

    // find_last_not_of: 找到最后一个不是空白字符的位置
    size_t end = str.find_last_not_of(" \t\n\r\f\v");

    // 使用 substr 截取去除首尾空白后的子串
    // end - start + 1 计算有效字符的长度
    return str.substr(start, end - start + 1);
}

// ============================================================
// printHeader - 打印带边框的标题
// ============================================================
void printHeader(const std::string& title, int width) {
    // 打印顶部边框线
    printSeparator('=', width);

    // 计算标题居中需要的空格数
    // 标题长度可能包含中文字符，这里简化处理
    int padding = (width - static_cast<int>(title.length()) - 2) / 2;
    if (padding < 0) padding = 0;

    // 打印标题行（居中）
    std::cout << "=";
    for (int i = 0; i < padding; ++i) std::cout << " ";
    std::cout << title;
    for (int i = 0; i < padding; ++i) std::cout << " ";
    // 如果宽度减去标题和两边空格后还有余数，在右边补一个空格
    if ((width - static_cast<int>(title.length()) - 2) % 2 != 0) {
        std::cout << " ";
    }
    std::cout << "=" << std::endl;

    // 打印底部边框线
    printSeparator('=', width);
}

// ============================================================
// printSeparator - 打印分隔线
// ============================================================
void printSeparator(char ch, int width) {
    // 循环输出指定数量的分隔符字符
    for (int i = 0; i < width; ++i) {
        std::cout << ch;
    }
    // 输出换行
    std::cout << std::endl;
}

// ============================================================
// waitForEnter - 暂停等待回车
// ============================================================
void waitForEnter() {
    std::cout << "按回车键继续...";
    // 读取输入但忽略内容，只等待用户按回车
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    // 如果输入缓冲区中还有换行符，getline 会直接读取到
    // 所以这里使用 ignore 来确保清除缓冲区
    std::cin.get();
}

} // namespace ems
