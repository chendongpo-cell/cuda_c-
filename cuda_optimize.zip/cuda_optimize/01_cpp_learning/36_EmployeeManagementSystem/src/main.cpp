// ============================================================
// main.cpp —— 员工管理系统的主入口文件
//
// 本文件是整个 EMS（Employee Management System）的入口点，
// 提供一个交互式控制台菜单，让用户通过键盘输入来管理员工数据。
// 菜单选项涵盖：添加、删除、更新、查询、显示、排序、统计、
// 文件保存/加载等完整功能。
//
// 融合的知识点（对应前面35课）：
//   基础语法：变量、运算符、流程控制(switch/while)、数组
//   函数：函数定义与调用、参数传递
//   面向对象：类与对象、继承、多态、封装、抽象基类
//   运算符重载：operator<<（Employee 基类中的友元函数）
//   模板：std::vector、std::map、std::shared_ptr
//   STL 容器：vector、map、string
//   STL 算法：std::find_if、std::sort（在 EmployeeManager 中）
//   智能指针：std::shared_ptr
//   文件操作：ifstream/ofstream（FileManager 中）
//   异常处理：try/catch（FileManager 中）
//   Lambda 表达式：displayByType、sortBySalary（EmployeeManager 中）
//   命名空间：namespace ems
//   静态成员：Employee::nextId 自增计数
//   const 成员函数：calcSalary() const、displayInfo() const
//   override 关键字：派生类重写虚函数
//   范围 for 循环：C++11 range-based for
//   auto 类型推导
// ============================================================

// ============================================================
// 包含头文件
// EmployeeManager 包含了所有员工管理业务逻辑
// Utils 包含了输入验证、格式化等工具函数
// 所有具体的员工类（FullTimeEmployee、Manager 等）在函数体内
// 通过 EmployeeManager 的方法间接使用，无需直接包含它们的头文件。
// ============================================================
#include "EmployeeManager.h"   // 员工管理器类，封装所有增删改查和持久化操作
#include "FullTimeEmployee.h"  // 正式员工类，在添加员工时需要构造具体派生类对象
#include "PartTimeEmployee.h"  // 兼职员工类，在添加员工时需要构造具体派生类对象
#include "Manager.h"           // 经理类，在添加员工时需要构造具体派生类对象
#include "Utils.h"             // 工具函数：getInput（整数/浮点数/字符串）、
                               //          printHeader、printSeparator、
                               //          waitForEnter、formatSalary、fmtTime

#include <iostream>            // std::cin / std::cout，控制台输入输出
#include <cstdlib>             // system("cls") 或 system("clear")，清屏
#include <string>              // std::string，字符串类型

// ============================================================
// 使用 ems 命名空间
// 项目中的所有类（Employee、EmployeeManager、FileManager、Utils 函数）
// 都在 namespace ems 中定义，此处 using 整个命名空间后，后续代码
// 可以直接使用类名和函数名，无需写 ems:: 前缀。
// ============================================================
using namespace ems;
using namespace std;            // 使用标准命名空间，省略 std:: 前缀

// ============================================================
// clearScreen —— 清屏函数
// 跨平台实现：Windows 使用 system("cls")，
// Linux/macOS 使用 system("clear")。
// 注意：system() 是调用操作系统的命令行命令来实现清屏，
// 虽然简单有效，但在生产代码中应尽量少用 system()。
// ============================================================
void clearScreen() {
#ifdef _WIN32                   // 如果定义了 _WIN32 宏（Windows 平台）
    system("cls");              // 调用 Windows 的 cls 清屏命令
#else                           // 其他平台（Linux / macOS）
    system("clear");            // 调用 Unix 的 clear 清屏命令
#endif
}

// ============================================================
// pauseAndContinue —— 暂停程序，等待用户按键后继续
// 在显示大量信息后使用，防止输出一闪而过用户来不及阅读。
// 调用 Utils 中的 waitForEnter() 函数来实现等待。
// ============================================================
void pauseAndContinue() {
    // 输出提示信息，告诉用户按回车继续
    cout << endl << "按回车键继续...";
    // 忽略输入缓冲区中的所有内容，直到遇到换行符
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    // 等待用户按下回车键
    cin.get();
}

// ============================================================
// addEmployeeMenu —— 添加员工子菜单
//
// 功能：让用户选择要添加的员工类型（1-正式员工、2-兼职员工、3-经理），
// 然后根据不同类型提示用户输入相应的字段数据，
// 构造对应的派生类对象并添加到员工管理器中。
//
// 涉及知识点：
//   1. 多态：通过基类指针（shared_ptr<Employee>）管理派生类对象
//   2. 智能指针：std::make_shared 创建共享指针
//   3. 输入验证：Utils::getInput 确保用户输入合法数据
//   4. 函数重载：getInput 的三个重载版本（int、double、string）
//
// 参数：
//   manager —— EmployeeManager 的引用，用于添加员工
//
// 返回值：void
// ============================================================
void addEmployeeMenu(EmployeeManager& manager) {
    // 步骤一：提示用户选择员工类型
    // 显示三种员工类型的编号，让用户选择
    cout << "\n请选择员工类型：" << endl;
    cout << "  1. 正式员工（FullTimeEmployee）" << endl;  // 选项1：正式员工
    cout << "  2. 兼职员工（PartTimeEmployee）" << endl;  // 选项2：兼职员工
    cout << "  3. 经理（Manager）" << endl;                 // 选项3：经理

    // 步骤二：读取用户选择（1~3 之间的整数）
    // getInput 函数带有范围验证，确保用户输入 1、2 或 3
    int choice = getInput("请输入选择 (1-3): ", 1, 3);

    // 步骤三：读取所有员工类型都需要的公共字段
    // 员工姓名（字符串）：getInput 的 string 重载版本
    string name = getInput("请输入员工姓名: ");
    // 基本工资（浮点数）：getInput 的 double 重载版本，范围 0.0 ~ 1000000.0
    double baseSalary = getInput("请输入基本工资: ", 0.0, 1000000.0);

    // 步骤四：根据用户选择构造不同类型的员工对象
    // 使用 shared_ptr<Employee> 基类指针来存储派生类对象
    // 这是多态的核心用法：通过基类指针操作派生类对象
    shared_ptr<Employee> emp;   // 声明基类类型的智能指针

    // 步骤五：根据用户选择，构造具体的派生类对象
    switch (choice) {
        case 1: {  // ======== 正式员工 ========
            // 提示用户输入正式员工特有的字段：奖金
            cout << "--- 正式员工特有字段 ---" << endl;
            // 读取奖金金额，范围 0.0 ~ 1000000.0
            double bonus = getInput("请输入奖金: ", 0.0, 1000000.0);

            // 使用 make_shared 构造 FullTimeEmployee 对象
            // make_shared 比 new 更高效（一次内存分配）
            // 构造参数：name, baseSalary, bonus
            emp = make_shared<FullTimeEmployee>(name, baseSalary, bonus);
            break;
        }

        case 2: {  // ======== 兼职员工 ========
            // 提示用户输入兼职员工特有的字段：时薪和工作小时数
            cout << "--- 兼职员工特有字段 ---" << endl;
            // 读取时薪，范围 0.0 ~ 1000.0
            double hourlyRate = getInput("请输入时薪: ", 0.0, 1000.0);
            // 读取工作小时数，范围 0 ~ 744（31天 * 24小时）
            int hoursWorked = getInput("请输入工作小时数: ", 0, 744);

            // 使用 make_shared 构造 PartTimeEmployee 对象
            // 注意：兼职员工没有基本工资，构造函数中 baseSalary 固定为 0
            // 构造参数：name, hourlyRate, hoursWorked
            emp = make_shared<PartTimeEmployee>(name, hourlyRate, hoursWorked);
            break;
        }

        case 3: {  // ======== 经理 ========
            // 提示用户输入经理特有的字段：部门、团队人数、绩效奖金
            cout << "--- 经理特有字段 ---" << endl;
            // 读取部门名称（字符串）
            string department = getInput("请输入部门: ");
            // 读取团队人数，范围 0 ~ 10000
            int teamSize = getInput("请输入团队人数: ", 0, 10000);
            // 读取绩效奖金，范围 0.0 ~ 1000000.0
            double performanceBonus = getInput("请输入绩效奖金: ", 0.0, 1000000.0);

            // 使用 make_shared 构造 Manager 对象
            // 构造参数：name, baseSalary, department, teamSize, performanceBonus
            emp = make_shared<Manager>(name, baseSalary, department,
                                       teamSize, performanceBonus);
            break;
        }
    }

    // 步骤六：将构造好的员工对象添加到管理器中
    // addEmployee 会更新 employees 向量和 employeeIndex 索引
    manager.addEmployee(emp);

    // 步骤七：输出成功信息
    cout << "✅ 员工添加成功！员工编号: " << emp->getId() << endl;
}

// ============================================================
// main —— 程序入口点
//
// 功能：创建 EmployeeManager 对象，进入主循环显示菜单，
//       根据用户的选择执行相应操作，直到用户选择退出。
//
// 主循环结构：
//   1. 清屏
//   2. 显示菜单选项
//   3. 读取用户选择
//   4. 根据选择执行对应的功能
//   5. 重复直到用户选择退出（选项 0）
//
// 涉及知识点：
//   1. do-while 循环：保证至少执行一次菜单显示
//   2. switch 语句：多分支选择
//   3. 作用域：case 语句中的 {} 块作用域
//   4. 函数调用：将不同功能拆分到独立的逻辑块中
//
// 返回值：
//   0 —— 正常退出
// ============================================================
int main() {
    // 步骤一：创建员工管理器对象
    // EmployeeManager 是系统的核心业务类，管理所有员工的生命周期
    // 包括：添加、删除、更新、查询、显示、统计、排序、文件操作
    EmployeeManager manager;

    // 步骤二：尝试从文件加载已有数据
    // 如果文件存在且格式正确，会将文件中的员工数据加载到管理器中；
    // 如果文件不存在（首次运行），loadFromFile 返回空，程序正常启动。
    cout << "正在加载员工数据..." << endl;
    manager.loadFromFile();
    cout << "加载完成！当前员工数量: " << manager.getCount() << endl;
    pauseAndContinue();

    // 步骤三：进入主菜单循环
    // 使用 while(true) 无限循环，直到用户选择退出（选项 0）时 break
    while (true) {
        // 每次显示菜单前先清屏，让界面更干净
        clearScreen();

        // ============================================================
        // 显示主菜单标题
        // printHeader 是 Utils 中的工具函数，输出带边框的标题
        // ============================================================
        printHeader("员工管理系统 v1.0", 56);

        // ============================================================
        // 显示菜单选项列表
        // 每个选项对应一个功能编号，用户输入编号后执行相应功能
        // ============================================================
        cout << "  ╔═══════════════════════════════════════════╗" << endl;
        cout << "  ║          请选择要执行的操作              ║" << endl;
        cout << "  ╠═══════════════════════════════════════════╣" << endl;
        cout << "  ║  1. 添加员工                             ║" << endl;
        cout << "  ║  2. 删除员工                             ║" << endl;
        cout << "  ║  3. 修改员工                             ║" << endl;
        cout << "  ║  4. 查询员工（按编号）                   ║" << endl;
        cout << "  ║  5. 查询员工（按姓名）                   ║" << endl;
        cout << "  ║  6. 显示所有员工                         ║" << endl;
        cout << "  ║  7. 按类型显示员工                       ║" << endl;
        cout << "  ║  8. 按工资排序（降序）                   ║" << endl;
        cout << "  ║  9. 工资统计                             ║" << endl;
        cout << "  ║  10. 保存到文件                          ║" << endl;
        cout << "  ║  11. 从文件加载                          ║" << endl;
        cout << "  ║  0. 退出系统                             ║" << endl;
        cout << "  ╚═══════════════════════════════════════════╝" << endl;

        // ============================================================
        // 读取用户的选择
        // getInput 是 Utils 中的重载函数，整数版本带范围验证
        // 用户只能输入 0 ~ 11 之间的整数
        // ============================================================
        int choice = getInput("请输入您的选择 (0-11): ", 0, 11);

        // ============================================================
        // 根据用户选择执行不同的功能
        // 使用 switch 语句实现多分支跳转，比 if-else 链更清晰
        // 每个 case 分支使用 {} 创建独立作用域，避免变量名冲突
        // ============================================================
        switch (choice) {
            // ============================================================
            // 案例 1：添加员工
            // 调用 addEmployeeMenu 子菜单，让用户选择类型并输入数据
            // ============================================================
            case 1: {
                clearScreen();
                printHeader("添加员工", 40);
                addEmployeeMenu(manager);
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 2：删除员工
            // 根据员工编号从系统中移除指定的员工
            // EmployeeManager::removeEmployee 返回 bool 表示是否成功
            // ============================================================
            case 2: {
                clearScreen();
                printHeader("删除员工", 40);

                // 检查是否有员工可以删除
                if (manager.getCount() == 0) {
                    cout << "当前没有员工，无法执行删除操作。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 提示用户输入要删除的员工编号
                int id = getInput("请输入要删除的员工编号: ", 1000, 9999);

                // 调用 EmployeeManager 的 removeEmployee 方法删除员工
                // 该方法会从 employees 向量中移除元素并重建 employeeIndex 索引
                if (manager.removeEmployee(id)) {
                    cout << "员工编号 " << id << " 已成功删除！" << endl;
                } else {
                    cout << "未找到编号为 " << id << " 的员工。" << endl;
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 3：修改员工信息
            // 根据员工编号查找员工，然后更新其姓名和基本工资
            // EmployeeManager::updateEmployee 接受 ID、新姓名、新工资
            // ============================================================
            case 3: {
                clearScreen();
                printHeader("修改员工信息", 40);

                // 检查是否有员工可以修改
                if (manager.getCount() == 0) {
                    cout << "当前没有员工，无法执行修改操作。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 提示用户输入要修改的员工编号
                int id = getInput("请输入要修改的员工编号: ", 1000, 9999);

                // 先查找员工是否存在
                auto emp = manager.findById(id);
                if (emp == nullptr) {
                    cout << "未找到编号为 " << id << " 的员工。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 显示当前员工信息（利用多态调用正确的 displayInfo）
                cout << "\n当前员工信息：" << endl;
                emp->displayInfo();

                // 提示用户输入新的姓名和基本工资
                cout << "\n请输入新的信息：" << endl;
                string newName = getInput("新姓名: ");
                double newSalary = getInput("新基本工资: ", 0.0, 1000000.0);

                // 调用 updateEmployee 更新员工信息
                if (manager.updateEmployee(id, newName, newSalary)) {
                    cout << "员工信息更新成功！" << endl;
                    // 显示更新后的信息
                    cout << "\n更新后的员工信息：" << endl;
                    emp->displayInfo();
                } else {
                    cout << "员工信息更新失败！" << endl;
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 4：按编号查询员工
            // 利用 EmployeeManager::findById 方法，基于 map 索引实现
            // O(log n) 时间复杂度的快速查找
            // ============================================================
            case 4: {
                clearScreen();
                printHeader("查询员工（按编号）", 40);

                // 检查是否有员工可以查询
                if (manager.getCount() == 0) {
                    cout << "当前没有员工。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 提示用户输入要查询的员工编号
                int id = getInput("请输入要查询的员工编号: ", 1000, 9999);

                // 通过 findById 查找员工（使用 map 索引，O(log n)）
                auto emp = manager.findById(id);
                if (emp) {
                    // 找到员工：利用多态调用正确的 displayInfo 方法
                    cout << "\n查询结果：" << endl;
                    emp->displayInfo();
                } else {
                    cout << "未找到编号为 " << id << " 的员工。" << endl;
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 5：按姓名查询员工（模糊匹配）
            // 使用 EmployeeManager::findByName 方法，支持大小写不敏感的
            // 部分匹配（输入"张"可以查到"张三"、"张伟"等）
            // ============================================================
            case 5: {
                clearScreen();
                printHeader("查询员工（按姓名）", 40);

                // 检查是否有员工可以查询
                if (manager.getCount() == 0) {
                    cout << "当前没有员工。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 提示用户输入要查询的姓名关键字
                string name = getInput("请输入要查询的姓名（支持模糊匹配）: ");

                // 通过 findByName 进行模糊查找（遍历 vector，大小写不敏感）
                auto results = manager.findByName(name);
                if (results.empty()) {
                    cout << "未找到姓名中包含 \"" << name << "\" 的员工。" << endl;
                } else {
                    // 显示查询到的员工数量
                    cout << "\n找到 " << results.size() << " 名员工：" << endl;
                    // 遍历结果列表，利用多态正确显示每个员工
                    for (const auto& emp : results) {
                        emp->displayInfo();
                        cout << "------------------------" << endl;
                    }
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 6：显示所有员工
            // 遍历 employees 向量，利用多态调用每个员工的 displayInfo()
            // 不同类型的员工会显示不同的信息格式
            // ============================================================
            case 6: {
                clearScreen();
                printHeader("所有员工信息", 48);

                // 检查是否有员工可以显示
                if (manager.getCount() == 0) {
                    cout << "当前没有员工，请先添加员工。" << endl;
                } else {
                    // 调用 displayAll 方法显示全部员工
                    // 内部使用 range-based for 循环遍历
                    // 利用多态：每个员工调用自己类型的 displayInfo()
                    cout << "当前员工总数: " << manager.getCount() << endl;
                    cout << "========================================" << endl;
                    manager.displayAll();
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 7：按类型显示员工
            // 使用 Lambda 表达式作为过滤条件，仅显示指定类型的员工
            // 选项包括：1-正式员工、2-兼职员工、3-经理
            // ============================================================
            case 7: {
                clearScreen();
                printHeader("按类型显示员工", 40);

                // 检查是否有员工可以显示
                if (manager.getCount() == 0) {
                    cout << "当前没有员工。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 让用户选择要显示的员工类型
                cout << "请选择要显示的员工类型：" << endl;
                cout << "  1. 正式员工（FullTimeEmployee）" << endl;
                cout << "  2. 兼职员工（PartTimeEmployee）" << endl;
                cout << "  3. 经理（Manager）" << endl;
                int typeChoice = getInput("请输入选择 (1-3): ", 1, 3);

                // 根据用户选择确定类型字符串
                // 这个字符串会传递给 displayByType 方法，
                // 方法内部使用 Lambda 表达式进行过滤：
                //   auto typeFilter = [&type](const auto& emp) {
                //       return emp->getType() == type;
                //   };
                string typeStr;
                switch (typeChoice) {
                    case 1:  typeStr = "正式员工"; break;
                    case 2:  typeStr = "兼职员工"; break;
                    case 3:  typeStr = "经理";     break;
                }

                // 调用 displayByType 方法，传入类型字符串
                // 内部使用 Lambda 表达式的 filter 进行过滤显示
                cout << endl;
                manager.displayByType(typeStr);
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 8：按工资排序（降序）
            // 使用 std::sort 配合 Lambda 表达式作为比较函数
            // 排序后调用 rebuildIndex 重建 map 索引
            // 排序完自动显示所有员工，展示排序效果
            // ============================================================
            case 8: {
                clearScreen();
                printHeader("按工资排序（降序）", 40);

                if (manager.getCount() == 0) {
                    cout << "当前没有员工，无法执行排序操作。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 调用 sortBySalary 方法进行降序排列
                // 内部使用 std::sort 和 Lambda：
                //   std::sort(employees.begin(), employees.end(),
                //       [](const auto& a, const auto& b) {
                //           return a->calcSalary() > b->calcSalary();
                //       });
                manager.sortBySalary();
                cout << "排序完成！按工资从高到低排列如下：" << endl;
                cout << "========================================" << endl;

                // 获取排序后的所有员工并显示
                const auto& all = manager.getAll();
                for (size_t i = 0; i < all.size(); ++i) {
                    // 显示排名、员工姓名、类型和工资
                    cout << "第 " << (i + 1) << " 名: "
                         << all[i]->getName() << " ("
                         << all[i]->getType() << ") —— "
                         << formatSalary(all[i]->calcSalary()) << " 元" << endl;
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 9：工资统计
            // 显示所有员工的总工资、平均工资、最高工资及对应员工信息
            // ============================================================
            case 9: {
                clearScreen();
                printHeader("工资统计", 40);

                if (manager.getCount() == 0) {
                    cout << "当前没有员工，无法进行工资统计。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 总工资：累加所有员工的 calcSalary() 返回值
                double total = manager.getTotalSalary();
                // 平均工资：总工资 / 员工数量
                double average = manager.getAverageSalary();
                // 最高工资员工：遍历比较所有员工的 calcSalary() 返回值
                auto highest = manager.getHighestPaid();

                // 使用 formatSalary 格式化工资为两位小数字符串
                cout << "员工总人数: " << manager.getCount() << " 人" << endl;
                cout << "工资总额:   " << formatSalary(total) << " 元" << endl;
                cout << "平均工资:   " << formatSalary(average) << " 元" << endl;

                // 显示最高工资员工信息
                if (highest) {
                    cout << "\n工资最高的员工：" << endl;
                    cout << "  姓名: " << highest->getName() << endl;
                    cout << "  类型: " << highest->getType() << endl;
                    cout << "  工资: " << formatSalary(highest->calcSalary()) << " 元" << endl;
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 10：保存到文件
            // 将当前所有员工数据持久化到 data/employees.dat 文件
            // 使用 FileManager::saveAll 方法，利用多态 saveToFile 写入
            // ============================================================
            case 10: {
                clearScreen();
                printHeader("保存到文件", 40);

                if (manager.getCount() == 0) {
                    cout << "当前没有员工，无需保存。" << endl;
                    pauseAndContinue();
                    break;
                }

                // 调用 saveToFile 保存数据到文件
                // 内部会遍历 employees 向量，对每个员工调用其 saveToFile()
                // 文件会保存在 data/employees.dat
                if (manager.saveToFile()) {
                    cout << "数据保存成功！已保存 "
                         << manager.getCount() << " 名员工到文件。" << endl;
                    cout << "保存时间: " << fmtTime() << endl;
                } else {
                    cout << "数据保存失败！请检查文件权限和磁盘空间。" << endl;
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 11：从文件加载
            // 从 data/employees.dat 文件读取员工数据并加载到管理器中
            // 使用 FileManager::loadAll 方法，利用工厂方法 createEmployee
            // 根据类型字符串构造对应的派生类对象
            // ============================================================
            case 11: {
                clearScreen();
                printHeader("从文件加载", 40);

                // 调用 loadFromFile 从文件加载数据
                if (manager.loadFromFile()) {
                    cout << "数据加载成功！当前员工数量: "
                         << manager.getCount() << " 人" << endl;
                    cout << "加载时间: " << fmtTime() << endl;
                } else {
                    cout << "数据加载失败！文件可能不存在或格式错误。" << endl;
                }
                pauseAndContinue();
                break;
            }

            // ============================================================
            // 案例 0：退出系统
            // 退出前提示用户保存数据（防止数据丢失）
            // ============================================================
            case 0: {
                clearScreen();
                printHeader("退出系统", 40);

                // 如果还有员工数据未保存，提示用户
                if (manager.getCount() > 0) {
                    cout << "当前还有 " << manager.getCount()
                         << " 名员工未保存。" << endl;
                    cout << "是否保存后再退出？(y/n): ";

                    // 读取用户选择
                    string saveChoice;
                    getline(cin, saveChoice);
                    if (!saveChoice.empty() &&
                        (saveChoice[0] == 'y' || saveChoice[0] == 'Y')) {
                        // 用户选择保存
                        if (manager.saveToFile()) {
                            cout << "数据保存成功！" << endl;
                        } else {
                            cout << "数据保存失败！" << endl;
                        }
                    }
                }

                // 显示退出信息
                cout << "\n感谢使用员工管理系统！" << endl;
                cout << "再见！" << endl;

                // 退出程序，返回 0 表示正常结束
                return 0;
            }

            // ============================================================
            // 默认分支：处理意外的输入
            // 虽然已经在 getInput 中限制了输入范围 0-11，
            // 但保留 default 分支是一种良好的编程习惯
            // ============================================================
            default:
                // 提示用户输入无效（理论上不会执行到这里）
                cout << "无效的选择，请重新输入。" << endl;
                pauseAndContinue();
                break;
        }
    }

    // 程序正常结束，返回 0
    return 0;
}
