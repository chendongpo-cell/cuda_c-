#include <iostream>     // 标准输入输出流库，用于控制台输出
#include <cstring>      // C 风格字符串操作库，用于 memcpy、strlen 等
#include <vector>       // 向量容器库，用于演示移动语义在容器中的效果
#include <chrono>       // 时间库，用于测量性能差异
#include <utility>      // 工具库，提供 std::move 和 std::forward

// ========== MyString 类：演示深拷贝 vs 移动语义 ==========

// MyString 是一个自定义的字符串类，用于演示拷贝构造（深拷贝）和移动构造（资源转移）的区别
class MyString {
private:
    char* data_;        // 指向动态分配的 C 风格字符串的指针
    size_t size_;       // 字符串的长度（不包括末尾的 '\0'）

public:
    // ========== 1. 普通构造函数 ==========

    // 接受 C 风格字符串的构造函数
    // 分配内存并拷贝字符串内容
    explicit MyString(const char* str) {
        // 计算源字符串的长度（不包括 '\0'）
        size_ = std::strlen(str);
        // 动态分配内存，多分配一个字节用于存储 '\0'
        data_ = new char[size_ + 1];
        // 拷贝字符串内容到新分配的内存中
        std::memcpy(data_, str, size_ + 1);
        // 输出调试信息，让用户看到构造函数被调用
        std::cout << "  [构造函数] 分配了 " << size_ + 1 << " 字节，内容: " << data_ << std::endl;
    }

    // ========== 2. 拷贝构造函数（深拷贝）==========

    // 拷贝构造函数：创建源对象的一个完整副本
    // 这是深拷贝——需要分配新的内存并拷贝所有数据
    MyString(const MyString& other) {
        // 获取源对象的大小
        size_ = other.size_;
        // 分配新的内存
        data_ = new char[size_ + 1];
        // 深拷贝：将源对象的数据完整复制到新内存中
        std::memcpy(data_, other.data_, size_ + 1);
        // 输出调试信息
        std::cout << "  [拷贝构造] 深拷贝，分配了 " << size_ + 1 << " 字节，内容: " << data_ << std::endl;
    }

    // ========== 3. 移动构造函数（资源转移）==========

    // 移动构造函数：从源对象"偷取"资源，而不是拷贝
    // noexcept 告诉编译器这个函数不会抛异常，使标准库容器能优先使用移动而非拷贝
    MyString(MyString&& other) noexcept {
        // 直接偷取源对象的资源（指针和大小）
        data_ = other.data_;   // 偷取指针，不分配新内存
        size_ = other.size_;   // 偷取大小

        // 将源对象置为空状态（有效但未定义的状态）
        other.data_ = nullptr; // 防止源对象析构时释放我们刚偷来的内存
        other.size_ = 0;

        // 输出调试信息
        std::cout << "  [移动构造] 转移了资源，未分配新内存，内容: " << (data_ ? data_ : "null") << std::endl;
    }

    // ========== 4. 拷贝赋值运算符 ==========

    // 拷贝赋值：释放当前资源，然后深拷贝源对象的数据
    MyString& operator=(const MyString& other) {
        std::cout << "  [拷贝赋值] 深拷贝赋值" << std::endl;
        if (this != &other) {              // 自我赋值检查
            delete[] data_;                // 释放当前持有的资源
            size_ = other.size_;           // 复制大小
            data_ = new char[size_ + 1];   // 分配新内存
            std::memcpy(data_, other.data_, size_ + 1);  // 深拷贝数据
        }
        return *this;  // 返回自身引用，支持链式赋值
    }

    // ========== 5. 移动赋值运算符 ==========

    // 移动赋值：释放当前资源，然后从源对象偷取资源
    MyString& operator=(MyString&& other) noexcept {
        std::cout << "  [移动赋值] 转移资源" << std::endl;
        if (this != &other) {              // 自我赋值检查
            delete[] data_;                // 释放当前持有的资源
            data_ = other.data_;           // 偷取源对象的指针
            size_ = other.size_;           // 偷取源对象的大小
            other.data_ = nullptr;         // 将源对象置空
            other.size_ = 0;
        }
        return *this;  // 返回自身引用
    }

    // ========== 6. 析构函数 ==========

    // 析构函数：释放动态分配的内存
    ~MyString() {
        // 输出析构信息（使用 (void*) 以安全地打印指针地址）
        std::cout << "  [析构函数] 释放内存，data_ = " << (void*)data_;
        if (data_) {
            std::cout << ", 内容: " << data_;
        } else {
            std::cout << ", 内容: (null)";
        }
        std::cout << std::endl;
        // 释放动态分配的内存
        delete[] data_;
    }

    // ========== 辅助方法 ==========

    // 获取字符串内容
    const char* c_str() const {
        return data_ ? data_ : "";
    }

    // 获取字符串长度
    size_t size() const {
        return size_;
    }
};

// ========== 辅助函数：返回一个 MyString 临时对象 ==========

// 这个函数返回一个 MyString 临时对象（右值），用于演示移动语义
MyString createTemporaryString() {
    MyString temp("临时字符串");  // 创建一个局部对象
    std::cout << "  [createTemporaryString] 即将返回临时对象" << std::endl;
    return temp;  // 返回值是右值，会触发移动构造（或 RVO 优化）
}

// ========== 演示完美转发 (Perfect Forwarding) 的辅助类 ==========

// 一个简单的包装器类，用于演示 std::forward 的用法
class Wrapper {
private:
    MyString value_;  // 内部存储的 MyString 对象

public:
    // 使用转发引用（万能引用）的构造函数
    // T&& 在这里不是右值引用，而是转发引用
    template<typename T>
    explicit Wrapper(T&& arg)
        // std::forward<T>(arg) 保持 arg 的原始值类别：
        // 如果传入的是左值，则 std::forward 返回左值引用，触发拷贝构造
        // 如果传入的是右值，则 std::forward 返回右值引用，触发移动构造
        : value_(std::forward<T>(arg)) {
        std::cout << "  [Wrapper 构造] 使用完美转发构造 Wrapper" << std::endl;
    }

    // 获取内部字符串的引用
    const MyString& getValue() const {
        return value_;
    }
};

// ========== 主函数 ==========

int main() {
    std::cout << "========== 右值与移动语义演示 ==========" << std::endl;
    std::cout << std::endl;

    // ====================================================================
    // 1. 演示普通构造函数
    // ====================================================================
    std::cout << "----- 1. 普通构造函数 -----" << std::endl;
    MyString str1("Hello, World!");  // 调用普通构造函数
    std::cout << "str1 内容: " << str1.c_str() << ", 长度: " << str1.size() << std::endl;
    std::cout << std::endl;

    // ====================================================================
    // 2. 演示拷贝构造函数（深拷贝）
    // ====================================================================
    std::cout << "----- 2. 拷贝构造函数（深拷贝）-----" << std::endl;
    MyString str2 = str1;            // 调用拷贝构造函数（str1 是左值）
    std::cout << "str2 内容: " << str2.c_str() << "（从 str1 深拷贝而来）" << std::endl;
    std::cout << "str1 仍然可用: " << str1.c_str() << "（源对象未被修改）" << std::endl;
    std::cout << std::endl;

    // ====================================================================
    // 3. 演示移动构造函数
    // ====================================================================
    std::cout << "----- 3. 移动构造函数 -----" << std::endl;
    // std::move 将 str2 转换为右值引用，触发移动构造函数
    // 注意：str2 在移动后将处于有效但未定义的状态
    MyString str3 = std::move(str2);  // 调用移动构造函数
    std::cout << "str3 内容: " << str3.c_str() << "（从 str2 移动而来）" << std::endl;
    std::cout << "str2 内容: " << (str2.c_str()[0] ? str2.c_str() : "(空)") << "（已被移动，内容为空）" << std::endl;
    std::cout << std::endl;

    // ====================================================================
    // 4. 演示移动赋值运算符
    // ====================================================================
    std::cout << "----- 4. 移动赋值运算符 -----" << std::endl;
    MyString str4("临时对象被赋值");   // 创建一个新对象
    str4 = MyString("移动赋值测试");   // MyString("移动赋值测试") 是右值，触发移动赋值
    std::cout << "str4 内容: " << str4.c_str() << "（移动赋值后）" << std::endl;
    std::cout << std::endl;

    // ====================================================================
    // 5. 演示从函数返回临时对象时的移动语义
    // ====================================================================
    std::cout << "----- 5. 函数返回临时对象 -----" << std::endl;
    MyString str5 = createTemporaryString();  // 函数返回值是右值，触发移动构造（或 RVO）
    std::cout << "str5 内容: " << str5.c_str() << "（从函数返回值移动而来）" << std::endl;
    std::cout << std::endl;

    // ====================================================================
    // 6. 演示完美转发 (Perfect Forwarding)
    // ====================================================================
    std::cout << "----- 6. 完美转发 (std::forward) -----" << std::endl;
    std::cout << "--- 传入左值 ---" << std::endl;
    MyString source("左值字符串");    // 创建一个左值对象
    Wrapper w1(source);               // 传入左值，完美转发会触发拷贝构造
    std::cout << std::endl;

    std::cout << "--- 传入右值 ---" << std::endl;
    Wrapper w2(MyString("右值字符串"));  // 传入右值，完美转发会触发移动构造
    std::cout << std::endl;

    // ====================================================================
    // 7. 演示性能对比：拷贝 vs 移动
    // ====================================================================
    std::cout << "----- 7. 性能对比：拷贝 vs 移动 -----" << std::endl;

    // 使用 std::vector 来演示大量对象构造时的性能差异
    constexpr int TEST_COUNT = 100000;  // 测试次数

    // 创建一个基础字符串，用于后续的拷贝构造
    MyString base("性能测试字符串");

    // 测试拷贝构造的性能（深拷贝）
    auto startCopy = std::chrono::high_resolution_clock::now();  // 记录开始时间
    {
        std::vector<MyString> vecCopy;  // 创建 vector 容器
        vecCopy.reserve(TEST_COUNT);    // 预先分配容量，避免多次扩容
        for (int i = 0; i < TEST_COUNT; ++i) {
            vecCopy.push_back(base);    // 每次 push_back 都触发深拷贝
        }
    }  // 离开作用域时 vector 析构，释放所有元素
    auto endCopy = std::chrono::high_resolution_clock::now();  // 记录结束时间
    auto copyDuration = std::chrono::duration_cast<std::chrono::milliseconds>(endCopy - startCopy);
    std::cout << "拷贝 " << TEST_COUNT << " 次耗时: " << copyDuration.count() << " 毫秒" << std::endl;

    // 测试移动构造的性能（资源转移）
    auto startMove = std::chrono::high_resolution_clock::now();  // 记录开始时间
    {
        std::vector<MyString> vecMove;  // 创建 vector 容器
        vecMove.reserve(TEST_COUNT);    // 预先分配容量
        for (int i = 0; i < TEST_COUNT; ++i) {
            vecMove.push_back(std::move(base));  // 使用 std::move 触发移动构造
            // 注意：每次移动后 base 为空，需要重新创建
            if (i < TEST_COUNT - 1) {
                base = MyString("性能测试字符串");  // 重新创建 base
            }
        }
    }  // 离开作用域时 vector 析构，释放所有元素
    auto endMove = std::chrono::high_resolution_clock::now();  // 记录结束时间
    auto moveDuration = std::chrono::duration_cast<std::chrono::milliseconds>(endMove - startMove);
    std::cout << "移动 " << TEST_COUNT << " 次耗时: " << moveDuration.count() << " 毫秒" << std::endl;

    // 输出性能对比
    if (copyDuration.count() > 0) {
        double ratio = static_cast<double>(copyDuration.count()) / std::max(moveDuration.count(), 1LL);
        std::cout << "性能对比：拷贝是移动的 " << ratio << " 倍耗时" << std::endl;
    }

    std::cout << std::endl;

    // ====================================================================
    // 总结
    // ====================================================================
    std::cout << "========== 演示完成 ==========" << std::endl;
    std::cout << "演示了以下内容:" << std::endl;
    std::cout << "  1. 普通构造函数" << std::endl;
    std::cout << "  2. 拷贝构造函数（深拷贝）" << std::endl;
    std::cout << "  3. 移动构造函数（资源转移）" << std::endl;
    std::cout << "  4. 移动赋值运算符" << std::endl;
    std::cout << "  5. 函数返回临时对象的移动语义" << std::endl;
    std::cout << "  6. 完美转发 (std::forward)" << std::endl;
    std::cout << "  7. 拷贝 vs 移动性能对比" << std::endl;

    return 0;  // 程序正常退出
}
