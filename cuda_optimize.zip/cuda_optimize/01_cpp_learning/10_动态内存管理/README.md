# 10 动态内存管理

## 1. 直观理解

### 为什么需要动态内存？

到目前为止，我们用的都是栈上变量——大小在编译时确定、函数返回后自动销毁。但很多时候这不够：

- "用户想输入 10 个数还是 10000 个数？编译时不知道"
- "这个对象需要在整个程序运行期间都存在"
- "这个数据太大，栈放不下（栈只有几 MB）"

动态内存让你在**运行时**决定分配多少内存，并且完全控制它的生命周期。

### 栈 vs 堆：一张图讲清楚

```
┌─────────────────┐ 高地址
│      栈 (Stack)  │ ← 局部变量，自动管理，向低地址增长
│  int x = 10;     │   快（移动寄存器）、小（< 8MB）
│  int* p;         │
├─────────────────┤
│       ↓          │
│    空闲空间      │
│       ↑          │
├─────────────────┤
│      堆 (Heap)   │ ← new/malloc，手动管理，向高地址增长
│  *p = 42;        │   慢（系统调用）、大（GB 级）
│                  │
├─────────────────┤
│    .BSS / .data   │ ← 全局/静态变量
├─────────────────┤
│     .text        │ ← 程序代码（只读）
└─────────────────┘ 低地址
```

---

## 2. 语法速查

### 单个对象

```cpp
int* p = new int;       // 在堆上分配一个 int（值未初始化）
int* p = new int(42);   // 在堆上分配一个 int，初始化为 42
int* p = new int{42};   // C++11：列表初始化

delete p;               // 释放内存
p = nullptr;            // 避免悬垂指针
```

### 动态数组

```cpp
int* arr = new int[100];       // 堆上分配 100 个 int

// 运行时确定大小：
int n;
cin >> n;
int* arr = new int[n];         // 数组大小在运行时才知道

delete[] arr;                  // 释放数组——注意是 delete[] 不是 delete
arr = nullptr;
```

### 混用的后果

```cpp
int* p = new int[10];
delete p;      // UB！应该用 delete[]
// 数组的析构函数可能不会全部调用（对基本类型 int 碰巧可能"正常"）

int* q = new int(42);
delete[] q;    // UB！应该用 delete
// delete[] 可能去读数组的大小信息，但单个对象没有
```

---

## 3. 底层原理

### `new` 背后发生了什么？

```cpp
int* p = new int(42);
```

这条语句做三件事：

1. **分配内存**：调用 `operator new(sizeof(int))`，向堆管理器申请 4 字节
2. **调用构造函数**：在这 4 字节上构造 int，初始化为 42
3. **返回指针**：返回分配的内存地址

`operator new` 的内部流程（简化）：

```
operator new(size)
  → 检查空闲链表有没有足够大的块
  → 没有 → 向 OS 请求更多堆空间（brk() 或 mmap() 系统调用）
  → 有 → 从空闲链表中切出一块，返回地址
```

### `delete` 背后发生了什么？

```cpp
delete p;
```

1. **调用析构函数**：`p->~int()`（对基本类型是空操作）
2. **释放内存**：调用 `operator delete(p)`，把这块内存归还给堆管理器
3. 注意：**p 本身的值没有变**——它仍然存着原来的地址，只是那块内存已经不属于你了

### Placement new ——在指定地址构造对象

```cpp
#include <new>

char buffer[sizeof(int)];          // 栈上的一块原始内存
int* p = new (buffer) int(42);     // 在 buffer 的地址上构造 int
// 没有分配新内存，只在已有内存上调用构造函数

// 用途：内存池、自定义分配器、嵌入式系统
// 注意：placement new 不能 delete——需要手动调用析构函数
p->~int();
```

### 内存碎片化 ——隐藏的杀手

```
初始状态:
[空闲: 1000MB]

分配 3 个对象后:
[A: 100MB][B: 200MB][C: 100MB][空闲: 600MB]

释放 B:
[A: 100MB][空洞: 200MB][C: 100MB][空闲: 600MB]
                           ↑ 总共空闲 800MB，但不能连续分配 > 600MB！
```

碎片化导致即使总空闲内存足够，也无法分配大块连续内存。这就是为什么高性能场景常用**内存池（Memory Pool）**——预先分配一大块，自己管理小块的分配和回收，避免碎片。

---

## 4. 深入细节

### 为什么现代 C++ 不鼓励裸 `new/delete`？

```cpp
void process() {
    auto* data = new BigObject();

    if (some_condition) {
        delete data;
        return;              // 正常 delete
    }

    doSomething();           // 如果这里抛异常——
    delete data;             // 这行永远不会执行！
}
// 结果：内存泄漏
```

裸 `new/delete` 的问题：
1. **异常不安全**：异常会跳过 delete
2. **所有权模糊**：谁负责 delete？看代码的人不知道
3. **容易忘记**：每个 new 都对应一个必须被调用的 delete
4. **容易重复释放或遗漏**

这就是 **RAII（Resource Acquisition Is Initialization）** 和**智能指针**存在的理由（详见第 23 课）：

```cpp
void process() {
    auto data = std::make_unique<BigObject>();  // 自动管理
    // 无论怎么退出函数——正常、异常、return——
    // unique_ptr 的析构函数都会自动 delete
}
```

> **RAII 核心思想**：把资源（内存、文件、锁）的生命周期绑定到一个栈对象的生命周期上。分配在构造函数，释放在析构函数。C++ 保证栈对象离开作用域时析构函数一定被调用。

### `new` 失败怎么办？

```cpp
// 默认行为：抛 std::bad_alloc 异常
int* p = new int[100000000000];  // 可能抛异常

// 不抛异常的版本：
int* p = new (std::nothrow) int[100000000000];
if (p == nullptr) {
    // 分配失败，自己处理
}
```

### 动态二维数组

```cpp
// 方式 1：指针数组（每行单独分配，内存不连续）
int** matrix = new int*[rows];
for (int i = 0; i < rows; i++)
    matrix[i] = new int[cols];
// 释放：
for (int i = 0; i < rows; i++)
    delete[] matrix[i];
delete[] matrix;

// 方式 2：一块连续内存（推荐——缓存友好）
int* matrix = new int[rows * cols];
// matrix[i][j] 写成 matrix[i * cols + j]
delete[] matrix;

// 方式 3：用 std::vector（最推荐）
std::vector<std::vector<int>> matrix(rows, std::vector<int>(cols));
// 无需手动释放
```

---

## 5. C++ vs Python 对照

```python
# Python：内存全自动管理
x = [1, 2, 3]     # 列表在堆上分配，GC 负责回收
x = None           # 旧列表无人引用 → 等待 GC 回收
# 你无法控制何时分配、何时回收
```

```cpp
// C++：你可以选择
// 自动（栈上）：
int x = 42;          // 函数结束自动释放

// 手动（堆上）：
int* p = new int(42);  // 你负责释放
delete p;

// 半自动（RAII）：
auto p = std::make_unique<int>(42);  // 离开作用域自动释放
```

| 方面 | Python | C++ |
|------|--------|-----|
| 堆分配 | 始终在堆上（一切皆对象） | 显式用 `new`/`malloc` |
| 回收 | GC 自动（引用计数 + 循环检测） | 手动 `delete` 或 RAII |
| 内存控制 | 无直接控制 | 完全控制（placement new、自定义 allocator） |
| 碎片化 | 无法感知 | 可以通过内存池管理 |
| 性能 | GC 有停顿 | 零开销（但错误代价高） |
| 安全性 | 高（无悬垂指针、无泄漏——理论上） | 低（全靠程序员） |

---

## 6. 练习与思考

### 基础练习

1. 用 `new` 动态创建一个数组，大小由用户输入，填充数据后输出
2. 实现一个动态二维数组（`new int[rows * cols]` 连续内存方式），输出每个元素
3. 对比 `new`/`delete` 和 `new[]`/`delete[]` 混用的后果（用 sanitizer）

### 思考题

4. `new` 和 `malloc` 有什么区别？（提示：构造函数、类型安全、失败行为）
5. 什么是 RAII？为什么它被称为 C++ 最重要的惯用法？
6. placement new 有什么实际用途？在 CUDA 编程中你可能会在什么场景遇到它？
7. 内存碎片化在长时间运行的程序（如推理服务器）中为什么是个问题？
8. 写一个简单的内存泄漏检测练习：故意泄漏一块内存，用 Address Sanitizer 检测

> 参考阅读：[内存模型](../docs/00_内存模型.md) —— 栈和堆的详细对比
> 参考阅读：[未定义行为](../docs/00_未定义行为.md) —— use-after-free、double-free 等
> 延伸阅读：第 23 课 [智能指针](../23_智能指针/README.md) —— 用 RAII 自动管理动态内存
