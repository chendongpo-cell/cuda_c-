// Student.h - 学生类的头文件
// 头文件用于声明类的接口，不包含实现细节

// 使用头文件保护宏，防止头文件被重复包含
#ifndef STUDENT_H
#define STUDENT_H

// 包含字符串头文件，用于使用 string 类型
#include <string>
// 包含输入输出流头文件，用于在控制台输出信息
#include <iostream>
// 使用标准命名空间
using namespace std;

// 定义 Student 类
// 类的声明放在头文件中，供其他文件引用
class Student {
// public 访问修饰符，表示下面的成员在类内外都可以访问
public:
    // 成员变量：学生的姓名，使用 string 类型存储
    string name;
    // 成员变量：学生的年龄，使用 int 类型存储
    int age;
    // 成员变量：学生的分数，使用 double 类型存储
    double score;

    // 成员函数声明：显示学生信息
    // 该函数用于在控制台打印学生的姓名、年龄和分数
    void display();

    // 成员函数声明：判断学生是否及格
    // 返回 true 表示及格（分数 >= 60），否则返回 false
    bool isPass();
};

// 结束头文件保护宏
#endif
