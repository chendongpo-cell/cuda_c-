// 11_类与对象 / main.cpp
// 本程序演示 C++ 中类与对象的基本概念

// 包含输入输出流头文件，用于控制台输入输出
#include <iostream>
// 包含字符串头文件，用于使用 string 类型
#include <string>
// 使用标准命名空间，避免每次调用 std:: 前缀
using namespace std;

// 定义一个名为 Student 的类
// 类是 C++ 面向对象编程的核心，用于封装数据和功能
class Student {
// public 访问修饰符，表示下面的成员在类内外都可以访问
public:
    // 成员变量（属性）：学生的姓名
    string name;
    // 成员变量（属性）：学生的年龄
    int age;
    // 成员变量（属性）：学生的分数
    double score;

    // 成员函数（方法）：显示学生信息
    // 该函数没有返回值，用于在控制台打印学生的基本信息
    void display() {
        // 输出学生的姓名、年龄和分数
        cout << "姓名: " << name << ", 年龄: " << age << ", 分数: " << score << endl;
    }

    // 成员函数（方法）：判断是否及格
    // 该函数返回一个布尔值，表示学生的分数是否大于等于 60 分
    bool isPass() {
        // 如果分数大于等于 60 则返回 true，否则返回 false
        return score >= 60;
    }
};

// 主函数，程序的入口点
int main() {
    // 创建一个 Student 对象，这是在栈上分配内存
    // 对象是类的具体实例，可以独立存储数据
    Student stu1;

    // 通过点运算符 "." 访问对象的成员变量，并为其赋值
    // 设置 stu1 的姓名为 "张三"
    stu1.name = "张三";
    // 设置 stu1 的年龄为 20
    stu1.age = 20;
    // 设置 stu1 的分数为 85.5
    stu1.score = 85.5;

    // 调用对象的成员函数 display，打印学生信息
    cout << "学生1的信息：" << endl;
    stu1.display();

    // 调用对象的成员函数 isPass，判断是否及格
    // 函数的返回值直接用于判断条件
    if (stu1.isPass()) {
        cout << stu1.name << " 考试及格！" << endl;
    } else {
        cout << stu1.name << " 考试不及格。" << endl;
    }

    // 在输出中加一个空行，使结果更清晰
    cout << endl;

    // 创建第二个 Student 对象
    Student stu2;
    // 为 stu2 的成员变量赋值
    stu2.name = "李四";
    // 设置年龄为 22
    stu2.age = 22;
    // 设置分数为 45.0，这是一个不及格的分数
    stu2.score = 45.0;

    // 打印 stu2 的信息
    cout << "学生2的信息：" << endl;
    stu2.display();

    // 判断 stu2 是否及格
    if (stu2.isPass()) {
        cout << stu2.name << " 考试及格！" << endl;
    } else {
        cout << stu2.name << " 考试不及格。" << endl;
    }

    // 演示使用指针创建对象（在堆上分配内存）
    // 使用 new 关键字在堆上动态创建 Student 对象
    cout << endl << "使用指针创建对象：" << endl;
    Student* pStu = new Student();
    // 通过箭头运算符 "->" 访问指针对象的成员
    // 这是指针访问成员的标准语法
    pStu->name = "王五";
    // 设置年龄
    pStu->age = 19;
    // 设置分数
    pStu->score = 92.0;
    // 调用成员函数
    pStu->display();

    // 使用 delete 释放堆上分配的内存，防止内存泄漏
    delete pStu;

    // 程序正常结束，返回 0
    return 0;
}
