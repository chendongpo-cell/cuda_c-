// Student.cpp - 学生类成员函数的实现文件
// 该文件包含 Student 类中声明的方法的具体实现

// 包含 Student 类的头文件，确保实现与声明一致
#include "Student.h"

// display 成员函数的实现
// 该函数在控制台输出学生的姓名、年龄和分数
void Student::display() {
    // 使用 cout 输出学生的姓名
    // name 是 Student 类的成员变量
    cout << "姓名: " << name << ", 年龄: " << age << ", 分数: " << score << endl;
}

// isPass 成员函数的实现
// 该函数判断学生分数是否达到及格线（60 分）
bool Student::isPass() {
    // 如果分数 score 大于等于 60，返回 true（及格）
    // 否则返回 false（不及格）
    return score >= 60;
}
