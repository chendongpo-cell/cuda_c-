# C++ 面试题 —— 基础篇

> 对应知识点：基础语法（第 01~10 课）+ 面向对象编程（第 11~18 课）
> 难度：⭐⭐ 适合初、中级面试

---

## 目录

1. [程序结构与编译运行](#1-程序结构与编译运行)
2. [变量与数据类型](#2-变量与数据类型)
3. [运算符与表达式](#3-运算符与表达式)
4. [流程控制](#4-流程控制)
5. [数组与字符串](#5-数组与字符串)
6. [函数](#6-函数)
7. [指针与动态内存](#7-指针与动态内存)
8. [类与对象](#8-类与对象)
9. [构造函数与析构函数](#9-构造函数与析构函数)
10. [封装与友元](#10-封装与友元)
11. [继承](#11-继承)
12. [多态与虚函数](#12-多态与虚函数)
13. [运算符重载](#13-运算符重载)
14. [类型转换](#14-类型转换)
15. [异常处理](#15-异常处理)

---

## 1. 程序结构与编译运行

### 题 1：C++ 程序的编译过程分为哪几个阶段？

**考察点**：C++ 编译原理、预处理、编译、汇编、链接

**参考答案**：

C++ 源文件到可执行文件需要经过四个阶段：

| 阶段 | 输入 → 输出 | 做的事 |
|------|-------------|--------|
| 预处理 | `.cpp` → `.i` | 处理 `#include`、`#define`、条件编译等预处理指令 |
| 编译 | `.i` → `.s` | 将预处理后的代码编译成汇编代码（语法分析、优化） |
| 汇编 | `.s` → `.o` | 将汇编代码转换为机器码（目标文件） |
| 链接 | `.o` → 可执行文件 | 将多个目标文件 + 库文件链接成最终可执行程序 |

```cpp
// 一个简单的示例
#include <iostream>     // 预处理阶段会展开这个头文件

#define PI 3.14159      // 预处理阶段会将所有 PI 替换为 3.14159

int main() {
    std::cout << PI << std::endl;   // 编译阶段检查语法
    return 0;                       // 链接阶段链接到标准库的 cout 实现
}
```

**提示**：面试中常追问"链接错误和编译错误的区别"——编译错误是语法问题，链接错误是找不到函数或变量的实现。

---

### 题 2：`#include <iostream>` 和 `#include "myheader.h"` 有什么区别？

**考察点**：头文件搜索路径、预处理

**参考答案**：

- `< >`：编译器在**系统头文件目录**中搜索（如 `/usr/include`、MinGW 的 include 目录）
- `" "`：编译器**先从源文件所在目录**搜索，找不到再去系统目录搜索

```cpp
// 通常约定：
#include <iostream>      // 标准库头文件用 <>
#include <vector>
#include "Employee.h"    // 项目自定义头文件用 ""
#include "Utils.h"
```

**提示**：如果项目中自定义头文件也用 `<>`，在特定编译器设置下可能意外找到系统同名文件，导致编译混淆。

---

## 2. 变量与数据类型

### 题 3：C++ 的基本数据类型有哪些？分别占多少字节？

**考察点**：基本数据类型、sizeof

**参考答案**：

| 类型 | 典型大小 | 取值范围 |
|------|----------|----------|
| `bool` | 1 字节 | true / false |
| `char` | 1 字节 | -128 ~ 127（或 0~255） |
| `short` | 2 字节 | -32,768 ~ 32,767 |
| `int` | 4 字节 | -2^31 ~ 2^31-1 |
| `long` | 4 或 8 字节（平台相关） | 取决于平台 |
| `long long` | 8 字节 | -2^63 ~ 2^63-1 |
| `float` | 4 字节 | ~7 位有效数字 |
| `double` | 8 字节 | ~15 位有效数字 |

```cpp
#include <iostream>
int main() {
    std::cout << "int 大小: " << sizeof(int) << " 字节" << std::endl;
    std::cout << "double 大小: " << sizeof(double) << " 字节" << std::endl;
    return 0;
}
```

**提示**：C++ 标准只规定了 `sizeof(char) == 1` 和 `sizeof(short) ≤ sizeof(int) ≤ sizeof(long) ≤ sizeof(long long)`，具体大小由编译器/平台决定。如果在嵌入式面试中，需要关注平台差异。

---

### 题 4：`const` 和 `#define` 定义常量有什么区别？

**考察点**：常量定义、预处理 vs 编译、类型安全

**参考答案**：

| 特性 | `const` | `#define` |
|------|---------|-----------|
| 处理阶段 | 编译期 | 预处理（文本替换） |
| 类型检查 | 有 | 无 |
| 作用域 | 遵循作用域规则 | 从定义到文件末尾 |
| 内存占用 | 通常分配内存（取决于优化） | 不占内存（直接替换） |
| 调试 | 可被调试器识别 | 预处理后被替换，不可见 |

```cpp
#define PI 3.14159           // 纯文本替换，没有类型
const double kPi = 3.14159;  // 有类型，可被编译器检查

// #define 的陷阱
#define SQUARE(x) x * x
int a = SQUARE(1 + 2);       // 展开为 1 + 2 * 1 + 2 = 5，不是 9！
// 正确写法：#define SQUARE(x) ((x) * (x))
```

**提示**：现代 C++ 中优先使用 `const` / `constexpr` 而不是 `#define` 定义常量。

---

### 题 5：什么是类型转换？C++ 中隐式类型转换和显式类型转换有什么区别？

**考察点**：类型转换、数据精度

**参考答案**：

- **隐式转换**：编译器自动进行的转换，可能丢失精度而不提示
- **显式转换**：程序员明确写出的转换，意图清晰

```cpp
// 隐式转换（可能丢失数据）
int a = 3.14;              // double → int，a = 3，丢失小数部分
double b = 10;             // int → double，b = 10.0，安全

// 显式转换（C 风格）
int c = (int)3.14;         // 不推荐，不易搜索

// 显式转换（C++ 风格，推荐）
int d = static_cast<int>(3.14);  // 推荐，明确意图

// 精度丢失示例
int big = 1000000;
float f = big;             // 隐式转换，可能丢失精度
int back = static_cast<int>(f);
std::cout << back;         // 可能不等于 1000000！
```

**提示**：可以补充 `static_cast` vs `reinterpret_cast` vs `dynamic_cast` vs `const_cast` 的区别（在第 17 课类型转换中详细展开）。

---

## 3. 运算符与表达式

### 题 6：`++i` 和 `i++` 有什么区别？分别在什么场景下使用？

**考察点**：前缀自增 vs 后缀自增、性能差异

**参考答案**：

- `++i`：先自增，后返回（返回的是引用）
- `i++`：先返回原值，后自增（返回的是临时副本）

```cpp
int i = 1;
int a = ++i;   // i 先变为 2，然后 a = 2
int b = i++;   // b = 2（原值），然后 i 变为 3

// 性能差异（迭代器场景）
// 对于内置类型，两者性能相同（编译器优化）
// 对于迭代器，++it 通常比 it++ 更高效
std::vector<int> v = {1, 2, 3};
for (auto it = v.begin(); it != v.end(); ++it) {  // 推荐使用 ++it
    // ...
}
```

**提示**：面试中常问"为什么 for 循环中推荐用 `++i` 而不是 `i++`"——因为 `i++` 会创建一个临时副本。

---

### 题 7：解释一下 `&&`（逻辑与）和 `||`（逻辑或）的短路求值特性。

**考察点**：短路求值、运算符优先级

**参考答案**：

短路求值：逻辑表达式中，当左侧结果已经能确定整个表达式的值时，右侧**不会被执行**。

```cpp
// 短路求值的实际应用
int* ptr = nullptr;
if (ptr != nullptr && *ptr > 0) {   // 安全！ptr != nullptr 为 false 时，右侧不执行
    // 不会解引用空指针
}

// OR 短路
bool isAdmin = false;
if (isAdmin || checkPermission()) {  // isAdmin 已经是 true，checkPermission 不会调用
    // ...
}

// 常见陷阱
int x = 0;
if (x != 0 && 10 / x > 1) {   // 安全：x=0 时右侧不执行，不会除零
}
```

**提示**：短路求值是常见的安全编程技巧，但也可能导致"隐形的未调用"bug。

---

## 4. 流程控制

### 题 8：`if-else if` 和 `switch` 如何选择？各自的优缺点？

**考察点**：分支选择、性能、可读性

**参考答案**：

```cpp
// switch 适合：单一变量与多个常量值的精确匹配
switch (type) {
    case 1: /* 正式员工逻辑 */ break;
    case 2: /* 兼职员工逻辑 */ break;
    case 3: /* 经理逻辑 */     break;
    default: /* 未知类型 */    break;
}

// if-else if 适合：范围比较、复杂条件
if (score >= 90) {
    grade = 'A';
} else if (score >= 80) {
    grade = 'B';
} else if (score >= 60) {
    grade = 'C';
} else {
    grade = 'D';
}
```

| 特性 | switch | if-else if |
|------|--------|------------|
| 条件类型 | 只能是整数/枚举/字符 | 任意 bool 表达式 |
| 可读性 | 等值匹配时更清晰 | 范围判断更自然 |
| 性能 | 可能优化为跳转表 | 逐个判断 |
| fallthrough | 默认需要 break | 无此问题 |

**提示**：现代编译器对连续的 `if-else` 和 `switch` 可能生成相同的高效代码，可读性才是主要考量。

---

### 题 9：`for` 循环和 `while` 循环在什么场景下使用？

**考察点**：循环选择、range-based for

**参考答案**：

```cpp
// for：知道循环次数时使用
for (int i = 0; i < 10; ++i) { ... }

// while：不知道循环次数，只知条件时使用
while (userInput != "quit") { ... }

// do-while：至少执行一次
do {
    // 显示菜单至少一次
} while (choice != 0);

// C++11 range-based for（最推荐，安全简洁）
std::vector<int> nums = {1, 2, 3, 4, 5};
for (const auto& num : nums) {
    std::cout << num << std::endl;
}
```

**提示**：range-based for 是现代 C++ 首选的遍历方式，比下标循环安全（不会越界）。

---

## 5. 数组与字符串

### 题 10：C 风格字符串和 `std::string` 有什么区别？

**考察点**：字符串处理、内存管理、安全性

**参考答案**：

```cpp
// C 风格字符串：char 数组，以 '\0' 结尾
char name1[] = "hello";       // 实际占 6 字节（含 '\0'）
// 操作麻烦：strcpy, strcat, strlen 等 C 函数
// 容易越界、忘记 '\0' 空间

// C++ std::string
std::string name2 = "hello";  // 自动管理内存
name2 += " world";            // 拼接方便
name2.size();                  // 获取长度，无需 strlen
name2.find("world");           // 查找子串
name2.substr(0, 5);            // 取子串
// 自动扩容，不会缓冲区溢出

// 常见陷阱：C 风格字符串复制
char src[] = "hello";
char dst[5];                    // 空间不够！
strcpy(dst, src);               // 缓冲区溢出！危险
```

**提示**：现代 C++ 中，除非与 C 库交互，否则永远使用 `std::string`。

---

### 题 11：数组和 `std::vector` 的区别是什么？

**考察点**：容器选择、动态数组

**参考答案**：

| 特性 | 原生数组 | std::vector |
|------|---------|-------------|
| 大小 | 编译期固定 | 运行时动态变化 |
| 内存管理 | 手动/栈分配 | 自动管理堆内存 |
| 越界检查 | 无（危险） | `at()` 方法有检查 |
| 传递参数 | 退化为指针 | 可复制、可引用传递 |
| 功能 | 无 | push_back, size, insert 等 |

```cpp
// 原生数组
int arr[5] = {1, 2, 3, 4, 5};   // 大小固定
// arr[10] = 100;                // 越界！无警告，可能崩溃

// std::vector（推荐）
std::vector<int> vec = {1, 2, 3};
vec.push_back(4);                // 自动扩容
vec.at(10);                      // 越界时抛出 std::out_of_range
std::cout << vec.size();         // 获取大小
```

**提示**：面试中常问 vector 的"扩容机制"——当容量不足时，重新申请 2 倍（或 1.5 倍）空间，将旧元素拷贝/移动到新内存。

---

## 6. 函数

### 题 12：值传递、指针传递、引用传递有什么区别？

**考察点**：参数传递方式、性能、安全

**参考答案**：

```cpp
void passByValue(int a) { a = 10; }           // 传值：修改不影响外部
void passByPointer(int* a) { *a = 10; }       // 传指针：修改影响外部
void passByReference(int& a) { a = 10; }      // 传引用：修改影响外部

int x = 0;
passByValue(x);          // x 仍为 0
passByPointer(&x);       // x 变为 10
passByReference(x);      // x 变为 10

// 大对象传递：引用 > 指针 > 值
// 传值会拷贝整个对象，开销大
void process(const std::vector<int>& data);   // 推荐：const 引用，只读不拷贝
void process(std::vector<int>* data);          // 可接受：指针，需判空
void process(std::vector<int> data);           // 不推荐：拷贝整个容器
```

| 方式 | 是否修改外部 | 是否拷贝 | 能否为 null |
|------|-------------|---------|-------------|
| 值传递 | 否 | 是 | — |
| 指针传递 | 是 | 否 | 可以（需判空） |
| 引用传递 | 是 | 否 | 不能（一定有效） |
| const 引用 | 否 | 否 | 不能 |

**提示**：面试中常追问"什么时候必须用指针？"——需要表示"没有对象"（nullptr）、与 C 代码交互时。

---

### 题 13：什么是函数重载？编译器如何区分重载函数？

**考察点**：函数重载、名字修饰（name mangling）

**参考答案**：

函数重载：同一作用域内，函数名相同但**参数列表不同**（个数/类型/顺序），返回值不影响重载。

```cpp
int add(int a, int b) { return a + b; }
double add(double a, double b) { return a + b; }   // OK：参数类型不同
int add(int a, int b, int c) { return a + b + c; } // OK：参数个数不同

// 以下不行：只有返回值不同
// double add(int a, int b);   // 编译错误：与 int add(int, int) 冲突

// 编译器通过"名字修饰"区分——将函数名和参数类型编码成唯一符号
// 例如 add(int, int) 可能被修饰为 _Z3addii
// add(double, double) 可能被修饰为 _Z3adddd
```

**提示**：C 语言不支持函数重载，C++ 通过名字修饰实现。与 C 混编时使用 `extern "C"` 关闭名字修饰。

---

### 题 14：什么是 inline 函数？和宏有什么区别？

**考察点**：函数内联、性能优化

**参考答案**：

`inline` 建议编译器将函数体直接插入调用处，消除函数调用开销。但只是"建议"，编译器可能忽略。

```cpp
// inline 函数
inline int max(int a, int b) {
    return a > b ? a : b;
}

// 对应的宏
#define MAX(a, b) ((a) > (b) ? (a) : (b))

// 使用
int m = max(3, 4);      // 可能被展开为：int m = 3 > 4 ? 3 : 4;
```

| 特性 | inline 函数 | 宏 |
|------|------------|-----|
| 类型检查 | 有 | 无 |
| 作用域 | 遵循作用域规则 | 预处理替换 |
| 调试 | 可设断点 | 不可见 |
| 副作用 | 安全 | 有陷阱（如 SQUARE(x++)） |
| 适用场景 | 短小频繁调用的函数 | 条件编译、头文件保护 |

**提示**：现代编译器优化能力强，`inline` 对性能的影响已经很小。编译器的"自动内联"通常比手动 `inline` 更智能。

---

## 7. 指针与动态内存

### 题 15：指针和引用的区别是什么？

**考察点**：指针 vs 引用、内存地址

**参考答案**：

```cpp
int a = 10;
int* p = &a;      // 指针：存储地址，可以为空
int& r = a;       // 引用：变量的别名，不能为空，必须初始化

// 指针可以重新指向别的变量
int b = 20;
p = &b;           // OK：指针可以指向别的变量
// r = b;         // 不是让 r 引用 b，而是把 b 的值赋给 a（r 引用的对象）

// sizeof 不同
sizeof(p);         // 指针本身的大小（64位系统为 8 字节）
sizeof(r);         // 引用的目标的大小（int 为 4 字节）
```

| 特性 | 指针 | 引用 |
|------|------|------|
| 是否可为空 | 可以（nullptr） | 不能 |
| 是否可重绑定 | 可以 | 不能 |
| 是否需要初始化 | 不必须 | 必须初始化 |
| 语法 | `*p` 解引用 | 直接使用 |
| 多级 | 可以（`int**`） | 不能 |

**提示**：能使用引用的场景优先使用引用（更安全），需要"没有对象"或"重新绑定"时用指针。

---

### 题 16：`new` 和 `malloc` 有什么区别？

**考察点**：动态内存分配、构造/析构

**参考答案**：

```cpp
// C 风格：malloc/free
int* arr1 = (int*)malloc(10 * sizeof(int));  // 只分配内存，不初始化
free(arr1);

// C++ 风格：new/delete
int* arr2 = new int[10];     // 分配内存 + 默认初始化
delete[] arr2;

// 对于对象，差异更明显
// malloc 只分配内存，不会调用构造函数
// new 分配内存 + 调用构造函数
```

| 特性 | malloc/free | new/delete |
|------|-------------|------------|
| 本质 | C 标准库函数 | C++ 运算符 |
| 调用构造函数 | 不调用 | 调用 |
| 调用析构函数 | 不调用 | 调用 |
| 返回类型 | `void*`（需强转） | 类型安全的指针 |
| 失败处理 | 返回 NULL | 抛出 std::bad_alloc |
| 重载 | 不可重载 | 可重载（自定义内存管理） |

**提示**：现代 C++ 几乎不用 `new/delete`，而是使用智能指针（`std::make_shared`、`std::make_unique`）。

---

### 题 17：什么是野指针？如何避免？

**考察点**：指针安全、内存管理

**参考答案**：

野指针是指向"已释放内存"或"无效地址"的指针，解引用野指针会导致**未定义行为**（可能崩溃、数据损坏、安全漏洞）。

```cpp
// 野指针的常见来源
// 1. 使用已释放的指针
int* p = new int(10);
delete p;
*p = 20;                   // 野指针！内存已释放

// 2. 函数返回局部变量的地址
int* badFunc() {
    int local = 42;
    return &local;          // 野指针！函数结束后 local 已销毁
}

// 3. 指针未初始化
int* p;                     // 野指针！未初始化
*p = 10;                    // 危险！

// 如何避免：
// 1. 指针初始化
int* p = nullptr;

// 2. delete 后置 nullptr
delete p;
p = nullptr;

// 3. 优先使用智能指针（最重要！）
std::unique_ptr<int> up = std::make_unique<int>(10);
// 无需手动 delete，自动释放
```

**提示**：现代 C++ 的最佳实践——**不要使用裸指针管理所有权**，用智能指针。

---

### 题 18：什么是内存泄漏？如何检测和避免？

**考察点**：资源管理、RAII

**参考答案**：

内存泄漏：动态分配的内存没有被释放，导致程序占用的内存持续增长，最终可能耗尽系统资源。

```cpp
// 内存泄漏的典型场景
void leakFunction() {
    int* p = new int[1000];
    // 忘记 delete[] p;
    // p 离开作用域后，内存地址丢失，再也无法释放
}

// 内存泄漏的累积效应
for (int i = 0; i < 1000000; ++i) {
    leakFunction();    // 每次泄漏 4KB，很快就耗尽内存
}

// 正确方式：RAII（资源获取即初始化）
void safeFunction() {
    std::vector<int> v(1000);   // 栈上对象，自动释放
    // 自动管理内存，不用手动 release
}
```

**如何避免**：
1. 尽量使用栈上对象（局部变量）
2. 必须用堆时使用智能指针（`unique_ptr`、`shared_ptr`）
3. 遵循 RAII 原则：资源和对象生命周期绑定
4. 使用工具检测：Valgrind（Linux）、Dr.Memory（Windows）、ASan（编译器的地址消毒）

---

## 8. 类与对象

### 题 19：类和结构体有什么区别？

**考察点**：class vs struct、默认访问权限

**参考答案**：

```cpp
// C++ 中 struct 和 class 几乎一样，只有两点不同：
struct Point {
    int x;          // 默认 public
    int y;
};

class Circle {
    double radius;  // 默认 private！
public:
    void setRadius(double r) { radius = r; }
};
```

| 特性 | struct | class |
|------|--------|-------|
| 默认访问权限 | public | private |
| 默认继承方式 | public | private |
| 语法风格 | 常用于 POD（纯数据） | 常用于封装行为的对象 |

**提示**：面试答案——"技术上只有默认访问权限的区别，但习惯上用 struct 表示纯数据，用 class 表示有封装行为的对象。"

---

### 题 20：什么是 this 指针？

**考察点**：成员函数、隐含参数

**参考答案**：

`this` 是指向当前对象自身的指针，在**非静态成员函数**中可用，是编译器隐式传递的。

```cpp
class Employee {
    int id;
    std::string name;
public:
    // this 指向调用该函数的对象
    void setId(int id) {
        this->id = id;          // 区分参数和成员变量
    }

    Employee& setName(const std::string& name) {
        this->name = name;
        return *this;           // 返回当前对象的引用，支持链式调用
    }

    void compare(Employee& other) {
        if (this == &other) {   // 判断是否是自己
            std::cout << "同一个对象" << std::endl;
        }
    }
};
```

**提示**：`this` 是一个**右值**（不能取 `this` 的地址），在静态成员函数中不可用。

---

## 9. 构造函数与析构函数

### 题 21：什么是构造函数的初始化列表？为什么推荐使用？

**考察点**：初始化 vs 赋值、效率

**参考答案**：

初始化列表在构造函数体**执行之前**初始化成员变量，比在函数体内赋值更高效。

```cpp
class Employee {
    const int id;           // const 成员必须在初始化列表中初始化
    std::string& ref;       // 引用必须在初始化列表中初始化
    std::string name;
public:
    // 推荐：初始化列表
    Employee(int i, const std::string& n)
        : id(i), ref(name), name(n)   // 初始化列表
    {
        // 函数体为空
    }

    // 不推荐：函数体内赋值
    Employee(int i, const std::string& n) {
        id = i;             // 错误！const 成员不能赋值
        name = n;           // 先默认构造 name，再赋值，效率低
    }
};
```

**必须使用初始化列表的场景**：
1. 初始化 `const` 成员
2. 初始化引用成员
3. 基类构造函数有参数
4. 成员类没有默认构造函数

---

### 题 22：什么是拷贝构造函数？何时被调用？

**考察点**：拷贝语义、深拷贝 vs 浅拷贝

**参考答案**：

拷贝构造函数用已有对象创建一个新对象，参数是 `const T&`。

```cpp
class String {
    char* data;
public:
    // 默认拷贝构造函数：做浅拷贝（按字节复制）
    // String(const String&) = default;  // 危险的浅拷贝！

    // 自定义深拷贝构造函数
    String(const String& other) {
        data = new char[strlen(other.data) + 1];
        strcpy(data, other.data);     // 深拷贝：复制内容而非指针
    }

    ~String() { delete[] data; }
};

// 拷贝构造函数在以下场景被调用：
String s1("hello");
String s2 = s1;             // 1. 初始化：调用拷贝构造
String s3(s1);              // 2. 直接初始化：调用拷贝构造

void func(String s) { ... }
func(s1);                   // 3. 函数参数传值：调用拷贝构造

String createString() {
    String s("temp");
    return s;               // 4. 函数返回值：可能调用拷贝构造（编译器优化后可能不调）
}
```

**提示**：如果一个类管理了动态内存/文件句柄/网络连接等资源，必须实现深拷贝或禁止拷贝（`= delete`）。否则浅拷贝会导致 double free。

---

### 题 23：什么是析构函数？为什么通常声明为 virtual？

**考察点**：资源释放、多态删除

**参考答案**：

析构函数在对象销毁时自动调用，负责释放资源。如果通过基类指针删除派生类对象，基类析构函数必须是 virtual 的，否则派生类部分不会被正确析构。

```cpp
class Employee {
public:
    virtual ~Employee() = default;   // 正确：虚析构
};

class Manager : public Employee {
    std::vector<Employee*> team;
public:
    ~Manager() {
        // 清理 team 中的员工
    }
};

Employee* emp = new Manager();
delete emp;     // 如果 ~Employee() 不是 virtual，只会调用 ~Employee()
                // 不会调用 ~Manager()，导致 team 资源泄漏
```

**核心规则**：
- **如果类有虚函数，析构函数必须是 virtual 的**
- 如果类是 final 或不被继承，析构函数不需要 virtual（避免 vtbl 开销）
- 从 C++11 开始，使用 `= default` 生成默认实现

---

## 10. 封装与友元

### 题 24：什么是封装？C++ 中如何实现封装？

**考察点**：面向对象的封装、访问控制

**参考答案**：

封装是将数据（成员变量）和操作（成员函数）捆绑在一起，并控制外部对内部数据的访问。

```cpp
class BankAccount {
private:                    // 私有：外部不可直接访问
    double balance;

public:                     // 公有：对外接口
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    double getBalance() const {  // 只读访问
        return balance;
    }
};

// 外部无法直接修改 balance，必须通过公有接口
BankAccount acc;
// acc.balance = 1000000;     // 错误！private 成员不可访问
acc.deposit(1000);            // 正确：通过公有接口
```

**三大访问控制**：
| 关键字 | 含义 |
|--------|------|
| `public` | 任何地方都可访问 |
| `protected` | 类内部和派生类可访问 |
| `private` | 仅类内部可访问 |

---

### 题 25：友元（friend）的作用是什么？有什么优缺点？

**考察点**：友元函数/类、封装破坏

**参考答案**：

友元允许一个非成员函数或其他类的成员函数访问本类的私有（private/protected）成员。

```cpp
class Employee {
private:
    double salary;

    // 声明友元函数
    friend void printSalary(const Employee& elevel);

    // 声明友元类
    friend class HRSystem;
};

// 友元函数可以访问私有成员
void printSalary(const Employee& e) {
    std::cout << e.salary << std::endl;  // OK：因为声明为友元
}

// 友元类可以访问所有私有成员
class HRSystem {
public:
    void adjustSalary(Employee& e, double amount) {
        e.salary += amount;     // OK：HRSystem 是 Employee 的友元类
    }
};
```

| 优点 | 缺点 |
|------|------|
| 运算符重载需要（如 `<<`） | 破坏了封装性 |
| 某些场景比成员函数更自然 | 增加了类之间的耦合 |
| 不增加虚函数开销 | 难以维护（A 的私有数据被 B 依赖） |

**提示**：友元应该谨慎使用，典型适用场景是运算符重载中的 `operator<<` 和 `operator>>`。

---

## 11. 继承

### 题 26：C++ 支持哪几种继承方式？区别是什么？

**考察点**：继承访问控制

**参考答案**：

```cpp
class Base {
public:
    int pub;
protected:
    int pro;
private:
    int pri;
};

class PubChild : public Base {
    // pub → public
    // pro → protected
    // pri → 不可访问
};

class ProChild : protected Base {
    // pub → protected
    // pro → protected
    // pri → 不可访问
};

class PriChild : private Base {
    // pub → private
    // pro → private
    // pri → 不可访问
};
```

| 继承方式 | 基类 public | 基类 protected | 基类 private |
|---------|-------------|----------------|--------------|
| public 继承 | public | protected | 不可访问 |
| protected 继承 | protected | protected | 不可访问 |
| private 继承 | private | private | 不可访问 |

**提示**：日常开发中 95% 使用 public 继承，表示 IS-A 关系。

---

### 题 27：什么是菱形继承？如何解决？

**考察点**：多重继承、虚继承

**参考答案**：

菱形继承：一个类通过两条路径继承了同一个基类，导致该基类的成员出现两份拷贝。

```cpp
// 菱形继承问题
class Animal { public: int age; };

class Dog : public Animal {};
class Cat : public Animal {};
class DogCat : public Dog, public Cat {
    // age 有两份：Dog::age 和 Cat::age
};

// 解决：虚继承
class Animal { public: int age; };

class Dog : virtual public Animal {};   // 虚继承
class Cat : virtual public Animal {};   // 虚继承
class DogCat : public Dog, public Cat {
    // age 只有一份
};
```

```cpp
// 使用
DogCat dc;
// dc.age = 10;        // 错误：歧义
dc.Dog::age = 10;       // 不优雅
// 虚继承后：
dc.age = 10;            // OK：只有一份
```

**提示**：虚继承会增加运行时开销（虚基类指针），日常开发中应尽量避免复杂的多重继承。

---

### 题 28：什么是派生类中 hiding（隐藏）和 overriding（覆盖）的区别？

**考察点**：函数隐藏 vs 重写、作用域

**参考答案**：

- **隐藏（hiding）**：派生类定义了和基类同名的函数（不管参数是否相同），基类的同名函数被"隐藏"了
- **覆盖（overriding）**：派生类重写基类的 **virtual** 函数，实现多态

```cpp
class Base {
public:
    void func(int x) { ... }            // 非虚函数
    virtual void vfunc(int x) { ... }   // 虚函数
};

class Derived : public Base {
public:
    void func(int x) { ... }            // 隐藏了 Base::func
    void vfunc(int x) override { ... }  // 覆盖了 Base::vfunc（多态）

    // 隐藏的陷阱：
    void func() { ... }                 // 隐藏了 Base::func(int)！
};

Derived d;
d.func(10);      // 调用 Derived::func(int) —— 隐藏了 Base::func
// 注意：即使参数不同也会隐藏！

// 通过基类指针调用
Base* b = &d;
b->func(10);     // 调用 Base::func（非虚，静态绑定）
b->vfunc(10);    // 调用 Derived::vfunc（虚函数，动态绑定）
```

**提示**：使用 `override` 关键字可以让编译器检查是否真的覆盖了基类的虚函数。

---

## 12. 多态与虚函数

### 题 29：什么是多态？C++ 中如何实现多态？

**考察点**：静态多态 vs 动态多态、虚函数表

**参考答案**：

多态：同一接口在不同类型对象上表现出不同行为。

- **编译时多态（静态多态）**：函数重载、模板
- **运行时多态（动态多态）**：虚函数、继承

```cpp
// 运行时多态（动态多态）—— 通过虚函数实现
class Employee {
public:
    virtual double calcSalary() const = 0;    // 纯虚函数
    virtual void displayInfo() const = 0;
    virtual ~Employee() = default;
};

class FullTimeEmployee : public Employee {
    double calcSalary() const override {
        return baseSalary + bonus;
    }
};

class PartTimeEmployee : public Employee {
    double calcSalary() const override {
        return hourlyRate * hoursWorked;
    }
};

// 多态使用
std::vector<std::shared_ptr<Employee>> employees;
employees.push_back(std::make_shared<FullTimeEmployee>("张三", 8000, 2000));
employees.push_back(std::make_shared<PartTimeEmployee>("李四", 50, 80));

for (const auto& emp : employees) {
    std::cout << emp->calcSalary() << std::endl;  // 多态！
    // 第一次调用 FullTimeEmployee::calcSalary → 8000+2000=10000
    // 第二次调用 PartTimeEmployee::calcSalary → 50*80=4000
}
```

---

### 题 30：虚函数是如何实现的？什么是虚函数表（vtable）？

**考察点**：虚函数表、动态绑定、性能

**参考答案**：

每个包含虚函数的类都有一个**虚函数表（vtable）**——一个存储虚函数地址的数组。每个对象有一个**虚指针（vptr）**指向该类的 vtable。

```
对象的内部布局：
┌─────────────┐
│ vptr        │──→ vtable:
│ 成员变量1   │     [0] → FullTimeEmployee::calcSalary()
│ 成员变量2   │     [1] → FullTimeEmployee::displayInfo()
└─────────────┘     [2] → ~FullTimeEmployee()

虚函数调用流程：
emp->calcSalary()  →  通过 emp 的 vptr 找到 vtable
                   →  从 vtable 中找到 calcSalary 的地址
                   →  调用该地址处的函数
```

```cpp
class Employee {
public:
    virtual double calcSalary() const = 0;   // 在 vtable 中占一个 slot
    virtual void displayInfo() const = 0;    // 另一个 slot
    virtual ~Employee() = default;            // 另一个 slot
};

// 虚函数调用的性能开销：
// 1. 通过 vptr 间接寻址（多一次内存访问）
// 2. 无法内联（运行期才知道调用哪个函数）
// 3. 通常比普通函数调用多 10%-20% 开销
```

**提示**：虚函数表是实现动态多态的底层机制，高频面试题。理解 vptr 和 vtable 的布局是深入 C++ 的关键。

---

### 题 31：纯虚函数和抽象类是什么？

**考察点**：抽象基类、纯虚函数、接口设计

**参考答案**：

纯虚函数是在基类中没有实现的虚函数（`= 0`），包含纯虚函数的类称为抽象类，**不能实例化**。

```cpp
// 抽象类定义了一个接口
class Shape {
public:
    virtual double area() const = 0;           // 纯虚函数
    virtual void draw() const = 0;             // 纯虚函数
    virtual ~Shape() = default;
};

// Shape s;                    // 编译错误！不能实例化抽象类

class Circle : public Shape {
    double radius;
public:
    double area() const override {
        return 3.14159 * radius * radius;
    }
    void draw() const override {
        std::cout << "画一个圆" << std::endl;
    }
};

// 派生类必须实现所有纯虚函数，否则它也是抽象类
class BadCircle : public Shape {
    // 没有实现 area()！
};  // BadCircle 也是抽象类，不能实例化
```

**提示**：纯虚函数使得 C++ 中可以定义"接口"（抽象基类），子类必须实现接口中定义的方法。

---

## 13. 运算符重载

### 题 32：哪些运算符不能重载？运算符重载的基本原则是什么？

**考察点**：运算符重载规则

**参考答案**：

**不能重载的运算符（共 5 个）**：
- `::`（作用域解析）
- `.`（成员访问）
- `.*`（成员指针访问）
- `?:`（三目运算符）
- `sizeof`（类型大小）

**基本原则**：
1. 不改变运算符的优先级和结合性
2. 不改变操作数的个数（一元/二元不变）
3. 不创建新运算符
4. 至少一个操作数是用户定义类型（不能重载 `int + int`）
5. 保持语义合理（不要重载 `+` 做减法）

```cpp
// 推荐用友元实现 << 和 >>
class Complex {
    double real, imag;
public:
    // 重载 + 为成员函数
    Complex operator+(const Complex& other) const {
        return Complex(real + other.real, imag + other.imag);
    }

    // 重载 << 为友元函数（因为左操作数是 ostream，不可改为成员）
    friend std::ostream& operator<<(std::ostream& os, const Complex& c) {
        os << c.real << " + " << c.imag << "i";
        return os;
    }
};
```

---

### 题 33：重载 `operator<<` 为什么要用友元函数？

**考察点**：流运算符、成员 vs 非成员

**参考答案**：

```cpp
class Employee {
    int id;
    std::string name;
public:
    // 如果定义为成员函数：
    // std::ostream& operator<<(std::ostream& os);  // 调用方式：emp << cout

    // 正确的做法：非成员函数 + 友元
    friend std::ostream& operator<<(std::ostream& os, const Employee& emp) {
        os << "ID: " << emp.id << ", Name: " << emp.name;
        return os;
    }
};

// 正确使用
Employee emp;
std::cout << emp;     // 直观！左操作数是 cout，右操作数是 emp
// 如果是成员函数，需要 emp << cout，不符合习惯
```

**原因**：
1. `<<` 的左操作数是 `ostream`，不是 `Employee`，无法作为成员函数
2. 友元可以访问私有成员
3. 保持 `cout << emp` 的自然书写顺序

---

## 14. 类型转换

### 题 34：C++ 四种强制类型转换分别是什么？各自的使用场景？

**考察点**：C++ 类型转换、安全性

**参考答案**：

```cpp
// 1. static_cast —— 编译时检查，最常用
double d = 3.14;
int i = static_cast<int>(d);                   // 数值类型转换
Base* base = static_cast<Base*>(&derived);     // 向上转型（安全）
// 不用于：基类转派生类（应使用 dynamic_cast）

// 2. dynamic_cast —— 运行时检查，用于多态类型安全向下转型
Employee* emp = new Manager();
Manager* mgr = dynamic_cast<Manager*>(emp);   // 安全向下转型
if (mgr) {
    // 转型成功，emp 确实指向 Manager 对象
} else {
    // 转型失败，emp 不是 Manager
}

// 3. const_cast —— 去除 const/volatile 属性
const int* cp = &i;
int* p = const_cast<int*>(cp);                // 移除 const
// 使用场景：调用某个参数为非 const 但实际不会修改的旧 C 函数

// 4. reinterpret_cast —— 重新解释内存，最危险
int* addr = reinterpret_cast<int*>(0x12345678); // 几乎不用
// 用于：特定硬件编程、数据序列化
```

| 转换方式 | 编译期 | 运行时 | 安全 | 使用频率 |
|---------|--------|--------|------|---------|
| static_cast | 检查 | 否 | 较高 | ★★★★★ |
| dynamic_cast | 无 | RTTI 检查 | 高 | ★★★ |
| const_cast | — | — | 危险 | ★★ |
| reinterpret_cast | — | — | 最危险 | ★ |

---

### 题 35：什么是 RTTI？什么时候用到 `typeid`？

**考察点**：运行时类型信息、typeid 运算符

**参考答案**：

RTTI（Run-Time Type Information）是 C++ 的运行时类型识别机制，允许程序在运行时获取对象的实际类型。

```cpp
#include <typeinfo>

class Employee { public: virtual ~Employee() = default; };
class Manager : public Employee {};

Employee* emp = new Manager();

// typeid 获取类型信息
const std::type_info& info = typeid(*emp);
std::cout << info.name() << std::endl;   // 输出：class Manager（具体实现可能不同）

// 类型比较
if (typeid(*emp) == typeid(Manager)) {
    std::cout << "这是一个经理" << std::endl;
}

// 注意：没有虚函数时，typeid 返回的是编译期类型
class Base { };  // 没有虚函数
Base* p = new Base();
typeid(*p) == typeid(Base);   // 总是 true，没有多态
```

**提示**：RTTI 有性能开销（动态_cast 遍历继承链），可以部分禁用（编译选项）。

---

## 15. 异常处理

### 题 36：C++ 异常处理的基本语法是什么？`try`、`catch`、`throw` 如何工作？

**考察点**：异常机制、栈展开

**参考答案**：

```cpp
#include <iostream>
#include <stdexcept>

double divide(int a, int b) {
    if (b == 0) {
        throw std::runtime_error("除数不能为零！");  // 抛出异常
    }
    return static_cast<double>(a) / b;
}

int main() {
    try {
        double result = divide(10, 0);     // 这里会抛出异常
        std::cout << result << std::endl;    // 不会执行到这里
    }
    catch (const std::runtime_error& e) {    // 捕获异常
        std::cout << "捕获异常：" << e.what() << std::endl;
    }
    catch (...) {                            // 捕获所有其他异常（兜底）
        std::cout << "未知异常" << std::endl;
    }
    // 异常被处理后，程序从这里继续执行
    return 0;
}
```

**栈展开（stack unwinding）**：抛出异常时，程序沿调用栈向上搜索匹配的 catch，沿途所有局部对象会被正确析构（RAII 保证资源释放）。

```cpp
void func() {
    std::string str("hello");     // 栈上对象
    std::vector<int> v(100);      // 栈上对象
    throw std::runtime_error("error");
    // 栈展开时，str 和 v 的析构函数会被正确调用
}
```

**提示**：异常捕获应该按"子类在前、基类在后"的顺序，`catch(...)` 放在最后。

---

### 题 37：什么是异常安全？异常安全级别有哪些？

**考察点**：异常安全、资源管理

**参考答案**：

异常安全是指代码在抛出异常时，不泄露资源、不破坏数据完整性。三个级别：

| 级别 | 保证 | 含义 |
|------|------|------|
| 基本保证 | 不泄露资源 | 异常后程序状态一致，但不一定是哪个状态 |
| 强保证 | 操作要么全做、要么不做 | 类似事务（commit/rollback） |
| 不抛异常 | noexcept | 保证不会抛出异常 |

```cpp
// 基本保证示例：使用 RAII 避免资源泄漏
void badFunc() {
    int* p = new int[100];
    // 如果中间抛出异常，p 不会被释放 → 内存泄漏！
    doSomething();     // 可能抛出异常
    delete[] p;
}

void goodFunc() {
    std::vector<int> v(100);   // RAII：离开作用域自动释放
    doSomething();              // 即使异常，v 也会被正确析构
}

// 不抛异常声明
void safeFunc() noexcept {
    // 承诺不会抛出异常
    // 如果实际抛出，程序会直接终止（调用 std::terminate）
}
```

**提示**：移动构造函数通常声明为 `noexcept`，这样 `std::vector` 扩容时才会用移动而非拷贝。

---

### 题 38：`noexcept` 关键字的作用是什么？

**考察点**：异常说明、移动语义

**参考答案**：

`noexcept` 声明一个函数不会抛出异常。编译器可以利用这一点进行优化。

```cpp
// noexcept 声明
void func() noexcept;           // 保证不抛异常
void func() noexcept(false);    // 可能抛异常（默认行为）

// 移动构造函数通常应为 noexcept
class String {
    char* data;
public:
    String(String&& other) noexcept
        : data(other.data)
    {
        other.data = nullptr;
    }
};

// noexcept 的重要性：vector 扩容时
// 如果移动构造是 noexcept：用移动操作（高效）
// 如果移动构造可能抛异常：用拷贝操作（安全但慢）
std::vector<String> v;
v.push_back(String("hello"));  // 扩容时依赖移动构造的 noexcept

// 条件 noexcept
template<typename T>
void swap(T& a, T& b) noexcept(std::is_nothrow_swappable_v<T>) {
    // 只有当 T 的 swap 是 noexcept 时，此函数才是 noexcept
}
```

**提示**：移动构造函数、`swap` 函数、析构函数通常声明为 `noexcept`。

---

> 基础篇结束，进阶请移步 [C++_面试题_进阶篇.md](C++_面试题_进阶篇.md)
