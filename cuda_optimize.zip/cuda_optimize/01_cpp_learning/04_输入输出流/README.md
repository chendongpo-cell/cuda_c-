# 04 输入输出流

## 1. 直观理解

### 什么是"流"（Stream）？

C++ 把输入输出抽象为**流**——数据像水流一样从一个地方流到另一个地方。无论是键盘输入、屏幕输出、文件读写、网络传输，都用同一套"流"的接口。

这背后的设计思想是**多态**和**继承**——所有具体的流（控制台、文件、字符串）都继承自共同的基类。你学会操作 `cout`，就基本学会了操作所有输出流。

---

## 2. 语法速查

### 四个标准流对象

| 对象 | 全称 | 方向 | 缓冲 | 用途 |
|------|------|------|------|------|
| `cin` | Console Input | 键盘 → 程序 | 有 | 标准输入 |
| `cout` | Console Output | 程序 → 屏幕 | 有 | 标准输出 |
| `cerr` | Console Error | 程序 → 屏幕 | **无缓冲** | 错误信息（立即显示） |
| `clog` | Console Log | 程序 → 屏幕 | 有 | 日志信息 |

### 输出（cout）

```cpp
#include <iostream>

cout << "Hello";              // 输出字符串
cout << 42;                   // 输出数字
cout << 3.14;                 // 输出浮点
cout << "A=" << a << endl;   // 连续输出
```

### 输入（cin）

```cpp
int age;
cin >> age;                   // 读取一个整数

double price;
cin >> price;                 // 读取一个浮点数

string name;
cin >> name;                  // 读取一个单词（遇空格/换行停止）

// 读取一行（包含空格）：
string line;
getline(cin, line);

// 连续读取：
cin >> a >> b >> c;
```

### 格式化输出（需要 `<iomanip>`）

```cpp
#include <iomanip>

// 设置字段宽度（只对下一次输出生效）
cout << setw(10) << 123;      // "       123"

// 设置浮点精度
cout << fixed << setprecision(2) << 3.14159;  // "3.14"

// 科学计数法
cout << scientific << 1234567.89;  // "1.234568e+06"

// 布尔值显示 true/false 而非 1/0
cout << boolalpha << true;    // "true"

// 左对齐
cout << left << setw(10) << 123;  // "123       "

// 填充字符
cout << setfill('0') << setw(8) << 123;  // "00000123"

// 正数显示 + 号
cout << showpos << 42;        // "+42"
```

| 操控符 | 作用 | 持久性 |
|--------|------|--------|
| `setw(n)` | 字段宽度 | 只对下一次输出有效 |
| `setprecision(n)` | 精度 | 持久有效 |
| `fixed` | 固定小数格式 | 持久有效 |
| `scientific` | 科学计数法 | 持久有效 |
| `setfill(c)` | 填充字符 | 持久有效 |
| `left` / `right` | 对齐方式 | 持久有效 |
| `boolalpha` / `noboolalpha` | 布尔格式 | 持久有效 |
| `showpos` / `noshowpos` | 正号 | 持久有效 |
| `hex` / `oct` / `dec` | 进制 | 持久有效 |

---

## 3. 底层原理

### 流的继承体系

所有流都继承自一套共同的基类：

```
              ios_base
                 ↑
               ios
           ↙         ↘
     istream          ostream
    (输入流)          (输出流)
        ↑                ↑
        └──────┬────────┘
               ↓
           iostream
          (输入输出流)
```

- `cin` 是 `istream` 类型的全局对象
- `cout`/`cerr`/`clog` 是 `ostream` 类型的全局对象
- `fstream`（文件流）和 `stringstream`（字符串流）也继承自这些基类

所以你对 `cout << x` 和 `cin >> x` 的理解，可以直接迁移到文件操作。

### `<<` / `>>` 的重载机制

```cpp
// operator<< 对每种类型都有重载：
ostream& operator<<(ostream& os, int val);
ostream& operator<<(ostream& os, double val);
ostream& operator<<(ostream& os, const char* str);
ostream& operator<<(ostream& os, const string& str);
// ... 几十种类型的重载

// operator>> 同理：
istream& operator>>(istream& is, int& val);
istream& operator>>(istream& is, double& val);
// 注意参数是非 const 引用——因为要修改传入的变量
```

因为 `<<` 返回 `ostream&`，你可以链式调用；因为接收 `ostream&`，你可以把 `cout`、文件输出流、字符串流传入同一个函数。

### 缓冲区与刷新

输出流有一个内部缓冲区。你写入的数据先进入这个缓冲区，缓冲区满了（或遇到 `endl` / `flush` / 程序结束）才会真正写入输出设备：

```
cout << "Hello"           // "Hello" 进入缓冲区（不一定会立即显示）
cout << endl;             // 写入 '\n' + 刷新缓冲区（立即显示）
```

- `endl`：写 `\n` + `flush()`（强制刷新）→ 有系统调用开销
- `\n`：只写换行符，缓冲区满时自动刷新 → 无额外开销
- `flush`：只刷新，不写换行符

**性能影响**：循环中大量用 `endl` 可能慢 10-100 倍：

```cpp
// 慢：每行都刷新
for (int i = 0; i < 1000000; i++)
    cout << i << endl;

// 快：只换行不刷新，最后统一刷新
for (int i = 0; i < 1000000; i++)
    cout << i << '\n';
cout << flush;
```

> 调试时用 `endl`（确保崩溃前能看到输出），正式代码用 `\n`。

### cin 的错误状态

`cin` 读取失败时会设置内部状态标志：

| 标志 | 含义 |
|------|------|
| `goodbit` | 一切正常（值为 0） |
| `failbit` | 读取失败（格式不对，如要求整数却输入了字母），流未损坏 |
| `badbit` | 严重错误（流已损坏，通常不可恢复） |
| `eofbit` | 到达输入末尾（EOF） |

```cpp
int x;
cin >> x;

if (cin.good()) {
    // 读取成功
} else if (cin.fail()) {
    // 格式错误
    cin.clear();              // 清除错误状态
    cin.ignore(10000, '\n');  // 丢弃缓冲区中的错误输入
} else if (cin.bad()) {
    // 严重错误，流已损坏
}
```

### 为什么 `scanf` / `printf` 比 `cin` / `cout` 快？

默认情况下，C++ 的 `cin`/`cout` 和 C 的 `scanf`/`printf` 是**同步**的——这意味着你可以混用它们而不出问题。但同步有性能开销。

```cpp
// 关闭与 C 标准 I/O 的同步，让 cin/cout 加速：
ios_base::sync_with_stdio(false);
cin.tie(nullptr);  // 同时解开 cin 和 cout 的绑定

// 之后不要混用 cin/cout 和 scanf/printf！
```

竞赛编程中这两行几乎是标配，速度可提升数倍。

---

## 4. 深入细节

### `cin >>` 的空白字符处理

`>>` 运算符默认跳过前导空白（空格、制表符、换行），然后读取数据直到遇到下一个空白：

```cpp
int x;
char c;
cin >> x >> c;
// 输入 "  42   A" → x=42, c='A'（中间的空白被跳过了）
```

如果不想跳过空白（比如读取单个字符时）：

```cpp
cin >> noskipws;    // 不跳过空白
char c;
cin >> c;           // 现在空格也会被读入
cin >> skipws;      // 恢复默认
```

### mixed cin >> and getline 的坑

这是新手最常见的问题之一：

```cpp
int age;
string name;

cout << "输入年龄: ";
cin >> age;                 // 读取 25，但 "\n" 留在缓冲区

cout << "输入姓名: ";
getline(cin, name);        // 立即读到残留的 "\n"，返回空字符串！
```

**修复**：在 `cin >>` 后消费掉换行符：

```cpp
cin >> age;
cin.ignore(10000, '\n');   // 丢弃直到换行符（包括换行符本身）
getline(cin, name);        // 现在正确读取姓名
```

### `setw` 的安全用途——防止缓冲区溢出

```cpp
char buffer[10];
cin >> setw(10) >> buffer;  // 最多读 9 个字符（留 1 个给 '\0'）
```

---

## 5. C++ vs Python 对照

```python
# Python
name = input("输入姓名: ")        # 读取一行
age = int(input("输入年龄: "))    # 读取并转换

print("Hello", name)              # 空格分隔，自动换行
print(f"{name}: {age}")           # 格式化字符串

print("Hello", end="")            # 不换行
print("A", "B", sep="|")          # 自定义分隔符
```

```cpp
// C++
string name;
cout << "输入姓名: ";
getline(cin, name);

int age;
cout << "输入年龄: ";
cin >> age;

cout << "Hello " << name << endl;
cout << name << ": " << age << endl;
```

| 方面 | Python | C++ |
|------|--------|-----|
| 输出 | `print()` 函数，自动换行 | `cout <<`，手动 `endl`/`\n` |
| 输入 | `input()` 返回字符串，自己转换 | `cin >>` 直接按类型读取 |
| 格式化 | f-string `f"{x:.2f}"` | `<iomanip>` 操控符 |
| 读取一行 | `input()` 默认就是读一行 | `getline(cin, str)` |
| 缓冲控制 | `print(flush=True)` | `cout << flush` 或 `cout << endl` |
| 错误处理 | 抛异常 | 设置状态标志（`failbit` 等） |

---

## 6. 练习与思考

### 基础练习

1. 从键盘读取一个整数和一个小数，用 `fixed` + `setprecision(2)` 格式化输出它们的乘积
2. 读取用户的姓名和年龄（一行输入），输出 `"XXX 的年龄是 XX 岁"`
3. 用 `setw` + `setfill` 打印一个靠右对齐的数字表格

### 思考题

4. 测试 `cin >> int` 当输入不是整数时会发生什么？如何处理错误输入？（用 `cin.clear()` 和 `cin.ignore()`）
5. `cin >>` 和 `getline()` 混用时的换行符残留问题如何解决？
6. 测试 `ios_base::sync_with_stdio(false)` 对大量 I/O 的性能影响（分别用 `cin`/`cout` 和 `scanf`/`printf` 读写 100 万个数字）
7. 为什么标准错误流 `cerr` 是无缓冲的？设计意图是什么？

> 参考阅读：[编译链接模型](../docs/00_编译链接模型.md) —— `iostream` 是标准库的一部分，链接时自动连接
