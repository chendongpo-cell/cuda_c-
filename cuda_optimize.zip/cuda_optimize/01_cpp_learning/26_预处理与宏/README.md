# 26 - 预处理与宏 (Preprocessor & Macros)

## 什么是预处理器？

预处理器（preprocessor）是编译的第一个阶段。它在编译器真正编译之前对源代码进行**文本处理**。所有以 `#` 开头的行都是预处理指令。

```
源代码 → 预处理器 → 编译器 → 汇编器 → 链接器
```

预处理器**不是 C++ 编译器的一部分**，它只是纯粹的文本替换工具。

## 常用预处理指令

| 指令 | 用途 |
|---|---|
| `#include` | 包含头文件 |
| `#define` | 定义宏（常量或函数式宏） |
| `#undef` | 取消宏定义 |
| `#ifdef` / `#ifndef` | 判断宏是否（未）定义 |
| `#if` / `#else` / `#elif` / `#endif` | 条件编译 |
| `#pragma` | 编译器特定指令 |
| `#error` | 编译时输出错误信息 |
| `#line` | 改变行号和文件名信息 |

## #define — 定义宏

### 对象式宏 (Object-like Macro)

```cpp
#define PI 3.1415926535
#define MAX_BUFFER_SIZE 1024
#define FILE_PATH "data.txt"
```

预处理后，代码中所有 `PI` 都会被替换为 `3.1415926535`。

### 函数式宏 (Function-like Macro)

```cpp
#define SQUARE(x) ((x) * (x))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
```

**注意**：每个参数和整个表达式都要加括号，否则会有优先级问题。

### 宏的陷阱

```cpp
#define SQUARE(x) x * x
SQUARE(1 + 2)  // 被展开为 1 + 2 * 1 + 2 = 5  ❌
// 正确做法:  #define SQUARE(x) ((x) * (x))

#define MULTI_LINE_MACRO \
    do { \
        something(); \
    } while(0)
```

## #undef — 取消宏定义

```cpp
#define TEMP 100
// ... 使用 TEMP ...
#undef TEMP    // 取消定义
// TEMP 不再可用
```

## 条件编译

### #ifdef / #ifndef

```cpp
#ifdef DEBUG
    cout << "调试信息: x = " << x << endl;
#endif

#ifndef NDEBUG
    // 调试模式下的断言
#endif
```

### #if / #else / #elif

```cpp
#if __cplusplus >= 201703L
    cout << "C++17 或更高版本" << endl;
#elif __cplusplus >= 201402L
    cout << "C++14" << endl;
#else
    cout << "C++11 或更早" << endl;
#endif
```

### 常见用途：调试/发布切换

```cpp
#define DEBUG_LEVEL 2

#if DEBUG_LEVEL >= 1
    // 基本调试信息
#endif
#if DEBUG_LEVEL >= 2
    // 详细调试信息
#endif
```

## 包含守卫 (Include Guards)

防止头文件被多次包含，导致重定义错误。

### 传统方式 (#ifndef)

```cpp
// myheader.h
#ifndef MYHEADER_H
#define MYHEADER_H

// 头文件内容...

#endif // MYHEADER_H
```

### #pragma once（现代、简洁）

```cpp
// myheader.h
#pragma once

// 头文件内容...
```

`#pragma once` 由编译器保证文件只被包含一次，更简洁、不易出错，但不是 C++ 标准（但所有主流编译器都支持）。

## 预定义宏

| 宏 | 含义 |
|---|---|
| `__FILE__` | 当前文件名 (string) |
| `__LINE__` | 当前行号 (int) |
| `__DATE__` | 编译日期 (string, 格式 "Mmm dd yyyy") |
| `__TIME__` | 编译时间 (string, 格式 "hh:mm:ss") |
| `__cplusplus` | C++ 标准版本号 (int) |
| `__STDC__` | 是否为标准 C 环境 (int) |
| `__func__` | 当前函数名 (C++11 起，不是宏) |

### __cplusplus 的值

| 值 | 标准 |
|---|---|
| `199711L` | C++98/03 |
| `201103L` | C++11 |
| `201402L` | C++14 |
| `201703L` | C++17 |
| `202002L` | C++20 |

## 宏 vs 内联函数 / constexpr

在现代 C++ 中，许多宏的用途已被更好的语言特性替代：

| 用途 | 宏 | 现代替代 |
|---|---|---|
| 常量 | `#define PI 3.14` | `constexpr double PI = 3.14;` |
| 小型函数 | `#define SQUARE(x) ((x)*(x))` | `constexpr auto square(auto x) { return x * x; }` |
| 类型无关 | 宏 | `template` / `auto` |
| 调试输出 | `#ifdef DEBUG` | `if constexpr (debug_mode)` |

但预处理器在以下场景仍然不可替代：
- 包含守卫 (`#pragma once`)
- 条件编译（跨平台代码）
- 获取 `__FILE__`/`__LINE__` 等编译信息
