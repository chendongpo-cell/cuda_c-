/*
 * 文件名: main.cpp
 * 功能:   演示 C++ 预处理与宏的各种用法
 * 编译:   g++ -std=c++17 main.cpp -o main
 *         g++ -DDEBUG -std=c++17 main.cpp -o main   (启用调试模式)
 *
 * 包含:
 *   1. 定义常量宏 (#define)
 *   2. 函数式宏 (#define 带参数)
 *   3. 条件编译 (DEBUG / RELEASE 切换)
 *   4. 包含守卫演示 (在 main.cpp 中模拟头文件)
 *   5. 预定义宏输出
 *   6. 宏的陷阱演示
 *   7. #undef 取消宏定义
 */

#include <iostream>   // 标准输入输出头文件

// ============ 第1部分: 定义常量宏 ============

// 使用 #define 定义常量宏
// 预处理时，代码中所有的 PI 会被替换为 3.1415926535
#define PI 3.1415926535

// 定义最大缓冲区大小宏
#define MAX_BUFFER 1024

// 定义应用版本号宏
#define VERSION "1.0.0"

// 定义项目名称宏
#define PROJECT_NAME "C++ Preprocessor Demo"

// ============ 第2部分: 定义函数式宏 ============

// 注意: 函数式宏的参数和整个表达式都要加括号，避免优先级问题
// 求平方的宏: 每个参数加括号，整体也加括号
#define SQUARE(x) ((x) * (x))

// 求两个值中较大者的宏
#define MAX(a, b) ((a) > (b) ? (a) : (b))

// 求两个值中较小者的宏
#define MIN(a, b) ((a) < (b) ? (a) : (b))

// 带多条语句的宏: 使用 do { ... } while(0) 包裹
// 这样宏在使用时像普通函数一样，不会和作用域冲突
#define SAFE_DELETE(p) \
    do {               \
        if (p) {       \
            delete p;  \
            p = nullptr; \
        }              \
    } while(0)

// 打印调试信息的宏 (条件编译，见下方 DEBUG 部分)
#ifdef DEBUG
    // 如果定义了 DEBUG 宏，则 LOG_DEBUG 会输出调试信息
    #define LOG_DEBUG(msg) \
        do { \
            std::cout << "[DEBUG] " << __FILE__ \
                      << ":" << __LINE__ << " - " \
                      << msg << std::endl; \
        } while(0)
#else
    // 如果没有定义 DEBUG 宏，则 LOG_DEBUG 被替换为空
    // 预处理器会去掉这个宏，不会生成任何代码
    #define LOG_DEBUG(msg)
#endif

// ============ 第3部分: 条件编译 ============

// 定义平台相关的宏
// 在实际项目中，这些通常由编译器自动定义或在编译命令中指定
// 例如: g++ -DWINDOWS main.cpp  会定义 WINDOWS 宏
// 这里我们手动注释/取消注释来演示

// 取消下面行的注释，模拟 Windows 平台
// #define WINDOWS

// 取消下面行的注释，模拟 Linux 平台
#define LINUX

// 条件编译: 根据不同平台定义不同的换行符
#if defined(WINDOWS)
    // Windows 使用 \r\n 作为换行符
    #define NEWLINE "\r\n"
    #define PLATFORM_NAME "Windows"
#elif defined(LINUX)
    // Linux 使用 \n 作为换行符
    #define NEWLINE "\n"
    #define PLATFORM_NAME "Linux"
#else
    // 未知平台
    #define NEWLINE "\n"
    #define PLATFORM_NAME "Unknown"
#endif

// 定义调试级别宏
// 0 = 无调试, 1 = 基本调试, 2 = 详细调试
#define DEBUG_LEVEL 2

// 根据调试级别条件编译
#if DEBUG_LEVEL >= 1
    // 基本调试输出
    #define LOG_BASIC(msg) std::cout << "[BASIC] " << msg << std::endl
#else
    #define LOG_BASIC(msg)
#endif

#if DEBUG_LEVEL >= 2
    // 详细调试输出
    #define LOG_VERBOSE(msg) std::cout << "[VERBOSE] " << msg << std::endl
#else
    #define LOG_VERBOSE(msg)
#endif

// 使用 #warning 编译时警告 (取消注释即可看到效果)
// #warning "This is a compile-time warning!"

// ============ 第4部分: 模拟包含守卫 ============

// 在真实项目中，以下代码通常放在头文件 (如 config.h) 中
// 这里我们在 main.cpp 中模拟，展示包含守卫的写法

// 包含守卫: 防止同一个头文件被多次包含
// 第一次包含时，CONFIG_H 未定义，进入 #ifndef 块
// 第二次包含时，CONFIG_H 已定义，跳过整个内容
#ifndef CONFIG_H
#define CONFIG_H   // 定义守卫宏，防止重复包含

// 这些是"头文件"中的内容
namespace Config {
    // 应用配置常量
    const int    MAX_USERS = 100;
    const double TIMEOUT   = 30.0;
}

#endif // CONFIG_H  包含守卫结束

// ============ 第5部分: #undef 取消宏 ============

// #undef 用于取消之前定义的宏
// 取消后，宏名称不再可用

// 定义一个临时宏
#define TEMP_VALUE 42

// 取消宏定义
#undef TEMP_VALUE
// 从此以后，TEMP_VALUE 不再被定义
// 如果再使用 TEMP_VALUE，会在编译时报错

// ============ 第6部分: 宏陷阱演示 ============

// 演示不正确使用宏会导致的问题

// 陷阱宏: 参数没有加括号
// 这会导致优先级错误！
#define BAD_SQUARE(x) x * x

// 陷阱宏: 多参数没有正确分组
#define BAD_MIN(a, b) a < b ? a : b

// ============ 第7部分: 主函数 ============

// 统一使用 std:: 前缀，避免混淆
int main() {
    // ============ 演示1: 常量宏 ============
    std::cout << "=== 1. 常量宏 ===" << std::endl;

    // PI 被预处理器替换为 3.1415926535
    std::cout << "PI = " << PI << std::endl;

    // MAX_BUFFER 被替换为 1024
    std::cout << "MAX_BUFFER = " << MAX_BUFFER << std::endl;

    // VERSION 和 PROJECT_NAME 是字符串宏
    std::cout << "项目: " << PROJECT_NAME << " v" << VERSION << std::endl;

    std::cout << std::endl;

    // ============ 演示2: 函数式宏 ============
    std::cout << "=== 2. 函数式宏 ===" << std::endl;

    int x = 5, y = 10;

    // SQUARE(5) 展开为 ((5) * (5)) = 25
    std::cout << "SQUARE(" << x << ") = " << SQUARE(x) << std::endl;

    // MAX(5, 10) 展开为 ((5) > (10) ? (5) : (10)) = 10
    std::cout << "MAX(" << x << ", " << y << ") = " << MAX(x, y) << std::endl;

    // MIN(5, 10) 展开为 ((5) < (10) ? (5) : (10)) = 5
    std::cout << "MIN(" << x << ", " << y << ") = " << MIN(x, y) << std::endl;

    std::cout << std::endl;

    // ============ 演示3: 宏的陷阱 ============
    std::cout << "=== 3. 宏的陷阱 ===" << std::endl;

    // 正确使用 SQUARE:
    std::cout << "SQUARE(1 + 2) = " << SQUARE(1 + 2) << std::endl;
    // SQUARE(1+2) 展开为 ((1+2) * (1+2)) = 9 (正确)

    // 错误使用 BAD_SQUARE:
    std::cout << "BAD_SQUARE(1 + 2) = " << BAD_SQUARE(1 + 2) << std::endl;
    // BAD_SQUARE(1+2) 展开为 1 + 2 * 1 + 2 = 1 + 2 + 2 = 5 (错误!)
    // 因为乘法优先级高于加法

    // 另一个陷阱: BAD_MIN
    int a = 10, b = 20, c = 30;

    // 正确使用 MIN:
    std::cout << "MIN(" << a << ", " << b << ") = "
              << MIN(a, b) << std::endl;          // 输出 10，正确

    // 错误使用 BAD_MIN 在三目表达式中:
    int result = BAD_MIN(a, b) + c;
    // BAD_MIN 展开为 a < b ? a : b + c
    // 实际: 10 < 20 ? 10 : 20 + 30 → 10 (因为 ?: 优先级低于 +)
    // 期望: 10 + 30 = 40
    std::cout << "BAD_MIN(" << a << ", " << b << ") + " << c << " = "
              << result << " (预期 40, 实际错误!)" << std::endl;

    std::cout << std::endl;

    // ============ 演示4: 条件编译 ============
    std::cout << "=== 4. 条件编译 ===" << std::endl;

    // 根据平台输出不同的信息
    std::cout << "当前平台: " << PLATFORM_NAME << std::endl;
    std::cout << "换行符类型: \""
              << NEWLINE << "\" (不可见字符)" << std::endl;

    // 根据调试级别输出
    LOG_BASIC("这是基本调试信息");     // DEBUG_LEVEL >= 1 时输出
    LOG_VERBOSE("这是详细调试信息");   // DEBUG_LEVEL >= 2 时输出
    // 注意: 这行无论如何都会输出
    std::cout << "主程序正常运行..." << std::endl;

    std::cout << std::endl;

    // ============ 演示5: 调试宏 ============
    std::cout << "=== 5. 调试宏 ===" << std::endl;

    // 如果在编译时加上 -DDEBUG 参数
    // 例如: g++ -DDEBUG main.cpp
    // 则 LOG_DEBUG 会输出文件、行号、消息
    //
    // 如果编译时没有 -DDEBUG
    // 则 LOG_DEBUG 展开为空，什么也不做
    LOG_DEBUG("程序已启动");
    LOG_DEBUG("x = " << x << ", y = " << y);

    std::cout << std::endl;

    // ============ 演示6: 预定义宏 ============
    std::cout << "=== 6. 预定义宏 ===" << std::endl;

    // __FILE__: 当前源文件名 (字符串)
    std::cout << "__FILE__    = " << __FILE__ << std::endl;

    // __LINE__: 当前行号 (整数)
    std::cout << "__LINE__    = " << __LINE__ << std::endl;

    // __DATE__: 编译日期
    std::cout << "__DATE__    = " << __DATE__ << std::endl;

    // __TIME__: 编译时间
    std::cout << "__TIME__    = " << __TIME__ << std::endl;

    // __cplusplus: C++ 标准版本
    std::cout << "__cplusplus = " << __cplusplus << std::endl;

    // 根据 __cplusplus 判断 C++ 标准版本
    #if __cplusplus >= 201703L
        std::cout << "编译标准: C++17 或更高" << std::endl;
    #elif __cplusplus >= 201402L
        std::cout << "编译标准: C++14" << std::endl;
    #elif __cplusplus >= 201103L
        std::cout << "编译标准: C++11" << std::endl;
    #else
        std::cout << "编译标准: C++98/03" << std::endl;
    #endif

    // __func__: 当前函数名 (C++11 起，不是宏，但类似)
    std::cout << "__func__    = " << __func__ << std::endl;

    std::cout << std::endl;

    // ============ 演示7: #undef ============
    std::cout << "=== 7. #undef 取消宏 ===" << std::endl;

    // 下面这行如果取消注释，会导致编译错误
    // 因为 TEMP_VALUE 已经被 #undef 取消了
    // std::cout << "TEMP_VALUE = " << TEMP_VALUE << std::endl;
    std::cout << "TEMP_VALUE 已被 #undef 取消，如使用会编译错误" << std::endl;

    std::cout << std::endl;

    // ============ 演示8: 宏的实用性 ============
    std::cout << "=== 8. 实用技巧: 带行号的断言 ===" << std::endl;

    // 定义一个带有文件和行号信息的条件检查宏
    #define ASSERT(cond, msg) \
        do { \
            if (!(cond)) { \
                std::cerr << "断言失败: " << #cond << std::endl; \
                std::cerr << "  文件: " << __FILE__ << std::endl; \
                std::cerr << "  行号: " << __LINE__ << std::endl; \
                std::cerr << "  信息: " << msg << std::endl; \
            } \
        } while(0)

    // # 运算符将宏参数转为字符串字面量
    // 比如 #cond 将 cond 替换为字符串 "cond"

    // 测试断言 (条件成立，不会触发)
    ASSERT(1 + 1 == 2, "数学定律");
    // 测试断言 (条件不成立，会输出错误信息)
    ASSERT(1 + 1 == 3, "这不可能");

    std::cout << std::endl;

    // ============ 演示9: include 守卫验证 ============
    std::cout << "=== 9. 包含守卫 ===" << std::endl;

    // 验证 Config 命名空间中的常量可用
    std::cout << "Config::MAX_USERS = " << Config::MAX_USERS << std::endl;
    std::cout << "Config::TIMEOUT   = " << Config::TIMEOUT << std::endl;

    std::cout << std::endl;

    std::cout << "程序执行完毕!" << std::endl;
    return 0;   // main 函数返回 0，表示程序成功结束
}
