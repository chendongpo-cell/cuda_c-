// Dog.h
// 狗类的头文件，声明 Dog 类的接口
// Dog 公开继承自 Animal，拥有 Animal 的所有公有成员
#ifndef DOG_H  // 如果没有定义 DOG_H 宏
#define DOG_H  // 定义 DOG_H 宏，防止重复包含

// 包含 Animal 类的头文件，因为 Dog 类继承自 Animal 类
#include "Animal.h"
// 包含字符串头文件，以便使用 std::string 类型
#include <string>

// 使用标准命名空间
using namespace std;

// ---- 派生类（子类）：Dog ----
// Dog 公开继承自 Animal，拥有 Animal 的所有公有成员
// public 继承方式：父类的 public 成员在子类中仍然是 public
class Dog : public Animal {
public:
    // 子类特有的成员变量：品种
    // 表示这只狗的品种，例如金毛、拉布拉多等
    string breed;

    // 子类的构造函数
    // 在初始化列表中调用父类的构造函数，传递必要的参数
    // 参数 n 是名称，参数 a 是年龄，参数 b 是品种
    Dog(string n, int a, string b);

    // 子类的析构函数
    // 当 Dog 对象销毁时自动调用
    ~Dog();

    // 重写（Override）父类的 makeSound 方法
    // 子类可以重新定义父类已有的函数
    // override 关键字明确表示这是一个重写操作
    void makeSound() override;

    // 子类特有的成员函数：摇尾巴
    // 只有狗才能摇尾巴，这是狗特有的行为
    void wagTail();

    // 子类特有的成员函数：看门
    // 只有狗才能看门，这是狗特有的行为
    void guard();
};

#endif  // 结束条件编译指令
