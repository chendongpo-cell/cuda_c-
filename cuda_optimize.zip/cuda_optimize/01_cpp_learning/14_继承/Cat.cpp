// Cat.cpp
// 猫类的实现文件，包含 Cat 类所有成员函数的实现代码
// Cat 类继承自 Animal 类，添加了猫特有的属性和行为

// 包含 Cat 类的头文件
#include "Cat.h"
// 包含输入输出流头文件
#include <iostream>

// 使用标准命名空间
using namespace std;

// 子类构造函数，通过初始化列表调用父类构造函数
// 在初始化列表中调用 Animal 类的构造函数，传递名称和年龄参数
// 然后初始化子类特有的 likesScratching 成员变量
Cat::Cat(string n, int a, bool scratch) : Animal(n, a) {
    // 初始化子类特有的成员变量 likesScratching
    likesScratching = scratch;
    // 输出提示信息，表示 Cat 构造函数被调用
    cout << "Cat 构造函数被调用" << endl;
}

// 子类析构函数
// 当 Cat 对象销毁时自动调用
Cat::~Cat() {
    // 输出提示信息，表示 Cat 析构函数被调用
    cout << "Cat 析构函数被调用" << endl;
}

// 重写父类的 makeSound 方法
// 实现猫特有的叫声行为
void Cat::makeSound() {
    // 输出猫特有的叫声
    // name 是从 Animal 类继承来的成员变量
    cout << name << " 喵喵叫！" << endl;
}

// 子类特有的成员函数：抓老鼠
// 这是 Cat 类独有的方法，Animal 基类中没有
void Cat::catchMouse() {
    // 输出当前猫正在抓老鼠的信息
    cout << name << " 正在抓老鼠..." << endl;
}
