// Dog.cpp
// 狗类的实现文件，包含 Dog 类所有成员函数的实现代码
// Dog 类继承自 Animal 类，添加了狗特有的属性和行为

// 包含 Dog 类的头文件
#include "Dog.h"
// 包含输入输出流头文件
#include <iostream>

// 使用标准命名空间
using namespace std;

// 子类的构造函数
// 在初始化列表中调用父类的构造函数，传递名称和年龄参数
// 然后初始化子类特有的 breed 成员变量
Dog::Dog(string n, int a, string b) : Animal(n, a) {
    // 初始化子类特有的成员变量 breed
    breed = b;
    // 输出提示信息，表示 Dog 构造函数被调用
    cout << "Dog 构造函数被调用" << endl;
}

// 子类的析构函数
// 当 Dog 对象销毁时自动调用
Dog::~Dog() {
    // 输出提示信息，表示 Dog 析构函数被调用
    cout << "Dog 析构函数被调用" << endl;
}

// 重写（Override）父类的 makeSound 方法
// 子类可以重新定义父类已有的函数，实现多态行为
void Dog::makeSound() {
    // 输出狗特有的叫声
    // name 是从 Animal 类继承来的成员变量
    cout << name << " 汪汪叫！" << endl;
}

// 子类特有的成员函数：摇尾巴
// 这是 Dog 类独有的方法，Animal 基类中没有
void Dog::wagTail() {
    // 输出当前狗正在摇尾巴的信息
    cout << name << " 正在摇尾巴..." << endl;
}

// 子类特有的成员函数：看门
// 这是 Dog 类独有的方法，Animal 基类中没有
void Dog::guard() {
    // 输出当前狗正在看门的信息
    cout << name << " 正在看门..." << endl;
}
