// 多文件演示：继承体系拆分为多个.h/.cpp
// 本程序演示 C++ 中继承的概念和用法，使用多文件项目结构

// 包含 Animal 类的头文件，使用 Animal 基类
#include "Animal.h"
// 包含 Dog 类的头文件，使用 Dog 派生类
#include "Dog.h"
// 包含 Cat 类的头文件，使用 Cat 派生类
#include "Cat.h"
// 包含输入输出流头文件
#include <iostream>
// 包含字符串头文件
#include <string>

// 使用标准命名空间
using namespace std;

// ---- 多层继承演示 ----
// 定义 WorkDog 类，继承自 Dog，形成多层继承链：Animal -> Dog -> WorkDog
// 由于 WorkDog 只在主函数中使用，所以直接定义在此文件中，不必单独拆分为文件

// WorkDog 继承自 Dog，因此继承了 Animal 和 Dog 的所有成员
class WorkDog : public Dog {
public:
    // 工作犬特有的成员变量：工作类型
    // 表示这只工作犬执行的任务类型，例如搜救、导盲等
    string workType;

    // 构造函数
    // 通过初始化列表调用 Dog 的构造函数，由 Dog 再调用 Animal 的构造函数
    WorkDog(string n, int a, string b, string w) : Dog(n, a, b) {
        // 初始化子类特有的成员变量 workType
        workType = w;
        // 输出提示信息，表示 WorkDog 构造函数被调用
        cout << "WorkDog 构造函数被调用" << endl;
    }

    // 析构函数
    // 当 WorkDog 对象销毁时自动调用
    ~WorkDog() {
        // 输出提示信息，表示 WorkDog 析构函数被调用
        cout << "WorkDog 析构函数被调用" << endl;
    }

    // 工作犬特有的成员函数：工作
    // 输出工作犬正在执行特定任务的信息
    void work() {
        // 输出当前工作犬正在执行的任务类型
        // name 是从 Animal 继承来的，workType 是 WorkDog 自己的
        cout << name << " 正在执行" << workType << "任务..." << endl;
    }
};

// ---- 多继承演示 ----
// 定义 Flyable 类，表示可以飞的能力
// 这是一个独立的类，用于多继承演示
class Flyable {
public:
    // 飞行方法
    // 输出正在飞行的信息
    void fly() {
        cout << "正在飞行..." << endl;
    }
};

// 定义 Swimmable 类，表示可以游泳的能力
// 这是一个独立的类，用于多继承演示
class Swimmable {
public:
    // 游泳方法
    // 输出正在游泳的信息
    void swim() {
        cout << "正在游泳..." << endl;
    }
};

// Duck 继承了 Animal 以及 Flyable 和 Swimmable
// 这就是多继承：一个子类有多个父类
class Duck : public Animal, public Flyable, public Swimmable {
public:
    // 构造函数
    // 通过初始化列表调用 Animal 类的构造函数
    Duck(string n, int a) : Animal(n, a) {
        // 输出提示信息，表示 Duck 构造函数被调用
        cout << "Duck 构造函数被调用" << endl;
    }

    // 析构函数
    // 当 Duck 对象销毁时自动调用
    ~Duck() {
        // 输出提示信息，表示 Duck 析构函数被调用
        cout << "Duck 析构函数被调用" << endl;
    }

    // 重写 makeSound 方法
    // 实现鸭子特有的叫声
    void makeSound() override {
        // 输出鸭子的嘎嘎叫声
        // name 是从 Animal 类继承来的成员变量
        cout << name << " 嘎嘎叫！" << endl;
    }
};

// 主函数
// 程序的入口点，演示继承的各种用法
int main() {
    // ---- 演示基本的单继承 ----
    // Dog 类单继承自 Animal 类，演示最基本的继承关系
    cout << "===== 演示单继承：Dog =====" << endl;
    cout << "--- 创建 Dog 对象 ---" << endl;
    // 创建 Dog 对象时会先调用父类 Animal 的构造函数，再调用 Dog 的构造函数
    // 参数依次为：名称、年龄、品种
    Dog dog("旺财", 3, "金毛");

    cout << endl << "--- 调用继承来的方法 ---" << endl;
    // 调用从 Animal 继承来的 eat 方法
    // 子类可以直接使用父类的公有方法
    dog.eat();
    // 调用从 Animal 继承来的 sleep 方法
    // 子类可以直接使用父类的公有方法
    dog.sleep();

    cout << endl << "--- 调用重写的方法 ---" << endl;
    // 调用 Dog 重写的 makeSound 方法
    // 子类重写父类方法后，调用时会执行子类的版本
    dog.makeSound();

    cout << endl << "--- 调用子类特有的方法 ---" << endl;
    // 调用 Dog 特有的 wagTail 方法
    // 这是 Animal 基类中没有的方法，只有 Dog 类有
    dog.wagTail();
    // 调用 Dog 特有的 guard 方法
    // 这是 Animal 基类中没有的方法，只有 Dog 类有
    dog.guard();

    cout << endl << "--- 访问继承来的成员变量 ---" << endl;
    // name 和 age 是从 Animal 继承来的
    // breed 是 Dog 类自己特有的成员变量
    cout << "名字：" << dog.name << "，年龄：" << dog.age << "岁，品种：" << dog.breed << endl;

    // ---- 演示 Cat 继承 ----
    // Cat 类同样单继承自 Animal 类，演示另一个派生类
    cout << endl << "===== 演示单继承：Cat =====" << endl;
    // 创建 Cat 对象，参数依次为：名称、年龄、是否喜欢抓沙发
    Cat cat("咪咪", 2, true);

    // 调用继承来的 eat 方法
    // Cat 从 Animal 继承了 eat 方法，可以直接调用
    cat.eat();
    // 调用重写的 makeSound 方法
    // Cat 重写了 makeSound，输出猫的叫声
    cat.makeSound();
    // 调用子类特有的 catchMouse 方法
    // 这是 Cat 类独有的方法
    cat.catchMouse();

    // ---- 演示多层继承 ----
    // WorkDog 继承自 Dog，Dog 继承自 Animal，形成三层继承链
    cout << endl << "===== 演示多层继承：WorkDog =====" << endl;
    // 创建 WorkDog 对象
    // 构造顺序：Animal -> Dog -> WorkDog
    cout << "--- 创建 WorkDog 对象 ---" << endl;
    // 参数依次为：名称、年龄、品种、工作类型
    WorkDog wd("小黑", 4, "德国牧羊犬", "搜救");

    // 调用继承来的 eat 方法（来自 Animal）
    // 多层继承中，最底层的子类可以使用所有祖先类的公有方法
    wd.eat();
    // 调用重写的 makeSound 方法（来自 Dog 对 Animal 的重写）
    // WorkDog 没有重写 makeSound，所以使用 Dog 的版本
    wd.makeSound();
    // 调用子类特有的 work 方法（来自 WorkDog）
    // 这是 WorkDog 类独有的方法
    wd.work();

    // ---- 演示多继承 ----
    // Duck 同时继承自 Animal、Flyable 和 Swimmable
    cout << endl << "===== 演示多继承：Duck =====" << endl;
    // 创建 Duck 对象
    cout << "--- 创建 Duck 对象 ---" << endl;
    // 参数依次为：名称、年龄
    Duck duck("唐老鸭", 1);

    // 调用继承来的 eat 方法（来自 Animal）
    // Duck 从 Animal 继承了 eat 方法
    duck.eat();
    // 调用重写的 makeSound 方法（来自 Duck 对 Animal 的重写）
    // Duck 重写了 makeSound，输出鸭子的叫声
    duck.makeSound();
    // 调用从 Flyable 继承的 fly 方法
    // 多继承允许 Duck 同时拥有飞行能力
    duck.fly();
    // 调用从 Swimmable 继承的 swim 方法
    // 多继承允许 Duck 同时拥有游泳能力
    duck.swim();

    // ---- 演示对象销毁顺序 ----
    // 局部变量在 main 函数结束时自动销毁
    // 销毁顺序与构造顺序相反：先构造的后销毁，后构造的先销毁
    cout << endl << "===== 对象销毁顺序（main 函数结束）=====" << endl;

    // 程序正常结束，返回 0
    return 0;
}
