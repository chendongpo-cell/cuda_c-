// 14_继承 / main.cpp
// 本程序演示 C++ 中继承的概念和用法

// 包含输入输出流头文件
#include <iostream>
// 包含字符串头文件
#include <string>
// 使用标准命名空间
using namespace std;

// ---- 基类（父类）：Animal ----
// 这是一个通用的动物类，包含所有动物共有的属性和行为
class Animal {
// 公有成员：所有地方都可以访问
public:
    // 公有成员变量：动物的名称
    string name;
    // 公有成员变量：动物的年龄
    int age;

    // 构造函数：初始化动物的名称和年龄
    Animal(string n, int a) {
        name = n;
        age = a;
        cout << "Animal 构造函数被调用" << endl;
    }

    // 析构函数：对象销毁时调用
    ~Animal() {
        cout << "Animal 析构函数被调用" << endl;
    }

    // 公有成员函数：动物吃东西
    void eat() {
        cout << name << " 正在吃东西..." << endl;
    }

    // 公有成员函数：动物睡觉
    void sleep() {
        cout << name << " 正在睡觉..." << endl;
    }

    // 公有成员函数：动物发出声音（通用的）
    void makeSound() {
        cout << name << " 发出了一些声音" << endl;
    }
};

// ---- 派生类（子类）：Dog ----
// Dog 公开继承自 Animal，拥有 Animal 的所有公有成员
// public 继承方式：父类的 public 成员在子类中仍然是 public
class Dog : public Animal {
public:
    // 子类特有的成员变量：品种
    string breed;

    // 子类的构造函数
    // 在初始化列表中调用父类的构造函数，传递必要的参数
    Dog(string n, int a, string b) : Animal(n, a) {
        // 初始化子类特有的成员
        breed = b;
        cout << "Dog 构造函数被调用" << endl;
    }

    // 子类的析构函数
    ~Dog() {
        cout << "Dog 析构函数被调用" << endl;
    }

    // 重写（Override）父类的 makeSound 方法
    // 子类可以重新定义父类已有的函数
    void makeSound() {
        // 调用父类的 makeSound 方法（通过 :: 作用域运算符）
        // Animal::makeSound();
        // 然后输出狗特有的叫声
        cout << name << " 汪汪叫！" << endl;
    }

    // 子类特有的成员函数：摇尾巴
    void wagTail() {
        cout << name << " 正在摇尾巴..." << endl;
    }

    // 子类特有的成员函数：看门
    void guard() {
        cout << name << " 正在看门..." << endl;
    }
};

// ---- 派生类（子类）：Cat ----
// Cat 也公开继承自 Animal
class Cat : public Animal {
public:
    // 子类特有的成员变量：是否喜欢抓沙发
    bool likesScratching;

    // 子类构造函数，通过初始化列表调用父类构造函数
    Cat(string n, int a, bool scratch) : Animal(n, a) {
        likesScratching = scratch;
        cout << "Cat 构造函数被调用" << endl;
    }

    // 子类析构函数
    ~Cat() {
        cout << "Cat 析构函数被调用" << endl;
    }

    // 重写父类的 makeSound 方法
    void makeSound() {
        cout << name << " 喵喵叫！" << endl;
    }

    // 子类特有的成员函数：抓老鼠
    void catchMouse() {
        cout << name << " 正在抓老鼠..." << endl;
    }
};

// ---- 多层继承演示 ----
// 定义 WorkDog 类，继承自 Dog，形成多层继承链：Animal -> Dog -> WorkDog

// WorkDog 继承自 Dog，因此继承了 Animal 和 Dog 的所有成员
class WorkDog : public Dog {
public:
    // 工作犬特有的成员变量：工作类型
    string workType;

    // 构造函数
    WorkDog(string n, int a, string b, string w) : Dog(n, a, b) {
        workType = w;
        cout << "WorkDog 构造函数被调用" << endl;
    }

    // 析构函数
    ~WorkDog() {
        cout << "WorkDog 析构函数被调用" << endl;
    }

    // 工作犬特有的成员函数：工作
    void work() {
        cout << name << " 正在执行" << workType << "任务..." << endl;
    }
};

// ---- 多继承演示 ----
// 定义 Flyable 类，表示可以飞的能力
class Flyable {
public:
    // 飞行方法
    void fly() {
        cout << "正在飞行..." << endl;
    }
};

// 定义 Swimmable 类，表示可以游泳的能力
class Swimmable {
public:
    // 游泳方法
    void swim() {
        cout << "正在游泳..." << endl;
    }
};

// Duck 继承了 Animal 以及 Flyable 和 Swimmable
// 这就是多继承：一个子类有多个父类
class Duck : public Animal, public Flyable, public Swimmable {
public:
    // 构造函数
    Duck(string n, int a) : Animal(n, a) {
        cout << "Duck 构造函数被调用" << endl;
    }

    // 析构函数
    ~Duck() {
        cout << "Duck 析构函数被调用" << endl;
    }

    // 重写 makeSound
    void makeSound() {
        cout << name << " 嘎嘎叫！" << endl;
    }
};

// 主函数
int main() {
    // ---- 演示基本的单继承 ----
    cout << "===== 演示单继承：Dog =====" << endl;
    cout << "--- 创建 Dog 对象 ---" << endl;
    // 创建 Dog 对象时会先调用父类 Animal 的构造函数，再调用 Dog 的构造函数
    Dog dog("旺财", 3, "金毛");

    cout << endl << "--- 调用继承来的方法 ---" << endl;
    // 调用从 Animal 继承来的 eat 方法
    dog.eat();
    // 调用从 Animal 继承来的 sleep 方法
    dog.sleep();

    cout << endl << "--- 调用重写的方法 ---" << endl;
    // 调用 Dog 重写的 makeSound 方法
    dog.makeSound();

    cout << endl << "--- 调用子类特有的方法 ---" << endl;
    // 调用 Dog 特有的 wagTail 方法
    dog.wagTail();
    // 调用 Dog 特有的 guard 方法
    dog.guard();

    cout << endl << "--- 访问继承来的成员变量 ---" << endl;
    // name 和 age 是从 Animal 继承来的
    cout << "名字：" << dog.name << "，年龄：" << dog.age << "岁，品种：" << dog.breed << endl;

    // ---- 演示 Cat 继承 ----
    cout << endl << "===== 演示单继承：Cat =====" << endl;
    // 创建 Cat 对象
    Cat cat("咪咪", 2, true);

    // 调用继承来的方法
    cat.eat();
    // 调用重写的方法
    cat.makeSound();
    // 调用子类特有的方法
    cat.catchMouse();

    // ---- 演示多层继承 ----
    cout << endl << "===== 演示多层继承：WorkDog =====" << endl;
    // 创建 WorkDog 对象
    // 构造顺序：Animal -> Dog -> WorkDog
    cout << "--- 创建 WorkDog 对象 ---" << endl;
    WorkDog wd("小黑", 4, "德国牧羊犬", "搜救");

    // 调用继承来的方法（来自 Animal）
    wd.eat();
    // 调用重写的方法（来自 Dog 对 Animal 的重写）
    wd.makeSound();
    // 调用子类特有的方法（来自 WorkDog）
    wd.work();

    // ---- 演示多继承 ----
    cout << endl << "===== 演示多继承：Duck =====" << endl;
    // 创建 Duck 对象
    cout << "--- 创建 Duck 对象 ---" << endl;
    Duck duck("唐老鸭", 1);

    // 调用继承来的方法
    duck.eat();
    // 调用重写的方法
    duck.makeSound();
    // 调用从 Flyable 继承的方法
    duck.fly();
    // 调用从 Swimmable 继承的方法
    duck.swim();

    // ---- 演示对象销毁顺序 ----
    // 局部变量在 main 函数结束时自动销毁
    // 销毁顺序与构造顺序相反
    cout << endl << "===== 对象销毁顺序（main 函数结束）=====" << endl;

    return 0;
}
