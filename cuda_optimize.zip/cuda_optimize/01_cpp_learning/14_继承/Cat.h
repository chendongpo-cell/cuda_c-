// Cat.h
// 猫类的头文件，声明 Cat 类的接口
// Cat 公开继承自 Animal，拥有 Animal 的所有公有成员
#ifndef CAT_H  // 如果没有定义 CAT_H 宏
#define CAT_H  // 定义 CAT_H 宏，防止重复包含

// 包含 Animal 类的头文件，因为 Cat 类继承自 Animal 类
#include "Animal.h"
// 包含字符串头文件，以便使用 std::string 类型
#include <string>

// 使用标准命名空间
using namespace std;

// ---- 派生类（子类）：Cat ----
// Cat 也公开继承自 Animal
// public 继承方式：父类的 public 成员在子类中仍然是 public
class Cat : public Animal {
public:
    // 子类特有的成员变量：是否喜欢抓沙发
    // 表示这只猫是否有抓沙发的习惯，布尔类型
    bool likesScratching;

    // 子类构造函数，通过初始化列表调用父类构造函数
    // 参数 n 是名称，参数 a 是年龄，参数 scratch 是是否喜欢抓沙发
    Cat(string n, int a, bool scratch);

    // 子类析构函数
    // 当 Cat 对象销毁时自动调用
    ~Cat();

    // 重写父类的 makeSound 方法
    // override 关键字明确表示这是一个重写操作
    void makeSound() override;

    // 子类特有的成员函数：抓老鼠
    // 只有猫才能抓老鼠，这是猫特有的行为
    void catchMouse();
};

#endif  // 结束条件编译指令
