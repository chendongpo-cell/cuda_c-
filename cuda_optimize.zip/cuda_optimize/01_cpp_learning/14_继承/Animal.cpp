// Animal.cpp
// 动物类的实现文件，包含 Animal 类所有成员函数的实现代码
// 每个函数的具体逻辑都在这里实现

// 包含 Animal 类的头文件，确保声明和实现一致
#include "Animal.h"

// 构造函数：初始化动物的名称和年龄
// 使用初始化列表来初始化 name 和 age 成员变量
// 参数 n 是动物的名称，参数 a 是动物的年龄
Animal::Animal(string n, int a) {
    // 将参数 n 赋值给成员变量 name
    name = n;
    // 将参数 a 赋值给成员变量 age
    age = a;
    // 输出提示信息，表示 Animal 构造函数被调用
    cout << "Animal 构造函数被调用" << endl;
}

// 析构函数：对象销毁时调用
// 当 Animal 对象生命周期结束时，此函数会被自动执行
Animal::~Animal() {
    // 输出提示信息，表示 Animal 析构函数被调用
    cout << "Animal 析构函数被调用" << endl;
}

// 公有成员函数：动物吃东西
// 输出当前动物正在吃东西的信息
void Animal::eat() {
    // 使用 name 成员变量输出具体是哪个动物在吃东西
    cout << name << " 正在吃东西..." << endl;
}

// 公有成员函数：动物睡觉
// 输出当前动物正在睡觉的信息
void Animal::sleep() {
    // 使用 name 成员变量输出具体是哪个动物在睡觉
    cout << name << " 正在睡觉..." << endl;
}

// 虚函数：动物发出声音（通用的）
// 这是基类的默认实现，派生类可以重写此方法
void Animal::makeSound() {
    // 输出通用的动物叫声信息
    cout << name << " 发出了一些声音" << endl;
}
