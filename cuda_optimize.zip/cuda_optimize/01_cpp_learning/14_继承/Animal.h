// Animal.h
// 动物类的头文件，声明基类 Animal 的接口
// 使用 #pragma once 确保头文件只被包含一次
#ifndef ANIMAL_H  // 如果没有定义 ANIMAL_H 宏
#define ANIMAL_H  // 定义 ANIMAL_H 宏，防止重复包含

// 包含字符串头文件，以便使用 std::string 类型
#include <string>
// 包含输入输出流头文件，以便在构造函数和析构函数中输出信息
#include <iostream>

// 使用标准命名空间，方便使用 cout、string 等标准库组件
using namespace std;

// ---- 基类（父类）：Animal ----
// 这是一个通用的动物类，包含所有动物共有的属性和行为
class Animal {
// 公有成员：所有地方都可以访问
public:
    // 公有成员变量：动物的名称
    string name;
    // 公有成员变量：动物的年龄
    int age;

    // 构造函数：初始化动物的名称和年龄
    // 参数 n 表示名称，参数 a 表示年龄
    Animal(string n, int a);

    // 虚析构函数：确保派生类对象被正确销毁
    // 当通过基类指针删除派生类对象时，虚析构函数会调用正确的派生类析构函数
    virtual ~Animal();

    // 公有成员函数：动物吃东西
    void eat();

    // 公有成员函数：动物睡觉
    void sleep();

    // 虚函数：动物发出声音（通用的）
    // 使用 virtual 关键字允许派生类重写此方法
    virtual void makeSound();
};

#endif  // 结束条件编译指令
