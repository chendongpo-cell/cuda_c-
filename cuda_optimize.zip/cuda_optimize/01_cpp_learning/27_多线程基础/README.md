# 27 - 多线程基础 (Multithreading Basics)

## 什么是多线程？

多线程（multithreading）允许一个程序**同时执行多个任务**。每个执行路径称为一个线程（thread），所有线程共享同一个进程的内存空间。

```
单线程:    ──── 任务A ──── 任务B ──── 任务C ────→  时间
多线程:    ──── 任务A ───────────────────────────→
           ──── 任务B ────→
           ──── 任务C ────────→
```

## 为什么使用线程？

| 目的 | 说明 |
|---|---|
| 并行计算 | 利用多核 CPU，加速计算密集型任务 |
| 提高响应性 | GUI 应用中不阻塞主线程 |
| I/O 并发 | 同时等待多个 I/O 操作 |
| 简化建模 | 将并发任务建模为独立的线程 |

## std::thread — 创建和管理线程

C++11 引入了 `<thread>` 库，提供了跨平台的多线程支持。

### 创建线程

```cpp
#include <thread>

void worker() { /* ... */ }

std::thread t1(worker);            // 函数指针
std::thread t2([] { /* ... */ }); // lambda 表达式
std::thread t3(worker, arg1, arg2); // 带参数
```

### 等待线程结束 (join)

```cpp
t1.join();  // 主线程阻塞，等待 t1 执行完毕
```

### 分离线程 (detach)

```cpp
t1.detach();  // 让线程在后台独立运行，不阻塞主线程
```

**重要**：线程在销毁前必须 `join()` 或 `detach()`，否则会调用 `std::terminate()` 导致程序崩溃。

## 数据竞争与竞态条件

### 数据竞争 (Data Race)

多个线程同时访问同一个变量，且至少有一个是写操作，结果取决于线程调度顺序，行为未定义。

### 竞态条件 (Race Condition)

程序的正确结果依赖于线程的执行顺序（即使没有数据竞争）。

## std::mutex — 互斥锁

互斥锁用于保护共享数据，确保同一时间只有一个线程能访问被保护的代码区域。

```cpp
std::mutex mtx;

mtx.lock();     // 加锁（阻塞等待）
// ... 访问共享数据 ...
mtx.unlock();   // 解锁
```

**不要直接使用 lock/unlock**，异常安全问题。推荐使用 RAII 封装：

### std::lock_guard

最简单的 RAII 锁包装，构造时加锁，析构时解锁：

```cpp
{
    std::lock_guard<std::mutex> lock(mtx);
    // 操作共享数据...
}   // 自动解锁
```

### std::unique_lock

更灵活的 RAII 包装，支持延迟加锁、手动解锁、移动语义：

```cpp
std::unique_lock<std::mutex> lock(mtx);         // 构造时加锁
std::unique_lock<std::mutex> lock(mtx, std::defer_lock);  // 延迟加锁
lock.lock();
lock.unlock();  // 可提前解锁
```

## std::atomic — 原子操作

对于简单的共享变量（整数、布尔值等），原子操作比互斥锁更轻量：

```cpp
std::atomic<int> counter{0};

// 线程安全的自增
counter.fetch_add(1);   // 等价于 counter++
counter.store(42);      // 写入
int val = counter.load(); // 读取
```

原子操作由 CPU 硬件保证，没有锁的开销。

## std::condition_variable — 条件变量

条件变量用于线程间通信：一个线程等待某个条件成立，另一个线程通知条件已满足。

```cpp
std::mutex mtx;
std::condition_variable cv;
bool ready = false;

// 等待线程
std::unique_lock<std::mutex> lock(mtx);
cv.wait(lock, [] { return ready; });  // 等待 ready 为 true

// 通知线程
{
    std::lock_guard<std::mutex> lock(mtx);
    ready = true;
}
cv.notify_one();  // 唤醒一个等待线程
// cv.notify_all();  // 唤醒所有等待线程
```

### 生产者-消费者模式

条件变量最经典的用法：一个或多个生产者产生数据，一个或多个消费者处理数据。

## 线程安全的要点

1. **最小化锁的范围**：只包裹必要的代码
2. **避免死锁**：多个锁的获取顺序保持一致；使用 `std::lock` 同时锁定多个互斥锁
3. **优先使用 lock_guard / unique_lock**：避免忘记 unlock
4. **能用 atomic 就不用 mutex**：性能更好
5. **避免在持有锁时调用未知函数**：可能导致死锁
6. **使用 std::async 替代手动线程**：更高级的抽象

## 编译

在 Linux 上编译多线程程序需要链接 pthread 库：

```bash
g++ -std=c++17 main.cpp -lpthread -o main
```

Windows 上的 MinGW 也可能需要 `-lpthread`，MSVC 则不需要。
