/*
 * 文件名: main.cpp
 * 功能:   演示 C++ 多线程基础的各种用法
 * 编译:   g++ -std=c++17 main.cpp -lpthread -o main
 *         (Linux 需要 -lpthread 链接 pthread 库)
 *         (Windows MinGW 也可能需要 -lpthread)
 *
 * 包含:
 *   1. 创建线程的多种方式 (函数、lambda、可调用对象)
 *   2. join 与 detach 的区别
 *   3. 使用 mutex 保护共享数据 (模拟银行账户)
 *   4. lock_guard RAII 自动加解锁
 *   5. atomic 原子计数器
 *   6. 生产者-消费者模型 (condition_variable)
 */

#include <iostream>       // 标准输入输出头文件
#include <thread>         // 线程头文件，提供 std::thread
#include <mutex>          // 互斥锁头文件，提供 std::mutex / lock_guard / unique_lock
#include <atomic>         // 原子操作头文件，提供 std::atomic
#include <condition_variable>  // 条件变量头文件，提供 std::condition_variable
#include <vector>         // 向量容器头文件
#include <queue>          // 队列容器头文件
#include <chrono>         // 时间库头文件，提供时间字面量
#include <functional>     // 函数对象头文件

// 使用 std 命名空间，简化代码
using namespace std;

// 使用时间字面量，如 100ms 表示 100 毫秒
using namespace chrono_literals;

// ============ 全局共享数据 (会被多个线程访问) ============

// 银行账户余额，多个线程会同时存取款
int bankBalance = 1000;

// 保护 bankBalance 的互斥锁
mutex bankMutex;

// 原子计数器: 记录总共完成了多少次操作
// atomic 保证了 fetch_add 操作的原子性，不需要加锁
atomic<int> totalOperations{0};

// ============ 第1部分: 线程函数 ============

// 这是一个普通的函数，可以作为线程的入口点
void helloFunction() {
    // 每个线程都有自己的栈空间，局部变量是线程私有的
    cout << "Hello from function!  线程ID: "
         << this_thread::get_id() << endl;
    // std::this_thread::get_id() 返回当前线程的唯一 ID
}

// 一个可调用对象 (仿函数)
class HelloFunctor {
public:
    // 重载 operator()，使对象可以像函数一样调用
    void operator()() const {
        cout << "Hello from functor!  线程ID: "
             << this_thread::get_id() << endl;
    }
};

// ============ 第2部分: 银行账户操作 (带互斥锁保护) ============

// 存款函数: 向账户添加指定金额
// 参数 amount: 存款金额
void deposit(int amount) {
    // lock_guard: RAII 风格的锁管理
    // 构造时自动调用 bankMutex.lock()
    // 析构时自动调用 bankMutex.unlock()
    // 即使中间抛出异常，也能保证解锁
    lock_guard<mutex> lock(bankMutex);

    // 临界区开始 — 只有一个线程能同时执行此区域
    int oldBalance = bankBalance;            // 读取当前余额

    // 模拟一些计算延迟
    this_thread::sleep_for(10ms);

    bankBalance = oldBalance + amount;       // 增加余额

    // 输出操作信息
    cout << "存款 +" << amount
         << ", 新余额: " << bankBalance
         << " (线程ID: " << this_thread::get_id() << ")"
         << endl;

    totalOperations.fetch_add(1);            // 原子操作: 操作计数加 1
    // 临界区结束 — lock_guard 析构时自动释放锁
}

// 取款函数: 从账户取出指定金额
// 参数 amount: 取款金额
void withdraw(int amount) {
    // unique_lock 比 lock_guard 更灵活
    // 这里我们展示 lock_guard 外的另一种选择
    lock_guard<mutex> lock(bankMutex);

    // 临界区开始
    int oldBalance = bankBalance;

    this_thread::sleep_for(10ms);            // 模拟延迟

    if (bankBalance >= amount) {             // 检查余额是否足够
        bankBalance = oldBalance - amount;   // 减少余额
        cout << "取款 -" << amount
             << ", 新余额: " << bankBalance
             << " (线程ID: " << this_thread::get_id() << ")"
             << endl;
    } else {
        // 余额不足，拒绝取款
        cout << "取款 -" << amount << " 失败! 余额不足 (当前: "
             << bankBalance << ")"
             << " (线程ID: " << this_thread::get_id() << ")"
             << endl;
    }

    totalOperations.fetch_add(1);            // 原子操作: 操作计数加 1
    // 临界区结束 — lock_guard 自动解锁
}

// ============ 第3部分: 无锁保护的错误演示 ============

// 银行的全局余额 (无锁保护，演示数据竞争)
int unsafeBalance = 1000;

// 不带锁的存款函数 — 这会导致数据竞争!
void unsafeDeposit(int amount) {
    // 注意: 这里没有加锁!
    // 多个线程同时执行下面的代码，会导致数据竞争
    int oldBalance = unsafeBalance;          // 读取 (非原子操作)

    this_thread::sleep_for(10ms);            // 模拟延迟

    unsafeBalance = oldBalance + amount;     // 写入 (非原子操作)
    // 问题: 线程A读取 oldBalance=1000，然后被切换出去
    //       线程B也读取 oldBalance=1000，加500后写入1500
    //       线程A继续，加200后写入1200 (覆盖了B的修改!)
    //       结果: 余额变为1200，而不是正确的1700
}

// ============ 第4部分: 生产者-消费者 ============

// 共享队列: 生产者放入数据，消费者取出数据
queue<int> dataQueue;

// 保护队列的互斥锁
mutex queueMutex;

// 条件变量: 用于消费者等待数据，生产者通知消费者
condition_variable dataCondition;

// 最大队列长度
const int MAX_QUEUE_SIZE = 5;

// 生产者标志: false 表示生产者还在工作
// 使用 atomic 确保线程安全
atomic<bool> producerDone{false};

// 生产者线程函数
// 参数 id: 生产者编号
void producer(int id) {
    // 生产 3 个数据项
    for (int i = 1; i <= 3; i++) {
        int data = id * 100 + i;             // 生成一个数据项 (如 101, 102, ...)

        {
            // 使用 unique_lock 配合条件变量
            // 这里用 lock_guard 也可以，但为了演示 unique_lock
            unique_lock<mutex> lock(queueMutex);

            // 如果队列满了，等待消费者消费
            // wait 的第二个参数是一个返回 bool 的 lambda
            // 当条件满足 (队列未满) 时才继续执行
            dataCondition.wait(lock, [] {
                return dataQueue.size() < MAX_QUEUE_SIZE;
            });

            // 将数据放入队列
            dataQueue.push(data);
            cout << "生产者 " << id << " 生产: " << data
                 << " (队列大小: " << dataQueue.size() << ")"
                 << endl;
        }
        // 离开代码块后 unique_lock 解锁

        // 通知一个等待的消费者
        dataCondition.notify_one();

        // 模拟生产间隔
        this_thread::sleep_for(50ms);
    }

    cout << "生产者 " << id << " 完成生产" << endl;
}

// 消费者线程函数
// 参数 id: 消费者编号
void consumer(int id) {
    // 持续消费，直到生产者全部完成且队列为空
    while (true) {
        int data = 0;                        // 存储取出的数据

        {
            // unique_lock 用于条件变量 (lock_guard 不适用)
            unique_lock<mutex> lock(queueMutex);

            // wait 等待条件变量被通知
            // 第二个参数 (lambda) 检查条件:
            //   队列不为空 OR 生产者已经完成
            // 如果条件为 false，线程阻塞并释放锁
            // 被唤醒后重新获取锁并再次检查条件
            dataCondition.wait(lock, [] {
                return !dataQueue.empty() || producerDone.load();
            });

            // 如果队列为空且生产者已完成，退出
            if (dataQueue.empty() && producerDone.load()) {
                break;                       // 没有更多数据了
            }

            // 从队列取出数据
            data = dataQueue.front();        // 获取队首元素
            dataQueue.pop();                 // 弹出队首元素
            cout << "消费者 " << id << " 消费: " << data
                 << " (队列大小: " << dataQueue.size() << ")"
                 << endl;
        }
        // 解锁后通知其他线程

        dataCondition.notify_one();          // 通知生产者队列有空位了

        // 模拟消费耗时
        this_thread::sleep_for(80ms);
    }

    cout << "消费者 " << id << " 完成消费" << endl;
}

// ============ 第5部分: 主函数 ============

int main() {
    // ============================================================
    // 演示1: 创建线程的多种方式
    // ============================================================
    cout << "========== 1. 创建线程的多种方式 ==========" << endl;

    // 方式1: 使用函数指针创建线程
    // thread 构造函数的第一个参数是可调用对象，后续是参数
    thread t1(helloFunction);                // 传入函数名

    // 方式2: 使用 lambda 表达式创建线程
    thread t2([] {
        cout << "Hello from lambda! 线程ID: "
             << this_thread::get_id() << endl;
    });

    // 方式3: 使用可调用对象 (仿函数)
    HelloFunctor functor;                    // 创建仿函数对象
    thread t3(functor);                      // 传入仿函数对象

    // 等待所有创建的线程执行完毕
    // join() 会阻塞当前线程 (主线程) 直到目标线程结束
    t1.join();                               // 等待 t1 完成
    t2.join();                               // 等待 t2 完成
    t3.join();                               // 等待 t3 完成

    cout << endl;

    // ============================================================
    // 演示2: join 与 detach
    // ============================================================
    cout << "========== 2. join vs detach ==========" << endl;

    // 演示 join: 主线程等待子线程完成
    thread joinThread([] {
        this_thread::sleep_for(100ms);       // 模拟工作
        cout << "joinThread 执行完毕" << endl;
    });
    cout << "主线程等待 joinThread..." << endl;
    joinThread.join();                       // 主线程阻塞，直到 joinThread 结束
    cout << "joinThread 已 join，主线程继续" << endl;

    // 演示 detach: 子线程在后台独立运行
    thread detachThread([] {
        this_thread::sleep_for(50ms);        // 模拟工作
        cout << "detachThread 在后台执行完毕" << endl;
    });
    detachThread.detach();                   // 分离线程，不再管理它
    // detach 后，detachThread 不再与任何 thread 对象关联
    // 它在后台独立运行，主线程不会等待它

    cout << "detachThread 已分离，主线程继续" << endl;

    // 等待一下，让 detach 的线程有机会执行
    this_thread::sleep_for(200ms);
    cout << endl;

    // ============================================================
    // 演示3: 使用 mutex 保护共享数据 (正确版本)
    // ============================================================
    cout << "========== 3. mutex 保护共享数据 (银行账户) ==========" << endl;

    // 重置余额
    bankBalance = 1000;
    totalOperations.store(0);

    // 创建多个线程同时存取款
    vector<thread> bankThreads;              // 存储线程对象的向量

    // 创建 5 个存款线程
    for (int i = 0; i < 5; i++) {
        // 每个线程存款 200
        bankThreads.emplace_back(deposit, 200);
    }

    // 创建 5 个取款线程
    for (int i = 0; i < 5; i++) {
        // 每个线程取款 100
        bankThreads.emplace_back(withdraw, 100);
    }

    // 等待所有银行线程完成
    for (auto& t : bankThreads) {
        t.join();                            // 等待每个线程
    }

    // 输出最终结果
    cout << "\n最终余额: " << bankBalance << endl;
    cout << "总操作次数: " << totalOperations.load() << endl;
    cout << "预期余额: 1000 + 5*200 - 5*100 = 1500" << endl;

    // 因为有锁保护，结果应该是正确的 1500

    cout << endl;

    // ============================================================
    // 演示4: 无锁保护导致的数据竞争
    // ============================================================
    cout << "========== 4. 无锁保护 -> 数据竞争 ==========" << endl;

    unsafeBalance = 1000;                    // 重置无保护余额

    vector<thread> unsafeThreads;

    // 创建 10 个线程同时进行无锁存款
    // 每个线程存 100，正确结果应该是 1000 + 10*100 = 2000
    for (int i = 0; i < 10; i++) {
        unsafeThreads.emplace_back(unsafeDeposit, 100);
    }

    for (auto& t : unsafeThreads) {
        t.join();
    }

    cout << "理论正确余额: 2000" << endl;
    cout << "无锁保护实际余额: " << unsafeBalance << endl;
    cout << "(由于数据竞争，结果通常不等于 2000)" << endl;

    cout << endl;

    // ============================================================
    // 演示5: atomic 原子计数器
    // ============================================================
    cout << "========== 5. atomic 原子操作 ==========" << endl;

    // 创建一个原子计数器
    atomic<long long> atomicCounter{0};

    // 创建 100 个线程，每个增加计数器 1000 次
    vector<thread> atomicThreads;

    for (int i = 0; i < 100; i++) {
        atomicThreads.emplace_back([&atomicCounter] {
            for (int j = 0; j < 1000; j++) {
                // fetch_add 是原子操作，不会被其他线程中断
                atomicCounter.fetch_add(1);
                // 等价于 atomicCounter++，但 fetch_add 更明确
            }
        });
    }

    for (auto& t : atomicThreads) {
        t.join();
    }

    cout << "原子计数器期望值: " << (100 * 1000) << endl;
    cout << "原子计数器实际值: " << atomicCounter.load() << endl;
    cout << "(原子操作保证结果准确)" << endl;

    cout << endl;

    // ============================================================
    // 演示6: 生产者-消费者模式 (condition_variable)
    // ============================================================
    cout << "========== 6. 生产者-消费者 (condition_variable) ==========" << endl;

    // 重置状态
    while (!dataQueue.empty()) {
        dataQueue.pop();                     // 清空队列
    }
    producerDone.store(false);               // 设置生产者未完成

    // 创建 2 个生产者线程和 2 个消费者线程
    thread producer1(producer, 1);           // 生产者 1
    thread producer2(producer, 2);           // 生产者 2
    thread consumer1(consumer, 1);           // 消费者 1
    thread consumer2(consumer, 2);           // 消费者 2

    // 等待生产者完成
    producer1.join();
    producer2.join();

    // 设置生产者已完成标志
    // 通知消费者不要再等待了
    {
        lock_guard<mutex> lock(queueMutex);
        producerDone.store(true);            // 生产者全部完成
    }
    dataCondition.notify_all();              // 唤醒所有等待的消费者

    // 等待消费者完成
    consumer1.join();
    consumer2.join();

    cout << "生产者-消费者演示完成!" << endl;
    cout << endl;

    // ============================================================
    // 演示7: 硬件并发信息
    // ============================================================
    cout << "========== 7. 硬件信息 ==========" << endl;

    // thread::hardware_concurrency() 返回 CPU 支持的并发线程数
    // 通常是 CPU 核心数 (含超线程)
    unsigned int cores = thread::hardware_concurrency();
    cout << "本机支持的并发线程数: " << cores << endl;
    cout << "(通常等于 CPU 核心数或逻辑处理器数)" << endl;

    cout << "\n所有演示完成!" << endl;
    return 0;                                // 程序正常退出
}
