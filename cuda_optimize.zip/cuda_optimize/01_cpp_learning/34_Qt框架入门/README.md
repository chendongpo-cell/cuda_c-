# 34_Qt框架入门

## 什么是 Qt？

Qt 是一个跨平台的 C++ 应用程序开发框架，由 Qt Company（原 Trolltech 公司）开发。它被广泛用于开发具有图形用户界面（GUI）的应用程序，但也支持无 GUI 的后端开发。Qt 以其**一次编写，处处编译**（write once, compile anywhere）的理念著称。

知名使用 Qt 的软件：Autodesk Maya、VirtualBox、VLC Media Player、Wireshark、KDE 桌面环境等。

## Qt 模块

Qt 采用模块化架构，按功能划分为多个模块：

### QtWidgets
桌面 GUI 应用程序的核心模块，提供完整的桌面风格控件（widgets）：
- 窗口：QMainWindow、QDialog、QWidget
- 按钮：QPushButton、QRadioButton、QCheckBox
- 输入控件：QLineEdit、QTextEdit、QSpinBox、QComboBox
- 显示控件：QLabel、QProgressBar、QListView、QTableView
- 容器：QGroupBox、QTabWidget、QScrollArea

### QtCore
Qt 的核心非 GUI 模块，提供：
- QObject：所有 Qt 对象的基类
- 信号与槽机制
- QVariant：类型安全的联合类型
- 容器类：QList、QMap、QHash
- 文件和 I/O：QFile、QDataStream
- 线程：QThread、QMutex
- JSON 和 XML 处理

### QtNetwork
网络编程模块：
- QTcpSocket / QUdpSocket：TCP/UDP 套接字
- QHttpMultiPart：HTTP 请求
- QNetworkAccessManager：高级网络请求管理
- QSslSocket：SSL/TLS 加密通信

### 其他常用模块
- QtSql：数据库访问（SQLite、MySQL、PostgreSQL 等）
- QtOpenGL：OpenGL 图形渲染
- QtMultimedia：音频/视频播放与录制
- QtQml / QtQuick：QML 声明式 UI 开发
- QtCharts：数据可视化图表

## 信号与槽（Signals and Slots）

信号与槽是 Qt 最核心、最具特色的机制，用于**对象之间的通信**。

### 基本概念
- **信号（Signal）**：当某个事件发生时，对象发射的信号。例如按钮被点击时发射 `clicked()` 信号。
- **槽（Slot）**：响应信号的函数。当连接的信号被发射时，槽函数会被自动调用。
- **连接（Connect）**：使用 `QObject::connect()` 将信号和槽关联起来。

### 特点
- **类型安全**：信号和槽的签名必须匹配（参数类型一致）
- **松耦合**：发射信号的对象不需要知道哪些槽在监听
- **灵活**：一个信号可以连接多个槽，一个槽可以接收多个信号
- **自动断开**：当 QObject 被销毁时，所有关联的连接自动断开

### 连接语法

```cpp
// 旧式语法（Qt 4）
connect(sender, SIGNAL(clicked()), receiver, SLOT(close()));

// 新式语法（Qt 5+，推荐）
connect(sender, &QPushButton::clicked, receiver, &QWidget::close);

// Lambda 表达式
connect(button, &QPushButton::clicked, [=]() {
    // 处理点击事件
});
```

## Qt 对象模型

### QObject
QObject 是 Qt 对象模型的基类，提供了：
- **对象树（Object Tree）**：QObject 可以拥有子对象，父对象销毁时自动销毁子对象
- **元对象系统**：运行时类型信息、动态属性
- **信号与槽**：对象间通信
- **事件系统**：事件过滤和处理

### MOC（Meta-Object Compiler）
MOC 是 Qt 的元对象编译器，是 Qt 构建过程中的一个额外步骤：
1. 扫描头文件中含有 `Q_OBJECT` 宏的类
2. 生成额外的 C++ 源文件（moc_xxx.cpp）
3. 这些文件包含元对象信息，支持信号与槽、运行时类型识别等功能
4. `QObject` 的子类需要在头文件中包含 `Q_OBJECT` 宏

CMake 中的 MOC 处理：
```cmake
set(CMAKE_AUTOMOC ON)  # 自动运行 MOC
```

## 常用控件

### QPushButton
标准按钮控件：
```cpp
QPushButton *btn = new QPushButton("点击我");
connect(btn, &QPushButton::clicked, [](){ /* 处理点击 */ });
```

### QLabel
文本或图像显示标签：
```cpp
QLabel *label = new QLabel("Hello Qt");
label->setText("更新文本");
```

### QLineEdit
单行文本输入框：
```cpp
QLineEdit *edit = new QLineEdit();
edit->setPlaceholderText("请输入内容...");
QString text = edit->text();  // 获取文本
```

### QTextEdit
多行文本编辑框/显示区：
```cpp
QTextEdit *textEdit = new QTextEdit();
textEdit->setPlainText("多行文本");
textEdit->append("追加一行");
```

## 布局管理

Qt 使用布局管理器自动安排控件位置，无需手动计算坐标。

### QVBoxLayout
垂直布局，控件自上而下排列：
```cpp
QVBoxLayout *layout = new QVBoxLayout();
layout->addWidget(button1);
layout->addWidget(button2);
layout->addWidget(label);
```

### QHBoxLayout
水平布局，控件从左到右排列：
```cpp
QHBoxLayout *layout = new QHBoxLayout();
layout->addWidget(label);
layout->addWidget(button);
```

### 其他布局
- QGridLayout：网格布局，按行/列排列
- QFormLayout：表单布局，标签-字段对
- QStackedLayout：堆叠布局，一次只显示一个控件

### 布局嵌套
布局可以互相嵌套，创建复杂的界面：
```cpp
QVBoxLayout *mainLayout = new QVBoxLayout();
QHBoxLayout *rowLayout = new QHBoxLayout();
rowLayout->addWidget(nameLabel);
rowLayout->addWidget(nameEdit);
mainLayout->addLayout(rowLayout);
```

## 事件处理

Qt 的事件系统允许响应各种用户操作：

- **鼠标事件**：mousePressEvent、mouseReleaseEvent、mouseMoveEvent
- **键盘事件**：keyPressEvent、keyReleaseEvent
- **绘制事件**：paintEvent（自定义绘图）
- **大小调整事件**：resizeEvent
- **定时器事件**：timerEvent

通过重写虚函数来自定义事件处理：
```cpp
class MyWidget : public QWidget {
protected:
    void mousePressEvent(QMouseEvent *event) override {
        // 处理鼠标点击
    }
};
```
