// ============================================================
// 34_Qt框架入门 - Qt 示例程序
//
// 重要说明：
// 本系统可能未安装 Qt 开发库。如果未安装 Qt，此代码无法编译。
// 本文件作为学习参考代码，展示了使用 Qt 创建 GUI 应用程序的
// 完整流程。要编译此程序，需要安装 Qt 库并配置 CMake。
//
// Qt 安装方式：
//   Windows: 从 https://www.qt.io/download 下载安装
//   Linux:   sudo apt install qtbase5-dev qt5-qmake
//   macOS:   brew install qt
//
// CMakeLists.txt 配置示例：
//   find_package(Qt5 REQUIRED COMPONENTS Widgets)
//   target_link_libraries(my_app Qt5::Widgets)
//   set(CMAKE_AUTOMOC ON)
//
// 程序功能描述：
// 1. 创建一个 400x300 的窗口
// 2. 窗口包含一个按钮、一个文本输入框、一个标签
// 3. 点击按钮时，将输入框中的文本复制到标签上显示
// 4. 点击按钮的同时，按钮自身的文本也会发生变化
// ============================================================

// 包含 Qt 小部件模块的头文件
// QApplication 管理 GUI 应用程序的控制流和主要设置
// QPushButton 提供一个可点击的命令按钮
// QLabel 显示文本或图像
// QLineEdit 提供单行文本编辑功能
// QVBoxLayout 垂直排列控件的布局管理器
// QWidget 是所有用户界面对象的基类
#include <QApplication>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QWidget>

/**
 * main - Qt 应用程序的入口函数
 * 创建一个包含按钮、输入框和标签的简单窗口，
 * 演示 Qt 的信号与槽机制。
 *
 * @param argc: 命令行参数的数量
 * @param argv: 命令行参数的数组
 * @return: 应用程序的执行结果码
 */
int main(int argc, char *argv[])
{
    // =====================================================
    // 1. 创建 QApplication 对象
    // 每个 Qt GUI 程序有且只有一个 QApplication 对象
    // 它管理全局资源、事件循环和应用程序设置
    // argc 和 argv 用于处理命令行参数（如 -style, -font 等）
    // =====================================================
    QApplication app(argc, argv);

    // =====================================================
    // 2. 创建主窗口（QWidget）
    // QWidget 是所有 UI 控件的基类
    // 一个空的 QWidget 就是一个最简单的窗口
    // 不设置父对象的 QWidget 会自动成为顶级窗口
    // =====================================================
    QWidget window;                       // 创建一个窗口对象

    // 设置窗口的标题，显示在标题栏上
    window.setWindowTitle("Qt 入门演示");

    // 设置窗口的初始大小，宽度 400 像素，高度 300 像素
    window.resize(400, 300);

    // =====================================================
    // 3. 创建 UI 控件
    // 这里创建三个控件：标签、输入框和按钮
    // 这些控件还没有指定父对象，稍后通过布局管理器关联
    // =====================================================

    // 创建一个标签控件，用于显示文本
    // 初始文本为 "欢迎使用 Qt！"
    QLabel *label = new QLabel("欢迎使用 Qt！");

    // 设置标签文本居中对齐
    label->setAlignment(Qt::AlignCenter);

    // 创建一个单行文本输入框
    // 设置占位提示文本（当输入框为空时显示灰色提示文字）
    QLineEdit *input = new QLineEdit();
    input->setPlaceholderText("在这里输入文字...");

    // 创建一个按钮控件，初始文本为 "点击我"
    QPushButton *button = new QPushButton("点击我");

    // =====================================================
    // 4. 创建布局管理器并添加控件
    // QVBoxLayout 是垂直布局，控件按添加顺序自上而下排列
    // 使用布局管理器后，控件的位置和大小由系统自动管理
    // =====================================================

    // 创建一个垂直布局管理器
    QVBoxLayout *layout = new QVBoxLayout();

    // 依次将控件添加到布局中：标签 -> 输入框 -> 按钮
    layout->addWidget(label);    // 第一行：标签
    layout->addWidget(input);    // 第二行：输入框
    layout->addWidget(button);   // 第三行：按钮

    // 将布局应用到窗口上
    // setLayout 会将窗口的布局设置为指定的布局管理器
    // 同时布局中的控件会自动成为窗口的子对象
    window.setLayout(layout);

    // =====================================================
    // 5. 信号与槽连接
    //
    // 这是 Qt 最核心的机制 —— 信号与槽
    //
    // 功能：当按钮被点击 (clicked) 时，执行三个操作：
    //   1. 将输入框的文字复制到标签上显示
    //   2. 修改按钮自身的文本
    //   3. 清空输入框
    //
    // 使用 C++11 Lambda 表达式作为槽函数
    // [=] 以值捕获方式捕获所有外部变量
    // =====================================================

    // 使用 QObject::connect 连接信号和槽
    // 信号发送者：button 对象
    // 信号：&QPushButton::clicked - 按钮被点击时发射
    // 槽：Lambda 表达式 - 定义点击后的响应行为
    QObject::connect(button, &QPushButton::clicked, [=]() {
        // 获取输入框中的文本内容
        // QLineEdit::text() 返回 QString 类型
        QString text = input->text();

        // 检查输入框是否为空
        if (text.isEmpty()) {
            // 如果输入为空，在标签上显示提示信息
            label->setText("输入为空，请输些文字！");
        } else {
            // 将输入框的文本设置到标签上显示
            // setText 是 QLabel 的成员函数
            label->setText("你输入了：" + text);
        }

        // 修改按钮自身的文本，反馈点击状态
        button->setText("已点击！继续输入...");

        // 清空输入框的内容，方便用户输入新内容
        input->clear();

        // 将输入焦点设置到输入框，用户可以直接输入
        input->setFocus();
    });

    // =====================================================
    // 6. 显示窗口
    // 所有 QWidget 及其子类创建后默认是隐藏的
    // 必须调用 show() 才能显示
    // =====================================================

    // 显示主窗口（及其包含的所有子控件）
    window.show();

    // =====================================================
    // 7. 进入事件循环
    // app.exec() 启动 Qt 的事件循环
    // 程序在此处等待并处理各种事件（鼠标点击、键盘输入等）
    // 当用户关闭窗口时，exec() 返回
    // 返回值作为 main 函数的返回值
    // =====================================================
    return app.exec();
}
