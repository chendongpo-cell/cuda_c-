// ============================================================
// 17_类型转换 main.cpp
// 演示：C++ 四种类型转换 static_cast / dynamic_cast / const_cast / reinterpret_cast
// ============================================================

// 包含输入输出流头文件
#include <iostream>
// 包含 typeinfo 头文件，用于 typeid 运算符（RTTI）
#include <typeinfo>
// 包含 stdexcept 头文件，用于捕获 bad_cast 异常
#include <stdexcept>

// 使用标准命名空间
using namespace std;

// ============================================================
// 基类 Base（含虚函数，是多态类型）
// dynamic_cast 要求基类必须至少有一个虚函数
// ============================================================
class Base {
public:
    // 虚函数：输出 Base 类的标识信息
    virtual void identify() const {
        cout << "这是一个 Base 类对象" << endl;
    }

    // 虚析构函数：确保派生类对象能正确释放
    // 同时也让 Base 成为多态类型（满足 dynamic_cast 要求）
    virtual ~Base() = default;
};

// ============================================================
// 派生类 Derived（继承自 Base）
// ============================================================
class Derived : public Base {
public:
    // 重写基类的虚函数 identify()
    void identify() const override {
        cout << "这是一个 Derived 类对象" << endl;
    }

    // Derived 类特有的函数：打印派生类的额外信息
    void derivedSpecific() const {
        cout << "调用 Derived 特有的函数 derivedSpecific()" << endl;
    }
};

// ============================================================
// 另一个派生类 AnotherDerived（也继承自 Base）
// 演示 dynamic_cast 在兄弟类之间的表现
// ============================================================
class AnotherDerived : public Base {
public:
    // 重写基类的虚函数 identify()
    void identify() const override {
        cout << "这是一个 AnotherDerived 类对象" << endl;
    }

    // AnotherDerived 类特有的函数
    void anotherSpecific() const {
        cout << "调用 AnotherDerived 特有的函数 anotherSpecific()" << endl;
    }
};

// ============================================================
// 辅助函数：打印分隔线
// ============================================================
void printSection(const string& title) {
    cout << endl;
    cout << "==========================================" << endl;
    cout << "  " << title << endl;
    cout << "==========================================" << endl;
}

// ============================================================
// 主函数
// ============================================================
int main() {
    cout << "========== C++ 四种类型转换 演示 ==========" << endl;

    // ============================================================
    // 第一部分：static_cast（静态转换）
    // 编译时检查，用于有明确语义的转换
    // ============================================================
    printSection("static_cast（静态转换）");

    // 1.1 static_cast 用于数字类型之间的转换（安全）
    cout << "--- 数字类型转换 ---" << endl;

    int a = 10;                   // 定义一个整数
    int b = 3;                    // 定义另一个整数

    // 不进行转换的整数除法：结果是整数
    int intResult = a / b;
    cout << "整数除法（不转换）: " << a << " / " << b << " = " << intResult << endl;
    // 输出: 3（小数部分被截断）

    // 使用 static_cast 将其中一个操作数转换为 double
    // static_cast<double>(a) 将 int 类型的 a 转换为 double 类型
    double doubleResult = static_cast<double>(a) / b;
    cout << "浮点除法（static_cast）: " << a << " / " << b << " = " << doubleResult << endl;
    // 输出: 3.33333

    // 1.2 static_cast 将 double 转换为 int（会截断小数部分）
    double pi = 3.1415926;
    int truncated = static_cast<int>(pi);
    cout << "double 转 int: " << pi << " -> " << truncated << endl;
    // 输出: 3.1415926 -> 3

    // 1.3 static_cast 用于枚举类型到整数的转换
    enum Color { RED = 0, GREEN = 1, BLUE = 2 };
    Color c = GREEN;
    int colorValue = static_cast<int>(c);
    cout << "枚举转 int: " << "GREEN = " << colorValue << endl;
    // 输出: GREEN = 1

    // 1.4 static_cast 用于 void* 到具体类型指针的转换
    void* voidPtr = &a;                       // 任何指针都可以隐式转换为 void*
    int* intPtr = static_cast<int*>(voidPtr);  // 使用 static_cast 将 void* 转回 int*
    cout << "void* 转 int*: " << *intPtr << endl;
    // 输出: 10

    // 1.5 static_cast 在继承体系中的上转型（派生类 -> 基类，安全）
    // 上转型是隐式转换，static_cast 是显式写法
    Derived derivedObj;                             // 创建派生类对象
    Base* basePtr = static_cast<Base*>(&derivedObj); // 上转型：Derived* -> Base*
    cout << "static_cast 上转型（Derived* -> Base*）" << endl;
    basePtr->identify();  // 由于 identify() 是虚函数，仍然调用 Derived 版本
    // 输出: 这是一个 Derived 类对象

    // ============================================================
    // 第二部分：dynamic_cast（动态转换）
    // 运行时检查，用于多态继承体系中的安全下转型
    // 需要基类含有虚函数（RTTI 机制）
    // ============================================================
    printSection("dynamic_cast（动态转换）");

    // 2.1 dynamic_cast 安全下转型：把 Base* 转换为 Derived*
    cout << "--- 安全下转型：Base* -> Derived* ---" << endl;

    // 创建一个 Derived 对象，用基类指针指向它
    Base* baseToDerived = new Derived();

    // 使用 dynamic_cast 将 Base* 转换为 Derived*
    // 运行时检查：如果 baseToDerived 实际指向的是 Derived 对象，转换成功
    // 如果指向的是其他派生类，返回 nullptr
    Derived* derivedPtr = dynamic_cast<Derived*>(baseToDerived);

    if (derivedPtr) {
        // 转换成功：说明 baseToDerived 确实指向一个 Derived 对象
        cout << "dynamic_cast 转换成功！" << endl;
        derivedPtr->identify();            // 调用 Derived 的 identify()
        derivedPtr->derivedSpecific();     // 调用 Derived 特有的函数
    } else {
        // 转换失败：baseToDerived 不是指向 Derived 对象
        cout << "dynamic_cast 转换失败！" << endl;
    }

    // 2.2 dynamic_cast 转换失败的情况
    cout << endl << "--- 转换失败的情况 ---" << endl;

    Base* baseToAnother = new AnotherDerived();  // 基类指针指向 AnotherDerived

    // 尝试将 Base* 转换为 Derived*，但实际对象是 AnotherDerived
    Derived* failPtr = dynamic_cast<Derived*>(baseToAnother);

    if (failPtr) {
        // 转换成功（不应进入此分支）
        cout << "转换成功" << endl;
    } else {
        // 转换失败！因为对象实际上是 AnotherDerived，不是 Derived
        // dynamic_cast 返回 nullptr 表示转换失败
        cout << "dynamic_cast 转换失败！返回 nullptr" << endl;
        cout << "原因: 实际对象类型是 AnotherDerived，不是 Derived" << endl;
    }

    // 2.3 dynamic_cast 用于引用（转换失败会抛出异常）
    cout << endl << "--- dynamic_cast 用于引用 ---" << endl;

    try {
        // 创建一个 AnotherDerived 对象
        AnotherDerived anotherObj;
        Base& baseRef = anotherObj;  // 基类引用

        // 尝试将基类引用转换为 Derived 引用
        // 如果转换失败，dynamic_cast 会抛出 std::bad_cast 异常
        Derived& derivedRef = dynamic_cast<Derived&>(baseRef);
        // 如果执行到这里，说明转换成功（不会执行到）
        (void)derivedRef;  // 防止未使用变量的编译器警告
    } catch (const bad_cast& e) {
        // 捕获 bad_cast 异常
        cout << "dynamic_cast 引用转换失败，捕获 bad_cast 异常: ";
        cout << e.what() << endl;
    }

    // 清理动态分配的内存
    delete baseToDerived;
    delete baseToAnother;

    // ============================================================
    // 第三部分：const_cast（常量转换）
    // 用于添加或移除 const/volatile 限定符
    // ============================================================
    printSection("const_cast（常量转换）");

    // 3.1 const_cast 移除 const 限定
    cout << "--- 移除 const 限定 ---" << endl;

    int value = 42;                        // 普通的 int 变量
    const int* constPtr = &value;           // const 指针指向 value

    // *constPtr = 100;  // 编译错误！不能通过 const 指针修改值

    // 使用 const_cast 移除 const 限定
    int* mutablePtr = const_cast<int*>(constPtr);
    // 现在可以修改 value 了（注意：原始对象 value 本身不是 const 的，这样是安全的）
    *mutablePtr = 100;

    cout << "修改后的 value = " << value << endl;
    // 输出: 100

    // 3.2 const_cast 添加 const 限定
    cout << endl << "--- 添加 const 限定 ---" << endl;

    int normalVar = 200;
    // 使用 const_cast 添加 const，得到 const 引用
    const int& constRef = const_cast<const int&>(normalVar);
    // constRef = 300;  // 编译错误！constRef 是 const 引用，不能修改
    cout << "constRef = " << constRef << endl;  // 可以读取

    // 3.3 const_cast 的实际用途：调用接受非 const 参数的旧函数
    cout << endl << "--- const_cast 的实际用途 ---" << endl;

    // 模拟一个接受 non-const char* 的旧式 C 函数
    auto oldCStyleFunction = [](char* str) {
        // 这个函数接受 char*（非 const），但它实际上不会修改字符串
        cout << "旧式函数输出: " << str << endl;
    };

    const char* message = "Hello, const_cast!";  // const 字符串
    // oldCStyleFunction(message);  // 编译错误！const char* 不能隐式转为 char*

    // 使用 const_cast 安全地调用（前提是函数确实不会修改参数）
    oldCStyleFunction(const_cast<char*>(message));

    // 3.4 警告示例：修改真正的 const 对象是未定义行为
    cout << endl << "--- 警告：不要修改真正的 const 对象 ---" << endl;

    const int constValue = 999;             // 真正的 const 对象
    int* dangerousPtr = const_cast<int*>(&constValue);
    // 消除未使用变量的编译器警告
    (void)dangerousPtr;
    // *dangerousPtr = 111;  // 未定义行为！程序可能崩溃
    cout << "constValue = " << constValue << endl;
    cout << "注意：不要通过 const_cast 修改真正的 const 对象，这是未定义行为！" << endl;

    // ============================================================
    // 第四部分：reinterpret_cast（重新解释转换）
    // 最危险的转换，底层比特位的重新解释
    // ============================================================
    printSection("reinterpret_cast（重新解释转换）");

    // 4.1 reinterpret_cast 将指针转换为整数
    cout << "--- 指针与整数的互转 ---" << endl;

    int number = 0x12345678;                          // 一个整数
    uintptr_t address = reinterpret_cast<uintptr_t>(&number);  // 将 int* 转换为整数

    cout << "变量 number 的地址（整数形式）: 0x" << hex << address << dec << endl;
    cout << "通过 reinterpret_cast 转回指针: " << *reinterpret_cast<int*>(address) << endl;

    // 4.2 reinterpret_cast 查看变量的内存字节
    cout << endl << "--- 查看变量的内存表示 ---" << endl;

    float floatVal = 3.14f;                           // 一个 float 值
    unsigned char* bytes = reinterpret_cast<unsigned char*>(&floatVal);  // 转为字节指针

    cout << "float " << floatVal << " 的内存字节（十六进制）: ";
    for (size_t i = 0; i < sizeof(float); i++) {
        // 输出每个字节的十六进制值
        cout << hex << static_cast<int>(bytes[i]) << " ";
    }
    cout << dec << endl;  // 恢复为十进制格式

    // 4.3 reinterpret_cast 在不同类型指针之间转换
    cout << endl << "--- 不同类型指针的转换 ---" << endl;

    int intVal = 65;                                   // 整数 65
    char* charPtr = reinterpret_cast<char*>(&intVal);   // 将 int* 重新解释为 char*

    // char 指针会将 int 的二进制数据解释为 ASCII 字符
    // 注意：结果依赖于系统的字节序（大端/小端）
    cout << "int 值 " << intVal << " 通过 char* 读取的第一个字节: ";
    cout << static_cast<int>(*charPtr) << " (字符: " << *charPtr << ")" << endl;

    // 4.4 reinterpret_cast 的典型用例：序列化/反序列化
    cout << endl << "--- 序列化/反序列化场景 ---" << endl;

    struct Data {
        int id;
        double value;
    };

    Data data = {1, 99.5};                            // 创建一个结构体对象
    unsigned char* raw = reinterpret_cast<unsigned char*>(&data);  // 转为字节数组

    cout << "结构体 Data 的原始字节（可写入文件或网络传输）: ";
    for (size_t i = 0; i < sizeof(Data); i++) {
        cout << hex << static_cast<int>(raw[i]) << " ";
    }
    cout << dec << endl;

    cout << endl;
    cout << "========== 程序结束 ==========" << endl;

    // 程序正常返回
    return 0;
}
