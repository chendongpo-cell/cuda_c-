# 17_类型转换

## 一、为什么需要类型转换

在 C++ 编程中，我们经常需要在不同类型之间进行转换，例如：
- 将 `int` 转换为 `double` 以进行精确计算
- 在继承体系中，将基类指针转换为派生类指针（向下转型）
- 在需要时移除 `const` 限定
- 将一种指针类型重新解释为另一种指针类型

C 语言的强制类型转换 `(type)value` 虽然简单，但不够安全，且难以在代码中搜索。因此 C++ 引入了 **四种命名的类型转换运算符**。

---

## 二、C++ 四种类型转换（Cast Operators）

### 2.1 static_cast（静态转换）

**语法：** `static_cast<目标类型>(表达式)`

**特点：**
- **编译时检查** —— 在编译时进行类型检查
- 最常用的类型转换，用于有明确语义的转换
- 不会进行运行时类型检查，不安全的下转型不会报错

**典型用途：**
```cpp
double d = 3.14;
int i = static_cast<int>(d);               // double → int
Base* bp = static_cast<Derived*>(&base);   // 下转型（不安全，不检查）
```

---

### 2.2 dynamic_cast（动态转换）

**语法：** `dynamic_cast<目标类型>(表达式)`

**特点：**
- **运行时检查** —— 在运行时进行类型检查（依赖 RTTI）
- 只能用于 **多态类型**（基类必须包含虚函数）
- 转换失败时，指针返回 `nullptr`，引用抛出 `std::bad_cast` 异常
- 有运行时开销

**典型用途：**
```cpp
// 安全的向下转型
Base* bp = new Derived();
Derived* dp = dynamic_cast<Derived*>(bp);
if (dp) { /* 转换成功 */ }
```

---

### 2.3 const_cast（常量转换）

**语法：** `const_cast<目标类型>(表达式)`

**特点：**
- 用于 **添加或移除** `const` / `volatile` 限定符
- 只能修改对象的常量性，不能改变类型
- 移除 `const` 后修改原本是 const 的对象是 **未定义行为**
- 主要用于需要兼容旧版 C 代码或第三方库的接口

**典型用途：**
```cpp
const int ci = 10;
int* pi = const_cast<int*>(&ci);  // 移除 const

// 用于兼容接受非 const 指针的旧函数
void old_func(char* str);
const char* msg = "hello";
old_func(const_cast<char*>(msg));
```

**警告：** 如果原始对象本身就是 `const`，通过 `const_cast` 移除 `const` 后修改它是 **未定义行为**。只有当原始对象是非 `const` 但通过 `const` 引用/指针访问时，移除 `const` 修改才是安全的。

---

### 2.4 reinterpret_cast（重新解释转换）

**语法：** `reinterpret_cast<目标类型>(表达式)`

**特点：**
- **最危险** 的转换 —— 在底层重新解释比特位
- 编译器不进行任何类型检查
- 通常用于指针/整数之间的转换，或不同类型指针之间的转换
- 可移植性差，不同平台结果可能不同

**典型用途：**
```cpp
int i = 42;
// 将 int 指针重新解释为 char 指针，查看内存中的每个字节
char* p = reinterpret_cast<char*>(&i);
```

---

## 三、C 风格类型转换 vs C++ 类型转换

| 对比项 | C 风格转换 | C++ 命名转换 |
|--------|-----------|-------------|
| 语法 | `(type)expr` | `xxx_cast<type>(expr)` |
| 安全性 | 无检查 | 不同转换有不同检查 |
| 可搜索性 | 难以搜索 | 易于搜索（xxx_cast） |
| 粒度 | 一种语法通吃所有转换 | 按用途分四种 |
| 推荐度 | 不推荐使用 | 推荐使用 |

**注意：** C 风格转换实际上会尝试 static_cast、const_cast、reinterpret_cast 的组合，可能做了比你预期更多的事情，这增加了风险。

---

## 四、RTTI（运行时类型识别）

`typeid` 运算符和 `dynamic_cast` 都依赖于 RTTI。

```cpp
#include <typeinfo>
Base* bp = new Derived();
cout << typeid(*bp).name();  // 输出 "Derived"
```

可以通过编译器选项关闭 RTTI（某些性能敏感场景），但 `dynamic_cast` 和 `typeid` 将无法正常工作。

---

## 五、总结

| 转换类型 | 关键字 | 检查时机 | 安全性 | 主要用途 |
|---------|--------|---------|-------|---------|
| 静态转换 | `static_cast` | 编译时 | 较高 | 数值转换、明确的下转型 |
| 动态转换 | `dynamic_cast` | 运行时 | 最高 | 多态继承中的安全下转型 |
| 常量转换 | `const_cast` | 编译时 | 中等 | 移除/添加 const |
| 重解释转换 | `reinterpret_cast` | 编译时 | 最低 | 底层比特位重新解释 |

**黄金法则：** 优先使用 `static_cast`，需要运行时安全用 `dynamic_cast`，特殊场景用 `const_cast`，尽量避免 `reinterpret_cast`。
