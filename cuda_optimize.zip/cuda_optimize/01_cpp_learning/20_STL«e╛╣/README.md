# 20 - STL容器 (STL Containers)

## 什么是 STL？

**STL（Standard Template Library，标准模板库）** 是 C++ 标准库的核心组成部分。它提供了一套通用的**容器**、**算法**和**迭代器**，让 C++ 程序员可以高效地进行数据存储和操作。

STL 的三大核心组件：
1. **容器（Containers）**：存储和管理数据的对象
2. **算法（Algorithms）**：对数据进行操作的函数
3. **迭代器（Iterators）**：连接容器和算法的桥梁

## 序列容器 (Sequence Containers)

序列容器按照线性顺序存储元素，每个元素有固定的位置。

### vector（动态数组）
- 在**内存中连续存储**
- 支持随机访问（`O(1)`）
- 在尾部插入/删除效率高（`O(1)` 均摊）
- 在中间或头部插入/删除效率低（需要移动元素，`O(n)`）
- 自动管理内存，动态扩容

```cpp
std::vector<int> vec = {1, 2, 3};
vec.push_back(4);  // 尾部添加元素
int x = vec[2];     // 随机访问，不进行边界检查
int y = vec.at(2);  // 随机访问，进行边界检查（越界抛出异常）
```

### list（双向链表）
- **非连续内存**，由节点通过指针链接
- 不支持随机访问（访问第 n 个元素需要遍历，`O(n)`）
- 在任意位置插入/删除效率高（`O(1)`），只需要修改指针
- 每个节点额外存储前后指针，内存开销较大

```cpp
std::list<int> lst = {1, 2, 3};
lst.push_front(0);   // 头部插入
lst.push_back(4);    // 尾部插入
lst.insert(iter, 5); // 在迭代器位置插入
```

### deque（双端队列）
- 分块的连续存储结构
- 支持随机访问（`O(1)`）
- 在头部和尾部插入/删除效率都很高（`O(1)`）
- 中间插入/删除较慢

### array（固定大小数组）
- C++11 引入，封装了普通数组
- 大小在编译期确定
- 支持随机访问
- 没有动态内存管理开销

### forward_list（单向链表）
- C++11 引入
- 只支持正向遍历
- 比 list 更节省内存（只存储一个方向的指针）

## 关联容器 (Associative Containers)

关联容器中的元素按照**键（key）** 自动排序存储，查找效率高（`O(log n)`）。

### set（集合）
- 存储**不重复**的元素
- 元素自动按升序排列
- 插入、删除、查找都是 `O(log n)`

### map（映射/字典）
- 存储**键值对（key-value pairs）**
- 每个键**唯一**
- 按键自动排序
- 插入、删除、查找都是 `O(log n)`
- 使用 `[]` 运算符可以通过键访问值（如果键不存在会插入默认值）

### multiset
- 与 set 类似，但允许**重复**的键

### multimap
- 与 map 类似，但允许**重复**的键
- 不支持 `[]` 运算符

## 无序容器 (Unordered Containers)

C++11 引入，使用**哈希表**实现，不进行排序。

### unordered_set / unordered_map
- 元素不排序
- 插入、删除、查找平均 `O(1)`，最坏 `O(n)`
- 需要为自定义类型提供哈希函数

## 容器适配器 (Container Adapters)

容器适配器是对基础容器的封装，提供特定的接口。

### stack（栈）
- **后进先出（LIFO）**
- 基于 deque（默认）或 vector、list
- 操作：push（压栈）、pop（出栈）、top（栈顶）

### queue（队列）
- **先进先出（FIFO）**
- 基于 deque（默认）或 list
- 操作：push（入队）、pop（出队）、front（队首）、back（队尾）

### priority_queue（优先队列）
- 元素按优先级出队，默认**最大堆**
- 基于 vector（默认）
- 操作：push、pop、top

## 容器选择指南

| 需求 | 推荐容器 |
|------|---------|
| 需要随机访问 | vector, deque, array |
| 经常在中间插入/删除 | list, forward_list |
| 需要在头尾操作 | deque |
| 按键查找 | map, unordered_map |
| 保持元素唯一 | set, unordered_set |
| LIFO | stack |
| FIFO | queue |
| 按优先级处理 | priority_queue |
