#include <iostream>   // 包含输入输出流头文件，用于 std::cout
#include <vector>     // 包含 vector 容器头文件
#include <list>       // 包含 list 容器头文件
#include <map>        // 包含 map 容器头文件
#include <set>        // 包含 set 容器头文件
#include <stack>      // 包含 stack 容器适配器头文件
#include <queue>      // 包含 queue 和 priority_queue 容器适配器头文件
#include <string>     // 包含字符串头文件，用于 std::string
#include <algorithm>  // 包含算法头文件，用于 std::find 等

int main() {
    // ========== 1. vector（动态数组）演示 ==========

    // 输出标题
    std::cout << "===== 1. vector 演示 =====" << std::endl;

    // 创建一个空的 vector，元素类型为 int
    // vector 是动态数组，可以自动扩容
    std::vector<int> vec;

    // 使用 push_back 在尾部添加元素
    // 每次添加一个元素到 vector 的末尾
    vec.push_back(10);   // vector 变为 [10]
    vec.push_back(20);   // vector 变为 [10, 20]
    vec.push_back(30);   // vector 变为 [10, 20, 30]

    // 使用 size() 获取 vector 中的元素个数
    std::cout << "vector 大小: " << vec.size() << std::endl;

    // 使用 for 循环遍历 vector
    // vec.size() 返回无符号整数，所以 i 使用 size_t 类型
    std::cout << "vector 元素: ";
    for (size_t i = 0; i < vec.size(); ++i) {
        // 使用 [] 运算符访问元素，不进行边界检查
        // 如果索引越界会导致未定义行为
        std::cout << vec[i] << " ";
    }
    std::cout << std::endl;

    // 使用 at() 访问元素，at 会进行边界检查
    // 如果索引越界，会抛出 std::out_of_range 异常
    std::cout << "vec.at(1) = " << vec.at(1) << std::endl;

    // 使用 front() 获取第一个元素
    std::cout << "vec.front() = " << vec.front() << std::endl;

    // 使用 back() 获取最后一个元素
    std::cout << "vec.back() = " << vec.back() << std::endl;

    // 使用 pop_back() 删除最后一个元素
    vec.pop_back();          // 删除 30，vector 变为 [10, 20]
    std::cout << "pop_back 后的大小: " << vec.size() << std::endl;

    // 使用范围 for 循环（C++11 起可用）遍历 vector
    // const auto& 表示常量引用，避免拷贝，提高效率
    std::cout << "范围 for 遍历: ";
    for (const auto& val : vec) {
        // 输出 vector 中的每个元素
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 在指定位置插入元素
    // vec.begin() 返回指向第一个元素的迭代器
    // 在开头插入元素 5
    vec.insert(vec.begin(), 5);    // vector 变为 [5, 10, 20]
    std::cout << "开头插入 5 后: ";
    for (const auto& val : vec) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 删除指定位置的元素
    // 删除第二个元素（索引为 1，即值 10）
    vec.erase(vec.begin() + 1);    // vector 变为 [5, 20]
    std::cout << "删除第二个元素后: ";
    for (const auto& val : vec) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 清空 vector
    vec.clear();                   // vector 变为 []
    std::cout << "clear 后的大小: " << vec.size() << std::endl;

    std::cout << std::endl;

    // ========== 2. list（双向链表）演示 ==========

    // 输出标题
    std::cout << "===== 2. list 演示 =====" << std::endl;

    // 创建一个空的 list，元素类型为 int
    // list 是双向链表，适合频繁插入删除操作
    std::list<int> myList;

    // 在尾部添加元素
    myList.push_back(10);          // list 变为 [10]
    myList.push_back(20);          // list 变为 [10, 20]

    // 在头部添加元素（vector 没有 push_front）
    // 这是 list 的优势之一，头部插入 O(1)
    myList.push_front(5);          // list 变为 [5, 10, 20]
    myList.push_front(1);          // list 变为 [1, 5, 10, 20]

    // 输出 list 的大小
    std::cout << "list 大小: " << myList.size() << std::endl;

    // 遍历 list 并输出元素
    // list 不支持随机访问（不能使用 []），只能通过迭代器遍历
    std::cout << "list 元素: ";
    for (const auto& val : myList) {
        // 输出 list 中的每个元素
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 在指定位置插入元素
    // 先获取指向第二个元素（值 5）的迭代器
    auto it = myList.begin();       // it 指向第一个元素（1）
    ++it;                           // it 指向第二个元素（5）
    // 在 it 指向的位置前面插入元素 3
    myList.insert(it, 3);           // list 变为 [1, 3, 5, 10, 20]
    std::cout << "插入 3 后: ";
    for (const auto& val : myList) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 删除指定位置的元素
    // 删除值为 10 的元素
    // std::find 在 list 中查找值为 10 的元素，返回指向该元素的迭代器
    auto findIt = std::find(myList.begin(), myList.end(), 10);
    // 检查是否找到了（如果没找到，findIt 等于 myList.end()）
    if (findIt != myList.end()) {
        // 删除找到的元素
        myList.erase(findIt);       // list 变为 [1, 3, 5, 20]
        std::cout << "删除 10 后: ";
        for (const auto& val : myList) {
            std::cout << val << " ";
        }
        std::cout << std::endl;
    }

    std::cout << std::endl;

    // ========== 3. map（键值对映射）演示 ==========

    // 输出标题
    std::cout << "===== 3. map 演示 =====" << std::endl;

    // 创建一个 map，键为 string 类型，值为 int 类型
    // map 内部使用红黑树实现，按键自动排序
    std::map<std::string, int> scores;

    // 使用 insert 方法插入键值对
    // std::make_pair 创建一个 pair 对象
    scores.insert(std::make_pair("Alice", 95));
    scores.insert(std::make_pair("Bob", 87));
    scores.insert(std::make_pair("Charlie", 92));

    // 使用 [] 运算符插入键值对
    // 如果键 "David" 不存在，会创建一个新的键值对
    scores["David"] = 78;

    // 使用 [] 运算符访问值
    // 注意：如果键不存在，[] 会创建默认值（int 的默认值为 0）
    std::cout << "Alice 的成绩: " << scores["Alice"] << std::endl;
    std::cout << "Bob 的成绩: " << scores["Bob"] << std::endl;

    // 使用 find 方法查找键值对
    // find 返回指向键值对的迭代器，如果没找到返回 end()
    auto mapIt = scores.find("Charlie");
    // 检查是否找到
    if (mapIt != scores.end()) {
        // mapIt 指向一个 pair<const string, int>
        // first 是键（key），second 是值（value）
        std::cout << "找到 Charlie，成绩为: " << mapIt->second << std::endl;
    }

    // 使用 count 方法检查键是否存在
    // 对于 map，count 仅返回 0 或 1（因为键唯一）
    if (scores.count("Eve") == 0) {
        // count 返回 0 表示键不存在
        std::cout << "Eve 不在 map 中" << std::endl;
    }

    // 遍历 map
    // map 中的元素是 pair<const Key, Value> 类型
    std::cout << "所有成绩:" << std::endl;
    for (const auto& entry : scores) {
        // entry.first 是键，entry.second 是值
        std::cout << "  " << entry.first << ": " << entry.second << std::endl;
    }

    // 使用 [] 的注意事项：即使只访问，[] 也会插入默认值
    // map 中现在还没有 "Frank"
    // 下面的代码不会输出 Frank，因为使用 [] 会创建一个默认值为 0 的键值对
    // 所以之后 count("Frank") 会返回 1！
    std::cout << "Frank 的成绩（通过 [] 访问）: " << scores["Frank"] << std::endl;
    std::cout << "注意：上面的 [] 访问导致 Frank 被插入 map！" << std::endl;
    std::cout << "Frank 现在在 map 中吗？" << (scores.count("Frank") > 0 ? "是" : "否") << std::endl;

    // 正确的检查方法是 find，不会插入新元素
    auto frankIt = scores.find("Frank");
    if (frankIt != scores.end()) {
        std::cout << "find 找到 Frank，值为: " << frankIt->second << std::endl;
    }

    std::cout << std::endl;

    // ========== 4. set（集合）演示 ==========

    // 输出标题
    std::cout << "===== 4. set 演示 =====" << std::endl;

    // 创建一个 set，元素类型为 int
    // set 存储不重复的元素，自动排序
    std::set<int> mySet;

    // 插入元素
    mySet.insert(3);                // set 变为 {3}
    mySet.insert(1);                // set 变为 {1, 3}
    mySet.insert(4);                // set 变为 {1, 3, 4}
    mySet.insert(1);                // 重复插入 1，set 不变！

    // 输出 set 的大小
    std::cout << "set 大小: " << mySet.size() << std::endl;

    // 遍历 set
    // 元素会自动按升序排列
    std::cout << "set 元素（自动排序且唯一）: ";
    for (const auto& val : mySet) {
        // 输出 set 中的每个元素
        std::cout << val << " ";
    }
    std::cout << std::endl;

    // 再次插入 1，set 不会变化
    auto insertResult = mySet.insert(1);
    // insert 返回一个 pair，second 为 bool 表示是否插入成功
    if (!insertResult.second) {
        // 插入失败，因为 1 已经存在
        std::cout << "1 已存在，插入无效" << std::endl;
    }

    // 使用 count 检查元素是否存在
    if (mySet.count(3) > 0) {
        std::cout << "set 中包含 3" << std::endl;
    }
    if (mySet.count(10) == 0) {
        std::cout << "set 中不包含 10" << std::endl;
    }

    // 删除元素
    mySet.erase(3);                 // set 变为 {1, 4}
    std::cout << "删除 3 后: ";
    for (const auto& val : mySet) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    std::cout << std::endl;

    // ========== 5. stack（栈）演示 ==========

    // 输出标题
    std::cout << "===== 5. stack 演示 =====" << std::endl;

    // 创建一个空的栈
    // stack 是容器适配器，默认基于 deque 实现
    std::stack<int> myStack;

    // push：将元素压入栈顶
    myStack.push(10);               // 栈：[10]
    myStack.push(20);               // 栈：[10, 20]  20 在栈顶
    myStack.push(30);               // 栈：[10, 20, 30]  30 在栈顶

    // top：获取栈顶元素（但不删除）
    std::cout << "栈顶元素: " << myStack.top() << std::endl;

    // pop：弹出栈顶元素（不返回被删除的元素）
    myStack.pop();                  // 栈变为 [10, 20]
    std::cout << "pop 后栈顶元素: " << myStack.top() << std::endl;

    // 循环弹出所有元素
    // empty() 判断栈是否为空
    std::cout << "依次弹出所有元素: ";
    while (!myStack.empty()) {
        // 获取栈顶元素
        std::cout << myStack.top() << " ";
        // 弹出栈顶元素
        myStack.pop();
    }
    std::cout << std::endl;
    // 此时栈为空
    std::cout << "栈为空吗？" << (myStack.empty() ? "是" : "否") << std::endl;

    std::cout << std::endl;

    // ========== 6. queue（队列）演示 ==========

    // 输出标题
    std::cout << "===== 6. queue 演示 =====" << std::endl;

    // 创建一个空的队列
    // queue 是容器适配器，默认基于 deque 实现
    std::queue<int> myQueue;

    // push：将元素入队（添加到队尾）
    myQueue.push(10);               // 队列：[10]
    myQueue.push(20);               // 队列：[10, 20]  10 在队首
    myQueue.push(30);               // 队列：[10, 20, 30]  10 在队首

    // front：获取队首元素
    std::cout << "队首元素: " << myQueue.front() << std::endl;

    // back：获取队尾元素
    std::cout << "队尾元素: " << myQueue.back() << std::endl;

    // pop：弹出队首元素
    myQueue.pop();                  // 队列变为 [20, 30]
    std::cout << "pop 后队首元素: " << myQueue.front() << std::endl;

    // 循环弹出所有元素
    std::cout << "依次出队: ";
    while (!myQueue.empty()) {
        // 获取队首元素
        std::cout << myQueue.front() << " ";
        // 弹出队首元素
        myQueue.pop();
    }
    std::cout << std::endl;

    std::cout << std::endl;

    // ========== 7. priority_queue（优先队列）演示 ==========

    // 输出标题
    std::cout << "===== 7. priority_queue 演示 =====" << std::endl;

    // 创建一个空的优先队列
    // 默认是最大堆，最大的元素在队首
    std::priority_queue<int> myPQ;

    // 随机插入一些元素
    // 内部会维护堆结构，每次插入 O(log n)
    myPQ.push(30);                  // 内部堆：[30]
    myPQ.push(10);                  // 内部堆：[30, 10]
    myPQ.push(50);                  // 内部堆：[50, 10, 30]
    myPQ.push(20);                  // 内部堆：[50, 20, 30, 10]

    // top：返回优先级最高的元素（最大堆中就是最大值）
    std::cout << "优先级最高的元素: " << myPQ.top() << std::endl;

    // 循环弹出所有元素（会按从大到小的顺序）
    std::cout << "按优先级依次出队: ";
    while (!myPQ.empty()) {
        // 获取优先级最高的元素
        std::cout << myPQ.top() << " ";
        // 弹出优先级最高的元素
        myPQ.pop();
    }
    std::cout << std::endl;

    std::cout << std::endl;

    // ========== 总结 ==========

    // 输出最终总结
    std::cout << "===== STL 容器演示结束 =====" << std::endl;

    // main 函数返回 0 表示程序正常结束
    return 0;
}
