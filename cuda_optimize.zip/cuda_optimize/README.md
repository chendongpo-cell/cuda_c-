# cuda_optimize — AI 推理优化工程师学习项目

系统学习 AI 推理优化的工程实践，从 C++/CUDA 基础到手写推理引擎，覆盖 vLLM/SGLang 源码、算子优化、量化、DCU/HIP 迁移。

---

## 快速导航

| 你想做什么 | 看这里 |
|-----------|--------|
| 了解项目全貌和学习路线 | [docs/LEARNING_ROADMAP.md](docs/LEARNING_ROADMAP.md) |
| 0 基础不知道怎么开始 | [docs/00_getting_started.md](docs/00_getting_started.md) |
| 遇到不懂的术语 | [docs/glossary.md](docs/glossary.md) |
| Python → C++/CUDA 心智模型 | [docs/foundations/](docs/foundations/) |

---

## 目录结构（按学习顺序排列）

```
cuda_optimize/
│
├── README.md
│
├── 📚 docs/                              # 所有学习文档
│   ├── LEARNING_ROADMAP.md               # 12 阶段总路线图
│   ├── 00_getting_started.md             # 0 基础入门
│   ├── glossary.md                       # 术语词典
│   ├── foundations/                      # Python→C++ 桥梁 / 硬件 / 工具链
│   ├── 01_cpp17_basics.md ~ 26_xxx.md   # 推理专题文档 (26篇)
│   ├── 13_sugon_hygon_cpu.md             # 海光 CPU 优化
│   ├── 14_sugon_dcu_hip.md               # DCU + HIP 编程
│   └── ai4s/                             # AI4S 模型迁移分析
│
├── 🟢 01_cpp_learning/                   # C++ 从零 (35课 + 综合项目)
│   ├── STAGE1~5_*.md                     # 5 阶段学习导航
│   ├── 01_HelloWorld/ ~ 35_Boost库入门/  # 带代码的课程
│   └── 36_EmployeeManagementSystem/      # 综合实战
│
├── 🟢 02_cpp_infra/                      # C++ 推理场景实战
│   ├── src/  raii_demo.cpp              # RAII & 智能指针 (GPU 显存管理)
│   ├── src/  template_demo.cpp          # 模板 & 变参 (泛型 Kernel 封装)
│   └── src/  modern_features.cpp        # Lambda / Move / Optional
│
├── 🟡 03_cuda_kernels/                   # CUDA Kernel 编程
│   ├── vector_add.cu                     # 入门: 向量加法
│   ├── reduction.cu                      # 树形归约 (Attention softmax 基础)
│   ├── matmul.cu                         # GEMM: 朴素 → Tiled → cuBLAS
│   └── matmul_tensorcore.cu              # TensorCore wmma 实战
│
├── 🟡 04_pytorch_extension/              # PyTorch 自定义算子
│   ├── custom_relu_matmul.py            # autograd.Function 自定义算子
│   ├── torch_compile_demo.py            # torch.compile 性能对比
│   ├── stream_demo.py                   # CUDA Stream/Event
│   └── csrc/fused_relu_matmul_kernel.cu # CUDA kernel 源码
│
├── 🔵 05_attention/                      # Attention 机制 (Python ↔ CUDA 对照)
│   ├── python/
│   │   ├── standard_attention.py        # Attention 原理
│   │   ├── kv_cache_demo.py             # KV Cache 效果对比
│   │   ├── attention_profiling.py       # PyTorch Profiler
│   │   ├── prefix_caching_demo.py      # Prefix Caching 简化版
│   │   └── eagle_speculative_demo.py   # EAGLE 投机解码教学版
│   └── cuda/
│       ├── attention.cu                  # Attention 前向 CUDA 版
│       ├── kv_cache.cu                   # KV Cache CUDA 版
│       └── flash_attention.cu            # FlashAttention CUDA 版
│
├── 🔵 06_flash_attention/                # FlashAttention Triton 实现
│   └── flash_attention_triton.py
│
├── 🔵 07_quantization/                   # 量化 (Python ↔ CUDA 对照)
│   ├── python/
│   │   ├── int8_gemm_sim.py             # INT8 GEMM 模拟
│   │   ├── kv_cache_quant_sim.py        # KV Cache 量化模拟
│   │   ├── awq_real_deploy.py           # AWQ 真实部署 + benchmark
│   │   └── gptq_vs_awq_deploy.py        # GPTQ vs AWQ 对比
│   └── cuda/
│       ├── int8_gemm.cu                  # INT8 GEMM CUDA 版
│       └── kv_cache_quant.cu             # KV Cache 量化 CUDA 版
│
├── 🔴 08_vllm_analysis/                  # vLLM 源码分析
│   └── source_notes.py                   # V1 代码阅读导航
│
├── 🔴 09_sglang_analysis/                # SGLang 源码分析
│   └── source_notes.py                   # 5 周阅读计划
│
├── 🔴 10_inference_engine/               # 手写推理引擎 (Python ↔ C++ 对照)
│   ├── python/
│   │   ├── model.py                      # 简化 Transformer (TinyLLM)
│   │   ├── kv_cache.py                   # 分页 KV Cache
│   │   ├── scheduler.py                  # Continuous Batching 调度器
│   │   ├── engine.py                     # 主循环: prefill + decode
│   │   ├── run_demo.py                   # 模拟并发请求
│   │   ├── preemption_demo.py           # Preemption RECOMPUTE/SWAP
│   │   └── benchmark_serving.py         # 服务化 benchmark
│   └── cpp/
│       ├── paged_kv_cache.cu             # 分页 KV Cache CUDA 版
│       ├── scheduler.cpp                 # 调度器 C++ 版
│       └── engine.cpp                    # 引擎主循环 C++ 版
│
├── 🟣 11_dcu_migration/                  # DCU / HIP 迁移
│   ├── hip_vector_add.cpp               # HIP 向量加法 (CUDA 对照)
│   ├── hip_matmul.cpp                   # HIP 矩阵乘法
│   ├── hipify_demo.sh                   # CUDA→HIP 自动迁移
│   └── wavefront_adapt.md              # Wavefront=64 适配指南
│
└── 🟣 12_sugon_cpu/                      # 海光 CPU 优化 (待添加)
```

---

## 学习路线

```
第 1 步：理解全局
  docs/LEARNING_ROADMAP.md + 00_getting_started.md + glossary.md
  └── 跑 Python 代码建立手感

第 1 月：C++ / CUDA / Attention 基础
  01_cpp_learning → 02_cpp_infra → 03_cuda_kernels → 04_pytorch_extension → 05_attention

第 2 月：推理框架源码
  08_vllm_analysis → 09_sglang_analysis → 10_inference_engine/python (调度器/KV Cache)

第 3 月：算子优化 + 手写引擎
  06_flash_attention → 07_quantization → 10_inference_engine/cpp

曙光平台专题 (穿插进行)
  11_dcu_migration + docs/13_sugon_hygon_cpu.md + docs/14_sugon_dcu_hip.md + docs/ai4s/
```

---

## 环境要求

| 代码 | 需要什么 | 状态 |
|------|---------|:----:|
| 01_cpp_learning | g++ / MSVC | ✅ 本地 |
| 02_cpp_infra | g++ / CMake | ✅ 本地 |
| 04_pytorch_extension (Python) | Python + PyTorch (CPU) | ✅ 本地 |
| 05_attention/python | Python + PyTorch (CPU) | ✅ 本地 |
| 07_quantization/python | Python + numpy | ✅ 本地 |
| 10_inference_engine/python | Python + PyTorch (CPU) | ✅ 本地 |
| 03_cuda_kernels | nvcc + NVIDIA GPU | 需远程 GPU |
| 05_attention/cuda | nvcc + NVIDIA GPU | 需远程 GPU |
| 06_flash_attention | GPU + Triton | 需远程 GPU |
| 07_quantization/cuda | nvcc + NVIDIA GPU | 需远程 GPU |
| 10_inference_engine/cpp | nvcc + NVIDIA GPU | 需远程 GPU |
| 11_dcu_migration | ROCm + DCU | 需曙光机器 |

---

## 快速运行

```bash
# Python 代码 (本地可跑)
python 05_attention/python/standard_attention.py
python 05_attention/python/kv_cache_demo.py
python 07_quantization/python/int8_gemm_sim.py
python 07_quantization/python/kv_cache_quant_sim.py
python 10_inference_engine/python/run_demo.py

# C++ 基础 (本地可跑)
cd 02_cpp_infra
mkdir build && cd build && cmake .. && cmake --build .

# CUDA (需要远程 GPU)
cd 03_cuda_kernels && mkdir build && cd build
cmake .. -DCMAKE_CUDA_ARCHITECTURES="80" && cmake --build .
./vector_add && ./reduction && ./matmul
```
